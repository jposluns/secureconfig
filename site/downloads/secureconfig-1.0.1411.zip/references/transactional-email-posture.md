# Transactional email posture: authenticating the mail your deployment sends

Transactional email is the automatic mail an app sends to individual users, such as account confirmations and reset links. This guide helps your AI assistant make that mail trustworthy, including SPF, DKIM and enforced DMARC, TLS before SMTP login with no open relay, and MTA-STS for mail your domain receives.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/transactional-email-posture.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against SPF RFC 7208, DKIM RFC 6376, DKIM cryptography RFC 8301, DMARC RFC 9989, DMARC aggregate reporting RFC 9990, DMARC failure reporting RFC 9991, Submission TLS RFC 8314, and SMTP submission roles RFC 6409, plus 8 more recorded bases; 1 further source carries no recorded version. Metadata reviewed 2026-10-05; documentation checked September 2026. The guide records 31 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Password resets, sign-in links, and invitations are part of your authentication path: a recipient who trusts a forged one hands an attacker the account. The controls that stop that forgery are not a single service's settings but three DNS-published standards (SPF, DKIM, and DMARC), the submission channel your application sends through, and the transport policy between mail servers. This guide covers that posture for a deployment that sends transactional mail. It is standards-based rather than product-based, so [authentication.md](authentication.md) covers the account side and [secrets.md](secrets.md) covers the SMTP credential and DKIM private key you will handle here.

The through-line: a spoofable sender undermines every message your users are trained to act on, an open relay burns your sending reputation and gets your mail blocked, and an authenticated but plaintext submission leaks the credential that lets an attacker send as you. All values below (domains, IPs, selectors, keys) are illustrative; replace them with your own deployment inventory.

## 1. SPF: authorize the sending IPs

SPF publishes, as a DNS TXT record, the IP addresses allowed to send for a domain. A receiver checks the record against the connecting IP and the envelope `MAIL FROM` domain (the `HELO` name for a null return path); it does not check the visible `From:` header, which is why SPF alone does not stop header spoofing and only becomes useful once DMARC ties it to `From:`.

```dns
bounce.example.com. 3600 IN TXT "v=spf1 ip4:192.0.2.10 include:_spf.provider.example -all"
```

The final mechanism decides unmatched senders: `-all` fails them, `~all` softfails (many receivers still deliver a softfail), and `+all` or a bare `all` passes everyone, which destroys the record's meaning. Publish exactly one SPF record per evaluated domain; a domain with two `v=spf1` records is a `permerror`. SPF also caps the terms that trigger DNS lookups (`include`, `a`, `mx`, `ptr`, `exists`, and the `redirect` modifier) at ten across the whole recursion, and exceeding that is a `permerror` that voids the result; `ip4`, `ip6`, and `all` do not count against the ten (RFC 7208 sections 4.5 and 4.6.4). A long chain of provider `include`s is the usual way a domain silently blows the budget: any evaluation that has to walk the whole chain returns `permerror`, though a sender matched by an earlier mechanism such as a listed `ip4` still passes, because evaluation stops at the first match. A `permerror` is not an SPF pass, so legitimate mail that reached it and relied on SPF alignment fails your own DMARC. It breaks your authentication, not an attacker's.

What remains unverified until you inspect your own zone: the real envelope domain, the provider `include` targets, the live recursive lookup count, and whether a second SPF record was left behind by an earlier vendor.

## 2. DKIM: sign with a rotatable key

DKIM attaches a cryptographic signature to each message and publishes the matching public key at a selector under the signing domain. The signature names its domain as `d=` and its selector as `s=`; the receiver fetches the key from the selector record under `_domainkey` (here `tx202609._domainkey.example.com`) to verify it. DKIM proves the signed headers and body were not altered and were authorized by the `d=` domain; it does not encrypt the message.

```dns
tx202609._domainkey.example.com. 3600 IN TXT "v=DKIM1; k=rsa; p=MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA..."
```

The `p=` value above is a truncated illustrative key; publish the full base64 your signer generates. Sign with `rsa-sha256`: RFC 8301 prohibits `rsa-sha1` outright, sets a hard floor of 1024-bit RSA keys, and recommends 2048-bit or larger, so treat 2048-bit as the working minimum rather than the 1024-bit floor. Rotate by publishing a new selector's public key first, switching signing to it, and only then retiring the old selector once mail signed with it has cleared the network; an empty `p=` revokes a key. Publishing a key is not enough on its own: the sending service must actually sign, and a receiver must actually verify, before DKIM contributes to a DMARC pass.

Unverified until checked in your deployment: whether signing is enabled, the live `d=` and selector, the key length, whether the key is a TXT record or a provider CNAME delegation, and who owns rotation.

## 3. DMARC: align authentication to the visible From and enforce

DMARC is the record that finally protects the `From:` your users see. A message passes DMARC when at least one of SPF or DKIM both passes and is aligned: SPF alignment compares the envelope domain, DKIM alignment compares the verified signature's `d=`, each against the visible `From:` domain. Relaxed alignment (`adkim=r`, `aspf=r`, the default) accepts the same organizational domain; strict (`s`) requires an exact match.

```dns
_dmarc.example.com. 3600 IN TXT "v=DMARC1; p=reject; sp=reject; np=reject; adkim=r; aspf=r; rua=mailto:dmarc-agg@example.com"
```

`p=` sets the requested handling of failures: `none` asks for no change (monitor only, and still spoofable), `quarantine` asks receivers to treat failures as suspicious, and `reject` asks them to reject at SMTP time. `sp=` sets the policy for existing subdomains and `np=` for non-existent ones; where a tag is absent, policy falls back `np` to `sp` to `p`, so a `p=reject` domain already rejects for its own subdomains without them. Publish `sp` and `np` when you want subdomains held to a policy of their own, whether it repeats or differs from `p`, and inventory any subdomain that publishes its own DMARC record, since a receiver's tree walk finds that record first. DMARC discovers the applicable policy and organizational domain by a DNS tree walk (RFC 9989 section 4.10), which replaced the old public-suffix-list method. `t=y` weakens enforcement for testing and `t=n` is the default; the enforcement record above omits it.

Reach `p=reject` only after a monitoring period under `p=none` with aggregate reports confirms every legitimate stream aligns, or you will reject your own mail. Missing DMARC or `p=none` means no enforcement is requested, not that mail is guaranteed to arrive; receivers keep their own local policy. One legacy note: RFC 9989 (May 2026), which now defines DMARC and obsoletes RFC 7489, removed the `pct` tag, so a `pct` value is not a current rollout control, and a legacy `p=reject; pct=25` was partial application rather than full enforcement.

Unverified until checked: which streams actually align, the inherited and explicit subdomain policies, and whether your receivers implement the current specification.

## 4. DMARC reporting: aggregate now, failure reports later

Aggregate reporting (`rua=`, RFC 9990) sends a daily XML summary of authentication results and is how you see what is sending as your domain before you enforce; turn it on first. A destination in another domain must authorize the reports, or receivers will not send them:

```dns
example.com._report._dmarc.collector.example.net. IN TXT "v=DMARC1"
```

Failure reporting (`ruf=`, RFC 9991) sends per-message forensic copies that can include message content and recipient data, which for password-reset mail can mean leaking a live reset token to whatever inbox collects the reports. Omit `ruf` at first, and enable it only after you have settled collection, redaction, retention, and access, and authorized any external destination the same way. Publication alone is not evidence reports arrive: verify the mailbox actually receives and processes them.

## 5. SMTP submission and relay: TLS before AUTH, and never an open relay

Where your application hands mail to a mail server, three ports carry different contracts. Port 587 is submission with STARTTLS: the client upgrades to TLS and then authenticates, but the STARTTLS offer alone does not force encryption, so an opportunistic client that falls back to plaintext is exposed to a STARTTLS-stripping downgrade that captures the credential. Port 465 is submission with implicit TLS: the connection is encrypted from the first byte and is immune to stripping, which is why RFC 8314 prefers it going forward. Require successful TLS with certificate chain and hostname validation before any credential is sent on either, and treat TLS 1.2 as the floor (RFC 8997). Port 25 is inter-server relay or, at some providers, submission; "port 25 means no authentication" is wrong (RFC 6409 section 3.1), so identify which role your endpoint plays rather than assuming.

An open relay forwards mail from an unauthenticated, untrusted client to a destination the server is not responsible for; it will be found and abused, and your domain blocked. Reject that forwarding while still allowing the two legitimate cases: ordinary unauthenticated inbound delivery to your own local recipients, and explicitly authorized relay paths (RFC 2505 section 2.1). After TLS, an unauthenticated or invalidly authenticated submission must fail and an authorized one succeed.

Unverified until checked: the live endpoints and ports, whether the client enforces TLS rather than merely offering it, the authentication mechanism, and the relay access rules.

## 6. Transport and display: MTA-STS, TLS-RPT, and BIMI

MTA-STS (RFC 8461) lets a receiving domain demand TLS for mail sent to it. A TXT record points to an HTTPS-hosted policy:

```dns
_mta-sts.example.com. IN TXT "v=STSv1; id=2026091501"
```

The policy is served as `text/plain` at `https://mta-sts.example.com/.well-known/mta-sts.txt`:

```text
version: STSv1
mode: enforce
mx: mx1.example.com
max_age: 604800
```

Only `mode: enforce` constrains delivery (`testing` and `none` do not), and the crucial caveat is direction: MTA-STS protects mail arriving at the policy domain, so publishing it does not secure your own outbound mail to other domains, and it depends on your sending server validating recipients' policies. Update the `id` whenever the policy changes. TLS-RPT (RFC 8460) is reporting only, never enforcement:

```dns
_smtp._tls.example.com. IN TXT "v=TLSRPTv1; rua=mailto:tls-rpt@example.com"
```

BIMI is optional display metadata that shows a brand logo in supporting clients; it depends on DMARC enforcement already being in place and is not an authentication mechanism or a guarantee the logo renders. Keep it last, after the records above are enforcing.

## Verify

REASONED: following block; DNS publication, submission TLS and plaintext AUTH refusal, per the guide's cited BIND 9.18.39 dig manual, BIND v9.20.24 `dig` manual and source, OpenSSL 3.0 s_client, RFC 8314: Cleartext Considered Obsolete and RFC 8997 section 3. No controlled DNS zone or SMTP endpoint is available, and local listeners are denied. bash -n and ShellCheck 0.11.0 exited 0 without diagnostics on the block before its name guard and its whole-block exit status were added; openssl s_client -help exited 0 and listed -starttls, -verify_hostname, -verify_return_error and -min_protocol. The form before this change, with the name guard and the whole-block exit status, lowercased the three names with `tr` before refusing a reserved one; the gate suite's bash -n and ShellCheck 0.11.0 passes covered it, and no stub run of it is recorded. The next form refused a reserved name under bash's `nocasematch` option instead of through `tr`, and refused with 2, saying the block needs bash, when `shopt` fails, as it does in dash. It was covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by dig and openssl stub runs on 2026-11-01 with no network. In bash, the block refused `example.com`, `EXAMPLE.NET`, `App.Example.COM`, `api.EXAMPLE.org` and seven other reserved spellings as the mail domain, the bounce domain or the submission host with 2 and no dig or openssl call, also with `tr` absent from PATH or failing and under an inherited `nocasematch`, `readonly`, `declare -i` or `set -e`. Names outside the reserved names reached all seven lookups and both TLS probes, and under dash the block refused every set of names with 2 and the bash message before any lookup. The current form keeps those guards and reads each lookup's reply instead of `dig`'s exit status alone, because `dig`'s manual gives exit 0 for any DNS response received, NXDOMAIN included, and none of its nonzero statuses is for a SERVFAIL reply. It also refuses a mail domain or bounce domain that starts with `+`, and a DKIM selector that starts with `+`, `@` or `%`, which `dig` would read as a query option, a server or the end of its arguments. The current form passed bash -n and ShellCheck 0.11.0. On 2026-11-12, from 07:22:56Z to 07:22:58Z UTC, an earlier form that differed from it only in comment text ran in bash with real `dig` 9.20.24 through the host's local stub resolver, with `openssl` stubbed so that no TLS connection was made: `gmail.com` with selector `20230601` exited 0, with NOERROR and answers for six lookups, NOERROR/NODATA for the DKIM CNAME and NXDOMAIN for BIMI; `ns1.google.com` as the mail and bounce domain exited 0, with NOERROR/NODATA and NXDOMAIN lines; a nonexistent mail domain under `gmail.com` exited 3, whether the bounce domain existed or not; `dnssec-failed.org` exited 3 with eight SERVFAIL replies, each with `dig` exit 0; and `gmail.com` with selector `ixfr=1` exited 3, `dig` printing "Couldn't parse serial number" and exiting 1 for both DKIM lookups. Stub replies gave 3 for no `ra`, upper-case `RA`, two headers, a `TYPE16` line, a lower-case status, REFUSED and `dig` exit 9, and the guards refused a leading `+` mail or bounce domain and a selector starting with `+`, `@` or `%` with 2 and no `dig` call. On 2026-11-12, from 08:15:52Z to 08:15:54Z UTC, a form that differed from the current one only by one comment clause, removed since, reran a reduced set in bash with real `dig` 9.20.24 through the same resolver and `openssl` stubbed: `gmail.com` with selector `20230601` exited 0, and `dnssec-failed.org` exited 3 with eight SERVFAIL replies, each with `dig` exit 0; the guards refused the mail domain `+short`, the bounce domain `+domain=` and the selectors `@8.8.8.8`, `%x` and `+short` with 2 and no `dig` call. Each lookup runs `dig -r +noall +comments +answer NAME. TYPE`: with `-r`, `dig` reads no options from `~/.digrc`, so no `+search` set there applies, and `dig`'s manual says the search list is not used by default. The first lookup is `TXT` at the mail domain itself, read only for whether that name exists: the mail domain need not publish TXT, so a NOERROR reply there, with records or none, leaves the status unchanged, and the block does not classify those records. A NOERROR reply with records, a NOERROR reply with none (NODATA) and an NXDOMAIN reply each print what was seen and leave the status unchanged, because a record that is not published, such as BIMI, is a state for you to judge, not a failed lookup. NXDOMAIN at the mail domain or at the bounce domain exits 3 instead: a domain that does not exist has no records to read, and may mean a wrong name on the `set --` line; without the mail-domain lookup, a mail domain that does not exist would leave only NXDOMAIN lines under it and the block at 0. SERVFAIL, any other status, more than one reply header, no header or flags line, a reply without the `ra` flag (recursion available), an answer line in a form the block does not read, a nonzero `dig` exit and no reply (exit 9) are inconclusive (3). Published records should match the configured policies; exposed submission accepts plaintext AUTH, while fixed submission refuses it and supports validated TLS before authorized AUTH. These live outcomes remain unobserved. Every probe below is reasoned, not demonstrated: the authoring environment has no DNS control, no SMTP endpoint, and no container runtime, so the outcomes are derived from the cited RFCs rather than observed. For the submission probes, a transport failure or a TLS error is inconclusive, never the fixed state. The DNS/TLS inspection, and the message alignment and relay discrimination checks at the end of this paragraph, also follow the guide's cited RFC 9989, RFC 8601 and RFC 2505, with RFC 8314. The four RFCs are RFC 8314: Cleartext Considered Obsolete, RFC 9989: Domain-based Message Authentication, Reporting, and Conformance (DMARC), RFC 8601: Message Header Field for Indicating Message Authentication Status and RFC 2505: Anti-Spam Recommendations for SMTP MTAs. No controlled sender or recipient is available either. Live outcomes remain unobserved: exposed submission accepts plaintext AUTH or unauthorized relay and lacks aligned enforcement; fixed submission validates TLS, shows receiver-trusted alignment and enforcing policy, rejects external relay with 5xx and preserves authorized submission and local delivery. After running the block, prove alignment by sending one benign message to a controlled recipient and reading the receiving system's trusted `Authentication-Results` header (RFC 8601), never a header the message itself supplied: require a passing, aligned SPF or DKIM result. Confirm the enforcement target is really `p=reject` with subdomain coverage and no testing or legacy sampling. Test open-relay rejection only in an operator-controlled environment (an external `MAIL FROM` and a non-local `RCPT TO` should draw a 5xx), and compare it against an authorized submission and ordinary local delivery. These checks inspect DNS, TLS, and message authentication, not an application listener; their expected exposed and fixed outcomes are REASONED from the cited RFCs.

```bash
# Inspect the published records. Substitute your own names inside the quotes on the set -- line below,
# taking the DKIM selector from the s= tag of a real signature. The block refuses example.com,
# example.net, example.org and their subdomains: example.com publishes real DNS records of its own, so
# an unsubstituted run would show another domain's policy.
# These read DNS and TLS state; they do not evaluate SPF or DMARC or prove a service listener.
(                                       # a subshell, so your own script arguments are untouched
  set +e                                # errexit off here, so a lookup or probe that fails is recorded in the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_MAIL_DOMAIN' 'REPLACE_WITH_YOUR_BOUNCE_DOMAIN' 'REPLACE_WITH_YOUR_DKIM_SELECTOR' 'REPLACE_WITH_YOUR_SUBMISSION_HOST'   # replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "the set -- line needs exactly 4 values: mail domain, bounce domain, DKIM selector and submission host; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|-*|+*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your mail domain (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$2" in
    ""|*REPLACE_WITH_*|-*|+*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your bounce (Return-Path) domain, the name that carries its SPF record, with no scheme, user name, port, path, query, fragment, percent sign or trailing dot, inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$3" in
    ""|*REPLACE_WITH_*|-*|[+@%]*|*/*|*:*|*.|*[[:space:][:cntrl:]]*) echo "substitute your DKIM selector, the s= tag of a real signature, inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$4" in
    ""|*REPLACE_WITH_*|-*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your submission host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
  case "|$1|$2|$4|" in
    *'|example.com|'*|*'|example.net|'*|*'|example.org|'*|*'.example.com|'*|*'.example.net|'*|*'.example.org|'*) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own names on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -u nocasematch   # every match below compares letter case exactly again
  { unset -n IFS q k n w o t c y f g v seen && unset -v IFS q k n w o t c y f g v seen; } 2>/dev/null || { echo "IFS or a name this block uses (q k n w o t c y f g v seen) is readonly in this shell: run the block in a fresh bash; not probing"; exit 2; }   # with IFS unset, read splits on any run of spaces and tabs, as dig's columns need
  set -- "$1" "$2" "$3" "$4" 0          # the 5th value is the block's status so far: 3 (inconclusive) outranks 0
  for q in "TXT $1. MAIL" "TXT $2. SPF" "TXT $3._domainkey.$1. DKIM" "CNAME $3._domainkey.$1. DKIM" "TXT _dmarc.$1. DMARC" "TXT _mta-sts.$1. MTA-STS" "TXT _smtp._tls.$1. TLS-RPT" "TXT default._bimi.$1. BIMI"; do   # one lookup each: the record type, the name with a trailing dot and what the lookup is for; MAIL, first, asks only whether the mail domain itself exists, before the six lookups under it
    read -r k n w <<< "$q"              # the guards above refuse spaces, tabs and control characters in every name, so each entry splits into exactly these 3 words
    set -- "$1" "$2" "$3" "$4" "$5" "$(if dig -r +noall +comments +answer "$n" "$k"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # -r: dig reads no options from ~/.digrc, which its manual calls useful for scripts that need predictable behavior, so no +search set there applies, and its manual says the search list is not used by default; dig tries each non-option argument as a type, then a class, before it takes it as the name, while a name starting ixfr= (such as selector ixfr=1) is read as an IXFR serial that fails to parse, so dig exits before any query and this block gives 3
    set -- "$1" "$2" "$3" "$4" "$5" "${6%$'\n'*}" "${6##*$'\n'}"   # the four names, the status, dig's output, then dig's exit status
    printf '%s\n' "-- $w: dig -r +noall +comments +answer $n $k, exit $7:" "$6"
    case "$7" in
      0) ;;
      9) echo "$w: no reply for $n (dig exit 9, which dig's manual gives for no reply from server); inconclusive"; set -- "$1" "$2" "$3" "$4" 3; continue ;;
      *) echo "$w: dig exit $7 for $n is not 0, the status dig's manual gives for a DNS response received, so this block reads no reply; inconclusive"; set -- "$1" "$2" "$3" "$4" 3; continue ;;
    esac
    seen=" "
    while read -r o t c y f g v; do     # dig's header and flags lines, then answer lines: name, TTL, class, type, then the record data
      case "$o $t $c $f" in
        ';; ->>HEADER<<- opcode: status:') seen="${seen}header:$g "; continue ;;   # g is the status and its comma, as dig prints the header
      esac
      case "$o $t" in
        ';; flags:'*)                   # the reply's flag words end at the first ";", and dig prints ra among them when the reply says recursion is available
          v=" $c $y $f $g $v"
          case "${v%%;*} " in *' ra '*) seen="${seen}flags:ra " ;; *) seen="${seen}flags:nora " ;; esac
          continue ;;
      esac
      case "$o" in ''|';'*) continue ;; esac   # blank lines and dig's other comment lines
      case "$t" in ''|*[!0123456789]*) seen="${seen}unread "; continue ;; esac   # an answer line's TTL is digits only
      case "$c $y" in
        "IN $k") seen="${seen}rr " ;;
        'IN CNAME') ;;                  # an alias line: the name points to another name, whose records follow; printed above, not classified
        *) seen="${seen}unread " ;;     # any other class or type, including a generic TYPEnnn or CLASSnnn form, is not read
      esac
    done <<< "$6"
    case "$seen" in
      *' header:'*' header:'*) echo "$w: dig printed more than one reply header for $n; this block reads a single reply only; inconclusive"; set -- "$1" "$2" "$3" "$4" 3; continue ;;
      *' header:'*) ;;
      *) echo "$w: dig printed no reply header for $n, so this block cannot read the reply; inconclusive"; set -- "$1" "$2" "$3" "$4" 3; continue ;;
    esac
    case "$seen" in
      *' flags:'*' flags:'*) echo "$w: dig printed more than one flags line for $n; this block reads a single reply only; inconclusive"; set -- "$1" "$2" "$3" "$4" 3; continue ;;
      *' flags:ra '*) ;;
      *' flags:nora '*) echo "$w: the reply for $n lacks the ra flag, so recursion was not available and the reply may not hold the records; this block reads only a recursive resolver's reply; inconclusive"; set -- "$1" "$2" "$3" "$4" 3; continue ;;
      *) echo "$w: dig printed no flags line for $n, so whether recursion was available is unknown; inconclusive"; set -- "$1" "$2" "$3" "$4" 3; continue ;;
    esac
    g="${seen#* header:}"; g="${g%% *}"   # the reply status with the comma dig prints after it; a status without that comma matches none of the names below
    case "$g$seen" in
      *' unread '*) echo "$w: status ${g%,}, but an answer line for $n is in a form this block does not read; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
      'NOERROR, '*' rr '*) echo "$w: NOERROR with answers: the $k lines above are not classified, so judge them yourself" ;;
      'NOERROR, '*) echo "$w: NOERROR/NODATA: no $k record at $n or at any name an alias line above points to" ;;
      'NXDOMAIN, '*)
        case "$w" in
          MAIL) echo "$w: NXDOMAIN: the mail domain $n does not exist (or, after an alias line above, the name it points to does not), so the lookups under it read nothing of yours: check the mail domain on the set -- line; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
          SPF) echo "$w: NXDOMAIN: the bounce domain $n does not exist, so this block read no SPF record for it: check the bounce domain on the set -- line; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
          *) echo "$w: NXDOMAIN: $n does not exist (or, after an alias line above, the name it points to does not), so it has no $k record" ;;
        esac ;;
      'SERVFAIL, '*) echo "$w: SERVFAIL: the resolver could not answer for $n, so this lookup read no records; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
      *) echo "$w: status ${g%,} for $n, which this block does not read; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
    esac
  done
  [ "$5" = 0 ] || echo "a lookup above failed, found that the mail or bounce domain does not exist, or gave a reply this block does not read as an answer, so the DNS reading is inconclusive"

  # Submission must complete TLS with a validated certificate before AUTH. -verify_return_error
  # matters because s_client otherwise continues past a verification failure. This confirms TLS is
  # available, not that AUTH is gated on it; the discriminating check, reasoned here, is the negative
  # one: a plaintext or post-stripped-STARTTLS AUTH attempt must be refused, where the exposed state
  # accepts it.
  openssl s_client -connect "$4:587" -starttls smtp \
    -servername "$4" -verify_hostname "$4" \
    -verify_return_error -min_protocol TLSv1.2 </dev/null ||
    { echo "port 587: s_client exit $?, a transport failure or a TLS error; inconclusive, never the fixed state"; set -- "$1" "$2" "$3" "$4" 3; }

  openssl s_client -connect "$4:465" \
    -servername "$4" -verify_hostname "$4" \
    -verify_return_error -min_protocol TLSv1.2 </dev/null ||
    { echo "port 465: s_client exit $?, a transport failure or a TLS error; inconclusive, never the fixed state"; set -- "$1" "$2" "$3" "$4" 3; }
  echo "block exit $5; the DNS records and the TLS sessions above are not classified, and validated TLS does not show that AUTH is refused before TLS, so judge them yourself"
  exit "$5"
)
```

## Common mistakes

- Stopping at `p=none`: monitoring is the first step, not the posture, and it stops no spoofing.
- Assuming the parent policy covers a subdomain that publishes its own weaker DMARC record; a receiver's tree walk uses the subdomain's own record first, so inventory those.
- Blowing the SPF ten-lookup budget through nested provider `include`s, so any evaluation that walks the whole chain returns a `permerror`, which is no pass and breaks authentication for your own mail rather than an attacker's.
- Enabling `ruf=` on password-reset mail without redaction, which can ship a live reset token to the report inbox.
- Trusting STARTTLS on 587 without enforcing it, so a stripped connection sends the credential in plaintext.
- Assuming MTA-STS on your own domain protects your outbound mail; it protects mail sent to you.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- RFC 9989: Domain-based Message Authentication, Reporting, and Conformance (DMARC), obsoletes RFC 7489, removes `pct`, adds `np`, DNS tree walk: https://www.rfc-editor.org/rfc/rfc9989.html
- RFC 9990: DMARC Aggregate Reporting (`rua`): https://www.rfc-editor.org/rfc/rfc9990.html
- RFC 9991: DMARC Failure Reporting (`ruf`, privacy): https://www.rfc-editor.org/rfc/rfc9991.html
- RFC 7208: Sender Policy Framework (terminators, ten-lookup limit, multiple-record permerror): https://www.rfc-editor.org/rfc/rfc7208.html
- RFC 6376: DomainKeys Identified Mail (DKIM) Signatures: https://www.rfc-editor.org/rfc/rfc6376.html
- RFC 8301: DKIM cryptographic update (rsa-sha256 required, rsa-sha1 prohibited, key sizes): https://www.rfc-editor.org/rfc/rfc8301.html
- RFC 8314: Cleartext Considered Obsolete (implicit TLS on 465, STARTTLS on 587): https://www.rfc-editor.org/rfc/rfc8314.html
- RFC 6409: Message Submission for Mail (submission vs relay, port 25): https://www.rfc-editor.org/rfc/rfc6409.html
- RFC 2505: Anti-Spam Recommendations for SMTP MTAs (open relay): https://www.rfc-editor.org/rfc/rfc2505.html
- RFC 8461: SMTP MTA Strict Transport Security (MTA-STS): https://www.rfc-editor.org/rfc/rfc8461.html
- RFC 8460: SMTP TLS Reporting (TLS-RPT): https://www.rfc-editor.org/rfc/rfc8460.html
- RFC 8601: Message Header Field for Indicating Message Authentication Status (`Authentication-Results`): https://www.rfc-editor.org/rfc/rfc8601.html
- BIMI Group: implementation and sender requirements: https://bimigroup.org/how-and-why-to-implement-bimi-selectors/
- RFC 8997 section 3 (checked October 2026; TLS 1.2 floor for email submission and access): https://www.rfc-editor.org/rfc/rfc8997.html#section-3
- BIND 9.18.39 `dig` manual (checked October 2026; TXT/CNAME queries and `+noall +answer` display controls): https://bind9.readthedocs.io/en/v9.18.39/manpages.html
- BIND v9.20.24 `dig` `-r` reads no options from `${HOME}/.digrc` (checked November 2026): https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.rst#L160-L163
- BIND v9.20.24 `dig` `+comments` header display (checked November 2026): https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.rst#L308-L312
- BIND v9.20.24 `dig` search list off by default (checked November 2026): https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.rst#L598-L606
- BIND v9.20.24 `dig` return codes, with exit 0 on NXDOMAIN (checked November 2026): https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.rst#L788-L806
- BIND v9.20.24 `dig` reply header line format (checked November 2026): https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.c#L864-L884
- BIND v9.20.24 `dig` reply flags line, including `ra`, and its recursion-not-available warning (checked November 2026): https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.c#L885-L924
- BIND v9.20.24 `dig` command-line argument dispatch: a leading `%` ends parsing, `@` names a server and `+` is a query option (checked November 2026): https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.c#L3090-L3123
- BIND v9.20.24 `dig` reads a non-option argument as an `ixfr=` serial, a type, then a class, before it takes it as the name (checked November 2026): https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.c#L3148-L3237
- OpenSSL 3.0 `s_client` (checked October 2026; SMTP STARTTLS, TLS connections, hostname verification, and verification errors): https://docs.openssl.org/3.0/man1/openssl-s_client/
- OpenSSL 3.0 protocol configuration (checked October 2026; `-min_protocol TLSv1.2`): https://docs.openssl.org/3.0/man3/SSL_CONF_cmd/


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- spf: SPF (RFC 7208)
- dkim: DKIM (RFC 6376)
- crypto: DKIM cryptography (RFC 8301)
- dmarc: DMARC (RFC 9989)
- aggregate: DMARC aggregate reporting (RFC 9990)
- failure: DMARC failure reporting (RFC 9991)
- submission: Submission TLS (RFC 8314)
- roles: SMTP submission roles (RFC 6409)
- relay: SMTP relay controls (RFC 2505)
- sts: MTA-STS (RFC 8461)
- rpt: TLS-RPT (RFC 8460)
- results: Authentication-Results (RFC 8601)
- bimi: BIMI documentation (unknown)
- submission-update: Submission TLS update (RFC 8997)
- bind: BIND dig manual (9.18.39)
- openssl: OpenSSL command documentation (3.0)
- bind-dig: BIND dig manual and source (v9.20.24)

Claims (full source mapping in the JSON block below):

- spf-identity (REASONED; spf, dmarc): SPF TXT authorizes connecting IPs for MAIL FROM, or HELO with a null return path; it does not authenticate visible From without DMARC alignment.
- spf-all (REASONED; spf): -all fails unmatched senders, ~all softfails and may still be delivered, while +all or bare all passes everyone.
- spf-record (REASONED; spf): Publish exactly one v=spf1 record per evaluated domain; multiple records produce permerror.
- spf-lookups (REASONED; spf): Ten DNS-lookup terms across recursion include include/a/mx/ptr/exists/redirect but exclude ip4/ip6/all; exceeding the limit gives permerror. An earlier matching mechanism stops evaluation; permerror is no SPF pass.
- dkim-signing (REASONED; dkim, dmarc): DKIM d= and s= select the _domainkey public key; signatures authenticate signed content for the signing domain, not encryption. Actual signing and verification are required for DMARC.
- dkim-crypto (REASONED; crypto): Use rsa-sha256, never rsa-sha1; RFC 8301 sets a 1024-bit RSA floor and recommends at least 2048 bits, used here as the working minimum. Publish the full generated key, not the truncated example.
- dkim-rotation (REASONED; dkim): Publish a new selector before switching signing, retire the old selector after in-flight mail clears, and revoke with empty p=; inspect actual selector, delegation and rotation ownership.
- dmarc-alignment (REASONED; dmarc): DMARC requires at least one passing and aligned SPF or DKIM result; relaxed adkim=r/aspf=r defaults to organizational-domain alignment, strict s requires exact domain matching.
- dmarc-policy (REASONED; dmarc): p=none requests monitoring only, quarantine suspicious handling, and reject SMTP-time rejection; receivers retain local policy, so missing enforcement does not guarantee delivery.
- dmarc-subdomains (REASONED; dmarc): sp covers existing subdomains and np non-existent ones, falling back np to sp to p; a subdomain-specific record can take precedence. Inventory explicit and inherited policies.
- dmarc-discovery (REASONED; dmarc): RFC 9989 DNS tree walk discovers policy and organizational domain, replacing the former public-suffix-list method.
- dmarc-testing (REASONED; dmarc): t=y weakens enforcement and t=n is the default; the illustrated enforcing record omits the tag.
- dmarc-rollout (REASONED; dmarc, aggregate): Monitor aggregate reports under p=none until legitimate streams align before moving to p=reject, or legitimate mail can be rejected.
- dmarc-pct (REASONED; dmarc): RFC 9989, May 2026, obsoletes RFC 7489 and removes pct; legacy p=reject;pct=25 was partial application, not a current rollout control.
- aggregate (REASONED; aggregate): Enable rua daily aggregate XML reporting to observe sending streams; an external reporting domain must authorize reports, and actual receipt/processing must be checked.
- failure-reports (REASONED; failure): ruf forensic reports can expose content, recipients and reset tokens; omit initially, settle redaction/retention/access before enabling, and authorize external destinations.
- starttls (REASONED; submission): 587 submission upgrades with STARTTLS before authentication; an opportunistic fallback can expose credentials to stripping, so require successful validated TLS.
- implicit-tls (REASONED; submission): 465 submission starts with TLS and avoids STARTTLS stripping; RFC 8314 prefers implicit TLS going forward.
- tls-validation (REASONED; submission, submission-update): Validate certificate chain and hostname before credentials on either submission port; the guide states TLS 1.2 as the floor and attributes that update to RFC 8997.
- port-25 (REASONED; roles): 25 is inter-server relay or provider submission; identify the endpoint role instead of assuming that port 25 implies no authentication.
- relay-policy (REASONED; relay): Reject unauthenticated untrusted forwarding to non-local recipients while allowing ordinary inbound local delivery and explicitly authorized relay paths.
- submission-auth (REASONED; roles, submission): After TLS, unauthenticated or invalidly authenticated submission must fail while authorized submission succeeds.
- sts-publication (REASONED; sts): MTA-STS TXT advertises the HTTPS text/plain policy at /.well-known/mta-sts.txt on mta-sts.example.com; the example selects enforce, an MX host and max_age 604800.
- sts-enforcement (REASONED; sts): Only enforce constrains delivery; testing and none do not. MTA-STS protects mail arriving at the policy domain and depends on sending-server validation, not protection of the publishing domain outbound mail.
- sts-refresh (REASONED; sts): Update the MTA-STS TXT id whenever the policy changes.
- tls-reports (REASONED; rpt): TLS-RPT _smtp._tls TXT with TLSRPTv1 and rua supplies reports, never enforcement.
- bimi (REASONED; bimi): BIMI is optional logo display metadata requiring DMARC enforcement, not authentication or guaranteed rendering; deploy it last.
- verify-dns (REASONED; spf, dkim, dmarc, sts, rpt, bimi, bind, bind-dig): Inspect SPF, DKIM TXT/CNAME, DMARC, MTA-STS, TLS-RPT and BIMI records using actual inventory; DNS inspection alone does not evaluate SPF/DMARC or prove a listener. Each reply's status and ra flag are read: NOERROR, NODATA and NXDOMAIN print unclassified, but NXDOMAIN at the mail or bounce domain, SERVFAIL, other statuses, no ra and no reply are inconclusive. No DNS control was available.
- verify-tls (REASONED; submission, submission-update, openssl): 587 STARTTLS and 465 implicit-TLS probes require validated TLS 1.2 or newer; TLS availability does not establish AUTH gating. Plaintext or stripped-STARTTLS AUTH must be refused; transport/TLS failures are inconclusive. No SMTP endpoint or container runtime was available.
- verify-alignment (REASONED; results, dmarc): Send a benign message to a controlled recipient and inspect receiver-trusted Authentication-Results, not a supplied header; require passing aligned SPF or DKIM and p=reject with subdomain coverage and no testing or legacy sampling.
- verify-relay (REASONED; relay, roles): In an operator-controlled environment, external MAIL FROM and non-local RCPT TO should receive 5xx; compare with authorized submission and ordinary local delivery. These expected outcomes remain unobserved.

````json
{
  "schema": 1,
  "checked": "2026-10-05",
  "documentation_checked": "2026-09",
  "body_sha256": "2230e4600b8369158733e620f7beb98257aa5c3460b75d476a84ffcc450f68da",
  "components": {
    "spf": {
      "name": "SPF",
      "basis": "RFC 7208",
      "sources": {
        "sea6ac206b034": "https://www.rfc-editor.org/rfc/rfc7208.html"
      }
    },
    "dkim": {
      "name": "DKIM",
      "basis": "RFC 6376",
      "sources": {
        "s13ee1bc66dfc": "https://www.rfc-editor.org/rfc/rfc6376.html"
      }
    },
    "crypto": {
      "name": "DKIM cryptography",
      "basis": "RFC 8301",
      "sources": {
        "sb675e6772778": "https://www.rfc-editor.org/rfc/rfc8301.html"
      }
    },
    "dmarc": {
      "name": "DMARC",
      "basis": "RFC 9989",
      "sources": {
        "s5da292ff1b92": "https://www.rfc-editor.org/rfc/rfc9989.html"
      }
    },
    "aggregate": {
      "name": "DMARC aggregate reporting",
      "basis": "RFC 9990",
      "sources": {
        "s5e0e418f74dd": "https://www.rfc-editor.org/rfc/rfc9990.html"
      }
    },
    "failure": {
      "name": "DMARC failure reporting",
      "basis": "RFC 9991",
      "sources": {
        "s136bbcd8e31a": "https://www.rfc-editor.org/rfc/rfc9991.html"
      }
    },
    "submission": {
      "name": "Submission TLS",
      "basis": "RFC 8314",
      "sources": {
        "sd78efc15555c": "https://www.rfc-editor.org/rfc/rfc8314.html"
      }
    },
    "roles": {
      "name": "SMTP submission roles",
      "basis": "RFC 6409",
      "sources": {
        "s3f9972faf8ff": "https://www.rfc-editor.org/rfc/rfc6409.html"
      }
    },
    "relay": {
      "name": "SMTP relay controls",
      "basis": "RFC 2505",
      "sources": {
        "s1b9349dd99bc": "https://www.rfc-editor.org/rfc/rfc2505.html"
      }
    },
    "sts": {
      "name": "MTA-STS",
      "basis": "RFC 8461",
      "sources": {
        "s39819f3ea93a": "https://www.rfc-editor.org/rfc/rfc8461.html"
      }
    },
    "rpt": {
      "name": "TLS-RPT",
      "basis": "RFC 8460",
      "sources": {
        "se80da0f5e0c8": "https://www.rfc-editor.org/rfc/rfc8460.html"
      }
    },
    "results": {
      "name": "Authentication-Results",
      "basis": "RFC 8601",
      "sources": {
        "s46f8392d93fd": "https://www.rfc-editor.org/rfc/rfc8601.html"
      }
    },
    "bimi": {
      "name": "BIMI documentation",
      "basis": "unknown",
      "sources": {
        "sd18b1e0134bd": "https://bimigroup.org/how-and-why-to-implement-bimi-selectors/"
      }
    },
    "submission-update": {
      "name": "Submission TLS update",
      "basis": "RFC 8997",
      "sources": {
        "sb5ca35fe0d1b": "https://www.rfc-editor.org/rfc/rfc8997.html#section-3"
      }
    },
    "bind": {
      "name": "BIND dig manual",
      "basis": "9.18.39",
      "sources": {
        "s54cff06bb882": "https://bind9.readthedocs.io/en/v9.18.39/manpages.html"
      }
    },
    "openssl": {
      "name": "OpenSSL command documentation",
      "basis": "3.0",
      "sources": {
        "s00aaf106164f": "https://docs.openssl.org/3.0/man1/openssl-s_client/",
        "s2a2127a2c79b": "https://docs.openssl.org/3.0/man3/SSL_CONF_cmd/"
      }
    },
    "bind-dig": {
      "name": "BIND dig manual and source",
      "basis": "v9.20.24",
      "sources": {
        "s5d98e69756c9": "https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.rst#L160-L163",
        "sda67db889c0e": "https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.rst#L308-L312",
        "s9cd3fcf628fb": "https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.rst#L598-L606",
        "s4a49b2a8a61e": "https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.rst#L788-L806",
        "sac989d3132f5": "https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.c#L864-L884",
        "sf70f634493d1": "https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.c#L885-L924",
        "s22625818a6a8": "https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.c#L3090-L3123",
        "sf3a5d3d72a10": "https://gitlab.isc.org/isc-projects/bind9/-/blob/v9.20.24/bin/dig/dig.c#L3148-L3237"
      }
    }
  },
  "claims": {
    "spf-identity": {"text": "SPF TXT authorizes connecting IPs for MAIL FROM, or HELO with a null return path; it does not authenticate visible From without DMARC alignment.", "components": ["spf", "dmarc"], "sources": ["spf:sea6ac206b034", "dmarc:s5da292ff1b92"], "status": "REASONED"},
    "spf-all": {"text": "-all fails unmatched senders, ~all softfails and may still be delivered, while +all or bare all passes everyone.", "components": ["spf"], "sources": ["spf:sea6ac206b034"], "status": "REASONED"},
    "spf-record": {"text": "Publish exactly one v=spf1 record per evaluated domain; multiple records produce permerror.", "components": ["spf"], "sources": ["spf:sea6ac206b034"], "status": "REASONED"},
    "spf-lookups": {"text": "Ten DNS-lookup terms across recursion include include/a/mx/ptr/exists/redirect but exclude ip4/ip6/all; exceeding the limit gives permerror. An earlier matching mechanism stops evaluation; permerror is no SPF pass.", "components": ["spf"], "sources": ["spf:sea6ac206b034"], "status": "REASONED"},
    "dkim-signing": {"text": "DKIM d= and s= select the _domainkey public key; signatures authenticate signed content for the signing domain, not encryption. Actual signing and verification are required for DMARC.", "components": ["dkim", "dmarc"], "sources": ["dkim:s13ee1bc66dfc", "dmarc:s5da292ff1b92"], "status": "REASONED"},
    "dkim-crypto": {"text": "Use rsa-sha256, never rsa-sha1; RFC 8301 sets a 1024-bit RSA floor and recommends at least 2048 bits, used here as the working minimum. Publish the full generated key, not the truncated example.", "components": ["crypto"], "sources": ["crypto:sb675e6772778"], "status": "REASONED"},
    "dkim-rotation": {"text": "Publish a new selector before switching signing, retire the old selector after in-flight mail clears, and revoke with empty p=; inspect actual selector, delegation and rotation ownership.", "components": ["dkim"], "sources": ["dkim:s13ee1bc66dfc"], "status": "REASONED"},
    "dmarc-alignment": {"text": "DMARC requires at least one passing and aligned SPF or DKIM result; relaxed adkim=r/aspf=r defaults to organizational-domain alignment, strict s requires exact domain matching.", "components": ["dmarc"], "sources": ["dmarc:s5da292ff1b92"], "status": "REASONED"},
    "dmarc-policy": {"text": "p=none requests monitoring only, quarantine suspicious handling, and reject SMTP-time rejection; receivers retain local policy, so missing enforcement does not guarantee delivery.", "components": ["dmarc"], "sources": ["dmarc:s5da292ff1b92"], "status": "REASONED"},
    "dmarc-subdomains": {"text": "sp covers existing subdomains and np non-existent ones, falling back np to sp to p; a subdomain-specific record can take precedence. Inventory explicit and inherited policies.", "components": ["dmarc"], "sources": ["dmarc:s5da292ff1b92"], "status": "REASONED"},
    "dmarc-discovery": {"text": "RFC 9989 DNS tree walk discovers policy and organizational domain, replacing the former public-suffix-list method.", "components": ["dmarc"], "sources": ["dmarc:s5da292ff1b92"], "status": "REASONED"},
    "dmarc-testing": {"text": "t=y weakens enforcement and t=n is the default; the illustrated enforcing record omits the tag.", "components": ["dmarc"], "sources": ["dmarc:s5da292ff1b92"], "status": "REASONED"},
    "dmarc-rollout": {"text": "Monitor aggregate reports under p=none until legitimate streams align before moving to p=reject, or legitimate mail can be rejected.", "components": ["dmarc", "aggregate"], "sources": ["dmarc:s5da292ff1b92", "aggregate:s5e0e418f74dd"], "status": "REASONED"},
    "dmarc-pct": {"text": "RFC 9989, May 2026, obsoletes RFC 7489 and removes pct; legacy p=reject;pct=25 was partial application, not a current rollout control.", "components": ["dmarc"], "sources": ["dmarc:s5da292ff1b92"], "status": "REASONED"},
    "aggregate": {"text": "Enable rua daily aggregate XML reporting to observe sending streams; an external reporting domain must authorize reports, and actual receipt/processing must be checked.", "components": ["aggregate"], "sources": ["aggregate:s5e0e418f74dd"], "status": "REASONED"},
    "failure-reports": {"text": "ruf forensic reports can expose content, recipients and reset tokens; omit initially, settle redaction/retention/access before enabling, and authorize external destinations.", "components": ["failure"], "sources": ["failure:s136bbcd8e31a"], "status": "REASONED"},
    "starttls": {"text": "587 submission upgrades with STARTTLS before authentication; an opportunistic fallback can expose credentials to stripping, so require successful validated TLS.", "components": ["submission"], "sources": ["submission:sd78efc15555c"], "status": "REASONED"},
    "implicit-tls": {"text": "465 submission starts with TLS and avoids STARTTLS stripping; RFC 8314 prefers implicit TLS going forward.", "components": ["submission"], "sources": ["submission:sd78efc15555c"], "status": "REASONED"},
    "tls-validation": {"text": "Validate certificate chain and hostname before credentials on either submission port; the guide states TLS 1.2 as the floor and attributes that update to RFC 8997.", "components": ["submission", "submission-update"], "sources": ["submission:sd78efc15555c", "submission-update:sb5ca35fe0d1b"], "status": "REASONED"},
    "port-25": {"text": "25 is inter-server relay or provider submission; identify the endpoint role instead of assuming that port 25 implies no authentication.", "components": ["roles"], "sources": ["roles:s3f9972faf8ff"], "status": "REASONED"},
    "relay-policy": {"text": "Reject unauthenticated untrusted forwarding to non-local recipients while allowing ordinary inbound local delivery and explicitly authorized relay paths.", "components": ["relay"], "sources": ["relay:s1b9349dd99bc"], "status": "REASONED"},
    "submission-auth": {"text": "After TLS, unauthenticated or invalidly authenticated submission must fail while authorized submission succeeds.", "components": ["roles", "submission"], "sources": ["roles:s3f9972faf8ff", "submission:sd78efc15555c"], "status": "REASONED"},
    "sts-publication": {"text": "MTA-STS TXT advertises the HTTPS text/plain policy at /.well-known/mta-sts.txt on mta-sts.example.com; the example selects enforce, an MX host and max_age 604800.", "components": ["sts"], "sources": ["sts:s39819f3ea93a"], "status": "REASONED"},
    "sts-enforcement": {"text": "Only enforce constrains delivery; testing and none do not. MTA-STS protects mail arriving at the policy domain and depends on sending-server validation, not protection of the publishing domain outbound mail.", "components": ["sts"], "sources": ["sts:s39819f3ea93a"], "status": "REASONED"},
    "sts-refresh": {"text": "Update the MTA-STS TXT id whenever the policy changes.", "components": ["sts"], "sources": ["sts:s39819f3ea93a"], "status": "REASONED"},
    "tls-reports": {"text": "TLS-RPT _smtp._tls TXT with TLSRPTv1 and rua supplies reports, never enforcement.", "components": ["rpt"], "sources": ["rpt:se80da0f5e0c8"], "status": "REASONED"},
    "bimi": {"text": "BIMI is optional logo display metadata requiring DMARC enforcement, not authentication or guaranteed rendering; deploy it last.", "components": ["bimi"], "sources": ["bimi:sd18b1e0134bd"], "status": "REASONED"},
    "verify-dns": {"text": "Inspect SPF, DKIM TXT/CNAME, DMARC, MTA-STS, TLS-RPT and BIMI records using actual inventory; DNS inspection alone does not evaluate SPF/DMARC or prove a listener. Each reply's status and ra flag are read: NOERROR, NODATA and NXDOMAIN print unclassified, but NXDOMAIN at the mail or bounce domain, SERVFAIL, other statuses, no ra and no reply are inconclusive. No DNS control was available.", "components": ["spf", "dkim", "dmarc", "sts", "rpt", "bimi", "bind", "bind-dig"], "sources": ["spf:sea6ac206b034", "dkim:s13ee1bc66dfc", "dmarc:s5da292ff1b92", "sts:s39819f3ea93a", "rpt:se80da0f5e0c8", "bimi:sd18b1e0134bd", "bind:s54cff06bb882", "bind-dig:s5d98e69756c9", "bind-dig:sda67db889c0e", "bind-dig:s9cd3fcf628fb", "bind-dig:s4a49b2a8a61e", "bind-dig:sac989d3132f5", "bind-dig:sf70f634493d1", "bind-dig:s22625818a6a8", "bind-dig:sf3a5d3d72a10"], "status": "REASONED", "verify": [1]},
    "verify-tls": {"text": "587 STARTTLS and 465 implicit-TLS probes require validated TLS 1.2 or newer; TLS availability does not establish AUTH gating. Plaintext or stripped-STARTTLS AUTH must be refused; transport/TLS failures are inconclusive. No SMTP endpoint or container runtime was available.", "components": ["submission", "submission-update", "openssl"], "sources": ["submission:sd78efc15555c", "submission-update:sb5ca35fe0d1b", "openssl:s00aaf106164f", "openssl:s2a2127a2c79b"], "status": "REASONED", "verify": [1]},
    "verify-alignment": {"text": "Send a benign message to a controlled recipient and inspect receiver-trusted Authentication-Results, not a supplied header; require passing aligned SPF or DKIM and p=reject with subdomain coverage and no testing or legacy sampling.", "components": ["results", "dmarc"], "sources": ["results:s46f8392d93fd", "dmarc:s5da292ff1b92"], "status": "REASONED"},
    "verify-relay": {"text": "In an operator-controlled environment, external MAIL FROM and non-local RCPT TO should receive 5xx; compare with authorized submission and ordinary local delivery. These expected outcomes remain unobserved.", "components": ["relay", "roles"], "sources": ["relay:s1b9349dd99bc", "roles:s3f9972faf8ff"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
