# MLflow tracking server: no authentication by default

MLflow tracks machine-learning work: its tracking server records experiments, runs and registered models and shows them in a web UI. This guide helps your AI assistant configure it securely, including a private bind, TLS from a fronting proxy, MLflow's built-in basic authentication turned on, and protected artifact storage credentials.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/mlflow.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against MLflow pinned source v3.16.1, MLflow security middleware minimum 3.5.0, Docker Engine loopback publication minimum 28.0.0, nginx proxy implementation release-1.28.0, Caddy reverse proxy parser v2.11.4, oauth2-proxy documentation v7.15.6, and Authelia source v4.39.28, plus 3 more recorded bases; 1 further source is pinned to a commit and 1 carries no recorded version. Metadata reviewed 2026-11-06; documentation checked September 2026. The guide records 32 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

`mlflow server` serves the tracking UI and REST API at `http://127.0.0.1:5000` (as of v3.16.1, unless `MLFLOW_HOST` or `MLFLOW_PORT` is set) and performs no authentication: anyone who can reach the port can read, alter, and delete experiments, runs, registered models, and (with artifact proxying on) the artifacts themselves. Authentication is opt-in through a separate app, and the server has no dedicated TLS flags (though `mlflow server --uvicorn-opts` can forward `--ssl-keyfile`/`--ssl-certfile` to the default Uvicorn server); MLflow's tracking-server documentation recommends a reverse proxy or VPN for both.

## 1. Bind privately

The defaults are already loopback:

```bash
mlflow server --host 127.0.0.1 --port 5000
```

The CLI help for `--host` says it plainly: "This is NOT a security setting". Do not switch to `--host 0.0.0.0` on a machine with a public interface. In Docker the two binds are different things: the host publishes on loopback (`-p 127.0.0.1:5000:5000`, which Docker's port-publishing docs say only the Docker host can reach, assuming a normal bridge-network NAT setup and a Docker version at or after 28.0.0; earlier releases could let hosts on the same layer-2 network reach a loopback-published port). The second Docker bind is inside the container, where the server must listen on the container's own interface (`--host 0.0.0.0` there, private to the Compose network and the host), because a process bound to the container's `127.0.0.1` is not reachable through the published port at all. See [docker.md](docker.md). If the server must listen beyond loopback for a proxy on another host, set `--allowed-hosts mlflow.example.com` and `--cors-allowed-origins https://mlflow.example.com`, and never use `--disable-security-middleware` outside a test. The security-middleware flags need MLflow 3.5.0 or newer and the default Uvicorn server, not `--gunicorn-opts`/`--waitress-opts`. The `--allowed-hosts` default validates the request's Host header against localhost, `127.0.0.1`, `[::1]`, `0.0.0.0`, and private ranges, which is a Host-header check, not a client-source firewall.

## 2. TLS from a fronting proxy

`mlflow server` has no dedicated certificate flags (though in MLflow v3.16.1 `--uvicorn-opts` forwards its options to the default Uvicorn server, for which Uvicorn 0.54.0 documents `--ssl-keyfile`/`--ssl-certfile`; MLflow rejects `--uvicorn-opts` with `--dev`, `--gunicorn-opts` or `--waitress-opts`, and `--gunicorn-opts` or `--waitress-opts` runs gunicorn or waitress instead of Uvicorn). Terminate TLS in nginx or Caddy per [nginx.md](nginx.md)/[caddy.md](caddy.md) with `proxy_pass http://127.0.0.1:5000` or `reverse_proxy 127.0.0.1:5000`, a certificate from [free-certificates.md](free-certificates.md), and `--allowed-hosts` set to the public hostname; or use a tunnel or tailnet ([cloudflare.md](cloudflare.md), [tailscale.md](tailscale.md)). Point clients at `MLFLOW_TRACKING_URI=https://mlflow.example.com`, and never set `MLFLOW_TRACKING_INSECURE_TLS=true` in production (MLflow's own docs say the same).

## 3. Turn on the built-in basic auth

MLflow ships an HTTP basic-auth app that stores users and per-resource permissions in a database (as of September 2026 the current documentation page carries no experimental label; verify before relying on it). The client-side `MLFLOW_TRACKING_USERNAME`/`MLFLOW_TRACKING_PASSWORD` variables do nothing on their own; the server must run this app.

Provision `/etc/mlflow/server.env` through your secret manager as a regular file owned by the server account, mode `0600`, in a directory other accounts cannot traverse, write to or replace, with no ACL granting them access. It must contain a dotenv assignment for `MLFLOW_FLASK_SERVER_SECRET_KEY` with a long random value, identical on every replica. Keep the file and its backups out of source control. The block assumes this file and the auth configuration below are provisioned before startup and a fresh, trusted shell.

The global `mlflow --env-file` option loads the file before executing the server command and does not override existing environment values. Clear inherited values first so the file supplies the key:

```bash
(
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  set +x +a +e
  { unset -n MLFLOW_FLASK_SERVER_SECRET_KEY MLFLOW_AUTH_CONFIG_PATH &&
    unset -v MLFLOW_FLASK_SERVER_SECRET_KEY MLFLOW_AUTH_CONFIG_PATH; } 2>/dev/null ||
    { echo 'cannot clear MLflow launch variables in this shell; not starting'; exit 2; }
  if [ ! -f /etc/mlflow/server.env ] || [ -L /etc/mlflow/server.env ] || [ ! -r /etc/mlflow/server.env ]; then
    echo 'need a readable regular /etc/mlflow/server.env file, not a symlink; not starting'; exit 2
  fi
  command -v pip >/dev/null || { echo 'pip not found; not starting'; exit 2; }
  pip install 'mlflow[auth]' || { echo 'installing mlflow[auth] failed; not starting'; exit 3; }
  command -v mlflow >/dev/null || { echo 'mlflow not found; not starting'; exit 2; }
  MLFLOW_AUTH_CONFIG_PATH=/etc/mlflow/basic_auth.ini \
    mlflow --env-file /etc/mlflow/server.env server --app-name basic-auth
)
```

REASONED: exit status meanings, per CONTRIBUTING.md rule 6. A block that sets its exit status uses 0 for a pass, or for an observation the block cannot classify and says so; 1 for a finding; 2 for a guard refusal; and 3 for a failed or inconclusive check. The block above sets its own status only when a guard refuses, with 2 (as when `pip` is not found, or `mlflow` is not found after the install), or `pip install` fails, with 3; otherwise it ends with the status of its last command, the `mlflow` server.

Only the file path reaches the launch command; the shell never reads or exports the key. MLflow loads it into its own environment and forwards it to workers (traced at v3.16.1 in the sources below), so it remains exposed to the same account and root in process memory and, for inheriting processes, `/proc/<pid>/environ` throughout their lifetimes. A protected file does not remove that server-side exposure.

Current MLflow has no default admin password: the first start requires an admin password of at least 12 characters, supplied as `MLFLOW_AUTH_ADMIN_PASSWORD` or as `admin_password` in the configuration file, and it rejects the legacy `password1234`, so startup fails without one. Set a strong password before that first start (an already-bootstrapped server does not need it re-supplied on later restarts):

```ini
# /etc/mlflow/basic_auth.ini
[mlflow]
# default is READ on every resource
default_permission = NO_PERMISSIONS
database_uri = postgresql://mlflow_auth:REPLACE_WITH_LONG_RANDOM_VALUE@127.0.0.1:5432/mlflow_auth
admin_username = admin
admin_password = REPLACE_WITH_LONG_RANDOM_VALUE
```

`database_uri` defaults to a SQLite file `basic_auth.db` in the working directory; MLflow recommends a central database for multi-node deployments. The same file can name an `authorization_function` (`module:function`) for a custom scheme, but the shipped one is basic auth. To rotate the admin password on a running server:

```bash
(
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  # Both passwords you substitute on the set -- line enter shell history.
  # Clear that history line afterward.
  # Stdin closes the argv channel only: it does not hide the passwords from
  # set -x tracing or your own account's view of the process.
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_CURRENT_ADMIN_PASSWORD' 'REPLACE_WITH_LONG_RANDOM_VALUE'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in *REPLACE_WITH_*|""|*[[:cntrl:]]*) echo "substitute the current admin password on the set -- line above; not probing"; exit 2 ;; esac
  case "$2" in *REPLACE_WITH_*|""|*[[:cntrl:]]*) echo "substitute the new password on the set -- line above; not probing"; exit 2 ;; esac
  # Both passwords reach curl on stdin via a config file (curl --config -), never
  # argv: -u admin:PASSWORD and the -d body are world-readable in /proc/<pid>/cmdline.
  # Escape backslashes then quotes for the config; the new password is JSON-escaped
  # first, then the whole JSON body is config-escaped.
  set -- "${1//\\/\\\\}" "${2//\\/\\\\}"
  set -- "${1//\"/\\\"}" "${2//\"/\\\"}"
  set -- "$1" "{\"username\":\"admin\",\"password\":\"$2\"}"
  set -- "$1" "${2//\\/\\\\}"
  set -- "$1" "${2//\"/\\\"}"
  printf 'user = "admin:%s"\ndata-binary = "%s"\n' "$1" "$2" | curl -q -sS --config - -X PATCH -H 'Content-Type: application/json' https://mlflow.example.com/api/2.0/mlflow/users/update-password
)
```

Creating users requires admin credentials (UI at `/signup`, or `POST /api/2.0/mlflow/users/create`). Give humans individual accounts and CI its own low-permission user per [authentication.md](authentication.md); `~/.mlflow/credentials` stores passwords unencrypted, so prefer the environment variables injected at runtime. The documentation notes that the UI has no limit on login attempts, and basic auth is checked on every protected API request, so rate-limit the authentication-bearing routes at the proxy (not only the login path) per [nginx.md](nginx.md); and because basic auth sends the password with every request ([authentication.md](authentication.md)), step 2 comes first.

MFA: this guide's cited MLflow material does not establish MFA support in the basic-auth app. Guide advice: put an identity-aware layer in front (Cloudflare Access, Authelia, oauth2-proxy per [mfa.md](mfa.md)) and require MFA for human access. Cloudflare Access at c896795b8e8bab68d05ae78d64c9cbcda1fdb104 supports IdP-based MFA requirements for Okta, Microsoft Entra ID, Generic OIDC and Generic SAML 2.0, rejecting a user who does not present the required method, or independent MFA with methods including TOTP and WebAuthn security keys. Independent MFA in Cloudflare Access at c896795b8e8bab68d05ae78d64c9cbcda1fdb104 must first be enabled at organization level, and the effective independent MFA requirement follows policy over application over organization. Authelia v4.39.28 applies the first matching access-control rule, or default_policy if none matches; its two_factor policy requires successful 2FA. oauth2-proxy v7.15.6 documents an OAuth provider and upstream endpoints, not second-factor enforcement in these passages; guide advice: require MFA at the identity provider for this login and test enforcement there. These sources do not establish MFA enforcement in a deployed MLflow combination.

MLflow v3.16.1 declares MLFLOW_TRACKING_USERNAME, MLFLOW_TRACKING_PASSWORD and MLFLOW_TRACKING_TOKEN as tracking authentication inputs; in the cited HTTP request-construction path, nonempty username and password credentials select an Authorization: Basic header unless the auth mode is kubernetes or kubernetes-namespaced, otherwise a nonempty token selects Authorization: Bearer. The token variable's comment claims precedence, but that request code selects Basic first under those conditions; AWS SigV4 overwrites Authorization, and a configured auth handler is applied separately, so this is not a guarantee for every authentication mode. Cloudflare Access service tokens at c896795b8e8bab68d05ae78d64c9cbcda1fdb104 use CF-Access-Client-Id and CF-Access-Client-Secret headers, with a Service Auth policy required to avoid an IdP login prompt; a self-hosted Access application can alternatively be configured to accept the service token in one header. Guide advice: confirm that the chosen client and proxy combination preserves both proxy authentication and MLflow authentication; these citations do not establish that MLFLOW_TRACKING_TOKEN alone supplies Cloudflare service-token headers or that both layers work together.

## 4. Artifact store credentials

With `--serve-artifacts` (the default) and `--artifacts-destination s3://bucket`, the server proxies every artifact read and write for experiments recorded under the proxied store, so it holds the storage credentials and clients need none. Experiments created before proxying, or with an explicit direct artifact location, keep that location and stay reachable independently of the tracking server's permissions, so apply storage IAM directly and inspect existing experiment locations rather than assuming proxying covers them. Supply them through the environment or an instance role, never in a compose file or the repository ([secrets.md](secrets.md), [object-storage.md](object-storage.md)). With `--no-serve-artifacts`, every client needs its own storage credentials and the tracking server's permissions no longer gate the artifacts.

## Verify

```bash
# REASONED: listener and authentication checks follow the cited MLflow documentation; no running basic-auth server is available.
# Run this block on the MLflow host: its backend checks reach 127.0.0.1:5000 and its listener list reads that host.
# experiments/search is a POST endpoint, so each check posts a minimal body. --noproxy so no client
# proxy answers. A 401 at your public MLflow host can come from the fronting proxy OR from MLflow's own basic
# auth, so the backend check below proves MLflow itself enforces it, not just the proxy. Each command prints
# its HTTP status and the block classifies it against the comment beside it; curl exits 0
# for 401/403/404 too, so shell success is NOT a pass, and an open MLflow backend answers the anonymous
# search with 200. If you front MLflow with an identity-aware proxy (Cloudflare Access etc., the MFA
# option in step 3) instead of plain basic auth, the public https probes also need that proxy's own
# credentials (its service-token headers), and a denial from that proxy is distinct from MLflow's own
# backend 401/403. Behind such a proxy the three public requests, which send no service-token headers, get
# that proxy's redirect or denial, so this block cannot exit 0 there; its four backend requests still show
# MLflow's own enforcement. The credentials below reach curl through a config file on stdin (curl --config -),
# never argv, because -u user:password is world-readable via ps / /proc/<pid>/cmdline; stdin protects
# the argv channel only, not shell history, set -x tracing, or your own
# account's view of the process. Substitute each password INSIDE the
# single quotes on the set -- line; a password containing a literal apostrophe must be written '\'' there.
# The block exits 1 for a finding (a 2xx where a refusal is expected), 3 if ss or a request fails or a request
# answers anything else the comments do not expect, 2 if ss is not installed or the credential part refuses its
# input, and otherwise 0.
(                                       # the whole block in one subshell, so one exit status covers every part of it
  set +e                                # errexit off here, so a part that ends nonzero is folded into the status below instead of ending the block
  set -- 0                              # the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 2 (ss is not installed, or a part refused its input), which outranks 0
  if command -v ss >/dev/null; then
    ss -tlnp || { echo "ss -tlnp exit $?: the listener list failed; inconclusive"; set -- 3; }   # read every listener; 5000: 127.0.0.1 only
    set -- "$1" listed                  # the 2nd value says whether ss ran, so the last line names the listeners only when it did
  else
    echo "ss is not installed here; not listing sockets"
    case "$1" in 0) set -- 2 ;; esac
    set -- "$1" unlisted
  fi
  (
    # Each credential reaches curl on stdin via a config file (curl --config -), never
    # argv; -u user:password is world-readable in /proc/<pid>/cmdline on a shared host.
    trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_MLFLOW_HOST' 'REPLACE_WITH_ADMIN_PASSWORD' 'REPLACE_WITH_LOWPERM_USER' 'REPLACE_WITH_LOWPERM_PASSWORD' 'REPLACE_WITH_A_REAL_EXPERIMENT_ID'   # first the public host name your proxy serves MLflow on, which is also a Host that --allowed-hosts admits, with no scheme, user name, port, path, query, fragment, percent sign or trailing dot: replace each value inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 5 ] || { echo "the set -- line needs exactly 5 values; not probing"; exit 2; }
    case "$1" in
      ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
    case "$1" in
      example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -u nocasematch   # every match below compares letter case exactly again
    case "$2" in *REPLACE_WITH_*|""|*[[:cntrl:]]*) echo "substitute the admin password on the set -- line above; not probing"; exit 2 ;; esac
    case "$3" in *REPLACE_WITH_*|""|*[[:cntrl:]]*) echo "substitute the low-permission user on the set -- line above; not probing"; exit 2 ;; esac
    case "$4" in *REPLACE_WITH_*|""|*[[:cntrl:]]*) echo "substitute the low-permission password on the set -- line above; not probing"; exit 2 ;; esac
    case "$5" in *REPLACE_WITH_*|""|*[[:cntrl:]]*) echo "substitute a real experiment id on the set -- line above; not probing"; exit 2 ;; esac
    set -- "$1" "${2//\\/\\\\}" "${3//\\/\\\\}" "${4//\\/\\\\}" "$5"
    set -- "$1" "${2//\"/\\\"}" "${3//\"/\\\"}" "${4//\"/\\\"}" "$5"
    set -- "$1" "$2" "$3" "$4" "$5" 0   # the 6th value is this part's status so far, ranked as above
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "$(if curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' -X POST -H 'Content-Type: application/json' -d '{"max_results":1}' \
      "https://$1/api/2.0/mlflow/experiments/search"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "${7##*$'\n'}" "${7%%$'\n'*}"   # curl's exit status, then the HTTP code
    printf '%s\n' "$8"                  # 401: no credentials
    case "$7:$8" in
      0:401) ;;
      0:2??) echo "FINDING: the public search answered $8 with no credentials"; set -- "$1" "$2" "$3" "$4" "$5" 1 ;;
      0:*) echo "HTTP $8 from the public search with no credentials is neither the 401 pass nor a 2xx finding; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
      *) echo "curl exit $7: the public search with no credentials failed; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
    esac
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "$(if printf 'user = "admin:%s"\n' "$2" | curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' -X POST -H 'Content-Type: application/json' -d '{"max_results":1}' \
      --config - "https://$1/api/2.0/mlflow/experiments/search"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "${7##*$'\n'}" "${7%%$'\n'*}"   # curl's exit status, then the HTTP code
    printf '%s\n' "$8"                  # positive control: 200 with the admin password
    case "$7:$8" in
      0:200) ;;
      0:*) echo "HTTP $8 from the public search with the admin password is not the 200 positive control; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
      *) echo "curl exit $7: the public search with the admin password failed; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
    esac
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "$(if printf 'user = "admin:not-the-real-password"\n' | curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' -X POST -H 'Content-Type: application/json' -d '{"max_results":1}' \
      --config - "https://$1/api/2.0/mlflow/experiments/search"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "${7##*$'\n'}" "${7%%$'\n'*}"   # curl's exit status, then the HTTP code
    printf '%s\n' "$8"                  # 401: a wrong password is refused (MLflow rejects the legacy password1234 by design, so there is no default to "remove")
    case "$7:$8" in
      0:401) ;;
      0:2??) echo "FINDING: the public search answered $8 to a wrong admin password"; set -- "$1" "$2" "$3" "$4" "$5" 1 ;;
      0:*) echo "HTTP $8 from the public search with a wrong password is neither the 401 pass nor a 2xx finding; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
      *) echo "curl exit $7: the public search with a wrong password failed; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
    esac
    # On the MLflow host, the same no-credential POST must ALSO be 401 - a 401 only at the proxy would leave
    # MLflow open behind it. On the host, --allowed-hosts rejects a bare 127.0.0.1 Host with 403 before auth,
    # so send the allowed Host header, your MLflow host name from the set -- line:
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "$(if curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' -X POST -H "Host: $1" -H 'Content-Type: application/json' -d '{"max_results":1}' \
      http://127.0.0.1:5000/api/2.0/mlflow/experiments/search; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "${7##*$'\n'}" "${7%%$'\n'*}"   # curl's exit status, then the HTTP code
    printf '%s\n' "$8"                  # 401: no credentials, on the backend
    case "$7:$8" in
      0:401) ;;
      0:2??) echo "FINDING: the backend search answered $8 with no credentials, so MLflow itself does not enforce authentication"; set -- "$1" "$2" "$3" "$4" "$5" 1 ;;
      0:403) echo "HTTP 403 from the backend search: --allowed-hosts refused the Host header before authentication ran; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
      0:*) echo "HTTP $8 from the backend search with no credentials is neither the 401 pass nor a 2xx finding; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
      *) echo "curl exit $7: the backend search with no credentials failed; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
    esac
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "$(if printf 'user = "admin:%s"\n' "$2" | curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' -X POST -H "Host: $1" -H 'Content-Type: application/json' -d '{"max_results":1}' \
      --config - http://127.0.0.1:5000/api/2.0/mlflow/experiments/search; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "${7##*$'\n'}" "${7%%$'\n'*}"   # curl's exit status, then the HTTP code
    printf '%s\n' "$8"                  # backend positive control: 200 with the admin password
    case "$7:$8" in
      0:200) ;;
      0:*) echo "HTTP $8 from the backend search with the admin password is not the 200 positive control; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
      *) echo "curl exit $7: the backend search with the admin password failed; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
    esac
    # Authorization, not just authentication: experiments/search only returns results the caller may see, so
    # it tests authn, not authz. Pick a REAL experiment id (not the placeholder), confirm admin can GET it,
    # then confirm a low-permission user is refused THERE - a 403 from MLflow on the backend, not the proxy:
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "$(if printf 'user = "admin:%s"\n' "$2" | curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' -H "Host: $1" \
      --config - "http://127.0.0.1:5000/api/2.0/mlflow/experiments/get?experiment_id=$5"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "${7##*$'\n'}" "${7%%$'\n'*}"   # curl's exit status, then the HTTP code
    printf '%s\n' "$8"                  # do this admin check FIRST: 200 means the experiment exists and admin may read it; a 401/403/404 here means a wrong id or wrong admin credentials, so fix that before trusting the next line
    case "$7:$8" in
      0:200) set -- "$1" "$2" "$3" "$4" "$5" "$6" admin-ok ;;
      0:*) echo "HTTP $8 from the admin experiment check is not 200: a wrong id or wrong admin credentials; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3; set -- "$1" "$2" "$3" "$4" "$5" "$6" admin-failed ;;
      *) echo "curl exit $7: the admin experiment check failed; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3; set -- "$1" "$2" "$3" "$4" "$5" "$6" admin-failed ;;
    esac
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$(if printf 'user = "%s:%s"\n' "$3" "$4" | curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' -H "Host: $1" \
      --config - "http://127.0.0.1:5000/api/2.0/mlflow/experiments/get?experiment_id=$5"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "$4" "$5" "$6" "$7" "${8##*$'\n'}" "${8%%$'\n'*}"   # the admin check's result, curl's exit status, then the HTTP code
    printf '%s\n' "$9"                  # 403: authenticated but not permitted, same real experiment from MLflow (a 401 here means the low-permission credentials are wrong, not authz)
    case "$7:$8:$9" in
      admin-ok:0:403) ;;
      admin-ok:0:2??) echo "FINDING: the low-permission user read the experiment ($9), so MLflow did not refuse it"; set -- "$1" "$2" "$3" "$4" "$5" 1 ;;
      admin-ok:0:401) echo "HTTP 401 for the low-permission user: its credentials are wrong, so authorization was not tested; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
      admin-ok:0:*) echo "HTTP $9 for the low-permission user is neither the 403 pass nor a 2xx finding; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
      admin-failed:0:*) echo "HTTP $9 for the low-permission user is not classified, because the admin check above failed" ;;
      *) echo "curl exit $8: the low-permission experiment check failed; inconclusive"; [ "$6" = 1 ] || set -- "$1" "$2" "$3" "$4" "$5" 3 ;;
    esac
    exit "$6"
  )
  case "$?:$1" in 0:*) ;; 1:*) set -- 1 "$2" ;; 2:0) set -- 2 "$2" ;; 2:*|*:1) ;; *) set -- 3 "$2" ;; esac   # fold that part's status into the block's, ranked as above
  case "$2" in
    listed) echo "block exit $1; the listeners are not classified, so read every one against the comment on the ss line" ;;
    *) echo "block exit $1; ss did not run, so there is no listener list to read" ;;
  esac
  exit "$1"
)
```

```bash
# Run this block from another machine, checking the port is unreachable from outside. The pass is that no TCP
# connection formed: time_connect stays 0.000000 and err names a connection-level failure (refused, no
# route, or a filtered-port connect timeout). A non-zero time_connect, or any http code, means the
# handshake completed and the port answered. A name-resolution or local socket error is inconclusive.
# The block exits 0 for curl exit 7 or 28 with time_connect 0.000000 and an err that opens "Failed to connect to"
# or "Connection timed out" (curl 8.18.0's connection-level wording; other wording reads as 3), 1 for a handshake
# or an http code, 3 for any other failure, a resolver timeout included, and 2 if it refuses its input. A local
# socket error can also exit 7 with "Failed to connect to", so read err before taking 0 as the pass.
(                                       # a subshell, so your own script arguments are untouched
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_THE_SERVER_PUBLIC_IP'   # replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the server's public address on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- "$1" "$(if curl -q -g -sI -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 10 \
       -w 'http=%{http_code} time_connect=%{time_connect} exit=%{exitcode} err=%{errormsg}\n' "http://$1:5000/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "${2##*$'\n'}" "${2%$'\n'*}"     # curl's exit status, then its write-out line
  printf '%s' "$3"
  case "$2:$3" in
    7:'http=000 time_connect=0.000000 '*' err=Failed to connect to '*|28:'http=000 time_connect=0.000000 '*' err=Failed to connect to '*|28:'http=000 time_connect=0.000000 '*' err=Connection timed out '*) echo "no TCP connection formed (curl exit $2); the pass, if err names a refusal, no route or a connect timeout"; set -- 0 ;;
    *:'http=000 time_connect=0.000000 '*) echo "curl exit $2 with no connection: a name-resolution or local error; inconclusive"; set -- 3 ;;
    *:http=*) echo "FINDING: the handshake completed or the port answered (a non-zero time_connect or an http code), so port 5000 is reachable from this machine"; set -- 1 ;;
    *) echo "curl exit $2 printed no write-out line; inconclusive"; set -- 3 ;;
  esac
  echo "block exit $1; the err text is not classified, so confirm it names a connection-level failure before reading 0 as the pass"
  exit "$1"
)
```

REASONED: preceding block; external TCP reachability follows the cited MLflow host/binding documentation and curl connection/error write-out reference; no external test path is available in the authoring environment, so no reachability result is recorded. The first block's listener inventory, proxy/backend authentication and experiment authorization are declared by its own leading comment and follow the cited MLflow host/binding and authentication documentation; no deployed server, credentials or experiment-permission fixture is available for them. An authenticated user without permission on a resource gets `403`; a missing or wrong credential gets `401`. The backend authentication and authorization checks above ship marked reasoned, not demonstrated: the authoring environment has no running MLflow basic-auth server, so the exposed and fixed states (anonymous `experiments/search` open versus `401`, and the admin `200` versus low-permission `403` on a real experiment) are not observed here. The expected outcomes are REASONED from the cited MLflow authentication documentation. The public checks and the backend Host header take the MLflow host name on a guarded `set --` line that refuses example.com, example.net, example.org and their subdomains. The second block's current form is covered only by the gate suite's bash -n and ShellCheck 0.11.0 passes and by curl-stub runs while it was drafted. Those curl-stub runs covered an earlier form of the first block, that guard included, before its `command -v ss` check. Stub runs with `ss` present and passing, present and failing, and missing covered a later form, whose last line named the listeners even when `ss` was missing. Stub runs under the same three `ss` conditions, in which its last line named the listeners only when `ss` ran, covered the form after that, whose guard lowercased the host with `tr` before refusing those names. The first block's current form is covered only by the gate suite's bash -n and ShellCheck 0.11.0 passes and by local bash -n, ShellCheck 0.11.0 and stub runs on 2026-11-01, in which the guard refused those names in lower, upper and mixed case, also with `tr` absent and under an inherited `nocasematch`, `readonly`, `declare -i` or `set -e`, and under dash refused every host with status 2.

## Common mistakes

- Running `--host 0.0.0.0` "for the team" with no `--app-name basic-auth` and no proxy: the whole experiment history is world-writable.
- Bootstrapping the admin account with a weak or shared password (MLflow now requires at least 12 characters and rejects `password1234`, but a guessable value is still a risk).
- Setting `MLFLOW_TRACKING_USERNAME` in CI and assuming the server checks it; without the auth app it is ignored.
- Committing `basic_auth.ini` with `admin_password` or a database password inside it.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- MLflow CSRF-key file input: [global `--env-file` option and existing-environment precedence](https://mlflow.org/docs/latest/api_reference/cli.html#mlflow), [v3.16.1 auth factory](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/auth/__init__.py#L6008-L6021), and [v3.16.1 worker environment](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/__init__.py#L401-L402).
- MLflow authentication with username and password (`--app-name basic-auth`, default admin credentials, `basic_auth.ini` keys, `MLFLOW_AUTH_CONFIG_PATH`, `MLFLOW_FLASK_SERVER_SECRET_KEY`, client variables, 403 on missing permission): https://mlflow.org/docs/latest/self-hosting/security/basic-http-auth/
- MLflow authentication REST API (`2.0/mlflow/users/update-password` request fields): https://mlflow.org/docs/latest/api_reference/auth/rest-api.html
- `mlflow server` CLI reference (`--host` default 127.0.0.1, `--port` 5000, `--app-name`, `--allowed-hosts`, `--cors-allowed-origins`, `--serve-artifacts`): https://mlflow.org/docs/latest/api_reference/cli.html
- MLflow tracking server (default address, reverse proxy or VPN for TLS and auth, `MLFLOW_TRACKING_TOKEN`, `MLFLOW_TRACKING_INSECURE_TLS`, artifact proxying) (security-middleware flags need MLflow 3.5.0 or newer): https://mlflow.org/docs/latest/self-hosting/architecture/tracking-server
- MLflow REST API, Search Experiments (`POST 2.0/mlflow/experiments/search`): https://mlflow.org/docs/latest/api_reference/rest-api.html
- Docker, port publishing (loopback publishing) (loopback-only reach assumes Docker 28.0.0 or later): https://docs.docker.com/engine/network/port-publishing/
- curl manual (`--connect-timeout` bounds the connection phase only; the `time_connect`, `exitcode`, and `errormsg` write-out variables, the last two added in curl 7.75.0): https://curl.se/docs/manpage.html
- MLflow `--host` option, default `127.0.0.1`, and `--port`, default `5000`, which the `MLFLOW_HOST` and `MLFLOW_PORT` environment variables override (pinned tag v3.16.1): https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/utils/cli_args.py#L162-L180
- MLflow's tracking-server command, `def server`, takes those `--host` and `--port` options (pinned tag v3.16.1): <https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L369-L541>
- MLflow v3.16.1 `--uvicorn-opts` forwarding to the default Uvicorn server (checked October 2026): [`--uvicorn-opts` option and `MLFLOW_UVICORN_OPTS`](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L454-L459), [only one of `--gunicorn-opts`, `--waitress-opts` or `--uvicorn-opts`](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L317-L325), [`--dev` refuses `--uvicorn-opts`](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L602-L608), [Uvicorn unless gunicorn or waitress options are given](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/__init__.py#L409-L411), [Uvicorn command selection](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/__init__.py#L437-L441) and [`shlex.split` options placed after `-m uvicorn`](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/__init__.py#L303-L327).
- Uvicorn 0.54.0 `--ssl-keyfile` and `--ssl-certfile` HTTPS options (checked October 2026): [settings documentation](https://github.com/encode/uvicorn/blob/0.54.0/docs/settings.md#L128-L134) and [command-line option definitions](https://github.com/encode/uvicorn/blob/0.54.0/uvicorn/main.py#L310-L317).
- nginx release-1.28.0 proxy directive registration (checked October 2026; `proxy_pass` takes one upstream argument): https://github.com/nginx/nginx/blob/release-1.28.0/src/http/modules/ngx_http_proxy_module.c#L305-L310
- Caddy v2.11.4 `reverse_proxy` parser (checked October 2026): [directive registration](https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/reverseproxy/caddyfile.go#L40) and [upstream syntax](https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/reverseproxy/caddyfile.go#L58-L62).
- iproute2 v6.12.0 `ss` manual (checked October 2026): [numeric output](https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L33-L34), [listening sockets](https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L43-L44), [process display](https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L162-L163), and [TCP sockets](https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L374-L375).
- MLflow v3.16.1 dotenv loader (checked October 2026): [existing-environment precedence](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L85-L86) and [global eager `--env-file` option](https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L94-L105).
- MLflow v3.16.1 tracking credential variables and the token comment; request-code precedence below qualifies that comment (checked October 2026): https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/environment_variables.py#L493-L503
- MLflow v3.16.1 HTTP Authorization construction, Kubernetes exception and additional auth handlers (checked October 2026): https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/utils/rest_utils.py#L254-L292
- Cloudflare Access MFA requirements and independent MFA prerequisites (pinned commit c896795b8e8bab68d05ae78d64c9cbcda1fdb104, checked October 2026): https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/policies/mfa-requirements.mdx#L17-L85
- Cloudflare independent MFA, including TOTP and WebAuthn security keys (pinned commit c896795b8e8bab68d05ae78d64c9cbcda1fdb104, checked October 2026): https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/access-settings/independent-mfa.mdx#L15-L24
- Cloudflare service-token Service Auth requirement, request headers and configurable single-header alternative (pinned commit c896795b8e8bab68d05ae78d64c9cbcda1fdb104, checked October 2026). Cloudflare service-token sources: https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/service-credentials/service-tokens.mdx#L33. More Cloudflare service-token sources: https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/service-credentials/service-tokens.mdx#L45-L49. More Cloudflare service-token sources: https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/service-credentials/service-tokens.mdx#L59
- oauth2-proxy v7.15.6 provider and upstream configuration; these entries do not establish MFA enforcement (checked November 2026): https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.6/docs/docs/configuration/overview.md#L94-L108, https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.6/docs/docs/configuration/overview.md#L305
- Authelia v4.39.28 first matching rule, default policy and two_factor requirement (checked October 2026): https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/security/access-control.md#L506-L507, https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/security/access-control.md#L536-L537


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- source: MLflow pinned source (v3.16.1)
- middleware-min: MLflow security middleware minimum (3.5.0)
- docs: MLflow documentation (unknown)
- docker: Docker Engine loopback publication minimum (28.0.0)
- nginx: nginx proxy implementation (release-1.28.0)
- caddy: Caddy reverse proxy parser (v2.11.4)
- cf-docs: Cloudflare documentation (c896795b8e8bab68d05ae78d64c9cbcda1fdb104)
- oauth2-proxy-source: oauth2-proxy documentation (v7.15.6)
- authelia-source: Authelia source (v4.39.28)
- curl: curl minimum write-out version (7.75.0)
- iproute2: iproute2 ss manual (v6.12.0)
- uvicorn: Uvicorn source (0.54.0)

Claims (full source mapping in the JSON block below):

- default-host (REASONED; source): v3.16.1 defaults to 127.0.0.1 unless MLFLOW_HOST overrides it; explicitly bind privately and do not treat --host as an authentication setting.
- default-port (REASONED; source): v3.16.1 serves the tracking UI and REST API on port 5000 unless MLFLOW_PORT overrides it.
- default-auth (REASONED; docs): Authentication is opt-in; a reachable server without the auth app permits reading, changing and deleting tracking resources and proxied artifacts.
- container-bind (REASONED; docker, docs): Normal bridge NAT requires host loopback publication 127.0.0.1:5000:5000 and --host 0.0.0.0 inside the container; container loopback cannot serve the publication. Before Docker 28.0.0, same-layer-2 hosts could reach loopback-published ports.
- middleware-scope (REASONED; middleware-min, docs): Security middleware requires MLflow 3.5.0 or newer and the default Uvicorn server; --gunicorn-opts and --waitress-opts do not use it.
- host-allowlist (REASONED; docs): Set --allowed-hosts mlflow.example.com for access beyond loopback; defaults admit localhost, 127.0.0.1, [::1], 0.0.0.0 and private ranges as Host headers, not client-source firewall rules.
- cors (REASONED; docs): Set --cors-allowed-origins https://mlflow.example.com for the intended browser origin.
- middleware-disable (REASONED; docs): Do not use --disable-security-middleware outside a test.
- tls (REASONED; docs, source, uvicorn, nginx, caddy): There are no dedicated server TLS flags; MLflow v3.16.1 --uvicorn-opts can forward Uvicorn 0.54.0 --ssl-keyfile/--ssl-certfile to the default Uvicorn server, not with --dev, --gunicorn-opts or --waitress-opts. Use a TLS proxy to 127.0.0.1:5000 or a tunnel/tailnet and set the allowed public hostname.
- client-tls (REASONED; docs): Use MLFLOW_TRACKING_URI=https://mlflow.example.com and never enable MLFLOW_TRACKING_INSECURE_TLS in production.
- auth-app (REASONED; docs): Install mlflow[auth] and run --app-name basic-auth; client username/password variables alone enable no server authentication. The September 2026 documentation has no experimental label.
- csrf-key (REASONED; docs): Provision a long random MLFLOW_FLASK_SERVER_SECRET_KEY identical on every replica through a protected server.env file, mode 0600, with protected directories and no other-account ACL access; keep file and backups out of source control.
- env-file (REASONED; docs, source): Global --env-file loads dotenv before the server command without overriding existing environment; clear inherited key/config-path variables and require a readable regular non-symlink file before launching.
- key-exposure (REASONED; source, docs): Only the file path reaches the launch command; MLflow v3.16.1 loads the key into its environment and forwards it to workers, retaining same-account/root memory and inheriting-process environment exposure.
- admin-bootstrap (REASONED; docs): No default admin password: first start requires at least 12 characters from MLFLOW_AUTH_ADMIN_PASSWORD or admin_password, rejects password1234 and fails without a password; an already-bootstrapped admin needs no resupply.
- default-permission (REASONED; docs): default_permission is READ on every resource; set NO_PERMISSIONS in the auth configuration to remove that default grant.
- auth-database (REASONED; docs): database_uri defaults to basic_auth.db in the working directory; use a central database for multiple nodes, as in the PostgreSQL auth-database example.
- auth-config (REASONED; docs): MLFLOW_AUTH_CONFIG_PATH selects basic_auth.ini; authorization_function accepts module:function for custom authentication, while the shipped scheme is HTTP Basic.
- password-rotation (REASONED; docs, curl): PATCH /api/2.0/mlflow/users/update-password takes username and password; the example feeds current and new passwords through curl config stdin with JSON/config escaping.
- user-creation (REASONED; docs): User creation requires admin credentials at /signup or POST /api/2.0/mlflow/users/create; give humans individual accounts and CI a separate low-permission user.
- client-credentials (REASONED; docs): ~/.mlflow/credentials stores passwords unencrypted; prefer runtime-injected MLFLOW_TRACKING_USERNAME/MLFLOW_TRACKING_PASSWORD.
- rate-limit (REASONED; docs): The UI has no login-attempt limit and Basic auth is checked on every protected API request; rate-limit all authentication-bearing routes at the proxy and protect password transport with TLS.
- mfa (REASONED; docs, cf-docs, oauth2-proxy-source, authelia-source): MFA: the cited MLflow material does not establish basic-auth MFA support; guide advice: front MLflow with Cloudflare Access, Authelia or oauth2-proxy per mfa.md and require MFA for human access. Cloudflare Access (pinned commit) and Authelia v4.39.28 document MFA-requiring policies, cited oauth2-proxy v7.15.6 passages do not, and none establishes MFA enforcement in a deployed MLflow combination.
- proxy-token (REASONED; docs, source, cf-docs): Cited MLflow v3.16.1 request code sends MLFLOW_TRACKING_TOKEN as Authorization: Bearer only when no username and password select Basic, not in every auth mode. Cloudflare Access service tokens (pinned commit) use CF-Access-Client-Id and CF-Access-Client-Secret headers; guide advice: confirm the client and proxy keep both proxy and MLflow authentication, which the citations do not establish.
- artifact-proxy (REASONED; docs): --serve-artifacts defaults on; --artifacts-destination s3://bucket lets the server proxy reads/writes for proxied experiments, holding storage credentials so clients need none.
- artifact-existing (REASONED; docs): Pre-existing experiments and explicit direct artifact locations retain their locations outside tracking-server permission enforcement; inspect locations and apply storage IAM directly.
- artifact-direct (REASONED; docs): With --no-serve-artifacts every client needs storage credentials and tracking-server permissions no longer gate artifacts; use environment or instance-role credentials, not repository/Compose secrets.
- verify-bind (REASONED; source, iproute2): Read every listener and require 5000 on 127.0.0.1.
- verify-network (REASONED; curl, docs): Outside :5000 must form no TCP connection: time_connect stays 0.000000 with a connection-level failure. A handshake or HTTP response means exposure; DNS/local socket errors are inconclusive.
- verify-public-auth (REASONED; docs, curl): POST experiments/search with a minimal body: anonymous and wrong-password requests should return 401, valid admin 200; an open backend returns anonymous 200. Proxy credentials may also be needed; shell success is not a pass.
- verify-backend-auth (REASONED; docs): Repeat anonymous 401/admin 200 directly on loopback with the public Host header that --allowed-hosts admits; an allowlist Host rejection is 403 before auth, and a proxy-only denial proves no backend enforcement.
- verify-authorization (REASONED; docs): Search filters visible experiments and does not prove authorization denial. First GET a real experiment as admin for 200, then the same backend resource as a low-permission user for 403; 401 means bad credentials and a failed admin control is inconclusive.

````json
{
  "schema": 1,
  "checked": "2026-11-06",
  "documentation_checked": "2026-09",
  "body_sha256": "955c235f0af3f28eb2b388886d814e71dc6cd8003a1df1632ced686a179c524f",
  "components": {
    "source": {
      "name": "MLflow pinned source",
      "basis": "v3.16.1",
      "sources": {
        "sf7285d252e29": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/utils/cli_args.py#L162-L180",
        "sa3993a9b625f": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L369-L541",
        "sd775f10c4d07": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/auth/__init__.py#L6008-L6021",
        "s349a81b9478e": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/__init__.py#L401-L402",
        "s99d30948902f": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L85-L86",
        "s687f1c9977cd": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L94-L105",
        "s1661739df39d": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/environment_variables.py#L493-L503",
        "s5801c6ac1ac2": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/utils/rest_utils.py#L254-L292",
        "s4a930b35f97e": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L454-L459",
        "s3df936d1e2ff": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L317-L325",
        "sea0054295867": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/cli/__init__.py#L602-L608",
        "sf711a9bb7d38": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/__init__.py#L409-L411",
        "s25614af41a95": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/__init__.py#L437-L441",
        "sa1678567912a": "https://github.com/mlflow/mlflow/blob/v3.16.1/mlflow/server/__init__.py#L303-L327"
      }
    },
    "middleware-min": {
      "name": "MLflow security middleware minimum",
      "basis": "3.5.0",
      "sources": {
        "s2517159af609": "https://mlflow.org/docs/latest/self-hosting/architecture/tracking-server"
      }
    },
    "docs": {
      "name": "MLflow documentation",
      "basis": "unknown",
      "sources": {
        "scbbc07258943": "https://mlflow.org/docs/latest/self-hosting/security/basic-http-auth/",
        "sc3a2d70cabf9": "https://mlflow.org/docs/latest/api_reference/auth/rest-api.html",
        "s5b79d1871e0b": "https://mlflow.org/docs/latest/api_reference/cli.html",
        "s2517159af609": "https://mlflow.org/docs/latest/self-hosting/architecture/tracking-server",
        "s996e587e947a": "https://mlflow.org/docs/latest/api_reference/rest-api.html",
        "s559e7a8271b9": "https://mlflow.org/docs/latest/api_reference/cli.html#mlflow"
      }
    },
    "docker": {
      "name": "Docker Engine loopback publication minimum",
      "basis": "28.0.0",
      "sources": {
        "s1e53417c513d": "https://docs.docker.com/engine/network/port-publishing/"
      }
    },
    "nginx": {
      "name": "nginx proxy implementation",
      "basis": "release-1.28.0",
      "sources": {
        "s6dfa81e36717": "https://github.com/nginx/nginx/blob/release-1.28.0/src/http/modules/ngx_http_proxy_module.c#L305-L310"
      }
    },
    "caddy": {
      "name": "Caddy reverse proxy parser",
      "basis": "v2.11.4",
      "sources": {
        "s52039756d4f4": "https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/reverseproxy/caddyfile.go#L40",
        "s9dde4a2bda4c": "https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/reverseproxy/caddyfile.go#L58-L62"
      }
    },
    "cf-docs": {
      "name": "Cloudflare documentation",
      "basis": "c896795b8e8bab68d05ae78d64c9cbcda1fdb104",
      "sources": {
        "s6f6104362214": "https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/policies/mfa-requirements.mdx#L17-L85",
        "s7e793d13cf31": "https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/access-settings/independent-mfa.mdx#L15-L24",
        "sbec4996a7089": "https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/service-credentials/service-tokens.mdx#L33",
        "s543b1f2eb29c": "https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/service-credentials/service-tokens.mdx#L45-L49",
        "sc565f2d80e6e": "https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/service-credentials/service-tokens.mdx#L59"
      }
    },
    "oauth2-proxy-source": {
      "name": "oauth2-proxy documentation",
      "basis": "v7.15.6",
      "sources": {
        "s523e9ec2bd77": "https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.6/docs/docs/configuration/overview.md#L94-L108",
        "sa2319a734772": "https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.6/docs/docs/configuration/overview.md#L305"
      }
    },
    "authelia-source": {
      "name": "Authelia source",
      "basis": "v4.39.28",
      "sources": {
        "s768b165b44a0": "https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/security/access-control.md#L506-L507",
        "sd4dd76e70475": "https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/security/access-control.md#L536-L537"
      }
    },
    "curl": {
      "name": "curl minimum write-out version",
      "basis": "7.75.0",
      "sources": {
        "s2b2686afaf41": "https://curl.se/docs/manpage.html"
      }
    },
    "iproute2": {
      "name": "iproute2 ss manual",
      "basis": "v6.12.0",
      "sources": {
        "s2afc4764d5bb": "https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L33-L34",
        "sfaa932c2ca13": "https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L43-L44",
        "sd295f82d643f": "https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L162-L163",
        "s65278ee45850": "https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L374-L375"
      }
    },
    "uvicorn": {
      "name": "Uvicorn source",
      "basis": "0.54.0",
      "sources": {
        "s1a2858bce328": "https://github.com/encode/uvicorn/blob/0.54.0/docs/settings.md#L128-L134",
        "s6ad833b4b583": "https://github.com/encode/uvicorn/blob/0.54.0/uvicorn/main.py#L310-L317"
      }
    }
  },
  "claims": {
    "default-host": {"text": "v3.16.1 defaults to 127.0.0.1 unless MLFLOW_HOST overrides it; explicitly bind privately and do not treat --host as an authentication setting.", "components": ["source"], "sources": ["source:sf7285d252e29", "source:sa3993a9b625f"], "status": "REASONED"},
    "default-port": {"text": "v3.16.1 serves the tracking UI and REST API on port 5000 unless MLFLOW_PORT overrides it.", "components": ["source"], "sources": ["source:sf7285d252e29", "source:sa3993a9b625f"], "status": "REASONED"},
    "default-auth": {"text": "Authentication is opt-in; a reachable server without the auth app permits reading, changing and deleting tracking resources and proxied artifacts.", "components": ["docs"], "sources": ["docs:scbbc07258943", "docs:s2517159af609"], "status": "REASONED"},
    "container-bind": {"text": "Normal bridge NAT requires host loopback publication 127.0.0.1:5000:5000 and --host 0.0.0.0 inside the container; container loopback cannot serve the publication. Before Docker 28.0.0, same-layer-2 hosts could reach loopback-published ports.", "components": ["docker", "docs"], "sources": ["docker:s1e53417c513d", "docs:s5b79d1871e0b"], "status": "REASONED"},
    "middleware-scope": {"text": "Security middleware requires MLflow 3.5.0 or newer and the default Uvicorn server; --gunicorn-opts and --waitress-opts do not use it.", "components": ["middleware-min", "docs"], "sources": ["middleware-min:s2517159af609", "docs:s5b79d1871e0b", "docs:s2517159af609"], "status": "REASONED"},
    "host-allowlist": {"text": "Set --allowed-hosts mlflow.example.com for access beyond loopback; defaults admit localhost, 127.0.0.1, [::1], 0.0.0.0 and private ranges as Host headers, not client-source firewall rules.", "components": ["docs"], "sources": ["docs:s5b79d1871e0b", "docs:s2517159af609"], "status": "REASONED"},
    "cors": {"text": "Set --cors-allowed-origins https://mlflow.example.com for the intended browser origin.", "components": ["docs"], "sources": ["docs:s5b79d1871e0b", "docs:s2517159af609"], "status": "REASONED"},
    "middleware-disable": {"text": "Do not use --disable-security-middleware outside a test.", "components": ["docs"], "sources": ["docs:s5b79d1871e0b", "docs:s2517159af609"], "status": "REASONED"},
    "tls": {"text": "There are no dedicated server TLS flags; MLflow v3.16.1 --uvicorn-opts can forward Uvicorn 0.54.0 --ssl-keyfile/--ssl-certfile to the default Uvicorn server, not with --dev, --gunicorn-opts or --waitress-opts. Use a TLS proxy to 127.0.0.1:5000 or a tunnel/tailnet and set the allowed public hostname.", "components": ["docs", "source", "uvicorn", "nginx", "caddy"], "sources": ["docs:s5b79d1871e0b", "docs:s2517159af609", "source:s4a930b35f97e", "source:s3df936d1e2ff", "source:sea0054295867", "source:sf711a9bb7d38", "source:s25614af41a95", "source:sa1678567912a", "uvicorn:s1a2858bce328", "uvicorn:s6ad833b4b583", "nginx:s6dfa81e36717", "caddy:s52039756d4f4", "caddy:s9dde4a2bda4c"], "status": "REASONED"},
    "client-tls": {"text": "Use MLFLOW_TRACKING_URI=https://mlflow.example.com and never enable MLFLOW_TRACKING_INSECURE_TLS in production.", "components": ["docs"], "sources": ["docs:s2517159af609"], "status": "REASONED"},
    "auth-app": {"text": "Install mlflow[auth] and run --app-name basic-auth; client username/password variables alone enable no server authentication. The September 2026 documentation has no experimental label.", "components": ["docs"], "sources": ["docs:scbbc07258943"], "status": "REASONED"},
    "csrf-key": {"text": "Provision a long random MLFLOW_FLASK_SERVER_SECRET_KEY identical on every replica through a protected server.env file, mode 0600, with protected directories and no other-account ACL access; keep file and backups out of source control.", "components": ["docs"], "sources": ["docs:scbbc07258943"], "status": "REASONED"},
    "env-file": {"text": "Global --env-file loads dotenv before the server command without overriding existing environment; clear inherited key/config-path variables and require a readable regular non-symlink file before launching.", "components": ["docs", "source"], "sources": ["docs:s559e7a8271b9", "source:s99d30948902f", "source:s687f1c9977cd"], "status": "REASONED"},
    "key-exposure": {"text": "Only the file path reaches the launch command; MLflow v3.16.1 loads the key into its environment and forwards it to workers, retaining same-account/root memory and inheriting-process environment exposure.", "components": ["source", "docs"], "sources": ["source:sd775f10c4d07", "source:s349a81b9478e", "docs:s559e7a8271b9", "source:s99d30948902f", "source:s687f1c9977cd"], "status": "REASONED"},
    "admin-bootstrap": {"text": "No default admin password: first start requires at least 12 characters from MLFLOW_AUTH_ADMIN_PASSWORD or admin_password, rejects password1234 and fails without a password; an already-bootstrapped admin needs no resupply.", "components": ["docs"], "sources": ["docs:scbbc07258943"], "status": "REASONED"},
    "default-permission": {"text": "default_permission is READ on every resource; set NO_PERMISSIONS in the auth configuration to remove that default grant.", "components": ["docs"], "sources": ["docs:scbbc07258943"], "status": "REASONED"},
    "auth-database": {"text": "database_uri defaults to basic_auth.db in the working directory; use a central database for multiple nodes, as in the PostgreSQL auth-database example.", "components": ["docs"], "sources": ["docs:scbbc07258943"], "status": "REASONED"},
    "auth-config": {"text": "MLFLOW_AUTH_CONFIG_PATH selects basic_auth.ini; authorization_function accepts module:function for custom authentication, while the shipped scheme is HTTP Basic.", "components": ["docs"], "sources": ["docs:scbbc07258943"], "status": "REASONED"},
    "password-rotation": {"text": "PATCH /api/2.0/mlflow/users/update-password takes username and password; the example feeds current and new passwords through curl config stdin with JSON/config escaping.", "components": ["docs", "curl"], "sources": ["docs:sc3a2d70cabf9", "curl:s2b2686afaf41"], "status": "REASONED"},
    "user-creation": {"text": "User creation requires admin credentials at /signup or POST /api/2.0/mlflow/users/create; give humans individual accounts and CI a separate low-permission user.", "components": ["docs"], "sources": ["docs:scbbc07258943", "docs:sc3a2d70cabf9"], "status": "REASONED"},
    "client-credentials": {"text": "~/.mlflow/credentials stores passwords unencrypted; prefer runtime-injected MLFLOW_TRACKING_USERNAME/MLFLOW_TRACKING_PASSWORD.", "components": ["docs"], "sources": ["docs:scbbc07258943"], "status": "REASONED"},
    "rate-limit": {"text": "The UI has no login-attempt limit and Basic auth is checked on every protected API request; rate-limit all authentication-bearing routes at the proxy and protect password transport with TLS.", "components": ["docs"], "sources": ["docs:scbbc07258943"], "status": "REASONED"},
    "mfa": {"text": "MFA: the cited MLflow material does not establish basic-auth MFA support; guide advice: front MLflow with Cloudflare Access, Authelia or oauth2-proxy per mfa.md and require MFA for human access. Cloudflare Access (pinned commit) and Authelia v4.39.28 document MFA-requiring policies, cited oauth2-proxy v7.15.6 passages do not, and none establishes MFA enforcement in a deployed MLflow combination.", "components": ["docs", "cf-docs", "oauth2-proxy-source", "authelia-source"], "sources": ["docs:scbbc07258943", "cf-docs:s6f6104362214", "cf-docs:s7e793d13cf31", "oauth2-proxy-source:s523e9ec2bd77", "oauth2-proxy-source:sa2319a734772", "authelia-source:s768b165b44a0", "authelia-source:sd4dd76e70475"], "status": "REASONED"},
    "proxy-token": {"text": "Cited MLflow v3.16.1 request code sends MLFLOW_TRACKING_TOKEN as Authorization: Bearer only when no username and password select Basic, not in every auth mode. Cloudflare Access service tokens (pinned commit) use CF-Access-Client-Id and CF-Access-Client-Secret headers; guide advice: confirm the client and proxy keep both proxy and MLflow authentication, which the citations do not establish.", "components": ["docs", "source", "cf-docs"], "sources": ["docs:s2517159af609", "source:s1661739df39d", "source:s5801c6ac1ac2", "cf-docs:sbec4996a7089", "cf-docs:s543b1f2eb29c", "cf-docs:sc565f2d80e6e"], "status": "REASONED"},
    "artifact-proxy": {"text": "--serve-artifacts defaults on; --artifacts-destination s3://bucket lets the server proxy reads/writes for proxied experiments, holding storage credentials so clients need none.", "components": ["docs"], "sources": ["docs:s5b79d1871e0b", "docs:s2517159af609"], "status": "REASONED"},
    "artifact-existing": {"text": "Pre-existing experiments and explicit direct artifact locations retain their locations outside tracking-server permission enforcement; inspect locations and apply storage IAM directly.", "components": ["docs"], "sources": ["docs:s2517159af609"], "status": "REASONED"},
    "artifact-direct": {"text": "With --no-serve-artifacts every client needs storage credentials and tracking-server permissions no longer gate artifacts; use environment or instance-role credentials, not repository/Compose secrets.", "components": ["docs"], "sources": ["docs:s2517159af609"], "status": "REASONED"},
    "verify-bind": {"text": "Read every listener and require 5000 on 127.0.0.1.", "components": ["source", "iproute2"], "sources": ["source:sf7285d252e29", "source:sa3993a9b625f", "iproute2:s2afc4764d5bb", "iproute2:sfaa932c2ca13", "iproute2:sd295f82d643f", "iproute2:s65278ee45850"], "status": "REASONED", "verify": [1]},
    "verify-network": {"text": "Outside :5000 must form no TCP connection: time_connect stays 0.000000 with a connection-level failure. A handshake or HTTP response means exposure; DNS/local socket errors are inconclusive.", "components": ["curl", "docs"], "sources": ["curl:s2b2686afaf41", "docs:s5b79d1871e0b"], "status": "REASONED", "verify": [2]},
    "verify-public-auth": {"text": "POST experiments/search with a minimal body: anonymous and wrong-password requests should return 401, valid admin 200; an open backend returns anonymous 200. Proxy credentials may also be needed; shell success is not a pass.", "components": ["docs", "curl"], "sources": ["docs:scbbc07258943", "docs:s996e587e947a", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [1]},
    "verify-backend-auth": {"text": "Repeat anonymous 401/admin 200 directly on loopback with the public Host header that --allowed-hosts admits; an allowlist Host rejection is 403 before auth, and a proxy-only denial proves no backend enforcement.", "components": ["docs"], "sources": ["docs:scbbc07258943", "docs:s5b79d1871e0b", "docs:s996e587e947a"], "status": "REASONED", "verify": [1]},
    "verify-authorization": {"text": "Search filters visible experiments and does not prove authorization denial. First GET a real experiment as admin for 200, then the same backend resource as a low-permission user for 403; 401 means bad credentials and a failed admin control is inconclusive.", "components": ["docs"], "sources": ["docs:scbbc07258943", "docs:s996e587e947a"], "status": "REASONED", "verify": [1]}
  }
}
````
<!-- version-basis:end -->
