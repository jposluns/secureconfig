# Fronting auth: putting login and MFA in front of an app that has none (oauth2-proxy, Authelia, Pomerium)

oauth2-proxy, Authelia and Pomerium are login gateways for apps that lack sign-in, checking every request first. This guide helps your AI assistant set one up securely, including an app reachable only through the proxy, MFA from the identity provider or Authelia itself, and one trusted identity header.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/fronting-auth.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against oauth2-proxy v7.15.6, Authelia v4.39.28, and curl minimum write-out version 7.75.0; 1 further source is pinned to a commit and 5 carry no recorded version. Metadata reviewed 2026-11-06; documentation checked September 2026. The guide records 34 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Many self-hosted apps (internal tools, dashboards, webhook receivers) ship with no login at all. The fix is the same shape every time: the app binds to loopback, a proxy in front does authentication and MFA, and it passes the app a verified identity, which the app must not accept from anywhere else. This guide is what [mfa.md](mfa.md), [nginx.md](nginx.md), [traefik.md](traefik.md), and [caddy.md](caddy.md) point at.

## 1. The pattern

1. **Bind the app to loopback**, `127.0.0.1`, never `0.0.0.0` or `::`. Bind the auth service so only the fronting proxy reaches it too: loopback when it shares the host, or a private container network with no published port when it does not, never a public interface. The oauth2-proxy `--http-address` option defaults to `127.0.0.1:4180` as of v7.15.6; Authelia's `server.address` defaults to `tcp://:9091/` as of v4.39.28, whose host-and-port, `:9091` with an empty host, Authelia passes to Go's `net.Listen`, which then listens on every local address, so restrict it. If the app also answers directly, the login page in front of it is decorative.
2. **A proxy authenticates first**: oauth2-proxy, Authelia, or Pomerium checks the session before the request reaches the app; an unauthenticated request never gets there.
3. **The proxy passes identity in a header and the app reads that header** instead of running its own login. The header must be one the proxy sets on every request from its own verified response, so the proxy overwrites any value a client sent: nginx `X-User`/`X-Email` in the example below, oauth2-proxy's `X-Auth-Request-User` carried through Traefik, Authelia's `Remote-User`. The app must never read a header the proxy does not set, because nginx and Traefik forward the client's other headers unchanged.
4. **The app must trust only the exact header the proxy sets, and reject any other.** Network isolation, only the proxy can reach the app, stops a direct client from setting the header; but a client can also send a header *through* the proxy, and the proxy overwrites only the one header it sets while forwarding the rest, so the app must read that one header and no other. The managed-cloud version of this same bypass risk is in [cloud-identity-proxies.md](cloud-identity-proxies.md).

## 2. oauth2-proxy: auth in front of an OIDC/OAuth2 provider

Core flags (env vars use the `OAUTH2_PROXY_` prefix): `--provider` (`oidc`, `google`, `github`, and others), `--client-id`/`--client-secret` from the IdP, `--email-domain` (a domain, or `*` for any authenticated user), `--upstream` (the app address, or `static://202` when a forward-auth proxy handles the actual proxying), and `--cookie-secret`. The `--cookie-secret` value must be exactly 16, 24, or 32 bytes, optionally base64-encoded: `openssl rand -base64 32 | tr -- '+/' '-_'`.

nginx uses `auth_request`, which requires oauth2-proxy's `--reverse-proxy` flag; forwarding the identity headers below also requires `--set-xauthrequest` (it makes oauth2-proxy set `X-Auth-Request-User` and `X-Auth-Request-Email` on its own `/oauth2/auth` response, which the `auth_request_set` lines then read):

```nginx
location /oauth2/ {
    proxy_pass       http://127.0.0.1:4180;
    proxy_set_header Host                    $host;
    proxy_set_header X-Real-IP               $remote_addr;
    proxy_set_header X-Auth-Request-Redirect $request_uri;
}
location = /oauth2/auth {
    proxy_pass       http://127.0.0.1:4180;
    proxy_set_header Host             $host;
    proxy_set_header X-Real-IP        $remote_addr;
    proxy_set_header X-Forwarded-Uri  $request_uri;
    proxy_set_header Content-Length   "";
    proxy_pass_request_body           off;
}
location / {
    auth_request /oauth2/auth;
    error_page 401 = @oauth2_signin;
    auth_request_set $user  $upstream_http_x_auth_request_user;
    auth_request_set $email $upstream_http_x_auth_request_email;
    proxy_set_header X-User  $user;
    proxy_set_header X-Email $email;
    proxy_pass http://127.0.0.1:3000;
}
location @oauth2_signin {
    return 302 /oauth2/sign_in?rd=$scheme://$host$request_uri;
}
```

Traefik uses a `forwardAuth` middleware at oauth2-proxy's `/oauth2/auth`, with `--upstream=static://202`, `--reverse-proxy=true`, and `--set-xauthrequest` (so oauth2-proxy sets `X-Auth-Request-User`/`X-Auth-Request-Email` on its `/oauth2/auth` response) set on oauth2-proxy. `authResponseHeaders` must list every identity header the app trusts, because Traefik copies only those from the auth response onto the request (replacing any the client sent) and forwards the client's other headers untouched:

```yaml
http:
  middlewares:
    oauth-auth:
      forwardAuth:
        address: "http://oauth2-proxy:4180/oauth2/auth"
        trustForwardHeader: true
        authResponseHeaders: [X-Auth-Request-User, X-Auth-Request-Email, X-Auth-Request-Access-Token, Authorization]
```

Attach the middleware to every router that serves the protected app: Traefik applies a middleware only where a router references it, so add `middlewares: [oauth-auth]` on the router in the file provider, or the label `traefik.http.routers.<app>.middlewares=oauth-auth@file`. A middleware that is defined but never referenced protects nothing.

Both examples run oauth2-proxy with `--reverse-proxy`, so also set `--trusted-proxy-ip` to the address the fronting proxy connects from. The [v7.15.6 nginx integration](https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.6/docs/docs/configuration/integrations/nginx.md#L18-L21) says to configure `--trusted-proxy-ip=127.0.0.1/32` when Nginx connects from localhost, which fits the nginx example above, since it proxies to `127.0.0.1:4180` (this guide's inference). For the Traefik example, use the address Traefik connects from on the container network (this guide's inference; the Traefik integration page does not name `--trusted-proxy-ip`). The v7.15.6 configuration overview warns that if `--trusted-proxy-ip` is left unset, oauth2-proxy trusts all source IPs, so a client that can reach it directly may be able to spoof forwarded headers.

The [v7.15.5 release notes](https://github.com/oauth2-proxy/oauth2-proxy/releases/tag/v7.15.5) list 2 critical advisories whose fixes concern settings this section uses. GHSA-wr5q-7wxw-x568, "Authentication bypass via spoofed client-IP headers in OAuth2 Proxy", is fixed so that, when `--reverse-proxy` is enabled, client-IP headers configured via `--real-client-ip-header` are accepted only from direct peers that match `--trusted-proxy-ip`. GHSA-63jm-59jj-478j, "Authentication bypass via inconsistent skip-auth path interpretation", is fixed by stricter `--skip-auth-route` and `--skip-auth-regex` matching, and the notes add that trusted `X-Forwarded-Uri` metadata, which the nginx example sets, must use origin form (`/path?query`). Both fixes are listed under v7.15.5, so releases before it lack them (this guide's inference from the release notes; the advisory pages, with their affected ranges, were not read), and this guide's oauth2-proxy basis is v7.15.6. This guide's configuration sets no `--trusted-ip` and no skip-auth rule; if you add either, review it against those notes. The same notes list a moderate advisory, GHSA-hhqp-vx7f-5c6m, "Credential disclosure through OAuth callback error logging", with no further detail, so whether it affects a given deployment is not established here. The v7.15.5 and [v7.15.6 release notes](https://github.com/oauth2-proxy/oauth2-proxy/releases/tag/v7.15.6) also list 4 and 18 CVE identifiers under "Vulnerabilities have been addressed", without titles or detail, so whether any bears on this guide's configuration is not established.

## 3. Authelia: a portal that does the second factor

Authelia is a login portal with built-in TOTP and WebAuthn, sitting behind the proxy rather than replacing it. Per its support page, nginx, Traefik, Caddy (2.5.1+), HAProxy (via a Lua module), Envoy, Skipper, NGINX Proxy Manager, and SWAG are supported; Apache and IIS are documented as having no compatible module and are not supported.

nginx calls a dedicated `auth-request` endpoint (its `auth_request` module cannot forward the method and body the way the others' forward-auth middlewares do). That endpoint must be defined; Authelia's own snippets (`authelia-location.conf` and `authelia-authrequest.conf`) show it as:

```nginx
resolver 127.0.0.11 valid=30s;
set $upstream_authelia http://authelia:9091/api/authz/auth-request;
location /internal/authelia/authz {
    internal;
    proxy_pass $upstream_authelia;
    proxy_set_header X-Original-Method $request_method;
    proxy_set_header X-Original-URL $scheme://$host$request_uri;
    proxy_set_header X-Forwarded-For $remote_addr;
    proxy_set_header Content-Length "";
    proxy_set_header Connection "";
    proxy_pass_request_body off;
}

# in the protected location block:
auth_request /internal/authelia/authz;
auth_request_set $user   $upstream_http_remote_user;
auth_request_set $groups $upstream_http_remote_groups;
auth_request_set $name   $upstream_http_remote_name;
auth_request_set $email  $upstream_http_remote_email;
proxy_set_header Remote-User   $user;
proxy_set_header Remote-Groups $groups;
proxy_set_header Remote-Name   $name;
proxy_set_header Remote-Email  $email;
auth_request_set $redirection_url $upstream_http_location;
error_page 401 =302 $redirection_url;
```

nginx needs a way to resolve the `authelia` hostname at request time since `proxy_pass` here targets
a variable rather than a static address, so the `resolver` line above (or a matching `upstream`
block) is required; Authelia's nginx integration assumes a Docker DNS resolver is available for
this, per Authelia's nginx integration guide. The `auth_request_set`/`proxy_set_header Remote-*` pairs set the app's identity headers from Authelia's response and, because nginx forwards client request headers to the upstream by default, overwrite any `Remote-User` a caller tried to send directly; without them, and without the network isolation from section 1, a client that reached the app could assert `Remote-User: admin` itself. The Traefik and Caddy examples below carry the same identity headers through `authResponseHeaders` and `copy_headers`.

Traefik and Caddy call `/api/authz/forward-auth` instead:

```yaml
- traefik.http.middlewares.authelia.forwardauth.address=http://authelia:9091/api/authz/forward-auth
- traefik.http.middlewares.authelia.forwardauth.authResponseHeaders=Remote-User,Remote-Groups,Remote-Email,Remote-Name
```

```caddyfile
forward_auth authelia:9091 {
    uri /api/authz/forward-auth
    copy_headers Remote-User Remote-Groups Remote-Email Remote-Name
}
```

Authelia needs its own random session secret and access-control rules (which paths need `one_factor` vs `two_factor`); its second factor is TOTP, WebAuthn/passkeys, or Duo mobile push.

## 4. Pomerium: the proxy is the access layer

Pomerium is an identity-aware proxy rather than a sidecar to nginx: it terminates the connection, authenticates the user, and enforces policy in one process. An IdP goes under `idp_provider`, `idp_provider_url`, `idp_client_id`, and `idp_client_secret`; each app is a route carrying its own `policy` (which users, domains, or claims may reach it), rather than a shared middleware bolted onto an existing proxy. Choose Pomerium over the two above when you want routing, TLS, and access control in one process instead of an auth check layered in front of nginx, Traefik, or Caddy.

## 5. MFA and identity source

oauth2-proxy's MFA is whatever its OIDC/OAuth provider enforces; Pomerium's is whatever its `idp_provider` enforces; only Authelia enforces a second factor itself. See [mfa.md](mfa.md) (enrolment is not enforcement) and [identity-providers.md](identity-providers.md) for which hosted providers' tiers include MFA.

## Verify

REASONED: the cited oauth2-proxy and Authelia listener defaults support this host-side inventory, which is prose rather than part of the block below, because it runs on the proxy's host and the block runs from another host. On the proxy's host, run `ss -tlnp` and read every listener: app 3000, oauth2-proxy 4180 and Authelia 9091 reachable only by the proxy (loopback, or a private container network), never a public interface. The authoring environment cannot provision the proxy, backend, IdP and external probe host, so no listing is recorded.

REASONED: following block; the cited oauth2-proxy/Authelia integrations, pinned listener defaults and curl manual define isolation, direct-header refusal and anonymous challenges. The authoring environment cannot provision the proxy, backend, IdP and external probe host; no live outcome is recorded. Expected responses and inconclusive failures are stated below. Listener isolation, anonymous challenges and direct and through-proxy identity-header checks follow the guide's cited oauth2-proxy nginx integration, oauth2-proxy Traefik integration, Traefik forwardAuth middleware and Authelia nginx integration. ShellCheck 0.11.0 and bash -n exited 0 without diagnostics on this block in an earlier form, before its anonymous-challenge curl took the app's host on a guarded `set --` line that refuses example.com, example.net, example.org and their subdomains; neither tool was re-run on that guarded form, and its guard was not run. Both YAML blocks parsed. Five rejected cases of the public-address guard printed refusal messages with no curl calls; a substituted address reached four curl stubs. The bash -n and ShellCheck runs recorded up to this point covered this fence and the stub runs its public-address block, all in an earlier form, whose guard refusals left the subshell with status 0; none was re-run on the form after that guarded form, whose guard refusals first left the subshell with status 2. The current form leaves the listener inventory to the section's first paragraph and gives the whole block one exit status. It is 1 if port 3000, 4180 or 9091 or the forged-header probe answers with an HTTP code; 3 if one of those probes ends without an HTTP code, a refusal or a timeout, or if the anonymous request fails or answers anything but a 401 or a 302 with a Location; 2 if a guard refuses, or curl is not installed, and nothing was found or failed; and otherwise 0. The anonymous request passes on a 401, or on a 302 to `/oauth2/sign_in`, with or without a query, given as a relative path or on the probed host over https. A refusal or timeout, and a 302 with any other Location, are left for you to judge: err must name YOUR address, and that Location passes only if it is your sign-in portal. Checks on 2026-10-31, with bash -n and with curl stubs and no network, covered the earlier form of the block, in which the anonymous-challenge part lowercased the host with `tr` before refusing a reserved name; they covered each status, an earlier finding or failure followed by passing later checks, and an inherited `readonly`, `declare -i` or `set -e`. The stub runs covered the refusals of a missing marker, too few or too many values, and an empty or placeholder value in each part, and in the second part of a host name with a scheme, port, trailing dot, `@`, `?`, `%`, `#` or space and of an example.com, example.net or example.org host including `App.Example.COM`; each refused part made no curl call. In those runs a 302 to `/oauth2/sign_in` on another host or over http printed an unclassified line and exited 0, and a 302 to the nginx example's `/oauth2/sign_in?rd=` target exited 0 with no such line. ShellCheck 0.11.0 passed on that form in the repository's gate suite. The current form refuses a reserved name under bash's `nocasematch` option instead of through `tr`, and its anonymous-challenge part refuses with 2, saying the block needs bash, when `shopt` fails, as it does in dash. Before its `curl` guards, it was covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by curl-stub runs on 2026-11-01 with no network. In bash, that part refused `example.com`, `EXAMPLE.NET`, `App.Example.COM`, `api.EXAMPLE.org` and seven other reserved spellings with 2 and no curl call, also with `tr` absent from PATH or failing and under an inherited `nocasematch`, `readonly`, `declare -i` or `set -e`, and a host name outside the reserved names reached its probe. Under dash, that part refused every host name with 2 and the bash message before its probe, and the whole block exited 3, because dash reads the public-address part's `$'\n'` differently and that part reported an inconclusive result. The current form adds a `command -v curl` guard to each part, which refuses that part with status 2 and no curl call when curl is not installed; none of those checks was re-run on it, and its guards were not run. No live outcome is observed: exposed access reaches a backend or trusts admin; fixed access isolates listeners, challenges anonymous users and admits a valid session under its real identity. After a real login through the proxy, confirm a session reaches the app and the app-side log shows the identity header the proxy set, not the forged one in the block. The direct forged header on the block's probe is refused at the network level, because the app is reachable only through the proxy. A header sent *through* the proxy is the separate risk: it is defeated only because the proxy overwrites the exact header the app trusts (nginx `X-User`/`X-Email`, the Traefik `authResponseHeaders`, Authelia's `Remote-*`) with its verified value. Confirm that overwrite: with a valid session, replay a request through the proxy that adds the trusted header (`-H 'X-User: admin'` for the nginx example, `-H 'X-Auth-Request-User: admin'` for the Traefik example, `-H 'Remote-User: admin'` for Authelia) and check the app-side log still shows your real identity, not `admin`. If it shows `admin`, the proxy is not overwriting that header and any authenticated user can impersonate anyone.

```bash
# Run this block from another host: app 3000, oauth2-proxy 4180 and Authelia 9091 must each be unreachable from it. Read err, not the number: it must name a refusal or timeout reaching
# YOUR address. An HTTP code means the app answered. A resolver failure, a local socket error, or a
# timeout that did not come from the remote address is inconclusive, never a pass.
(                                             # the whole block in one subshell, so one exit status covers every part of it
  set +e                                      # errexit off here, so a part that ends nonzero is folded into the status below instead of ending the block
  set -- 0                                    # the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 2 (a part refused its input or found a required tool missing), which outranks 0
  (                                             # a subshell, so your own script arguments are untouched
    set +e   # expected refusals must not skip later probes under an inherited set -e
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_PUBLIC_IP'   # replace inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
    case "$1" in
      *REPLACE_WITH_*|*YOUR_PUBLIC_IP*|"") echo "substitute your own address on the set -- line above; not probing"; exit 2 ;;
    esac
    command -v curl >/dev/null || { echo "curl is not installed here; not probing"; exit 2; }   # a missing curl refuses this part with status 2, ranked as above
    set -- "$1" 0                               # the 2nd value is this part's status so far, ranked as above
    # app 3000, oauth2-proxy 4180, Authelia 9091: each must be unreachable from another host
    set -- "$1" "$2" "$(if curl -q -g -s -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 -w 'port=3000 http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "http://$1:3000/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"   # curl's exit status, then its port= http= exit= err= line
    printf '%s\n' "$4"
    case "$3:$4" in
      7:*"http=000 "*|28:*"http=000 "*) echo "port 3000: unclassified, read err above; a refusal or timeout reaching YOUR address is the pass, and any other cause is inconclusive" ;;
      *"http=000 "*|*:) echo "port 3000: curl exit $3 with no HTTP code and no refusal or timeout; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
      *"http="*) echo "FINDING: port 3000 answered with an HTTP code, so the app is reachable from this host"; set -- "$1" 1 ;;
      *) echo "port 3000: curl exit $3 printed no http= line; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    esac
    set -- "$1" "$2" "$(if curl -q -g -s -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 -w 'port=4180 http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "http://$1:4180/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"   # curl's exit status, then its port= http= exit= err= line
    printf '%s\n' "$4"
    case "$3:$4" in
      7:*"http=000 "*|28:*"http=000 "*) echo "port 4180: unclassified, read err above; a refusal or timeout reaching YOUR address is the pass, and any other cause is inconclusive" ;;
      *"http=000 "*|*:) echo "port 4180: curl exit $3 with no HTTP code and no refusal or timeout; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
      *"http="*) echo "FINDING: port 4180 answered with an HTTP code, so oauth2-proxy is reachable from this host"; set -- "$1" 1 ;;
      *) echo "port 4180: curl exit $3 printed no http= line; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    esac
    set -- "$1" "$2" "$(if curl -q -g -s -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 -w 'port=9091 http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "http://$1:9091/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"   # curl's exit status, then its port= http= exit= err= line
    printf '%s\n' "$4"
    case "$3:$4" in
      7:*"http=000 "*|28:*"http=000 "*) echo "port 9091: unclassified, read err above; a refusal or timeout reaching YOUR address is the pass, and any other cause is inconclusive" ;;
      *"http=000 "*|*:) echo "port 9091: curl exit $3 with no HTTP code and no refusal or timeout; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
      *"http="*) echo "FINDING: port 9091 answered with an HTTP code, so Authelia is reachable from this host"; set -- "$1" 1 ;;
      *) echo "port 9091: curl exit $3 printed no http= line; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    esac
    set -- "$1" "$2" "$(if curl -q -g -s -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' -H 'X-User: admin' "http://$1:3000/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # forged header the nginx app trusts, straight at the app
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"   # curl's exit status, then its http= exit= err= line
    printf '%s\n' "$4"
    case "$3:$4" in
      7:*"http=000 "*|28:*"http=000 "*) echo "forged header: unclassified, read err above; a refusal or timeout reaching YOUR address is the pass, and any other cause is inconclusive" ;;
      *"http=000 "*|*:) echo "forged header: curl exit $3 with no HTTP code and no refusal or timeout; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
      *"http="*) echo "FINDING: the forged X-User request reached port 3000 and got an HTTP code, so network isolation does not refuse it"; set -- "$1" 1 ;;
      *) echo "forged header: curl exit $3 printed no http= line; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    esac
    exit "$2"
  )
  case "$?:$1" in 0:*) ;; 1:*) set -- 1 ;; 2:0) set -- 2 ;; 2:*|*:1) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  (                                       # a subshell, so your own script arguments are untouched
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_APP_HOST'   # the public host name your auth proxy serves the app on, no scheme, user name, port, path, query, fragment, percent sign or trailing dot: replace inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
    case "$1" in
      ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
    case "$1" in
      example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -u nocasematch   # every match below compares letter case exactly again
    command -v curl >/dev/null || { echo "curl is not installed here; not probing"; exit 2; }   # a missing curl refuses this part with status 2, ranked as above
    set -- "$1" 0                         # the 2nd value is this part's status so far: 3 (inconclusive) outranks 0
    set -- "$1" "$2" "$(if curl -q -g -sI -w '\n%{http_code} %{redirect_url}' "https://$1/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # no session: a 401, or a 302 whose Location is the sign-in page (/oauth2/sign_in or the portal); any other 302 is not a pass
    set -- "$1" "$2" "${3##*$'\n'}" "${3%$'\n'*}"         # curl's exit status, then the headers with the HTTP code and redirect target on the last line
    set -- "$1" "$2" "$3" "${4%$'\n'*}" "${4##*$'\n'}"    # curl's exit status, the headers, then the HTTP code and redirect target
    printf '%s' "$4"
    case "$3:$5" in
      "0:401 "*|"0:302 https://$1/oauth2/sign_in"|"0:302 https://$1/oauth2/sign_in?"*|"0:302 /oauth2/sign_in"|"0:302 /oauth2/sign_in?"*) ;;
      "0:302 ") echo "a 302 with no Location is not a pass; inconclusive"; set -- "$1" 3 ;;
      "0:302 "*) echo "unclassified: the 302 goes to ${5#* }, not /oauth2/sign_in; it passes only if that is your sign-in portal, and any other 302 is not a pass" ;;
      0:*) echo "HTTP ${5%% *} without a session is neither a 401 nor a 302 to the sign-in page; inconclusive"; set -- "$1" 3 ;;
      *) echo "curl exit $3: the request without a session failed; inconclusive"; set -- "$1" 3 ;;
    esac
    exit "$2"
  )
  case "$?:$1" in 0:*) ;; 1:*) set -- 1 ;; 2:0) set -- 2 ;; 2:*|*:1) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  echo "block exit $1; a refusal or timeout on ports 3000, 4180 and 9091 and on the forged-header probe, and a 302 to a location other than /oauth2/sign_in, are not classified, so read err and the Location yourself"
  exit "$1"
)
```

## Common mistakes

- The app also listens on a public interface next to the proxy, so a direct request skips authentication entirely.
- The app trusts `X-Auth-Request-User` or `Remote-User` from any caller, not only from the proxy.
- oauth2-proxy's `--cookie-secret` reused across environments or committed to the repository.
- Deploying Authelia behind Apache or IIS, which it does not support.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- oauth2-proxy configuration overview, flags, cookie-secret length and the `--trusted-proxy-ip` warning (pinned tag v7.15.6, checked November 2026): https://raw.githubusercontent.com/oauth2-proxy/oauth2-proxy/v7.15.6/docs/docs/configuration/overview.md
- oauth2-proxy nginx integration (rolling documentation, checked September 2026): https://oauth2-proxy.github.io/oauth2-proxy/configuration/integrations/nginx/
- oauth2-proxy Traefik integration (pinned tag v7.15.6, checked November 2026): https://raw.githubusercontent.com/oauth2-proxy/oauth2-proxy/v7.15.6/docs/docs/configuration/integrations/traefik.md
- oauth2-proxy nginx integration, `--trusted-proxy-ip=127.0.0.1/32` when Nginx connects from localhost (pinned tag v7.15.6, checked November 2026): https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.6/docs/docs/configuration/integrations/nginx.md#L18-L21
- oauth2-proxy v7.15.5 release notes, security advisories GHSA-wr5q-7wxw-x568, GHSA-63jm-59jj-478j and GHSA-hhqp-vx7f-5c6m with the critical fixes' notes, and 4 CVE identifiers (read for the v7.15.6 basis, checked November 2026): https://github.com/oauth2-proxy/oauth2-proxy/releases/tag/v7.15.5
- oauth2-proxy v7.15.6 release notes, 18 CVE identifiers and the changes since v7.15.5 (pinned tag v7.15.6, checked November 2026): https://github.com/oauth2-proxy/oauth2-proxy/releases/tag/v7.15.6
- Traefik forwardAuth middleware (authResponseHeaders replaces only the listed headers; others pass through): https://doc.traefik.io/traefik/reference/routing-configuration/http/middlewares/forwardauth/
- Authelia proxy integration introduction (rolling documentation, checked September 2026): https://www.authelia.com/integration/proxies/introduction/
- Authelia proxy support matrix, Apache and IIS unsupported; Caddy support minimum (rolling documentation, checked September 2026): https://www.authelia.com/integration/proxies/support/
- Authelia nginx integration (rolling documentation, checked September 2026): https://www.authelia.com/integration/proxies/nginx/
- Authelia Traefik integration (rolling documentation, checked September 2026): https://www.authelia.com/integration/proxies/traefik/
- Authelia Caddy integration (rolling documentation, checked September 2026): https://www.authelia.com/integration/proxies/caddy/
- Authelia second-factor introduction (rolling documentation, checked September 2026): https://www.authelia.com/configuration/second-factor/introduction/
- Pomerium identity provider settings: https://www.pomerium.com/docs/reference/identity-provider-settings
- Pomerium documentation: https://www.pomerium.com/docs
- oauth2-proxy `--http-address` default `127.0.0.1:4180` (pinned tag v7.15.6, checked November 2026): https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.6/pkg/apis/options/legacy_options.go#L494
- Authelia `server.address` default `tcp://:9091/` (pinned tag v4.39.28): https://github.com/authelia/authelia/blob/v4.39.28/internal/configuration/schema/server.go#L90-L92
- Authelia listens with `net.Listen(a.Network(), a.NetworkAddress())` (`types_addresses_nix.go` L37), where `NetworkAddress()` returns the URL's host and port, `:9091` for the default (`types_address.go` L480) (pinned tag v4.39.28): https://github.com/authelia/authelia/blob/v4.39.28/internal/configuration/schema/types_addresses_nix.go#L37
- Go `net.Listen` with an empty host listens on all available unicast and anycast addresses of the local system: https://pkg.go.dev/net#Listen
- curl manual (the `exitcode` and `errormsg` write-out variables, both added in curl 7.75.0): https://curl.se/docs/manpage.html
- Authelia v4.39.28 random session secret (checked October 2026): https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/session/introduction.md#L78-L82
- Authelia v4.39.28 path-matching resources (checked October 2026): https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/security/access-control.md#L102
- Authelia v4.39.28 one_factor and two_factor policies (checked October 2026): https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/security/access-control.md#L527-L537
- Pomerium route authorization policy (pinned commit 691714e2f0ae74fab47412275e8b64b68acdc0d3, checked October 2026): https://github.com/pomerium/documentation/blob/691714e2f0ae74fab47412275e8b64b68acdc0d3/content/docs/reference/routes/policy.mdx#L20
- Pomerium domain and user policy examples (pinned commit 691714e2f0ae74fab47412275e8b64b68acdc0d3, checked October 2026): https://github.com/pomerium/documentation/blob/691714e2f0ae74fab47412275e8b64b68acdc0d3/content/docs/internals/ppl.mdx#L50-L52
- Pomerium domain and group-claim policy (pinned commit 691714e2f0ae74fab47412275e8b64b68acdc0d3, checked October 2026): https://github.com/pomerium/documentation/blob/691714e2f0ae74fab47412275e8b64b68acdc0d3/content/docs/internals/ppl.mdx#L90


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- oauth: oauth2-proxy (v7.15.6)
- authelia: Authelia (v4.39.28)
- oauth-rolling: oauth2-proxy documentation (rolling) (unknown)
- authelia-rolling: Authelia documentation (rolling) (unknown)
- pomerium: Pomerium (unknown)
- pomerium-docs: Pomerium policy documentation (691714e2f0ae74fab47412275e8b64b68acdc0d3)
- traefik: Traefik (unknown)
- go: Go net.Listen (unknown)
- curl: curl minimum write-out version (7.75.0)

Claims (full source mapping in the JSON block below):

- isolate (REASONED; oauth, oauth-rolling, authelia-rolling): Bind app and auth service to loopback or an unpublished private container network; only the fronting proxy may reach them.
- oauth-bind (REASONED; oauth): oauth2-proxy --http-address defaults to 127.0.0.1:4180.
- authelia-bind (REASONED; authelia, go): Authelia server.address defaults tcp://:9091/; its empty host reaches Go net.Listen and binds every local address.
- authenticate (REASONED; pomerium, oauth-rolling, authelia-rolling): oauth2-proxy, Authelia or Pomerium must check the session before forwarding to the app.
- header-trust (REASONED; oauth, traefik, oauth-rolling, authelia-rolling): The app must trust only headers overwritten from verified proxy responses; other client headers pass through, so isolation alone is insufficient.
- oauth-provider (REASONED; oauth): OAUTH2_PROXY_ environment variables map core flags; configure provider and IdP client-id/client-secret.
- oauth-domain (REASONED; oauth): --email-domain restricts a domain; * admits any authenticated user.
- oauth-upstream (REASONED; oauth): --upstream targets the app, or static://202 when another proxy handles forwarding.
- oauth-cookie (REASONED; oauth): --cookie-secret must be 16, 24 or 32 bytes, optionally base64-encoded; generate randomly and do not reuse or commit it.
- oauth-nginx (REASONED; oauth-rolling): nginx auth_request at /oauth2/auth needs --reverse-proxy; --set-xauthrequest supplies User/Email response headers.
- oauth-nginx-identity (REASONED; oauth-rolling): nginx maps verified X-Auth-Request-User/Email to X-User/Email before forwarding to 127.0.0.1:3000.
- oauth-signin (REASONED; oauth-rolling): The nginx example forwards /oauth2/ to 127.0.0.1:4180 and redirects auth 401 to /oauth2/sign_in with the return URL.
- oauth-traefik (REASONED; oauth): Traefik forwardAuth calls oauth2-proxy:4180/oauth2/auth with static://202, reverse-proxy and set-xauthrequest enabled.
- traefik-headers (REASONED; traefik, oauth): authResponseHeaders must include every trusted identity header; only those replace client values, with other headers forwarded unchanged.
- traefik-attach (REASONED; oauth, traefik): Attach oauth-auth to every protected router; defining middleware without a router reference protects nothing.
- oauth-trusted-proxy (REASONED; oauth): With --reverse-proxy, set --trusted-proxy-ip to the fronting proxy's address, 127.0.0.1/32 for a localhost nginx; left unset, oauth2-proxy trusts all source IPs and a client reaching it directly may spoof forwarded headers.
- oauth-advisories (REASONED; oauth): The v7.15.5 notes list critical fixes GHSA-wr5q-7wxw-x568 (client-IP headers under --reverse-proxy) and GHSA-63jm-59jj-478j (skip-auth paths, X-Forwarded-Uri origin form), which earlier releases lack, by inference, and moderate GHSA-hhqp-vx7f-5c6m, whose effect is not established. Basis: v7.15.6.
- authelia-support (REASONED; authelia-rolling): Authelia supports the listed nginx, Traefik, Caddy, HAProxy/Lua, Envoy, Skipper, NGINX Proxy Manager and SWAG integrations, not Apache/IIS.
- caddy-min (REASONED; authelia-rolling): Authelia's documented Caddy support requires 2.5.1+.
- authelia-nginx (REASONED; authelia-rolling): nginx uses the dedicated /api/authz/auth-request endpoint through an internal location with original method/URL and no request body.
- authelia-dns (REASONED; authelia-rolling): Variable proxy_pass needs runtime DNS resolution or a matching upstream; the shown 127.0.0.11 resolver assumes Docker DNS.
- authelia-identity (REASONED; authelia-rolling): nginx copies verified Remote-User/Groups/Name/Email and uses the auth Location for 401 redirection; trusted client headers must be overwritten.
- authelia-traefik (REASONED; authelia-rolling): Traefik calls authelia:9091/api/authz/forward-auth and copies the four Remote-* identity headers.
- authelia-caddy (REASONED; authelia-rolling): Caddy forward_auth calls authelia:9091 with /api/authz/forward-auth and copies the four Remote-* identity headers.
- authelia-session (REASONED; authelia-rolling, authelia): Authelia needs a random session secret and path access rules selecting one_factor or two_factor.
- authelia-mfa (REASONED; authelia-rolling): Authelia enforces TOTP, WebAuthn/passkeys or Duo push itself.
- pomerium-idp (REASONED; pomerium): Pomerium combines routing, TLS and access control; configure idp_provider, idp_provider_url, idp_client_id and idp_client_secret.
- pomerium-policy (REASONED; pomerium, pomerium-docs): Each Pomerium route carries policy restricting users, domains or claims.
- idp-mfa (REASONED; oauth, pomerium): oauth2-proxy and Pomerium rely on MFA enforced by their identity provider.
- verify-listeners (REASONED; oauth, authelia): Inspect every listener: app 3000, oauth2-proxy 4180 and Authelia 9091 must be reachable only by the proxy.
- verify-direct (REASONED; curl, oauth-rolling, authelia-rolling): From another host, all three ports must refuse/time out at the actual address; HTTP proves exposure and local/resolver failures are inconclusive.
- verify-forged-direct (REASONED; curl, oauth-rolling): A forged X-User sent directly to app port 3000 must be refused by network isolation.
- verify-login (REASONED; oauth-rolling, authelia-rolling): Without a session, expect 401 or a 302 to the sign-in page; other redirects do not pass. A real session must reach the app.
- verify-overwrite (REASONED; oauth, traefik, oauth-rolling, authelia-rolling): With a valid session, replay a forged trusted identity header through each proxy; the app log must show the real identity, not admin.

````json
{
  "schema": 1,
  "checked": "2026-11-06",
  "documentation_checked": "2026-09",
  "body_sha256": "00e8961767c7787bf8311ba1318d61670007ca963403c31e7a009c9aad1b664c",
  "components": {
    "oauth": {
      "name": "oauth2-proxy",
      "basis": "v7.15.6",
      "sources": {
        "s4e4893506224": "https://raw.githubusercontent.com/oauth2-proxy/oauth2-proxy/v7.15.6/docs/docs/configuration/overview.md",
        "s259af7bc0946": "https://raw.githubusercontent.com/oauth2-proxy/oauth2-proxy/v7.15.6/docs/docs/configuration/integrations/traefik.md",
        "se3815f92bd1c": "https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.6/pkg/apis/options/legacy_options.go#L494",
        "s54abafae25c5": "https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.6/docs/docs/configuration/integrations/nginx.md#L18-L21",
        "s85b199e72a39": "https://github.com/oauth2-proxy/oauth2-proxy/releases/tag/v7.15.5",
        "s7acbcc639708": "https://github.com/oauth2-proxy/oauth2-proxy/releases/tag/v7.15.6"
      }
    },
    "authelia": {
      "name": "Authelia",
      "basis": "v4.39.28",
      "sources": {
        "s064d1e72c1e8": "https://github.com/authelia/authelia/blob/v4.39.28/internal/configuration/schema/server.go#L90-L92",
        "sbec86d37ea1c": "https://github.com/authelia/authelia/blob/v4.39.28/internal/configuration/schema/types_addresses_nix.go#L37",
        "sec3688bec026": "https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/session/introduction.md#L78-L82",
        "s91886e5dca2c": "https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/security/access-control.md#L102",
        "sf170ee48ce0d": "https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/security/access-control.md#L527-L537"
      }
    },
    "oauth-rolling": {
      "name": "oauth2-proxy documentation (rolling)",
      "basis": "unknown",
      "sources": {
        "sdcd74a9cd9c6": "https://oauth2-proxy.github.io/oauth2-proxy/configuration/integrations/nginx/"
      }
    },
    "authelia-rolling": {
      "name": "Authelia documentation (rolling)",
      "basis": "unknown",
      "sources": {
        "s0cb4f49871b5": "https://www.authelia.com/integration/proxies/introduction/",
        "s1409ac8fe3d9": "https://www.authelia.com/integration/proxies/support/",
        "s4af41b2fed9f": "https://www.authelia.com/integration/proxies/nginx/",
        "sfb8ce161d56a": "https://www.authelia.com/integration/proxies/traefik/",
        "sd5437cbc4328": "https://www.authelia.com/integration/proxies/caddy/",
        "scd46ff77c737": "https://www.authelia.com/configuration/second-factor/introduction/"
      }
    },
    "pomerium": {
      "name": "Pomerium",
      "basis": "unknown",
      "sources": {
        "s181907d16ed1": "https://www.pomerium.com/docs/reference/identity-provider-settings",
        "s4ed306cb118e": "https://www.pomerium.com/docs"
      }
    },
    "pomerium-docs": {
      "name": "Pomerium policy documentation",
      "basis": "691714e2f0ae74fab47412275e8b64b68acdc0d3",
      "sources": {
        "s18dd6f6efcc6": "https://github.com/pomerium/documentation/blob/691714e2f0ae74fab47412275e8b64b68acdc0d3/content/docs/reference/routes/policy.mdx#L20",
        "s69a7e15c61ca": "https://github.com/pomerium/documentation/blob/691714e2f0ae74fab47412275e8b64b68acdc0d3/content/docs/internals/ppl.mdx#L50-L52",
        "s84633400030e": "https://github.com/pomerium/documentation/blob/691714e2f0ae74fab47412275e8b64b68acdc0d3/content/docs/internals/ppl.mdx#L90"
      }
    },
    "traefik": {
      "name": "Traefik",
      "basis": "unknown",
      "sources": {
        "s7f6f6200de1f": "https://doc.traefik.io/traefik/reference/routing-configuration/http/middlewares/forwardauth/"
      }
    },
    "go": {
      "name": "Go net.Listen",
      "basis": "unknown",
      "sources": {
        "s37204ff1b27c": "https://pkg.go.dev/net#Listen"
      }
    },
    "curl": {
      "name": "curl minimum write-out version",
      "basis": "7.75.0",
      "sources": {
        "s2b2686afaf41": "https://curl.se/docs/manpage.html"
      }
    }
  },
  "claims": {
    "isolate": {"text": "Bind app and auth service to loopback or an unpublished private container network; only the fronting proxy may reach them.", "components": ["oauth", "oauth-rolling", "authelia-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6", "oauth:s259af7bc0946", "authelia-rolling:s0cb4f49871b5"], "status": "REASONED"},
    "oauth-bind": {"text": "oauth2-proxy --http-address defaults to 127.0.0.1:4180.", "components": ["oauth"], "sources": ["oauth:se3815f92bd1c"], "status": "REASONED"},
    "authelia-bind": {"text": "Authelia server.address defaults tcp://:9091/; its empty host reaches Go net.Listen and binds every local address.", "components": ["authelia", "go"], "sources": ["authelia:s064d1e72c1e8", "authelia:sbec86d37ea1c", "go:s37204ff1b27c"], "status": "REASONED"},
    "authenticate": {"text": "oauth2-proxy, Authelia or Pomerium must check the session before forwarding to the app.", "components": ["pomerium", "oauth-rolling", "authelia-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6", "authelia-rolling:s0cb4f49871b5", "pomerium:s4ed306cb118e"], "status": "REASONED"},
    "header-trust": {"text": "The app must trust only headers overwritten from verified proxy responses; other client headers pass through, so isolation alone is insufficient.", "components": ["oauth", "traefik", "oauth-rolling", "authelia-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6", "oauth:s259af7bc0946", "authelia-rolling:s4af41b2fed9f", "traefik:s7f6f6200de1f"], "status": "REASONED"},
    "oauth-provider": {"text": "OAUTH2_PROXY_ environment variables map core flags; configure provider and IdP client-id/client-secret.", "components": ["oauth"], "sources": ["oauth:s4e4893506224"], "status": "REASONED"},
    "oauth-domain": {"text": "--email-domain restricts a domain; * admits any authenticated user.", "components": ["oauth"], "sources": ["oauth:s4e4893506224"], "status": "REASONED"},
    "oauth-upstream": {"text": "--upstream targets the app, or static://202 when another proxy handles forwarding.", "components": ["oauth"], "sources": ["oauth:s4e4893506224", "oauth:s259af7bc0946"], "status": "REASONED"},
    "oauth-cookie": {"text": "--cookie-secret must be 16, 24 or 32 bytes, optionally base64-encoded; generate randomly and do not reuse or commit it.", "components": ["oauth"], "sources": ["oauth:s4e4893506224"], "status": "REASONED"},
    "oauth-nginx": {"text": "nginx auth_request at /oauth2/auth needs --reverse-proxy; --set-xauthrequest supplies User/Email response headers.", "components": ["oauth-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6"], "status": "REASONED"},
    "oauth-nginx-identity": {"text": "nginx maps verified X-Auth-Request-User/Email to X-User/Email before forwarding to 127.0.0.1:3000.", "components": ["oauth-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6"], "status": "REASONED"},
    "oauth-signin": {"text": "The nginx example forwards /oauth2/ to 127.0.0.1:4180 and redirects auth 401 to /oauth2/sign_in with the return URL.", "components": ["oauth-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6"], "status": "REASONED"},
    "oauth-traefik": {"text": "Traefik forwardAuth calls oauth2-proxy:4180/oauth2/auth with static://202, reverse-proxy and set-xauthrequest enabled.", "components": ["oauth"], "sources": ["oauth:s259af7bc0946", "oauth:s4e4893506224"], "status": "REASONED"},
    "traefik-headers": {"text": "authResponseHeaders must include every trusted identity header; only those replace client values, with other headers forwarded unchanged.", "components": ["traefik", "oauth"], "sources": ["traefik:s7f6f6200de1f", "oauth:s259af7bc0946"], "status": "REASONED"},
    "traefik-attach": {"text": "Attach oauth-auth to every protected router; defining middleware without a router reference protects nothing.", "components": ["oauth", "traefik"], "sources": ["oauth:s259af7bc0946", "traefik:s7f6f6200de1f"], "status": "REASONED"},
    "oauth-trusted-proxy": {"text": "With --reverse-proxy, set --trusted-proxy-ip to the fronting proxy's address, 127.0.0.1/32 for a localhost nginx; left unset, oauth2-proxy trusts all source IPs and a client reaching it directly may spoof forwarded headers.", "components": ["oauth"], "sources": ["oauth:s54abafae25c5", "oauth:s4e4893506224"], "status": "REASONED"},
    "oauth-advisories": {"text": "The v7.15.5 notes list critical fixes GHSA-wr5q-7wxw-x568 (client-IP headers under --reverse-proxy) and GHSA-63jm-59jj-478j (skip-auth paths, X-Forwarded-Uri origin form), which earlier releases lack, by inference, and moderate GHSA-hhqp-vx7f-5c6m, whose effect is not established. Basis: v7.15.6.", "components": ["oauth"], "sources": ["oauth:s85b199e72a39", "oauth:s7acbcc639708"], "status": "REASONED"},
    "authelia-support": {"text": "Authelia supports the listed nginx, Traefik, Caddy, HAProxy/Lua, Envoy, Skipper, NGINX Proxy Manager and SWAG integrations, not Apache/IIS.", "components": ["authelia-rolling"], "sources": ["authelia-rolling:s1409ac8fe3d9"], "status": "REASONED"},
    "caddy-min": {"text": "Authelia's documented Caddy support requires 2.5.1+.", "components": ["authelia-rolling"], "sources": ["authelia-rolling:s1409ac8fe3d9"], "status": "REASONED"},
    "authelia-nginx": {"text": "nginx uses the dedicated /api/authz/auth-request endpoint through an internal location with original method/URL and no request body.", "components": ["authelia-rolling"], "sources": ["authelia-rolling:s4af41b2fed9f"], "status": "REASONED"},
    "authelia-dns": {"text": "Variable proxy_pass needs runtime DNS resolution or a matching upstream; the shown 127.0.0.11 resolver assumes Docker DNS.", "components": ["authelia-rolling"], "sources": ["authelia-rolling:s4af41b2fed9f"], "status": "REASONED"},
    "authelia-identity": {"text": "nginx copies verified Remote-User/Groups/Name/Email and uses the auth Location for 401 redirection; trusted client headers must be overwritten.", "components": ["authelia-rolling"], "sources": ["authelia-rolling:s4af41b2fed9f"], "status": "REASONED"},
    "authelia-traefik": {"text": "Traefik calls authelia:9091/api/authz/forward-auth and copies the four Remote-* identity headers.", "components": ["authelia-rolling"], "sources": ["authelia-rolling:sfb8ce161d56a"], "status": "REASONED"},
    "authelia-caddy": {"text": "Caddy forward_auth calls authelia:9091 with /api/authz/forward-auth and copies the four Remote-* identity headers.", "components": ["authelia-rolling"], "sources": ["authelia-rolling:sd5437cbc4328"], "status": "REASONED"},
    "authelia-session": {"text": "Authelia needs a random session secret and path access rules selecting one_factor or two_factor.", "components": ["authelia-rolling", "authelia"], "sources": ["authelia-rolling:s0cb4f49871b5", "authelia-rolling:s4af41b2fed9f", "authelia:sec3688bec026", "authelia:s91886e5dca2c", "authelia:sf170ee48ce0d"], "status": "REASONED"},
    "authelia-mfa": {"text": "Authelia enforces TOTP, WebAuthn/passkeys or Duo push itself.", "components": ["authelia-rolling"], "sources": ["authelia-rolling:scd46ff77c737"], "status": "REASONED"},
    "pomerium-idp": {"text": "Pomerium combines routing, TLS and access control; configure idp_provider, idp_provider_url, idp_client_id and idp_client_secret.", "components": ["pomerium"], "sources": ["pomerium:s181907d16ed1", "pomerium:s4ed306cb118e"], "status": "REASONED"},
    "pomerium-policy": {"text": "Each Pomerium route carries policy restricting users, domains or claims.", "components": ["pomerium", "pomerium-docs"], "sources": ["pomerium:s4ed306cb118e", "pomerium-docs:s18dd6f6efcc6", "pomerium-docs:s69a7e15c61ca", "pomerium-docs:s84633400030e"], "status": "REASONED"},
    "idp-mfa": {"text": "oauth2-proxy and Pomerium rely on MFA enforced by their identity provider.", "components": ["oauth", "pomerium"], "sources": ["oauth:s4e4893506224", "pomerium:s181907d16ed1"], "status": "REASONED"},
    "verify-listeners": {"text": "Inspect every listener: app 3000, oauth2-proxy 4180 and Authelia 9091 must be reachable only by the proxy.", "components": ["oauth", "authelia"], "sources": ["oauth:se3815f92bd1c", "authelia:s064d1e72c1e8", "authelia:sbec86d37ea1c"], "status": "REASONED"},
    "verify-direct": {"text": "From another host, all three ports must refuse/time out at the actual address; HTTP proves exposure and local/resolver failures are inconclusive.", "components": ["curl", "oauth-rolling", "authelia-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6", "authelia-rolling:s0cb4f49871b5", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [1]},
    "verify-forged-direct": {"text": "A forged X-User sent directly to app port 3000 must be refused by network isolation.", "components": ["curl", "oauth-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [1]},
    "verify-login": {"text": "Without a session, expect 401 or a 302 to the sign-in page; other redirects do not pass. A real session must reach the app.", "components": ["oauth-rolling", "authelia-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6", "authelia-rolling:s4af41b2fed9f"], "status": "REASONED", "verify": [1]},
    "verify-overwrite": {"text": "With a valid session, replay a forged trusted identity header through each proxy; the app log must show the real identity, not admin.", "components": ["oauth", "traefik", "oauth-rolling", "authelia-rolling"], "sources": ["oauth-rolling:sdcd74a9cd9c6", "oauth:s259af7bc0946", "authelia-rolling:s4af41b2fed9f", "authelia-rolling:sfb8ce161d56a", "authelia-rolling:sd5437cbc4328", "traefik:s7f6f6200de1f"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
