# Ollama: it has no built-in authentication or TLS

Ollama runs AI language models on your own machine and serves them to other apps through a local web API. This guide helps your AI assistant configure it securely, including a private listener, login, TLS and MFA at a fronting layer, model management limited to administrators, and bounded inference load.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/ollama.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Ollama v0.40.14, Ollama (go list sweep and go.sum reading) v0.34.2, Docker Engine localhost boundary 28.0, systemd v257, Go go1.26.5, go1.26.0, go1.26.1, go1.26.2, go1.26.3, go1.26.4, go1.26.6, go1.26.7, go1.26.8, go1.26.9, and go1.26.10, and github.com/dgryski/trifles v0.0.0-20200323201526-dd97f9abfb48, plus 3 more recorded bases; 7 further sources carry no recorded version. Metadata reviewed 2026-11-06; documentation checked September 2026. The guide records 79 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Ollama's local HTTP API has **no native inbound authentication and no TLS**. A reachable listener gives callers inference and management capabilities, including model acquisition, replacement, export, and deletion. Model metadata may disclose templates and, by this guide's source reading (section 9), system prompts. Cloud credentials can also authorize upstream use. These capabilities do not establish arbitrary access to every host file. The security boundary for remote access is an authenticating proxy or tunnel, with a policy that separates inference from administration. See the [authentication reference](https://docs.ollama.com/api/authentication) and [server implementation](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go).

This guide's baseline is **Ollama v0.40.14**, published on 3 November 2026 and identified as the newest release on 4 November 2026, at commit **`9a3e8177767245acc62b735eba7d5d8a553606d0`**. The GitHub release records fetched for this guide on 5 November 2026 list no later release other than the v0.40.15-rc1 prerelease. The guide earlier rested on v0.34.2; the `go list` sweeps and dependency reading in section 9 were made at v0.34.2 and say so. Review subsequent releases before changing the deployment pin. See the [release](https://github.com/ollama/ollama/releases/tag/v0.40.14) and [release commit](https://github.com/ollama/ollama/commit/9a3e8177767245acc62b735eba7d5d8a553606d0).

The standalone binary defaults to `127.0.0.1:11434`. The official Docker image instead sets `OLLAMA_HOST=0.0.0.0:11434` inside the container. Under ordinary bridge networking, a bare `-p 11434:11434` publishes that unauthenticated API on every host interface by default. Container binding and host publication are different controls. See the [pinned FAQ](https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx), [Dockerfile](https://github.com/ollama/ollama/blob/v0.40.14/Dockerfile), and [Docker publication reference](https://docs.docker.com/engine/network/port-publishing/).

Rules:

1. Leave the host listener on loopback unless a restricted private path is required.
2. Never expose an unprotected wildcard host listener. Free compute, model tampering, model export, disclosed metadata, and unintended upstream use are meaningful exposure.
3. Publish only an authenticated TLS boundary. Restrict inference identities to the exact inference operations they need.

The numbered settings build one deployment. Merge the selected systemd settings into one drop-in and choose one fronting authentication arrangement. The proxy alternatives are replacements, not additional public paths.

## 1. Make the private listener explicit

**Tier-1 rationale:** an independently reachable backend bypasses every authentication and transport control at the proxy.

For a host-installed systemd service, use `systemctl edit ollama.service`:

```ini
[Service]
Environment="OLLAMA_HOST=127.0.0.1:11434"
```

After assembling the settings below, run `systemctl daemon-reload` and `systemctl restart ollama.service` with the required administrative privileges. Setting the variable in an interactive shell does not change an already running systemd service. See the [Linux environment instructions](https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx).

For the official image under bridge networking, retain its internal wildcard listener and use this publication with a host-run proxy:

```text
-p 127.0.0.1:11434:11434
```

Use Docker Engine **28.0 or later** for this localhost-publication boundary. Before 28.0, other hosts on the same layer-2 segment can reach localhost-published ports; upgrade or leave the port unpublished. Alternatively, omit publication and attach the proxy to a restricted container network. Address Ollama by its container name there: a proxy container's own `127.0.0.1` does not reach Ollama. See [Docker port publishing](https://docs.docker.com/engine/network/port-publishing/).

With `--network host`, Docker ignores `-p`; there is no publication address to constrain. Override the image's `OLLAMA_HOST` with loopback or the deliberately selected private interface, and restrict that private interface to authorized peers.

Loopback permits local callers. An unpublished container remains reachable by permitted network peers. Inspect IPv4, IPv6, every publication, and additional network attachments. A missing `ss` listener does not establish that Docker NAT publication is absent.

**Exposed/fixed comparison, REASONED:** no deployed Ollama host or external observer is available here. An outside observer can obtain an HTTP response from the exposed backend on 11434; after the fix, that direct path is unreachable while the approved proxy path completes inference.

## 2. Put authentication, TLS, and MFA at the fronting layer

**Tier-1 rationale:** every accepted remote request needs an authenticated caller and protected transport.

The local API does not require authentication. Ollama cloud API keys and signing in concern upstream services; they do not protect the local listener. Despite its name, **`OLLAMA_AUTH` is a client-side outbound-signing setting, not an inbound server-authentication switch**. See the [authentication reference](https://docs.ollama.com/api/authentication) and [pinned client implementation](https://github.com/ollama/ollama/blob/v0.40.14/api/client.go).

Ollama serves plaintext HTTP. An `https://` prefix in `OLLAMA_HOST` does not install certificates or enable server TLS. See [server startup](https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go) and [HTTP serving](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go).

### Option A: reverse proxy with TLS and Basic authentication

Keep Ollama on loopback and publish only the proxy. This nginx fragment belongs inside the existing `http` context; see [nginx.md](nginx.md) for the surrounding configuration. It includes C3's inference-only policy and C6's example admission budgets:

```nginx
# http context: define each zone once.
limit_req_zone $binary_remote_addr zone=ollama_rate:10m rate=2r/s;
limit_conn_zone $server_name zone=ollama_active:10m;

server {
    listen 443 ssl;
    server_name ollama.example.com;

    ssl_certificate     /etc/letsencrypt/live/ollama.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/ollama.example.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;

    auth_basic           "Ollama";
    auth_basic_user_file /etc/nginx/.htpasswd;

    location = /api/chat {
        if ($request_method != POST) { return 405; }

        client_max_body_size 1m;
        limit_req zone=ollama_rate burst=4 nodelay;
        limit_req_status 429;
        limit_conn ollama_active 4;
        limit_conn_status 429;

        proxy_pass http://127.0.0.1:11434;
        proxy_set_header Host localhost:11434;
        proxy_read_timeout 300s;
    }

    location / {
        return 404;
    }
}
```

Substitute the hostname and certificate paths. Generate password entries with `htpasswd -B -C 12`, using its interactive password prompt and the intended password-file path and username. The prompt keeps the password out of the command text, shell history and shell tracing; the account owner and root can still read it in the `htpasswd` process while it runs. Bare `-B` defaults to bcrypt cost 5, below OWASP's minimum of 10; regenerate existing cost-5 hashes. Protect the password file and its backups. See [nginx Basic authentication](https://nginx.org/en/docs/http/ngx_http_auth_basic_module.html), [htpasswd](https://httpd.apache.org/docs/2.4/programs/htpasswd.html), and [OWASP password storage](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html).

Authentication is at `server` scope so every permitted location inherits it. Do not disable it in an added inference location. A denied path or method can return 404 or 405 before authentication; those responses do not imply access to Ollama.

Retain `proxy_set_header Host localhost:11434;` in every proxied location. The relevant loopback-bound host middleware can reject a public hostname with 403. This rewrite makes that middleware accept the proxy's backend request; **it is not authentication**. See the [pinned host middleware](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go).

`proxy_read_timeout 300s` permits slow model responses but limits the interval between upstream reads. It is not a five-minute generation deadline: continuous streaming can outlast it. Enforce any total execution deadline in the application or gateway and propagate cancellation. See the [timeout reference](https://nginx.org/en/docs/http/ngx_http_proxy_module.html#proxy_read_timeout).

TLS termination protects the client-to-proxy leg. If the proxy and Ollama are on different hosts, protect the backend transport with a tunnel or another verified encrypted transport. See [nginx TLS configuration](https://nginx.org/en/docs/http/ngx_http_ssl_module.html).

### Caddy alternative

The corresponding authentication and path policy in [caddy.md](caddy.md) is:

```caddyfile
ollama.example.com {
    @chat {
        path /api/chat
        method POST
    }

    handle @chat {
        basic_auth {
            admin $2a$14$REPLACE_WITH_HASH_FROM_caddy_hash-password
        }
        reverse_proxy 127.0.0.1:11434 {
            header_up Host localhost:11434
        }
    }

    handle {
        respond 404
    }
}
```

Generate the hash with `caddy hash-password`. Run it without `--plaintext`, which would put the password in its arguments, and enter the password at its prompt. The prompt keeps the password out of the command text, shell history and shell tracing; the account owner and root can still read it in the `caddy` process while it runs. The exact matcher and fallback keep other paths private. Stock Caddy has no built-in rate-limiting directive; provide the admission and resource controls in C6 through a suitable fronting layer before publishing this alternative. See [Basic authentication](https://caddyserver.com/docs/caddyfile/directives/basic_auth), [request matchers](https://caddyserver.com/docs/caddyfile/matchers), [exclusive handles](https://caddyserver.com/docs/caddyfile/directives/handle), and [reverse proxy configuration](https://caddyserver.com/docs/caddyfile/directives/reverse_proxy).

### Bearer-only clients

For clients that only send bearer tokens, replace the Basic-auth directives and the two locations in the nginx TLS server with the following. Retain its certificates, protocols, and the `http`-context zones:

```nginx
auth_basic off;

location = /api/chat {
    if ($http_authorization != "Bearer REPLACE_WITH_LONG_RANDOM_TOKEN") { return 401; }
    if ($request_method != POST) { return 405; }

    client_max_body_size 1m;
    limit_req zone=ollama_rate burst=4 nodelay;
    limit_req_status 429;
    limit_conn ollama_active 4;
    limit_conn_status 429;

    proxy_pass http://127.0.0.1:11434;
    proxy_set_header Host localhost:11434;
    proxy_read_timeout 300s;
}

location / {
    return 404;
}
```

Generate the token per [authentication.md](authentication.md) and keep it out of the repository. The exact comparison followed by `return 401` is valid nginx syntax, but it is a **shared static credential stored in configuration, with no constant-time verification guarantee**. Protect configuration dumps, backups, and deployment output. Prefer Basic authentication or an Access service token where suitable. See the [nginx rewrite module](https://nginx.org/en/docs/http/ngx_http_rewrite_module.html).

Apply this authentication check to **every** permitted location added later. Do not retain the former catch-all proxy alongside the allowlist. A token-checking catch-all authenticates management operations too, granting token holders more authority than inference requires.

### Mutual TLS for machine clients

An alternative authentication choice inside the existing TLS server is:

```nginx
ssl_client_certificate /etc/nginx/ollama-client-ca.pem;
ssl_verify_client on;
```

Use a dedicated client CA and define certificate issuance, expiry, and revocation procedures. Remove the Basic-auth requirement if choosing mTLS alone. Combining Basic authentication and mTLS is valid when deliberate; copying fragments must not make both accidental requirements. Retain the inference allowlist and admission controls. See [nginx client-certificate verification](https://nginx.org/en/docs/http/ngx_http_ssl_module.html#ssl_verify_client).

### Option B: Cloudflare Tunnel with Access

Follow [cloudflare.md](cloudflare.md) and add an Access policy, or a service-token policy for API clients, on the published hostname. The [Ollama FAQ](https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx) documents tunnelling to `http://localhost:11434`; adding Access authenticates that route, but a direct tunnel to Ollama still gives valid callers its management surface.

For the inference-only deployment, point the tunnel at the local policy proxy instead. Adapt the nginx server above to `listen 127.0.0.1:11435;`, remove its TLS directives, and remove its Basic-auth directives when Access is the selected authentication boundary. Retain the exact locations, limits, and upstream Host rewrite. Route the tunnel to `http://127.0.0.1:11435`. Keep both local listeners unreachable from untrusted peers. On a Mac running the Ollama desktop app, its Claude Desktop gateway, when on, also uses `127.0.0.1:11435` (section 9): this guide's inference, not observed, is that the gateway and this proxy would both try to bind that port.

Retain the tunnel route's HTTP Host Header setting of `localhost:11434`, named `originRequest.httpHostHeader` in a config-file tunnel. The final proxy hop also sets that Host header before reaching Ollama. See [origin parameters](https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/configure-tunnels/origin-parameters/) and [Access service tokens](https://developers.cloudflare.com/cloudflare-one/access-controls/service-credentials/service-tokens/).

Access authentication does not itself supply the inference rate, concurrency, or resource budgets. Retain C6's controls; [Cloudflare WAF rate-limiting rules](https://developers.cloudflare.com/waf/rate-limiting-rules/) can provide an additional rate boundary. Configure trusted client-address handling if rate accounting must distinguish callers behind the connector.

MFA: Ollama has no local login, so a second factor comes from the fronting layer: an Access policy backed by an MFA-enforcing identity provider, or an [Authelia](https://www.authelia.com/)-protected proxy. See [mfa.md](mfa.md). Machine service tokens are not a human MFA flow.

**Exposed/fixed comparison, REASONED:** no live proxy, credentials, certificates, or Access deployment is available here. An unprotected listener accepts anonymous inference or exposes credentials over plaintext; the fixed remote path rejects missing or invalid credentials and uses verified TLS for accepted requests.

## 3. Reserve management for administrators

**Tier-1 rationale:** an inference credential must not authorize model replacement, deletion, uploads, or server-initiated transfers.

The C2 server permits only native chat. Its essential routing policy is:

```nginx
# Inside the existing authenticated TLS server.
# Retain C6's admission directives in this permitted location.
location = /api/chat {
    if ($request_method != POST) { return 405; }

    proxy_pass http://127.0.0.1:11434;
    proxy_set_header Host localhost:11434;
    proxy_read_timeout 300s;
}

location / {
    return 404;
}
```

This illustrates the routing component already assembled in C2; do not add duplicate locations. For bearer authentication, retain the token check from C2 inside each permitted location.

Add separately reviewed exact locations only when the application requires them, for example `/api/generate` or `/v1/chat/completions`. Repeat method restrictions, authentication, admission limits, and upstream settings. Allowing `/api/` or `/v1/` wholesale defeats this policy. See nginx [location selection](https://nginx.org/en/docs/http/ngx_http_core_module.html#location) and [return directives](https://nginx.org/en/docs/http/ngx_http_rewrite_module.html).

**A public `/api/tags` may intentionally return 404 even with valid credentials.** Use an allowed inference operation to verify public authentication, and the private administrative path to inspect model inventory.

Keep these operations private:

| API | Authority to keep private |
|---|---|
| `POST /api/pull` | Fetch models and consume local storage and network capacity. |
| `POST /api/push` | Upload model material; upstream registry authorization is separate. |
| `POST /api/create` | Create or replace model definitions and process uploaded model files. |
| `POST /api/copy` | Create another model name. |
| `DELETE /api/delete` | Remove models and associated data. |
| `POST /api/blobs/:digest` | Upload bytes into the model store. |
| `HEAD /api/blobs/:digest` | Discover whether a particular blob exists. |

Methods and blob semantics come from the [pinned API reference](https://github.com/ollama/ollama/blob/v0.40.14/docs/api.md). Administrators can use the loopback endpoint from a restricted host session, or a separately authenticated and network-restricted administrative path. An inference credential must not grant access to that path.

Also exclude account operations, experimental operations, diagnostics, and unused compatibility routes. At v0.40.14 the server [registers](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2385-L2450) `/api/me`, `GET /api/balance`, `GET /api/usage`, `/api/signout`, `/api/user/keys/:encodedKey`, `/api/experimental/web_search`, `/api/experimental/web_fetch`, `GET /api/experimental/model-recommendations`, and a desktop proxy route under `/api/codex`, behind only the router's CORS and host middleware. It also registers `POST /v1/systemone`, and `POST /v1/audio/translations` and `POST /v1/audio/speech` beside `POST /v1/audio/transcriptions`. Default denial avoids maintaining an exhaustive blacklist. See [route registration](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go).

The balance and usage routes [act as the account signed into the server, whoever calls them](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2684-L2696): each handler carries the comment `// Use the account signed into this server, regardless of caller credentials.`, runs `c.Request.Header.Del("Authorization")` and passes the request to the cloud proxy. [That proxy](https://github.com/ollama/ollama/blob/v0.40.14/server/cloud_proxy.go#L176-L226) answers `403` when the server's cloud status reads as disabled; otherwise it sends the caller's path and query to [`https://ollama.com:443` by default](https://github.com/ollama/ollama/blob/v0.40.14/server/cloud_proxy.go#L28-L31), after [signing the request with `auth.Sign` and setting that signature as `Authorization`](https://github.com/ollama/ollama/blob/v0.40.14/server/cloud_proxy.go#L408-L422) when the target host is the signing host, `ollama.com` by default. This guide's inference, not observed: any caller that passes the Host and CORS checks can read the signed-in account's balance and usage, signed with the server's own key. Whether `OLLAMA_NO_CLOUD` sets the cloud status that check reads is not established, because `internal/cloud`, which defines it, was not read.

Current create requests map filenames to uploaded blob digests. The implementation validates relative filenames and digest paths. Historical arbitrary host-file read/write reports must not be presented as documented v0.40.14 functionality. See [create validation](https://github.com/ollama/ollama/blob/v0.40.14/server/create.go) and [blob-path validation](https://github.com/ollama/ollama/blob/v0.40.14/manifest/paths.go).

Pull, push, and creation still provide server-side transfer and storage authority: an **SSRF-relevant egress and disk-fill surface**. At v0.40.14 the registry request helper's [default redirect policy](https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1753-L1822) is not strictly same-host. It first refuses any redirect after the 10th with `errMaxRedirectsExceeded`. Within that limit, it accepts a redirect to the same host, or between two hosts that each equal, or are a subdomain of, an entry in `allowedRedirectHosts = []string{"ollama.com", "ollama.ai", "hf.co", "huggingface.co"}`, and otherwise returns `errBlockedRedirect`. With `insecure`, it skips that host check and accepts a redirect to any host within the same 10-redirect limit, and the helper also switches the scheme of the URL it is given to `http`, but not the scheme of a redirect it follows (section 7). That default applies only when the caller sets no redirect check of its own. A pull's blob download [sets its own](https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L336-L349) only on [the GET request that finds the blob's direct URL](https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L219-L331), with `newOpts.CheckRedirect = downloadDiscoveryRedirect(requestURL)`. Within the same 10-redirect limit, after a `transfer.ValidateRedirectScheme` check, that GET follows only redirects to the same scheme, host and port. When no `-partial-*` part files exist yet, the HEAD size request that [`Prepare` in `server/download.go`](https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L131-L186) sends first, `makeRequestWithRetry(ctx, http.MethodHead, requestURL, nil, nil, opts)` at line 151, carries the caller's options, on which `server/` sets no `CheckRedirect`, so the default policy above governs it. The downloader then [passes any other redirect target to `transfer.ValidateRedirectTarget`](https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L219-L331). The `transfer` package was not read, so where a pulled blob's download may be redirected is not established. This is not evidence of an unrestricted, demonstrated SSRF vulnerability. Blocking public management also prevents inference callers from selecting insecure transfers. See [transfer implementation](https://github.com/ollama/ollama/blob/v0.40.14/server/images.go).

A path allowlist does not constrain model names or generation parameters inside allowed requests. C6 and C7 address those boundaries.

**Exposed/fixed comparison, REASONED:** no live Ollama, proxy, or disposable model fixtures are available here. A valid credential on the former catch-all proxy can create a model alias; the inference-only boundary refuses that operation without forwarding it, while a private administrator can complete it.

## 4. Limit additional browser origins

**Tier-1 rationale:** a browser on a trusted machine must not grant arbitrary websites access to its reachable inference service.

If an explicitly required browser frontend needs an additional origin, add:

```ini
[Service]
Environment="OLLAMA_ORIGINS=https://chat.example.com"
```

Otherwise, leave additional origins unset and remove inherited wildcard assignments. Avoid `*` and blanket extension-origin patterns. The desktop app's Browser setting is one such assignment: when it is on, the app [sets `OLLAMA_ORIGINS` to `*`](https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L241-L255) for the `ollama serve` process it runs (section 9), so leave it off unless a browser frontend requires it.

**`OLLAMA_ORIGINS` adds to built-in origins; it does not replace them.** The pin retains localhost, loopback, wildcard-port origins, and application/file/webview schemes. Neither an empty value nor one explicit origin creates an exclusive one-origin policy. See [pinned `AllowedOrigins`](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go).

CORS is not caller authentication and does not constrain a non-browser client. An exclusive browser policy belongs at the frontend boundary. Cross-origin authentication also needs a deliberate preflight policy. C2's POST-only example is intended for non-browser clients or a same-origin backend arrangement; it rejects browser preflight OPTIONS requests.

**Exposed/fixed comparison, REASONED:** no live endpoint or browser frontend is available here. A wildcard additional-origin configuration permits an unwanted website's browser requests; removing that wildcard refuses unnecessary additional origins while an intended browser flow still works. Built-in origins remain exceptions to test, not evidence of an exclusive policy.

## 5. Use a dedicated account and protect the model store

**Tier-1 rationale:** model-store writes and a compromised inference process must not inherit root privileges or unrelated application secrets.

For the vendor-style Linux service:

```ini
[Service]
User=ollama
Group=ollama
UMask=0077
Environment="OLLAMA_MODELS=/var/lib/ollama/models"
```

Ensure the account exists and pre-provision the store. For new directories, an administrator can use `install -d -o ollama -g ollama -m 0700 /var/lib/ollama /var/lib/ollama/models`. Plan migration separately if models already exist elsewhere.

| Object | Proposed ownership and mode |
|---|---|
| `/var/lib/ollama` and model-store directories | `ollama:ollama`, `0700` |
| Model-store regular files | `ollama:ollama`; in the v0.40.14 code read (below), Ollama sets `0644` with `chmod` on the blobs `manifest/layer.go` writes and on manifests, while `server/download.go` writes pulled blobs with no `chmod`, so the `0700` directories carry the restriction |
| Service unit and administrative configuration | Root-owned and not writable by `ollama` |
| Proxy credentials and TLS private keys | Accessible to the required proxy identity, not Ollama |

The account and writable-store requirements follow the [Linux instructions](https://github.com/ollama/ollama/blob/v0.40.14/docs/linux.mdx) and [installer](https://github.com/ollama/ollama/blob/v0.40.14/scripts/install.sh). The restrictive modes are deployment policy; `UMask` is a systemd setting, not an Ollama option. See the [systemd execution reference](https://github.com/systemd/systemd/blob/v257/man/systemd.exec.xml).

At v0.40.14, Ollama sets the mode of some of the store files it writes. In `manifest/layer.go` it runs `os.Chmod(blob, 0o644)` on each new blob, both when [it writes the blob from a stream](https://github.com/ollama/ollama/blob/v0.40.14/manifest/layer.go#L68-L77) and when [it moves a file into the store](https://github.com/ollama/ollama/blob/v0.40.14/manifest/layer.go#L112-L121). It runs `os.Chmod(tempName, 0o644)` before renaming into place [each legacy-path manifest](https://github.com/ollama/ollama/blob/v0.40.14/manifest/manifest.go#L1219-L1245), [each manifest it stores as a new blob](https://github.com/ollama/ollama/blob/v0.40.14/manifest/manifest.go#L1287-L1329) and [each copied manifest](https://github.com/ollama/ollama/blob/v0.40.14/manifest/manifest.go#L1331-L1357). It creates [each manifest root](https://github.com/ollama/ollama/blob/v0.40.14/manifest/paths.go#L51-L58) with `os.MkdirAll(path, 0o755)` and [the blob directory](https://github.com/ollama/ollama/blob/v0.40.14/manifest/paths.go#L400-L420) with `os.MkdirAll(dirPath, 0o755)`. A pull writes its blobs another way. For a model without tensor layers, [the pull](https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1261-L1293) calls [`downloadBlob`, which downloads each blob to its store path](https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L509-L551). [The downloader](https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L219-L331) opens that path plus `-partial` with `os.OpenFile(b.Name+"-partial", os.O_CREATE|os.O_RDWR, 0o644)` and renames it into place, and `server/download.go` calls no `chmod`. A model with tensor layers is pulled through `pullWithTransfer` and the `transfer` package instead, which was not read, so the mode of those pulled blobs is not established. This guide's inference from POSIX semantics, not observed: the process umask masks the modes Ollama creates directories and files with, so `UMask=0077` makes those directories `0700` and a `-partial` file the downloader creates `0600`, but it does not mask `chmod`, so the files set with `chmod` above end at `0644`, not `0600`. By the same inference, a store can then hold both `0600` pulled blobs and `0644` files, so a check that expects a single mode for every file after a pull or create can fail. The `0700` store directories are then what keep other local accounts from the `0644` files, provided no ACL grants them traversal. Whether v0.34.2 already set these modes is not established, because its `manifest/layer.go` was not read.

`UMask` does not repair existing permissions or ACLs. Inspect existing directories, files, parent-directory access, and backups. Preserve required GPU device-group access. `OLLAMA_MODELS` relocates models, not the entire service home or its signing keys. Do not assume the official container inherits the installer's service-user arrangement.

At v0.40.14 the installer's `configure_systemd` function runs `$SUDO useradd -r -s /bin/false -U -m -d /usr/share/ollama ollama` only under `if ! id ollama >/dev/null 2>&1`, that is, when no `ollama` account exists, and then, with no condition, prints "Adding current user to ollama group..." and runs `$SUDO usermod -a -G ollama $(whoami)` ([`scripts/install.sh` lines 197 to 212](https://github.com/ollama/ollama/blob/v0.40.14/scripts/install.sh#L197-L212)). The [Linux instructions](https://github.com/ollama/ollama/blob/v0.40.14/docs/linux.mdx) give the same `useradd` and `sudo usermod -a -G ollama $(whoami)` commands for a manual install, and neither file says what that membership is for. In the script, `$(whoami)` is expanded by the shell running the script, not under `$SUDO`, so it names the account that ran the script, which is root when the script itself runs as root.

This guide's inference from POSIX permissions, not observed: the proposed `0700` store directories grant their group nothing, so that membership gives the invoking user no access to the store, and anything that relied on it, such as reading model files or manifests as that user, stops working once the directories are `0700`. On such a setup, this guide suggests doing that work as the `ollama` account or through the loopback API, and removing the invoking user from the `ollama` group if nothing else needs it. That removal does not last through an update: the [installer](https://github.com/ollama/ollama/blob/v0.40.14/scripts/install.sh) calls `configure_systemd` on every run where `systemctl` is available (lines 250 and 251), and the [Linux instructions](https://github.com/ollama/ollama/blob/v0.40.14/docs/linux.mdx) say "Update Ollama by running the install script again". Each update through the script therefore adds the account that runs it to the `ollama` group again, so recheck that group's members after every update. If group access is a requirement, a deliberate alternative is `0750` store directories with `UMask=0027`, because by the same inference `UMask=0077` makes the directories Ollama creates `0700`. Every `ollama` group member can then read the store's `0644` and `0640` files, so keep that group to accounts trusted with the models.

**Exposed/fixed comparison, REASONED:** no running service, model store, or test identities are available here. Root execution or a broadly writable store permits wider damage or model replacement; the fixed service uses its dedicated identity, required model operations succeed, and an unrelated identity cannot modify the store.

## 6. Bound inference pressure and distinguish limits from defaults

**Tier-1 rationale:** anonymous traffic and compromised authenticated clients must encounter finite admission and resource budgets.

These are illustrative settings to size against the selected models and hardware:

```ini
[Service]
Environment="OLLAMA_MAX_LOADED_MODELS=1"
Environment="OLLAMA_NUM_PARALLEL=1"
Environment="OLLAMA_MAX_QUEUE=16"
Environment="OLLAMA_KEEP_ALIVE=1m"
Environment="OLLAMA_CONTEXT_LENGTH=4096"
```

At v0.40.14, parallelism defaults to **1**, queue capacity to **512**, and keep-alive to **5 minutes**. Loaded-model capacity is selected automatically when not explicitly configured. See the [environment configuration](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go) and [scheduler](https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go).

Context defaults are **VRAM-dependent: 4K, 32K, or 256K**. The dedicated context document describes 4K below 24 GiB, 32K for the intermediate VRAM band, and 256K at 48 GiB or more; the implementation selects these tiers slightly lower, at roughly 23 GiB and 47 GiB of summed detected VRAM after the configured GPU overhead, so treat the documented figures as nominal. See the [pinned context reference](https://github.com/ollama/ollama/blob/v0.40.14/docs/context-length.mdx) and [server startup](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go).

The v0.40.14 documentation gives 3 different `num_ctx` defaults for local models. The context document gives the VRAM tiers above and adds "Cloud models are set to their maximum context length by default." The [pinned FAQ](https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx) says "By default, Ollama uses a context window size of 4096 tokens.", and the [Modelfile parameter table](https://github.com/ollama/ollama/blob/v0.40.14/docs/modelfile.mdx) describes `num_ctx` with "(Default: 2048)".

In the v0.40.14 code, [`api.DefaultOptions`](https://github.com/ollama/ollama/blob/v0.40.14/api/types.go#L1237-L1246) takes `NumCtx` from `OLLAMA_CONTEXT_LENGTH`, which [defaults to `0`](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L229-L230). [The server's option builder](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L139-L173) replaces a `0` with [the VRAM-tier default set at startup](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2571-L2586), `4096`, `32768` or `262144`. It then applies the model's generation defaults, the model's parameters and the request's options, in that order, so a Modelfile `num_ctx` or a request's `options.num_ctx` overrides either default. In the files read for this, `api/types.go`, `envconfig/config.go`, `server/routes.go` and `server/sched.go`, the only `2048` applied to `num_ctx` is a floor: [the scheduler](https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L212-L220) raises `num_ctx` to at least 4 for every model and, with `opts.NumCtx = max(opts.NumCtx, 2048)`, to at least 2048 for a model with vision capability or projector files.

In the code read, the scheduler also lowers `num_ctx`, or the value it plans a load with. Where `num_ctx` exceeds a model's nonzero training context, [`effectiveContext`](https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L192-L210) returns the training context, which the scheduler uses to predict a load's memory (line 578) and to compare a request with a loaded runner (line 1440). After loading a model file, [it sets `num_ctx` to the nonzero context length the runner reports](https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L735-L740); how the runner sets that length is in code not read. When `llm.IsOutOfMemory` reports a load failure as out of memory, [the scheduler retries the load once](https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L694-L708) with a lower context, but only when `num_ctx` came from the automatic default. [The server counts it as automatic](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L202-L212) only when neither the request's options nor the model's parameters set `num_ctx` and `OLLAMA_CONTEXT_LENGTH` reads as `0`. For that retry, [`reduceAutoNumCtxForLoadOOM`](https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L811-L837) first caps the value at the training context, and [`nextLowerAutoNumCtx`](https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L953-L961) then gives 32768 for a value above 32768 or 4096 for a value above 4096; at 4096 or below there is no such retry. For a model it runs through MLX, the scheduler instead passes `num_ctx` to [`mlxrunner.NewClient(modelName, req.opts.NumCtx)`](https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L631-L634), whose package was not read, so the context those models load with is not established.

This guide therefore reads the FAQ's flat 4096 and the Modelfile table's 2048 as disagreeing with the v0.40.14 code read. When `OLLAMA_CONTEXT_LENGTH` is unset, `0` or not a valid unsigned integer, which [its parser](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L261-L272) reads as `0`, and no model or request `num_ctx` applies, that code selects 4096 at startup only below the 23 GiB tier. It can also step an automatic default down to 32768 or 4096 after an out-of-memory load, and it uses 2048 only as that floor. This example sets 4096 explicitly.

C2 already includes these nginx admission controls. Define the zones once in `http`:

```nginx
limit_req_zone $binary_remote_addr zone=ollama_rate:10m rate=2r/s;
limit_conn_zone $server_name zone=ollama_active:10m;
```

Retain these directives in each permitted inference location:

```nginx
client_max_body_size 1m;
limit_req zone=ollama_rate burst=4 nodelay;
limit_req_status 429;
limit_conn ollama_active 4;
limit_conn_status 429;
```

These are example budgets, not universal recommendations. The first zone accounts by source address; the second shares an active-request budget for this server name. Configure trusted client-address handling when another proxy is in front. The connection limiter does not cap every idle or incomplete connection. See [request limiting](https://nginx.org/en/docs/http/ngx_http_limit_req_module.html), [connection limiting](https://nginx.org/en/docs/http/ngx_http_limit_conn_module.html), and [body-size limits](https://nginx.org/en/docs/http/ngx_http_core_module.html#client_max_body_size).

Context length and keep-alive are **defaults, not mandatory ceilings**. Request parameters can override them, and model defaults also matter. A trusted application or gateway must validate permitted models, `options.num_ctx`, output limits such as `options.num_predict`, and `keep_alive` when untrusted callers receive inference access. A deployment policy might allow one approved model, context at most 4096, at most 128 generated tokens, and keep-alive at most one minute; the nginx path policy does not implement those JSON validations. See [override semantics](https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx) and [request types](https://github.com/ollama/ollama/blob/v0.40.14/api/types.go).

Ollama scheduling limits are not total RAM, VRAM, disk, or HTTP-connection caps. Apply host/container budgets appropriate to the deployment. Use a finite application deadline where required; the nginx idle-read timeout alone is insufficient.

Per [authentication.md](authentication.md) rule 9, authenticated but unthrottled inference remains a denial-of-wallet risk. Apply the same admission controls to the Caddy and Access alternatives.

**Exposed/fixed comparison, REASONED:** no inference runtime, model workload, or GPU is available here. Excess requests enter larger queues or consume more concurrent work in the exposed configuration; explicit admission limits reject excess, accepted requests complete, and normal service recovers. GPU-specific capacity claims require GPU hardware; HTTP admission checks do not.

## 7. Control model provenance and registry transfers

**Tier-1 rationale:** API access must not become permission to install or export arbitrary model material.

Make acquisition an administrative provisioning step. For an illustrative controlled registry, this is a private `POST /api/pull` request body:

```json
{
  "model": "registry.example.com/team/app:release-2026-09",
  "insecure": false,
  "stream": false
}
```

Substitute the approved registry and release before sending it through the private administrative path. Fully qualified registry/namespace/model/tag names are supported. Unqualified names default to Ollama's registry, and an omitted tag defaults to `latest`. See [pinned name parsing](https://github.com/ollama/ollama/blob/v0.40.14/types/model/name.go).

At v0.40.14, `api/types.go` [declares the `PullRequest` field `Insecure`](https://github.com/ollama/ollama/blob/v0.40.14/api/types.go#L856-L867) with the comment `// Deprecated: ignored`, but the handler code does not ignore it. [The pull handler](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1530-L1532) builds `regOpts := &registryOptions{` with `Insecure: req.Insecure,`, and [the push handler](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1584-L1586) does the same from `PushRequest`, whose field carries no such comment. Without it, [pull](https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1213-L1215) and [push](https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1047-L1053) refuse a model name whose protocol scheme is `http` with `errInsecureProtocol`. With it, [the registry request helper](https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1753-L1822) sets the scheme of the URL it is given to `http` before sending, even for an `https` name, and its default redirect check skips the host check but keeps the 10-redirect limit (section 3). That check does not test or rewrite a redirect's scheme, so, as this guide's inference from Go's `net/http` client, not observed, the helper follows a redirect to the `Location` URL as given, `https` included. A caller that sets its own redirect check replaces that default. For a model without tensor layers, [the blob downloader](https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L219-L331) also passes `insecure` into the `transfer` package in 2 places: line 264 runs `transfer.ValidateRedirectTarget(ctx, loc, requestURL.String(), opts.Insecure)` on the direct-URL redirect, and line 274 builds the client that downloads the blob's parts with `transfer.NewRedirectClient(requestURL.String(), opts.Insecure)`. The `transfer` package was not read, so what `insecure` changes in those 2 calls, and so where a pulled blob's download may be redirected with it, is not established. With it, [the `transfer` download](https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1502-L1560) used for models with tensor layers and [the `transfer` upload](https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1594-L1653) also switch their base URL to `http` and pass `AllowPrivateHosts: regOpts != nil && regOpts.Insecure`. What that option permits inside the `transfer` package, which was not read, is not established. The [API reference](https://github.com/ollama/ollama/blob/v0.40.14/docs/api.md) describes `insecure` as "allow insecure connections to the library. Only use this if you are pulling from your own library during development."; keep `"insecure": false` in administrative requests unless the registry is a trusted local one served over plain HTTP.

Record the approved artifact or model digest independently, then compare it with deployed inventory before admitting traffic. `/api/tags` supplies model digests. Preserve approved bytes or a controlled registry artifact: a named tag alone does not guarantee immutability. See [model inventory](https://docs.ollama.com/api/tags).

An alternative for a reviewed local GGUF artifact is this **Modelfile**, not a Dockerfile:

```dockerfile
FROM /srv/ollama-import/app.gguf
```

Independently verify the artifact's approved SHA-256 before administrative import. The administrative CLI reads the path during import; this does not mean arbitrary remote API callers can read that host path. See the [Modelfile reference](https://github.com/ollama/ollama/blob/v0.40.14/docs/modelfile.mdx) and [CLI import flow](https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go).

A digest establishes byte identity, not publisher trust or model safety. Do not assume a universal `model@sha256` deployment recipe or native signature enforcement. Restrict deployment egress when only approved registries may be contacted. Keep export authority and registry credentials on the administrative side.

**Exposed/fixed comparison, REASONED:** no controlled registry, approved model artifacts, or live inventory is available here. Exposed management lets callers choose acquisition/export targets and mutate models; the fixed deployment admits independently recorded artifacts through administrators and denies mutation to inference identities.

## 8. Disable unused cloud execution

**Tier-1 rationale:** an exposed local API must not spend the host's upstream authority or send prompts to an unintended remote service.

For a local-only deployment:

```ini
[Service]
Environment="OLLAMA_NO_CLOUD=1"
```

Restart Ollama after changing it. It is one of two documented controls for cloud models and web search: the FAQ gives `disable_ollama_cloud` in `~/.ollama/server.json` first, and this variable as an alternative. See the [pinned FAQ](https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx).

This is not a general no-network switch. It does not replace management-route restrictions or registry egress policy. `OLLAMA_REMOTES` concerns remote-model hosts; it is not a pull/push registry allowlist. See [environment configuration](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go). The account balance and usage routes in section 3 answer `403` without contacting ollama.com when the server's cloud status reads as disabled; whether this setting is what sets that status is not established, so keep those routes behind the default denial whatever its value.

**Exposed/fixed comparison, REASONED:** no signed-in server, authorized cloud fixture, or live local model is available here. A cloud-enabled signed-in server completes an authorized cloud-model request; after disabling cloud functionality, that request is refused while local inference still completes.

## 9. Keep diagnostics private and disable request-body logging

**Tier-1 rationale:** operational endpoints and diagnostic files can disclose deployment details and submitted prompts.

C3's default-deny location also covers diagnostics. Keep `/`, `/api/version`, `/api/status`, `/api/tags`, `/api/ps`, and `/api/show` private unless individually required. Model details may contain templates and system prompts. The system-prompt part is this guide's source reading, not documentation: the served [model-details reference](https://docs.ollama.com/api-reference/show-model-details) documents a `template` field but no `system` field. At v0.40.14, `ShowResponse` [declares](https://github.com/ollama/ollama/blob/v0.40.14/api/types.go#L806-L812) `System string` with the tag `json:"system,omitempty"`, and `GetModelInfo` [fills it](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1935-L1947) from the model with `System: m.System,`. `ShowHandler` answers [a cloud model reference](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1779-L1800) from a cloud cache or `proxyCloudJSONRequest`, and [a request with `all_manifests` set](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1819-L1829) from `GetAllManifestsInfo`, whose code was not read, so whether those responses include `system` is not established. [For other requests](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1831-L1835) it calls `GetModelInfo` unless it answers from its show cache, whose code was not read. See the [router](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go).

Use:

```ini
[Service]
Environment="OLLAMA_DEBUG=0"
Environment="OLLAMA_DEBUG_LOG_REQUESTS=false"
```

Request debugging writes request bodies and replay scripts into a temporary directory. Disabling it prevents new captures; existing captures still need a retention and deletion policy. Protect diagnostic files and ensure proxy/application logging does not independently capture credentials or prompts. See [logging configuration](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go) and the [request logger](https://github.com/ollama/ollama/blob/v0.40.14/server/inference_request_log.go).

No `/metrics` registration appears in the [reviewed main router](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go); do not assume a native metrics port. At v0.40.14, the [CLI entry point](https://github.com/ollama/ollama/blob/v0.40.14/main.go#L3-L13) runs the CLI built by [`NewCLI`](https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2541-L2831), which [registers](https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2809-L2831) the [serve command (`start` alias)](https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2644-L2650), whose [server path](https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2269-L2285) calls [`server.Serve`](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2472-L2596) (the [`server` import](https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L3-L60) names the [`server` package](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1)) when invoked as `serve` or `start`. That function [registers the generated router with `http.Handle("/", h)`](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2523-L2528), creates an HTTP server with a [nil `Handler` and a comment saying `http.DefaultServeMux` was chosen to get `net/http/pprof` for free](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2537-L2547), and [serves the listener](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2588-L2593). The [server import block](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L3-L55) has no `net/http/pprof` import. Whether any other first-party code at v0.40.14 imports `net/http/pprof` or registers a pprof handler is not established, because this guide read only the v0.40.14 files Sources cites, and the `go list` sweeps and dependency reading below were made at v0.34.2 and not repeated at v0.40.14. This guide's source assessment is that first-party code in v0.34.2 registers no pprof handler: its non-test Go code has no `net/http/pprof` import, pprof handler registration, or `/debug/pprof` route. A `go list` import resolution run for this guide on 21 October 2026 with Go 1.26.5, for the main package at v0.34.2 (commit `dfabde45`) on linux, darwin and windows amd64 with cgo on and off, listed neither `net/http/pprof` nor `runtime/pprof` in any of its six package lists (413 to 419 import paths each). Twelve further `go list -deps .` runs for this guide on 21 October 2026, in the v0.34.2 tree root with Go 1.26.5 on a linux/amd64 host, `GOFLAGS=-mod=readonly` and the default `GOPROXY`, each exited 0 and listed neither `net/http/pprof` nor `runtime/pprof` in any of their twelve package lists (411 to 418 import paths each). The only path containing `pprof` in each of those twelve lists is `internal/runtime/pprof/label`. The twelve runs used default tags on linux and darwin arm64 with cgo on and off, and on windows arm64 and freebsd, openbsd, netbsd and solaris amd64 with cgo off; and, with cgo off, `-tags updater_live` on windows amd64 and darwin arm64 and `-tags release,library` on linux amd64. The darwin arm64 list with `-tags updater_live` is identical to the one without. In the tree's first-party `//go:build` lines at v0.34.2, the custom tags `integration` (for example [`integration/basic_test.go`](https://github.com/ollama/ollama/blob/v0.34.2/integration/basic_test.go#L1)), `fast`, `release` and `library` ([`integration/reg_groups_test.go`](https://github.com/ollama/ollama/blob/v0.34.2/integration/reg_groups_test.go#L1)), `generate` ([`integration/generate_jinja_test.go`](https://github.com/ollama/ollama/blob/v0.34.2/integration/generate_jinja_test.go#L1)) and `updater_live` ([`app/updater/updater_live_test.go`](https://github.com/ollama/ollama/blob/v0.34.2/app/updater/updater_live_test.go#L1)) gate only `_test.go` files. The tags `appengine` and `os400` appear in the tree's first-party `//go:build` lines at v0.34.2 only in the [constraint of `readline/term.go`, whose only import is `syscall`](https://github.com/ollama/ollama/blob/v0.34.2/readline/term.go#L1-L7). This guide's inference, not run, is that the test-only tags select no additional first-party non-test files, because `_test.go` files are not part of a non-test build ([`go build` ignores files that end in `_test.go`](https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L83) in Go 1.26.5), so they leave the main package's first-party imports unchanged. The dependency search below ignores build constraints, so which dependency modules' files those tags select was not determined, though the sweep below shows that `generate` selects a `github.com/rivo/uniseg` file.

A further 227 `go list -deps .` runs were made for this guide on 22 October 2026 in the v0.34.2 tree (commit `dfabde45`) with Go 1.26.5 on a linux/amd64 host, using `/usr/local/go/bin/go` with `GOENV=off`, `GOTOOLCHAIN=local`, `GOWORK=off`, `GOFLAGS=-mod=readonly`, `GOPROXY=off` and a module cache filled by `go mod download` (all modules verified, with a clean tree afterwards). The 227 runs, like the runs above, resolve imports without compiling a binary or running Ollama code. These 227 runs cover default tags for all 47 GOOS/GOARCH pairs that Go 1.26.5's `go tool dist list` reports, with cgo off, and for the 40 of those that report cgo support, with cgo on. These 227 runs also cover, with cgo off and on, the tag sets `updater_live`, `release,library`, `appengine`, `os400`, `appengine,os400`, `integration,fast,generate,release,library,updater_live` and those six tags plus `appengine` and `os400`, each on linux 386, amd64, arm and arm64, darwin amd64 and arm64, windows 386, amd64 and arm64, and aix ppc64. The 182 runs that exited 0 listed neither `net/http/pprof` nor `runtime/pprof`, and the only path containing `pprof` in any of their lists is `internal/runtime/pprof/label`. Those 182 runs are 82 default-tag runs, covering every pair with cgo off except the five below and every cgo-capable pair with cgo on, and all 100 runs with the `updater_live`, `release,library`, `appengine`, `os400` and `appengine,os400` tag sets. The other 45 exited 1. With cgo off, android 386, amd64 and arm and ios arm64 reported that the pair "requires external (cgo) linking, but cgo is not enabled" and ios amd64 reported "default PIE binary requires external (cgo) linking, but cgo is not enabled"; a `go list -e` rerun of each listed only the main package, carrying that error. The 40 runs with a tag set containing `generate` reported `found packages uniseg (doc.go) and main (gen_breaktest.go)` in the `github.com/rivo/uniseg` v0.4.7 module; their `go list -e` reruns listed neither pprof package but marked `github.com/rivo/uniseg` with that load error, so its imports may be incomplete. In the same session, a search of the main module's non-test Go files found no `"net/http/pprof"` or `"runtime/pprof"` import, and a `go list` query over the standard library named only `net/http/pprof` and `testing/internal/testdeps` as packages depending on either. Listing the dependency modules to search first failed with `go: module lookup disabled by GOPROXY=off`. A rerun the same day with the default `GOPROXY`, after `go mod download all` (whose added `go.sum` lines were then reverted), listed 108 dependency modules besides the main module, each with a directory, and every one was searched for those import paths in non-test Go files and for the text `/debug/pprof`. That search ignores build constraints, so it over-approximates. That search found `"net/http/pprof"` or `"runtime/pprof"` only in `package main` commands, in the `golang.org/x/tools` internal packages `go/analysis/internal/checker` and `internal/tool`, and as string data in `golang.org/x/tools/internal/stdlib`. The `package main` commands with those matches are seven in `github.com/dgryski/trifles`, plus `github.com/klauspost/compress/s2/cmd/s2c`, `golang.org/x/text/collate/tools/colcmp` and `golang.org/x/tools/cmd/deadcode`, `goimports` and `ssadump`. That search found `/debug/pprof` only in the `package main` command `github.com/dgryski/trifles/fastpprof`. None of those package paths, and no `github.com/dgryski/trifles` or `golang.org/x/tools` package, appears in the output of any of the 227 runs or the 45 `go list -e` reruns. This guide's inference, not run, is that these matches add no `net/http/pprof` or `runtime/pprof` import to the graphs of those runs. It judges reachability only against those runs' graphs, and the same searches, run over the main module the same day, ignore build constraints and found neither import nor `/debug/pprof` text there.

A source reading for this guide on 26 October 2026, with no Go code built or run, followed those import paths through the extracted sources of the 93 dependency modules whose zips v0.34.2's [`go.sum`](https://github.com/ollama/ollama/blob/v0.34.2/go.sum) lists, from the module cache of the 22 October 2026 sweep; each of those zips has a `.ziphash` and an `h1:` hash recomputed from its contents that match `go.sum`. The other 15 modules in that cache, including `golang.org/x/tools` v0.38.0, have no `go.sum` hash for their module zip (nine have only a `/go.mod` line), so the reading excluded them and did not read them. Reading the package clause and imports of every non-test Go file in those 93 modules and in the main module, ignoring build constraints, found `net/http/pprof` or `runtime/pprof` imported only by the `package main` files of ten commands. Those ten commands are [`cstbucket`](https://github.com/dgryski/trifles/blob/dd97f9abfb48/cstbucket/main.go#L1-L17), [`fastpprof`](https://github.com/dgryski/trifles/blob/dd97f9abfb48/fastpprof/main.go#L1-L13), [`jumpreplica`](https://github.com/dgryski/trifles/blob/dd97f9abfb48/jumpreplica/main.go#L1-L18), [`lz`](https://github.com/dgryski/trifles/blob/dd97f9abfb48/lz/lz.go#L1-L11), [`matcher`](https://github.com/dgryski/trifles/blob/dd97f9abfb48/matcher/main.go#L1-L13), [`quantiles`](https://github.com/dgryski/trifles/blob/dd97f9abfb48/quantiles/main.go#L1-L22) and [`udprelay`](https://github.com/dgryski/trifles/blob/dd97f9abfb48/udprelay/main.go#L1-L26) in `github.com/dgryski/trifles` v0.0.0-20200323201526-dd97f9abfb48, [`s2/cmd/s2c`](https://github.com/klauspost/compress/blob/v1.18.3/s2/cmd/s2c/main.go#L1-L27) in `github.com/klauspost/compress` v1.18.3 and [`collate/tools/colcmp`](https://github.com/golang/text/blob/v0.30.0/collate/tools/colcmp/colcmp.go#L5-L22) in `golang.org/x/text` v0.30.0. The text `/debug/pprof` appears in those modules only in [the `package main` command `github.com/dgryski/trifles/fastpprof`](https://github.com/dgryski/trifles/blob/dd97f9abfb48/fastpprof/main.go#L16-L42) and in a `github.com/pelletier/go-toml/v2` v2.2.2 test file, at [line 1571](https://github.com/pelletier/go-toml/blob/v2.2.2/marshaler_test.go#L1571) and [line 1649](https://github.com/pelletier/go-toml/blob/v2.2.2/marshaler_test.go#L1649). Following imports from every main-module package through the non-test files of packages other than `package main`, with standard-library packages taken as leaves, reached no file importing either pprof package and no import path outside those 93 modules and the standard library. The `golang.org/x/text` and `golang.org/x/exp` packages that import `golang.org/x/tools` packages are imported in those modules only by `package main` and test files, and the main module imports none of them. This guide's inference, not run, is that none of those 93 dependency modules adds `net/http/pprof` or `runtime/pprof` to a build of v0.34.2's main package at these module versions, for any GOOS/GOARCH pair, cgo setting or tag set, because a `package main` command is not imported by other packages. The reading does not cover the standard library, whose importers of either package come from the linux/amd64 query above and the Go 1.26.5 source reading below, other Go versions, or what the failed runs or a shipped binary would contain.

In Go 1.26.5, `net/http/pprof`'s [`init` function](https://github.com/golang/go/blob/go1.26.5/src/net/http/pprof/pprof.go#L96-L106) registers `/debug/pprof/` and its `cmdline`, `profile`, `symbol` and `trace` paths, each prefixed with the method `GET` unless the `httpmuxgo121` GODEBUG setting is `1`, through [`http.HandleFunc`, which registers on `DefaultServeMux`](https://github.com/golang/go/blob/go1.26.5/src/net/http/server.go#L2870-L2878); a server's [`Handler` is `http.DefaultServeMux` if nil](https://github.com/golang/go/blob/go1.26.5/src/net/http/server.go#L2971), as [its request dispatch applies](https://github.com/golang/go/blob/go1.26.5/src/net/http/server.go#L3302-L3306). A `go list` of the `server` package's Go files on linux amd64 in the same session includes `routes.go`. This guide's inference, not run, is that a build whose import graph includes `net/http/pprof` would serve those paths on the Ollama listener through `Serve`'s nil `Handler`, and that the builds above whose graphs exclude it get no handler from that package. It assumes that a package outside the graph is not linked, so its `init` never runs, and that no other linked code registers a `/debug/pprof/` handler, which this guide checked in first-party code and, by a search for the text `/debug/pprof`, in the 93 dependency modules whose zips `go.sum` hashes.

v0.34.2's [`go.mod` declares `go 1.26.0`](https://github.com/ollama/ollama/blob/v0.34.2/go.mod#L3) with no `toolchain` line, a requirement that the Go 1.26.5 used for these runs satisfies. v0.40.14's [`go.mod` declares `go 1.26.10`](https://github.com/ollama/ollama/blob/v0.40.14/go.mod#L3), also with no `toolchain` line, a requirement that Go 1.26.5 does not meet. This guide's reading of the v0.40.14 release configuration, which shows the builds intended and not what a published artifact contains, is that the [Dockerfile's Go build stage](https://github.com/ollama/ollama/blob/v0.40.14/Dockerfile#L257-L273) downloads the Go release named by that `go` line, Go 1.26.10, and builds the main package with `CGO_ENABLED=1`, `-trimpath -buildmode=pie` and no `-tags`. By the same reading, the [macOS build script](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_darwin.sh#L88-L89) sets `GOOS=darwin GOARCH=$ARCH CGO_ENABLED=1` for a CMake build whose [Go step](https://github.com/ollama/ollama/blob/v0.40.14/cmake/local.cmake#L711-L758) runs `go build -trimpath` on the main package with `CGO_ENABLED=1` and no `-tags`. By the same reading, the [Windows build script](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L865-L920) builds the CLI with no `-tags`, and its [`checkEnv` function sets `CGO_ENABLED=1` unconditionally](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L296) and [runs before the build steps](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L1299), so its [default CLI build, whose `go build` sets no `GOARCH`](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L896-L908), uses `CGO_ENABLED=1`, as does its arm64 build, whose wrapper sets `GOOS=windows`, `GOARCH=arm64` and `CGO_ENABLED=1` explicitly. By the same reading, for the default build, the architecture `checkEnv` [selects](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L210-L230) is [copied to `TARGET_ARCH`](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L231), which reaches that build only as [its output directory](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L295). By the same reading, the release workflow's [macOS](https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L71-L82) and [Windows](https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L354-L378) jobs set up Go with `go-version-file: go.mod` before running those scripts. By the same reading, the workflow's [`GOFLAGS` value](https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L13-L25) carries one `-ldflags` flag (`-w -s` and two `-X` settings) and no `-tags`, and the [macOS job's](https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L34) and [Windows job's](https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L338) environments apply it, so those environments add no `-tags` to the scripts' builds. By the same reading, the workflow's [`linux-depends` job](https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L480-L557) passes that value as a Docker build argument only to dependency targets, none of which is or copies from the [Dockerfile's](https://github.com/ollama/ollama/blob/v0.40.14/Dockerfile) Go build stage. By the same reading, the [`docker-build-push` job](https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L562-L667), whose builds do reach that stage, names `GOFLAGS` without a value among its build arguments and sets the workflow value in its environment; whether the build receives that value depends on Docker build tooling not traced here, and [the stage's own `GOFLAGS` default](https://github.com/ollama/ollama/blob/v0.40.14/Dockerfile#L257-L273) carries no `-tags` either. The sweep's matching default-tag runs (linux, darwin and windows amd64 and arm64, cgo on and off) list neither pprof package, but they resolved v0.34.2 with Go 1.26.5, which is neither the tree nor the Go release these v0.40.14 builds use.

A source reading for this guide on 26 October 2026, with no Go code built or run, compared the standard library of every other stable Go 1.26.x release, Go 1.26.0 to 1.26.4 and 1.26.6 to 1.26.10, with that of Go 1.26.5, the release the `go list` runs above used. Each release's source tarball was fetched from go.dev on 26 October 2026, and the fetch record shows its SHA-256 matching the value go.dev publishes; Sources cites each release's `goversion` line, `go/build` release-tag lines and `runtime/pprof` imports at its `go1.26.N` tag. In each of those releases, as in Go 1.26.5, `internal/goversion` sets `Version = 26`, from which `go/build` derives the release tags `go1.1` to `go1.26` (`go/build/build.go` lines 354 and 355). Reading the import declarations of the non-test Go files outside the `cmd` and `testdata` directories, ignoring build constraints, found `runtime/pprof` imported in each release only by `net/http/pprof`, by `testing/internal/testdeps` and by the `package main` command `simd/archsimd/_gen/simdgen`, at the same lines as in Go 1.26.5. The same reading found no file importing `net/http/pprof` or `testing/internal/testdeps`, and found the text `/debug/pprof` only in `net/http/pprof` and in doc comments of `runtime/pprof` and `runtime/trace`. A file-by-file comparison of each release's import lists with Go 1.26.5's, whose listed additions were each found in that release's source, found across the ten releases one added file, which has no imports, and added imports of 14 packages. Those packages are `bytes`, `crypto/internal/entropy/v1.0.0`, `crypto/internal/fips140/sha256`, `crypto/internal/sysrand`, `crypto/sha256`, `encoding/hex`, `internal/runtime/atomic`, `internal/stringslite`, `internal/syscall/unix`, `math`, `runtime`, `slices`, `sync` and `sync/atomic`; none is a pprof package or one of the importers above, and removed imports and files cannot add one. This guide's inference, not run, is that none of those releases adds `net/http/pprof` or `runtime/pprof` to a v0.34.2 build graph that the Go 1.26.5 runs above recorded without them, because in each release no standard-library package other than those importers imports either one. The reading compares source and checked no `go list` graph, so which files the build constraints and cgo select, and whether the builds that failed with Go 1.26.5 load, are recorded for Go 1.26.5 only. Read the same way, Go 1.26.5's own standard library has the same three importers of `runtime/pprof`, at the lines Sources cites, and outside `cmd` the quoted import paths otherwise appear only in doc comments, in `testdata` files and in `_test.go` files, so no non-test file outside `cmd` and `testdata` imports `net/http/pprof` or `testing/internal/testdeps`. The `simdgen` command is [`package main`](https://github.com/golang/go/blob/go1.26.5/src/simd/archsimd/_gen/simdgen/main.go#L71) in a `_gen` directory, which, like a `testdata` directory, [the go tool ignores](https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L3225-L3226), and `testing/internal/testdeps` is [importable only by code under `testing`](https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L2811-L2812), where no non-test file imports it; in `cmd`, [the main package that `go test` generates](https://github.com/golang/go/blob/go1.26.5/src/cmd/go/internal/load/test.go#L790-L801) imports it. [The packages that the go command adds to a main package's link](https://github.com/golang/go/blob/go1.26.5/src/cmd/go/internal/load/pkg.go#L2638-L2672), `runtime` and, depending on the build, `runtime/cgo`, `math`, `runtime/race`, `runtime/msan`, `runtime/asan` and `runtime/coverage`, are not among those importers. [The imports that the go command adds](https://github.com/golang/go/blob/go1.26.5/src/cmd/go/internal/load/pkg.go#L1912-L1935) to a package that uses cgo, `unsafe`, `runtime/cgo` and `syscall` (`cmd/go/internal/load/pkg.go` lines 1912 to 1922), and to a package that uses SWIG, those three and `sync` (lines 1924 to 1931), are not among those importers either. A comment in `pkg.go` (lines 1933 and 1934) notes that `.swig` and `.swigcxx` files can also import other packages through `%go_import` directives. This guide's inference, not run, is that in Go 1.26.5 no standard-library package adds `net/http/pprof` or `runtime/pprof` to a non-test build whose other packages import neither, on any GOOS/GOARCH pair or tag set, because the reading ignores build constraints and so covers every standard-library file a build could select. With the first-party search and the 93-module reading above, this guide infers that no Go 1.26.5 build of v0.34.2's main package at these module versions imports either package, on any pair, cgo setting or tag set; the inference rests on no `go list` graph and does not cover code that cgo generates, whether the builds that failed load, the desktop app or a shipped binary. That inference also does not cover `%go_import` directives in any `.swig` or `.swigcxx` files, for which this guide searched neither v0.34.2 nor its modules.

These `go list` results resolve imports without building a binary and did not inspect the shipped release binary. No `go list` graph was made at v0.40.14, and the dependency reading was not rerun over v0.40.14's `go.sum`, so both remain unestablished. Builds with Go releases outside the 1.26.x patch line, `go list` graphs for the other 1.26.x releases (including the Go 1.26.0 that v0.34.2's `go` line names), the five cgo-off android and ios runs and the 40 `generate` runs that failed, the swept tag sets on GOOS/GOARCH pairs other than the ten they were run on, and other tag sets and combinations remain unestablished. For the Go 1.26.5 builds among those that load, the source readings above leave open, of their imports, only those of code that cgo generates and of any `%go_import` directives in SWIG files, since this guide infers from those readings, with no `go list` graph, that no first-party, `go.sum` dependency or standard-library package adds either to those builds. This guide searched neither v0.34.2 nor its modules for `.swig` or `.swigcxx` files, the SWIG files whose `%go_import` directives can import other packages (Go 1.26.5 `cmd/go/internal/load/pkg.go` lines 1933 and 1934). Beyond this guide's inferences above, whether these or such builds give the served mux pprof handlers also remains unestablished. Shipped-binary pprof availability remains unestablished, and the comment alone does not establish it. This guide's advice: include `/debug/pprof/` in live inventory and public-denial checks. Do not claim either default availability or that `OLLAMA_DEBUG=0` disables profiling.

At v0.34.2, the desktop app main package [`./app/cmd/app`, whose files build only on windows or darwin and whose import block names no pprof package](https://github.com/ollama/ollama/blob/v0.34.2/app/cmd/app/app.go#L1-L33), which the release scripts also build, was resolved by ten further `go list -e -deps ./app/cmd/app` runs made for this guide on 23 October 2026. They ran in the same v0.34.2 tree and environment as the sweep above, on darwin and windows amd64 and arm64 and linux amd64, cgo off and on. No run listed `net/http/pprof` or `runtime/pprof`, and the only path containing `pprof` in any of their lists is `internal/runtime/pprof/label`. Every run carries a load error, and a package carrying one may list incomplete imports. Both linux amd64 runs fail on that constraint (`build constraints exclude all Go files`) and list only the main package, marked with that error, establishing only that the package has no linux files at v0.34.2. All eight darwin and windows runs mark `app/ui` with `pattern app/dist: no matching files found`, because [its `//go:embed app/dist` directive](https://github.com/ollama/ollama/blob/v0.34.2/app/ui/app.go#L15-L16) names web assets that are not in the v0.34.2 tree (the macOS build script builds them with npm before its Go builds). The four cgo-off darwin and windows runs cannot load [`app/webview`, which is cgo-only through its `import "C"`](https://github.com/ollama/ollama/blob/v0.34.2/app/webview/webview.go#L51) and also omit the main package's own cgo files ([`app_darwin.go`](https://github.com/ollama/ollama/blob/v0.34.2/app/cmd/app/app_darwin.go#L10) and [`webview.go`](https://github.com/ollama/ollama/blob/v0.34.2/app/cmd/app/webview.go#L6)) with no error, while the cgo-on runs, the setting the release scripts use, load them. These runs were not repeated at v0.40.14. There, [the tree](https://github.com/ollama/ollama/tree/v0.40.14) still holds no `app/ui/app/dist`, and the main package has further non-test files, among them `claude_desktop_status.go`, whose name carries no OS suffix and whose build constraint was not read, so whether the package still builds only on windows or darwin at v0.40.14 is not established. By source reading at v0.40.14, not run, the import blocks of [`app/ui/app.go`](https://github.com/ollama/ollama/blob/v0.40.14/app/ui/app.go#L5-L13), [`app/ui/ui.go`](https://github.com/ollama/ollama/blob/v0.40.14/app/ui/ui.go#L6-L39) and [`app/ui/extract.go`](https://github.com/ollama/ollama/blob/v0.40.14/app/ui/extract.go#L5-L14), the three non-test Go files directly in `app/ui`, of [`app/webview/webview.go`](https://github.com/ollama/ollama/blob/v0.40.14/app/webview/webview.go#L53-L60), the only Go file in `app/webview`, and of the main package's [`app_darwin.go`](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L12-L44), [`webview.go`](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/webview.go#L8-L26) and [`codex_app_darwin.go`](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/codex_app_darwin.go#L5-L25) name neither `net/http/pprof` nor `runtime/pprof`. Not read here are the main package's other files, the `app/ui/responses` subpackage, the imports of the packages those blocks name, and how `go list` records a package's imports despite load errors, so whether the app's build imports either pprof package at v0.40.14 remains open. In the app's own non-test code read here, two listeners appear, both loopback. Neither v0.40.14 Codex Desktop integration file read here opens one: [`internal/proxy/codex_desktop.go`](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go) and [`app/cmd/app/codex_app_darwin.go`](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/codex_app_darwin.go), read whole, contain no `net.Listen` or `http.Server`, and the first [describes its handler as routing requests "using the existing Ollama listener"](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L60-L62) under [`/api/codex`, which it calls the "loopback-only Ollama server route"](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L27-L30). The Ollama server [registers the handler that `newCodexDesktopProxy` returns for every method under `/api/codex`](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2385-L2450), the desktop proxy route section 3 names, beside a comment that Codex uses this existing Ollama listener; `newCodexDesktopProxy` itself and [the `cmd/launch` `CodexApp` controller that the second file drives](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/codex_app_darwin.go#L35-L49) were not read. [The `CodexDesktop` handler's `ServeHTTP`](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L157-L177) answers `403` unless [the request's remote address is `localhost` or a loopback IP](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L640-L650), answers `NotFound` outside that prefix, and serves `/_health` and [a `/_status` route reporting request counters and the last model, route and upstream status](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L513-L529) with no further check. [Other requests](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L193-L264) go to Ollama when the body's model is in the routing catalog file, [with only the `Accept`, `Content-Type`, `OpenAI-Beta` and `User-Agent` headers](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L359-L376) [copied](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L675-L681), and otherwise to the OpenAI API or the ChatGPT upstream, except that a request carrying the managed sentinel key and not routed to Ollama is answered `401`. This guide's inference, not observed: the loopback check reads the TCP peer address, so if the Ollama server serves this handler on its own listener, a request relayed by a proxy on the same host would pass it only when that proxy connects to Ollama over loopback, and then the policy proxy's default denial of unlisted paths, not this check, is what refuses `/api/codex` to remote callers. The UI listener is [`net.Listen("tcp", "127.0.0.1:0")`, or `127.0.0.1:3001` in dev mode](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app.go#L186-L196), and [`srv := &http.Server{Handler: uiServer.Handler()}` serves it with a non-nil `Handler`](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app.go#L280-L293), so, as this guide's inference from the Go sources cited above, a build that linked `net/http/pprof` would still not serve `DefaultServeMux`'s handlers on this listener. [The UI mux](https://github.com/ollama/ollama/blob/v0.40.14/app/ui/ui.go#L278-L327) registers `/api/v1/` routes behind [a token-cookie check that development mode skips](https://github.com/ollama/ollama/blob/v0.40.14/app/ui/ui.go#L194-L225), reverse-proxy routes for seven Ollama API paths (eight method patterns) and catch-all app routes, both wired without that check, and no `/debug/pprof` pattern. The second listener traced here is the macOS Claude Desktop gateway: [`app_darwin.go` is cgo-only through its `import "C"`](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L10), so the darwin cgo builds, the release setting, compile it, and [at startup the app reconciles that gateway](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L535), [starting it only when Claude Desktop is installed and configured to use it](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L546-L561). The app's Claude Desktop connect and model-mapping actions also start it without an already configured Claude Desktop, through [`setClaudeGatewayInstalled`](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1202-L1229), [`prepareClaudeDesktopConnection`, which starts it before configuring Claude Desktop and stops it only when Claude Desktop does not end up using the gateway](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1478-L1493), and [the model-mapping path](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1645-L1667). However, [the start itself skips when Claude Desktop is not installed](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L592-L598). `setClaudeGatewayInstalled` also starts it before configuring Claude Desktop and stops it when Claude Desktop does not end up using the gateway, unless `effectiveClaudeDesktopAutoMode` has already returned an error. The model-mapping path, [when it finds no existing gateway](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1574-L1579), stops it when its profile change returns an error other than `ErrClaudeDesktopRestartConfirmationRequired`, while [with an existing gateway it returns such an error joined with `restoreState()`'s result, without stopping it](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1700-L1704). The start [constructs the gateway](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L614-L631) with [a listen address set to `proxy.DefaultClaudeDesktopListenAddr` beside a 750 ms start retry window](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L95-L96), [`127.0.0.1:11435`](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L23-L26) [copied to the gateway's own listen address at construction](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L131-L132), and [calls its `Start`, retrying briefly while the address is in use](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L944-L951). [`Start` listens there and serves an `http.Server` whose `Handler` is the gateway itself, non-nil](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L198-L221), and [its `ServeHTTP` serves only `/_ollama/health`, `/v1/models`, `/v1/messages/count_tokens` and `/v1/messages`, rejects a request whose first `Origin` header value is non-empty and answers other paths with `NotFound`](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L300-L361), with no `/debug/pprof` route. [Go 1.26.5's `Header.Get` returns a header's first value](https://github.com/golang/go/blob/go1.26.5/src/net/http/header.go#L43-L51); this guide's inference, not observed, is that a non-empty `Origin` value after an empty first one does not trigger that rejection. [Before that `Origin` check, `ServeHTTP` answers `403`](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L300-L361) to any request whose `Host` header [is not `localhost`, in any letter case, or a loopback IP literal, followed by the port the gateway is listening on](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L419-L435), so a `Host` with no port is refused too. Only `POST /v1/messages` passes to the gateway's reverse proxy, since the other routes return first: the gateway [removes `Authorization`, `Cookie` and `Proxy-Authorization`, sets `X-Api-Key: ollama` and the upstream `Host`, waits for the upstream, and forwards the request](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L363-L380) through a reverse proxy [whose transport's `Proxy` is nil](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L126-L130). [That wait](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L442-L511) dials the upstream over TCP until a connection succeeds or 10 seconds pass, and a success is reused for 5 seconds: [the constants `upstreamReadyTimeout` and `upstreamReadyTTL`](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L27-L31) hold those values, and [construction sets the wait from the first](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L143). [The start takes the upstream from `envconfig.ConnectableHost()` and refuses an `OLLAMA_HOST` whose port is the gateway's](https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L599-L609), then passes it as the gateway's Ollama URL: [`Host`](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L20-L60) reads `OLLAMA_HOST` [from the app process's environment](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L378-L380), defaulting to `http://127.0.0.1:11434`, and [`ConnectableHost`](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L62-L83) replaces an unspecified address with loopback. This guide's inference, not observed: if the app's own environment sets `OLLAMA_HOST` to another address, the gateway forwards Claude Desktop's messages there without the caller's `Authorization`, `Cookie` or `Proxy-Authorization` headers, so an authenticating proxy at that address that expects them would refuse those requests. [Model routing](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L594-L634) reads the body's `model` and admits it only when it [equals a listed model's gateway ID or Ollama model name](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L741-L748), [otherwise answering `400`](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L300-L361); it answers [`401`, `403`, `404` or `503`](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L807-L818) when that model's access check fails, and otherwise rewrites `model` to the listed Ollama model name. [A `400` from Ollama to a replayable `POST /v1/messages` is retried once](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L636-L724), with each image replaced by a text notice, under three further conditions. The error body, at most [64 KiB](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L27-L31), must decode as an `anthropic.ErrorResponse` whose `Type` is `error` and whose `Error.Type` is `invalid_request_error`, with a message that, ignoring letter case, contains `image` or `vision` and `not support` or `unsupported`. The JSON request body, at most 64 MiB, must name a string `model` that is not a listed model supporting vision, and at least one image must be replaced. By source reading, not run, the gateway keeps at most five models, each holding one of [five fixed Claude route IDs](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_models.go#L16-L35) (`claude-fable-5`, `claude-opus-5`, `claude-sonnet-5`, `claude-haiku-4-5-20251001` and `claude-sonnet-4-6`), which [it assigns in that order unless the models already hold distinct ones](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_models.go#L308-L353), and [with no configured models it uses](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L146-L148) [five built-in cloud models](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_models.go#L183-L200). Of the models these files construct, only models named `kimi-k3:cloud`, such as the built-in one, [are marked as supporting vision](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_models.go#L433-L467). [`/v1/models` lists only the models whose access check returns available](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L519-L555). [That check](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_access.go#L55-L124) admits a local model only when the local inventory is known and lists it, and a cloud model only when Cloud is on, the account is signed in, the model's entitlement is known and the plan meets its requirement: an empty or `free` requirement admits any plan, and any other needs a plan that is neither empty nor `free`. Otherwise it reports `cloud_off`, `sign_in_required`, `upgrade_required` or `model_not_installed`, which the message and token-count routes [answer](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L807-L818) with `403`, `401`, `403` and `404`, or unknown availability with `verification_unavailable`, answered with `503`, when the inventory, Cloud status or account state is undetermined or a cloud model's entitlement is unknown. With no access resolver, [the gateway assumes Cloud on, a signed-in account and plan `pro`, and with no local-model lister it treats every local model as installed](https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L750-L799); the app callbacks that supply these and refresh the list are not traced here. This guide's inference, not observed: on a Mac running the desktop app with that gateway on, the gateway and the Option B policy proxy recipe's `listen 127.0.0.1:11435;` would both try to bind that address and port. The app does not serve the Ollama API listener itself: it runs [the separate `ollama` binary resolved at construction](https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L49-L51) [with `serve`, copying the app's own environment, setting `OLLAMA_HOST=0.0.0.0` when the app's Expose setting is on, and setting `OLLAMA_ORIGINS=*` when its Browser setting is on](https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L241-L255), the server the rest of this guide covers, and [restarts it in a supervision loop when it exits](https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L190-L225). So a desktop deployment can be exposed by the Expose setting, as well as by an `OLLAMA_HOST` in the app's own environment, and the Browser setting adds `*` to that server's allowed origins, the wildcard section 4 advises against. By this guide's reading of the intended builds, not artifacts, [the macOS build script](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_darwin.sh#L200-L216) builds the web assets with npm and then this package with `GOARCH=amd64` and `arm64`, `CGO_ENABLED=1`, `GOOS=darwin` and no `-tags`. By the same reading, [`build_windows.ps1`'s `buildApp` runs `go build` with no `-tags`](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L981-L1005), once as the default app build, which sets no `GOARCH` and uses the architecture `checkEnv` selects in its output file name only, under its unconditional `CGO_ENABLED=1`. By the same reading, [only when the cross-compile tools are present](https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L995-L998), `buildApp` runs that `go build` once more, for arm64, inside `withWindowsArm64GoEnv`, which sets `GOOS=windows`, `GOARCH=arm64` and `CGO_ENABLED=1`. These runs resolve imports without compiling and no shipped app binary was inspected; other Go versions, other GOOS/GOARCH pairs and tag sets, the imports the load errors above may hide, the gateway behaviour not traced above and every runtime response of these listeners remain unestablished.

**Exposed/fixed comparison, REASONED:** no runtime, diagnostic files, or live profiling inventory is available here. An exposed deployment returns operational metadata and may capture request bodies; the fixed public boundary denies diagnostics, administrators retain necessary visibility, and disabled request logging creates no new capture.

For the host-installed, local-only example, the assembled systemd drop-in is:

```ini
[Service]
User=ollama
Group=ollama
UMask=0077
Environment="OLLAMA_HOST=127.0.0.1:11434"
Environment="OLLAMA_MODELS=/var/lib/ollama/models"
Environment="OLLAMA_MAX_LOADED_MODELS=1"
Environment="OLLAMA_NUM_PARALLEL=1"
Environment="OLLAMA_MAX_QUEUE=16"
Environment="OLLAMA_KEEP_ALIVE=1m"
Environment="OLLAMA_CONTEXT_LENGTH=4096"
Environment="OLLAMA_NO_CLOUD=1"
Environment="OLLAMA_DEBUG=0"
Environment="OLLAMA_DEBUG_LOG_REQUESTS=false"
```

Add C4's explicit origin only if required, and remove inherited unwanted origins. Apply this to the existing service, reload systemd, and restart once the account, store, and proxy configuration are ready. Preserve GPU access required by the installed service.

## Common mistakes

- Publishing `11434:11434` and assuming the standalone loopback default protects the official container.
- Using `-p` as a host-networking control, or treating an absent `ss` listener as proof that Docker has no published path.
- Treating cloud login, API keys, `OLLAMA_AUTH`, a Host rewrite, or CORS as local inbound authentication.
- Adding `https://` to `OLLAMA_HOST` and assuming the backend now serves TLS.
- Authenticating `/api/generate` while leaving management or compatibility routes reachable.
- Retaining a catch-all proxy beside an inference allowlist, or omitting the bearer check from a newly permitted location.
- Expecting public `/api/tags` to return 200 after intentionally making inventory private.
- Treating one `OLLAMA_ORIGINS` value as an exclusive browser-origin policy.
- Treating context length, keep-alive, or `proxy_read_timeout` as enforced total resource or execution ceilings.
- Assuming a model tag is immutable, `OLLAMA_NO_CLOUD` blocks every network transfer, or `OLLAMA_REMOTES` restricts registries.
- Running as root, leaving the store broadly writable, assuming `UMask` repairs existing files, or expecting it to make the manifests and the blobs `manifest/layer.go` writes `0600`.
- Disabling debug logging without handling existing captures, or assuming that also disables profiling.

## Verify

REASONED: service-comparison scope from the cited v0.40.14 sources; no authorized live deployment or external observer. No service was started or contacted for these checks. All service-behavior checks below are **REASONED, not demonstrated**. The authoring environment has no Ollama, Docker, Podman, nginx, or Caddy executable in `PATH`, no Ollama runtime or GPU, and no supplied authorized deployment, external observer, credentials, or model fixtures. Filesystem and network restrictions prevent provisioning a live comparison here. **Lack of a GPU alone would not prevent listener, API, CORS, or management testing.**

REASONED: mixed local-validation evidence and unobserved service comparisons from the cited v0.40.14 sources; a fresh local run with Bash 5.3.9 bash -n and ShellCheck 0.11.0 run with -s bash accepted all four Verify shell fences with exit 0 and no output, establishing only syntax and lint results. Native proxy parsing and live comparisons remain unobserved without the binaries and an authorized deployment; the following validation account is historical, including its 74-case count, guard-scanner result and drop-in gate statement, and that count was not re-established here. Local validation covered the four Bash fragments with `bash -n`, ShellCheck 0.11.0, and the repository's strict guard-convention scanner. Guard-only tests rejected 74 invalid or incomplete positional-input cases under `bash -u`; four substituted controls reached local markers in place of the operational branch. These observations establish shell and outer-guard behavior only. The fresh bash -n and ShellCheck run and the historical guard-only tests covered the four Verify fences in an earlier form, whose guard refusals exited with status 1; those runs did not cover the later forms, whose guard refusals exit with status 2. In that earlier form, V6 also exited with status 1 when its result directory could not be created or protected, and with status 0 after a failed transfer, and V1, V2 and V3 ended with the status of their last command. The current V6 exits with status 3 in both of those V6 cases and keeps its values in positional parameters, and the current V1, V2 and V3 report the statuses their sections describe. On the form that preceded V1's `command -v ss` check, bash -n in Bash 5.3.9 exited 0, stub runs without network access checked its exit statuses, and `tools/run_all_checks.sh` ran ShellCheck 0.11.0 over it with no findings; no server run is recorded, and no demonstration was re-run. V1 changed again after every run recorded here: it now checks `command -v ss` before running `ss -tlnp`, and when `ss` is not installed it prints `ss is not installed here; not listing sockets` and exits with status 2 unless an inspection command failed, which still gives 3. Those runs covered an earlier form of V1; its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs with `ss` present and passing, present and failing, and missing. Native proxy parsing remains unconfirmed; every service comparison is REASONED from the cited v0.40.14 sources and vendor documentation. The whole-corpus gate suite was not run against this drop-in.

REASONED: shell preparation and limitations from the printed guards and curl reference. Local Bash 5.3.9 ran bash -n on all four Verify shell fences with exit 0 and no output. For each complete subshell, operational commands were replaced with local printf markers; valid controls were ollama.service/NONE, 192.168.50.7, and https://fixture.internal/api/chat with readable disposable JSON and empty mode-0600 client configuration files, POST and application/json where applicable. Replacing the first value after the marker with an empty string or bad value, keeping the original placeholders, or using set -- without arguments produced no operational marker and exit 1. Those runs covered the four Verify fences in an earlier form, whose guard refusals exited with status 1; those runs did not cover the later forms, whose guard refusals exit with status 2; in the current form V1, V2, V3 and V6 also report the statuses their sections describe. V1 changed again after those runs and now also exits with status 2 when `ss` is not installed and no inspection command failed; its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, not by these marker runs. The V6 arms that stop when the result directory cannot be created or protected are not guard refusals; they exited with status 1 in that earlier form and now exit with status 3, and V6 now also exits with status 3 after any failed transfer, where the earlier form ended with status 0. The valid controls reached their markers; V6 wrote eight LOCAL_CURL status files in a mode-0700 directory. This tests only those shell cases, not address syntax, client configuration acceptance, inference, or deployment isolation. Paste complete blocks, including the parentheses, marker, and count checks. Substitute inside the single quotes on each `set --` line; a literal apostrophe requires shell escaping. The guards assume normal shell builtins and cannot protect a fragment pasted from below them. Use curl 7.75.0 or later for the displayed `exitcode` and `errormsg` variables.

REASONED: comparison procedure from the cited service and proxy sources; isolated exposed/fixed deployments, identities and observers are unavailable. Use isolated exposed and fixed deployments with disposable fixtures. Do not make production public to obtain a baseline. Record binary/image identity, effective configuration, observer location, HTTP results, completed response bodies, upstream observations, state changes, and cleanup without secrets.

### V1. Inspect the listener, identity, and store (REASONED: listener, systemd/container identity, publication, ownership, ACL and writable-store comparisons, with administrative and inference positive controls, follow C1 and C5; no deployed store, service identity or external observer. Local command-marker tests above do not inspect a deployment)

**REASONED:** no deployed service, container runtime, store, or test identities are available. Run this on the deployment host with enough privilege to inspect processes and sockets. Use `NONE` for a host-only deployment.

Expected behavior follows C1's [Docker publication reference](https://docs.docker.com/engine/network/port-publishing/) and C5's [Linux service instructions](https://github.com/ollama/ollama/blob/v0.40.14/docs/linux.mdx).

```bash
(
  set -- PASTE_WHOLE_BLOCK 'ollama.service' 'REPLACE_WITH_CONTAINER_NAME_OR_NONE'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not inspecting"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "supply unit and container name or NONE"; exit 2; }
  case "$1|$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|'|'*|*'|'|*'||'*|*[[:space:]]*)
      echo "replace both values; not inspecting"; exit 2 ;;
    *)
      set -- "$1" "$2" 0                # the 3rd value is the block's status: 3 once an inspection command fails, else 2 if ss is missing, otherwise 0
      systemctl cat -- "$1" || { echo "systemctl cat exit $?; inconclusive"; set -- "$1" "$2" 3; }
      systemctl show --property=User,Group,UMask,Environment,MainPID -- "$1" || { echo "systemctl show exit $?; inconclusive"; set -- "$1" "$2" 3; }
      ps -C ollama -o pid,user,group,args || { echo "ps exit $? (no ollama process, or ps failed); inconclusive"; set -- "$1" "$2" 3; }
      if command -v ss >/dev/null; then
        ss -tlnp || { echo "ss -tlnp exit $?; inconclusive"; set -- "$1" "$2" 3; }
      else
        echo "ss is not installed here; not listing sockets"
        case "$3" in 0) set -- "$1" "$2" 2 ;; esac
      fi
      stat -c '%U:%G %a %n' /var/lib/ollama /var/lib/ollama/models || { echo "stat exit $?; inconclusive"; set -- "$1" "$2" 3; }
      getfacl -p /var/lib/ollama /var/lib/ollama/models || { echo "getfacl exit $?; inconclusive"; set -- "$1" "$2" 3; }
      if [ "$2" != NONE ]; then
        docker ps --format 'table {{.Names}}\t{{.Ports}}' || { echo "docker ps exit $?; inconclusive"; set -- "$1" "$2" 3; }
        docker inspect --format '{{json .HostConfig.PortBindings}} {{json .NetworkSettings.Networks}} {{json .Config.User}}' -- "$2" || { echo "docker inspect exit $?; inconclusive"; set -- "$1" "$2" 3; }
      fi
      echo "block exit $3; nothing above is classified, so judge every listing against the comparisons below"
      exit "$3"
      ;;
  esac
)
```

The exposed comparison shows unintended listeners/publications, root execution, or writable model state. The fixed comparison shows the intended private path and dedicated identity. Check existing regular files and ACLs, service-home signing keys, root-owned configuration, and proxy key separation too.

REASONED: container-only inspection and this block's exit statuses, from the block's own code and the C1 and C5 references cited before the block; no deployment was inspected. For container-only deployments, systemd inspection may be inapplicable. Inspect the actual container process identity and mounted store; an empty configured container user is not proof of an unprivileged process. Inspect every relevant network namespace, IPv4/IPv6 address, publication, and network attachment. The block exits 3 when any inspection command fails, as the systemd or store commands can on a container-only deployment or with the store elsewhere, 2 when `ss` is not installed and no inspection command failed, and otherwise 0, because it classifies nothing and leaves every listing for you to judge.

From an unrelated unprivileged test account, run `test -w /var/lib/ollama/models` and inspect its exit status; writable access is a failure of the proposed policy. In an isolated store, confirm that identity cannot create a disposable file, while the service identity can perform the approved import/inference workflow. Pair ownership inspection with V4's successful administrative operation and V3's inference control.

### V2. Probe direct-backend bypass from another machine (REASONED: direct-origin reachability and approved-proxy inference comparison follow C1 binding documentation; no live target or external observer. The local address-guard cases above establish no network outcome)

No deployed target or disallowed external observer is available. Use the actual deployment address, not a documentation address. For IPv6, supply the actual address enclosed in square brackets inside the quotes. Repeat for each deployed address family and publication:

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_PUBLIC_IP'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "supply exactly one address; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*YOUR_PUBLIC_IP*|*'<'*|*'>'*|*example.com*|""|*@*|*/*|*\?*|*\#*|*[[:space:]]*|203.0.113.*|198.51.100.*|192.0.2.*|*2001:db8*)
      echo "supply the real deployment address; not probing"; exit 2 ;;
    *)
      if curl -q -g -sS -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
        -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' \
        "http://$1:11434/api/tags"; then
        echo "FINDING: the direct port answered over HTTP, which establishes the bypass even if its status is an error"; exit 1
      else
        set -- "$1" "$?"                # the address, then curl's exit status
        case "$2" in
          7|28) echo "curl exit $2, no connection (refused, unreachable or timed out): unclassified observation; it is the fixed result only when V1 and firewall evidence attribute it to the disallowed remote path and inference through the approved proxy succeeds"; exit 0 ;;
          *) echo "curl exit $2: read err above; a resolver failure, local socket error or other local error is inconclusive"; exit 3 ;;
        esac
      fi
      ;;
  esac
)
```

Exposed: an HTTP response establishes that the direct port answered, even if its status is an error. Fixed: refusal or timeout attributable to the actual disallowed remote path, paired with successful inference through the approved proxy.

Read `err`, not merely the exit number. A resolver failure, local socket error, wrong address, stopped service, or unexplained timeout is inconclusive. Correlate the result with V1 and firewall evidence. The block exits 1 when the direct port answers over HTTP, 0 with an unclassified-observation line when curl exits 7 or 28 (no connection, or a timeout), which you still attribute as above, and 3 on any other curl failure. See C1's [binding documentation](https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx).

### V3. Verify authentication and TLS with a real inference request (REASONED: cited Ollama, proxy and curl behavior; no live proxy, certificates, credentials or model)

No proxy deployment, trusted certificates, credentials, or loaded model is available. Prepare a small approved local model and a request body file such as `chat.json`:

```json
{
  "model": "REPLACE_WITH_APPROVED_LOCAL_MODEL",
  "messages": [
    {
      "role": "user",
      "content": "Reply with the word ready."
    }
  ],
  "stream": false,
  "options": {
    "num_predict": 16
  }
}
```

Replace the model before probing. Keep fixture prompts non-sensitive.

Prepare client configuration files with mode `0600` in a private directory. For Basic authentication, the correct-credential file contains:

```text
user = "admin:REPLACE_WITH_PASSWORD"
```

Prepare a separate file containing the deliberately wrong password and a separate empty file for no credentials. For bearer authentication, use this file content instead:

```text
header = "Authorization: Bearer REPLACE_WITH_TOKEN"
```

For mTLS, add the required trust and certificate paths:

```text
cacert = "/absolute/path/to/server-ca.pem"
cert = "/absolute/path/to/client-cert.pem"
key = "/absolute/path/to/client-key.pem"
```

Use the normal trust store when appropriate. Escape backslashes and double quotes according to curl's configuration-file syntax. Never put live passwords, bearer tokens, or Access secrets on the command line.

Inspect these files before use: allow only the intended authentication, trust, client-certificate, and test-header settings. Do not include URLs, redirects, proxy settings, insecure TLS options, extra transfers, or request/output overrides. An intentional `resolve` entry can support a hostname-negative test against the same server address. The files are trusted test inputs, not a safe format for untrusted instructions.

The following reusable probe reads the client configuration on stdin, keeping credentials off curl's argv. No credential is typed into the command, and the block's `set +x` turns tracing off before it reads the file, so neither shell history nor `set -x` tracing records the credentials; write the file with an editor, not a shell command, so preparing it does not put them in history either. Stdin closes the argv channel only: the account owner and root can still read the file and the memory of the block's subshell, whose placeholder check reads the file, and of curl. It supports the concrete operations in V3 through V8. Use `/dev/null` as the body for GET, HEAD, and OPTIONS. Use `application/octet-stream` for blob bytes and `application/json` for JSON fixtures. The probe exits 0 when the transfer completes, leaving every response for you to compare with the table for your check, and 3 when curl fails; for the wrong-trust, wrong-hostname and client-certificate negatives that failure is the expected fixed result, so read its `err=` text as well as its status.

```bash
(
  set +x
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_ENDPOINT_URL' 'POST' 'REPLACE_WITH_BODY_FILE_OR_DEV_NULL' 'REPLACE_WITH_CURL_CONFIG_FILE' 'application/json'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 5 ] || { echo "supply URL, method, body file, client config, and content type"; exit 2; }
  case "$1|$2|$3|$4|$5" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|'|'*|*'|'|*'||'*|*[[:cntrl:]]*)
      echo "replace every value; not probing"; exit 2 ;;
    *)
      case "$1" in
        *@*|*\?*|*\#*|*[[:space:]]*) echo "use a URL without credentials, query, or fragment"; exit 2 ;;
        https://*|http://127.0.0.1:11434/*|http://localhost:11434/*) ;;
        *) echo "use HTTPS, or the administrative loopback endpoint"; exit 2 ;;
      esac
      case "$2" in
        GET|HEAD|OPTIONS)
          [ "$3" = /dev/null ] || { echo "use /dev/null for this method"; exit 2; } ;;
        POST|DELETE) ;;
        *) echo "unsupported test method"; exit 2 ;;
      esac
      case "$5" in
        application/json|application/octet-stream) ;;
        *) echo "choose the fixture content type"; exit 2 ;;
      esac
      [ -r "$3" ] || { echo "body file is unreadable"; exit 2; }
      [ -r "$4" ] || { echo "client config is unreadable"; exit 2; }
      case "$(< "$4")" in
        *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*)
          echo "replace placeholders in the client config; not probing"; exit 2 ;;
      esac
      case "$2" in
        HEAD) set -- "$4" --head --url "$1" ;;
        GET|OPTIONS) set -- "$4" --request "$2" --url "$1" ;;
        POST|DELETE) set -- "$4" --request "$2" --url "$1" \
          --header "Content-Type: $5" --data-binary "@$3" ;;
      esac
      if curl -q -g -sS --config - --noproxy '*' --connect-timeout 5 --max-time 120 \
        --dump-header /dev/stderr \
        -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' \
        "${@:2}" < "$1"; then
        echo "unclassified observation: compare the headers, body and http= line above with the table for the check you are running"
      else
        echo "curl exit $?: the transfer failed; inconclusive, though a certificate or handshake failure is the expected fixed result of a wrong-trust, wrong-hostname or client-certificate negative, so read err above"
        exit 3
      fi
      ;;
  esac
)
```

For the public authentication comparison, use the actual HTTPS `/api/chat` URL, POST, and the same valid `chat.json` each time:

| Client configuration | Exposed comparison | Fixed comparison |
|---|---|---|
| Empty, no credentials | Unprotected API completes inference. | Basic/bearer boundary rejects with 401 and no upstream inference request. |
| Deliberately wrong credentials | Credentials do not protect an unprotected API. | Request is rejected, never accepted inference. |
| Correct credentials | Request completes. | HTTP 200 with a completed, successful inference response. |

For mTLS, retain a valid client certificate while testing missing Basic credentials if both mechanisms are deliberately required. Test missing and untrusted client certificates separately; both must fail before inference. nginx may report a TLS failure or a proxy rejection depending on the failure stage.

Repeat the valid request with a correct hostname and trust chain, an unrelated valid CA trust file, and a wrong hostname directed to the same server. Correct trust succeeds; wrong trust or hostname must fail certificate verification. Do not use `-k`. A missing local certificate file is not evidence that the server enforced mTLS.

For Access, use protected client-config header entries for the required service-token fields. Verify missing/wrong-token denial and valid-token inference. For a human MFA policy, use the actual browser login flow; a service-token request does not demonstrate MFA.

Retain the original model-inventory check with corrected expectations: use V3 with `GET /api/tags` and `/dev/null`. On the public C3 boundary, expect 404 even with valid inference credentials. On the approved private administrative path, expect 200 with model-list JSON. A public 404 is not an authentication test.

A streamed 200 alone does not prove model work succeeded. Inspect the complete response, including completion and error fields. Transport failures, rate-limit rejection, missing models, and timeouts are distinct from authentication denial. Inspect proxy and upstream records without logging credentials or bodies.

These comparisons follow C2's [authentication reference](https://docs.ollama.com/api/authentication), [nginx Basic authentication](https://nginx.org/en/docs/http/ngx_http_auth_basic_module.html), [client-certificate verification](https://nginx.org/en/docs/http/ngx_http_ssl_module.html#ssl_verify_client), and the [curl manual](https://curl.se/docs/manpage.html).

### V4. Exercise management authorization and blob writes (REASONED: management, account, experimental and blob operations, public denial and private administrative success, cleanup and public-chat controls follow C3 API methods and route registration; no isolated model store, registry, identities or proxy. Python 3.14.4 json.loads accepted the four literal JSON bodies in this table; that is syntax only. sha256sum on a disposable file containing OLLAMA_VERIFY_FIXTURE followed by LF returned 9b18adfd436acae378346d9452646db562690662d43ded1df7adceea38540c95; no blob upload or existence check ran)

**REASONED:** no isolated model store, registry fixtures, administrative identity, or live proxy is available. Use V3's reusable probe against three paths: an isolated exposed catch-all proxy, the fixed public inference proxy, and the private administrative endpoint. Direct loopback requests run on the service host with an empty client configuration.

Prepare valid, disposable fixtures. The exposed comparison must demonstrate actual authorized operations, not malformed-request errors.

| Operation for V3 | Body or fixture | Evidence to retain |
|---|---|---|
| `POST /api/copy` | `{"source":"REPLACE_WITH_SOURCE_MODEL","destination":"REPLACE_WITH_DISPOSABLE_ALIAS"}` | Alias appears in private `/api/tags` inventory after exposed/private success. |
| `POST /api/create` | `{"model":"REPLACE_WITH_DISPOSABLE_MODEL","from":"REPLACE_WITH_REVIEWED_GGUF_MODEL","stream":false}` | Successful completion and the new definition in private inventory. |
| `POST /api/pull` | C7's pull body, substituted for a small controlled registry fixture. | Successful transfer and the expected deployed digest. |
| `POST /api/push` | `{"model":"REPLACE_WITH_CONTROLLED_EXPORT_MODEL","insecure":false,"stream":false}` | Authorized test registry receives the intended disposable artifact. |
| `DELETE /api/delete` | `{"model":"REPLACE_WITH_DISPOSABLE_ALIAS"}` | Only the selected disposable name disappears. |
| `POST /api/blobs/sha256:REPLACE_WITH_FIXTURE_SHA256` | A small file containing unique non-sensitive bytes; use `application/octet-stream`. | Upload succeeds and subsequent HEAD finds that digest. |
| `HEAD /api/blobs/sha256:REPLACE_WITH_FIXTURE_SHA256` | `/dev/null` | Existence result distinguishes a stored fixture from a fresh absent digest. |

Substitute the JSON values before use. Calculate the blob fixture's SHA-256 locally with `sha256sum` and place its hexadecimal digest after `sha256:` in the URL. Never use a disk-filling workload.

For the fixed public boundary, every management request must return 404 without an upstream request or state change, even with valid inference credentials. Confirm the operation succeeds for the private administrator, then remove disposable aliases/models and clean up the isolated registry/store. Do not manually delete shared production blobs.

Also test the account and experimental methods registered at the pin: POST to `/api/me`, `/api/signout`, `/api/experimental/web_search`, and `/api/experimental/web_fetch`, GET to `/api/balance`, `/api/usage`, and `/api/experimental/model-recommendations`, plus DELETE to `/api/user/keys/:encodedKey`, using an isolated account where state can change. For the balance and usage routes, a private success returns the signed-in account's data, so use a test account. Inventory the deployed desktop proxy route and unused compatibility endpoints, including `POST /v1/systemone` and the `/v1/audio/` routes, and confirm public denial. Never sign out or delete keys on a production account merely to obtain evidence.

Use proxy upstream-status records or equivalent observation to distinguish a proxy-generated 404 from an upstream error. Pair each denial set with successful public `/api/chat`.

The discriminators are C3's [API methods](https://github.com/ollama/ollama/blob/v0.40.14/docs/api.md), [route registration](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go), and [create validation](https://github.com/ollama/ollama/blob/v0.40.14/server/create.go).

### V5. Compare browser origins and preflights (REASONED: required/unrelated/built-in/missing Origin, preflight, actual browser calls and authenticated/anonymous POST comparisons follow C4 AllowedOrigins and C2 proxy policies; no live backend, proxy or browser fixture. The header text was not exercised by a browser)

No live backend or authorized browser frontend is available. Use V3 with OPTIONS, `/dev/null`, and a client configuration containing these non-secret test headers:

```text
header = "Origin: https://REPLACE_WITH_BROWSER_ORIGIN"
header = "Access-Control-Request-Method: POST"
header = "Access-Control-Request-Headers: content-type"
```

Run against the private test backend to isolate Ollama's CORS behavior, then against the actual frontend boundary. Repeat with the required origin, an unrelated controlled origin, representative built-in origins, and no Origin header.

Exposed: with wildcard additional origins, the unrelated browser origin is permitted. Fixed: unnecessary additional origins are refused; required origins still work. Inspect access-control response headers and perform an actual browser request, because curl itself does not enforce CORS.

For the C2 POST-only proxy, an OPTIONS request is not forwarded; the exact status depends on the variant: the nginx Basic-auth example returns 405, the nginx bearer variant returns 401 for a missing or wrong credential and 405 once a valid one passes, and the Caddy example falls through to 404. Each denies forwarding, so any of these is the expected non-browser policy, not a successful cross-origin frontend deployment. If a cross-origin browser frontend is required, demonstrate its separately designed preflight/authentication flow, including any authorization header it needs.

Repeat the actual POST with and without Origin. Removing Origin must not bypass proxy authentication; a non-browser caller with valid credentials is not constrained by CORS. The built-in origins remain as described by C4's [AllowedOrigins implementation](https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go).

### V6. Exercise finite admission and resource budgets (REASONED: admission, body size, model loading, expiry, parameter overrides, queue capacity and recovery comparisons follow C6 scheduler/types and nginx limit references; no inference runtime, loaded model, capacity fixture or GPU. Local V6 marker files above demonstrate child completion only, not either limiter or successful inference)

No inference runtime, loaded models, capacity fixture, or GPU is available. The following probe launches exactly eight requests, each bounded to 120 seconds, waits for every child, and retains separate results. Like V3's reusable probe, it reads the client configuration on each curl's stdin, keeping credentials off curl's argv. No credential is typed into the command, and the block's `set +x` turns tracing off before it reads the file, so neither shell history nor `set -x` tracing records the credentials; write the file with an editor, not a shell command, so preparing it does not put them in history either. Stdin closes the argv channel only: the account owner and root can still read the file and the memory of the block's subshell, whose placeholder check reads the file, and of each curl. Use only an isolated capacity test with the same small, valid chat fixture as V3:

```bash
(
  set +x
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_HTTPS_CHAT_URL' 'REPLACE_WITH_CHAT_BODY_FILE' 'REPLACE_WITH_CURL_CONFIG_FILE'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "supply URL, body file, and client config"; exit 2; }
  case "$1|$2|$3" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|'|'*|*'|'|*'||'*|*[[:cntrl:]]*)
      echo "replace every value; not probing"; exit 2 ;;
    *)
      case "$1" in
        *@*|*\?*|*\#*|*[[:space:]]*) echo "use a URL without credentials, query, or fragment"; exit 2 ;;
        https://*/api/chat) ;;
        *) echo "use the HTTPS chat URL"; exit 2 ;;
      esac
      [ -r "$2" ] || { echo "body file is unreadable"; exit 2; }
      [ -r "$3" ] || { echo "client config is unreadable"; exit 2; }
      case "$(< "$3")" in
        *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*)
          echo "replace placeholders in the client config; not probing"; exit 2 ;;
      esac
      set -- "$1" "$2" "$3" "$(if mktemp -d; then printf '\n0'; else printf '\n%s' "$?"; fi)"
      set -- "$1" "$2" "$3" "${4%%$'\n'*}" "${4##*$'\n'}"   # URL, body file, client config, the result directory, then mktemp's exit status
      [ "$5" = 0 ] && [ -n "$4" ] || { echo "cannot create result directory"; exit 3; }
      chmod 700 "$4" || { echo "cannot protect results"; exit 3; }
      set -- "$1" "$2" "$3" "$4"
      while [ "$#" -lt 12 ]; do         # eight transfers: each appends its process ID, and $(($# - 3)) numbers its result files 1 to 8
        curl -q -g -sS --config - --noproxy '*' --connect-timeout 5 --max-time 120 \
          --request POST --header 'Content-Type: application/json' --data-binary "@$2" \
          --output "$4/$(($# - 3)).body" \
          -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1" \
          < "$3" > "$4/$(($# - 3)).status" \
          2> "$4/$(($# - 3)).stderr" &
        set -- "$@" "$!"
      done
      set -- "$4" 0 "${@:5}"            # the result directory, the block's status so far, then the eight process IDs
      while [ "$#" -gt 2 ]; do
        if wait "$3"; then
          :
        else
          echo "one transfer failed; inspect its status and stderr"
          set -- "$1" 3 "${@:3}"        # records the failure; the block exits with status 3 below
        fi
        set -- "$1" "$2" "${@:4}"
      done
      printf 'Results retained in %s\n' "$1"
      echo "block exit $2; the eight results are not classified, so judge them against the exposed and fixed comparisons below"
      exit "$2"                         # status 3 if any transfer failed; otherwise 0, and you judge the results
      ;;
  esac
)
```

Exposed: without admission limits, the workload reaches Ollama subject to its own scheduler. Fixed: excess requests receive the configured proxy 429 responses while accepted requests complete. Inspect limiter/upstream evidence to identify which control acted. After the bounded burst ends and the rate budget recovers, repeat one ordinary request and require successful inference.

A fast fixture may not hold four requests active simultaneously. To demonstrate the connection limit separately, use a bounded fixture that keeps four accepted requests active, pace their admission within the rate budget, then attempt one additional request from another test client. It must be rejected while the accepted requests complete; freeing a slot must permit another request. An eight-request burst alone does not prove both limiters acted.

Using V3, also perform these comparisons:

| Operation | Exposed versus fixed evidence |
|---|---|
| Submit a valid chat JSON file of 1,048,577 bytes, using harmless JSON whitespace for padding. | Without the selected body cap it can reach upstream; the 1 MiB public limit returns 413 without an upstream request. Pair with a small accepted body. |
| Request a second approved small model and inspect private `GET /api/ps`. | Compare automatic loaded-model behavior with the explicit one-model budget; record loading, eviction, and recovery. |
| Send a request without `keep_alive`, then inspect `/api/ps` before and after the selected expiry. | Compare the five-minute default with the configured one-minute default, allowing observation overhead. |
| Attempt `options.num_ctx: 8192`, `options.num_predict: 256`, `keep_alive: "2m"`, and a disallowed model under the illustrative gateway policy. | Direct Ollama may accept overrides; the validating gateway must reject or constrain them. Environment defaults and the nginx path policy alone do not pass this check. |
| Fill the scheduler queue with an isolated bounded workload that actually enters it. | Compare default and explicit queue capacities using scheduler observations and completed requests. Do not infer that the seventeenth HTTP request must return 503. |

The public four-active-request budget may prevent a single test client from filling Ollama's sixteen-entry scheduler queue. Test scheduler behavior separately through the isolated private test path, with an explicit workload bound and cleanup. Do not remove production proxy limits.

These comparisons follow C6's [scheduler](https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go), [request override types](https://github.com/ollama/ollama/blob/v0.40.14/api/types.go), and nginx [request](https://nginx.org/en/docs/http/ngx_http_limit_req_module.html), [connection](https://nginx.org/en/docs/http/ngx_http_limit_conn_module.html), and [body](https://nginx.org/en/docs/http/ngx_http_core_module.html#client_max_body_size) limits.

### V7. Check provenance, cloud disablement, and administrative egress (REASONED: digest approval, private inventory, public mutation denial, allowed/disallowed registry transfers, cloud-enabled/disabled inference and local-model controls follow C7 and C8; no approved artifacts, controlled registries, cloud identity or live server)

**REASONED:** no approved artifact inventory, controlled registry, cloud credentials, or live server is available.

Use V3 for private `GET /api/tags`. Compare each deployed model digest with the independently approved inventory. For a GGUF import, compare `sha256sum /srv/ollama-import/app.gguf` with the approved artifact checksum before import. The raw GGUF SHA-256 and a model manifest digest are different identifiers; record each for its purpose.

Exposed: callers can install or export arbitrary chosen material through public management. Fixed: V4's public mutations are denied, administrative provisioning yields the approved model digest, and ordinary inference succeeds. Where registry exclusivity is required, compare an approved transfer with a small transfer to a separately controlled disallowed registry. The egress boundary must deny the latter without blocking the former.

For C8, use V3's POST `/api/chat` with a currently authorized cloud-model fixture and a non-sensitive prompt. In the isolated cloud-enabled state, establish a completed response. After setting `OLLAMA_NO_CLOUD=1` and restarting, require a cloud-disabled refusal, then repeat the local-model positive control. An invalid model or missing upstream credential is not proof of cloud disablement.

Sources: C7's [model inventory](https://docs.ollama.com/api/tags) and [transfer implementation](https://github.com/ollama/ollama/blob/v0.40.14/server/images.go), and C8's [cloud-disable documentation](https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx).

### V8. Inspect diagnostics, profiling, and prompt captures (REASONED: public/private diagnostics, actual profiling availability, public-chat controls and debug-enabled/disabled capture inspection follow C9 router/logger; no running binary, service temporary namespace or diagnostic fixtures. Python 3.14.4 json.loads accepted the literal show-request body; it establishes syntax only. At v0.34.2, default-tag go list runs for linux, darwin and windows amd64, twelve further platform, cgo and tag variants, and the 182 of 227 runs in a 22 October 2026 Go 1.26.5 platform, cgo and tag-set sweep that exited 0 listed no net/http/pprof or runtime/pprof dependency; the sweep's other 45 runs failed, none ran at v0.40.14, and none establishes a runtime response)

**REASONED:** no running binary, diagnostic fixtures, or service temporary directory is available.

Use V3's probe with valid public inference credentials and then through the private administrative path:

| Method | Path | Body |
|---|---|---|
| GET | `/` | `/dev/null` |
| GET | `/api/version` | `/dev/null` |
| GET | `/api/status` | `/dev/null` |
| GET | `/api/tags` | `/dev/null` |
| GET | `/api/ps` | `/dev/null` |
| POST | `/api/show` | `{"model":"REPLACE_WITH_APPROVED_LOCAL_MODEL"}` in a substituted fixture file |
| GET | `/debug/pprof/` | `/dev/null` |

Exposed: registered operational routes disclose their responses through the catch-all boundary. Fixed: public requests return 404 without reaching upstream, while private administrative diagnostics still work. Pair the denial set with successful public chat.

For `/debug/pprof/`, first observe the actual private binary; this guide's source trace does not establish its response. This guide's source assessment is that first-party v0.34.2 registers no pprof handler, and the `go list` runs at v0.34.2 for the platform, cgo and tag combinations listed in C9 found no `net/http/pprof` or `runtime/pprof` dependency in any run that loaded; C9 did not resolve the v0.40.14 import graphs, which remain unestablished. Builds with Go releases outside the 1.26.x patch line, `go list` graphs for the other 1.26.x releases (C9 gives only an inference from source), the C9 runs that failed, the tagged sets on platforms not run, other tag sets, exposure through the served mux in such builds (C9 gives only this guide's inference for the builds that loaded) and shipped-binary pprof availability remain unestablished. If no handler exists, record that absence; do not call it proof that debug settings disabled profiling. If it exists, retain the observed response and demonstrate public denial.

For logging, use an isolated service and a unique non-sensitive prompt. With request debugging deliberately enabled only for the comparison, send one completed V3 request and inspect the service's actual temporary-directory namespace for `ollama-request-logs-*`, request bodies, and replay scripts. Then apply C9, restart, send another completed request, and verify that no new request capture is created. Account for a service-specific `TMPDIR` or private temporary namespace. Retain timestamps and file evidence without sharing captured prompts or credentials, then clean up the test captures.

Expected behavior follows C9's [router](https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go) and [request logger](https://github.com/ollama/ollama/blob/v0.40.14/server/inference_request_log.go).

### Native proxy parsing (REASONED: native acceptance and its limits follow the linked nginx/Caddy command references; neither executable is on PATH and deployment certificate/password files are unavailable. Neither native validation command ran)

Parsing is an offline check, but it was **not demonstrated here** because nginx and Caddy are absent. On the deployment host, run `nginx -t` against the assembled configuration and real referenced certificate/password files before reloading. For the Caddy alternative, run `caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile`.

These commands validate configuration acceptance; they do not prove authentication, management denial, TLS enforcement, or resource behavior. Avoid sharing `nginx -T` output from a bearer configuration because it contains the shared token. See the [nginx command reference](https://nginx.org/en/docs/switches.html) and [Caddy validation reference](https://caddyserver.com/docs/command-line#caddy-validate).

### Verification scope and local work (REASONED: service-comparison and native-parsing prerequisites from V1-V8 and the cited sources; no authorized deployment, external observer, service credentials or native proxy binaries. Historical local observations above are not new deployment evidence)

| Check scope | Status | Procedure and prerequisites |
|---|---|---|
| Service behavior | REASONED from the cited v0.40.14 sources and vendor documentation; not demonstrated | On v0.40.14 or a newly reviewed explicit pin, load the assembled service/proxy configuration and reproduce every applicable exposed/fixed comparison above in isolated states. Record binary/image identity, effective configuration, commands, responses, upstream observations, completed positive controls, state changes, and cleanup without secrets. Include (1 of 2): IPv4/IPv6 and Docker bypass paths; absent/wrong/correct authentication; TLS trust and mTLS negatives; all management methods and blob writes; browser preflights and actual calls; finite admission, scheduler observations, parameter overrides, and recovery. The items to include (2 of 2): effective identity, ACLs, and model digests; controlled registry transfers; cloud disablement; diagnostic denial, prompt-capture behavior, and actual profiling availability. Use CPU fixtures where sufficient and GPU hardware for GPU-specific claims. Configuration inspection or `nginx -t` alone does not demonstrate service behavior. |
| Native proxy parsing | Not demonstrated here because nginx and Caddy are absent; retained local work | Run the offline parsing checks above against the assembled configuration and real referenced certificate/password files. |

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- Ollama v0.40.14 release (checked November 2026): https://github.com/ollama/ollama/releases/tag/v0.40.14
- Ollama release commit (checked November 2026): https://github.com/ollama/ollama/commit/9a3e8177767245acc62b735eba7d5d8a553606d0
- Ollama repository at the reviewed tag, its file list (checked November 2026): https://github.com/ollama/ollama/tree/v0.40.14
- Ollama FAQ: https://docs.ollama.com/faq
- Pinned FAQ, service environment, proxy examples, overrides, and cloud disablement (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx
- Ollama local API authentication (rolling documentation, checked September 2026): https://docs.ollama.com/api/authentication
- Official Docker image wildcard listener (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/Dockerfile
- Linux service instructions (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/docs/linux.mdx
- Linux installer and service account (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/install.sh
- Linux installer `configure_systemd` account creation and `ollama` group membership for the invoking user (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/install.sh#L197-L212
- Environment configuration and additive origins (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go
- API methods and blob operations (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/docs/api.md
- HTTP serving, routes, and host middleware (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go
- Route registration behind the CORS and host middleware, including the account, experimental, `/v1/systemone`, audio and `/api/codex` routes (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2385-L2450
- Account balance and usage handlers that drop the caller's `Authorization` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2684-L2696
- Cloud proxy default base URL and signing host (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/cloud_proxy.go#L28-L31
- Cloud proxy disabled-status refusal, header copy, signing call and send (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/cloud_proxy.go#L176-L226
- Cloud proxy request signing with `auth.Sign` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/cloud_proxy.go#L408-L422
- Client-side outbound signing (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/api/client.go
- Server startup and administrative import (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go
- CLI entry point (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/main.go#L3-L13
- CLI entry point at v0.34.2, the main package the `go list` sweeps resolved (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/main.go#L3-L13
- Serve command definition (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2644-L2650
- CLI constructor NewCLI (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2541-L2831
- Serve command registration (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2809-L2831
- Serve command server path (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2269-L2285
- Router attachment (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2523-L2528
- HTTP server handler and pprof comment (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2537-L2547
- HTTP listener serve call (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2588-L2593
- HTTP server import block (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L3-L55
- Serve function (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2472-L2596
- cmd package imports, including the server package (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L3-L60
- server package clause (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1
- integration test build tag at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/integration/basic_test.go#L1
- fast, release and library test build tags at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/integration/reg_groups_test.go#L1
- generate test build tag at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/integration/generate_jinja_test.go#L1
- updater_live test build tag at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/app/updater/updater_live_test.go#L1
- readline terminal build constraint and syscall import at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/readline/term.go#L1-L7
- Go module `go` line at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/go.mod#L3
- Go module `go` line at v0.40.14 (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/go.mod#L3
- Go module requirement blocks at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/go.mod#L5-L91
- Go module checksums at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/go.sum
- `github.com/dgryski/trifles` `cstbucket` command package clause and imports at v0.0.0-20200323201526-dd97f9abfb48 (checked October 2026): https://github.com/dgryski/trifles/blob/dd97f9abfb48/cstbucket/main.go#L1-L17
- `github.com/dgryski/trifles` `fastpprof` command package clause and imports at v0.0.0-20200323201526-dd97f9abfb48 (checked October 2026): https://github.com/dgryski/trifles/blob/dd97f9abfb48/fastpprof/main.go#L1-L13
- `github.com/dgryski/trifles` `jumpreplica` command package clause and imports at v0.0.0-20200323201526-dd97f9abfb48 (checked October 2026): https://github.com/dgryski/trifles/blob/dd97f9abfb48/jumpreplica/main.go#L1-L18
- `github.com/dgryski/trifles` `lz` command package clause and imports at v0.0.0-20200323201526-dd97f9abfb48 (checked October 2026): https://github.com/dgryski/trifles/blob/dd97f9abfb48/lz/lz.go#L1-L11
- `github.com/dgryski/trifles` `matcher` command package clause and imports at v0.0.0-20200323201526-dd97f9abfb48 (checked October 2026): https://github.com/dgryski/trifles/blob/dd97f9abfb48/matcher/main.go#L1-L13
- `github.com/dgryski/trifles` `quantiles` command package clause and imports at v0.0.0-20200323201526-dd97f9abfb48 (checked October 2026): https://github.com/dgryski/trifles/blob/dd97f9abfb48/quantiles/main.go#L1-L22
- `github.com/dgryski/trifles` `udprelay` command package clause and imports at v0.0.0-20200323201526-dd97f9abfb48 (checked October 2026): https://github.com/dgryski/trifles/blob/dd97f9abfb48/udprelay/main.go#L1-L26
- `github.com/dgryski/trifles` `fastpprof` command `/debug/pprof` handlers at v0.0.0-20200323201526-dd97f9abfb48 (checked October 2026): https://github.com/dgryski/trifles/blob/dd97f9abfb48/fastpprof/main.go#L16-L42
- `github.com/klauspost/compress` `s2/cmd/s2c` command package clause and imports at v1.18.3 (checked October 2026): https://github.com/klauspost/compress/blob/v1.18.3/s2/cmd/s2c/main.go#L1-L27
- `golang.org/x/text` `collate/tools/colcmp` command package clause and imports at v0.30.0 (checked October 2026): https://github.com/golang/text/blob/v0.30.0/collate/tools/colcmp/colcmp.go#L5-L22
- `github.com/pelletier/go-toml/v2` test file `/debug/pprof` text, first match at v2.2.2 (checked October 2026): https://github.com/pelletier/go-toml/blob/v2.2.2/marshaler_test.go#L1571
- `github.com/pelletier/go-toml/v2` test file `/debug/pprof` text, second match at v2.2.2 (checked October 2026): https://github.com/pelletier/go-toml/blob/v2.2.2/marshaler_test.go#L1649
- Dockerfile Go build stage (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/Dockerfile#L257-L273
- macOS build script Go environment (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_darwin.sh#L88-L89
- CMake Go build step and local payload target (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/cmake/local.cmake#L711-L758
- Windows build script CLI and arm64 builds (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L865-L920
- Windows build script architecture selection, from `ARCH` or host detection (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L210-L230
- Windows build script unconditional `CGO_ENABLED` setting in `checkEnv` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L296
- Windows build script `checkEnv` call before the build steps (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L1299
- Windows build script default CLI build, its `go build` without `GOARCH` and its output directory argument (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L896-L908
- Windows build script selected architecture copied to `TARGET_ARCH` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L231
- Windows build script output directory named from `TARGET_ARCH` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L295
- Release workflow macOS Go setup and build (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L71-L82
- Release workflow Windows Go setup and build (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L354-L378
- Release workflow `GOFLAGS` value (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L13-L25
- Release workflow Windows job `GOFLAGS` environment (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L338
- Release workflow macOS job `GOFLAGS` environment (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L34
- Release workflow `linux-depends` job, its dependency targets and `GOFLAGS` build argument (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L480-L557
- Release workflow `docker-build-push` job, its value-less `GOFLAGS` build argument and environment (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L562-L667
- Desktop app main package constraint and imports at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/app/cmd/app/app.go#L1-L33
- Desktop app loopback listener (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app.go#L186-L196
- Desktop app HTTP server with non-nil handler and serve call (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app.go#L280-L293
- Desktop app UI token-cookie check (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/ui/ui.go#L194-L225
- Desktop app UI mux routes (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/ui/ui.go#L278-L327
- Desktop app managed ollama serve process and its Expose and Browser settings (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L241-L255
- Desktop app embedded web assets directive at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/app/ui/app.go#L15-L16
- Desktop app webview cgo-only import at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/app/webview/webview.go#L51
- macOS build script desktop app npm and Go builds (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_darwin.sh#L200-L216
- Windows build script desktop app builds (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L981-L1005
- Desktop app `app_darwin.go` cgo-only import (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L10
- Desktop app `app_darwin.go` cgo-only import at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/app/cmd/app/app_darwin.go#L10
- Desktop app main package webview cgo-only import at v0.34.2 (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/app/cmd/app/webview.go#L6
- Desktop app Claude gateway listen address and start retry window variables (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L95-L96
- Desktop app Claude gateway reconcile call (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L535
- Desktop app Claude gateway reconcile conditions (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L546-L561
- Desktop app Claude gateway start installed check (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L592-L598
- Desktop app Claude gateway `setClaudeGatewayInstalled` start and conditional stop (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1202-L1229
- Desktop app Claude gateway `prepareClaudeDesktopConnection` start and conditional stop (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1478-L1493
- Desktop app Claude gateway model-mapping start with no existing gateway, and in that case stop on a failed profile change other than restart confirmation (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1645-L1667
- Desktop app Claude gateway model-mapping read of any existing gateway (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1574-L1579
- Desktop app Claude gateway model-mapping failed profile change with an existing gateway, returned without a stop (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1700-L1704
- Desktop app Claude gateway construction and start call (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L614-L631
- Desktop app Claude gateway start retry loop (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L944-L951
- Claude Desktop gateway default listen address (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L23-L26
- Claude Desktop gateway configured listen address copy (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L131-L132
- Claude Desktop gateway listener and HTTP server (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L198-L221
- Claude Desktop gateway routes (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L300-L361
- Claude Desktop gateway host allowlist (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L419-L435
- Claude Desktop gateway credential-header removal, `X-Api-Key` and `Host` rewrite, upstream wait and forwarding (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L363-L380
- Claude Desktop gateway reverse proxy and its transport with a nil `Proxy` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L126-L130
- Claude Desktop gateway upstream readiness wait (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L442-L511
- Claude Desktop gateway body size limits and upstream wait and reuse durations (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L27-L31
- Claude Desktop gateway upstream wait set from its timeout at construction (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L143
- Claude Desktop gateway model routing and body rewrite (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L594-L634
- Claude Desktop gateway model ID and Ollama name match (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L741-L748
- Claude Desktop gateway access error statuses (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L807-L818
- Claude Desktop gateway image-rejection retry (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L636-L724
- Claude Desktop gateway model limit and five fixed route IDs (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_models.go#L16-L35
- Claude Desktop gateway model selection and route assignment (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_models.go#L308-L353
- Claude Desktop gateway built-in model fallback at construction (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L146-L148
- Claude Desktop gateway built-in cloud models (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_models.go#L183-L200
- Claude Desktop gateway model construction and vision mark (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_models.go#L433-L467
- Claude Desktop gateway model list filtered by access (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L519-L555
- Claude Desktop gateway model access rules and plan check (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop_access.go#L55-L124
- Claude Desktop gateway default access state and local-model facts (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L750-L799
- Desktop app Claude gateway upstream from `ConnectableHost` and gateway-port refusal (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L599-L609
- Environment `Host` parsing of `OLLAMA_HOST` and its default (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L20-L60
- Environment `ConnectableHost` loopback substitution (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L62-L83
- Environment `Var` read from the process environment (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L378-L380
- Desktop app UI `app.go` import block (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/ui/app.go#L5-L13
- Desktop app UI `ui.go` import block (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/ui/ui.go#L6-L39
- Desktop app webview package import block (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/webview/webview.go#L53-L60
- Desktop app `app_darwin.go` import block (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L12-L44
- Desktop app main package `webview.go` import block (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/webview.go#L8-L26
- Desktop app UI `extract.go` import block (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/ui/extract.go#L5-L14
- Desktop app `codex_app_darwin.go` import block (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/codex_app_darwin.go#L5-L25
- Desktop app Codex Desktop integration, read whole (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/codex_app_darwin.go
- Desktop app Codex Desktop controller interface and `launch.CodexApp` value (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/codex_app_darwin.go#L35-L49
- Codex Desktop proxy handler, read whole (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go
- Codex Desktop proxy `/api/codex` prefix comment (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L27-L30
- Codex Desktop proxy handler comment on the existing Ollama listener (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L60-L62
- Codex Desktop proxy loopback refusal, prefix, health and status routes (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L157-L177
- Codex Desktop proxy routing to Ollama or the native upstream and managed-key refusal (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L193-L264
- Codex Desktop proxy outbound rewrite and Ollama header reset (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L359-L376
- Codex Desktop proxy status response (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L513-L529
- Codex Desktop proxy loopback remote-address check (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L640-L650
- Codex Desktop proxy headers copied to Ollama (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L675-L681
- Desktop app managed ollama serve restart loop (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L190-L225
- Desktop app ollama binary resolution (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L49-L51
- Windows build script conditional arm64 app build (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L995-L998
- Go go1.26.5 net/http/pprof handler registration (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/net/http/pprof/pprof.go#L96-L106
- Go go1.26.5 http.HandleFunc on DefaultServeMux (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/net/http/server.go#L2870-L2878
- Go go1.26.5 Server Handler default (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/net/http/server.go#L2971
- Go go1.26.5 nil-Handler request dispatch (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/net/http/server.go#L3302-L3306
- Go go1.26.5 go build test-file exclusion (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L83
- Go go1.26.5 build -tags flag (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L236-L240
- Go go1.26.5 net/http `Header.Get` first value (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/net/http/header.go#L43-L51
- Go go1.26.5 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/internal/goversion/goversion.go#L12
- Go go1.26.5 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/go/build/build.go#L354-L355
- Go go1.26.5 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/net/http/pprof/pprof.go#L88
- Go go1.26.5 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.5 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.5 `simd/archsimd/_gen/simdgen` `package main` clause (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/simd/archsimd/_gen/simdgen/main.go#L71
- Go go1.26.5 go tool ignores `_` and `testdata` directories (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L3225-L3226
- Go go1.26.5 internal-directory import rule (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L2811-L2812
- Go go1.26.5 `go test` generated main importing `testing/internal/testdeps` (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/cmd/go/internal/load/test.go#L790-L801
- Go go1.26.5 `LinkerDeps` linker-induced dependencies (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/cmd/go/internal/load/pkg.go#L2638-L2672
- Go go1.26.5 cgo and SWIG implicit imports (checked October 2026): https://github.com/golang/go/blob/go1.26.5/src/cmd/go/internal/load/pkg.go#L1912-L1935
- Go go1.26.0 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.0/src/internal/goversion/goversion.go#L12
- Go go1.26.0 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.0/src/go/build/build.go#L354-L355
- Go go1.26.0 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.0/src/net/http/pprof/pprof.go#L88
- Go go1.26.0 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.0/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.0 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.0/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.1 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.1/src/internal/goversion/goversion.go#L12
- Go go1.26.1 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.1/src/go/build/build.go#L354-L355
- Go go1.26.1 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.1/src/net/http/pprof/pprof.go#L88
- Go go1.26.1 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.1/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.1 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.1/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.2 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.2/src/internal/goversion/goversion.go#L12
- Go go1.26.2 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.2/src/go/build/build.go#L354-L355
- Go go1.26.2 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.2/src/net/http/pprof/pprof.go#L88
- Go go1.26.2 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.2/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.2 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.2/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.3 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.3/src/internal/goversion/goversion.go#L12
- Go go1.26.3 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.3/src/go/build/build.go#L354-L355
- Go go1.26.3 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.3/src/net/http/pprof/pprof.go#L88
- Go go1.26.3 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.3/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.3 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.3/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.4 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.4/src/internal/goversion/goversion.go#L12
- Go go1.26.4 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.4/src/go/build/build.go#L354-L355
- Go go1.26.4 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.4/src/net/http/pprof/pprof.go#L88
- Go go1.26.4 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.4/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.4 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.4/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.6 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.6/src/internal/goversion/goversion.go#L12
- Go go1.26.6 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.6/src/go/build/build.go#L354-L355
- Go go1.26.6 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.6/src/net/http/pprof/pprof.go#L88
- Go go1.26.6 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.6/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.6 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.6/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.7 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.7/src/internal/goversion/goversion.go#L12
- Go go1.26.7 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.7/src/go/build/build.go#L354-L355
- Go go1.26.7 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.7/src/net/http/pprof/pprof.go#L88
- Go go1.26.7 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.7/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.7 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.7/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.8 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.8/src/internal/goversion/goversion.go#L12
- Go go1.26.8 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.8/src/go/build/build.go#L354-L355
- Go go1.26.8 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.8/src/net/http/pprof/pprof.go#L88
- Go go1.26.8 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.8/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.8 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.8/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.9 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.9/src/internal/goversion/goversion.go#L12
- Go go1.26.9 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.9/src/go/build/build.go#L354-L355
- Go go1.26.9 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.9/src/net/http/pprof/pprof.go#L88
- Go go1.26.9 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.9/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.9 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.9/src/simd/archsimd/_gen/simdgen/main.go#L91
- Go go1.26.10 `internal/goversion` `Version = 26` (checked October 2026): https://github.com/golang/go/blob/go1.26.10/src/internal/goversion/goversion.go#L12
- Go go1.26.10 `go/build` release tags derived from `goversion.Version` (checked October 2026): https://github.com/golang/go/blob/go1.26.10/src/go/build/build.go#L354-L355
- Go go1.26.10 `net/http/pprof` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.10/src/net/http/pprof/pprof.go#L88
- Go go1.26.10 `testing/internal/testdeps` import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.10/src/testing/internal/testdeps/deps.go#L23
- Go go1.26.10 `simd/archsimd/_gen/simdgen` command import of `runtime/pprof` (checked October 2026): https://github.com/golang/go/blob/go1.26.10/src/simd/archsimd/_gen/simdgen/main.go#L91
- Create-file validation (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/create.go
- Blob-path validation (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/manifest/paths.go
- Manifest root creation with `os.MkdirAll(path, 0o755)` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/manifest/paths.go#L51-L58
- Blob directory creation with `os.MkdirAll(dirPath, 0o755)` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/manifest/paths.go#L400-L420
- New blob from a stream, set to `0o644` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/manifest/layer.go#L68-L77
- New blob moved from a file, set to `0o644` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/manifest/layer.go#L112-L121
- Legacy-path manifest write, set to `0o644` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/manifest/manifest.go#L1219-L1245
- Manifest stored as a blob, set to `0o644` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/manifest/manifest.go#L1287-L1329
- Copied manifest, set to `0o644` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/manifest/manifest.go#L1331-L1357
- Pull through `downloadBlob` for a model without tensor layers, `pullWithTransfer` otherwise (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1261-L1293
- `downloadBlob` downloading to the blob's store path (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L509-L551
- Pulled blob opened as `-partial` with `0o644`, renamed into place, no `chmod`, redirect target check (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L219-L331
- Blob-download redirect check, same origin within 10 redirects (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L336-L349
- Pulled blob `Prepare`, whose HEAD size request at line 151 passes the caller's options (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L131-L186
- `PullRequest` field `Insecure` with the comment `// Deprecated: ignored` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/api/types.go#L856-L867
- Pull handler passing `Insecure: req.Insecure` to the registry options (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1530-L1532
- Push handler passing `Insecure: req.Insecure` to the registry options (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1584-L1586
- Push refusal of an `http` model name without `insecure` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1047-L1053
- Pull refusal of an `http` model name without `insecure` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1213-L1215
- `transfer` download with `http` base URL and `AllowPrivateHosts` under `insecure` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1502-L1560
- `transfer` upload with `http` base URL and `AllowPrivateHosts` under `insecure` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1594-L1653
- Registry transfers and redirect restrictions (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/images.go
- Registry request helper default redirect policy and `allowedRedirectHosts` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1753-L1822
- Registry and model-name parsing (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/types/model/name.go
- Modelfile reference (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/docs/modelfile.mdx
- Ollama model inventory and digests (rolling documentation, checked September 2026): https://docs.ollama.com/api/tags
- Ollama model details (rolling documentation, checked September 2026): https://docs.ollama.com/api-reference/show-model-details
- Scheduler (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go
- VRAM-dependent context defaults (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/docs/context-length.mdx
- Server startup VRAM-tier default context, 4096, 32768 or 262144 (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2571-L2586
- Server option builder, default `num_ctx` then model and request options (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L139-L173
- Scheduler `num_ctx` floors of 4 and, for multimodal models, 2048 (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L212-L220
- Scheduler `effectiveContext` training-context cap (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L192-L210
- Scheduler setting `num_ctx` to the runner's reported context length after a load (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L735-L740
- Scheduler single load retry with a lower automatic context after an out-of-memory failure (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L694-L708
- Server test for an automatic `num_ctx`: no request or model `num_ctx` and `OLLAMA_CONTEXT_LENGTH` at 0 (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L202-L212
- `reduceAutoNumCtxForLoadOOM`, capping at the training context before stepping down (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L811-L837
- `nextLowerAutoNumCtx`, 32768 above 32768 and 4096 above 4096 (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L953-L961
- Scheduler passing `num_ctx` to `mlxrunner.NewClient` for MLX models (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L631-L634
- Unsigned environment parser returning the default for an invalid value (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L261-L272
- Default options taking `NumCtx` from `OLLAMA_CONTEXT_LENGTH` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/api/types.go#L1237-L1246
- `OLLAMA_CONTEXT_LENGTH` default of 0 (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L229-L230
- Request options and overrides (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/api/types.go
- `ShowResponse` field `System` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/api/types.go#L806-L812
- `GetModelInfo` response with `System: m.System` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1935-L1947
- `ShowHandler` show-cache branch and `GetModelInfo` call (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1831-L1835
- `ShowHandler` cloud model reference branch, cloud cache or `proxyCloudJSONRequest` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1779-L1800
- `ShowHandler` `all_manifests` branch calling `GetAllManifestsInfo` (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1819-L1829
- Request-body logging (checked November 2026): https://github.com/ollama/ollama/blob/v0.40.14/server/inference_request_log.go
- Docker publication and the pre-28.0 same-L2 caveat: https://docs.docker.com/engine/network/port-publishing/
- systemd identities, environment, and umask: https://github.com/systemd/systemd/blob/v257/man/systemd.exec.xml
- nginx Basic authentication: https://nginx.org/en/docs/http/ngx_http_auth_basic_module.html
- nginx TLS and client-certificate verification: https://nginx.org/en/docs/http/ngx_http_ssl_module.html
- nginx locations and request-body size: https://nginx.org/en/docs/http/ngx_http_core_module.html
- nginx conditions and returns: https://nginx.org/en/docs/http/ngx_http_rewrite_module.html
- nginx proxy headers and timeout semantics: https://nginx.org/en/docs/http/ngx_http_proxy_module.html
- nginx request-rate limiting: https://nginx.org/en/docs/http/ngx_http_limit_req_module.html
- nginx connection limiting: https://nginx.org/en/docs/http/ngx_http_limit_conn_module.html
- nginx configuration testing: https://nginx.org/en/docs/switches.html
- Apache htpasswd bcrypt options: https://httpd.apache.org/docs/2.4/programs/htpasswd.html
- OWASP bcrypt work-factor guidance: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
- Caddy Basic authentication: https://caddyserver.com/docs/caddyfile/directives/basic_auth
- Caddy request matchers: https://caddyserver.com/docs/caddyfile/matchers
- Caddy exclusive handles: https://caddyserver.com/docs/caddyfile/directives/handle
- Caddy reverse proxy: https://caddyserver.com/docs/caddyfile/directives/reverse_proxy
- Caddy validation and password hashing: https://caddyserver.com/docs/command-line
- Cloudflare Tunnel origin parameters: https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/configure-tunnels/origin-parameters/
- Cloudflare Access service tokens: https://developers.cloudflare.com/cloudflare-one/access-controls/service-credentials/service-tokens/
- Cloudflare WAF rate-limiting rules: https://developers.cloudflare.com/waf/rate-limiting-rules/
- curl configuration input, timeouts, and write-out variables: https://curl.se/docs/manpage.html


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- ollama: Ollama (v0.40.14)
- ollama-sweep: Ollama (go list sweep and go.sum reading) (v0.34.2)
- ollama-rolling: Ollama documentation (rolling) (unknown)
- docker: Docker Engine localhost boundary (28.0)
- systemd: systemd (v257)
- go: Go (go1.26.5)
- go-1-26-0: Go (go1.26.0)
- go-1-26-1: Go (go1.26.1)
- go-1-26-2: Go (go1.26.2)
- go-1-26-3: Go (go1.26.3)
- go-1-26-4: Go (go1.26.4)
- go-1-26-6: Go (go1.26.6)
- go-1-26-7: Go (go1.26.7)
- go-1-26-8: Go (go1.26.8)
- go-1-26-9: Go (go1.26.9)
- go-1-26-10: Go (go1.26.10)
- trifles: github.com/dgryski/trifles (v0.0.0-20200323201526-dd97f9abfb48)
- compress: github.com/klauspost/compress (v1.18.3)
- x-text: golang.org/x/text (v0.30.0)
- go-toml: github.com/pelletier/go-toml/v2 (v2.2.2)
- nginx: nginx (unknown)
- htpasswd: Apache htpasswd (unknown)
- caddy: Caddy (unknown)
- cloudflare: Cloudflare (unknown)
- owasp: OWASP password guidance (unknown)
- curl: curl (unknown)

Claims (full source mapping in the JSON block below):

- local-auth (REASONED; ollama, ollama-rolling): Local API has no inbound authentication; cloud keys and OLLAMA_AUTH concern upstream signing.
- local-tls (REASONED; ollama): Ollama serves plaintext; an https prefix in OLLAMA_HOST does not enable TLS.
- host-bind (REASONED; ollama, systemd): Standalone default is 127.0.0.1:11434; set OLLAMA_HOST in the service and reload/restart systemd.
- container-bind (REASONED; ollama, docker): Official image sets 0.0.0.0:11434 internally; bridge publication and container binding are separate.
- publication (REASONED; docker): Use 127.0.0.1:11434:11434 with Engine 28.0+; earlier same-L2 access defeats this boundary; unpublished private networks are an alternative.
- host-network (REASONED; ollama, docker): Host networking ignores publication flags; override the image listener and restrict authorized peers.
- basic-auth (REASONED; nginx): nginx server-scope Basic auth protects permitted locations; denied paths/methods may reject before authentication.
- password-hash (REASONED; htpasswd, owasp): Use prompted htpasswd -B -C 12; bare -B defaults to bcrypt cost 5, below the cited minimum 10.
- tls-proxy (REASONED; nginx): Publish authenticated TLS; encrypt the backend leg separately when proxy and Ollama are on different hosts.
- host-header (REASONED; ollama, nginx): Proxy Host localhost:11434 avoids loopback middleware hostname rejection; it is not authentication.
- idle-timeout (REASONED; nginx): proxy_read_timeout 300s limits gaps between reads, not total generation duration.
- caddy-policy (REASONED; caddy): Caddy Basic auth, exact POST /api/chat matcher and fallback deny other paths; supply admission limits separately.
- bearer-policy (REASONED; nginx): Exact nginx bearer comparison is a shared configuration secret without a constant-time guarantee; repeat it in every permitted location.
- mtls (REASONED; nginx): Dedicated client CA and ssl_verify_client require certificate lifecycle management; combine Basic auth only deliberately.
- access (REASONED; cloudflare, nginx): Access authenticates the tunnel; target a loopback policy proxy on 11435 to retain inference-only authorization.
- access-host (REASONED; cloudflare, ollama): originRequest.httpHostHeader and the final proxy retain localhost:11434; keep both local listeners private.
- access-limits (REASONED; cloudflare, nginx): Access authentication supplies no inference budgets; retain proxy limits, optionally add WAF rate limits and trusted client-address handling.
- mfa (REASONED; cloudflare): Human MFA belongs at the fronting identity layer; machine service tokens are not a human MFA flow.
- inference-policy (REASONED; nginx, ollama): Allow only exact required inference paths/methods; broad /api/ or /v1/ prefixes grant excessive authority.
- pull (REASONED; ollama): Keep POST /api/pull private: acquisition consumes storage and network capacity.
- push (REASONED; ollama): Keep POST /api/push private: export has separate upstream authorization.
- create (REASONED; ollama): Keep POST /api/create private: it creates/replaces definitions and processes uploaded model material.
- copy (REASONED; ollama): Keep POST /api/copy private: it creates another model name.
- delete (REASONED; ollama): Keep DELETE /api/delete private: it removes models and associated data.
- blob-write (REASONED; ollama): Keep POST /api/blobs/:digest private: it uploads model-store bytes.
- blob-read (REASONED; ollama): Keep HEAD /api/blobs/:digest private: it reveals blob existence.
- other-routes (REASONED; ollama): Default denial excludes account, experimental, desktop proxy and unused compatibility routes, including v0.40.14's balance and usage routes, which drop caller Authorization and sign ollama.com requests (this guide infers with the server's key). Source reading, not run: the /api/codex handler opens no listener and accepts any loopback TCP peer, which a same-host proxy has only over loopback.
- file-validation (REASONED; ollama): Create validates relative filenames and blob paths; arbitrary host-file access is not established at this pin.
- transfer (REASONED; ollama): Management transfers are egress/disk-fill surfaces; the registry helper's default redirects stay same-host or between hosts allowlisted under ollama.com, ollama.ai, hf.co and huggingface.co, insecure lifts that host check but not the 10-redirect cap, a blob download's direct-URL GET sets its own check but its HEAD size request keeps that default, and no unrestricted SSRF is demonstrated.
- origins (REASONED; ollama): OLLAMA_ORIGINS adds to built-in origins; removing wildcards is neither authentication nor an exclusive-origin policy.
- service-user (REASONED; ollama, systemd): Use a dedicated account and writable store; preserve GPU access and do not assume the container shares installer identity. install.sh adds the invoking user to the ollama group on each run with systemctl, which this guide infers grants no store access under 0700 directories; a group-access setup uses the ollama account or API, or deliberately chooses 0750 directories with systemd UMask=0027.
- store (REASONED; ollama, systemd): Proposed 0700 directories and UMask=0077 need existing-permission/ACL inspection; v0.40.14's layer.go and manifest writers chmod files to 0644, which this guide infers UMask does not mask, while download.go writes pulled blobs with no chmod and transfer-package pulls are unread, so the 0700 directories carry the restriction; separate service configuration and proxy keys.
- model-path (REASONED; ollama): OLLAMA_MODELS relocates models, not the entire service home or signing keys.
- loaded-models (REASONED; ollama): Loaded-model capacity is automatic unless configured; the example selects one model, not a total memory cap.
- parallel (REASONED; ollama): OLLAMA_NUM_PARALLEL defaults to 1.
- queue (REASONED; ollama): OLLAMA_MAX_QUEUE defaults to 512; the example selects 16 without promising the seventeenth HTTP request is refused.
- keep-alive (REASONED; ollama): Keep-alive defaults to five minutes; one minute is the example, and requests can override it.
- context (REASONED; ollama): With OLLAMA_CONTEXT_LENGTH unset, 0 or invalid and no model or request num_ctx, the default is VRAM-dependent 4096/32768/262144 at about 23/47 GiB after overhead (documented 24/48 GiB). The FAQ's 4096 and Modelfile table's 2048 disagree with the code read, where 2048 is only a multimodal floor and the scheduler applies a training-context cap and an OOM step-down; MLX is unread.
- rate (REASONED; nginx): Example nginx source-address rate is 2r/s, burst 4 nodelay, with 429 responses; trusted client-address handling matters behind proxies.
- concurrency (REASONED; nginx): Example nginx server-name budget is four active requests with 429; it does not cap every idle/incomplete connection.
- body-limit (REASONED; nginx): Example body cap is 1 MiB; a larger valid fixture should get 413 without upstream work.
- parameters (REASONED; ollama): Gateway must validate model, num_ctx, num_predict and keep_alive; defaults/path allowlists do not enforce JSON ceilings.
- registry-names (REASONED; ollama): Fully qualified registry names are supported; unqualified names select Ollama's registry and omitted tags select latest.
- provenance (REASONED; ollama, ollama-rolling): Compare deployed tags digests with independent approval; mutable tags/digest equality do not establish publisher trust.
- local-import (REASONED; ollama): CLI imports reviewed local GGUF through a Modelfile; artifact SHA-256 and manifest digest are different identifiers.
- registry-egress (REASONED; ollama): Restrict acquisition/export to administrators and constrain egress; compare approved and controlled disallowed transfers. At v0.40.14 the pull and push handlers pass insecure despite PullRequest's Deprecated: ignored comment; it admits http model names, makes helper request URLs, not redirects, http, skips its redirect host check, sets AllowPrivateHosts and feeds unread transfer redirect checks.
- cloud (REASONED; ollama): OLLAMA_NO_CLOUD=1 disables cloud models and web search after restart; it is not a no-network switch.
- remotes (REASONED; ollama): OLLAMA_REMOTES selects remote-model hosts, not a registry allowlist.
- diagnostics (REASONED; ollama, ollama-rolling): Keep root, version, status, tags, ps and show private; model details can disclose templates and, by source reading of v0.40.14's ShowResponse and GetModelInfo rather than the served page, which documents no system field, system prompts.
- request-logs (REASONED; ollama): Disable OLLAMA_DEBUG and OLLAMA_DEBUG_LOG_REQUESTS; existing request captures/replay scripts need separate cleanup.
- profiling (REASONED; ollama, ollama-sweep): No metrics route was found in the main router; this guide assesses that first-party v0.34.2 code registers no pprof handler, and at v0.40.14 found no pprof import in the server import block, other first-party code being unchecked. Shipped-binary pprof availability remains unestablished: observe the binary, deny public profiling, infer nothing from debug settings.
- profiling-scope (REASONED; ollama-sweep, trifles, compress, x-text, go): Go 1.26.5 go list runs for this guide found neither net/http/pprof nor runtime/pprof in the default-tag v0.34.2 main-package graph for every go tool dist list pair that loaded, cgo off and, where supported, on; five cgo-off android/ios runs failed. This guide infers no go.sum or standard-library package adds either; Go outside 1.26.x, cgo/SWIG output, those runs and served-mux exposure stay open.
- profiling-tags (REASONED; ollama-sweep, go): From source reading, v0.34.2's first-party custom tags integration, fast, generate, release, library and updater_live gate only _test.go files, which go build ignores; appengine and os400 appear only in readline/term.go, importing only syscall. The dependency search ignored build constraints, so which dependency files these tags select was not determined; go list runs show generate selects one.
- profiling-tag-runs (REASONED; ollama-sweep, go, trifles, compress, x-text): Go 1.26.5 go list runs for this guide found neither net/http/pprof nor runtime/pprof in v0.34.2 main-package graphs with tag set updater_live, release,library, appengine, os400 or appengine,os400 on the eight first-class pairs, windows arm64 and aix ppc64, cgo off and on. This guide infers no first-party, go.sum or standard-library file adds either; cgo/SWIG output and Go outside 1.26.x are open.
- profiling-generate (REASONED; ollama-sweep, go): Go 1.26.5 go list runs for v0.34.2 with tag sets containing generate failed on all ten pairs tried, cgo off and on, reporting both uniseg and main packages in dependency github.com/rivo/uniseg v0.4.7; -e reruns listed neither pprof package but marked that package with a load error, so whether such builds import either remains open.
- profiling-go-versions (REASONED; go-1-26-0, go-1-26-1, go-1-26-2, go-1-26-3, go-1-26-4, go-1-26-6, go-1-26-7, go-1-26-8, go-1-26-9, go-1-26-10, go): Source reading, not run: Go 1.26.0 to 1.26.10 except 1.26.5 match 1.26.5: goversion is 26. Ignoring build constraints, only net/http/pprof, testing/internal/testdeps and a package main command import runtime/pprof in non-test files outside cmd and testdata. No such file imports the first two. This guide infers no such release adds either package to the 1.26.5 go list graphs; no graph was checked.
- profiling-deps-scan (REASONED; ollama-sweep, trifles, compress, x-text, go-toml): From source reading, ignoring build constraints, only package main files in the 93 dependency modules with go.sum zip hashes import net/http/pprof or runtime/pprof. Imports followed from first-party packages stay in those modules and the standard library, so this guide infers no such module adds either at those versions. The 15 cached modules with no go.sum zip hash were excluded.
- profiling-mux (REASONED; go, ollama): This guide's inference, not run: Go 1.26.5 net/http/pprof's init registers /debug/pprof/ handlers on http.DefaultServeMux, which a server with a nil Handler, as in v0.40.14's Serve, uses, so a build linking that package would serve them on the Ollama listener, while builds whose go list graph lacks it get none from it.
- profiling-release (REASONED; ollama, ollama-sweep): From this guide's reading of v0.40.14's Dockerfile, build scripts and release workflow, which show intended builds rather than artifact contents, the main package is built with no -tags, and with CGO_ENABLED=1 in the Dockerfile, the darwin build and both Windows CLI builds. Its go.mod declares go 1.26.10, which the Dockerfile uses to choose Go; the go list runs used Go 1.26.5 on v0.34.2.
- profiling-app-runs (REASONED; ollama-sweep): Go 1.26.5 go list -e -deps runs for this guide list no net/http/pprof or runtime/pprof for the v0.34.2 desktop app main package on darwin/windows amd64 and arm64, cgo off and on; linux lists only the error-marked main package. Loaded cells mark app/ui (no app/dist); cgo-off cells cannot load cgo-only app/webview and omit the main package's cgo files with no error, so imports may be incomplete.
- profiling-app-listener (REASONED; ollama, go): From source reading, the app's UI listener is loopback (127.0.0.1:0, or 3001 in dev mode), served by an http.Server with a non-nil Handler whose mux has a token-cookie check on /api/v1 routes, proxy and catch-all routes without it, and no /debug/pprof pattern. This guide's inference, not run: even a build linking net/http/pprof would not serve DefaultServeMux handlers there.
- profiling-app-gateway (REASONED; ollama, go): From source reading, another loopback app listener is the Claude Desktop gateway on 127.0.0.1:11435, in macOS cgo builds, started only when Claude Desktop is installed. Its non-nil Handler refuses non-loopback Host values and a non-empty first Origin, serves four routes, not /debug/pprof, and forwards only POST /v1/messages, stripping caller auth headers, to the app's OLLAMA_HOST; not run.
- profiling-app-gateway-start (REASONED; ollama): Source reading, not run: startup starts the gateway only if Claude Desktop is installed and configured to use it; setClaudeGatewayInstalled, prepareClaudeDesktopConnection and model mapping start it if installed. The first two stop it unless Claude Desktop then uses it (the first not after an auto-mode error); mapping, if none existed, stops it on profile-change errors except restart confirmation.
- profiling-app-release (REASONED; ollama): By this guide's reading of intended builds, not artifacts, build_darwin.sh builds the app package with GOOS=darwin, CGO_ENABLED=1, amd64 and arm64 and no -tags. In build_windows.ps1, buildApp builds it with no -tags, by default setting no GOARCH under its unconditional CGO_ENABLED=1 and, when the cross-compile tools are present, for arm64 (GOOS=windows, GOARCH=arm64, CGO_ENABLED=1).
- desktop-app-server (REASONED; ollama): From source reading, the desktop app serves no HTTP on the Ollama API listener itself: it runs the separate ollama binary with serve and restarts it, copying its environment, setting OLLAMA_HOST=0.0.0.0 when Expose is on and OLLAMA_ORIGINS=* when Browser is on, so Expose or an inherited OLLAMA_HOST can expose that process. No shipped app binary was inspected and no run observed these behaviours.
- verify-inventory (REASONED; ollama, docker, systemd): Inspect namespaces, publication, identity, store and ACLs; local ss output alone does not establish isolation.
- verify-bypass (REASONED; ollama, curl): HTTP means direct 11434 answered; fixed refusal needs the real remote path plus successful proxy inference; local errors are inconclusive.
- verify-auth (REASONED; nginx, ollama, curl): Absent/wrong credentials must refuse while correct credentials complete chat; streamed 200 alone is insufficient.
- verify-tls (REASONED; nginx, curl): Correct trust/hostname succeeds; wrong trust/hostname and missing/untrusted mTLS certificates must fail before inference.
- verify-management (REASONED; ollama): Public management must be denied without upstream mutation; private admin operations and public chat supply positive controls.
- verify-tags (REASONED; nginx, ollama-rolling): Public tags may return 404 with valid credentials; private tags should return model JSON; public 404 is not an authentication test.
- verify-origins (REASONED; ollama, nginx, caddy): Compare unwanted, required and built-in origins with actual browser calls; POST-only proxy preflight refusals differ by variant.
- verify-rate (REASONED; nginx): Eight bounded requests test admission with limiter/upstream evidence and recovery; the burst alone does not demonstrate both limiters.
- verify-concurrency (REASONED; nginx): Hold four accepted requests active within the rate budget, reject another, then confirm a freed slot accepts work.
- verify-scheduler (REASONED; ollama): Compare loading/eviction, keep-alive expiry and actual queue occupancy; public limits can prevent exercising the private queue.
- verify-cloud (REASONED; ollama): Authorized cloud chat works before disablement and refuses afterward while local chat succeeds; invalid credentials/models are inconclusive.
- verify-captures (REASONED; ollama): Compare completed canary requests with logging enabled/disabled in the actual temporary namespace; deny public diagnostics while private controls work.
- proxy-parsing (REASONED; nginx, caddy): nginx -t and caddy validate check configuration acceptance only; native parsing was not demonstrated here.
- curl-version (REASONED; curl): Displayed exitcode and errormsg write-out variables need curl 7.75.0 or later; no tested curl release is recorded.

````json
{
  "schema": 1,
  "checked": "2026-11-06",
  "documentation_checked": "2026-09",
  "body_sha256": "f8ec3b79013bcc954292b960b176b94e11b0a50c857ee5d92ea4d75860fc7d59",
  "components": {
    "ollama": {
      "name": "Ollama",
      "basis": "v0.40.14",
      "sources": {
        "s926454766be0": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go",
        "s763beb3a2234": "https://github.com/ollama/ollama/blob/v0.40.14/api/client.go",
        "s10d55d89ff19": "https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go",
        "s477d97fbecc7": "https://github.com/ollama/ollama/blob/v0.40.14/main.go#L3-L13",
        "s577d2578b863": "https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2644-L2650",
        "sbb511d763012": "https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2809-L2831",
        "s4c83d37be5fa": "https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2541-L2831",
        "s4dbf716fa9c0": "https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L2269-L2285",
        "s934786aa1508": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2523-L2528",
        "s6bce9b343229": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2537-L2547",
        "sbc0cc53c7ea8": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2588-L2593",
        "s5b265711d2af": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L3-L55",
        "se69445e252da": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2472-L2596",
        "s2474467b2e60": "https://github.com/ollama/ollama/blob/v0.40.14/cmd/cmd.go#L3-L60",
        "s2f1d94710feb": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1",
        "s6be064685bba": "https://github.com/ollama/ollama/blob/v0.40.14/docs/faq.mdx",
        "s26be17f980e1": "https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go",
        "se20b98b4fa6f": "https://github.com/ollama/ollama/blob/v0.40.14/Dockerfile",
        "s8fdbeefa696b": "https://github.com/ollama/ollama/blob/v0.40.14/docs/api.md",
        "s670d892bf359": "https://github.com/ollama/ollama/blob/v0.40.14/server/create.go",
        "sce8a0d1f3831": "https://github.com/ollama/ollama/blob/v0.40.14/manifest/paths.go",
        "s7cb14cc64574": "https://github.com/ollama/ollama/blob/v0.40.14/server/images.go",
        "sc0e1dbae723e": "https://github.com/ollama/ollama/blob/v0.40.14/docs/linux.mdx",
        "sdd9be070f841": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/install.sh",
        "s8451cd2c04b7": "https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go",
        "s597bdfe54329": "https://github.com/ollama/ollama/blob/v0.40.14/api/types.go",
        "scf9b09b4b118": "https://github.com/ollama/ollama/blob/v0.40.14/docs/context-length.mdx",
        "s885a39bf1889": "https://github.com/ollama/ollama/blob/v0.40.14/types/model/name.go",
        "sf6fd078295ae": "https://github.com/ollama/ollama/blob/v0.40.14/docs/modelfile.mdx",
        "s2265f8345962": "https://github.com/ollama/ollama/blob/v0.40.14/server/inference_request_log.go",
        "sba6a4f320b6a": "https://github.com/ollama/ollama/blob/v0.40.14/go.mod#L3",
        "s1ac39b3660a2": "https://github.com/ollama/ollama/blob/v0.40.14/Dockerfile#L257-L273",
        "se3193be32015": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_darwin.sh#L88-L89",
        "s38976770bc28": "https://github.com/ollama/ollama/blob/v0.40.14/cmake/local.cmake#L711-L758",
        "s1be5d1576a50": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L865-L920",
        "s164b13109d88": "https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L71-L82",
        "s3d5c5764fed2": "https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L354-L378",
        "s6b9f9627a574": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L210-L230",
        "s14d11e19ac27": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L296",
        "sc06aae169fc9": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L1299",
        "s2332130fa1e7": "https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L13-L25",
        "s6129c0dd7a10": "https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L338",
        "saa84b3aea335": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L896-L908",
        "s55a8b7a39807": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L231",
        "s284d5c9ccbf6": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L295",
        "s589f0e50fa35": "https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L34",
        "s3b7fa1fcefbd": "https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L480-L557",
        "s828bd193c1fd": "https://github.com/ollama/ollama/blob/v0.40.14/.github/workflows/release.yaml#L562-L667",
        "s3cc1f9009971": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app.go#L186-L196",
        "s63598805dfec": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app.go#L280-L293",
        "sf3b9c404c46f": "https://github.com/ollama/ollama/blob/v0.40.14/app/ui/ui.go#L194-L225",
        "s8cc22efcaaca": "https://github.com/ollama/ollama/blob/v0.40.14/app/ui/ui.go#L278-L327",
        "s4fb8958f1218": "https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L241-L255",
        "seaa45ac56dd7": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_darwin.sh#L200-L216",
        "s41d553145c17": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L981-L1005",
        "sa56366559d62": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L10",
        "sa55b9f381b09": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L95-L96",
        "scbcba9fa2026": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L535",
        "s776bbcd95f3c": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L546-L561",
        "s3d5b427b463a": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L592-L598",
        "s32d2fa1014f8": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1202-L1229",
        "scde20ea5a74a": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1478-L1493",
        "sb2938e867f20": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1645-L1667",
        "sab2fbcd0c98e": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L614-L631",
        "s14ee6c3159e4": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L944-L951",
        "sfc4c24d8630b": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L23-L26",
        "s498d9212196e": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L131-L132",
        "s80406fd9e16d": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L198-L221",
        "s5f05208cf314": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L300-L361",
        "sacbb561c6cfe": "https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L190-L225",
        "sadbce7446a0d": "https://github.com/ollama/ollama/blob/v0.40.14/app/server/server.go#L49-L51",
        "s7283b88c8765": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/build_windows.ps1#L995-L998",
        "sc9151806147c": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1574-L1579",
        "s61e666769722": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L1700-L1704",
        "sb816d460f392": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L419-L435",
        "s1efc29a8d9c6": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L363-L380",
        "s741bae4c4fa6": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/claude_desktop.go#L126-L130",
        "sb40469426b0e": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/app_darwin.go#L599-L609",
        "sada8b309ca30": "https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L20-L60",
        "sfee7de68771c": "https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L62-L83",
        "s6540e626aa77": "https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L378-L380",
        "s5e41321e18ef": "https://github.com/ollama/ollama/blob/v0.40.14/app/cmd/app/codex_app_darwin.go",
        "s476a70052b98": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go",
        "s04e05b71ae0c": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L27-L30",
        "sf17ba77d4cfb": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L60-L62",
        "s5e484a0c4247": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L157-L177",
        "s26e9dfa27980": "https://github.com/ollama/ollama/blob/v0.40.14/internal/proxy/codex_desktop.go#L640-L650",
        "s7a9f22479c78": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2385-L2450",
        "s5fa22654febc": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2684-L2696",
        "s0376a63afed9": "https://github.com/ollama/ollama/blob/v0.40.14/server/cloud_proxy.go#L28-L31",
        "sf652fe336dd3": "https://github.com/ollama/ollama/blob/v0.40.14/server/cloud_proxy.go#L176-L226",
        "s6beaf6f88873": "https://github.com/ollama/ollama/blob/v0.40.14/server/cloud_proxy.go#L408-L422",
        "s6fe675aeacf6": "https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1753-L1822",
        "sc767079217fa": "https://github.com/ollama/ollama/blob/v0.40.14/manifest/paths.go#L51-L58",
        "sda1300806a6f": "https://github.com/ollama/ollama/blob/v0.40.14/manifest/paths.go#L400-L420",
        "s86c505b22a2e": "https://github.com/ollama/ollama/blob/v0.40.14/manifest/layer.go#L68-L77",
        "sbfd802f779fc": "https://github.com/ollama/ollama/blob/v0.40.14/manifest/layer.go#L112-L121",
        "s14695a033e02": "https://github.com/ollama/ollama/blob/v0.40.14/manifest/manifest.go#L1219-L1245",
        "sd702c5befe55": "https://github.com/ollama/ollama/blob/v0.40.14/manifest/manifest.go#L1287-L1329",
        "sf7e0612d39ea": "https://github.com/ollama/ollama/blob/v0.40.14/manifest/manifest.go#L1331-L1357",
        "s862914c50e5d": "https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1261-L1293",
        "s780ccf68092b": "https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L509-L551",
        "s1c5af6f0c574": "https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L219-L331",
        "s57e44eeb534d": "https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L336-L349",
        "s39a4f25f6ac7": "https://github.com/ollama/ollama/blob/v0.40.14/server/download.go#L131-L186",
        "sdf91d0608d37": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L2571-L2586",
        "sb618c5e4f17b": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L139-L173",
        "sf3ccbc200368": "https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L212-L220",
        "s09cfe9587540": "https://github.com/ollama/ollama/blob/v0.40.14/api/types.go#L1237-L1246",
        "sf5b30e423c90": "https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L229-L230",
        "s77b969258f4f": "https://github.com/ollama/ollama/blob/v0.40.14/scripts/install.sh#L197-L212",
        "sc86b87d0a117": "https://github.com/ollama/ollama/blob/v0.40.14/api/types.go#L806-L812",
        "s94fdd53a108e": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1935-L1947",
        "s5d162677208c": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1831-L1835",
        "se630a0a320f1": "https://github.com/ollama/ollama/blob/v0.40.14/api/types.go#L856-L867",
        "s47731e254da7": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1530-L1532",
        "saf82203abe6f": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1584-L1586",
        "s73ed57de607f": "https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1047-L1053",
        "s4adb801bd1b4": "https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1213-L1215",
        "s6b099c8e9f4a": "https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1502-L1560",
        "s071857f111bf": "https://github.com/ollama/ollama/blob/v0.40.14/server/images.go#L1594-L1653",
        "s8bb7e5126025": "https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L192-L210",
        "s33a315a5654d": "https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L735-L740",
        "s5f74467e50db": "https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L694-L708",
        "s0779856619f5": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L202-L212",
        "se3fc27596f3f": "https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L811-L837",
        "sc1ca059531b9": "https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L953-L961",
        "se5f97896e369": "https://github.com/ollama/ollama/blob/v0.40.14/server/sched.go#L631-L634",
        "sc38e9c04399d": "https://github.com/ollama/ollama/blob/v0.40.14/envconfig/config.go#L261-L272",
        "s7c9c7bfb6e3f": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1779-L1800",
        "sf5128e4106c3": "https://github.com/ollama/ollama/blob/v0.40.14/server/routes.go#L1819-L1829"
      }
    },
    "ollama-sweep": {
      "name": "Ollama (go list sweep and go.sum reading)",
      "basis": "v0.34.2",
      "sources": {
        "s9bf8940c3001": "https://github.com/ollama/ollama/blob/v0.34.2/main.go#L3-L13",
        "s98a6abaa3838": "https://github.com/ollama/ollama/blob/v0.34.2/integration/basic_test.go#L1",
        "s9a29ad2cbe09": "https://github.com/ollama/ollama/blob/v0.34.2/integration/reg_groups_test.go#L1",
        "s748c551a2a08": "https://github.com/ollama/ollama/blob/v0.34.2/integration/generate_jinja_test.go#L1",
        "sd7c08f30e61e": "https://github.com/ollama/ollama/blob/v0.34.2/app/updater/updater_live_test.go#L1",
        "s720db4671dfd": "https://github.com/ollama/ollama/blob/v0.34.2/readline/term.go#L1-L7",
        "s2422d51c7511": "https://github.com/ollama/ollama/blob/v0.34.2/go.mod#L3",
        "sc8a033a390da": "https://github.com/ollama/ollama/blob/v0.34.2/go.mod#L5-L91",
        "sfc02278c501f": "https://github.com/ollama/ollama/blob/v0.34.2/go.sum",
        "sad61f21372d7": "https://github.com/ollama/ollama/blob/v0.34.2/app/cmd/app/app.go#L1-L33",
        "sf38afcc73250": "https://github.com/ollama/ollama/blob/v0.34.2/app/ui/app.go#L15-L16",
        "s45897fae891f": "https://github.com/ollama/ollama/blob/v0.34.2/app/webview/webview.go#L51",
        "s2b2be911f51e": "https://github.com/ollama/ollama/blob/v0.34.2/app/cmd/app/app_darwin.go#L10",
        "se6c615cc2b3a": "https://github.com/ollama/ollama/blob/v0.34.2/app/cmd/app/webview.go#L6"
      }
    },
    "ollama-rolling": {
      "name": "Ollama documentation (rolling)",
      "basis": "unknown",
      "sources": {
        "sf49fae5df9fd": "https://docs.ollama.com/api/authentication",
        "s6c2961786919": "https://docs.ollama.com/api/tags",
        "s528f69db04e0": "https://docs.ollama.com/api-reference/show-model-details"
      }
    },
    "docker": {
      "name": "Docker Engine localhost boundary",
      "basis": "28.0",
      "sources": {
        "s1e53417c513d": "https://docs.docker.com/engine/network/port-publishing/"
      }
    },
    "systemd": {
      "name": "systemd",
      "basis": "v257",
      "sources": {
        "sd4c1aeb45417": "https://github.com/systemd/systemd/blob/v257/man/systemd.exec.xml"
      }
    },
    "go": {
      "name": "Go",
      "basis": "go1.26.5",
      "sources": {
        "sab55ef9009c4": "https://github.com/golang/go/blob/go1.26.5/src/net/http/pprof/pprof.go#L96-L106",
        "s2e779f75153e": "https://github.com/golang/go/blob/go1.26.5/src/net/http/server.go#L2870-L2878",
        "s038b2186ee21": "https://github.com/golang/go/blob/go1.26.5/src/net/http/server.go#L2971",
        "sa0c56e16001f": "https://github.com/golang/go/blob/go1.26.5/src/net/http/server.go#L3302-L3306",
        "s7f4cde22e030": "https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L83",
        "sdba7b87fda8d": "https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L236-L240",
        "s7290caae7a3c": "https://github.com/golang/go/blob/go1.26.5/src/net/http/header.go#L43-L51",
        "s0388b420c217": "https://github.com/golang/go/blob/go1.26.5/src/internal/goversion/goversion.go#L12",
        "s41262ad87b65": "https://github.com/golang/go/blob/go1.26.5/src/net/http/pprof/pprof.go#L88",
        "s80e5cbbd9e14": "https://github.com/golang/go/blob/go1.26.5/src/testing/internal/testdeps/deps.go#L23",
        "s63df9d2be607": "https://github.com/golang/go/blob/go1.26.5/src/simd/archsimd/_gen/simdgen/main.go#L91",
        "s247aaccc10e3": "https://github.com/golang/go/blob/go1.26.5/src/simd/archsimd/_gen/simdgen/main.go#L71",
        "sdbf899cd837b": "https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L3225-L3226",
        "s28c91a6e011d": "https://github.com/golang/go/blob/go1.26.5/src/cmd/go/alldocs.go#L2811-L2812",
        "s6d68526316f0": "https://github.com/golang/go/blob/go1.26.5/src/cmd/go/internal/load/test.go#L790-L801",
        "sd3be35e6620b": "https://github.com/golang/go/blob/go1.26.5/src/cmd/go/internal/load/pkg.go#L2638-L2672",
        "sd58d43f93322": "https://github.com/golang/go/blob/go1.26.5/src/cmd/go/internal/load/pkg.go#L1912-L1935"
      }
    },
    "go-1-26-0": {
      "name": "Go",
      "basis": "go1.26.0",
      "sources": {
        "s7670be382fd6": "https://github.com/golang/go/blob/go1.26.0/src/internal/goversion/goversion.go#L12",
        "sc4d5a418cc8a": "https://github.com/golang/go/blob/go1.26.0/src/net/http/pprof/pprof.go#L88",
        "s63f63360f142": "https://github.com/golang/go/blob/go1.26.0/src/testing/internal/testdeps/deps.go#L23",
        "se924f730cd16": "https://github.com/golang/go/blob/go1.26.0/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "go-1-26-1": {
      "name": "Go",
      "basis": "go1.26.1",
      "sources": {
        "sc2735a74234b": "https://github.com/golang/go/blob/go1.26.1/src/internal/goversion/goversion.go#L12",
        "sd0122b4596e5": "https://github.com/golang/go/blob/go1.26.1/src/net/http/pprof/pprof.go#L88",
        "sa24dcdd9e52c": "https://github.com/golang/go/blob/go1.26.1/src/testing/internal/testdeps/deps.go#L23",
        "s2a55e411da1d": "https://github.com/golang/go/blob/go1.26.1/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "go-1-26-2": {
      "name": "Go",
      "basis": "go1.26.2",
      "sources": {
        "sa8ba29c45871": "https://github.com/golang/go/blob/go1.26.2/src/internal/goversion/goversion.go#L12",
        "s058a974ee5d5": "https://github.com/golang/go/blob/go1.26.2/src/net/http/pprof/pprof.go#L88",
        "s019e0fb220fc": "https://github.com/golang/go/blob/go1.26.2/src/testing/internal/testdeps/deps.go#L23",
        "s8a4dc2d3db9b": "https://github.com/golang/go/blob/go1.26.2/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "go-1-26-3": {
      "name": "Go",
      "basis": "go1.26.3",
      "sources": {
        "sdc07d97a87b6": "https://github.com/golang/go/blob/go1.26.3/src/internal/goversion/goversion.go#L12",
        "sed7ba616e62c": "https://github.com/golang/go/blob/go1.26.3/src/net/http/pprof/pprof.go#L88",
        "s040d1ea399ae": "https://github.com/golang/go/blob/go1.26.3/src/testing/internal/testdeps/deps.go#L23",
        "s898567a72486": "https://github.com/golang/go/blob/go1.26.3/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "go-1-26-4": {
      "name": "Go",
      "basis": "go1.26.4",
      "sources": {
        "s2fd10ac9b790": "https://github.com/golang/go/blob/go1.26.4/src/internal/goversion/goversion.go#L12",
        "s860b46eaab36": "https://github.com/golang/go/blob/go1.26.4/src/net/http/pprof/pprof.go#L88",
        "s2104c8373c85": "https://github.com/golang/go/blob/go1.26.4/src/testing/internal/testdeps/deps.go#L23",
        "s0e9e578b8243": "https://github.com/golang/go/blob/go1.26.4/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "go-1-26-6": {
      "name": "Go",
      "basis": "go1.26.6",
      "sources": {
        "s8b8ebc7e8db6": "https://github.com/golang/go/blob/go1.26.6/src/internal/goversion/goversion.go#L12",
        "sb1475154fbb7": "https://github.com/golang/go/blob/go1.26.6/src/net/http/pprof/pprof.go#L88",
        "s974c60526bb6": "https://github.com/golang/go/blob/go1.26.6/src/testing/internal/testdeps/deps.go#L23",
        "s52851e8b4312": "https://github.com/golang/go/blob/go1.26.6/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "go-1-26-7": {
      "name": "Go",
      "basis": "go1.26.7",
      "sources": {
        "s17ad8bf46090": "https://github.com/golang/go/blob/go1.26.7/src/internal/goversion/goversion.go#L12",
        "s54141d62f948": "https://github.com/golang/go/blob/go1.26.7/src/net/http/pprof/pprof.go#L88",
        "sf081388dd0f7": "https://github.com/golang/go/blob/go1.26.7/src/testing/internal/testdeps/deps.go#L23",
        "s64e2db3b685b": "https://github.com/golang/go/blob/go1.26.7/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "go-1-26-8": {
      "name": "Go",
      "basis": "go1.26.8",
      "sources": {
        "s6175e03794cf": "https://github.com/golang/go/blob/go1.26.8/src/internal/goversion/goversion.go#L12",
        "s88d4166a7bee": "https://github.com/golang/go/blob/go1.26.8/src/net/http/pprof/pprof.go#L88",
        "sa79ec4182285": "https://github.com/golang/go/blob/go1.26.8/src/testing/internal/testdeps/deps.go#L23",
        "s9ad74046b534": "https://github.com/golang/go/blob/go1.26.8/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "go-1-26-9": {
      "name": "Go",
      "basis": "go1.26.9",
      "sources": {
        "s69637c613830": "https://github.com/golang/go/blob/go1.26.9/src/internal/goversion/goversion.go#L12",
        "s71887e5f7cdf": "https://github.com/golang/go/blob/go1.26.9/src/net/http/pprof/pprof.go#L88",
        "s6728c0a5d0d1": "https://github.com/golang/go/blob/go1.26.9/src/testing/internal/testdeps/deps.go#L23",
        "s110ef73adaf3": "https://github.com/golang/go/blob/go1.26.9/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "go-1-26-10": {
      "name": "Go",
      "basis": "go1.26.10",
      "sources": {
        "scff07ded2fad": "https://github.com/golang/go/blob/go1.26.10/src/internal/goversion/goversion.go#L12",
        "sd61f4ff8d5d6": "https://github.com/golang/go/blob/go1.26.10/src/net/http/pprof/pprof.go#L88",
        "s9b82f1629b4d": "https://github.com/golang/go/blob/go1.26.10/src/testing/internal/testdeps/deps.go#L23",
        "s599b4645909f": "https://github.com/golang/go/blob/go1.26.10/src/simd/archsimd/_gen/simdgen/main.go#L91"
      }
    },
    "trifles": {
      "name": "github.com/dgryski/trifles",
      "basis": "v0.0.0-20200323201526-dd97f9abfb48",
      "sources": {
        "s38ad5e627932": "https://github.com/dgryski/trifles/blob/dd97f9abfb48/cstbucket/main.go#L1-L17",
        "seeae3b9d9459": "https://github.com/dgryski/trifles/blob/dd97f9abfb48/fastpprof/main.go#L1-L13",
        "s56182db1ad94": "https://github.com/dgryski/trifles/blob/dd97f9abfb48/jumpreplica/main.go#L1-L18",
        "s4e12f43a1afe": "https://github.com/dgryski/trifles/blob/dd97f9abfb48/lz/lz.go#L1-L11",
        "s6a11f78133a6": "https://github.com/dgryski/trifles/blob/dd97f9abfb48/matcher/main.go#L1-L13",
        "s82d128642faa": "https://github.com/dgryski/trifles/blob/dd97f9abfb48/quantiles/main.go#L1-L22",
        "s53fe5b36bae7": "https://github.com/dgryski/trifles/blob/dd97f9abfb48/udprelay/main.go#L1-L26",
        "s3c8772bb591f": "https://github.com/dgryski/trifles/blob/dd97f9abfb48/fastpprof/main.go#L16-L42"
      }
    },
    "compress": {
      "name": "github.com/klauspost/compress",
      "basis": "v1.18.3",
      "sources": {
        "sd309de5a57e2": "https://github.com/klauspost/compress/blob/v1.18.3/s2/cmd/s2c/main.go#L1-L27"
      }
    },
    "x-text": {
      "name": "golang.org/x/text",
      "basis": "v0.30.0",
      "sources": {
        "s7b232c7ac531": "https://github.com/golang/text/blob/v0.30.0/collate/tools/colcmp/colcmp.go#L5-L22"
      }
    },
    "go-toml": {
      "name": "github.com/pelletier/go-toml/v2",
      "basis": "v2.2.2",
      "sources": {
        "s263bb2467c05": "https://github.com/pelletier/go-toml/blob/v2.2.2/marshaler_test.go#L1571",
        "sf307292d806f": "https://github.com/pelletier/go-toml/blob/v2.2.2/marshaler_test.go#L1649"
      }
    },
    "nginx": {
      "name": "nginx",
      "basis": "unknown",
      "sources": {
        "sf32ce2956917": "https://nginx.org/en/docs/http/ngx_http_auth_basic_module.html",
        "s40bdf1af1596": "https://nginx.org/en/docs/http/ngx_http_core_module.html",
        "sf0bc2adae8cb": "https://nginx.org/en/docs/http/ngx_http_rewrite_module.html",
        "sda4ba3fcedbe": "https://nginx.org/en/docs/http/ngx_http_ssl_module.html",
        "sf3430c5a0b22": "https://nginx.org/en/docs/http/ngx_http_proxy_module.html",
        "sb3bee9429629": "https://nginx.org/en/docs/http/ngx_http_limit_req_module.html",
        "sddc43aac8779": "https://nginx.org/en/docs/http/ngx_http_limit_conn_module.html",
        "sa28876996ece": "https://nginx.org/en/docs/switches.html"
      }
    },
    "htpasswd": {
      "name": "Apache htpasswd",
      "basis": "unknown",
      "sources": {
        "scde9004bb967": "https://httpd.apache.org/docs/2.4/programs/htpasswd.html"
      }
    },
    "caddy": {
      "name": "Caddy",
      "basis": "unknown",
      "sources": {
        "sbc2bd9599bd1": "https://caddyserver.com/docs/caddyfile/directives/basic_auth",
        "s38b1b78ce980": "https://caddyserver.com/docs/caddyfile/matchers",
        "s39d7d5ee55e2": "https://caddyserver.com/docs/caddyfile/directives/handle",
        "s3865a73ccda3": "https://caddyserver.com/docs/caddyfile/directives/reverse_proxy",
        "sc5832c7dc52f": "https://caddyserver.com/docs/command-line"
      }
    },
    "cloudflare": {
      "name": "Cloudflare",
      "basis": "unknown",
      "sources": {
        "s4b65a8359a37": "https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/configure-tunnels/origin-parameters/",
        "s15ab6de85740": "https://developers.cloudflare.com/cloudflare-one/access-controls/service-credentials/service-tokens/",
        "sbd88e529ebf2": "https://developers.cloudflare.com/waf/rate-limiting-rules/"
      }
    },
    "owasp": {
      "name": "OWASP password guidance",
      "basis": "unknown",
      "sources": {
        "s49e8d76431d9": "https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html"
      }
    },
    "curl": {
      "name": "curl",
      "basis": "unknown",
      "sources": {
        "s2b2686afaf41": "https://curl.se/docs/manpage.html"
      }
    }
  },
  "claims": {
    "local-auth": {"text": "Local API has no inbound authentication; cloud keys and OLLAMA_AUTH concern upstream signing.", "components": ["ollama", "ollama-rolling"], "sources": ["ollama-rolling:sf49fae5df9fd", "ollama:s926454766be0", "ollama:s763beb3a2234"], "status": "REASONED"},
    "local-tls": {"text": "Ollama serves plaintext; an https prefix in OLLAMA_HOST does not enable TLS.", "components": ["ollama"], "sources": ["ollama:s926454766be0", "ollama:s10d55d89ff19"], "status": "REASONED"},
    "host-bind": {"text": "Standalone default is 127.0.0.1:11434; set OLLAMA_HOST in the service and reload/restart systemd.", "components": ["ollama", "systemd"], "sources": ["ollama:s6be064685bba", "ollama:s26be17f980e1", "systemd:sd4c1aeb45417"], "status": "REASONED"},
    "container-bind": {"text": "Official image sets 0.0.0.0:11434 internally; bridge publication and container binding are separate.", "components": ["ollama", "docker"], "sources": ["ollama:se20b98b4fa6f", "docker:s1e53417c513d"], "status": "REASONED"},
    "publication": {"text": "Use 127.0.0.1:11434:11434 with Engine 28.0+; earlier same-L2 access defeats this boundary; unpublished private networks are an alternative.", "components": ["docker"], "sources": ["docker:s1e53417c513d"], "status": "REASONED"},
    "host-network": {"text": "Host networking ignores publication flags; override the image listener and restrict authorized peers.", "components": ["ollama", "docker"], "sources": ["ollama:se20b98b4fa6f", "docker:s1e53417c513d"], "status": "REASONED"},
    "basic-auth": {"text": "nginx server-scope Basic auth protects permitted locations; denied paths/methods may reject before authentication.", "components": ["nginx"], "sources": ["nginx:sf32ce2956917", "nginx:s40bdf1af1596", "nginx:sf0bc2adae8cb"], "status": "REASONED"},
    "password-hash": {"text": "Use prompted htpasswd -B -C 12; bare -B defaults to bcrypt cost 5, below the cited minimum 10.", "components": ["htpasswd", "owasp"], "sources": ["htpasswd:scde9004bb967", "owasp:s49e8d76431d9"], "status": "REASONED"},
    "tls-proxy": {"text": "Publish authenticated TLS; encrypt the backend leg separately when proxy and Ollama are on different hosts.", "components": ["nginx"], "sources": ["nginx:sda4ba3fcedbe"], "status": "REASONED"},
    "host-header": {"text": "Proxy Host localhost:11434 avoids loopback middleware hostname rejection; it is not authentication.", "components": ["ollama", "nginx"], "sources": ["ollama:s926454766be0", "nginx:sf3430c5a0b22"], "status": "REASONED"},
    "idle-timeout": {"text": "proxy_read_timeout 300s limits gaps between reads, not total generation duration.", "components": ["nginx"], "sources": ["nginx:sf3430c5a0b22"], "status": "REASONED"},
    "caddy-policy": {"text": "Caddy Basic auth, exact POST /api/chat matcher and fallback deny other paths; supply admission limits separately.", "components": ["caddy"], "sources": ["caddy:sbc2bd9599bd1", "caddy:s38b1b78ce980", "caddy:s39d7d5ee55e2", "caddy:s3865a73ccda3"], "status": "REASONED"},
    "bearer-policy": {"text": "Exact nginx bearer comparison is a shared configuration secret without a constant-time guarantee; repeat it in every permitted location.", "components": ["nginx"], "sources": ["nginx:sf0bc2adae8cb"], "status": "REASONED"},
    "mtls": {"text": "Dedicated client CA and ssl_verify_client require certificate lifecycle management; combine Basic auth only deliberately.", "components": ["nginx"], "sources": ["nginx:sda4ba3fcedbe"], "status": "REASONED"},
    "access": {"text": "Access authenticates the tunnel; target a loopback policy proxy on 11435 to retain inference-only authorization.", "components": ["cloudflare", "nginx"], "sources": ["cloudflare:s4b65a8359a37", "cloudflare:s15ab6de85740", "nginx:s40bdf1af1596"], "status": "REASONED"},
    "access-host": {"text": "originRequest.httpHostHeader and the final proxy retain localhost:11434; keep both local listeners private.", "components": ["cloudflare", "ollama"], "sources": ["cloudflare:s4b65a8359a37", "ollama:s926454766be0"], "status": "REASONED"},
    "access-limits": {"text": "Access authentication supplies no inference budgets; retain proxy limits, optionally add WAF rate limits and trusted client-address handling.", "components": ["cloudflare", "nginx"], "sources": ["cloudflare:sbd88e529ebf2", "nginx:sb3bee9429629"], "status": "REASONED"},
    "mfa": {"text": "Human MFA belongs at the fronting identity layer; machine service tokens are not a human MFA flow.", "components": ["cloudflare"], "sources": ["cloudflare:s15ab6de85740"], "status": "REASONED"},
    "inference-policy": {"text": "Allow only exact required inference paths/methods; broad /api/ or /v1/ prefixes grant excessive authority.", "components": ["nginx", "ollama"], "sources": ["nginx:s40bdf1af1596", "nginx:sf0bc2adae8cb", "ollama:s926454766be0"], "status": "REASONED"},
    "pull": {"text": "Keep POST /api/pull private: acquisition consumes storage and network capacity.", "components": ["ollama"], "sources": ["ollama:s8fdbeefa696b"], "status": "REASONED"},
    "push": {"text": "Keep POST /api/push private: export has separate upstream authorization.", "components": ["ollama"], "sources": ["ollama:s8fdbeefa696b"], "status": "REASONED"},
    "create": {"text": "Keep POST /api/create private: it creates/replaces definitions and processes uploaded model material.", "components": ["ollama"], "sources": ["ollama:s8fdbeefa696b", "ollama:s670d892bf359"], "status": "REASONED"},
    "copy": {"text": "Keep POST /api/copy private: it creates another model name.", "components": ["ollama"], "sources": ["ollama:s8fdbeefa696b"], "status": "REASONED"},
    "delete": {"text": "Keep DELETE /api/delete private: it removes models and associated data.", "components": ["ollama"], "sources": ["ollama:s8fdbeefa696b"], "status": "REASONED"},
    "blob-write": {"text": "Keep POST /api/blobs/:digest private: it uploads model-store bytes.", "components": ["ollama"], "sources": ["ollama:s8fdbeefa696b"], "status": "REASONED"},
    "blob-read": {"text": "Keep HEAD /api/blobs/:digest private: it reveals blob existence.", "components": ["ollama"], "sources": ["ollama:s8fdbeefa696b"], "status": "REASONED"},
    "other-routes": {"text": "Default denial excludes account, experimental, desktop proxy and unused compatibility routes, including v0.40.14's balance and usage routes, which drop caller Authorization and sign ollama.com requests (this guide infers with the server's key). Source reading, not run: the /api/codex handler opens no listener and accepts any loopback TCP peer, which a same-host proxy has only over loopback.", "components": ["ollama"], "sources": ["ollama:s926454766be0", "ollama:s7a9f22479c78", "ollama:s5fa22654febc", "ollama:sf652fe336dd3", "ollama:s6beaf6f88873", "ollama:s0376a63afed9", "ollama:s476a70052b98", "ollama:s5e41321e18ef", "ollama:s04e05b71ae0c", "ollama:sf17ba77d4cfb", "ollama:s5e484a0c4247", "ollama:s26e9dfa27980"], "status": "REASONED"},
    "file-validation": {"text": "Create validates relative filenames and blob paths; arbitrary host-file access is not established at this pin.", "components": ["ollama"], "sources": ["ollama:s670d892bf359", "ollama:sce8a0d1f3831"], "status": "REASONED"},
    "transfer": {"text": "Management transfers are egress/disk-fill surfaces; the registry helper's default redirects stay same-host or between hosts allowlisted under ollama.com, ollama.ai, hf.co and huggingface.co, insecure lifts that host check but not the 10-redirect cap, a blob download's direct-URL GET sets its own check but its HEAD size request keeps that default, and no unrestricted SSRF is demonstrated.", "components": ["ollama"], "sources": ["ollama:s7cb14cc64574", "ollama:s6fe675aeacf6", "ollama:s57e44eeb534d", "ollama:s1c5af6f0c574", "ollama:s39a4f25f6ac7"], "status": "REASONED"},
    "origins": {"text": "OLLAMA_ORIGINS adds to built-in origins; removing wildcards is neither authentication nor an exclusive-origin policy.", "components": ["ollama"], "sources": ["ollama:s26be17f980e1"], "status": "REASONED"},
    "service-user": {"text": "Use a dedicated account and writable store; preserve GPU access and do not assume the container shares installer identity. install.sh adds the invoking user to the ollama group on each run with systemctl, which this guide infers grants no store access under 0700 directories; a group-access setup uses the ollama account or API, or deliberately chooses 0750 directories with systemd UMask=0027.", "components": ["ollama", "systemd"], "sources": ["ollama:sc0e1dbae723e", "ollama:sdd9be070f841", "ollama:s77b969258f4f", "systemd:sd4c1aeb45417"], "status": "REASONED"},
    "store": {"text": "Proposed 0700 directories and UMask=0077 need existing-permission/ACL inspection; v0.40.14's layer.go and manifest writers chmod files to 0644, which this guide infers UMask does not mask, while download.go writes pulled blobs with no chmod and transfer-package pulls are unread, so the 0700 directories carry the restriction; separate service configuration and proxy keys.", "components": ["ollama", "systemd"], "sources": ["ollama:sc0e1dbae723e", "systemd:sd4c1aeb45417", "ollama:s86c505b22a2e", "ollama:sbfd802f779fc", "ollama:s14695a033e02", "ollama:sd702c5befe55", "ollama:sf7e0612d39ea", "ollama:sc767079217fa", "ollama:sda1300806a6f", "ollama:s862914c50e5d", "ollama:s780ccf68092b", "ollama:s1c5af6f0c574"], "status": "REASONED"},
    "model-path": {"text": "OLLAMA_MODELS relocates models, not the entire service home or signing keys.", "components": ["ollama"], "sources": ["ollama:s26be17f980e1", "ollama:sc0e1dbae723e"], "status": "REASONED"},
    "loaded-models": {"text": "Loaded-model capacity is automatic unless configured; the example selects one model, not a total memory cap.", "components": ["ollama"], "sources": ["ollama:s26be17f980e1", "ollama:s8451cd2c04b7"], "status": "REASONED"},
    "parallel": {"text": "OLLAMA_NUM_PARALLEL defaults to 1.", "components": ["ollama"], "sources": ["ollama:s26be17f980e1", "ollama:s8451cd2c04b7"], "status": "REASONED"},
    "queue": {"text": "OLLAMA_MAX_QUEUE defaults to 512; the example selects 16 without promising the seventeenth HTTP request is refused.", "components": ["ollama"], "sources": ["ollama:s26be17f980e1", "ollama:s8451cd2c04b7"], "status": "REASONED"},
    "keep-alive": {"text": "Keep-alive defaults to five minutes; one minute is the example, and requests can override it.", "components": ["ollama"], "sources": ["ollama:s26be17f980e1", "ollama:s597bdfe54329"], "status": "REASONED"},
    "context": {"text": "With OLLAMA_CONTEXT_LENGTH unset, 0 or invalid and no model or request num_ctx, the default is VRAM-dependent 4096/32768/262144 at about 23/47 GiB after overhead (documented 24/48 GiB). The FAQ's 4096 and Modelfile table's 2048 disagree with the code read, where 2048 is only a multimodal floor and the scheduler applies a training-context cap and an OOM step-down; MLX is unread.", "components": ["ollama"], "sources": ["ollama:scf9b09b4b118", "ollama:s926454766be0", "ollama:sdf91d0608d37", "ollama:sb618c5e4f17b", "ollama:sf3ccbc200368", "ollama:s09cfe9587540", "ollama:sf5b30e423c90", "ollama:s6be064685bba", "ollama:sf6fd078295ae", "ollama:s8bb7e5126025", "ollama:s33a315a5654d", "ollama:s5f74467e50db", "ollama:s0779856619f5", "ollama:se3fc27596f3f", "ollama:sc1ca059531b9", "ollama:se5f97896e369", "ollama:sc38e9c04399d"], "status": "REASONED"},
    "rate": {"text": "Example nginx source-address rate is 2r/s, burst 4 nodelay, with 429 responses; trusted client-address handling matters behind proxies.", "components": ["nginx"], "sources": ["nginx:sb3bee9429629"], "status": "REASONED"},
    "concurrency": {"text": "Example nginx server-name budget is four active requests with 429; it does not cap every idle/incomplete connection.", "components": ["nginx"], "sources": ["nginx:sddc43aac8779"], "status": "REASONED"},
    "body-limit": {"text": "Example body cap is 1 MiB; a larger valid fixture should get 413 without upstream work.", "components": ["nginx"], "sources": ["nginx:s40bdf1af1596"], "status": "REASONED", "verify": [3]},
    "parameters": {"text": "Gateway must validate model, num_ctx, num_predict and keep_alive; defaults/path allowlists do not enforce JSON ceilings.", "components": ["ollama"], "sources": ["ollama:s6be064685bba", "ollama:s597bdfe54329"], "status": "REASONED", "verify": [3]},
    "registry-names": {"text": "Fully qualified registry names are supported; unqualified names select Ollama's registry and omitted tags select latest.", "components": ["ollama"], "sources": ["ollama:s885a39bf1889"], "status": "REASONED"},
    "provenance": {"text": "Compare deployed tags digests with independent approval; mutable tags/digest equality do not establish publisher trust.", "components": ["ollama", "ollama-rolling"], "sources": ["ollama-rolling:s6c2961786919", "ollama:s885a39bf1889"], "status": "REASONED", "verify": [3]},
    "local-import": {"text": "CLI imports reviewed local GGUF through a Modelfile; artifact SHA-256 and manifest digest are different identifiers.", "components": ["ollama"], "sources": ["ollama:sf6fd078295ae", "ollama:s10d55d89ff19"], "status": "REASONED", "verify": [3]},
    "registry-egress": {"text": "Restrict acquisition/export to administrators and constrain egress; compare approved and controlled disallowed transfers. At v0.40.14 the pull and push handlers pass insecure despite PullRequest's Deprecated: ignored comment; it admits http model names, makes helper request URLs, not redirects, http, skips its redirect host check, sets AllowPrivateHosts and feeds unread transfer redirect checks.", "components": ["ollama"], "sources": ["ollama:s7cb14cc64574", "ollama:se630a0a320f1", "ollama:s47731e254da7", "ollama:saf82203abe6f", "ollama:s73ed57de607f", "ollama:s4adb801bd1b4", "ollama:s6fe675aeacf6", "ollama:s6b099c8e9f4a", "ollama:s071857f111bf", "ollama:s8fdbeefa696b", "ollama:s1c5af6f0c574"], "status": "REASONED", "verify": [3]},
    "cloud": {"text": "OLLAMA_NO_CLOUD=1 disables cloud models and web search after restart; it is not a no-network switch.", "components": ["ollama"], "sources": ["ollama:s6be064685bba"], "status": "REASONED", "verify": [3]},
    "remotes": {"text": "OLLAMA_REMOTES selects remote-model hosts, not a registry allowlist.", "components": ["ollama"], "sources": ["ollama:s26be17f980e1"], "status": "REASONED"},
    "diagnostics": {"text": "Keep root, version, status, tags, ps and show private; model details can disclose templates and, by source reading of v0.40.14's ShowResponse and GetModelInfo rather than the served page, which documents no system field, system prompts.", "components": ["ollama", "ollama-rolling"], "sources": ["ollama:s926454766be0", "ollama-rolling:s528f69db04e0", "ollama:sc86b87d0a117", "ollama:s94fdd53a108e", "ollama:s5d162677208c", "ollama:s7c9c7bfb6e3f", "ollama:sf5128e4106c3"], "status": "REASONED", "verify": [3]},
    "request-logs": {"text": "Disable OLLAMA_DEBUG and OLLAMA_DEBUG_LOG_REQUESTS; existing request captures/replay scripts need separate cleanup.", "components": ["ollama"], "sources": ["ollama:s26be17f980e1", "ollama:s2265f8345962"], "status": "REASONED", "verify": [3]},
    "profiling": {"text": "No metrics route was found in the main router; this guide assesses that first-party v0.34.2 code registers no pprof handler, and at v0.40.14 found no pprof import in the server import block, other first-party code being unchecked. Shipped-binary pprof availability remains unestablished: observe the binary, deny public profiling, infer nothing from debug settings.", "components": ["ollama", "ollama-sweep"], "sources": ["ollama:s926454766be0", "ollama-sweep:s9bf8940c3001", "ollama:s477d97fbecc7", "ollama:s577d2578b863", "ollama:sbb511d763012", "ollama:s4c83d37be5fa", "ollama:s4dbf716fa9c0", "ollama:s934786aa1508", "ollama:s6bce9b343229", "ollama:sbc0cc53c7ea8", "ollama:s5b265711d2af", "ollama:se69445e252da", "ollama:s2474467b2e60", "ollama:s2f1d94710feb"], "status": "REASONED", "verify": [3]},
    "profiling-scope": {"text": "Go 1.26.5 go list runs for this guide found neither net/http/pprof nor runtime/pprof in the default-tag v0.34.2 main-package graph for every go tool dist list pair that loaded, cgo off and, where supported, on; five cgo-off android/ios runs failed. This guide infers no go.sum or standard-library package adds either; Go outside 1.26.x, cgo/SWIG output, those runs and served-mux exposure stay open.", "components": ["ollama-sweep", "trifles", "compress", "x-text", "go"], "sources": ["ollama-sweep:s9bf8940c3001", "ollama-sweep:sfc02278c501f", "trifles:s38ad5e627932", "trifles:seeae3b9d9459", "trifles:s56182db1ad94", "trifles:s4e12f43a1afe", "trifles:s6a11f78133a6", "trifles:s82d128642faa", "trifles:s53fe5b36bae7", "compress:sd309de5a57e2", "x-text:s7b232c7ac531", "go:s41262ad87b65", "go:s80e5cbbd9e14", "go:s63df9d2be607", "go:s247aaccc10e3", "go:sdbf899cd837b", "go:s28c91a6e011d", "go:s6d68526316f0", "go:sd3be35e6620b", "go:sd58d43f93322"], "status": "REASONED", "verify": [3]},
    "profiling-tags": {"text": "From source reading, v0.34.2's first-party custom tags integration, fast, generate, release, library and updater_live gate only _test.go files, which go build ignores; appengine and os400 appear only in readline/term.go, importing only syscall. The dependency search ignored build constraints, so which dependency files these tags select was not determined; go list runs show generate selects one.", "components": ["ollama-sweep", "go"], "sources": ["ollama-sweep:s9bf8940c3001", "ollama-sweep:s98a6abaa3838", "ollama-sweep:s9a29ad2cbe09", "ollama-sweep:s748c551a2a08", "ollama-sweep:sd7c08f30e61e", "ollama-sweep:s720db4671dfd", "go:s7f4cde22e030"], "status": "REASONED", "verify": [3]},
    "profiling-tag-runs": {"text": "Go 1.26.5 go list runs for this guide found neither net/http/pprof nor runtime/pprof in v0.34.2 main-package graphs with tag set updater_live, release,library, appengine, os400 or appengine,os400 on the eight first-class pairs, windows arm64 and aix ppc64, cgo off and on. This guide infers no first-party, go.sum or standard-library file adds either; cgo/SWIG output and Go outside 1.26.x are open.", "components": ["ollama-sweep", "go", "trifles", "compress", "x-text"], "sources": ["ollama-sweep:s9bf8940c3001", "ollama-sweep:s720db4671dfd", "go:sdba7b87fda8d", "ollama-sweep:sfc02278c501f", "trifles:s38ad5e627932", "trifles:seeae3b9d9459", "trifles:s56182db1ad94", "trifles:s4e12f43a1afe", "trifles:s6a11f78133a6", "trifles:s82d128642faa", "trifles:s53fe5b36bae7", "compress:sd309de5a57e2", "x-text:s7b232c7ac531", "go:s41262ad87b65", "go:s80e5cbbd9e14", "go:s63df9d2be607", "go:s247aaccc10e3", "go:sdbf899cd837b", "go:s28c91a6e011d", "go:s6d68526316f0", "go:sd3be35e6620b", "go:sd58d43f93322"], "status": "REASONED", "verify": [3]},
    "profiling-generate": {"text": "Go 1.26.5 go list runs for v0.34.2 with tag sets containing generate failed on all ten pairs tried, cgo off and on, reporting both uniseg and main packages in dependency github.com/rivo/uniseg v0.4.7; -e reruns listed neither pprof package but marked that package with a load error, so whether such builds import either remains open.", "components": ["ollama-sweep", "go"], "sources": ["ollama-sweep:s9bf8940c3001", "go:sdba7b87fda8d"], "status": "REASONED"},
    "profiling-go-versions": {"text": "Source reading, not run: Go 1.26.0 to 1.26.10 except 1.26.5 match 1.26.5: goversion is 26. Ignoring build constraints, only net/http/pprof, testing/internal/testdeps and a package main command import runtime/pprof in non-test files outside cmd and testdata. No such file imports the first two. This guide infers no such release adds either package to the 1.26.5 go list graphs; no graph was checked.", "components": ["go-1-26-0", "go-1-26-1", "go-1-26-2", "go-1-26-3", "go-1-26-4", "go-1-26-6", "go-1-26-7", "go-1-26-8", "go-1-26-9", "go-1-26-10", "go"], "sources": ["go-1-26-0:s7670be382fd6", "go-1-26-0:sc4d5a418cc8a", "go-1-26-0:s63f63360f142", "go-1-26-0:se924f730cd16", "go-1-26-1:sc2735a74234b", "go-1-26-1:sd0122b4596e5", "go-1-26-1:sa24dcdd9e52c", "go-1-26-1:s2a55e411da1d", "go-1-26-2:sa8ba29c45871", "go-1-26-2:s058a974ee5d5", "go-1-26-2:s019e0fb220fc", "go-1-26-2:s8a4dc2d3db9b", "go-1-26-3:sdc07d97a87b6", "go-1-26-3:sed7ba616e62c", "go-1-26-3:s040d1ea399ae", "go-1-26-3:s898567a72486", "go-1-26-4:s2fd10ac9b790", "go-1-26-4:s860b46eaab36", "go-1-26-4:s2104c8373c85", "go-1-26-4:s0e9e578b8243", "go-1-26-6:s8b8ebc7e8db6", "go-1-26-6:sb1475154fbb7", "go-1-26-6:s974c60526bb6", "go-1-26-6:s52851e8b4312", "go-1-26-7:s17ad8bf46090", "go-1-26-7:s54141d62f948", "go-1-26-7:sf081388dd0f7", "go-1-26-7:s64e2db3b685b", "go-1-26-8:s6175e03794cf", "go-1-26-8:s88d4166a7bee", "go-1-26-8:sa79ec4182285", "go-1-26-8:s9ad74046b534", "go-1-26-9:s69637c613830", "go-1-26-9:s71887e5f7cdf", "go-1-26-9:s6728c0a5d0d1", "go-1-26-9:s110ef73adaf3", "go-1-26-10:scff07ded2fad", "go-1-26-10:sd61f4ff8d5d6", "go-1-26-10:s9b82f1629b4d", "go-1-26-10:s599b4645909f", "go:s0388b420c217", "go:s41262ad87b65", "go:s80e5cbbd9e14", "go:s63df9d2be607"], "status": "REASONED"},
    "profiling-deps-scan": {"text": "From source reading, ignoring build constraints, only package main files in the 93 dependency modules with go.sum zip hashes import net/http/pprof or runtime/pprof. Imports followed from first-party packages stay in those modules and the standard library, so this guide infers no such module adds either at those versions. The 15 cached modules with no go.sum zip hash were excluded.", "components": ["ollama-sweep", "trifles", "compress", "x-text", "go-toml"], "sources": ["ollama-sweep:s9bf8940c3001", "ollama-sweep:s2422d51c7511", "ollama-sweep:sc8a033a390da", "ollama-sweep:sfc02278c501f", "trifles:s38ad5e627932", "trifles:seeae3b9d9459", "trifles:s56182db1ad94", "trifles:s4e12f43a1afe", "trifles:s6a11f78133a6", "trifles:s82d128642faa", "trifles:s53fe5b36bae7", "trifles:s3c8772bb591f", "compress:sd309de5a57e2", "x-text:s7b232c7ac531", "go-toml:s263bb2467c05", "go-toml:sf307292d806f"], "status": "REASONED"},
    "profiling-mux": {"text": "This guide's inference, not run: Go 1.26.5 net/http/pprof's init registers /debug/pprof/ handlers on http.DefaultServeMux, which a server with a nil Handler, as in v0.40.14's Serve, uses, so a build linking that package would serve them on the Ollama listener, while builds whose go list graph lacks it get none from it.", "components": ["go", "ollama"], "sources": ["go:sab55ef9009c4", "go:s2e779f75153e", "go:s038b2186ee21", "go:sa0c56e16001f", "ollama:s6bce9b343229", "ollama:sbc0cc53c7ea8"], "status": "REASONED", "verify": [3]},
    "profiling-release": {"text": "From this guide's reading of v0.40.14's Dockerfile, build scripts and release workflow, which show intended builds rather than artifact contents, the main package is built with no -tags, and with CGO_ENABLED=1 in the Dockerfile, the darwin build and both Windows CLI builds. Its go.mod declares go 1.26.10, which the Dockerfile uses to choose Go; the go list runs used Go 1.26.5 on v0.34.2.", "components": ["ollama", "ollama-sweep"], "sources": ["ollama:sba6a4f320b6a", "ollama-sweep:s2422d51c7511", "ollama:s1ac39b3660a2", "ollama:se3193be32015", "ollama:s38976770bc28", "ollama:s1be5d1576a50", "ollama:s6b9f9627a574", "ollama:s14d11e19ac27", "ollama:sc06aae169fc9", "ollama:s164b13109d88", "ollama:s3d5c5764fed2", "ollama:s2332130fa1e7", "ollama:s6129c0dd7a10", "ollama:saa84b3aea335", "ollama:s55a8b7a39807", "ollama:s284d5c9ccbf6", "ollama:s589f0e50fa35", "ollama:s3b7fa1fcefbd", "ollama:s828bd193c1fd"], "status": "REASONED"},
    "profiling-app-runs": {"text": "Go 1.26.5 go list -e -deps runs for this guide list no net/http/pprof or runtime/pprof for the v0.34.2 desktop app main package on darwin/windows amd64 and arm64, cgo off and on; linux lists only the error-marked main package. Loaded cells mark app/ui (no app/dist); cgo-off cells cannot load cgo-only app/webview and omit the main package's cgo files with no error, so imports may be incomplete.", "components": ["ollama-sweep"], "sources": ["ollama-sweep:sad61f21372d7", "ollama-sweep:sf38afcc73250", "ollama-sweep:s45897fae891f", "ollama-sweep:s2b2be911f51e", "ollama-sweep:se6c615cc2b3a"], "status": "REASONED"},
    "profiling-app-listener": {"text": "From source reading, the app's UI listener is loopback (127.0.0.1:0, or 3001 in dev mode), served by an http.Server with a non-nil Handler whose mux has a token-cookie check on /api/v1 routes, proxy and catch-all routes without it, and no /debug/pprof pattern. This guide's inference, not run: even a build linking net/http/pprof would not serve DefaultServeMux handlers there.", "components": ["ollama", "go"], "sources": ["ollama:s3cc1f9009971", "ollama:s63598805dfec", "ollama:sf3b9c404c46f", "ollama:s8cc22efcaaca", "go:sab55ef9009c4", "go:s2e779f75153e", "go:s038b2186ee21", "go:sa0c56e16001f"], "status": "REASONED"},
    "profiling-app-gateway": {"text": "From source reading, another loopback app listener is the Claude Desktop gateway on 127.0.0.1:11435, in macOS cgo builds, started only when Claude Desktop is installed. Its non-nil Handler refuses non-loopback Host values and a non-empty first Origin, serves four routes, not /debug/pprof, and forwards only POST /v1/messages, stripping caller auth headers, to the app's OLLAMA_HOST; not run.", "components": ["ollama", "go"], "sources": ["ollama:sa56366559d62", "ollama:sa55b9f381b09", "ollama:s498d9212196e", "ollama:s3d5b427b463a", "ollama:sab2fbcd0c98e", "ollama:s14ee6c3159e4", "ollama:sfc4c24d8630b", "ollama:s80406fd9e16d", "ollama:s5f05208cf314", "ollama:sb816d460f392", "ollama:s1efc29a8d9c6", "ollama:s741bae4c4fa6", "ollama:sb40469426b0e", "ollama:sada8b309ca30", "ollama:sfee7de68771c", "ollama:s6540e626aa77", "go:s7290caae7a3c"], "status": "REASONED"},
    "profiling-app-gateway-start": {"text": "Source reading, not run: startup starts the gateway only if Claude Desktop is installed and configured to use it; setClaudeGatewayInstalled, prepareClaudeDesktopConnection and model mapping start it if installed. The first two stop it unless Claude Desktop then uses it (the first not after an auto-mode error); mapping, if none existed, stops it on profile-change errors except restart confirmation.", "components": ["ollama"], "sources": ["ollama:scbcba9fa2026", "ollama:s776bbcd95f3c", "ollama:s32d2fa1014f8", "ollama:scde20ea5a74a", "ollama:sb2938e867f20", "ollama:s3d5b427b463a", "ollama:sc9151806147c", "ollama:s61e666769722"], "status": "REASONED"},
    "profiling-app-release": {"text": "By this guide's reading of intended builds, not artifacts, build_darwin.sh builds the app package with GOOS=darwin, CGO_ENABLED=1, amd64 and arm64 and no -tags. In build_windows.ps1, buildApp builds it with no -tags, by default setting no GOARCH under its unconditional CGO_ENABLED=1 and, when the cross-compile tools are present, for arm64 (GOOS=windows, GOARCH=arm64, CGO_ENABLED=1).", "components": ["ollama"], "sources": ["ollama:seaa45ac56dd7", "ollama:s41d553145c17", "ollama:s7283b88c8765", "ollama:s14d11e19ac27", "ollama:sc06aae169fc9", "ollama:s1be5d1576a50"], "status": "REASONED"},
    "desktop-app-server": {"text": "From source reading, the desktop app serves no HTTP on the Ollama API listener itself: it runs the separate ollama binary with serve and restarts it, copying its environment, setting OLLAMA_HOST=0.0.0.0 when Expose is on and OLLAMA_ORIGINS=* when Browser is on, so Expose or an inherited OLLAMA_HOST can expose that process. No shipped app binary was inspected and no run observed these behaviours.", "components": ["ollama"], "sources": ["ollama:s4fb8958f1218", "ollama:sacbb561c6cfe", "ollama:sadbce7446a0d"], "status": "REASONED"},
    "verify-inventory": {"text": "Inspect namespaces, publication, identity, store and ACLs; local ss output alone does not establish isolation.", "components": ["ollama", "docker", "systemd"], "sources": ["ollama:sc0e1dbae723e", "docker:s1e53417c513d", "systemd:sd4c1aeb45417"], "status": "REASONED", "verify": [1]},
    "verify-bypass": {"text": "HTTP means direct 11434 answered; fixed refusal needs the real remote path plus successful proxy inference; local errors are inconclusive.", "components": ["ollama", "curl"], "sources": ["ollama:s6be064685bba", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [2]},
    "verify-auth": {"text": "Absent/wrong credentials must refuse while correct credentials complete chat; streamed 200 alone is insufficient.", "components": ["nginx", "ollama", "curl"], "sources": ["nginx:sf32ce2956917", "ollama:s926454766be0", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [3]},
    "verify-tls": {"text": "Correct trust/hostname succeeds; wrong trust/hostname and missing/untrusted mTLS certificates must fail before inference.", "components": ["nginx", "curl"], "sources": ["nginx:sda4ba3fcedbe", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [3]},
    "verify-management": {"text": "Public management must be denied without upstream mutation; private admin operations and public chat supply positive controls.", "components": ["ollama"], "sources": ["ollama:s8fdbeefa696b", "ollama:s926454766be0", "ollama:s670d892bf359", "ollama:s7a9f22479c78"], "status": "REASONED", "verify": [3]},
    "verify-tags": {"text": "Public tags may return 404 with valid credentials; private tags should return model JSON; public 404 is not an authentication test.", "components": ["nginx", "ollama-rolling"], "sources": ["ollama-rolling:s6c2961786919", "nginx:s40bdf1af1596"], "status": "REASONED", "verify": [3]},
    "verify-origins": {"text": "Compare unwanted, required and built-in origins with actual browser calls; POST-only proxy preflight refusals differ by variant.", "components": ["ollama", "nginx", "caddy"], "sources": ["ollama:s26be17f980e1", "nginx:s40bdf1af1596", "nginx:sf0bc2adae8cb", "caddy:s38b1b78ce980"], "status": "REASONED", "verify": [3]},
    "verify-rate": {"text": "Eight bounded requests test admission with limiter/upstream evidence and recovery; the burst alone does not demonstrate both limiters.", "components": ["nginx"], "sources": ["nginx:sb3bee9429629", "nginx:sddc43aac8779"], "status": "REASONED", "verify": [4]},
    "verify-concurrency": {"text": "Hold four accepted requests active within the rate budget, reject another, then confirm a freed slot accepts work.", "components": ["nginx"], "sources": ["nginx:sddc43aac8779"], "status": "REASONED", "verify": [3]},
    "verify-scheduler": {"text": "Compare loading/eviction, keep-alive expiry and actual queue occupancy; public limits can prevent exercising the private queue.", "components": ["ollama"], "sources": ["ollama:s8451cd2c04b7", "ollama:s26be17f980e1"], "status": "REASONED", "verify": [3]},
    "verify-cloud": {"text": "Authorized cloud chat works before disablement and refuses afterward while local chat succeeds; invalid credentials/models are inconclusive.", "components": ["ollama"], "sources": ["ollama:s6be064685bba"], "status": "REASONED", "verify": [3]},
    "verify-captures": {"text": "Compare completed canary requests with logging enabled/disabled in the actual temporary namespace; deny public diagnostics while private controls work.", "components": ["ollama"], "sources": ["ollama:s2265f8345962", "ollama:s926454766be0"], "status": "REASONED", "verify": [3]},
    "proxy-parsing": {"text": "nginx -t and caddy validate check configuration acceptance only; native parsing was not demonstrated here.", "components": ["nginx", "caddy"], "sources": ["nginx:sa28876996ece", "caddy:sc5832c7dc52f"], "status": "REASONED"},
    "curl-version": {"text": "Displayed exitcode and errormsg write-out variables need curl 7.75.0 or later; no tested curl release is recorded.", "components": ["curl"], "sources": ["curl:s2b2686afaf41"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
