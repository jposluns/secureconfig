# Gradio: launch() authentication and TLS

Gradio is a Python framework that serves an interactive web app from a script's launch() call. This guide helps your AI assistant make sure an app is configured securely: a login required, TLS in place, public sharing avoided, file access and uploads restricted, and queued work and URL fetching bounded.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/gradio.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Gradio 6.31.0 and Gradio historical fixes 6.16.0 and 6.20.0; 2 further sources carry no recorded version. Metadata reviewed 2026-11-07; documentation checked September 2026. The guide records 53 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Gradio binds to `127.0.0.1` by default. Two launch choices create exposure: `server_name="0.0.0.0"` (all interfaces) and `share=True` (a public `*.gradio.live` URL through Gradio's relay). Neither is acceptable without authentication.

At the time of writing, this guide targets **Gradio 6.31.0**, the recommended deployment baseline for these examples. Parameters and defaults were checked against the 6.28.0 source and vendor documentation in September 2026. In November 2026 the cited Interface ranges were re-read at 6.31.0 and the Blocks and routes source was compared between 6.28.0 and 6.31.0, by source reading with nothing run; the vendor documentation was not rechecked. Historical security fixes below explain why older minimum versions are insufficient. See the [6.31.0 release](https://github.com/gradio-app/gradio/releases/tag/gradio%406.31.0).

The launch examples are alternatives. Apply the relevant controls to your app's single `launch()` call, and configure its queue before launching.

## 1. Require a login

`launch()` takes credentials directly:

```python
import os
demo.launch(
    server_name="127.0.0.1",   # bind loopback explicitly; if omitted it can inherit GRADIO_SERVER_NAME
    share=False,                # if omitted, share can inherit GRADIO_SHARE=True or auto-enable in Colab/hosted notebooks
    auth=(os.environ["GRADIO_USER"], os.environ["GRADIO_PASS"]),
    auth_message="Authorized users only",
)
```

`auth` also accepts a list of `(user, password)` tuples or a callable `f(username, password) -> bool`, which lets you check hashed credentials per [authentication.md](authentication.md). Keep the credentials in environment variables, not in the script.

MFA: `auth` is single-factor, with no rate limiting, login throttling, or automatic lockout. The callable form allows a TOTP step (for example, verify a [pyotp](https://github.com/pyauth/pyotp) code appended to the password), but a bare verification callback is not enough on its own: it needs secure enrollment, secret storage, and replay rejection. Fronting the app with Cloudflare Access or an Authelia-protected proxy is the cleaner route, but configure that service's own brute-force controls (Authelia regulation, Cloudflare rate limiting) and disable or separately protect any Gradio login you keep behind it, since fronting does not add throttling or lockout to the built-in login. Options in [mfa.md](mfa.md).

For external authentication, `launch(auth_dependency=callback)` accepts a callback receiving a FastAPI request and returning a user ID for an authorized request or `None` to deny it. It cannot be combined with `auth`. Validate the identity provider's session or token in that callback; do not trust an identity header supplied directly by a caller. If a proxy supplies identity, it must remove caller-supplied identity headers, inject authenticated values, and be the only route to the backend. Enforce MFA, login throttling, lockout, and session lifetime at the identity provider or proxy. See the [launch reference](https://gradio.app/docs/gradio/blocks) and [authentication dependency and login handlers](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py).

Native password login creates random bearer session tokens stored in the app process's memory. It issues an HttpOnly, Secure cookie and an HttpOnly insecure-cookie fallback; the server accepts either. There is **no server-side token expiry** in this native token store. Restarting the app clears its tokens, and the native `/logout` route revokes all sessions for the username by default (`all_session=True`). Browser cookie lifetime is not server-side revocation. Require HTTPS, prevent direct backend access, and enforce a finite session lifetime externally on every request; a copied native cookie must not bypass that external check. Inspect both cookies when configuring proxy cookie hardening. See the [native session implementation](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py).

## 2. Enable TLS

For a public deployment, prefer a reverse proxy or tunnel in front of a loopback-bound Gradio app: [caddy.md](caddy.md), [nginx.md](nginx.md), or [cloudflare.md](cloudflare.md). Gradio can also serve HTTPS itself with a certificate from [free-certificates.md](free-certificates.md) or [self-signed.md](self-signed.md):

```python
import os
demo.launch(
    server_name="0.0.0.0",
    server_port=8443,
    share=False,        # even for a TLS deployment: never implicitly share via GRADIO_SHARE or Colab
    ssl_certfile="/path/cert.pem",
    ssl_keyfile="/path/key.pem",
    ssl_verify=False,   # without SSR, launch() requests a URL under https://localhost:PORT/ at startup; needed unless the cert is valid for localhost
    ssr_mode=False,     # SSR can put a plain-HTTP Node proxy on the public port (blocks.py 3326-3328; proxy_index.js 56)
    auth=(os.environ["GRADIO_USER"], os.environ["GRADIO_PASS"]),
)
```

`ssl_keyfile_password` exists for encrypted keys. With `server_name="0.0.0.0"` and a default first `launch()` without SSR, `launch()` makes a startup request to a URL under `https://localhost:PORT/` using `ssl_verify`, so `ssl_verify=False` is needed for a self-signed certificate, and for a CA-issued certificate that does not also name `localhost`. Outside dev mode, with SSR on and Node available, Gradio 6.31.0 moves Python, still with TLS, to an internal port and tries to start a Node proxy on the user-facing port that reaches Python over plain `http://` (blocks.py lines 3326-3328 select this path and 3500-3506 start Node; [Node proxy source](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/js/app/proxy_index.js) lines 1, 22 and 56). Gradio keeps Node only if it answers `HEAD /` below 500 within 30 seconds ([node_server.py](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/node_server.py) lines 183 and 265-281), and what the SvelteKit handler answers to that request, with Python behind it on TLS, is not established here. If Node is not kept, Gradio tries to move Python, with TLS, onto the user-facing port (blocks.py lines 3518-3529); if that port is not free, or is lost in a race, Python stays only on the internal port and Gradio warns (blocks.py lines 3537-3544, 3875-3877 and 3890-3897). SSR turns on with `ssr_mode=True` or `GRADIO_SSR_MODE=true`, and an explicit `ssr_mode=False` overrides the variable (blocks.py lines 3035-3039, the argument tested first at 3036-3037). So the example pins `ssr_mode=False`. In blocks.py, http_server.py and networking.py at 6.31.0 the only use of the flag is `verify=ssl_verify` at blocks.py line 3561. The flag is also stored on the Blocks object (line 3221, default True at line 1454), so other modules could read it. Supply any key password through your secret manager or environment, not a literal in the script. See the [TLS parameters](https://gradio.app/docs/gradio/blocks), the [launcher startup request](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py) (blocks.py lines 3035-3039 and 3085 for the SSR default, 3407-3415 for the first `launch()`, and 3431-3432 and 3559-3563 for the request), and the [localhost URL choice](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/http_server.py) (http_server.py lines 113 and 186-187).

Behind a proxy, keep `server_name="127.0.0.1"` explicit. The argument defaults to `None`, resolving through `GRADIO_SERVER_NAME` to loopback when that variable is unset. If the proxy publishes the app beneath `/demo`, `root_path="/demo"` builds the corresponding URLs. It is **not an access control** and does not replace authentication or prevent direct access to the backend. See the [launch reference](https://gradio.app/docs/gradio/blocks).

## 3. share=True is publication

`share=True` publishes the app at a random public URL for anyone who obtains the link, with your machine executing the requests. Use it only for short demos, always combined with `auth`, and shut it down afterwards. It is not a deployment mechanism; for persistent authenticated remote access use [cloudflare.md](cloudflare.md).

Set `share=False` explicitly in the deployed launch call. When omitted, sharing can inherit `GRADIO_SHARE=True` or auto-enable in Colab and hosted notebooks. A loopback listener does not prove that a share tunnel is absent. See the [sharing defaults and launch behavior](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py).

## 4. Restrict file access

`launch()` serves files over a `/gradio_api/file=` route. By default it serves three things: static files you register with `gr.set_static_paths()`, the directories you list in `allowed_paths`, and Gradio's own cache. A path handed back through a file-based output component can be served too when it lies in `allowed_paths`, the current working directory, or the system temp directory; files Gradio caches this way are reachable by every user of the app, not only the one who produced it. Dotfiles in the working directory are excluded from automatic caching unless explicitly permitted. This exception does not justify storing secrets beside the app. See [file access](https://gradio.app/guides/file-access).

- The reliable boundary is a minimal filesystem available to the process, with narrowly scoped additional paths. `allowed_paths` **adds exposure**; it is not an exclusive sandbox. An empty list does not disable cache serving or eligible returned files. Launch from a directory that holds no `.env`, keys, or private source, and add only the directories users must download from to `allowed_paths` and `gr.set_static_paths()`, as absolute paths, each holding only public files, since a directory there exposes all of its files and subdirectories.
- `blocked_paths` takes precedence over the default set, `allowed_paths`, and `set_static_paths()`, but it is a blocklist: filesystem quirks, including case handling and NTFS alternate data streams, have enabled bypasses of path blocklists, so treat it as a backstop and keep Gradio on a current release.
- Never return untrusted user input through a file-based output component: Gradio can serve an eligible returned path that lies in the working or temp directory, so a crafted value can hand back a file you did not mean to expose. The working-directory dotfile exception does not protect other eligible files.
- Set `max_file_size` on `launch()` (bytes, or a string such as `"5mb"`); it defaults to `None`, which leaves uploads unlimited. It is a per-file limit, not a total-storage quota, so pair it with disk and rate controls at the proxy. **6.20.0 fixed missing enforcement on multipart `/component_server` uploads**; setting this argument on an older version is insufficient. Use the 6.31.0 baseline. See the [upload fix](https://github.com/gradio-app/gradio/releases/tag/gradio%406.20.0).

Both `allowed_paths` and `blocked_paths` default to `None` in 6.31.0. They fall back to the comma-separated `GRADIO_ALLOWED_PATHS` and `GRADIO_BLOCKED_PATHS` environment variables **even when passed `[]`**. Audit the environment of the actual service process. Remove unintended inherited values; when moving policy into explicit arguments, retain any required denies in `blocked_paths`. Do not assume an empty argument cleared an inherited grant or deny. See the [path resolution implementation](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py).

Set `GRADIO_TEMP_DIR` in the service environment before starting Gradio, for example:

```
GRADIO_TEMP_DIR=/srv/gradio-cache
```

Provision that absolute directory for the Gradio service account, with restrictive filesystem permissions such as mode `0700`, a storage quota, and an appropriate cleanup policy. Keep it separate from source, secrets, and other services' temporary data. This relocates Gradio's cache; it does **not** add per-user download authorization. Cached uploads and outputs remain readable by other app users who obtain their URLs. Filesystem permissions constrain other local accounts, not requests served by the Gradio process. See the [cache location and sharing rules](https://gradio.app/guides/file-access).

CVE-2023-51449, the historical `/file` traversal vulnerability, and the associated SSRF issue were fixed in **4.11.0**. That is a historical fix floor, not a deployment baseline. **6.16.0** includes FileExplorer traversal fixes. The case-handling advisory GHSA-j2jg-fq62-7c3h / CVE-2025-23042 remains a reason to distrust blocklists as the primary boundary; its patched-version records conflict, so this guide assigns it no precise fixed version. Use **6.31.0** as the baseline here. See the [historical traversal advisory](https://github.com/gradio-app/gradio/security/advisories/GHSA-6qm2-wpxq-7qh2), [case-handling advisory](https://github.com/gradio-app/gradio/security/advisories/GHSA-j2jg-fq62-7c3h), and [6.16.0 fixes](https://github.com/gradio-app/gradio/releases/tag/gradio%406.16.0).

## 5. Disable optional execution surfaces

Leave `GRADIO_VIBE_MODE` **unset** in production, and do not start the deployed app with `gradio --vibe`. Its default is the empty string, and the implementation tests string truthiness: **any non-empty value, including `"False"` or `"0"`, enables it**. The vibe-code handlers lack a native login check and allow source reading and modification; vibe mode permits arbitrary code execution on the host. Adding `auth` to ordinary app routes does not secure those handlers. See the [vibe-mode setting](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py), [vibe handlers](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py), and [vendor development-only warning](https://gradio.app/guides/developing-faster-with-reload-mode).

Set `launch(mcp_server=False)` unless you deliberately publish MCP tools. Its default is `None`, which consults `GRADIO_MCP_SERVER`; that variable defaults to `"False"`. Enabling it exposes tools beneath `/gradio_api/mcp/`. If MCP is required, protect and test that surface separately. A 401 from `/gradio_api/info` does **not** establish MCP protection; this guide has not demonstrated MCP authentication behavior. See the [MCP setup implementation](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py) and [MCP documentation](https://gradio.app/guides/building-mcp-server-with-gradio).

API visibility is separate from authorization:

| Setting in Gradio 6.31.0 | Effect |
| --- | --- |
| `launch(footer_links=["gradio", "settings"])` | Omits the API documentation link. It does not disable the API. This replaces `launch(show_api=False)`. |
| Event listener `api_visibility="public"` | The default: documented and callable through Gradio clients. |
| Event listener `api_visibility="undocumented"` | Hides documentation while remaining callable. |
| Event listener `api_visibility="private"` | Hides documentation and blocks Gradio-client use. Direct HTTP requests can still invoke the function, subject to authentication and queue policy. |
| `api_name=None` | Derives an endpoint name from the function. It does not create an inaccessible endpoint. `api_name=False` is no longer a supported public argument. |

Both the migration guide and the current reference distinguish Gradio-client visibility from HTTP authorization: setting an event to `"private"` prevents Gradio-client discovery and use, but direct HTTP requests remain possible, and the HTTP prediction handler checks login and queue policy separately. Native login checks protect `/config`, `/gradio_api/info`, prediction routes, and queue join/data routes when `auth` or `auth_dependency` is configured. Hiding a link or endpoint name does not replace those checks. See the [6.x migration guide](https://gradio.app/guides/gradio-6-migration-guide), [event reference](https://gradio.app/docs/gradio/button), and [HTTP handlers](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py).

## 6. Bound queued work and close the direct-API bypass

Configure `demo.queue(api_open=False, default_concurrency_limit=1, max_size=20)` before launching, and set `max_threads=8` and `max_file_size="5mb"` on `launch()`. This complete, harmless example also applies the optional-surface and collection settings described in this guide:

```python
import os
import gradio as gr

def echo(text):
    return text

demo = gr.Interface(
    fn=echo,
    inputs="text",
    outputs="text",
    api_name="echo",
    flagging_mode="never",
    analytics_enabled=False,
)
demo.queue(api_open=False, default_concurrency_limit=1, max_size=20)
demo.launch(
    server_name="127.0.0.1",
    share=False,
    auth=(os.environ["GRADIO_USER"], os.environ["GRADIO_PASS"]),
    auth_message="Authorized users only",
    mcp_server=False,
    max_threads=8,
    max_file_size="5mb",
    run_history=False,
    footer_links=["gradio", "settings"],
)
```

Use the audited environment and isolated filesystem from sections 4 and 5, and publish through the authenticated HTTPS proxy from sections 1 and 2. Replace the echo function with the intended application.

At the time of writing, the 6.31.0 defaults and these illustrative limits are:

| Control | Default | Example |
| --- | --- | --- |
| `queue(api_open=...)` | Argument `None`; effective `True` off Hugging Face Spaces | `False` |
| `default_concurrency_limit` | `1` unless changed through `GRADIO_DEFAULT_CONCURRENCY_LIMIT` | `1` |
| `max_size` | `None`, no queue-size limit; ZeroGPU Spaces have a special default | `20` |
| `max_threads` | `40` | `8` |
| `max_file_size` | `None`, no upload-size limit | `"5mb"` |

`api_open=False` closes the direct `/gradio_api/run/` and `/gradio_api/api/` bypass **for queued functions**. It does not disable the queued API. Events configured with `queue=False` remain outside this boundary, so audit listener overrides. The default concurrency limit applies to listeners that use the default, not as one global request limit across every function; explicit listener concurrency settings can override it.

These numbers are illustrative capacity limits, not per-user quotas or rate limits. Apply request-rate, body-size, storage, and resource controls at the deployment layer as appropriate. A single authenticated caller can otherwise consume the available capacity. See the [queue and launch implementation](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py), [direct-request refusal](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py), and [launch reference](https://gradio.app/docs/gradio/blocks).

## 7. Restrict server-side URL fetching

Treat URL inputs as an outbound network surface. MCP file inputs accept URLs, and component processing can fetch remote resources. Gradio 6.31.0 has no general destination-allowlist argument covering every server-side fetch. Use deployment egress restrictions and application-controlled destination allowlists, including validation of redirects and resolved destinations. Do not let callers choose arbitrary remote apps or URLs for server-side fetching. Authentication limits who submits a URL; it does not make the destination safe. See the [MCP file behavior](https://gradio.app/guides/building-mcp-server-with-gradio), [component cache downloads](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py), and [launch reference](https://gradio.app/docs/gradio/blocks).

Current fetches are not all unprotected. **6.16.0** fixed SSRF in Image/Gallery SVG processing and Audio streaming processing. **6.20.0** changed `/gradio_api/file=<url>` from an open redirect to an SSRF-protected streaming proxy. Keep those protections and the 6.31.0 baseline; deployment egress policy provides the application-specific destination boundary. See the [6.16.0 fixes](https://github.com/gradio-app/gradio/releases/tag/gradio%406.16.0), [6.20.0 proxy change](https://github.com/gradio-app/gradio/releases/tag/gradio%406.20.0), and [current file route](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py).

For `gr.load(name, src=..., token=...)`, keep `name` and `src` under application control and load only trusted targets. The `token` can inherit `HF_TOKEN`; the current reference distinguishes model loading, which can also use a locally saved token, from Space loading. A token supplied to a loaded Space can be read by that Space. Do not pass a privileged token to an untrusted Space, and do not assume `token=None` universally means no credentials will be used. See the [load reference](https://gradio.app/docs/gradio/load).

## 8. Disable unnecessary persistent collection

Set `flagging_mode="never"` in **`gr.Interface(...)`**, as in section 6. This is the current spelling of `allow_flagging`; it is not a `launch()` argument. The default is resolved through `GRADIO_FLAGGING_MODE` and otherwise is `"manual"`. `"auto"` records every submission and its generated output. The default `CSVLogger` writes beneath `.gradio/flagged`, including saved file data for file-based components. Disable flagging when this collection is unnecessary, and apply an explicit retention and access policy where it is required. See the [Interface reference](https://gradio.app/docs/gradio/interface) and [flagging storage behavior](https://gradio.app/guides/flagging).

Consider `launch(run_history=False)`. In 6.31.0 its default is `None`, resolving through `GRADIO_RUN_HISTORY` to `True`. Run history stores runs privately in the browser by default; users can connect a Hugging Face bucket for subsequent runs. Disabling it stops recording, disables the history page, and removes previously saved browser history for that app. Do not assume this deletes separately retained bucket data or existing flagging files. See the [run-history reference](https://gradio.app/docs/gradio/blocks).

`analytics_enabled=False` belongs on `Blocks` or `Interface`, as shown in section 6. It disables basic telemetry and is separate from flagging and run history. Its default is `None`, resolving through `GRADIO_ANALYTICS_ENABLED` to `True`. This lower-priority privacy setting is not evidence that prediction inputs are sent as telemetry, and it does not establish that application logs or other integrations retain no inputs. See the [Blocks reference](https://gradio.app/docs/gradio/blocks) and [Interface reference](https://gradio.app/docs/gradio/interface).

## 9. Verify

**REASONED:** Verification overview and historical authoring report; no live Gradio, HTTPS ingress, second host, or IdP fixture is supplied for this offline run. Per the guide's cited Gradio 6.31.0 Blocks source and Gradio 6.31.0 routes source, compare the exposed/fixed outcomes specified below. In this marking run, three Python examples parsed, all three Verify shell blocks passed bash -n and ShellCheck 0.11.0 with no output, and stubbed guards rejected invalid inputs without curl calls; these are local checks only. The bash -n, ShellCheck and stub runs recorded here covered the base-URL probe block and the protected request helper in an earlier form, whose guard refusals exited with status 1; none was re-run on the current form, whose guard refusals exit with status 2. Every bash -n, ShellCheck and stub run recorded in this section also predates the change that makes each of the three Verify shell blocks report its result in its exit status (1 for a finding, 2 for a guard refusal, 3 for a failed or inconclusive check, 0 for a pass or a named unclassified observation), so those runs covered an earlier form. They also predate the listener inventory block's `ss` presence check, which refuses with status 2 when `ss` is not installed. The gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form of each block. Stub runs of the listener inventory block's current form, with a stub `ss`, in a clean shell and under an inherited `readonly`, `declare -i` and `set -e`, exited 0 when `ss` passed, 3 when it failed and 2 when it was missing. The following environment and run account describes the earlier authoring session. These service checks are **reasoned, not demonstrated**. The authoring environment has no installed Gradio or container runtime, has restricted network access, and provides no authorized live Gradio deployment, second-host ingress fixture, or identity provider. Python syntax, Bash parsing, ShellCheck 0.11.0, and the repository's guard scan were checked locally; they do not demonstrate service behavior. Expected exposed/fixed outcomes rest on the cited Gradio 6.31.0 source and vendor documentation.

**REASONED:** Comparison-fixture isolation and evidence collection, per the guide's cited Gradio 6.31.0 Blocks source and Gradio 6.31.0 routes source; no authorized live Gradio or public-ingress fixture is supplied here. The local shell and stub checks recorded above ran, but publication, native refusal, and successful authorized controls remain the expected comparisons below, not observations. Those shell and stub checks covered the base-URL probe block and the protected request helper in an earlier form, whose guard refusals exited with status 1; neither block was re-run in its current form, whose guard refusals exit with status 2. Use a disposable private fixture for exposed comparisons, with harmless data and disposable credentials. Record the installed Gradio version, effective configuration, response content, and the layer issuing each refusal. Do not expose an unauthenticated or vibe-enabled comparison to the internet.

### Binding, sharing, TLS, and native login

**REASONED:** The deployment host and a live share-tunnel fixture are unavailable here. On the application host, inspect the listener and the current launch's complete startup output. An exposed fixture with `server_name="0.0.0.0"` should show an all-interface bind; the proxy-backed configuration should show loopback. A shared fixture should print its public URL and be reachable through it; the fixed fresh process must satisfy all three conditions below. See the [launch and sharing implementation](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py).

```bash
(                                       # a subshell, so the exits below end only the subshell
  set +e                                # errexit off here, so a failed ss is reported below instead of ending the block
  command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
  ss -tlnp   # With server_port=None, the port search starts at 7860 unless GRADIO_SERVER_PORT changes it.
             # Expect loopback unless deliberately exposed. ss shows a local BIND only, and it CANNOT detect
             # a share=True tunnel: that keeps the listener on loopback and opens an OUTBOUND frpc connection to
             # Gradio's relay publishing a *.gradio.live URL. Confirm share is off with all three checks, and if you
             # cannot confirm ALL THREE, treat it as UNKNOWN (not off): (1) the previous app process or
             # notebook kernel and its tunnel are terminated FIRST (a rerun with share=False in a persistent
             # kernel clears the URL but can leave the earlier tunnel connected), (2) share=False is set in
             # the launch() call, and (3) THIS fresh run's full startup output shows no "Running on public
             # URL: https://<name>.gradio.live" line (a shared run prints it in its startup output, so read the current
             # launch's output, not a stale log). If you know a former public URL, also confirm it is now
             # unreachable. Terminate any share tunnel after a demo.
  case "$?" in
    0) echo "block exit 0, an unclassified observation: ss cannot show a share=True tunnel, so read the listeners above and confirm all three share conditions yourself"; exit 0 ;;
    *) echo "ss -tlnp failed; inconclusive"; exit 3 ;;
  esac
)
```

**REASONED:** following block; native authentication and certificate checks require live HTTPS ingress and an outside client, unavailable here. A served login page does NOT prove the API is gated. Probe a protected API route WITHOUT a Gradio session cookie. With native authentication absent on the isolated comparison fixture, `/gradio_api/info` should return 200 with API information; with native authentication enabled, Gradio's own `login_check` should return 401. See the [protected info route and login check](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py).

**REASONED:** Native versus proxy authorization, per the guide's cited Gradio 6.31.0 routes source; no live Gradio behind an authenticated proxy is supplied here. The helper's stubbed GET retained the protected header-file argument and printed 'STUB curl called; no HTTP observation'. That stub run covered the protected request helper in an earlier form, whose guard refusals exited with status 1; it was not re-run on the current form, whose guard refusals exit with status 2. Expect API information without native auth, native 401 without its cookie after enabling auth, and 200 with a fresh cookie while proxy authorization stays constant. Keep the request otherwise identical to a real client, including any fronting-proxy authorization, so the ONLY thing removed is the Gradio cookie - then a 401 can be attributed to Gradio's native auth, not the proxy. Supply proxy credentials from a protected header file using the helper below; never put them in command arguments. `auth_dependency` deployments need the separate external-auth comparison below.

**REASONED:** following block; base-URL substitution, native API authentication, and TLS, per the guide's cited Gradio 6.31.0 routes source and Gradio Blocks.launch() parameters (rolling documentation, checked September 2026). No live HTTPS Gradio or outside client is supplied here: expect exposed 200, native-auth 401, and, via the protected helper below, fresh-cookie 200. Locally bash -n and ShellCheck 0.11.0 exited 0 without output; missing marker/assignment, wrong count, empty/placeholder/example/angle/control-character URLs, and HTTP were rejected with explanatory messages and zero stub curl calls. A substituted HTTPS prefix reached stub curl with /gradio_api/info and printed 'STUB curl called; no HTTP observation'. The bash -n, ShellCheck and stub runs recorded here covered the following block in an earlier form, whose guard refusals exited with status 1; none was re-run on the current form, whose guard refusals exit with status 2. Substitute the actual base URL inside the quotes. For a fronting proxy this might be `https://gradio.example.com`; for a direct section-2 TLS launch use the actual host with `:8443`. Include any `root_path` prefix, and use the SAME base URL (host, port, prefix) for `/login` below. Do not put credentials or signed URLs in the substitution. A literal apostrophe requires proper shell quoting. Paste whole blocks; the marker and count checks do not protect fragments pasted below their guards or shells with shadowed builtins.

```bash
# REASONED: native API authentication and TLS; no live HTTPS Gradio fixture or outside client here. Expected exposed/fixed outcomes follow the cited 6.31.0 handlers.
(
  set +e                                # errexit off here, so a failed request is reported below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'https://REPLACE_WITH_GRADIO_HOST'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one base URL; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|""|*[[:cntrl:]]*)
      echo "substitute the actual base URL inside the quotes; not probing"; exit 2 ;;
    https://*)
      set -- "$1" "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 \
        -D - -o /dev/null -w 'anon=%{http_code} exit=%{exitcode} err=%{errormsg}\n%{http_code}' \
        "${1%/}/gradio_api/info"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
      set -- "$1" "${2##*$'\n'}" "${2%$'\n'*}"   # curl's exit status, then its output
      printf '%s\n' "${3%$'\n'*}"         # the response headers and the anon= line
      case "$2:${3##*$'\n'}" in
        0:401) echo "pass: /gradio_api/info refused the request with 401; a fronting proxy's own 401 looks the same, so attribute it with the protected helper below"; exit 0 ;;
        0:200) echo "FINDING: /gradio_api/info answered 200 without a Gradio session cookie"; exit 1 ;;
        0:*) echo "HTTP ${3##*$'\n'} is neither native authentication's 401 nor the exposed 200; inconclusive"; exit 3 ;;
        *) echo "curl exit $2: a TLS, DNS or connection failure is not an authentication refusal; inconclusive"; exit 3 ;;
      esac
      ;;
    *) echo "use an HTTPS base URL; not probing"; exit 2 ;;
  esac
)
```

**REASONED:** preceding block; TLS and native API probing, including its URL guards and request options, per the guide's cited Gradio 6.31.0 routes source and Gradio Blocks.launch() parameters (rolling documentation, checked September 2026). No live HTTPS endpoint or deployment CA is supplied here; expect API 200 before native auth, 401 without its cookie afterwards, and, via the helper below, 200 with a fresh cookie, not a transport failure. Local bash -n and ShellCheck 0.11.0 exited 0 without output; guard failures made no stub curl calls, and valid HTTPS preserved -q, -g, --noproxy '*' and the prefix, printing 'STUB curl called; no HTTP observation'. The bash -n, ShellCheck and stub runs recorded here covered the preceding block in an earlier form, whose guard refusals exited with status 1; none was re-run on the current form, whose guard refusals exit with status 2. `--noproxy '*'` prevents a client proxy from answering. With a self-signed certificate from section 2, add `--cacert your-ca.pem` using your actual CA file, never `-k`. `-D -` shows status and headers rather than just the body. A TLS, DNS, or connection failure is not an authentication refusal.

**REASONED:** Login positive control, per the guide's cited Gradio 6.31.0 routes source; no live Gradio or browser fixture is supplied here. Stubbed LOGIN and GET printed 'STUB curl called; no HTTP observation', retained file-based request arguments, and created response files with mode 0600 in mode-0700 directories. Those stub runs covered the protected request helper in an earlier form, whose guard refusals exited with status 1; none was re-run on the current form, whose guard refusals exit with status 2. Expect cookie-free native 401 after enabling auth and fresh-cookie 200 with app content; browser gating and real cookie issuance remain unobserved. Positive control: get a Gradio session cookie by POSTing your credentials to `/login` (form fields `username` and `password`), then re-request that same route WITH the cookie and confirm 200 with app content. Static assets are public, so test a protected route, not the home page. In a private browser the login form should appear before the app (necessary, not sufficient).

### Protected requests for the comparisons below

**REASONED:** Protected request headers, per the guide's cited Gradio 6.31.0 routes source; no live native/proxy authentication fixture is supplied here. A local mode-0600 dummy header file was passed unchanged by the stubbed helper; its GET printed 'STUB curl called; no HTTP observation'. That stub run covered the protected request helper in an earlier form, whose guard refusals exited with status 1; it was not re-run on the current form, whose guard refusals exit with status 2. Expect exposed API 200, native 401 when only its cookie is removed after enabling auth, and authorized 200 with a fresh cookie. Prepare a mode-0600 header file in a private directory. For a signed-in request, include the native `Cookie:` header and any required proxy authorization. For the native anonymous comparison, retain proxy authorization and remove only Gradio's cookies. Use an empty file when no headers are required.

**REASONED:** Request bodies and private results, per the guide's cited Gradio 6.31.0 routes source; no live login/prediction fixture is supplied here. The local marker JSON parsed; stubbed POST and LOGIN printed 'STUB curl called; no HTTP observation' and retained body-file and content-type arguments, with response files mode 0600 and directories mode 0700. Those stub runs covered the protected request helper in an earlier form, whose guard refusals exited with status 1; none was re-run on the current form, whose guard refusals exit with status 2. Expect unauthorized refusal after enabling native auth and successful fresh-cookie requests; no real credentials or responses were tested. Prepare a separate protected body file: JSON for `POST`, URL-encoded `username` and `password` form fields for `LOGIN`, and an empty file for `GET`. Do not put credentials in shell history or enable shell tracing while handling them. The helper keeps response headers, bodies, and login cookies private because they can contain credentials.

**REASONED:** This helper's request outcomes require the live HTTPS fixture, unavailable here. Use it for the concrete exposed/fixed comparisons below. Its local parsing and guard checks do not establish those outcomes. Those parsing and guard checks covered the following block in an earlier form, whose guard refusals exited with status 1; none was re-run on the current form, whose guard refusals exit with status 2.

```bash
(
  set +e                                # errexit off here, so a failed request is reported below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_ENDPOINT_URL' 'GET' 'REPLACE_WITH_HEADER_FILE' 'REPLACE_WITH_BODY_FILE'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "provide endpoint, method, header file and body file; not probing"; exit 2; }
  case "|$1|$2|$3|$4|" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|*'||'*|*[[:cntrl:]]*)
      echo "substitute every placeholder inside the quotes; not probing"; exit 2 ;;
  esac
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the endpoint; not probing"; exit 2 ;;
    https://*)
      [ -r "$3" ] || { echo "header file is unreadable"; exit 2; }
      [ -r "$4" ] || { echo "body file is unreadable"; exit 2; }
      umask 077
      set -- "$@" "$(mktemp -d)"         # empty if mktemp fails, which the next line catches
      [ -d "$5" ] || { echo "cannot create private results directory"; exit 3; }
      printf 'Private response directory: %s\n' "$5"
      case "$2" in
        GET)
          curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 60 \
            -H "@$3" -o "$5/body" -D "$5/headers" \
            -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1"
          ;;
        POST)
          curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 60 \
            -H "@$3" -H 'Content-Type: application/json' --data-binary "@$4" \
            -o "$5/body" -D "$5/headers" \
            -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1"
          ;;
        LOGIN)
          curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 60 \
            -H "@$3" -H 'Content-Type: application/x-www-form-urlencoded' --data-binary "@$4" \
            -c "$5/cookies" -o "$5/body" -D "$5/headers" \
            -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1"
          ;;
        *) echo "use GET, POST or LOGIN; not probing"; exit 2 ;;
      esac
      set -- "$1" "$2" "$3" "$4" "$5" "$?"   # curl's exit status
      case "$6" in
        0) echo "block exit 0, an unclassified observation: a completed request is not a pass on its own, so compare the http= line above and the response in $5 with the comparison you are running"; exit 0 ;;
        *) echo "curl exit $6: the request failed; inconclusive"; exit 3 ;;
      esac
      ;;
    *) echo "use HTTPS; not probing"; exit 2 ;;
  esac
)
```

**REASONED:** preceding block; the complete protected helper, including guards, GET/POST/LOGIN dispatch, request files, private responses, and login controls, per the guide's cited Gradio 6.31.0 routes source. No live HTTPS Gradio or deployment CA is supplied here; expect the exposed/fixed comparisons below and fresh-cookie success. Locally bash -n and ShellCheck 0.11.0 exited 0 without output; invalid marker/count/URL/method and missing files produced explanatory refusals with zero stub curl calls. Valid GET/POST/LOGIN printed 'STUB curl called; no HTTP observation', retained request-file arguments, and produced mode-0600 response files in mode-0700 directories. The bash -n, ShellCheck and stub runs recorded here covered the preceding block in an earlier form, whose guard refusals exited with status 1; none was re-run on the current form, whose guard refusals exit with status 2. The guard checks arguments, not file contents. Inspect request files before sending them. For the login positive control, use `LOGIN` against `/login`, then place the returned session cookie in the protected header file and use `GET` against `/gradio_api/info`. Add the actual CA file to these curl invocations when using a private CA. Preserve redacted evidence, then remove disposable accounts, uploads, credentials, and response files.

### File access and upload limits

**REASONED:** This requires a running Gradio with writable disposable marker directories and authenticated file downloads, unavailable here. Use the protected helper for each GET. The exposed and fixed outcomes follow the [file access rules](https://gradio.app/guides/file-access) and [authenticated file route](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py).

**REASONED:** File blocklist discrimination, per the guide's cited Gradio file access (rolling documentation, checked September 2026) and Gradio 6.31.0 routes source; no live authenticated file-serving Gradio is supplied here. Local marker creation/readback and the helper's stubbed GET ran; they do not exercise Gradio's file route. That stubbed GET covered the protected request helper in an earlier form, whose guard refusals exited with status 1; it was not re-run on the current form, whose guard refusals exit with status 2. Expect both marker contents before blocking, then blocked 403 with the other marker still served after restart and fresh login, as detailed below. While signed in, create two harmless marker files with recognizable contents in a directory you added to `allowed_paths`, then request each over `/gradio_api/file=` (with any deployment URL prefix) and confirm BOTH return their marker contents. Only then add one to `blocked_paths` and restart. After the restart, log in again for a fresh session cookie (a restart resets Gradio's session tokens, so the old cookie now returns 401, which is a session failure, not a blocklist result) and confirm BOTH files still exist on disk with their contents (a restart can also clear a temp or cache directory, and a file that vanished returns the same 403 as a blocklist refusal). The step after that on-disk check is to request each file with the fresh cookie: the blocked one must return 403 while the other still returns its contents. For a stronger check, remove it from `blocked_paths`, restart again, and confirm it serves once more. Establishing that both served their contents first, and that the blocked one still exists after the restart, is what distinguishes a `blocked_paths` refusal from a missing file, a wrong path, a login prompt, or a proxy denial (the `/gradio_api/file=` route returns the same refusal for several of these).

| Comparison | Request and expected exposed/fixed outcomes |
| --- | --- |
| Environment fallback and cache isolation | **REASONED:** Requires a live app, two test users, and disposable directories, unavailable here. Put a harmless directory outside the working, system-temp, and cache directories in `GRADIO_ALLOWED_PATHS`; with `allowed_paths=[]`, GET its marker through `/gradio_api/file=` and expect its contents. Unset that environment grant, restart, log in again, and require refusal while an intentionally allowed marker still serves. Separately upload a harmless file as user A, then GET its returned cache URL as user B. Moving `GRADIO_TEMP_DIR` should change storage location, but user B can still read the cached file. Inspect filesystem ownership and quota separately; cache relocation is not user isolation. See [path fallback](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py) and [shared cache](https://gradio.app/guides/file-access). |
| Upload size | **REASONED:** Requires a live file component and a component that sends multipart `/gradio_api/component_server` requests, unavailable here. Through the browser, upload valid harmless files below and above 5 MB and inspect the requests to `/gradio_api/upload` and, separately, `/gradio_api/component_server`. With `max_file_size=None`, both sizes should reach the applicable handler. With `"5mb"` on 6.31.0, the smaller file must still work and the larger must be refused for size. A malformed multipart body, absent component handler, or proxy rejection does not demonstrate Gradio's limit. Record the valid multipart fields from the actual component request. See the [6.20.0 enforcement fix](https://github.com/gradio-app/gradio/releases/tag/gradio%406.20.0) and [multipart handler](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py). |

### Optional surfaces, authorization, capacity, and collection

**REASONED:** Route-prefix and optional-surface comparisons, per the guide's cited Gradio 6.31.0 routes source and Gradio MCP server documentation (rolling documentation, checked September 2026); no live Gradio, browser, MCP client fixture, or IdP is supplied here. Local marker JSON parsed and stubbed helper requests preserved the HTTPS prefix, printing 'STUB curl called; no HTTP observation'. Those stubbed requests covered the protected request helper in an earlier form, whose guard refusals exited with status 1; none was re-run on the current form, whose guard refusals exit with status 2. Each row below specifies its expected exposed/fixed result and, except Vibe mode, a positive control; none was observed against a service. Use the protected request helper and the specified browser or MCP operations. Include the actual deployment prefix in every route.

| Comparison | Request and expected exposed/fixed outcomes |
| --- | --- |
| Vibe mode | **REASONED:** Requires a disposable development app with a readable demo source file, unavailable here. Without a Gradio cookie, GET `/gradio_api/vibe-code`. On an isolated fixture with `GRADIO_VIBE_MODE="False"`, the non-empty value enables the handler and it should return the source. Unset the variable, recreate the process, and require the handler's 403 response. A missing demo file is not evidence that vibe mode is disabled. Record the disabled setting for the write handlers too; do not probe source modification on the deployed app. See the [setting](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py) and [vibe handlers](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py). |
| MCP | **REASONED:** Requires a working MCP client, Gradio's MCP dependency, and a harmless tool fixture, unavailable here. With MCP deliberately enabled on the private fixture, connect to `/gradio_api/mcp/`, list tools, and invoke the harmless tool successfully. Restart with `mcp_server=False`; that same connection must no longer list or invoke tools while ordinary authenticated app use still works. If publishing MCP, repeat with and without the intended authorization and require anonymous tool calls to be refused by the chosen protecting layer. `/gradio_api/info` is not this test. See [MCP operations](https://gradio.app/guides/building-mcp-server-with-gradio) and [conditional MCP setup](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py). |
| Visibility and native authorization | **REASONED:** Requires the live echo fixture, unavailable here. On the private comparison fixture, set `api_open=True` and POST `{"data":["GRADIO-LIVE marker"]}` to `/gradio_api/run/echo`. Changing visibility from `"public"` to `"undocumented"` or `"private"` must not be treated as HTTP denial: direct requests can still return the marker. Then require native auth and repeat without its cookie: expect 401. With a fresh cookie, require the marker again. Also compare GET `/config` and `/gradio_api/info`, and replay a valid browser `/gradio_api/queue/join` request with and without the native cookie. Malformed input is not an auth test. See the [event reference](https://gradio.app/docs/gradio/button) and [protected handlers](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py). |
| Direct queue bypass and capacity | **REASONED:** Requires a live queued fixture and observable handler execution, unavailable here. With native authentication satisfied, POST the same echo JSON to `/gradio_api/run/echo` and `/gradio_api/api/echo`: with `api_open=True`, expect the marker; with `False` and the function queued, expect Gradio's direct-request refusal, HTTP 404. POST it to `/gradio_api/call/echo` and retrieve `/gradio_api/call/echo/EVENT_ID`, substituting the returned event ID, to confirm queued work still completes. For capacity, use a bounded slow harmless handler, keep one call running, and submit enough valid queued calls to fill 20 waiting slots; excess submissions should receive a queue-full refusal. Compare with the private fixture's unlimited queue, and record handler overlap with concurrency 1 versus a deliberately higher listener limit. Inspect `max_threads=8` and listener overrides separately; a queue-full response does not demonstrate a per-user quota or the thread ceiling. See [queue controls](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py) and [queue/direct handlers](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py). |
| External auth, prefix, and session lifetime | **REASONED:** Requires HTTPS ingress, a trusted proxy/IdP, two native sessions for one test username, and a second-host backend-access fixture, unavailable here. GET `/config` beneath the deployment prefix: an external-auth callback returning a user ID should permit it; a callback returning `None` should produce 401. Forged identity headers and direct backend access must not bypass the chosen boundary. For native auth, create two sessions using POST `/login`, confirm both can GET `/gradio_api/info`, then GET `/logout` with one session: both old cookies must subsequently fail. Recreate sessions and restart to check token invalidation separately. Inspect both login cookies' attributes. Before external lifetime enforcement, a retained native token has no server expiry; after the configured external lifetime, the same public request must be denied by that external layer until reauthentication, while a fresh authorized session works. Test the configured login-throttling threshold with disposable credentials and proxy/IdP logs. `root_path` only changes the request prefix. See [native sessions and callback handling](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py) and [root_path](https://gradio.app/docs/gradio/blocks). |
| Outbound destinations | **REASONED:** Requires controlled allowed and denied destination servers, egress logs, and the relevant file/MCP components, unavailable here. Submit a valid allowed URL through each used fetch surface, including GET `/gradio_api/file=` followed by its encoded URL, and require the expected marker bytes. Repeat with a controlled destination outside the application's allowlist and with a redirect to it. Before application-specific restrictions, a controlled public destination can be fetched; after enforcement it must receive no request, while the allowed control still succeeds. Inspect destination and egress logs, not just HTTP errors. For MCP, invoke the actual file-input tool with those URLs. Never use real metadata services as probes. These comparisons test application destination policy, not a claim that current Gradio fetches lack SSRF protection. See [MCP URL inputs](https://gradio.app/guides/building-mcp-server-with-gradio), [component fetch fixes](https://github.com/gradio-app/gradio/releases/tag/gradio%406.16.0), and [file proxy](https://github.com/gradio-app/gradio/releases/tag/gradio%406.20.0). |
| Flagging, history, and telemetry | **REASONED:** Requires a live Interface, disposable browser profile, file components, and observable storage/network activity, unavailable here. Submit a unique harmless marker. With `"manual"`, click Flag and require a CSV entry; with `"auto"`, require an entry without clicking, including saved file data where applicable. With `"never"`, require no new flagging record from the same submission. With `run_history=True`, make a browser submission and inspect `/gradio_api/runs`; after `False`, require recording and the history page to be disabled, while prediction still works. Inspect previous files and any connected bucket separately. Compare basic telemetry with `analytics_enabled=True` and `False`; do not infer prediction-input transmission from telemetry alone. See [flagging](https://gradio.app/docs/gradio/interface), [file storage](https://gradio.app/guides/flagging), and [history and analytics](https://gradio.app/docs/gradio/blocks). |

### REASONED service checks

**REASONED:** Service-check evidence summary, per the guide's cited Gradio 6.31.0 Blocks source and Gradio 6.31.0 routes source; the live Gradio and deployment fixtures listed below are not supplied here. Local Python/JSON parsing, bash -n, ShellCheck 0.11.0, marker-file readback, and stubbed request guards ran successfully as recorded above; expected exposed success versus fixed refusal with working authorized controls remains unobserved. The bash -n, ShellCheck and stub runs of the base-URL probe block and the protected request helper covered an earlier form of each, whose guard refusals exited with status 1; neither block was re-run in its current form, whose guard refusals exit with status 2. The checks below remain REASONED from the cited Gradio 6.31.0 source and documentation. Configuration inspection and local syntax checks do not demonstrate service behavior.

| Scope | Exposed/fixed checks and prerequisites | Status |
| --- | --- | --- |
| Gradio controls | Check every REASONED comparison above on Gradio 6.31.0 with recorded dependency versions, disposable data, HTTPS ingress, a second host, native test users, proxy/IdP fixtures, an isolated vibe fixture, MCP tools, queued handlers, multipart components, controlled outbound destinations, and observable browser/server storage. Include share-tunnel termination; native versus proxy refusals; file-marker positive controls across restarts; environment fallback; shared-cache access; both upload routes; visibility versus HTTP authorization; direct queue bypass; capacity and thread behavior; external lifetime and logout/restart revocation; egress restrictions; flagging, history, and telemetry. Record requests, response content, positive controls, effective configuration, timestamps, and cleanup. | **REASONED:** Full comparison inventory, per the guide's cited entries (1 of 2): Gradio 6.31.0 Blocks source, Gradio 6.31.0 routes source, Gradio Blocks.launch() parameters (rolling documentation, checked September 2026), Gradio file access (rolling documentation, checked September 2026), Gradio event reference (rolling documentation, checked September 2026). The guide's cited entries for the full comparison inventory (2 of 2): Gradio MCP server documentation (rolling documentation, checked September 2026), Gradio 6.16.0 release, Gradio 6.20.0 release, Gradio Interface reference (rolling documentation, checked September 2026), and Gradio flagging guide (rolling documentation, checked September 2026). The listed live deployment fixtures are not supplied here. Local syntax/parsing, marker readback, and stubbed request/permission checks ran as recorded above, not the service comparisons. The bash -n, ShellCheck and stub runs of the base-URL probe block and the protected request helper covered an earlier form of each, whose guard refusals exited with status 1; neither block was re-run in its current form, whose guard refusals exit with status 2. Expected exposed/fixed outcomes and controls remain those specified above. REASONED from the cited source and documentation; service behavior is not demonstrated. |

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- [Gradio Blocks.launch() parameters (rolling documentation, checked September 2026)](https://gradio.app/docs/gradio/blocks): auth, auth_message, ssl_certfile, ssl_keyfile, ssl_keyfile_password, ssl_verify, server_name, and share; also auth_dependency, root_path, queue/launch limits, footer_links, run_history, and analytics.
- [Gradio file access (rolling documentation, checked September 2026)](https://gradio.app/guides/file-access): the `/gradio_api/file=` route; the default set is `set_static_paths`, `allowed_paths`, and the cache; eligible returned paths in `allowed_paths`, the working directory, or the temp directory; working-directory dotfile exclusion; `blocked_paths` precedence; cache sharing across users; and `GRADIO_TEMP_DIR`.
- Gradio security advisories: [the `/file` traversal and SSRF fixed in 4.11.0](https://github.com/gradio-app/gradio/security/advisories/GHSA-6qm2-wpxq-7qh2) and [the case-handling blocklist bypass](https://github.com/gradio-app/gradio/security/advisories/GHSA-j2jg-fq62-7c3h). Historical evidence for keeping a current release and minimizing the process filesystem and additional allowed paths; no precise fix version is assigned here to the case-handling advisory.
- [Gradio 6.31.0 release](https://github.com/gradio-app/gradio/releases/tag/gradio%406.31.0).
- [Gradio 6.31.0 Blocks source](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py): launch and queue signatures/defaults, off-Spaces api_open default, vibe-mode truthiness, path environment fallback, sharing behavior, component cache downloads, API names, and history settings.
- [Gradio 6.31.0 http_server source](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/http_server.py): the `localhost` URL chosen for `server_name="0.0.0.0"` and the `https` scheme when a key file is set (lines 113 and 186-187); the startup request using `ssl_verify` is at blocks.py lines 3559-3563.
- [Gradio 6.31.0 Node proxy source](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/js/app/proxy_index.js): the front proxy that SSR can start on the user-facing port imports `http` (line 1), targets Python at `http://` (line 22) and creates a plain-HTTP server (`http.createServer`, line 56); the Blocks branch that selects it is at blocks.py lines 3326-3328 and Gradio tries to start Node at lines 3500-3506, with the Python fallback it tries at lines 3518-3529.
- [Gradio 6.31.0 node_server source](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/node_server.py): Node is kept only if `HEAD /` returns below 500 within 30 seconds (lines 183 and 265-281).
- [Gradio 6.31.0 routes source](https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py): login checks, native tokens/cookies/logout, auth_dependency, vibe handlers, conditional MCP setup, direct queue-bypass refusal, multipart limits, and SSRF-protected file streaming.
- Gradio 6.31.0 Interface source: `flagging_mode` resolution through `GRADIO_FLAGGING_MODE` to `"manual"` ([lines 389 to 399](https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L389-L399)) and flagging-callback setup only when the mode is not `"never"` ([lines 467 to 476](https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L467-L476)). Flag buttons only for `"manual"` and the submit button for `"auto"` ([lines 607 to 610](https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L607-L610) and [lines 657 to 662](https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L657-L662)), and no flagging event without flag buttons, with `"auto"` flagging inputs and outputs after each successful submit ([lines 841 to 870](https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L841-L870)).
- Gradio 6.31.0 Interface source, flag buttons unset unless the mode renders them: the input column ([line 564](https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L564)) and the output column ([lines 630 to 635](https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L630-L635)) each start `flag_btns` as `None`.
- [Gradio event reference (rolling documentation, checked September 2026)](https://gradio.app/docs/gradio/button): api_visibility, api_name, queue, and listener concurrency.
- [Gradio 6 migration guide (rolling documentation, checked September 2026)](https://gradio.app/guides/gradio-6-migration-guide): footer_links and the replacement event visibility API; read its visibility wording with the current reference and HTTP source.
- [Gradio development and vibe-mode warning (rolling documentation, checked September 2026)](https://gradio.app/guides/developing-faster-with-reload-mode).
- [Gradio MCP server documentation (rolling documentation, checked September 2026)](https://gradio.app/guides/building-mcp-server-with-gradio): tool publication, `/gradio_api/mcp/`, and URL file inputs.
- [Gradio 6.16.0 release](https://github.com/gradio-app/gradio/releases/tag/gradio%406.16.0): FileExplorer traversal and Image/Gallery SVG and Audio streaming SSRF fixes.
- [Gradio 6.20.0 release](https://github.com/gradio-app/gradio/releases/tag/gradio%406.20.0): multipart `/component_server` max_file_size enforcement and the SSRF-protected file streaming proxy.
- [Gradio load reference (rolling documentation, checked September 2026)](https://gradio.app/docs/gradio/load): trusted targets, src, token, HF_TOKEN inheritance, and loaded-Space token disclosure.
- [Gradio Interface reference (rolling documentation, checked September 2026)](https://gradio.app/docs/gradio/interface): flagging_mode, GRADIO_FLAGGING_MODE, CSVLogger, `.gradio/flagged`, and analytics_enabled.
- [Gradio flagging guide (rolling documentation, checked September 2026)](https://gradio.app/guides/flagging): persistence of flagged inputs, outputs, and file data.


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- gradio: Gradio (6.31.0)
- fixes: Gradio historical fixes (6.16.0)
- multipart: Gradio historical fixes (6.20.0)
- advisory: Gradio security advisories (unknown)
- gradio-rolling: Gradio documentation (rolling) (unknown)

Claims (full source mapping in the JSON block below):

- bind (REASONED; gradio, gradio-rolling): server_name=None resolves through GRADIO_SERVER_NAME to 127.0.0.1 when unset; set loopback explicitly behind the proxy; 0.0.0.0 exposes all interfaces.
- port (REASONED; gradio, gradio-rolling): With server_port=None, port search starts at 7860 unless GRADIO_SERVER_PORT changes it; native TLS example explicitly uses 8443.
- password (REASONED; gradio, gradio-rolling): auth accepts one tuple, a tuple list or a credential-checking callable; auth_message customizes login; keep credentials outside source.
- login-limits (REASONED; gradio, gradio-rolling): Native auth is single-factor without throttling, rate limiting or lockout; a TOTP callable also needs enrollment, secret custody and replay rejection.
- external-auth (REASONED; gradio, gradio-rolling): auth_dependency returns a user ID or None and cannot combine with auth; validate identity, sanitize proxy headers and prevent direct backend bypass.
- sessions (REASONED; gradio): Native bearer tokens live in process memory without server-side expiry; login issues HttpOnly Secure and insecure fallback cookies, and accepts either.
- revocation (REASONED; gradio): Restart clears native tokens; /logout defaults all_session=True, revoking all sessions for a username; cookie lifetime is not server revocation.
- external-policy (REASONED; gradio, gradio-rolling): Require HTTPS and externally enforced MFA, throttling, lockout and finite lifetime on every request; a copied native cookie must not bypass that boundary.
- tls (REASONED; gradio, gradio-rolling): ssl_certfile/ssl_keyfile enable HTTPS and ssl_keyfile_password supports encrypted keys; with server_name="0.0.0.0" and no SSR, the first launch() requests a URL under https://localhost:PORT/ with ssl_verify, so ssl_verify=False is needed for a self-signed certificate, or a CA-issued certificate not naming localhost; ssr_mode=False pinned: SSR can put a plain-HTTP Node proxy on the public port.
- prefix (REASONED; gradio-rolling): root_path builds URLs beneath the proxy prefix; it neither authenticates nor prevents direct backend access.
- share (REASONED; gradio): share=True publishes a public relay URL; omitted share may inherit GRADIO_SHARE=True or auto-enable in hosted notebooks; deploy with explicit False.
- file-route (REASONED; gradio, gradio-rolling): /gradio_api/file= serves registered static paths, allowed_paths and cache; returned file outputs can expose eligible working/temp paths to every app user.
- allowed-paths (REASONED; gradio-rolling): allowed_paths adds exposure, not a sandbox; empty lists do not disable cache or eligible outputs, and granted directories expose descendants.
- dotfiles (REASONED; gradio-rolling): Working-directory dotfiles are excluded from automatic caching unless explicitly permitted; this does not protect other eligible files or justify colocated secrets.
- blocked-paths (REASONED; advisory, gradio-rolling): blocked_paths overrides default/static/allowed grants but is a backstop; minimize the process filesystem and never return untrusted file paths.
- path-environment (REASONED; gradio): allowed_paths and blocked_paths default None; even [] falls back to comma-separated GRADIO_ALLOWED_PATHS and GRADIO_BLOCKED_PATHS.
- cache (REASONED; gradio-rolling): GRADIO_TEMP_DIR relocates cache; restrict permissions, quota and cleanup, but relocation and local permissions do not provide per-user download authorization.
- upload-limit (REASONED; gradio, gradio-rolling): max_file_size defaults None; set bytes or 5mb for a per-file limit, adding separate storage/rate controls.
- multipart-fix (REASONED; gradio, multipart): 6.20.0 fixed missing max_file_size enforcement on multipart /component_server uploads; retain the 6.31.0 deployment baseline.
- historical-traversal (REASONED; advisory): 4.11.0 fixed the historical /file traversal and associated SSRF; this is a historical floor, not the deployment baseline.
- historical-files (REASONED; advisory, fixes): 6.16.0 includes FileExplorer traversal fixes; the case-handling advisory has conflicting patched-version records and no precise fix version here.
- vibe (REASONED; gradio, gradio-rolling): GRADIO_VIBE_MODE defaults empty; any nonempty value including False or 0 enables unauthenticated source read/write handlers and arbitrary execution; leave unset and avoid --vibe.
- mcp (REASONED; gradio, gradio-rolling): mcp_server defaults None, consulting GRADIO_MCP_SERVER (False); explicitly disable unless tools beneath /gradio_api/mcp/ are deliberately protected and tested.
- footer (REASONED; gradio-rolling): footer_links can hide API documentation; it replaces show_api=False and does not disable the API.
- visibility (REASONED; gradio, gradio-rolling): api_visibility defaults public; undocumented hides docs and private blocks Gradio-client use, but direct HTTP remains subject to separate auth/queue policy.
- api-name (REASONED; gradio, gradio-rolling): api_name=None derives a function name; api_name=False is no longer a supported public argument and hiding names is not authorization.
- protected-routes (REASONED; gradio): Native auth/auth_dependency checks cover /config, /gradio_api/info, prediction and queue join/data routes; public assets and a login page do not prove API protection.
- queue-bypass (REASONED; gradio): queue(api_open=None) is effectively True off Spaces; False refuses direct run/api calls for queued functions, while queued API and queue=False events remain.
- concurrency (REASONED; gradio, gradio-rolling): default_concurrency_limit defaults 1 unless changed through GRADIO_DEFAULT_CONCURRENCY_LIMIT; listener overrides apply, not a global per-user limit.
- queue-size (REASONED; gradio): max_size defaults None with a ZeroGPU Spaces exception; 20 bounds waiting work but is not a per-user quota.
- threads (REASONED; gradio, gradio-rolling): max_threads defaults 40; the example sets 8, separately from queue and listener capacity.
- egress (REASONED; gradio, gradio-rolling): URL inputs and component/MCP fetches need application destination allowlists and deployment egress controls, including redirects/resolution; no general fetch allowlist covers all surfaces.
- fetch-fixes (REASONED; fixes, multipart): 6.16.0 fixed SVG/Audio SSRF; 6.20.0 changed /gradio_api/file=&lt;url&gt; from open redirect to SSRF-protected streaming proxy.
- load-token (REASONED; gradio-rolling): Keep gr.load name/src trusted; token can inherit HF_TOKEN, model loading can use a saved token, and a loaded Space can read a supplied token.
- flagging (REASONED; gradio, gradio-rolling): Interface flagging_mode defaults through GRADIO_FLAGGING_MODE to manual; auto flags inputs and outputs after each successful submit, not in input-only Interfaces. In 6.31.0, never skips flagging-callback setup and renders no flag button, so Interface attaches no flagging event. The cited code only skips setup and events, so this guide's reading is that never leaves existing flagged files in place.
- flag-storage (REASONED; gradio-rolling): Default CSVLogger writes .gradio/flagged including file data. As this guide's own recommendation, not a Gradio statement, apply an explicit access and retention policy wherever that collection is required.
- history (REASONED; gradio, gradio-rolling): run_history defaults None through GRADIO_RUN_HISTORY to True; False disables recording/page and removes saved browser history, not separately retained bucket data.
- analytics (REASONED; gradio-rolling): Blocks/Interface analytics_enabled defaults None through GRADIO_ANALYTICS_ENABLED to True; False disables basic telemetry independently of flagging/history and application logs.
- verify-bind-share (REASONED; gradio): Inventory bind and terminate the prior process/tunnel, set share=False, and inspect this fresh run's full startup output; loopback ss alone cannot exclude a relay.
- verify-native (REASONED; gradio): Compare /gradio_api/info without native cookies (200 exposed, native 401 fixed), retaining proxy authorization; fresh login cookie must restore 200 with app content.
- verify-tls (REASONED; gradio-rolling): Use validated HTTPS at the same host/port/prefix and trust the actual CA; TLS, DNS and connection failures do not demonstrate auth refusal.
- verify-files (REASONED; gradio, gradio-rolling): Both markers must serve before blocking; after restart use fresh cookies and confirm both files remain, with blocked 403 and allowed marker content; missing files also yield 403.
- verify-environment (REASONED; gradio, gradio-rolling): With allowed_paths=[], an environment-granted marker serves; remove grant and restart to require refusal with an allowed control; relocated cache remains readable across app users.
- verify-upload (REASONED; gradio, multipart): Compare valid below/above-limit uploads on upload and multipart component_server independently; malformed requests or proxy refusal do not demonstrate Gradio enforcement.
- verify-vibe (REASONED; gradio): Unauthenticated GET /gradio_api/vibe-code returns demo source with GRADIO_VIBE_MODE=False as a string; unset/restart requires handler 403, not merely a missing file.
- verify-mcp (REASONED; gradio, gradio-rolling): Enabled MCP must list/invoke a harmless tool; disabled MCP must stop both with ordinary app still working; published tools need their own anonymous/authorized comparison.
- verify-visibility (REASONED; gradio, gradio-rolling): Direct echo HTTP can still work with undocumented/private visibility; auth must reject missing cookies and fresh cookies restore marker content, including config/info/queue comparisons.
- verify-queue (REASONED; gradio): Authenticated queued run/echo and api/echo succeed with api_open=True and return 404 with False; call/echo plus its event URL must still complete.
- verify-capacity (REASONED; gradio, gradio-rolling): Fill 20 waiting slots with a bounded slow handler, compare queue-full refusal and overlap against controls, and inspect thread/listener settings separately.
- verify-external (REASONED; gradio, gradio-rolling): auth_dependency user ID permits prefixed config and None yields 401; forged headers/direct origin must fail, with a fresh authorized session as control.
- verify-revocation (REASONED; gradio): Create two native sessions, require logout to invalidate both, test restart separately, inspect both cookies, and test external lifetime/throttling at the enforcing layer.
- verify-egress (REASONED; gradio, fixes, multipart, gradio-rolling): Allowed markers must arrive; denied or redirected destinations must receive no request after policy enforcement; confirm with destination/egress logs across used fetch surfaces.
- verify-collection (REASONED; gradio-rolling): Compare manual/auto flag records against never, history runs/page on/off and telemetry on/off while predictions work; inspect old files and buckets separately.

````json
{
  "schema": 1,
  "checked": "2026-11-07",
  "documentation_checked": "2026-09",
  "body_sha256": "bec410f284144a3442417675c3044b0b78c257c0540c3dce048c062de015dd39",
  "components": {
    "gradio": {
      "name": "Gradio",
      "basis": "6.31.0",
      "sources": {
        "s629ceeab3c07": "https://github.com/gradio-app/gradio/releases/tag/gradio%406.31.0",
        "sae6db7547d00": "https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/blocks.py",
        "s37df1f92298b": "https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/routes.py",
        "sdcdad5ea4067": "https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/http_server.py",
        "s2195dd19b32e": "https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/js/app/proxy_index.js",
        "sc5151ef2fa1e": "https://raw.githubusercontent.com/gradio-app/gradio/gradio%406.31.0/gradio/node_server.py",
        "s96937c91853b": "https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L389-L399",
        "sbe57cf8cae8d": "https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L467-L476",
        "sa9f247ed7ad2": "https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L607-L610",
        "s7b4d418e3232": "https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L657-L662",
        "s3ba7f10d7fef": "https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L841-L870",
        "s36b4412971de": "https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L564",
        "sa06b065ecf88": "https://github.com/gradio-app/gradio/blob/gradio%406.31.0/gradio/interface.py#L630-L635"
      }
    },
    "fixes": {
      "name": "Gradio historical fixes",
      "basis": "6.16.0",
      "sources": {
        "s4c2d0b42c65a": "https://github.com/gradio-app/gradio/releases/tag/gradio%406.16.0"
      }
    },
    "multipart": {
      "name": "Gradio historical fixes",
      "basis": "6.20.0",
      "sources": {
        "sdcc6d6d01633": "https://github.com/gradio-app/gradio/releases/tag/gradio%406.20.0"
      }
    },
    "advisory": {
      "name": "Gradio security advisories",
      "basis": "unknown",
      "sources": {
        "sdab1cc199434": "https://github.com/gradio-app/gradio/security/advisories/GHSA-j2jg-fq62-7c3h",
        "s72ab0d90c666": "https://github.com/gradio-app/gradio/security/advisories/GHSA-6qm2-wpxq-7qh2"
      }
    },
    "gradio-rolling": {
      "name": "Gradio documentation (rolling)",
      "basis": "unknown",
      "sources": {
        "s2e352ec80647": "https://gradio.app/docs/gradio/blocks",
        "s236e6a1cfda7": "https://gradio.app/guides/file-access",
        "s26cf2d8c03e6": "https://gradio.app/docs/gradio/button",
        "scda58c57b93d": "https://gradio.app/guides/gradio-6-migration-guide",
        "sa70cd6adbc85": "https://gradio.app/guides/developing-faster-with-reload-mode",
        "sb9d13823991d": "https://gradio.app/guides/building-mcp-server-with-gradio",
        "s6241688bfec2": "https://gradio.app/docs/gradio/load",
        "s4c8865afcff1": "https://gradio.app/docs/gradio/interface",
        "s3f2e7e8ca402": "https://gradio.app/guides/flagging"
      }
    }
  },
  "claims": {
    "bind": {"text": "server_name=None resolves through GRADIO_SERVER_NAME to 127.0.0.1 when unset; set loopback explicitly behind the proxy; 0.0.0.0 exposes all interfaces.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:sae6db7547d00"], "status": "REASONED"},
    "port": {"text": "With server_port=None, port search starts at 7860 unless GRADIO_SERVER_PORT changes it; native TLS example explicitly uses 8443.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:sae6db7547d00"], "status": "REASONED"},
    "password": {"text": "auth accepts one tuple, a tuple list or a credential-checking callable; auth_message customizes login; keep credentials outside source.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:s37df1f92298b"], "status": "REASONED"},
    "login-limits": {"text": "Native auth is single-factor without throttling, rate limiting or lockout; a TOTP callable also needs enrollment, secret custody and replay rejection.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:s37df1f92298b"], "status": "REASONED"},
    "external-auth": {"text": "auth_dependency returns a user ID or None and cannot combine with auth; validate identity, sanitize proxy headers and prevent direct backend bypass.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:s37df1f92298b"], "status": "REASONED"},
    "sessions": {"text": "Native bearer tokens live in process memory without server-side expiry; login issues HttpOnly Secure and insecure fallback cookies, and accepts either.", "components": ["gradio"], "sources": ["gradio:s37df1f92298b"], "status": "REASONED"},
    "revocation": {"text": "Restart clears native tokens; /logout defaults all_session=True, revoking all sessions for a username; cookie lifetime is not server revocation.", "components": ["gradio"], "sources": ["gradio:s37df1f92298b"], "status": "REASONED"},
    "external-policy": {"text": "Require HTTPS and externally enforced MFA, throttling, lockout and finite lifetime on every request; a copied native cookie must not bypass that boundary.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:s37df1f92298b"], "status": "REASONED"},
    "tls": {"text": "ssl_certfile/ssl_keyfile enable HTTPS and ssl_keyfile_password supports encrypted keys; with server_name=\"0.0.0.0\" and no SSR, the first launch() requests a URL under https://localhost:PORT/ with ssl_verify, so ssl_verify=False is needed for a self-signed certificate, or a CA-issued certificate not naming localhost; ssr_mode=False pinned: SSR can put a plain-HTTP Node proxy on the public port.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:sae6db7547d00", "gradio:sdcdad5ea4067", "gradio:s2195dd19b32e", "gradio:sc5151ef2fa1e"], "status": "REASONED"},
    "prefix": {"text": "root_path builds URLs beneath the proxy prefix; it neither authenticates nor prevents direct backend access.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647"], "status": "REASONED"},
    "share": {"text": "share=True publishes a public relay URL; omitted share may inherit GRADIO_SHARE=True or auto-enable in hosted notebooks; deploy with explicit False.", "components": ["gradio"], "sources": ["gradio:sae6db7547d00"], "status": "REASONED"},
    "file-route": {"text": "/gradio_api/file= serves registered static paths, allowed_paths and cache; returned file outputs can expose eligible working/temp paths to every app user.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s236e6a1cfda7", "gradio:s37df1f92298b"], "status": "REASONED"},
    "allowed-paths": {"text": "allowed_paths adds exposure, not a sandbox; empty lists do not disable cache or eligible outputs, and granted directories expose descendants.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s236e6a1cfda7"], "status": "REASONED"},
    "dotfiles": {"text": "Working-directory dotfiles are excluded from automatic caching unless explicitly permitted; this does not protect other eligible files or justify colocated secrets.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s236e6a1cfda7"], "status": "REASONED"},
    "blocked-paths": {"text": "blocked_paths overrides default/static/allowed grants but is a backstop; minimize the process filesystem and never return untrusted file paths.", "components": ["advisory", "gradio-rolling"], "sources": ["gradio-rolling:s236e6a1cfda7", "advisory:sdab1cc199434"], "status": "REASONED"},
    "path-environment": {"text": "allowed_paths and blocked_paths default None; even [] falls back to comma-separated GRADIO_ALLOWED_PATHS and GRADIO_BLOCKED_PATHS.", "components": ["gradio"], "sources": ["gradio:sae6db7547d00"], "status": "REASONED"},
    "cache": {"text": "GRADIO_TEMP_DIR relocates cache; restrict permissions, quota and cleanup, but relocation and local permissions do not provide per-user download authorization.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s236e6a1cfda7"], "status": "REASONED"},
    "upload-limit": {"text": "max_file_size defaults None; set bytes or 5mb for a per-file limit, adding separate storage/rate controls.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:sae6db7547d00"], "status": "REASONED"},
    "multipart-fix": {"text": "6.20.0 fixed missing max_file_size enforcement on multipart /component_server uploads; retain the 6.31.0 deployment baseline.", "components": ["gradio", "multipart"], "sources": ["gradio:s629ceeab3c07", "multipart:sdcc6d6d01633"], "status": "REASONED"},
    "historical-traversal": {"text": "4.11.0 fixed the historical /file traversal and associated SSRF; this is a historical floor, not the deployment baseline.", "components": ["advisory"], "sources": ["advisory:s72ab0d90c666"], "status": "REASONED"},
    "historical-files": {"text": "6.16.0 includes FileExplorer traversal fixes; the case-handling advisory has conflicting patched-version records and no precise fix version here.", "components": ["advisory", "fixes"], "sources": ["advisory:sdab1cc199434", "fixes:s4c2d0b42c65a"], "status": "REASONED"},
    "vibe": {"text": "GRADIO_VIBE_MODE defaults empty; any nonempty value including False or 0 enables unauthenticated source read/write handlers and arbitrary execution; leave unset and avoid --vibe.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio:sae6db7547d00", "gradio:s37df1f92298b", "gradio-rolling:sa70cd6adbc85"], "status": "REASONED"},
    "mcp": {"text": "mcp_server defaults None, consulting GRADIO_MCP_SERVER (False); explicitly disable unless tools beneath /gradio_api/mcp/ are deliberately protected and tested.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio:sae6db7547d00", "gradio:s37df1f92298b", "gradio-rolling:sb9d13823991d"], "status": "REASONED"},
    "footer": {"text": "footer_links can hide API documentation; it replaces show_api=False and does not disable the API.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio-rolling:scda58c57b93d"], "status": "REASONED"},
    "visibility": {"text": "api_visibility defaults public; undocumented hides docs and private blocks Gradio-client use, but direct HTTP remains subject to separate auth/queue policy.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s26cf2d8c03e6", "gradio-rolling:scda58c57b93d", "gradio:s37df1f92298b"], "status": "REASONED"},
    "api-name": {"text": "api_name=None derives a function name; api_name=False is no longer a supported public argument and hiding names is not authorization.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio:sae6db7547d00", "gradio-rolling:s26cf2d8c03e6", "gradio-rolling:scda58c57b93d"], "status": "REASONED"},
    "protected-routes": {"text": "Native auth/auth_dependency checks cover /config, /gradio_api/info, prediction and queue join/data routes; public assets and a login page do not prove API protection.", "components": ["gradio"], "sources": ["gradio:s37df1f92298b"], "status": "REASONED"},
    "queue-bypass": {"text": "queue(api_open=None) is effectively True off Spaces; False refuses direct run/api calls for queued functions, while queued API and queue=False events remain.", "components": ["gradio"], "sources": ["gradio:sae6db7547d00", "gradio:s37df1f92298b"], "status": "REASONED"},
    "concurrency": {"text": "default_concurrency_limit defaults 1 unless changed through GRADIO_DEFAULT_CONCURRENCY_LIMIT; listener overrides apply, not a global per-user limit.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio:sae6db7547d00", "gradio-rolling:s26cf2d8c03e6"], "status": "REASONED"},
    "queue-size": {"text": "max_size defaults None with a ZeroGPU Spaces exception; 20 bounds waiting work but is not a per-user quota.", "components": ["gradio"], "sources": ["gradio:sae6db7547d00"], "status": "REASONED"},
    "threads": {"text": "max_threads defaults 40; the example sets 8, separately from queue and listener capacity.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:sae6db7547d00"], "status": "REASONED"},
    "egress": {"text": "URL inputs and component/MCP fetches need application destination allowlists and deployment egress controls, including redirects/resolution; no general fetch allowlist covers all surfaces.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:sae6db7547d00", "gradio-rolling:sb9d13823991d"], "status": "REASONED"},
    "fetch-fixes": {"text": "6.16.0 fixed SVG/Audio SSRF; 6.20.0 changed /gradio_api/file=<url> from open redirect to SSRF-protected streaming proxy.", "components": ["fixes", "multipart"], "sources": ["fixes:s4c2d0b42c65a", "multipart:sdcc6d6d01633"], "status": "REASONED"},
    "load-token": {"text": "Keep gr.load name/src trusted; token can inherit HF_TOKEN, model loading can use a saved token, and a loaded Space can read a supplied token.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s6241688bfec2"], "status": "REASONED"},
    "flagging": {"text": "Interface flagging_mode defaults through GRADIO_FLAGGING_MODE to manual; auto flags inputs and outputs after each successful submit, not in input-only Interfaces. In 6.31.0, never skips flagging-callback setup and renders no flag button, so Interface attaches no flagging event. The cited code only skips setup and events, so this guide's reading is that never leaves existing flagged files in place.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s4c8865afcff1", "gradio-rolling:s3f2e7e8ca402", "gradio:s96937c91853b", "gradio:sbe57cf8cae8d", "gradio:s36b4412971de", "gradio:sa9f247ed7ad2", "gradio:sa06b065ecf88", "gradio:s7b4d418e3232", "gradio:s3ba7f10d7fef"], "status": "REASONED"},
    "flag-storage": {"text": "Default CSVLogger writes .gradio/flagged including file data. As this guide's own recommendation, not a Gradio statement, apply an explicit access and retention policy wherever that collection is required.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s4c8865afcff1", "gradio-rolling:s3f2e7e8ca402"], "status": "REASONED"},
    "history": {"text": "run_history defaults None through GRADIO_RUN_HISTORY to True; False disables recording/page and removes saved browser history, not separately retained bucket data.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:sae6db7547d00"], "status": "REASONED"},
    "analytics": {"text": "Blocks/Interface analytics_enabled defaults None through GRADIO_ANALYTICS_ENABLED to True; False disables basic telemetry independently of flagging/history and application logs.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio-rolling:s4c8865afcff1"], "status": "REASONED"},
    "verify-bind-share": {"text": "Inventory bind and terminate the prior process/tunnel, set share=False, and inspect this fresh run's full startup output; loopback ss alone cannot exclude a relay.", "components": ["gradio"], "sources": ["gradio:sae6db7547d00"], "status": "REASONED", "verify": [1]},
    "verify-native": {"text": "Compare /gradio_api/info without native cookies (200 exposed, native 401 fixed), retaining proxy authorization; fresh login cookie must restore 200 with app content.", "components": ["gradio"], "sources": ["gradio:s37df1f92298b"], "status": "REASONED", "verify": [2, 3]},
    "verify-tls": {"text": "Use validated HTTPS at the same host/port/prefix and trust the actual CA; TLS, DNS and connection failures do not demonstrate auth refusal.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647"], "status": "REASONED", "verify": [2, 3]},
    "verify-files": {"text": "Both markers must serve before blocking; after restart use fresh cookies and confirm both files remain, with blocked 403 and allowed marker content; missing files also yield 403.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s236e6a1cfda7", "gradio:s37df1f92298b"], "status": "REASONED", "verify": [3]},
    "verify-environment": {"text": "With allowed_paths=[], an environment-granted marker serves; remove grant and restart to require refusal with an allowed control; relocated cache remains readable across app users.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s236e6a1cfda7", "gradio:sae6db7547d00"], "status": "REASONED", "verify": [3]},
    "verify-upload": {"text": "Compare valid below/above-limit uploads on upload and multipart component_server independently; malformed requests or proxy refusal do not demonstrate Gradio enforcement.", "components": ["gradio", "multipart"], "sources": ["gradio:s37df1f92298b", "multipart:sdcc6d6d01633"], "status": "REASONED", "verify": [3]},
    "verify-vibe": {"text": "Unauthenticated GET /gradio_api/vibe-code returns demo source with GRADIO_VIBE_MODE=False as a string; unset/restart requires handler 403, not merely a missing file.", "components": ["gradio"], "sources": ["gradio:sae6db7547d00", "gradio:s37df1f92298b"], "status": "REASONED", "verify": [3]},
    "verify-mcp": {"text": "Enabled MCP must list/invoke a harmless tool; disabled MCP must stop both with ordinary app still working; published tools need their own anonymous/authorized comparison.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio:s37df1f92298b", "gradio-rolling:sb9d13823991d"], "status": "REASONED"},
    "verify-visibility": {"text": "Direct echo HTTP can still work with undocumented/private visibility; auth must reject missing cookies and fresh cookies restore marker content, including config/info/queue comparisons.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio:s37df1f92298b", "gradio-rolling:s26cf2d8c03e6"], "status": "REASONED", "verify": [3]},
    "verify-queue": {"text": "Authenticated queued run/echo and api/echo succeed with api_open=True and return 404 with False; call/echo plus its event URL must still complete.", "components": ["gradio"], "sources": ["gradio:s37df1f92298b"], "status": "REASONED", "verify": [3]},
    "verify-capacity": {"text": "Fill 20 waiting slots with a bounded slow handler, compare queue-full refusal and overlap against controls, and inspect thread/listener settings separately.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio:sae6db7547d00", "gradio-rolling:s26cf2d8c03e6"], "status": "REASONED"},
    "verify-external": {"text": "auth_dependency user ID permits prefixed config and None yields 401; forged headers/direct origin must fail, with a fresh authorized session as control.", "components": ["gradio", "gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio:s37df1f92298b"], "status": "REASONED", "verify": [3]},
    "verify-revocation": {"text": "Create two native sessions, require logout to invalidate both, test restart separately, inspect both cookies, and test external lifetime/throttling at the enforcing layer.", "components": ["gradio"], "sources": ["gradio:s37df1f92298b"], "status": "REASONED", "verify": [3]},
    "verify-egress": {"text": "Allowed markers must arrive; denied or redirected destinations must receive no request after policy enforcement; confirm with destination/egress logs across used fetch surfaces.", "components": ["gradio", "fixes", "multipart", "gradio-rolling"], "sources": ["gradio:s37df1f92298b", "gradio-rolling:sb9d13823991d", "fixes:s4c2d0b42c65a", "multipart:sdcc6d6d01633"], "status": "REASONED", "verify": [3]},
    "verify-collection": {"text": "Compare manual/auto flag records against never, history runs/page on/off and telemetry on/off while predictions work; inspect old files and buckets separately.", "components": ["gradio-rolling"], "sources": ["gradio-rolling:s2e352ec80647", "gradio-rolling:s4c8865afcff1", "gradio-rolling:s3f2e7e8ca402"], "status": "REASONED", "verify": [3]}
  }
}
````
<!-- version-basis:end -->
