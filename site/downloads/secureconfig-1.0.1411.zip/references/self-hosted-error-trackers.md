# Self-hosted error trackers: Sentry and GlitchTip

Sentry and GlitchTip are error trackers: apps send them crash reports with stack traces and request details. This guide helps your AI assistant configure an instance securely, including a loopback bind behind a TLS proxy, open sign-up off (GlitchTip ships it on), required MFA, and unpublished backing stores.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/self-hosted-error-trackers.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Sentry and self-hosted distribution 26.10.1, Sentry prior-release frontend-migrated reference 26.8.0, and GlitchTip backend v6.2.6; 3 further sources carry no recorded version. Metadata reviewed 2026-09-26; documentation checked September 2026. The guide records 23 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

An error tracker exists to collect what your application would otherwise hide: stack traces, the source lines around each frame, request bodies and headers, environment variables, release and server names, and whatever user context the SDK attaches. That makes an exposed tracker one of the richest leaks in a deployment, because it aggregates secrets, tokens, and personal data that were never meant to leave the app, and it does so in a searchable UI. The two common self-hosted choices behave differently at their most important default, so the guide takes them one at a time. [fronting-auth.md](fronting-auth.md) is the reverse-proxy pattern both rely on for TLS, [secrets.md](secrets.md) covers the signing keys, and [mfa.md](mfa.md) is the account layer. Values below are illustrative; replace them.

One thing both share: the DSN a client uses to send events is a public, client-side key by design, not a secret. It authorizes event submission and nothing else, so finding one in shipped JavaScript is expected and is not the exposure this guide is about. The exposure is the tracker's own web and API, and the data they hold.

## Sentry

The `getsentry/self-hosted` Docker Compose distribution fronts the web and API with a bundled nginx. Its published port comes from `SENTRY_BIND` in `.env`, which ships as `SENTRY_BIND=9000` (a bare port), so nginx binds `0.0.0.0:9000` and the instance answers on every interface. Bind it to loopback and let your own proxy terminate TLS in front:

```ini
# .env
SENTRY_BIND=127.0.0.1:9000
```

Everything else in the Compose file (the web and relay processes, PostgreSQL, Redis, Kafka, and the ClickHouse and Snuba services) is an internal service that the distribution does not publish; leave it that way, because those backing stores hold the same event data with no authentication of their own.

Registration is off by default: `auth.allow-registration` defaults to `False`, so an exposed instance does not by itself let a stranger create an account. Do not turn it on for an internet-facing tracker, and create the first administrator with the superuser flag set explicitly (a plain `createuser` prompts for superuser and defaults to no):

```bash
docker compose run --rm web createuser --superuser
```

Set the rest in `sentry/config.yml`, and generate the signing key rather than copying one:

```yaml
system.url-prefix: "https://sentry.example.com"
auth.allow-registration: false
# system.secret-key: generate once with `sentry config generate-secret-key`, keep it out of version control
```

Because your proxy terminates TLS, Sentry has to be told it is behind HTTPS, or its session and CSRF cookies are never marked secure. The bundled `sentry/sentry.conf.example.py` ships the relevant settings commented out; enable them in `sentry/sentry.conf.py`:

```python
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
USE_X_FORWARDED_HOST = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
```

One catch is specific to the bundled stack: its own nginx sets `proxy_set_header X-Forwarded-Proto $scheme`, which overwrites whatever an outer proxy sent, so if you add a TLS proxy in front of nginx on `9000` it forwards `http` and Sentry still sees plaintext. Either terminate TLS at the bundled nginx itself, or propagate the real scheme through it, and verify the scheme Sentry actually receives rather than assuming the header setting alone took effect.

Enforce member MFA and data scrubbing at the organization level (an authenticated API call, or the same fields in the org settings UI): `require2FA`, `dataScrubber`, `dataScrubberDefaults`, and `scrubIPAddresses`. Scrubbing matters precisely because the tracker ingests request data, so redacting passwords, tokens, and IPs at intake reduces what a later exposure leaks.

The file setting is authoritative for this option: `auth.allow-registration` is a prioritize-disk option, so the value in `config.yml` wins over any value stored in the database, not the other way around. Unverified until checked in your deployment: any SSO path that provisions accounts around registration, the full list of auxiliary listeners your compose revision publishes, and the effective scrubbing rules.

## GlitchTip

GlitchTip is a single Django application, and its Compose distribution publishes it on port `8000`. Its default is the opposite of Sentry's on the setting that matters most: `ENABLE_USER_REGISTRATION` defaults to `True`, which means an exposed instance offers open self-signup to anyone who reaches it. Close it, and remember the value's own nuance:

```ini
# When True (the default), anyone may self-register; when False, self-signup is disabled
# after the first user exists. Set it False once your accounts are provisioned.
ENABLE_USER_REGISTRATION=False
```

Bind the app to loopback or a private interface and terminate TLS at a reverse proxy, since GlitchTip serves no TLS of its own. Give it a unique `SECRET_KEY` (Django's session and CSRF signing key) and keep it out of version control. GlitchTip has supported two-factor authentication since v1.8; enable it and require it for your users. PostgreSQL and the optional Valkey or Redis are internal services; do not publish them.

Unverified until checked: the exact host bind in your Compose sample, whether MFA is enforced rather than merely available in your version, and whether any single-sign-on you add carries its own registration path around `ENABLE_USER_REGISTRATION`.

## Shared exposures

- **The event data itself.** Both tools store stack traces with source context, request payloads, and user identifiers. An exposed backing store is reachable with the credentials the compose ships and expects on its internal network, so publishing it is a direct disclosure of every event it holds; an exposed web or API discloses to the degree an attacker can authenticate to it, which is why the registration default and the intake scrubbing both matter. Scrub at intake and keep the stores private.
- **Open registration.** GlitchTip ships it on; Sentry ships it off. What a self-registered stranger then reaches differs by tool. Through Sentry 26.8.0, single-organization mode added a new sign-up without a pending invitation to the default organization, and at 26.10.1 this moved to the frontend and is unverified here. At GlitchTip backend v6.2.6 [the login signal](https://gitlab.com/glitchtip/glitchtip-backend/-/blob/v6.2.6/apps/users/signals.py#L16-45) adds a user with a linked social provider to an organization linked to that provider on login, with the first member of a memberless organization becoming owner. Confirm your own membership and project permissions rather than assuming a new account has none or all. Confirm the live setting rather than trusting the default.
- **The public DSN misread as a secret.** Rotating a DSN does not protect the tracker; authenticating its web and API does. Do not treat a leaked DSN as the incident.
- **Plaintext.** Neither serves TLS natively, so an instance reachable without a terminating proxy sends session cookies and the event UI in the clear.

## Verify (REASONED: listener and backing-store inventory, Sentry/GlitchTip registration, redirect handling, disposable signup, off-host backing-port reachability and HTTP-to-HTTPS routing comparisons follow the cited tracker sources; no live tracker, backing stores, authorized signup fixture or external host. Bash 5.3.9 bash -n accepted both Verify fences. With curl replaced by printf LOCAL_CURL in the complete registration subshell, https://fixture.internal/api/chat reached one marker and exit 0; empty input, original placeholders, set -- without arguments and bad value printed guard diagnostics with exit 2 and no marker. This tests those guards only, not registration, protocol reachability, redirects or TLS; these runs covered earlier forms of both fences, the gate suite's bash -n and ShellCheck 0.11.0 passes cover their current forms, and the stub runs recorded under Listener inventory also cover the inventory's current form)

REASONED: every probe below is reasoned, not demonstrated: the authoring environment has no container runtime, so the outcomes are derived from the cited vendor sources rather than observed. A redirect to a login page, a 404, or a TLS error is inconclusive, never the fixed state. The bash -n and stub runs recorded in the heading covered both blocks in an earlier form: the inventory then ran `sudo ss -tlnp` at top level, and the registration block took one value and ended with curl's own status. The repository's gate suite checks the current form of both blocks with bash -n and ShellCheck 0.11.0, like every block.

### Listener inventory

REASONED: following block; listener expectations follow the cited vendor sources and the guide's cited sudo sudoers manual, secure_path entry; no container runtime is available. The block exits 2 when ss is not installed, 3 when ss fails and otherwise 0, leaving the listeners it prints for you to judge. Where sudoers sets `secure_path`, sudo looks `ss` up in that path instead of your PATH, so the `command -v ss` check can refuse although sudo would find `ss`, or pass and then end with status 3 when sudo cannot run it. Stub runs of its current form, with stub `ss` and `sudo` commands, exited 0 when `ss` passed, 3 when it failed and 2 when it was missing, in a clean shell and under an inherited `readonly`, `declare -i` and `set -e`.

```bash
(                  # a subshell, so the exits below end only the subshell
  command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
  set -- 0         # this block's status: 2 if ss is not installed, 3 if ss fails, otherwise 0, because you judge the listeners it prints
  if sudo ss -tlnp; then :; else   # the tracker's own port only, on a private address: 9000 for Sentry, 8000 for
                                   # GlitchTip; and no PostgreSQL, Redis, Kafka, or ClickHouse port published beside it
    echo "sudo ss -tlnp exit $?: the listener inventory failed; inconclusive"; set -- 3
  fi
  echo "block exit $1; the listeners above are not classified, so judge them against the comments yourself"
  exit "$1"
)
```

### Registration and backing-store probe (REASONED: registration and backing-port checks follow the cited Sentry and GlitchTip sources; no container runtime is available)

```bash
# Registration discriminator against the plaintext listener, or a backing-store reachability probe.
# Substitute the URL inside the single quotes on the set -- line, then web for the tracker's web
# listener or store for a backing-store port probed from off-host, and paste the whole block so the
# guard runs; with web, read the body, since an open form and a closed one can both return 200.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_REGISTER_URL' 'REPLACE_WITH_web_OR_store'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute a full URL on the set -- line above; not probing"; exit 2 ;;
    http://*|https://*) : ;;
    *) echo "expected an http:// or https:// URL; not probing"; exit 2 ;;
  esac
  case "$2" in
    web|store) : ;;
    *) echo "substitute web (the tracker's web listener) or store (a backing-store port, probed from off-host) as the second value on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- "$1" "$2" "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 \
    -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$2" "${3##*$'\n'}" "${3%$'\n'*}"       # web or store, then curl's exit status and its output
  printf '%s' "$3"
  set -- "$1" "$2" "${3%$'\n'}"
  set -- "$1" "$2" "${3##*$'\n'}"                # web or store, curl's exit status, then its http= exit= err= line
  case "$1:$2:$3" in
    web:0:"http=3"??" "*|web:0:"http=404 "*) echo "for the registration check, a redirect or a 404 is inconclusive, never the fixed state (for Sentry, add -L to follow the redirect to the served login page); the HTTP-to-HTTPS routing check is read from the redirect target, not from this status"; set -- 3 ;;
    web:0:*) echo "unclassified observation: read the body above for a create-account path or signup form"; set -- 0 ;;
    store:7:*) echo "curl exit 7: the connection failed, which includes the refused connection; when err shows a refusal from this vantage, that is the closed, fixed state, and otherwise exit 7 is not proof"; set -- 0 ;;
    store:0:*|store:1:*HTTP/0.9*|store:8:*|store:52:*|store:56:*) echo "FINDING: curl exit $2 after the backing store accepted the connection, so its port is reachable from here"; set -- 1 ;;
    *) echo "curl exit $2: a transport failure or a TLS error is inconclusive; read the err field above"; set -- 3 ;;
  esac
  echo "block exit $1; the body and the err field above are not classified beyond this, so read them yourself"
  exit "$1"
)
```

Point that block, with `web`, at Sentry's `http://tracker.example.com:9000/`: through Sentry 26.8.0, because the bundled config sets `SENTRY_SINGLE_ORGANIZATION`, `/auth/register/` redirects to the organization login, so follow the redirect (add `-L`) to the served login page, where an instance with registration on presents a create-account path and a closed one (the default) does not. At 26.10.1 that page serves a React app and this redirect is unverified, so confirm the registration state from `auth.allow-registration` instead. For GlitchTip's `http://tracker.example.com:8000/`, an instance with `ENABLE_USER_REGISTRATION=True` accepts a new account through its signup, and one set `False` refuses after the first user exists; confirm by attempting a throwaway registration in an operator-controlled test, never against a shared instance. For each backing store, run the same guarded block with `store` against its port from off-host: those ports speak their own protocols, not HTTP, so read the connection outcome in the `exit` and `err` fields (a refused connection is the closed, fixed state; an accepted one is reachable) rather than any HTTP status. With `web`, the block exits 3 for a failed request, a redirect or a `404` and otherwise 0, leaving the body for you to read. With `store`, it exits 0 for curl exit 7, which includes the refused connection and is otherwise not proof. It exits 1 for curl exit 0, 8, 52 or 56, or for exit 1 with `HTTP/0.9` in `err`, curl's documented error for an HTTP/0.9 reply, one with no HTTP status line, such as a reachable Redis can give; curl reports each of these only after the connection was accepted. Any other failure, such as a timeout, which can come before or after the connection, gives 3. The `ss` inventory shows what Docker has published on the host, but a container port can be reachable through Docker's forwarding without a matching host socket, so the off-host probe is what proves it closed. Distinguish the public HTTPS proxy from the direct backend ports, and confirm plain HTTP to the web redirects to that proxy rather than serving the app. Read that routing check from the redirect target, such as the `Location` header that curl prints with `-i`, not from the block's status, which counts any redirect as inconclusive for the registration check. A reachable login page alone proves only that the port is open, not that registration or the backing stores are closed.

## Common mistakes

- Publishing Sentry with the shipped `SENTRY_BIND=9000`, which binds every interface, instead of a loopback address behind a proxy.
- Leaving GlitchTip's `ENABLE_USER_REGISTRATION` at its default `True` on an internet-facing instance, so anyone can self-register.
- Treating a leaked client DSN as the exposure while the tracker's own web and API stay unauthenticated.
- Publishing a backing service (PostgreSQL, Redis, Kafka, ClickHouse) beside the tracker, which holds the same event data with no auth of its own.
- Skipping data scrubbing, so secrets and personal data captured in events sit in the tracker in the clear.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- Sentry self-hosted Docker Compose (`SENTRY_BIND`, the bundled nginx publication): https://github.com/getsentry/self-hosted/blob/26.10.1/docker-compose.yml
- Sentry self-hosted `.env` (`SENTRY_BIND=9000` default): https://github.com/getsentry/self-hosted/blob/26.10.1/.env
- Sentry `auth.allow-registration` default `False`: https://github.com/getsentry/sentry/blob/26.10.1/src/sentry/options/defaults.py
- Sentry `createuser` (explicit `--superuser`): https://github.com/getsentry/sentry/blob/26.10.1/src/sentry/runner/commands/createuser.py
- Sentry organization update API (`require2FA`, data scrubbing fields): https://docs.sentry.io/api/organizations/update-an-organization/
- Sentry bundled configuration (`SENTRY_SINGLE_ORGANIZATION`, the commented-out `SECURE_PROXY_SSL_HEADER`, `SESSION_COOKIE_SECURE`, `CSRF_COOKIE_SECURE`): https://github.com/getsentry/self-hosted/blob/26.10.1/sentry/sentry.conf.example.py
- Sentry DSN explainer (a DSN is public and allows only event submission, not read access): https://docs.sentry.io/concepts/key-terms/dsn-explainer/
- GlitchTip installation (port `8000`, `ENABLE_USER_REGISTRATION` default and behavior): https://glitchtip.com/documentation/install/
- GlitchTip two-factor authentication (available since v1.8): https://glitchtip.com/blog/2021-09-17-glitchtip-1-8/
- [GlitchTip backend v6.2.6 organization membership on login for a user with a linked social account (checked October 2026)](https://gitlab.com/glitchtip/glitchtip-backend/-/blob/v6.2.6/apps/users/signals.py#L16-45).
- [Sentry 26.10.1 secret-key generator command (checked October 2026)](https://raw.githubusercontent.com/getsentry/sentry/26.10.1/src/sentry/runner/commands/config.py).
- [Sentry self-hosted 26.10.1 bundled nginx forwarded scheme (checked October 2026)](https://github.com/getsentry/self-hosted/blob/26.10.1/nginx.conf#L63).
- [Sentry 26.8.0 registration and single-organization membership (checked October 2026)](https://raw.githubusercontent.com/getsentry/sentry/26.8.0/src/sentry/web/frontend/auth_login.py).
- [sudo SUDO_1_9_16p2 sudoers manual, secure_path (checked October 2026)](https://github.com/sudo-project/sudo/blob/SUDO_1_9_16p2/docs/sudoers.man.in#L5650-L5655).


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- sentry: Sentry and self-hosted distribution (26.10.1)
- sentry-prev: Sentry prior-release frontend-migrated reference (26.8.0)
- glitchtip-backend: GlitchTip backend (v6.2.6)
- sentry-docs: Sentry documentation (unknown)
- glitchtip: GlitchTip documentation (unknown)
- glitchtip-mfa: GlitchTip MFA announcement (unknown)

Claims (full source mapping in the JSON block below):

- dsn (REASONED; sentry-docs): Client DSNs authorize event submission, not reading tracker data.
- sentry-bind (REASONED; sentry): SENTRY_BIND=9000 publishes nginx on all interfaces; set 127.0.0.1:9000 behind a TLS proxy.
- sentry-stores (REASONED; sentry): Leave web, relay and backing stores unpublished; their internal credentials are not a public boundary.
- sentry-registration (REASONED; sentry): auth.allow-registration defaults False; keep it false on an internet-facing tracker.
- sentry-admin (REASONED; sentry): createuser --superuser explicitly creates an administrator; plain createuser defaults its superuser prompt to no.
- sentry-url (REASONED; sentry): Set system.url-prefix to the public HTTPS origin.
- sentry-secret (REASONED; sentry): Generate system.secret-key once and keep it out of version control.
- sentry-cookies (REASONED; sentry): Enable forwarded scheme/host recognition and secure session/CSRF cookies; bundled settings are commented out.
- sentry-nginx (REASONED; sentry): Bundled nginx overwrites X-Forwarded-Proto with its scheme; terminate TLS there or propagate the real scheme.
- sentry-mfa (REASONED; sentry-docs): Enforce organization member MFA with require2FA.
- sentry-scrubbing (REASONED; sentry-docs): Use dataScrubber, dataScrubberDefaults and scrubIPAddresses to reduce sensitive intake.
- sentry-precedence (REASONED; sentry, sentry-docs): auth.allow-registration prioritizes config.yml over the database; verify SSO provisioning and effective scrubbing separately.
- glitchtip-port (REASONED; glitchtip): GlitchTip Compose publishes 8000; bind privately behind TLS and verify the actual sample host bind.
- glitchtip-registration (REASONED; glitchtip): ENABLE_USER_REGISTRATION defaults True; False disables self-signup after the first user exists.
- glitchtip-secret (REASONED; glitchtip): Use a unique SECRET_KEY for Django signing and keep it out of version control.
- glitchtip-mfa (REASONED; glitchtip-mfa): Two-factor authentication is available since v1.8; confirm enforcement and SSO registration paths in the deployed version.
- glitchtip-stores (REASONED; glitchtip): Keep PostgreSQL and optional Valkey or Redis internal.
- membership (REASONED; sentry, sentry-prev, glitchtip-backend): Through Sentry 26.8.0, a single-organization signup without a pending invitation joined the default organization; its 26.10.1 behaviour is unverified since that code moved to the frontend. At GlitchTip backend v6.2.6, on login the signal adds a user with a linked social provider to an organization linked to that provider, with the first member of a memberless organization becoming owner.
- verify-listeners (REASONED; sentry, glitchtip): Inventory private 9000/8000 and backing ports; Docker forwarding can expose ports without host sockets.
- verify-sentry (REASONED; sentry, sentry-prev): Through Sentry 26.8.0, /auth/register/ redirects to the single-organization login; follow it and inspect the create-account path, since HTTP 200 alone cannot distinguish registration. At 26.10.1 that page serves a React app, so this redirect check is unverified; confirm registration state from the auth.allow-registration setting instead.
- verify-glitchtip (REASONED; glitchtip): On an operator-controlled fixture, signup succeeds with registration True and is refused with False after the first user.
- verify-stores (REASONED; sentry, glitchtip): Off-host backing-port probes judge TCP connection outcomes, not HTTP codes; distinguish the public HTTPS proxy and backend ports.
- verify-https (REASONED; sentry, glitchtip): Confirm plaintext web requests redirect to the HTTPS proxy; login pages, 404s and TLS errors do not prove controls.

````json
{
  "schema": 1,
  "checked": "2026-09-26",
  "documentation_checked": "2026-09",
  "body_sha256": "edbd055603171ef8b79e7910a038b4cff42d0f23f69870988b33241afe6e30cb",
  "components": {
    "sentry": {
      "name": "Sentry and self-hosted distribution",
      "basis": "26.10.1",
      "sources": {
        "s8c9ef6c47c63": "https://github.com/getsentry/self-hosted/blob/26.10.1/docker-compose.yml",
        "s6b3008b7ce70": "https://github.com/getsentry/self-hosted/blob/26.10.1/.env",
        "s8cfd1816bebc": "https://github.com/getsentry/sentry/blob/26.10.1/src/sentry/options/defaults.py",
        "s9dc4a5a38dd5": "https://github.com/getsentry/sentry/blob/26.10.1/src/sentry/runner/commands/createuser.py",
        "sffc6218f3e60": "https://github.com/getsentry/self-hosted/blob/26.10.1/sentry/sentry.conf.example.py",
        "s34e00f944b78": "https://raw.githubusercontent.com/getsentry/sentry/26.10.1/src/sentry/runner/commands/config.py",
        "s8448c8ef78cc": "https://github.com/getsentry/self-hosted/blob/26.10.1/nginx.conf#L63"
      }
    },
    "sentry-prev": {
      "name": "Sentry prior-release frontend-migrated reference",
      "basis": "26.8.0",
      "sources": {
        "se4a92c571e6f": "https://raw.githubusercontent.com/getsentry/sentry/26.8.0/src/sentry/web/frontend/auth_login.py"
      }
    },
    "glitchtip-backend": {
      "name": "GlitchTip backend",
      "basis": "v6.2.6",
      "sources": {
        "s32daf6ef6011": "https://gitlab.com/glitchtip/glitchtip-backend/-/blob/v6.2.6/apps/users/signals.py#L16-45"
      }
    },
    "sentry-docs": {
      "name": "Sentry documentation",
      "basis": "unknown",
      "sources": {
        "see399d43779f": "https://docs.sentry.io/api/organizations/update-an-organization/",
        "s5e15f3959620": "https://docs.sentry.io/concepts/key-terms/dsn-explainer/"
      }
    },
    "glitchtip": {
      "name": "GlitchTip documentation",
      "basis": "unknown",
      "sources": {
        "scaee058a19e4": "https://glitchtip.com/documentation/install/"
      }
    },
    "glitchtip-mfa": {
      "name": "GlitchTip MFA announcement",
      "basis": "unknown",
      "sources": {
        "sb4f6be6e6b48": "https://glitchtip.com/blog/2021-09-17-glitchtip-1-8/"
      }
    }
  },
  "claims": {
    "dsn": {"text": "Client DSNs authorize event submission, not reading tracker data.", "components": ["sentry-docs"], "sources": ["sentry-docs:s5e15f3959620"], "status": "REASONED"},
    "sentry-bind": {"text": "SENTRY_BIND=9000 publishes nginx on all interfaces; set 127.0.0.1:9000 behind a TLS proxy.", "components": ["sentry"], "sources": ["sentry:s8c9ef6c47c63", "sentry:s6b3008b7ce70"], "status": "REASONED"},
    "sentry-stores": {"text": "Leave web, relay and backing stores unpublished; their internal credentials are not a public boundary.", "components": ["sentry"], "sources": ["sentry:s8c9ef6c47c63"], "status": "REASONED"},
    "sentry-registration": {"text": "auth.allow-registration defaults False; keep it false on an internet-facing tracker.", "components": ["sentry"], "sources": ["sentry:s8cfd1816bebc"], "status": "REASONED"},
    "sentry-admin": {"text": "createuser --superuser explicitly creates an administrator; plain createuser defaults its superuser prompt to no.", "components": ["sentry"], "sources": ["sentry:s9dc4a5a38dd5"], "status": "REASONED"},
    "sentry-url": {"text": "Set system.url-prefix to the public HTTPS origin.", "components": ["sentry"], "sources": ["sentry:sffc6218f3e60", "sentry:s8cfd1816bebc"], "status": "REASONED"},
    "sentry-secret": {"text": "Generate system.secret-key once and keep it out of version control.", "components": ["sentry"], "sources": ["sentry:s8cfd1816bebc", "sentry:sffc6218f3e60", "sentry:s34e00f944b78"], "status": "REASONED"},
    "sentry-cookies": {"text": "Enable forwarded scheme/host recognition and secure session/CSRF cookies; bundled settings are commented out.", "components": ["sentry"], "sources": ["sentry:sffc6218f3e60"], "status": "REASONED"},
    "sentry-nginx": {"text": "Bundled nginx overwrites X-Forwarded-Proto with its scheme; terminate TLS there or propagate the real scheme.", "components": ["sentry"], "sources": ["sentry:s8c9ef6c47c63", "sentry:sffc6218f3e60", "sentry:s8448c8ef78cc"], "status": "REASONED"},
    "sentry-mfa": {"text": "Enforce organization member MFA with require2FA.", "components": ["sentry-docs"], "sources": ["sentry-docs:see399d43779f"], "status": "REASONED"},
    "sentry-scrubbing": {"text": "Use dataScrubber, dataScrubberDefaults and scrubIPAddresses to reduce sensitive intake.", "components": ["sentry-docs"], "sources": ["sentry-docs:see399d43779f"], "status": "REASONED"},
    "sentry-precedence": {"text": "auth.allow-registration prioritizes config.yml over the database; verify SSO provisioning and effective scrubbing separately.", "components": ["sentry", "sentry-docs"], "sources": ["sentry:s8cfd1816bebc", "sentry-docs:see399d43779f"], "status": "REASONED"},
    "glitchtip-port": {"text": "GlitchTip Compose publishes 8000; bind privately behind TLS and verify the actual sample host bind.", "components": ["glitchtip"], "sources": ["glitchtip:scaee058a19e4"], "status": "REASONED"},
    "glitchtip-registration": {"text": "ENABLE_USER_REGISTRATION defaults True; False disables self-signup after the first user exists.", "components": ["glitchtip"], "sources": ["glitchtip:scaee058a19e4"], "status": "REASONED"},
    "glitchtip-secret": {"text": "Use a unique SECRET_KEY for Django signing and keep it out of version control.", "components": ["glitchtip"], "sources": ["glitchtip:scaee058a19e4"], "status": "REASONED"},
    "glitchtip-mfa": {"text": "Two-factor authentication is available since v1.8; confirm enforcement and SSO registration paths in the deployed version.", "components": ["glitchtip-mfa"], "sources": ["glitchtip-mfa:sb4f6be6e6b48"], "status": "REASONED"},
    "glitchtip-stores": {"text": "Keep PostgreSQL and optional Valkey or Redis internal.", "components": ["glitchtip"], "sources": ["glitchtip:scaee058a19e4"], "status": "REASONED"},
    "membership": {"text": "Through Sentry 26.8.0, a single-organization signup without a pending invitation joined the default organization; its 26.10.1 behaviour is unverified since that code moved to the frontend. At GlitchTip backend v6.2.6, on login the signal adds a user with a linked social provider to an organization linked to that provider, with the first member of a memberless organization becoming owner.", "components": ["sentry", "sentry-prev", "glitchtip-backend"], "sources": ["sentry:sffc6218f3e60", "sentry-prev:se4a92c571e6f", "glitchtip-backend:s32daf6ef6011"], "status": "REASONED"},
    "verify-listeners": {"text": "Inventory private 9000/8000 and backing ports; Docker forwarding can expose ports without host sockets.", "components": ["sentry", "glitchtip"], "sources": ["sentry:s8c9ef6c47c63", "glitchtip:scaee058a19e4"], "status": "REASONED", "verify": [1]},
    "verify-sentry": {"text": "Through Sentry 26.8.0, /auth/register/ redirects to the single-organization login; follow it and inspect the create-account path, since HTTP 200 alone cannot distinguish registration. At 26.10.1 that page serves a React app, so this redirect check is unverified; confirm registration state from the auth.allow-registration setting instead.", "components": ["sentry", "sentry-prev"], "sources": ["sentry:s8cfd1816bebc", "sentry:sffc6218f3e60", "sentry-prev:se4a92c571e6f"], "status": "REASONED", "verify": [2]},
    "verify-glitchtip": {"text": "On an operator-controlled fixture, signup succeeds with registration True and is refused with False after the first user.", "components": ["glitchtip"], "sources": ["glitchtip:scaee058a19e4"], "status": "REASONED", "verify": [2]},
    "verify-stores": {"text": "Off-host backing-port probes judge TCP connection outcomes, not HTTP codes; distinguish the public HTTPS proxy and backend ports.", "components": ["sentry", "glitchtip"], "sources": ["sentry:s8c9ef6c47c63", "glitchtip:scaee058a19e4"], "status": "REASONED", "verify": [2]},
    "verify-https": {"text": "Confirm plaintext web requests redirect to the HTTPS proxy; login pages, 404s and TLS errors do not prove controls.", "components": ["sentry", "glitchtip"], "sources": ["sentry:sffc6218f3e60", "glitchtip:scaee058a19e4"], "status": "REASONED", "verify": [2]}
  }
}
````
<!-- version-basis:end -->
