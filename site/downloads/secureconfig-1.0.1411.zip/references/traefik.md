# Traefik: automatic TLS and authentication middleware

Traefik is a reverse proxy that sits in front of your applications, often Docker containers, and routes each request to the right one. This guide helps your AI assistant configure it securely, including HTTPS entry points with HTTP redirected, ACME certificates, authentication middleware on routes, and request limits.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/traefik.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Traefik v3 documentation v3.7, Traefik ACME storage source v3.7.17, Traefik BasicAuth source v3.7.17, Apache httpd htpasswd source 2.4.69, and curl write-out minimum 7.75.0; 2 further sources are pinned to a commit and 4 carry no recorded version. Metadata reviewed 2026-11-08; documentation checked September 2026. The guide records 31 claims: 1 demonstrated by a check that ran; 30 reasoned from cited sources and any earlier-form run (not a live demonstration of the shipped form).

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Applies to Traefik v2 and v3. Traefik obtains and renews certificates itself through ACME resolvers, which suits container deployments.

## 1. Static configuration: entry points, redirect, ACME

`traefik.yml`:

```yaml
entryPoints:
  web:
    address: ":80"
    http:
      redirections:
        entryPoint:
          to: websecure
          scheme: https
  websecure:
    address: ":443"

certificatesResolvers:
  letsencrypt:
    acme:
      email: admin@example.com
      storage: /letsencrypt/acme.json
      tlsChallenge: {}

providers:
  docker:
    exposedByDefault: false
```

`acme.json` must persist across restarts (volume-mount it) and be mode `600`. The TLS-ALPN challenge above needs port 443 reachable from the internet; use `httpChallenge` (port 80) or a `dnsChallenge` (wildcards, no inbound ports) where that fits better.

The `providers.docker` block turns on container discovery, and `exposedByDefault: false` is the security-relevant half. Its default is `true`, so a `providers.docker` block without that line builds a router for every eligible container it discovers, not only the one you labelled. The provider reads labels over the Docker socket, so mount it into the Traefik service:

```yaml
services:
  traefik:
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock:ro
```

Mounting the socket gives Traefik control of the Docker daemon, which is root-equivalent on the host: a compromised Traefik is a compromised host. The `:ro` marks the socket file read-only; it does not make the Docker API read-only. To limit what Traefik can call, put a read-only Docker socket proxy in front of the socket (see the Docker provider reference under Sources).

Raise the protocol floor with a TLS options block in the dynamic configuration:

```yaml
tls:
  options:
    default:
      minVersion: VersionTLS12
```

## 2. Route a service with TLS (Docker labels)

```yaml
services:
  app:
    image: yourapp
    labels:
      - traefik.enable=true
      - traefik.http.routers.app.rule=Host(`app.example.com`)
      - traefik.http.routers.app.entrypoints=websecure
      - traefik.http.routers.app.tls.certresolver=letsencrypt
      - traefik.http.services.app.loadbalancer.server.port=3000
```

Labelling this container `traefik.enable=true` opts it in; it does not keep any other container private. With `exposedByDefault: false` set in section 1, Traefik ignores every container that lacks that label. Without it, discovery is daemon-wide, not scoped to this Compose project, so any other container that exposes a port Traefik can build a service from also gets a router matched by its `Host` header on the same `:443` listener. A container with no usable port is skipped, and the port Traefik picks need not serve usable HTTP; but a router you never requested is the exposure this setting shuts off. The label opts a container in; it never opts others out, so keep it on each application you mean to publish.

Do not also publish the app's port with `ports:`; only Traefik publishes 80 and 443. See [docker.md](docker.md).

## 3. Require authentication

Application-level login is preferable ([authentication.md](authentication.md)). At the proxy, attach a basicAuth middleware with bcrypt entries from `htpasswd -nB -C 12 admin`. In Apache httpd 2.4.69, bare `-nB` defaults to bcrypt cost 5 and `-C 12` selects cost 12; OWASP at 72865b1e recommends a work factor of 10 or more for legacy bcrypt:

```yaml
    labels:
      - traefik.http.middlewares.app-auth.basicauth.users=admin:$$2y$$12$$REPLACE_WITH_HASH
      - traefik.http.routers.app.middlewares=app-auth
```

In Compose files every `$` in the hash must be doubled to `$$`. The file-provider equivalent, where no escaping is needed:

```yaml
http:
  middlewares:
    app-auth:
      basicAuth:
        users:
          - "admin:$2y$12$REPLACE_WITH_HASH"
```

Load that dynamic file with `providers.file.directory` (or `providers.file.filename`) in the static config, and when a Docker-labelled router references a file-defined middleware, qualify it as `app-auth@file`. basicAuth is single-factor. For human-facing sites, add MFA with the `forwardAuth` middleware pointed at [Authelia](https://www.authelia.com/) or [oauth2-proxy](https://github.com/oauth2-proxy/oauth2-proxy), or front the site with Cloudflare Access and require MFA in its governing Access setting (policy over application over organization); options in [mfa.md](mfa.md).

Run Traefik v3.7.10 or later, or v3.6.25 or later on the 3.6 line. Advisory GHSA-6765-c87h-8mrf, rated low, reports that in Traefik v3.6.11 to v3.6.24 and v3.7.0 to v3.7.9 the BasicAuth singleflight key that deduplicates password checks could collide across different credential pairs, so a request could be authenticated as a different user than its own credentials; it is fixed in v3.6.25 and v3.7.10. This guide's prior v3.5.0 basis and the current v3.7.17 are outside that affected range. Traefik v3.7.17 keys the check on the user and the password, refuses to create a BasicAuth middleware with no users, and checks an unknown user's password against one of the configured hashes, which its source says resists timing attacks only when every configured hash uses the same algorithm.

## 4. Bound the expensive endpoints

Three middlewares, attached to the router alongside the auth middleware from section 3.

```yaml
    # ADD these to the labels you already have. Do not replace that list:
    # section 2 carries the router rule, entrypoints, certresolver and service
    # port, and section 3 carries basicauth.users. A labels block without them
    # breaks routing and authentication.
    labels:
      - traefik.http.middlewares.app-body.buffering.maxRequestBodyBytes=10485760
      - traefik.http.middlewares.app-inflight.inflightreq.amount=10
      - traefik.http.middlewares.app-rate.ratelimit.average=10
      - traefik.http.middlewares.app-rate.ratelimit.burst=20
      # replace the section 3 middlewares= line with this one
      - traefik.http.routers.app.middlewares=app-rate,app-inflight,app-auth,app-body
```

Order matters here. `app-rate` and `app-inflight` come before `app-auth` so they bound failed-login attempts: Traefik v3.7.17 BasicAuth returns on failed credentials without calling its next handler, so a limiter placed after auth cannot count a rejected attempt. `buffering` reads the request into memory or disk before forwarding it, so it must
come after the admission controls; placed first, an accepted upload consumes the buffer before
`ratelimit` or `inflightreq` has considered it. `maxRequestBodyBytes` sets the largest body accepted;
`memRequestBodyBytes`, which defaults to 1048576, is the separate threshold at which buffering moves
from memory to disk. Raising the first increases what you will buffer, not where that buffer lives. `ratelimit` is per source by default, while `inflightreq` caps concurrent
in-flight requests rather than their rate, and its `sourceCriterion` defaults to the request host rather
than the client, so set it explicitly if you want a per-client cap.

## 5. Verify (REASONED: all Verify scenarios follow the cited Traefik and curl documentation; no live Docker/Traefik canary demonstration is recorded. The recorded 429 alone does not demonstrate limiter attribution, and the 429 was recorded before the flood probe took a guarded host and before the first block ran its parts in one subshell with one exit status. This metadata-only review has no authorized deployment fixture. The redirect, unauthenticated, body-size and flood requests take the app's host name on guarded `set --` lines that refuse example.com, example.net, example.org and their subdomains. The repository gate suite's bash -n and ShellCheck 0.11.0 passes over every block cover the current forms of the three blocks. Stub runs on 2026-10-31 with Bash 5.3.9, stub curl, docker, sudo, rm and ss and no network ran the guards and every exit status, on the current forms of the second and third blocks and on the earlier form of the first, which lowercased the host with `tr` before refusing reserved names; no Traefik answered them. The first block now refuses a reserved name under bash's `nocasematch` option instead of through `tr`, and each of its host parts refuses with 2, saying the block needs bash, when `shopt` fails, as it does in dash. That current form is covered by stub runs on 2026-11-01 with stub curl, docker, sudo, head, rm and ss and no network. In bash, each host part refused example.com, example.net, example.org and their subdomains in lower, upper and mixed case with 2 and no curl call, also with `tr` absent from PATH or failing and under an inherited `nocasematch`, `readonly`, `declare -i` or `set -e`, and a host name outside the reserved names reached its probes. Under dash, stub runs of the current form refused every host name in each host part with 2 and the bash message before its probes; the block still ran `docker compose ps` and `sudo ss -tlnp` and exited 2. The first block records 2 for a missing `ss` only when nothing else was recorded, because none of its other parts needs `ss`, and 3 when `sudo ss -tlnp` runs and fails. Where sudoers sets `secure_path`, sudo looks `ss` up in that path instead of your PATH (the guide's cited sudo sudoers manual, secure_path entry), so the `command -v ss` check can refuse although sudo would find `ss`, or pass and then end with status 3 when sudo cannot run it.)

```bash
(                                       # the whole block in one subshell, so one exit status covers every part of it
  set +e                                # errexit off here, so a part that ends nonzero is folded into the status below instead of ending the block
  set -- 0                              # the block's status so far: 3 (inconclusive) outranks 2 (a part refused its input), which outranks 0; no answer here is classified
  (                                     # a subshell, so your own script arguments are untouched
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_APP_HOST'   # the public host name Traefik routes to the app (the Host rule in section 2), no scheme, user name, port, path, query, fragment, percent sign or trailing dot: replace inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
    case "$1" in
      ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
    case "$1" in
      example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -u nocasematch   # every match below compares letter case exactly again
    set -- "$1" 0                       # the 2nd value is this part's status so far, ranked as above
    curl -q -g -sI "http://$1/"         # expect a redirect to https://
    case "$?" in 0) ;; *) echo "curl exit $?: the redirect request failed; inconclusive"; set -- "$1" 3 ;; esac
    curl -q -g -sI "https://$1/"        # expect 401 without credentials once auth is on
    case "$?" in 0) ;; *) echo "curl exit $?: the HTTPS request failed; inconclusive"; set -- "$1" 3 ;; esac
    exit "$2"
  )
  case "$?:$1" in 0:*) ;; 2:0) set -- 2 ;; 2:*) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  (
    # curl reads the admin password from a config stream on stdin (--config -),
    # never argv (-u admin:PASSWORD is readable in ps / /proc/<pid>/cmdline).
    trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
    # The password you substitute on the set -- line enters shell history.
    # Clear that history line afterward.
    # Stdin closes the argv channel only: it does not hide the password from
    # set -x tracing or your own account's view of the process.
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_APP_HOST' 'REPLACE_WITH_PASSWORD'   # the same app host name as the checks above (no scheme, user name, port, path, query, fragment, percent sign or trailing dot), then the admin password: replace inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
    case "$1" in
      ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
    case "$1" in
      example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -u nocasematch   # every match below compares letter case exactly again
    case "$2" in *REPLACE_WITH_*|""|*[[:cntrl:]]*) echo "substitute the admin password on the set -- line above; not probing"; exit 2 ;; esac
    set -- "$1" "${2//\\/\\\\}"
    set -- "$1" "${2//\"/\\\"}"
    set -- "$1" "$2" 0                  # the 3rd value is this part's status so far, ranked as above
    if head -c 1M /dev/zero > /tmp/under.bin && head -c 11M /dev/zero > /tmp/over.bin; then
      printf 'user = "admin:%s"\n' "$2" | curl -q -g -s -o /dev/null -w '%{http_code}\n' --config - --data-binary @/tmp/under.bin "https://$1/"
                                       # positive control: under the limit, expect the app's own normal response (a 2xx, or its own 404/redirect), never 413; a 401 means the credentials, not the size limit, were exercised and a 000 means transport failed, either of which voids the control
      case "$?" in 0) ;; *) echo "curl exit $?: the 1M request failed; inconclusive"; set -- "$1" "$2" 3 ;; esac
      printf 'user = "admin:%s"\n' "$2" | curl -q -g -s -o /dev/null -w '%{http_code}\n' --config - --data-binary @/tmp/over.bin  "https://$1/"
                                       # 413. Credentials matter: app-body runs after app-auth, so an
                                       # unauthenticated probe is counted by app-rate/app-inflight but stops
                                       # at 401 before app-body buffers it. A backend with its own limit
                                       # returns the same code, so attributing the refusal needs an isolated
                                       # environment with app-body removed
      case "$?" in 0) ;; *) echo "curl exit $?: the 11M request failed; inconclusive"; set -- "$1" "$2" 3 ;; esac
    else
      echo "head could not create /tmp/under.bin and /tmp/over.bin, so the size checks did not run; inconclusive"; set -- "$1" "$2" 3
    fi
    rm -f /tmp/under.bin /tmp/over.bin
    case "$?" in 0) ;; *) echo "rm exit $?: /tmp/under.bin and /tmp/over.bin could not be removed; inconclusive"; set -- "$1" "$2" 3 ;; esac
    exit "$3"
  )
  case "$?:$1" in 0:*) ;; 2:0) set -- 2 ;; 2:*) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  (                                     # a subshell, so your own script arguments are untouched
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_APP_HOST'   # the same app host name as the checks above, no scheme, user name, port, path, query, fragment, percent sign or trailing dot: replace inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
    case "$1" in
      ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
    case "$1" in
      example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -u nocasematch   # every match below compares letter case exactly again
    set -o pipefail                     # the pipeline's status is its last failing command's, so a failed request inside xargs is not hidden by uniq
    seq 1 40 | xargs -P 40 -I{} curl -q -g -s -o /dev/null -w '%{http_code}\n' "https://$1/" | sort | uniq -c
                                         # No credentials here: app-rate and app-inflight run BEFORE app-auth in the
                                         # middleware chain (section 4); Traefik v3.7.17 BasicAuth does not call its
                                         # next handler on failure, so an unauthenticated flood is counted by the
                                         # limiter, keyed on the client source. A 429 appeared. That is all this shows.
                                         # inflightreq also returns
                                         # 429, and an upstream under load can too, so this does not
                                         # establish that ratelimit fired. Attributing it needs an isolated
                                         # environment with both disabled as a baseline, then each enabled
                                         # alone, with the arrival rate actually measured
    case "$?" in 0) exit 0 ;; *) echo "flood pipeline exit $?: a request or a counting command failed; inconclusive"; exit 3 ;; esac
  )
  case "$?:$1" in 0:*) ;; 2:0) set -- 2 ;; 2:*) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  docker compose ps                     # only Traefik publishes ports; the app's 3000 must NOT be published
  case "$?" in 0) ;; *) echo "docker compose ps exit $?; inconclusive"; set -- 3 ;; esac
  if command -v ss >/dev/null; then     # no other part needs ss, so a missing ss records 2 only when nothing else was recorded
    sudo ss -tlnp                       # read the whole listener table, do not grep it down to the port you
                                        # expect (that hides an unexpected listener): only Traefik should
                                        # answer on the host. A backend answering on 3000 directly bypasses
                                        # Traefik's TLS and its authentication middleware
    case "$?" in 0) ;; *) echo "sudo ss -tlnp exit $?; inconclusive"; set -- 3 ;; esac
  else
    echo "ss is not installed here; not listing sockets"; case "$1" in 0) set -- 2 ;; esac
  fi
  echo "block exit $1; no answer in this block is classified: judge the redirect and 401 headers, the 1M and 11M codes, the flood counts and both listings yourself against the comments above"
  exit "$1"
)
```

Check the Traefik log for ACME errors on first start; issuance failures otherwise surface as a self-signed "TRAEFIK DEFAULT CERT" in the browser.

`docker compose ps` and `ss` help find a container that bypasses Traefik with its own `ports:`, though neither is exhaustive: `docker compose ps` lists only this Compose project, and a port published through NAT alone, with Docker's userland proxy disabled, opens no host listening socket for `ss` to show. Neither, in any case, sees a container Traefik routes without your asking: a routed container has no host port publication of its own. To confirm `exposedByDefault: false` actually excludes unlabelled containers, launch an unlabelled canary on Traefik's network and probe the front door. Do this on a disposable copy of the deployment; never make a container deliberately routable on the production host. These canary steps are reasoned from Traefik's documented routing behavior and the exposed-versus-fixed outcomes it predicts; they have not been demonstrated against a live Docker/Traefik deployment here.

```yaml
services:
  canary:
    image: traefik/whoami   # one HTTP port, echoes its own hostname; no traefik.* labels, no ports:
```

`traefik/whoami` listens on a single HTTP port, so Traefik's single-port detection can build a service for it and a routed reply is unmistakable (the body carries a `Hostname:` line). Read the router rule Traefik generated for the canary; its `Host(...)` value is the canary's normalized name, and you pass that value as the `Host:` header below. Probe plain HTTP against the `:443` listener: the auto-generated router never requested TLS, so it answers plain HTTP even there. Run these probe blocks with Bash and curl 7.75.0 or newer, which added the `exitcode` and `errormsg` write-out variables they print.

```bash
(                              # a subshell, so your own shell arguments are untouched; it exits 0 for 404, 1 for 200, 502 or 504, 3 otherwise
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_TRAEFIK_HOST' 'REPLACE_WITH_HTTPS_PORT' 'REPLACE_WITH_CANARY_HOST_HEADER'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 3 values; not probing"; exit 2; }
  if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]; then echo "substitute the values on the set -- line above; not probing"; exit 2; fi
  case "$1:$2:$3" in
    *REPLACE_WITH_*) echo "substitute the values on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- "$1" "$2" "$3" "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 \
    -H "Host: $3" \
    -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "http://$1:$2/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "${4##*$'\n'}" "${4%$'\n'*}"   # curl's exit status, then everything it printed
  printf '%s' "$5"
  set -- "$1" "$2" "$3" "$4" "${5%$'\n'}"              # the same, without the final line feed, so the last line is curl's http= line and the body cannot stand in for it
  case "$4:${5##*$'\n'}" in
    "0:http=404 exit="*) echo "pass: Traefik answered 404 for the canary, so it ignored the unlabelled container"; set -- 0 ;;
    "0:http=200 exit="*|"0:http=502 exit="*|"0:http=504 exit="*) echo "FINDING: Traefik routed the unlabelled canary (expected on the exposed calibration fixture; anywhere else an exposure to remove)"; set -- 1 ;;
    0:*) echo "the canary's answer is neither the 404 pass nor a 200, 502 or 504 route; inconclusive"; set -- 3 ;;
    *) echo "curl exit $4: the canary request failed; inconclusive"; set -- 3 ;;
  esac
  echo "block exit $1; a 404 counts only after the exposed-fixture calibration returned 200 with the canary's own Hostname: body, which this block does not check, so judge that and the body yourself"
  exit "$1"
)
```

With `exposedByDefault: false` the canary returns `http=404` from Traefik's unmatched-route handler: it was ignored, and that is the pass. Calibrate first on the exposed fixture (temporarily `exposedByDefault: true`), where the canary must return `http=200` with a `Hostname:` body naming the canary itself, not some other service; that proves the probe reaches Traefik through the canary's own router. Without that positive calibration a `404` is not trustworthy: it can equally mean Traefik never discovered the canary or built no matching route. A canary Traefik did discover but cannot reach on its network answers `502` or `504`, not `404`. On production, run the probe only after applying the fix; a canary that answers `200` there is a live exposure to remove, not a passing test.

A `404` for the canary also appears when the whole Docker provider is off, which breaks all routing. Confirm the provider still works by probing the app itself, published only over HTTPS:

```bash
(                              # a subshell, so your own shell arguments are untouched; it exits 0 when the app answers, 3 for 404 or a failed request
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_APP_HOST' 'REPLACE_WITH_HTTPS_PORT'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  if [ -z "$1" ] || [ -z "$2" ]; then echo "substitute the values on the set -- line above; not probing"; exit 2; fi
  case "$1:$2" in
    *REPLACE_WITH_*) echo "substitute the values on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- "$1" "$2" "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 \
    -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "https://$1:$2/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "${3##*$'\n'}" "${3%$'\n'*}"   # curl's exit status, then everything it printed
  printf '%s' "$4"
  set -- "$1" "$2" "$3" "${4%$'\n'}"              # the same, without the final line feed, so the last line is curl's http= line and the body cannot stand in for it
  case "$3:${4##*$'\n'}" in
    "0:http=404 exit="*) echo "the app answered 404, so the provider is not routing it; inconclusive, and a canary 404 means nothing until it does"; set -- 3 ;;
    0:*) echo "the app answered, so the provider is routing it"; set -- 0 ;;
    *) echo "curl exit $3: the request failed, and a connection failure means the provider is not routing the app; inconclusive"; set -- 3 ;;
  esac
  echo "block exit $1; the status code is not classified, and a 401 may come from the app's own login rather than Traefik's basicAuth, so judge it and the router's middlewares yourself"
  exit "$1"
)
```

With the authentication from section 3 in place, this unauthenticated probe returns `http=401`: a response, rather than a connection failure or a `404`, means the provider is routing this app. The `401` may come from Traefik's basicAuth or from the app's own login, so it confirms routing, not specifically that the proxy middleware is attached; confirm that separately from the router's `middlewares` in the dashboard or config. (Feed the admin credential to that curl on stdin, as the section 5 Verify block does, to see the app's own authenticated response instead.) The fix is confirmed when, in the same run, the app answers `401` (or your known authenticated `200`) and the canary answers `404`: routing works and the unlabelled container is excluded. A `404` or a connection failure for the app instead means the provider is not routing it. No `-k` here; the app needs a real certificate.

## Common mistakes

- Enabling the Traefik dashboard (`api.insecure=true` or an unprotected `api@internal` router) on a public entry point; keep it off or behind the auth middleware.
- Forgetting to persist `acme.json`, which re-issues certificates on every restart and hits CA rate limits.
- Single `$` in Compose basicauth labels, which breaks the hash silently.
- Enabling the Docker provider but leaving `exposedByDefault` at its default of `true`, which exposes every eligible container it discovers to routing, not only the labelled one; a working HTTP route also needs a reachable HTTP backend on the detected port.
- Assuming this page covers Docker Swarm. It covers standalone Docker; Swarm is a separate provider (`providers.swarm` in Traefik v3) with its own `exposedByDefault`, which also defaults to `true`. Consult the Swarm provider reference for your version before relying on this page under Swarm.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- Traefik documentation (rolling documentation, checked September 2026): https://doc.traefik.io/traefik/ (HTTPS/ACME, routers, and basicAuth middleware sections)
- Docker provider (`exposedByDefault`, socket endpoint): https://doc.traefik.io/traefik/reference/install-configuration/providers/docker/
- Swarm provider (`providers.swarm.exposedByDefault`): https://doc.traefik.io/traefik/reference/install-configuration/providers/swarm/
- curl manual (the `exitcode` and `errormsg` write-out variables, both added in curl 7.75.0): https://curl.se/docs/manpage.html
- Buffering middleware (`maxRequestBodyBytes`, `memRequestBodyBytes`): https://doc.traefik.io/traefik/middlewares/http/buffering/
- InFlightReq middleware (`amount`): https://doc.traefik.io/traefik/middlewares/http/inflightreq/
- RateLimit middleware (`average`, `burst`, `period`): https://doc.traefik.io/traefik/middlewares/http/ratelimit/
- Traefik v3.7 entry-point HTTPS redirection (checked November 2026): https://doc.traefik.io/traefik/v3.7/reference/install-configuration/entrypoints/
- Traefik v3.7 ACME renewal, challenges and certificate storage (checked November 2026): https://doc.traefik.io/traefik/v3.7/reference/install-configuration/tls/certificate-resolvers/acme/
- Traefik v3.7.17 ACME storage file creation with mode 600 (checked November 2026): https://github.com/traefik/traefik/blob/v3.7.17/pkg/provider/acme/local_store.go#L172
- Traefik v3.7 minimum TLS version (checked November 2026): https://doc.traefik.io/traefik/v3.7/reference/routing-configuration/http/tls/tls-options/
- Traefik v3.7 file-provider configuration (checked November 2026): https://doc.traefik.io/traefik/v3.7/reference/install-configuration/providers/others/file/
- Traefik v3.7 BasicAuth and Compose dollar-sign escaping (checked November 2026): https://doc.traefik.io/traefik/v3.7/reference/routing-configuration/http/middlewares/basicauth/
- Traefik v3.7 ForwardAuth delegation (checked November 2026): https://doc.traefik.io/traefik/v3.7/reference/routing-configuration/http/middlewares/forwardauth/
- Traefik v3.7.17 BasicAuth failure and next-handler path (checked November 2026): https://github.com/traefik/traefik/blob/v3.7.17/pkg/middlewares/auth/basic_auth.go#L82-L119
- Traefik v3.7.17 BasicAuth refusal of an empty users list and choice of a configured hash for unknown users (checked November 2026): https://github.com/traefik/traefik/blob/v3.7.17/pkg/middlewares/auth/basic_auth.go#L48-L55
- Traefik v3.7.17 BasicAuth unknown-user hash check and user-and-password singleflight key (checked November 2026): https://github.com/traefik/traefik/blob/v3.7.17/pkg/middlewares/auth/basic_auth.go#L122-L143
- Traefik security advisory GHSA-6765-c87h-8mrf (severity low; affects v3.6.11 to v3.6.24 and v3.7.0 to v3.7.9, fixed in v3.6.25 and v3.7.10), cited in the comment above `singleflightKey` in the v3.7.17 BasicAuth source (checked November 2026): https://github.com/traefik/traefik/security/advisories/GHSA-6765-c87h-8mrf
- Apache httpd 2.4.69 htpasswd bcrypt default cost (checked October 2026): https://github.com/apache/httpd/blob/2.4.69/support/passwd_common.h#L45
- Apache httpd 2.4.69 htpasswd default cost applied (checked October 2026): https://github.com/apache/httpd/blob/2.4.69/support/passwd_common.c#L292-L295
- Apache httpd 2.4.69 htpasswd `-C` cost option (checked October 2026): https://github.com/apache/httpd/blob/2.4.69/support/passwd_common.c#L373-L382
- Apache httpd 2.4.69 htpasswd usage (checked October 2026): https://github.com/apache/httpd/blob/2.4.69/support/htpasswd.c#L100-L128
- OWASP Password Storage Cheat Sheet at 72865b1e3b5754246a101778dc00b37f9c233373, legacy bcrypt work factor (checked October 2026): https://github.com/OWASP/CheatSheetSeries/blob/72865b1e3b5754246a101778dc00b37f9c233373/cheatsheets/Password_Storage_Cheat_Sheet.md#L13
- Cloudflare Access MFA documentation at c896795b8e8bab68d05ae78d64c9cbcda1fdb104, application or policy MFA (checked October 2026): https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/policies/mfa-requirements.mdx#L35-L81
- sudo SUDO_1_9_16p2 sudoers manual, secure_path (checked October 2026): https://github.com/sudo-project/sudo/blob/SUDO_1_9_16p2/docs/sudoers.man.in#L5650-L5655


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- traefik-v3: Traefik v3 documentation (v3.7)
- traefik-source: Traefik ACME storage source (v3.7.17)
- traefik-basicauth-source: Traefik BasicAuth source (v3.7.17)
- traefik-docs: Traefik documentation (rolling) (unknown)
- docker: Traefik Docker provider (unknown)
- swarm: Traefik Swarm provider (unknown)
- middleware: Traefik middleware documentation (unknown)
- httpd-source: Apache httpd htpasswd source (2.4.69)
- cloudflare-source: Cloudflare Access MFA documentation (c896795b8e8bab68d05ae78d64c9cbcda1fdb104)
- curl: curl write-out minimum (7.75.0)
- owasp-source: OWASP Password Storage Cheat Sheet (72865b1e3b5754246a101778dc00b37f9c233373)

Claims (full source mapping in the JSON block below):

- entrypoints (REASONED; traefik-docs, traefik-v3): For Traefik v2/v3, web :80 redirects to HTTPS websecure :443 and an ACME resolver obtains/renews certificates.
- acme-storage (REASONED; traefik-docs, traefik-v3, traefik-source): Persist acme.json across restarts with mode 600 to retain certificates and avoid repeated issuance/rate limits.
- acme-challenges (REASONED; traefik-docs, traefik-v3): TLS-ALPN requires inbound 443; HTTP-01 uses 80, while DNS supports wildcards without inbound ports.
- docker-default (REASONED; docker): Docker discovery defaults exposedByDefault to true; set false and opt each intended container in with traefik.enable=true.
- docker-scope (REASONED; docker): Discovery is daemon-wide, not Compose-project scoped; eligible unlabelled containers get routers unless excluded. Missing usable ports skip service creation.
- docker-socket (REASONED; docker): The Docker socket gives daemon control despite :ro; use a restricted socket proxy to limit API access.
- tls-floor (REASONED; traefik-docs, traefik-v3): Dynamic default TLS options set minVersion VersionTLS12.
- route (REASONED; traefik-docs, docker): Docker labels select the app host, websecure, letsencrypt resolver and backend port 3000.
- backend-isolation (REASONED; docker): Publish only Traefik 80/443, not the app's 3000, to prevent middleware/TLS bypass.
- basic (REASONED; traefik-docs, traefik-v3, httpd-source, owasp-source): Attach bcrypt basicAuth to the router; Apache httpd 2.4.69 htpasswd -nB defaults to bcrypt cost 5, while -C 12 selects cost 12; OWASP at 72865b1e recommends 10 or more for legacy bcrypt.
- compose-hash (REASONED; traefik-docs, traefik-v3): Double each dollar sign in Compose hash labels; file-provider hashes need no such escaping.
- file-provider (REASONED; traefik-docs, traefik-v3): Load dynamic files with providers.file.directory/filename and reference their middleware from Docker as app-auth@file.
- mfa (REASONED; traefik-docs, traefik-v3, cloudflare-source): Basic is single-factor; use forwardAuth with Authelia/oauth2-proxy or front the site with Cloudflare Access and require MFA in its governing Access setting (policy over application over organization).
- basicauth-advisory (REASONED; traefik-basicauth-source): GHSA-6765-c87h-8mrf (low): in Traefik v3.6.11-v3.6.24 and v3.7.0-v3.7.9 a colliding BasicAuth singleflight key could authenticate a request as another user; v3.6.25 and v3.7.10 fix it by keying on user plus password. v3.7.17 also refuses a middleware with no users and checks unknown users against a configured hash. Run v3.7.10+ (v3.6.25+ on 3.6); v3.5.0/v3.7.17 are outside the affected range.
- body-limit (REASONED; middleware): Attach buffering.maxRequestBodyBytes=10485760 alongside existing auth/routing labels; it bounds accepted body size.
- buffer-storage (REASONED; middleware): memRequestBodyBytes defaults to 1048576 and controls the memory-to-disk threshold independently of maximum accepted body size.
- rate-limit (REASONED; middleware): average=10 and burst=20 configure a rate cap, per source by default.
- inflight (REASONED; middleware): inflightreq.amount=10 bounds concurrent requests; sourceCriterion defaults to request host rather than client, so configure a per-client cap explicitly.
- middleware-order (REASONED; traefik-docs, middleware, traefik-basicauth-source): Rate/inflight precede auth to count rejected logins: Traefik v3.7.17 BasicAuth returns on failure without calling the next handler; buffering follows admission controls to avoid buffering rejected uploads.
- dashboard (REASONED; traefik-docs): Keep api.insecure and unprotected api@internal routers off public entry points or protect the dashboard with auth.
- swarm (REASONED; swarm): Standalone Docker guidance does not cover Swarm; v3 uses providers.swarm and its separate exposedByDefault also defaults true.
- verify-redirect (REASONED; traefik-docs): HTTP should redirect to HTTPS.
- verify-auth (REASONED; traefik-docs): Unauthenticated HTTPS should return 401 once auth is attached.
- verify-size (REASONED; middleware, traefik-docs): Authenticated 1M must reach the app and 11M return 413; 401/000 invalidate the control. Remove app-body in isolation to rule out backend refusal.
- observed-429 (DEMONSTRATED; middleware): The guide records only a 429 response; no limiter attribution or exposed/fixed demonstration is established; recorded on an earlier form of the flood probe, before it took a guarded host and ran inside the first block's single subshell.
- verify-rate (REASONED; middleware, traefik-basicauth-source): Concurrent unauthenticated probes can reach pre-auth limiters; 429 alone cannot distinguish rate, inflight or upstream refusal. Compare each limiter alone against both disabled.
- verify-isolation (REASONED; docker): Compose ps covers one project; ss misses NAT-only publication without a userland proxy. Neither finds unintended routes through Traefik.
- verify-acme (REASONED; traefik-docs): Inspect ACME startup errors; failed issuance can leave a self-signed TRAEFIK DEFAULT CERT.
- canary-route (REASONED; docker, traefik-docs): On a disposable deployment, unlabelled traefik/whoami has one HTTP port; use its generated Host rule and plain HTTP even on :443 because the generated router requests no TLS.
- verify-canary (REASONED; docker, curl): Calibrate exposedByDefault true with 200 and the canary Hostname body; false should give 404. Missing discovery/provider also gives 404, unreachable backend 502/504.
- verify-app-control (REASONED; docker, traefik-docs, curl): In the same run, the app must return 401 or known authenticated 200 while the canary gives 404; app 401 proves routing, not proxy-auth attachment. Keep TLS verification.

````json
{
  "schema": 1,
  "checked": "2026-11-08",
  "documentation_checked": "2026-09",
  "body_sha256": "68a57a292487e7116343504444c6caffc8b1193012efc01bfa56fdbe78e9e283",
  "components": {
    "traefik-v3": {
      "name": "Traefik v3 documentation",
      "basis": "v3.7",
      "sources": {
        "s0b6ac3975f40": "https://doc.traefik.io/traefik/v3.7/reference/install-configuration/entrypoints/",
        "se6cd04436adc": "https://doc.traefik.io/traefik/v3.7/reference/install-configuration/tls/certificate-resolvers/acme/",
        "s53640550c66d": "https://doc.traefik.io/traefik/v3.7/reference/routing-configuration/http/tls/tls-options/",
        "s67a26fc82498": "https://doc.traefik.io/traefik/v3.7/reference/install-configuration/providers/others/file/",
        "s8bce7ead3813": "https://doc.traefik.io/traefik/v3.7/reference/routing-configuration/http/middlewares/basicauth/",
        "s8a5b3bd688d0": "https://doc.traefik.io/traefik/v3.7/reference/routing-configuration/http/middlewares/forwardauth/"
      }
    },
    "traefik-source": {
      "name": "Traefik ACME storage source",
      "basis": "v3.7.17",
      "sources": {
        "s6ac13e6baddc": "https://github.com/traefik/traefik/blob/v3.7.17/pkg/provider/acme/local_store.go#L172"
      }
    },
    "traefik-basicauth-source": {
      "name": "Traefik BasicAuth source",
      "basis": "v3.7.17",
      "sources": {
        "s47f86b3ccaea": "https://github.com/traefik/traefik/blob/v3.7.17/pkg/middlewares/auth/basic_auth.go#L82-L119",
        "sa3b8ca37a702": "https://github.com/traefik/traefik/blob/v3.7.17/pkg/middlewares/auth/basic_auth.go#L48-L55",
        "sd275dbbf08d8": "https://github.com/traefik/traefik/blob/v3.7.17/pkg/middlewares/auth/basic_auth.go#L122-L143",
        "s08f357bbcbd2": "https://github.com/traefik/traefik/security/advisories/GHSA-6765-c87h-8mrf"
      }
    },
    "traefik-docs": {
      "name": "Traefik documentation (rolling)",
      "basis": "unknown",
      "sources": {
        "scbc0f2135c78": "https://doc.traefik.io/traefik/"
      }
    },
    "docker": {
      "name": "Traefik Docker provider",
      "basis": "unknown",
      "sources": {
        "se23fe4fe79fa": "https://doc.traefik.io/traefik/reference/install-configuration/providers/docker/"
      }
    },
    "swarm": {
      "name": "Traefik Swarm provider",
      "basis": "unknown",
      "sources": {
        "s256d46f3f558": "https://doc.traefik.io/traefik/reference/install-configuration/providers/swarm/"
      }
    },
    "middleware": {
      "name": "Traefik middleware documentation",
      "basis": "unknown",
      "sources": {
        "sd987195d64dd": "https://doc.traefik.io/traefik/middlewares/http/buffering/",
        "sd20dcba7ebca": "https://doc.traefik.io/traefik/middlewares/http/inflightreq/",
        "scf1b1e35ef5d": "https://doc.traefik.io/traefik/middlewares/http/ratelimit/"
      }
    },
    "httpd-source": {
      "name": "Apache httpd htpasswd source",
      "basis": "2.4.69",
      "sources": {
        "sf711558bdf3c": "https://github.com/apache/httpd/blob/2.4.69/support/passwd_common.h#L45",
        "s4aa0f7f341fb": "https://github.com/apache/httpd/blob/2.4.69/support/passwd_common.c#L292-L295",
        "s4482c55d79a2": "https://github.com/apache/httpd/blob/2.4.69/support/passwd_common.c#L373-L382",
        "s309ecdd34379": "https://github.com/apache/httpd/blob/2.4.69/support/htpasswd.c#L100-L128"
      }
    },
    "cloudflare-source": {
      "name": "Cloudflare Access MFA documentation",
      "basis": "c896795b8e8bab68d05ae78d64c9cbcda1fdb104",
      "sources": {
        "sdcac732541da": "https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/policies/mfa-requirements.mdx#L35-L81"
      }
    },
    "curl": {
      "name": "curl write-out minimum",
      "basis": "7.75.0",
      "sources": {
        "s2b2686afaf41": "https://curl.se/docs/manpage.html"
      }
    },
    "owasp-source": {
      "name": "OWASP Password Storage Cheat Sheet",
      "basis": "72865b1e3b5754246a101778dc00b37f9c233373",
      "sources": {
        "s4531e65b6502": "https://github.com/OWASP/CheatSheetSeries/blob/72865b1e3b5754246a101778dc00b37f9c233373/cheatsheets/Password_Storage_Cheat_Sheet.md#L13"
      }
    }
  },
  "claims": {
    "entrypoints": {"text": "For Traefik v2/v3, web :80 redirects to HTTPS websecure :443 and an ACME resolver obtains/renews certificates.", "components": ["traefik-docs", "traefik-v3"], "sources": ["traefik-docs:scbc0f2135c78", "traefik-v3:s0b6ac3975f40", "traefik-v3:se6cd04436adc"], "status": "REASONED"},
    "acme-storage": {"text": "Persist acme.json across restarts with mode 600 to retain certificates and avoid repeated issuance/rate limits.", "components": ["traefik-docs", "traefik-v3", "traefik-source"], "sources": ["traefik-docs:scbc0f2135c78", "traefik-v3:se6cd04436adc", "traefik-source:s6ac13e6baddc"], "status": "REASONED"},
    "acme-challenges": {"text": "TLS-ALPN requires inbound 443; HTTP-01 uses 80, while DNS supports wildcards without inbound ports.", "components": ["traefik-docs", "traefik-v3"], "sources": ["traefik-docs:scbc0f2135c78", "traefik-v3:se6cd04436adc"], "status": "REASONED"},
    "docker-default": {"text": "Docker discovery defaults exposedByDefault to true; set false and opt each intended container in with traefik.enable=true.", "components": ["docker"], "sources": ["docker:se23fe4fe79fa"], "status": "REASONED"},
    "docker-scope": {"text": "Discovery is daemon-wide, not Compose-project scoped; eligible unlabelled containers get routers unless excluded. Missing usable ports skip service creation.", "components": ["docker"], "sources": ["docker:se23fe4fe79fa"], "status": "REASONED"},
    "docker-socket": {"text": "The Docker socket gives daemon control despite :ro; use a restricted socket proxy to limit API access.", "components": ["docker"], "sources": ["docker:se23fe4fe79fa"], "status": "REASONED"},
    "tls-floor": {"text": "Dynamic default TLS options set minVersion VersionTLS12.", "components": ["traefik-docs", "traefik-v3"], "sources": ["traefik-docs:scbc0f2135c78", "traefik-v3:s53640550c66d"], "status": "REASONED"},
    "route": {"text": "Docker labels select the app host, websecure, letsencrypt resolver and backend port 3000.", "components": ["traefik-docs", "docker"], "sources": ["traefik-docs:scbc0f2135c78", "docker:se23fe4fe79fa"], "status": "REASONED"},
    "backend-isolation": {"text": "Publish only Traefik 80/443, not the app's 3000, to prevent middleware/TLS bypass.", "components": ["docker"], "sources": ["docker:se23fe4fe79fa"], "status": "REASONED"},
    "basic": {"text": "Attach bcrypt basicAuth to the router; Apache httpd 2.4.69 htpasswd -nB defaults to bcrypt cost 5, while -C 12 selects cost 12; OWASP at 72865b1e recommends 10 or more for legacy bcrypt.", "components": ["traefik-docs", "traefik-v3", "httpd-source", "owasp-source"], "sources": ["traefik-docs:scbc0f2135c78", "traefik-v3:s8bce7ead3813", "httpd-source:sf711558bdf3c", "httpd-source:s4aa0f7f341fb", "httpd-source:s4482c55d79a2", "httpd-source:s309ecdd34379", "owasp-source:s4531e65b6502"], "status": "REASONED"},
    "compose-hash": {"text": "Double each dollar sign in Compose hash labels; file-provider hashes need no such escaping.", "components": ["traefik-docs", "traefik-v3"], "sources": ["traefik-docs:scbc0f2135c78", "traefik-v3:s8bce7ead3813"], "status": "REASONED"},
    "file-provider": {"text": "Load dynamic files with providers.file.directory/filename and reference their middleware from Docker as app-auth@file.", "components": ["traefik-docs", "traefik-v3"], "sources": ["traefik-docs:scbc0f2135c78", "traefik-v3:s67a26fc82498"], "status": "REASONED"},
    "mfa": {"text": "Basic is single-factor; use forwardAuth with Authelia/oauth2-proxy or front the site with Cloudflare Access and require MFA in its governing Access setting (policy over application over organization).", "components": ["traefik-docs", "traefik-v3", "cloudflare-source"], "sources": ["traefik-docs:scbc0f2135c78", "traefik-v3:s8a5b3bd688d0", "cloudflare-source:sdcac732541da"], "status": "REASONED"},
    "basicauth-advisory": {"text": "GHSA-6765-c87h-8mrf (low): in Traefik v3.6.11-v3.6.24 and v3.7.0-v3.7.9 a colliding BasicAuth singleflight key could authenticate a request as another user; v3.6.25 and v3.7.10 fix it by keying on user plus password. v3.7.17 also refuses a middleware with no users and checks unknown users against a configured hash. Run v3.7.10+ (v3.6.25+ on 3.6); v3.5.0/v3.7.17 are outside the affected range.", "components": ["traefik-basicauth-source"], "sources": ["traefik-basicauth-source:sd275dbbf08d8", "traefik-basicauth-source:sa3b8ca37a702", "traefik-basicauth-source:s08f357bbcbd2"], "status": "REASONED"},
    "body-limit": {"text": "Attach buffering.maxRequestBodyBytes=10485760 alongside existing auth/routing labels; it bounds accepted body size.", "components": ["middleware"], "sources": ["middleware:sd987195d64dd"], "status": "REASONED"},
    "buffer-storage": {"text": "memRequestBodyBytes defaults to 1048576 and controls the memory-to-disk threshold independently of maximum accepted body size.", "components": ["middleware"], "sources": ["middleware:sd987195d64dd"], "status": "REASONED"},
    "rate-limit": {"text": "average=10 and burst=20 configure a rate cap, per source by default.", "components": ["middleware"], "sources": ["middleware:scf1b1e35ef5d"], "status": "REASONED"},
    "inflight": {"text": "inflightreq.amount=10 bounds concurrent requests; sourceCriterion defaults to request host rather than client, so configure a per-client cap explicitly.", "components": ["middleware"], "sources": ["middleware:sd20dcba7ebca"], "status": "REASONED"},
    "middleware-order": {"text": "Rate/inflight precede auth to count rejected logins: Traefik v3.7.17 BasicAuth returns on failure without calling the next handler; buffering follows admission controls to avoid buffering rejected uploads.", "components": ["traefik-docs", "middleware", "traefik-basicauth-source"], "sources": ["traefik-docs:scbc0f2135c78", "middleware:sd987195d64dd", "middleware:scf1b1e35ef5d", "middleware:sd20dcba7ebca", "traefik-basicauth-source:s47f86b3ccaea"], "status": "REASONED"},
    "dashboard": {"text": "Keep api.insecure and unprotected api@internal routers off public entry points or protect the dashboard with auth.", "components": ["traefik-docs"], "sources": ["traefik-docs:scbc0f2135c78"], "status": "REASONED"},
    "swarm": {"text": "Standalone Docker guidance does not cover Swarm; v3 uses providers.swarm and its separate exposedByDefault also defaults true.", "components": ["swarm"], "sources": ["swarm:s256d46f3f558"], "status": "REASONED"},
    "verify-redirect": {"text": "HTTP should redirect to HTTPS.", "components": ["traefik-docs"], "sources": ["traefik-docs:scbc0f2135c78"], "status": "REASONED", "verify": [1]},
    "verify-auth": {"text": "Unauthenticated HTTPS should return 401 once auth is attached.", "components": ["traefik-docs"], "sources": ["traefik-docs:scbc0f2135c78"], "status": "REASONED", "verify": [1]},
    "verify-size": {"text": "Authenticated 1M must reach the app and 11M return 413; 401/000 invalidate the control. Remove app-body in isolation to rule out backend refusal.", "components": ["middleware", "traefik-docs"], "sources": ["middleware:sd987195d64dd", "traefik-docs:scbc0f2135c78"], "status": "REASONED", "verify": [1]},
    "observed-429": {"text": "The guide records only a 429 response; no limiter attribution or exposed/fixed demonstration is established; recorded on an earlier form of the flood probe, before it took a guarded host and ran inside the first block's single subshell.", "components": ["middleware"], "sources": ["middleware:scf1b1e35ef5d", "middleware:sd20dcba7ebca"], "status": "DEMONSTRATED", "evidence": "A 429 appeared. That is all this shows."},
    "verify-rate": {"text": "Concurrent unauthenticated probes can reach pre-auth limiters; 429 alone cannot distinguish rate, inflight or upstream refusal. Compare each limiter alone against both disabled.", "components": ["middleware", "traefik-basicauth-source"], "sources": ["middleware:scf1b1e35ef5d", "middleware:sd20dcba7ebca", "traefik-basicauth-source:s47f86b3ccaea"], "status": "REASONED", "verify": [1]},
    "verify-isolation": {"text": "Compose ps covers one project; ss misses NAT-only publication without a userland proxy. Neither finds unintended routes through Traefik.", "components": ["docker"], "sources": ["docker:se23fe4fe79fa"], "status": "REASONED", "verify": [1]},
    "verify-acme": {"text": "Inspect ACME startup errors; failed issuance can leave a self-signed TRAEFIK DEFAULT CERT.", "components": ["traefik-docs"], "sources": ["traefik-docs:scbc0f2135c78"], "status": "REASONED", "verify": [1]},
    "canary-route": {"text": "On a disposable deployment, unlabelled traefik/whoami has one HTTP port; use its generated Host rule and plain HTTP even on :443 because the generated router requests no TLS.", "components": ["docker", "traefik-docs"], "sources": ["docker:se23fe4fe79fa", "traefik-docs:scbc0f2135c78"], "status": "REASONED", "verify": [2]},
    "verify-canary": {"text": "Calibrate exposedByDefault true with 200 and the canary Hostname body; false should give 404. Missing discovery/provider also gives 404, unreachable backend 502/504.", "components": ["docker", "curl"], "sources": ["docker:se23fe4fe79fa", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [2]},
    "verify-app-control": {"text": "In the same run, the app must return 401 or known authenticated 200 while the canary gives 404; app 401 proves routing, not proxy-auth attachment. Keep TLS verification.", "components": ["docker", "traefik-docs", "curl"], "sources": ["docker:se23fe4fe79fa", "traefik-docs:scbc0f2135c78", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [3]}
  }
}
````
<!-- version-basis:end -->
