# Server administration panels: Cockpit, Webmin, and Proxmox VE

Cockpit, Webmin, Usermin and Proxmox VE are web consoles for managing servers and virtualization clusters. This guide helps your AI assistant configure them securely, including reach limited to admin networks (access lists and firewall rules on Proxmox clusters) and second factors through Cockpit's PAM stack or Webmin's and Proxmox's settings.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/server-admin-panels.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Cockpit 368, Webmin 2.670, Proxmox VE 9.2 docs 9.2.12, pve-manager 9.2.20, Usermin 2.570, and systemd v262; 3 further sources are pinned to a commit. Metadata reviewed 2026-10-18; documentation checked September 2026. The guide records 38 claims: 4 demonstrated by a check that ran; 34 reasoned from cited sources and any earlier-form run (not a live demonstration of the shipped form).

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

A server administration panel is root on the host behind a login form. Cockpit gives any user who can
escalate with sudo or polkit an administrative session and a terminal. Webmin's packages make the host's
root password a Webmin login with every module, including a root shell. Proxmox VE's web interface is the
whole cluster API, and its `root@pam` user can always log in. All three listen on every interface by
default, none turns on a second factor by default, and none locks out an account after repeated wrong
passwords. Keep them off the public internet: bind them to a management address, allow only management
networks ([cloud-firewalls.md](cloud-firewalls.md), [host.md](host.md)), reach them over a VPN or tunnel
([tunnels.md](tunnels.md)), and turn on each panel's second factor. Versions checked: Cockpit 368, Webmin
2.670 (Usermin 2.570), and Proxmox VE 9.2 (pve-manager 9.2.20, pve-docs 9.2.12;
libpve-http-server-perl 6.0.5 and libpve-common-perl 9.1.21 for the bind and access-list review).

## Cockpit

Cockpit's socket unit listens on a bare port, `ListenStream=9090`. The systemd reference reads a bare
number as a port "to listen on via IPv6", "available via both IPv6 and IPv4 (default)", so it is
reachable on every address. The port cannot be changed in `cockpit.conf`; restrict it with a socket
drop-in, `/etc/systemd/system/cockpit.socket.d/listen.conf`, whose empty `ListenStream=` line resets the
default before the new one:

```ini
[Socket]
ListenStream=
ListenStream=10.0.0.5:9090
FreeBind=yes
```

Apply it with `sudo systemctl daemon-reload` and `sudo systemctl restart cockpit.socket`. The vendor
calls `FreeBind` "highly recommended when defining specific IP addresses".

Cockpit serves HTTP and HTTPS on the same port and redirects HTTP to HTTPS, except from localhost;
`AllowUnencrypted` defaults to false. Without a certificate in `/etc/cockpit/ws-certs.d`, it creates a
self-signed one. Any local account can log in through the `cockpit` PAM stack. Root is refused by a
deny list, `/etc/cockpit/disallowed-users`, which the upstream packages write only on a first install,
and the PAM line uses `onerr=succeed`, so a missing or unreadable file lets root in. A logged-in user
has "exactly the same privileges as if they logged in via SSH", including the terminal, and Cockpit
escalates the session to root "immediately upon login" when the user can already escalate with sudo or
polkit. There is no built-in second factor; use the PAM stack, Kerberos, or client certificates. There
is no lockout either: `MaxStartups` (default 10) limits concurrent login attempts, not attempts over
time. If Cockpit can also reach a private network, the vendor recommends `LoginTo=false`, which "prevents
unauthenticated remote attackers from scanning the internal network".

## Webmin and Usermin

Webmin listens on TCP 10000 and Usermin on 20000. The installer writes no `bind=` line, and without one
miniserv listens on all IPv4 and IPv6 addresses ("Listening on all IPs"). It also writes `listen=10000`
(Usermin `listen=20000`), which opens a UDP socket on every IPv4 address so other Webmin servers can find
this one. The vendor says Webmin "will accept connections from any IP address" by default and advises
limiting access "so that an attacker from outside your network cannot even attempt to login". In
`/etc/webmin/miniserv.conf`, set `bind=` to a management address, delete the `listen=` line if you do
not use server discovery, add `allow=` with your management networks, then run `/etc/webmin/restart`.

On a loopback run of Webmin 2.670's miniserv with `bind=127.0.0.1` and no `listen=` line, its only
socket was TCP `127.0.0.1` on the test port, with no UDP socket.

The deb and RPM packages turn on HTTPS (`ssl=1`) with a self-signed certificate, and create the Webmin
user `root` with `crypt=x`, which means Unix authentication: the host's root password logs in to Webmin
with every module. They also add `sudo=1`, which lets any Unix user whom sudo permits log in "effectively
as root". The Command Shell module runs commands as root by default. Two-factor authentication (TOTP or
Authy) exists but is not configured on install; turn it on and enroll every user. Vendor advisories
record a two-factor bypass through basic authentication (CVE-2026-42210, CVE-2026-56022) in releases
listed under "Webmin prior to 2.641", so run a current release.

The installer sets `blockhost_failures=5` and `blockhost_time=60`, so a host is blocked for 60 seconds
after five failed logins; per-user blocking is not set. That is a rate limit, not a lockout. Failed
HTTP basic-authentication logins are counted only when `passdelay` is set, which the installer also
writes (`passdelay=1`). On the loopback run with those settings, the fifth wrong password was delayed
past a five-second client timeout by miniserv's growing failure delay, and the right password was then
refused with `403` "Access denied for 127.0.0.1". Keep the network allow list as the real control.

## Proxmox VE

`pveproxy` serves the whole Proxmox VE API over HTTPS on 8006, and `spiceproxy` listens on 3128. By
default both "listen on the wildcard address and accept connections from both IPv4 and IPv6 clients"
according to pve-docs 9.2.12. **Implementation qualification:** when creating a new socket without
`LISTEN_IP`, libpve-common-perl 9.1.21 tries `::`, then `0.0.0.0` if that fails, rather than guaranteeing
both families; its restart path can reuse an existing socket. Dual-stack acceptance and the documented
IPv6-only effect of `net.ipv6.bindv6only=1` remain documentation-backed: the socket-library implementation
was not fetched or tested. The fetched files also do not trace PVE::HTTPServer inheritance.
Check the running listeners and each public address as below.
`LISTEN_IP` in `/etc/default/pveproxy` restricts the bind, but the vendor warns that it is "not
recommended" on clustered systems, whose nodes need each other's `pveproxy`, possibly across subnets.
That cluster warning is documentation-backed; this guide advises management-only access lists and
firewall rules. Both daemons read the same file and use its `ALLOW_FROM`, `DENY_FROM` and `POLICY`.
The implementation defaults to `allow`: allow-only matches pass, deny-only matches fail, and clients
matching both lists or neither list follow the policy. Thus an `ALLOW_FROM` list alone restricts
nothing under the default policy; also set `DENY_FROM="all"` (the vendor's example) or `POLICY="deny"`.
This guide's advice is to set one or the other, not both: under `POLICY="deny"` a client that matches
both lists is denied, so adding `DENY_FROM="all"` refuses everyone. `LISTEN_IP` binds `spiceproxy` as
well as `pveproxy`. The Proxmox VE firewall "is completely disabled by default"; when you enable it,
allow 8006, 22 and 3128 from management addresses only.

This source conjunction uses pve-manager 9.2.20, pve-docs 9.2.12, libpve-http-server-perl 6.0.5 and
libpve-common-perl 9.1.21 at the Sources pins. Their changelog entries identify those versions;
pve-manager's runtime dependencies require pve-docs >= 9.2.8, libpve-http-server-perl >= 6.0.3 and
libpve-common-perl >= 9.1.21. This guide's inference is that the selected versions satisfy those
three bounds, not that they establish one installed package set. A host may run a later pve-common;
its installed versions and live behaviour remain unverified. The ACL code agrees with the documented
access table; the wildcard code adds the IPv4 fallback qualification above.

The system's `root` user "can always log in via the Linux PAM realm and is an unconfined administrator",
and the installer sets its password for the web interface. Its node shell opens with
`/bin/login -f root`, without a further password. Two-factor authentication (TOTP, WebAuthn, recovery
keys, and realm-enforced TOTP or YubiKey OTP) is available and must be configured. The only lockout is on
the second factor: eight failed TOTP attempts disable that user's TOTP, and after 100 failed WebAuthn or
recovery-key attempts all second factors are blocked for an hour. For passwords, the API delays every
unauthorized response by three seconds. Each cluster creates its own self-signed CA. API tokens have
separated privileges by default, and cannot reach the VM or node consoles.

## Verify

REASONED: this historical run overview preserves the original authoring record, not a new live comparison; a live Cockpit, Webmin/Usermin or Proxmox VE stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Local marking review ran the listener block through `bash -n` and ShellCheck 0.11.0 with no output, and a `sudo` stub printed `sudo stub: ss -tlnp` and `sudo stub: ss -ulnp`. Those runs covered an earlier form of the listener block, two top-level `ss` commands without a status of their own. The current form, which checks for `ss` before listing, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by local bash -n and stub runs with `ss` present, failing and missing. Exposed listeners are wildcard TCP and Webmin/Usermin discovery UDP; fixed listeners bind management addresses with discovery UDP absent, or, in this guide's assessment, clustered Proxmox retains wildcard TCP behind management-only ACLs and firewall rules. The exposed and fixed listener descriptions are per the guide's cited Cockpit 368 socket unit; Webmin 2.670 miniserv (`bind`, `sockets` and the discovery socket); Webmin 2.670 installer (`listen=`, `blockhost_*`, `passdelay=1`, certificate); Usermin 2.570 installer; and Proxmox VE `pveproxy` (bind, `LISTEN_IP`, access lists) (Proxmox VE 9.2, pve-docs 9.2.12). The guide's cited sources for those descriptions are now supplemented for Proxmox bind and access lists by the source conjunction and implementation qualification above. Two checks here were demonstrated: the Webmin configuration check, whose parser was compared with
Webmin 2.670's own on thirty test files, and the TCP reachability probe, which is the block demonstrated
on loopback in [low-code-builders.md](low-code-builders.md) with this guide's ports. The Webmin parser's
fixture runs and the TCP probe's loopback runs used earlier forms of those blocks, whose guard
refusals ended with status 0; the current forms, whose guard refusals exit with status 2, have had no
demonstration run. Everything else
is reasoned: the authoring host runs neither Cockpit's
systemd socket nor Proxmox VE, and it forbids binding every interface, so no default bind was observed.
Those expected outcomes are REASONED from the cited vendor documentation and source.

REASONED: this TCP and UDP inventory instruction; a live Cockpit, Webmin/Usermin or Proxmox VE stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Local marking review ran the listener block through `bash -n` and ShellCheck 0.11.0 with no output, and a `sudo` stub printed `sudo stub: ss -tlnp` and `sudo stub: ss -ulnp`. Those runs covered an earlier form of the listener block, two top-level `ss` commands without a status of their own. The form before the `ss` presence check passed bash -n and local stub runs; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by local bash -n and stub runs with `ss` present, failing and missing. Exposed listeners are wildcard TCP and Webmin/Usermin discovery UDP; fixed listeners bind management addresses with discovery UDP absent, or, in this guide's assessment, clustered Proxmox retains wildcard TCP behind management-only ACLs and firewall rules. The exposed and fixed listener descriptions are per the guide's cited Cockpit 368 socket unit; Webmin 2.670 miniserv (`bind`, `sockets` and the discovery socket); Webmin 2.670 installer (`listen=`, `blockhost_*`, `passdelay=1`, certificate); Usermin 2.570 installer; and Proxmox VE `pveproxy` (bind, `LISTEN_IP`, access lists) (Proxmox VE 9.2, pve-docs 9.2.12). The guide's cited sources for those descriptions are now supplemented for Proxmox bind and access lists by the source conjunction and implementation qualification above. On the host, list the listeners, TCP and UDP:

REASONED: following block; pinned Cockpit, Webmin/Usermin and Proxmox sources support this inventory. The recorded host lacks Cockpit systemd and Proxmox and forbids wildcard binds; exposed/fixed expectations follow. The cluster exception in this listener interpretation also needs a multi-node Proxmox VE cluster with management networks, access lists and firewall rules, none of which was available. A live Cockpit, Webmin/Usermin or Proxmox VE stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Local marking review ran the listener block through `bash -n` and ShellCheck 0.11.0 with no output, and a `sudo` stub printed `sudo stub: ss -tlnp` and `sudo stub: ss -ulnp`. Those runs covered an earlier form of the listener block, two top-level `ss` commands without a status of their own. The current form, which checks for `ss` before listing, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by local bash -n and stub runs with `ss` present, failing and missing. Exposed listeners are wildcard TCP and Webmin/Usermin discovery UDP; fixed listeners bind management addresses with discovery UDP absent, or, in this guide's assessment, clustered Proxmox retains wildcard TCP behind management-only ACLs and firewall rules. The exposed and fixed listener descriptions are per the guide's cited Cockpit 368 socket unit; Webmin 2.670 miniserv (`bind`, `sockets` and the discovery socket); Webmin 2.670 installer (`listen=`, `blockhost_*`, `passdelay=1`, certificate); Usermin 2.570 installer; and Proxmox VE `pveproxy` (bind, `LISTEN_IP`, access lists) (Proxmox VE 9.2, pve-docs 9.2.12). The guide's cited sources for those descriptions are now supplemented for Proxmox bind and access lists by the source conjunction and implementation qualification above. Exposed, the reasoned expectation is a wildcard address (`*:`, `0.0.0.0:` or `[::]:`) on 9090, 10000, 20000, 8006 and 3128; fixed means a management address only. On a Proxmox VE cluster, where the vendor advises against `LISTEN_IP`, 8006 and 3128 keep their wildcard binds; this guide's assessment is that the fixed state there requires the management-only access lists and firewall below. The new-socket code tries `::` then `0.0.0.0`; dual-stack operation is documentation-backed and must be checked on the host. The block exits 2 if `ss` is not installed, 1 for a wildcard TCP listener on 9090, 10000 or 20000 or any UDP listener on 10000 or 20000, 3 if either `ss` command fails and otherwise 0, and leaves 8006, 3128 and every other listener for you to judge. Where sudoers sets `secure_path`, sudo looks `ss` up in that path instead of your PATH (the guide's cited sudo sudoers manual, secure_path entry), so the `command -v ss` check can refuse although sudo would find `ss`, or pass and then end with status 3 when sudo cannot run it.

```bash
(                                       # one subshell, so one exit status covers both listener lists
  set +e                                # errexit off here, so a failed command is recorded below instead of ending the block
  command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }   # a refusal, status 2, before either list runs, so no part has found anything yet
  set -- 0 "$(if sudo ss -tlnp; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0; a missing ss has already exited 2 above), then the TCP listeners
  set -- "$1" "${2%$'\n'*}" "${2##*$'\n'}"                                         # status, the TCP listener table, then ss's exit status
  printf '%s' "$2"   # 9090 (Cockpit), 10000 (Webmin), 20000 (Usermin), 8006 and 3128 (Proxmox VE): a management address only; Proxmox cluster exception below
  [ "$3" = 0 ] || { echo "sudo ss -tlnp exit $3: the TCP listener list did not print; inconclusive"; set -- 3 "$2" "$3"; }
  if printf '%s' "$2" | awk 'NR > 1 { p = $4; sub(/.*:/, "", p); a = substr($4, 1, length($4) - length(p) - 1); sub(/%.*/, "", a) } NR > 1 && (p == "9090" || p == "10000" || p == "20000") && (a == "*" || a == "0.0.0.0" || a == "[::]") { found = 1 } END { exit !found }'; then
    echo "FINDING: a TCP listener on port 9090, 10000 or 20000 is bound to a wildcard address"; set -- 1 "$2" "$3"
  else
    case "$?" in 1) ;; *) echo "awk could not read the TCP listener list; inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" "$3" ;; esac
  fi
  set -- "$1" "$(if sudo ss -ulnp; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # the status so far, then the UDP listeners
  set -- "$1" "${2%$'\n'*}" "${2##*$'\n'}"                                          # status, the UDP listener table, then ss's exit status
  printf '%s' "$2"   # Webmin's discovery socket on UDP 10000 (Usermin 20000) should be gone
  [ "$3" = 0 ] || { echo "sudo ss -ulnp exit $3: the UDP listener list did not print; inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" "$3"; }
  if printf '%s' "$2" | awk 'NR > 1 && $4 ~ /:(10000|20000)$/ { found = 1 } END { exit !found }'; then
    echo "FINDING: a UDP listener on port 10000 or 20000, the Webmin or Usermin discovery socket, is still open"; set -- 1 "$2" "$3"
  else
    case "$?" in 1) ;; *) echo "awk could not read the UDP listener list; inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" "$3" ;; esac
  fi
  echo "block exit $1; Proxmox VE's 8006 and 3128 and every other listener are not classified, so judge them yourself against the cluster exception below"
  exit "$1"
)
```

REASONED: this file-inspection procedure needs a Webmin host and running miniserv for comparison with sockets; a live Webmin stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Local marking review ran the parser block through `bash -n` and ShellCheck 0.11.0 without output; under `set -u`, placeholder, omitted assignment and marker-only inputs printed the respective substitution, whole-block and value-count refusals. The bash -n, ShellCheck and refusal runs recorded here covered the parser block in an earlier form, whose guard refusals and result arms ended with status 0, and were not repeated on the current form, which exits 2 for a guard refusal, 1 for a file that prints `NO effective bind=`, a `listen=` line or `NO allow=` and 3 for a failed parse. The current form passed bash -n and local stub runs and the gate suite's bash -n and ShellCheck 0.11.0. The extracted Perl program on local exposed and fixed fixtures printed `NO effective bind=: every address`, discovery and `NO allow=`, versus `bind=10.0.0.5`, `no UDP discovery socket` and `allow=10.0.0.0/24`; extra-listener/deny/sudo and repeated-bind fixtures printed the corresponding settings and last bind. Those Perl fixture runs used an earlier form of the program, whose result arms ended with status 0; in local runs of the current form, which exits 1 after printing an exposed setting, exposed and fixed fixtures printed those lines and ended with status 1 and 0. These are file results only; on the Webmin host, exposed miniserv listens on every address with discovery UDP open and offers its login to any client; fixed miniserv listens on the management address only with no discovery socket, a management-network client reaches the login, and from a client outside the allow= networks the connection fails or miniserv refuses it. The exposed and fixed Webmin host behaviours are per the guide's cited Webmin 2.670 miniserv (`bind`, `sockets` and the discovery socket) and Webmin 2.670 sudo login, configuration parser (`read_config_file`), allow and deny lists, and basic-authentication failure counting (`passdelay`). On a Webmin host, check the configuration miniserv reads when it starts. The block parses the file
with a copy of miniserv's own `read_config_file` (a line starting with `#` is a comment, spaces around
the name and the value are trimmed, and the last occurrence of a setting wins), then applies
miniserv's rules: `bind=*`, `bind=0`, `bind=0.0.0.0`, `bind=::`, or an empty or missing `bind=` means
every address. The block reads the value with the system's numeric address parser, `inet_pton`, which
never looks up a name: an all-zero IPv4 or IPv6 address is reported as every address, any other
IPv4 or IPv6 address the parser accepts is printed as it is, except an IPv4-mapped IPv6 address, and
every other value is flagged for checking with `ss`.
The `sockets=` setting adds listeners; a `listen=` value other than empty or `0` opens the UDP discovery socket;
and an empty `allow=` lets every client address try to log in, except those a `deny=` list refuses. The block describes the file, not the running process:
`ss` above is the authority for what is listening now, and a change takes effect at
`/etc/webmin/restart`. Substitute the file path inside the single quotes (the package default is
`/etc/webmin/miniserv.conf`), and paste the whole block.

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_MINISERV_CONF'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not checking"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not checking"; exit 2; }
  case "$1" in *REPLACE_WITH_*|"") echo "substitute your file on the set -- line above; not checking"; exit 2 ;; esac
  { [ -f "$1" ] && [ -r "$1" ]; } || { echo "cannot read $1 as a regular file (try sudo); not checked"; exit 2; }
  command -v perl >/dev/null || { echo "perl is not installed here; not checking"; exit 2; }
  set -- "$1" 0                         # the file, then the block's status so far: 1 for a finding, 3 for a failed parse, otherwise 0
  # shellcheck disable=SC2016  # the single-quoted Perl program is meant to expand its own variables
  if perl -e '
    eval {
      require Socket;
      open(CONF, "<", $ARGV[0]) || die "cannot open the file\n";
      while (<CONF>) {
        s/\r|\n//g;
        if (/^#/ || !/\S/) { next; }
        /^([^=]+)=(.*)$/;
        $name = $1; $val = $2;
        $name =~ s/^\s+//g; $name =~ s/\s+$//g;
        $val =~ s/^\s+//g; $val =~ s/\s+$//g;
        $rv{$name} = $val;
      }
      close(CONF);
      $bind = $rv{"bind"}; $bind = "" if ($bind eq "*");
      $v4 = $bind eq "" ? undef : Socket::inet_pton(Socket::AF_INET(), $bind);
      $v6 = (defined($v4) || $bind !~ /:/) ? undef : Socket::inet_pton(Socket::AF_INET6(), $bind);
      if (!$bind || (defined($v4) && $v4 eq "\0" x 4) || (defined($v6) && $v6 eq "\0" x 16)) { print "NO effective bind=: every address\n"; $found = 1; }
      elsif (defined($v4) || (defined($v6) && substr($v6, 0, 12) ne ("\0" x 10) . "\xff\xff")) { print "bind=$bind\n"; }
      else { print "bind=$bind: not a plain IPv4 or IPv6 address; check with ss what miniserv binds\n"; }
      print "sockets=$rv{sockets}: extra listeners, possibly on every address; check ss\n" if ($rv{"sockets"} =~ /\S/);
      print $rv{"listen"} ? "listen=$rv{listen}: UDP discovery socket on every IPv4 address\n" : "no UDP discovery socket\n";
      $found = 1 if ($rv{"listen"});
      @allow = split(/\s+/, $rv{"allow"});
      @deny = split(/\s+/, $rv{"deny"});
      print "deny=@deny\n" if (@deny);
      print @allow ? "allow=@allow\n" : @deny ? "NO allow=: any client address not on deny= may try to log in\n" : "NO allow=: any client address may try to log in\n";
      $found = 1 if (!@allow);
      print "sudo=$rv{sudo}: Unix users whom sudo permits can log in as root\n" if ($rv{"sudo"});
      1;
    } or do { print STDERR "parse failed: $@"; exit 3; };
    exit($found ? 1 : 0);
  ' "$1"; then :; else
    case "$?" in
      1) set -- "$1" 1 ;;
      *) echo "could not read $1; not checked"; set -- "$1" 3 ;;
    esac
  fi
  echo "block exit $2; the allow= and deny= entries as written, any sockets= or sudo= line and any bind= value flagged for ss are not classified, so judge them yourself"
  exit "$2"
)
```

DEMONSTRATED: preceding block; the parser matched Webmin 2.670 on thirty fixtures and printed the recorded outcomes below. The thirty-file fixture runs used an earlier form of the block, whose guard refusals and result arms ended with status 0; the current form exits 2 for a guard refusal, 1 for a file that prints `NO effective bind=`, a `listen=` line or `NO allow=`, and 3 for a failed parse, including a Perl error. The current form passed bash -n and local stub runs, and the repository's gate suite runs ShellCheck 0.11.0 over every block; no demonstration was re-run on it. This demonstrates file inspection, not running sockets or network isolation. Exposed: "NO effective bind=", a `listen=` line and "NO allow=". Fixed: a management address on
`bind=`, "no UDP discovery socket" and only your management networks on `allow=`; the block prints
the lists as written, so check each entry. A `sockets=` line means more listeners; check each with
`ss`. This was demonstrated on thirty test files: the loopback run's configuration, its
exposed variant, a repeated `bind=` whose last value is `*`, `bind=0.0.0.0`, `bind=::`,
`bind=0:0:0:0:0:0:0:0`, four IPv6 addresses printed as they are (`2001:db8::5`,
`0:0:0:0:ffff:0:0:1`, `::ffff:0` and `64:ff9b::10.0.0.5`), fourteen values flagged for `ss`, and
six other files. The fourteen values flagged for `ss` were `0x0`, `0x00000000`,
`0x0a000005`, `010.0.0.5`, `cafe`, `0 10.0.0.5`, `::ffff:0:0`, `::ffff:10.0.0.5`, `1::2::3`, `a:b:c`,
`12345::1`, `1:2:3`, `:::1` and `2001:db8:5`. The thirty test files included six other files,
with spaced settings, commented settings, `bind=0` with
`listen=0` and an empty `allow=`, an empty `allow=` with `deny=127.0.0.1`, CRLF line endings with
`sockets=*:10001`, and a line without `=`. On each, the copy's parsed values matched Webmin 2.670's own `read_config_file` run on
the same file, and the block printed the outcomes above; it reported an unreadable path as not
checked.

REASONED: this Cockpit socket and root-deny inspection needs a Cockpit systemd/PAM host; a live Cockpit stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Local marking review used a `systemctl` stub printing `[Socket]`, empty `ListenStream=` and `ListenStream=10.0.0.5:9090`; the `sudo` stub printed `sudo stub: cat /etc/cockpit/disallowed-users`, not file contents. The expected bare-port exposure versus reset/private bind and missing-file root access versus a root deny entry follow per the guide's cited Cockpit 368 socket unit; systemd v262 socket unit reference (bare port); Cockpit 368 listening address and port; and Cockpit 368 PAM stack and root deny list. On a Cockpit host, reasoned: `systemctl cat cockpit.socket` shows the effective listeners; exposed is a
bare `ListenStream=9090`, fixed is the drop-in's empty `ListenStream=` followed by an address and port.
`sudo cat /etc/cockpit/disallowed-users` should list `root`; a missing file lets root log in.

REASONED: this Proxmox bind, ACL, firewall and second-factor inspection needs a Proxmox node, cluster inventory and administrative web-interface access; a live Proxmox VE stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Local marking review ran the stated grep expression on scratch files: an empty fixture exited 1 without output, and a fixed fixture exited 0 printing `ALLOW_FROM="10.0.0.0/24"` and `DENY_FROM="all"`; a `pve-firewall` stub printed `Status: enabled/running (stub)`. Expected exposed wildcard/default-allow access and disabled firewall versus management-only bind or ACLs, enabled firewall with management-only rules, and an enrolled second factor for every administrator are this guide's assessment based on the source conjunction and implementation qualification above and the guide's cited Proxmox VE sources. Those cited Proxmox VE sources are Proxmox VE `pveproxy` (bind, `LISTEN_IP`, access lists) (Proxmox VE 9.2, pve-docs 9.2.12), Proxmox VE firewall (Proxmox VE 9.2, pve-docs 9.2.12) and Proxmox VE user management (Proxmox VE 9.2, pve-docs 9.2.12; root@pam, two-factor, lockout and API tokens). On a Proxmox VE node, reasoned: `grep -E '^(LISTEN_IP|ALLOW_FROM|DENY_FROM|POLICY)=' /etc/default/pveproxy`
reports that the file does not exist (a diagnostic and a non-zero exit) if it is absent, or
prints nothing if the file exists but contains none of those lines, consistent with the wildcard bind and `allow`
policy in the pinned code. This grep is only a shortlist: the reader sources the file with Bash, so
inspect the complete file with `cat /etc/default/pveproxy` for assignments the pattern misses, shell
logic and sourced files; no grep output alone does not establish effective settings. Confirm both
daemons' running listeners with `ss` above. This guide's assessment of fixed is `LISTEN_IP` set to a
management address on a single node, or `ALLOW_FROM` with your management networks together with
`DENY_FROM="all"` or `POLICY="deny"`; this guide advises one of the two, not both. An `ALLOW_FROM`
line alone is not fixed: under `allow`, a client matching neither list is allowed; under `deny`, a
client matching both lists is denied (the pinned access check agrees with the vendor's access table).
`pve-firewall status` prints whether the firewall is enabled and running. Exposed is disabled, the
default; fixed is enabled and running, with rules that allow 8006, 22 and 3128 only from management
addresses, which you confirm in the datacenter and node firewall rules in the web interface. In the web interface, check
that every administrative user, `root@pam` included, has a second factor.

REASONED: this external-vantage procedure needs each server public address, a known-open control port and a host outside the allowed management network; a live Cockpit, Webmin/Usermin or Proxmox VE stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Local marking review ran the TCP block through `bash -n` and ShellCheck 0.11.0 with no output; under `set -u`, placeholder, omitted assignment and marker-only inputs printed the respective substitution, whole-block and value-count refusals. A `timeout` stub returning 124 for the control printed `control 198.51.100.7:22 did not connect (timeout stub invoked); not probing`. The bash -n, ShellCheck and stub runs recorded here covered the TCP block in an earlier form, whose guard refusals, failed control and result arms ended with status 0, and were not repeated on the current form, which exits 2 for a guard refusal, 3 for a failed control, and after its probes 1 if any port connected, otherwise 3 if any port was inconclusive, otherwise 0. The current form passed bash -n and local stub runs and the gate suite's bash -n and ShellCheck 0.11.0. Expected exposed TCP connects; fixed isolation may refuse or time out, which is only consistent with isolation after the positive control and server inventory checks. The exposed and fixed TCP expectations and that consistency qualification are per the guide's cited Cockpit 368 socket unit; Webmin 2.670 miniserv (`bind`, `sockets` and the discovery socket); Usermin 2.570 installer; and Proxmox VE `pveproxy` (bind, `LISTEN_IP`, access lists) (Proxmox VE 9.2, pve-docs 9.2.12). Finally, from a host that should not have access, try a TCP connection to each panel port. The block
takes one IP address rather than a host name, so that a name with both IPv4 and IPv6 addresses cannot
hide one behind a timeout on the other: run it once for each public address of the server. It also
takes a port you know is open on that address from this host (for example SSH on 22) as the positive
control, and stops if the control does not connect. Substitute both inside the single quotes.

DEMONSTRATED: following block; recorded reuse of the low-code-builders.md loopback probe with these ports includes the mapped-address connection below. This is probe evidence only; live panel reachability and firewall isolation remain reasoned. The reused loopback probe runs used an earlier form of the block, whose guard refusals, failed control and result arms ended with status 0; the current form exits 2 for a guard refusal, 3 for a failed control, and after its probes 1 if any port connected, otherwise 3 if any port was inconclusive, otherwise 0, and it holds its values in positional parameters. The current form passed bash -n and local stub runs, and the repository's gate suite runs ShellCheck 0.11.0 over every block; no demonstration was re-run on it.

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_ONE_IP_ADDRESS' 'REPLACE_WITH_A_KNOWN_OPEN_PORT'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in *REPLACE_WITH_*|"") echo "substitute one IP address on the set -- line above; not probing"; exit 2 ;; esac
  case "$1" in 0.0.0.0) echo "$1 reaches this host itself; give the public address of the service; not probing"; exit 2 ;; esac
  set -- "$1" "$2" '^((25[012345]|2[01234][0123456789]|1[0123456789][0123456789]|[123456789]?[0123456789])[.]){3}(25[012345]|2[01234][0123456789]|1[0123456789][0123456789]|[123456789]?[0123456789])$'   # the address, the control port, then the IPv4 pattern, held here rather than in a named variable
  case "$1" in
    *:*:*)
      case "$1" in *[!0123456789ABCDEFabcdef.:]*) echo "$1 is not an IPv6 address; not probing"; exit 2 ;; esac
      case "$1" in *.*) echo "give the IPv4 address itself rather than $1; not probing"; exit 2 ;; esac
      case "$1" in *[!0:]*) ;; *) echo "$1 is all zeros (this host itself, or not an address); give the public address of the service; not probing"; exit 2 ;; esac ;;
    *) [[ $1 =~ $3 ]] || { echo "give one IPv4 address (four numbers, 0 to 255, joined by dots) or one IPv6 address, with no host name, port or brackets; not probing"; exit 2; } ;;
  esac
  case "$2" in *[!0123456789]*|"") echo "substitute a known-open control port on the set -- line above; not probing"; exit 2 ;; esac
  { [ "$2" -ge 1 ] && [ "$2" -le 65535 ]; } 2>/dev/null || { echo "the control port must be 1 to 65535; not probing"; exit 2; }
  command -v timeout >/dev/null || { echo "timeout is not installed here; not probing"; exit 2; }
  # shellcheck disable=SC2016  # the single-quoted script is meant to expand $1 and $2 in the child shell
  set -- "$1" "$2" "$(if LC_ALL=C timeout 5 bash -c ': > "/dev/tcp/$1/$2"' probe "$1" "$2" 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "${3%$'\n'*}" "${3##*$'\n'}"   # the address, the control port, the control's messages, then its exit status
  set -- "$1" "$2" "${3%$'\n'}" "$4"              # the messages without their final line break, as a plain capture prints them
  [ "$4" = 0 ] || { echo "control $1:$2 did not connect (${3:-timed out}); not probing"; exit 3; }
  echo "control $1:$2 connected"
  set -- "$1" 0 9090 10000 20000 8006 3128   # the address, the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0), then the ports still to probe
  while [ "$#" -gt 2 ]; do
    # shellcheck disable=SC2016  # the single-quoted script is meant to expand $1 and $2 in the child shell
    set -- "$(if LC_ALL=C timeout 5 bash -c ': > "/dev/tcp/$1/$2"' probe "$1" "$3" 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)" "$@"
    set -- "${1##*$'\n'}" "${1%$'\n'*}" "${@:2}"   # this port's exit status, its messages, the address, the status so far, this port, then the ports after it
    set -- "$1" "${2%$'\n'}" "${@:3}"             # the messages without their final line break
    case "$1:$2" in
      0:*) echo "$3:$5 connected: reachable from this host"; set -- "$1" "$2" "$3" 1 "${@:5}" ;;
      124:*) echo "$3:$5 timed out from this host" ;;
      *"Connection refused"*) echo "$3:$5 refused from this host" ;;
      *) echo "$3:$5 inconclusive (not a connection, refusal or timeout): ${2:-no message}"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 "${@:5}" ;;
    esac
    set -- "$3" "$4" "${@:6}"                     # the address, the status so far, then the ports still to probe
  done
  exit "$2"
)
```

DEMONSTRATED: preceding block; the loopback connection recorded below came from low-code-builders.md's earlier form of this probe, whose guard refusals, failed control and result arms ended with status 0. Exposed, a panel port reports "connected"; a transparent proxy on the probing host's network can
also complete the handshake, so confirm a surprising "connected" with `ss` on the server. "refused"
and "timed out" show only that this host could not reach the port: a firewall in front of the server
produces either, but so can filtering on the probing host's own network, and the control proves only
its own port. Treat them as consistent with fixed, and take `ss` on the server as the authority; the
probe does not test Webmin's UDP discovery socket, which only `ss -ulnp` shows. "inconclusive" is any
other result and says nothing about the port. The block is the one demonstrated in
[low-code-builders.md](low-code-builders.md) with only the port list changed; that guide lists the
values it was measured to refuse. It refuses `0.0.0.0`, IPv6 values made only of zeros and colons,
and IPv6 values containing a dot, but not every value that reaches the probing host: loopback
addresses pass, and hex spellings such as `::ffff:0:0` connected to a listener bound to 127.0.0.1, so
give the server's public address. A "connected" on a port you did not mean to expose is the finding.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- Cockpit 368 socket unit: https://github.com/cockpit-project/cockpit/blob/368/src/systemd/cockpit.socket.in
- Cockpit 368 listening address and port: https://github.com/cockpit-project/cockpit/blob/368/doc/modules/guide/pages/listen.adoc
- Cockpit 368 HTTPS and certificates: https://github.com/cockpit-project/cockpit/blob/368/doc/modules/guide/pages/https.adoc
- Cockpit 368 `cockpit.conf` reference (`AllowUnencrypted`, `MaxStartups`, `LoginTo`): https://github.com/cockpit-project/cockpit/blob/368/doc/modules/man/pages/cockpit.conf.5.adoc
- Cockpit 368 authentication: https://github.com/cockpit-project/cockpit/blob/368/doc/modules/guide/pages/authentication.adoc
- Cockpit 368 privileges: https://github.com/cockpit-project/cockpit/blob/368/doc/modules/guide/pages/privileges.adoc
- Cockpit 368 PAM stack and root deny list: https://github.com/cockpit-project/cockpit/blob/368/tools/cockpit.pam and https://github.com/cockpit-project/cockpit/blob/368/tools/cockpit.spec
- systemd v262 socket unit reference (bare port): https://github.com/systemd/systemd/blob/v262/man/systemd.socket.xml
- Webmin 2.670 installer (`listen=`, `blockhost_*`, `passdelay=1`, certificate): https://github.com/webmin/webmin/blob/2.670/setup.sh
- Webmin 2.670 miniserv (`bind`, `sockets` and the discovery socket): https://github.com/webmin/webmin/blob/2.670/miniserv.pl
- Webmin 2.670 deb and RPM package builders (`crypt=x`, `ssl=1`, `sudo=1`): https://github.com/webmin/webmin/blob/2.670/makedebian.pl and https://github.com/webmin/webmin/blob/2.670/makerpm.pl
- Webmin 2.670 sudo login, configuration parser (`read_config_file`), allow and deny lists, and basic-authentication failure counting (`passdelay`): https://github.com/webmin/webmin/blob/2.670/miniserv-lib.pl
- Webmin 2.670 Command Shell default ACL: https://github.com/webmin/webmin/blob/2.670/shell/defaultacl
- Webmin 2.670 two-factor providers: https://github.com/webmin/webmin/blob/2.670/webmin/twofactor-funcs-lib.pl
- Webmin documentation (configuration, security advisories): https://github.com/webmin/webmin.com/blob/8ceae26c5a074053905cbcc6c0053be573633f3a/content/docs/Modules/webmin-configuration.md and https://github.com/webmin/webmin.com/blob/8ceae26c5a074053905cbcc6c0053be573633f3a/content/security.md
- Usermin 2.570 installer: https://github.com/webmin/usermin/blob/2.570/setup.sh
- Proxmox VE `pveproxy` documentation (Proxmox VE 9.2, pve-docs 9.2.12), API paragraph lines 26 to 28, access lists lines 38 to 60, listening-address section lines 66 to 114 (checked October 2026): https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=pveproxy.adoc
- Proxmox VE user management (Proxmox VE 9.2, pve-docs 9.2.12; root@pam, two-factor, lockout and API tokens): https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=pveum.adoc
- Proxmox VE firewall (Proxmox VE 9.2, pve-docs 9.2.12): https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=pve-firewall.adoc
- Proxmox VE certificates (Proxmox VE 9.2, pve-docs 9.2.12): https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=certificate-management.adoc
- Proxmox VE node shell (`/bin/login -f root`) (pve-manager 9.2.20): https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=PVE/API2/Nodes.pm
- Proxmox VE HTTP server (three-second delay on unauthorized responses; libpve-http-server-perl 6.0.5 at 5119ff9bec08c69584c0c98bea3edd0098179e5f); access check lines 1868 to 1908, default policy line 2111 (checked October 2026): https://git.proxmox.com/?p=pve-http-server.git;a=blob_plain;hb=5119ff9bec08c69584c0c98bea3edd0098179e5f;f=src/PVE/APIServer/AnyEvent.pm
- pve-manager 9.2.20 version, line 1 (checked October 2026): https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=debian/changelog
- pve-docs 9.2.12 version, line 1 (checked October 2026): https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=debian/changelog
- libpve-http-server-perl 6.0.5 version, line 1, at 5119ff9bec08c69584c0c98bea3edd0098179e5f (checked October 2026): https://git.proxmox.com/?p=pve-http-server.git;a=blob_plain;hb=5119ff9bec08c69584c0c98bea3edd0098179e5f;f=debian/changelog
- libpve-common-perl 9.1.21 version, line 1, at 5054082fe492429fc37574985c2ca812af9a3125 (checked October 2026): https://git.proxmox.com/?p=pve-common.git;a=blob_plain;hb=5054082fe492429fc37574985c2ca812af9a3125;f=debian/changelog
- pve-manager 9.2.20 runtime dependency entries, lines 65 to 67 and 91 (checked October 2026): https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=debian/control
- pve-manager 9.2.20 pveproxy name, configuration, bind and ACLs, lines 41, 66 to 67, 75 to 76 and 98 to 137 (checked October 2026): https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=PVE/Service/pveproxy.pm
- pve-manager 9.2.20 spiceproxy shared configuration, bind and ACLs, lines 31 to 59 (checked October 2026): https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=PVE/Service/spiceproxy.pm
- libpve-http-server-perl 6.0.5 configuration reader, lines 10 to 97, at 5119ff9bec08c69584c0c98bea3edd0098179e5f (checked October 2026): https://git.proxmox.com/?p=pve-http-server.git;a=blob_plain;hb=5119ff9bec08c69584c0c98bea3edd0098179e5f;f=src/PVE/APIServer/Utils.pm
- libpve-common-perl 9.1.21 socket creation and reuse, lines 803 to 854, at 5054082fe492429fc37574985c2ca812af9a3125 (checked October 2026): https://git.proxmox.com/?p=pve-common.git;a=blob_plain;hb=5054082fe492429fc37574985c2ca812af9a3125;f=src/PVE/Daemon.pm
- sudo SUDO_1_9_16p2 sudoers manual, secure_path (checked October 2026): https://github.com/sudo-project/sudo/blob/SUDO_1_9_16p2/docs/sudoers.man.in#L5650-L5655


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- cockpit: Cockpit (368)
- webmin: Webmin (2.670)
- pve-docs: Proxmox VE 9.2 docs (9.2.12)
- pve-manager: pve-manager (9.2.20)
- webmin-docs: Webmin docs (8ceae26c5a074053905cbcc6c0053be573633f3a)
- pve-http: Proxmox HTTP server (5119ff9bec08c69584c0c98bea3edd0098179e5f)
- pve-common: libpve-common-perl 9.1.21 (5054082fe492429fc37574985c2ca812af9a3125)
- usermin: Usermin (2.570)
- systemd: systemd (v262)

Claims (full source mapping in the JSON block below):

- private (REASONED; cockpit, webmin-docs, pve-docs): Keep root-capable panels off the internet, bound/restricted to management networks with private access and a second factor.
- cockpit-bind (REASONED; cockpit, systemd): Bare ListenStream=9090 binds IPv6 and, by default, IPv4 wildcard addresses.
- cockpit-dropin (REASONED; cockpit): Use a socket drop-in, not cockpit.conf: reset ListenStream, set 10.0.0.5:9090 and FreeBind=yes, then daemon-reload/restart.
- cockpit-tls (REASONED; cockpit): One port serves HTTP/HTTPS, redirecting HTTP except localhost; AllowUnencrypted defaults false and missing certificates cause self-signed creation.
- cockpit-pam (REASONED; cockpit): Local accounts use Cockpit PAM with normal SSH-equivalent privileges.
- cockpit-root (REASONED; cockpit): First-install packages write root to disallowed-users; onerr=succeed permits root if that file is missing/unreadable.
- cockpit-escalation (REASONED; cockpit): Users allowed sudo/polkit escalation get an immediately elevated session and terminal.
- cockpit-mfa (REASONED; cockpit): No built-in second factor; use PAM, Kerberos or client certificates.
- cockpit-rate (REASONED; cockpit): MaxStartups defaults to 10 concurrent attempts, not repeated-password lockout.
- cockpit-loginto (REASONED; cockpit): Set LoginTo=false to prevent unauthenticated scanning of reachable private networks.
- webmin-bind (REASONED; webmin, usermin): Webmin/Usermin TCP ports are 10000/20000; omitted bind makes miniserv listen on all IPv4/IPv6 addresses.
- webmin-discovery (REASONED; webmin, usermin): Installed listen=10000/20000 opens discovery UDP on every IPv4 address; delete when unused.
- webmin-access (REASONED; webmin, webmin-docs): Set management bind and allow networks, then restart; empty allow admits all except denied clients.
- webmin-tls (REASONED; webmin): Deb/RPM packages enable ssl=1 with a self-signed certificate.
- webmin-root (REASONED; webmin): Installed root crypt=x accepts the Unix root password with all modules; Command Shell defaults to root.
- webmin-sudo (REASONED; webmin): Installed sudo=1 lets sudo-permitted Unix users log in effectively as root.
- webmin-mfa (REASONED; webmin): TOTP/Authy exists but is not configured at install; enable and enrol every user.
- webmin-advisories (REASONED; webmin-docs): Advisories list Basic-auth MFA bypasses CVE-2026-42210/CVE-2026-56022 under Webmin prior to 2.641; use a current release.
- webmin-rate (REASONED; webmin): Defaults blockhost_failures=5/blockhost_time=60 block a host for 60 seconds, not a user lockout; Basic-auth failures count only with installed passdelay=1.
- pve-bind (REASONED; pve-docs, pve-manager, pve-http, pve-common): pveproxy HTTPS API 8006 and spiceproxy 3128 share LISTEN_IP in /etc/default/pveproxy; new sockets without it try :: then 0.0.0.0. Dual-stack defaults and bindv6only=1 effects are documentation-backed; socket-library behaviour and installed versions remain unverified.
- pve-cluster (REASONED; pve-docs): The vendor warns against LISTEN_IP on clustered systems: nodes need peer pveproxy access, possibly across subnets. This guide advises management-only ACLs and firewall rules.
- pve-acl (REASONED; pve-docs, pve-manager, pve-http): Both daemons share ALLOW_FROM/DENY_FROM/POLICY; default allow admits unmatched clients and dual matches. Deny rejects both cases. This guide advises ALLOW_FROM with DENY_FROM=all or POLICY=deny, one of the two, not both, because deny plus DENY_FROM=all refuses everyone.
- pve-firewall (REASONED; pve-docs): Firewall defaults disabled; enable and restrict 8006/22/3128 to management addresses.
- pve-root (REASONED; pve-docs): root@pam can always log in as unconfined admin; installer sets the web-interface root password.
- pve-shell (REASONED; pve-manager): Node shell opens /bin/login -f root without another password.
- pve-mfa (REASONED; pve-docs): Configure TOTP, WebAuthn, recovery keys or realm-enforced TOTP/YubiKey OTP; no default second factor.
- pve-lockout (REASONED; pve-docs): Eight TOTP failures disable TOTP; 100 WebAuthn/recovery-key failures block all factors for an hour. These are second-factor lockouts.
- pve-password-delay (REASONED; pve-http): Unauthorized API responses delay three seconds; this is not password lockout.
- pve-certificates (REASONED; pve-docs): Each cluster creates its own self-signed CA.
- pve-tokens (REASONED; pve-docs): API tokens default to separated privileges and cannot access VM/node consoles.
- verify-cockpit (REASONED; cockpit): Inspect effective socket reset/address and root deny file; bare port or missing deny file exposes documented defaults.
- verify-pve (REASONED; pve-docs, pve-manager, pve-http, pve-common): Inspect the shared LISTEN_IP/ACL configuration for both daemons, enabled/running firewall and management-only rules, and every admin's second factor including root@pam. This guide assesses management bind on a single node or management ALLOW_FROM with DENY_FROM=all or POLICY=deny, one of the two, not both, as fixed; grep alone does not establish effective settings.
- verify-external (REASONED; cockpit, webmin, usermin, pve-docs): Probe each public IP with a reachable control; refusal/timeout is only consistent with isolation. TCP does not test Webmin UDP.
- webmin-loopback (DEMONSTRATED; webmin): Loopback bind with no listen line produced one TCP socket and no UDP.
- webmin-rate-run (DEMONSTRATED; webmin): Fifth wrong password exceeded a five-second timeout; then even the right password received host-block 403.
- verify-listeners (REASONED; cockpit, webmin, usermin, pve-docs, pve-manager, pve-http, pve-common): Expect management TCP binds and no discovery UDP; this guide assesses clustered Proxmox wildcards as fixed only with management-only ACLs and firewall rules. Pinned new-socket code tries :: then 0.0.0.0; dual-stack operation remains documentation-backed and must be checked on the host.
- verify-webmin-parser (DEMONSTRATED; webmin): Thirty fixtures matched miniserv parsing and bind/sockets/discovery/ACL outputs; unreadable paths were not checked. File inspection is not running-state proof. Runs covered an earlier form whose result arms ended with status 0; the current form was not re-run.
- verify-tcp-loopback (DEMONSTRATED; cockpit, webmin, usermin, pve-docs): Copied probe has recorded loopback provenance, not live panel-isolation evidence; loopback and mapped hex addresses pass its guard. Runs covered an earlier form whose control and result arms ended with status 0; the current form was not re-run.

````json
{
  "schema": 1,
  "checked": "2026-10-18",
  "documentation_checked": "2026-09",
  "body_sha256": "bac493718a70fb97fcc2700e9b036adff9dd79c8632a4f386b22f18b53730855",
  "components": {
    "cockpit": {
      "name": "Cockpit",
      "basis": "368",
      "sources": {
        "sc42ba09017c7": "https://github.com/cockpit-project/cockpit/blob/368/src/systemd/cockpit.socket.in",
        "s0c1e0db624a4": "https://github.com/cockpit-project/cockpit/blob/368/doc/modules/guide/pages/listen.adoc",
        "sd0cb4ea3db56": "https://github.com/cockpit-project/cockpit/blob/368/doc/modules/guide/pages/https.adoc",
        "sf157ab3a6f47": "https://github.com/cockpit-project/cockpit/blob/368/doc/modules/man/pages/cockpit.conf.5.adoc",
        "s48ebdec28e10": "https://github.com/cockpit-project/cockpit/blob/368/doc/modules/guide/pages/authentication.adoc",
        "s2432e599485f": "https://github.com/cockpit-project/cockpit/blob/368/doc/modules/guide/pages/privileges.adoc",
        "sbdcd6e74a0c7": "https://github.com/cockpit-project/cockpit/blob/368/tools/cockpit.pam",
        "sc20103cfb39b": "https://github.com/cockpit-project/cockpit/blob/368/tools/cockpit.spec"
      }
    },
    "webmin": {
      "name": "Webmin",
      "basis": "2.670",
      "sources": {
        "sa4f7ac343e85": "https://github.com/webmin/webmin/blob/2.670/setup.sh",
        "sb8fec2baa0f2": "https://github.com/webmin/webmin/blob/2.670/miniserv.pl",
        "sdd465cac1ff8": "https://github.com/webmin/webmin/blob/2.670/makedebian.pl",
        "s9ecba8f15014": "https://github.com/webmin/webmin/blob/2.670/makerpm.pl",
        "sdb2ef2bf9978": "https://github.com/webmin/webmin/blob/2.670/miniserv-lib.pl",
        "s1a1dbd21dddd": "https://github.com/webmin/webmin/blob/2.670/shell/defaultacl",
        "s2f3504ad1328": "https://github.com/webmin/webmin/blob/2.670/webmin/twofactor-funcs-lib.pl"
      }
    },
    "pve-docs": {
      "name": "Proxmox VE 9.2 docs",
      "basis": "9.2.12",
      "sources": {
        "s8538bab3d3fc": "https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=pveproxy.adoc",
        "sdbc681682e8f": "https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=pveum.adoc",
        "sc6bbbfe64d09": "https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=pve-firewall.adoc",
        "s31f242f10eaa": "https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=certificate-management.adoc",
        "s954445cf4e14": "https://git.proxmox.com/?p=pve-docs.git;a=blob_plain;hb=9370638116430c4b1ccb9707b5716eaad7c7c9d3;f=debian/changelog"
      }
    },
    "pve-manager": {
      "name": "pve-manager",
      "basis": "9.2.20",
      "sources": {
        "se4c11b901cf8": "https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=PVE/API2/Nodes.pm",
        "s1507ce3e40b8": "https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=debian/changelog",
        "s67c1a8621e22": "https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=debian/control",
        "sb7f08e4e98ab": "https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=PVE/Service/pveproxy.pm",
        "s0b79b5bbd95f": "https://git.proxmox.com/?p=pve-manager.git;a=blob_plain;hb=49318c671b82f31e6b273b79447526161739b97a;f=PVE/Service/spiceproxy.pm"
      }
    },
    "webmin-docs": {
      "name": "Webmin docs",
      "basis": "8ceae26c5a074053905cbcc6c0053be573633f3a",
      "sources": {
        "s7a91f9f23044": "https://github.com/webmin/webmin.com/blob/8ceae26c5a074053905cbcc6c0053be573633f3a/content/docs/Modules/webmin-configuration.md",
        "s8b072a3403d1": "https://github.com/webmin/webmin.com/blob/8ceae26c5a074053905cbcc6c0053be573633f3a/content/security.md"
      }
    },
    "pve-http": {
      "name": "Proxmox HTTP server",
      "basis": "5119ff9bec08c69584c0c98bea3edd0098179e5f",
      "sources": {
        "s753d88abe320": "https://git.proxmox.com/?p=pve-http-server.git;a=blob_plain;hb=5119ff9bec08c69584c0c98bea3edd0098179e5f;f=src/PVE/APIServer/AnyEvent.pm",
        "sb8d499c6bd8c": "https://git.proxmox.com/?p=pve-http-server.git;a=blob_plain;hb=5119ff9bec08c69584c0c98bea3edd0098179e5f;f=debian/changelog",
        "s2f151d3facd0": "https://git.proxmox.com/?p=pve-http-server.git;a=blob_plain;hb=5119ff9bec08c69584c0c98bea3edd0098179e5f;f=src/PVE/APIServer/Utils.pm"
      }
    },
    "pve-common": {
      "name": "libpve-common-perl 9.1.21",
      "basis": "5054082fe492429fc37574985c2ca812af9a3125",
      "sources": {
        "s062026297433": "https://git.proxmox.com/?p=pve-common.git;a=blob_plain;hb=5054082fe492429fc37574985c2ca812af9a3125;f=debian/changelog",
        "s022a9e4640ab": "https://git.proxmox.com/?p=pve-common.git;a=blob_plain;hb=5054082fe492429fc37574985c2ca812af9a3125;f=src/PVE/Daemon.pm"
      }
    },
    "usermin": {
      "name": "Usermin",
      "basis": "2.570",
      "sources": {
        "s7fe74c9a3138": "https://github.com/webmin/usermin/blob/2.570/setup.sh"
      }
    },
    "systemd": {
      "name": "systemd",
      "basis": "v262",
      "sources": {
        "s0a96457c713e": "https://github.com/systemd/systemd/blob/v262/man/systemd.socket.xml"
      }
    }
  },
  "claims": {
    "private": {"text": "Keep root-capable panels off the internet, bound/restricted to management networks with private access and a second factor.", "components": ["cockpit", "webmin-docs", "pve-docs"], "sources": ["cockpit:s0c1e0db624a4", "webmin-docs:s7a91f9f23044", "pve-docs:s8538bab3d3fc", "pve-docs:sc6bbbfe64d09"], "status": "REASONED"},
    "cockpit-bind": {"text": "Bare ListenStream=9090 binds IPv6 and, by default, IPv4 wildcard addresses.", "components": ["cockpit", "systemd"], "sources": ["cockpit:sc42ba09017c7", "systemd:s0a96457c713e"], "status": "REASONED"},
    "cockpit-dropin": {"text": "Use a socket drop-in, not cockpit.conf: reset ListenStream, set 10.0.0.5:9090 and FreeBind=yes, then daemon-reload/restart.", "components": ["cockpit"], "sources": ["cockpit:s0c1e0db624a4"], "status": "REASONED"},
    "cockpit-tls": {"text": "One port serves HTTP/HTTPS, redirecting HTTP except localhost; AllowUnencrypted defaults false and missing certificates cause self-signed creation.", "components": ["cockpit"], "sources": ["cockpit:sd0cb4ea3db56", "cockpit:sf157ab3a6f47"], "status": "REASONED"},
    "cockpit-pam": {"text": "Local accounts use Cockpit PAM with normal SSH-equivalent privileges.", "components": ["cockpit"], "sources": ["cockpit:s48ebdec28e10"], "status": "REASONED"},
    "cockpit-root": {"text": "First-install packages write root to disallowed-users; onerr=succeed permits root if that file is missing/unreadable.", "components": ["cockpit"], "sources": ["cockpit:sbdcd6e74a0c7", "cockpit:sc20103cfb39b"], "status": "REASONED"},
    "cockpit-escalation": {"text": "Users allowed sudo/polkit escalation get an immediately elevated session and terminal.", "components": ["cockpit"], "sources": ["cockpit:s2432e599485f"], "status": "REASONED"},
    "cockpit-mfa": {"text": "No built-in second factor; use PAM, Kerberos or client certificates.", "components": ["cockpit"], "sources": ["cockpit:s48ebdec28e10"], "status": "REASONED"},
    "cockpit-rate": {"text": "MaxStartups defaults to 10 concurrent attempts, not repeated-password lockout.", "components": ["cockpit"], "sources": ["cockpit:sf157ab3a6f47"], "status": "REASONED"},
    "cockpit-loginto": {"text": "Set LoginTo=false to prevent unauthenticated scanning of reachable private networks.", "components": ["cockpit"], "sources": ["cockpit:sf157ab3a6f47"], "status": "REASONED"},
    "webmin-bind": {"text": "Webmin/Usermin TCP ports are 10000/20000; omitted bind makes miniserv listen on all IPv4/IPv6 addresses.", "components": ["webmin", "usermin"], "sources": ["webmin:sa4f7ac343e85", "webmin:sb8fec2baa0f2", "usermin:s7fe74c9a3138"], "status": "REASONED"},
    "webmin-discovery": {"text": "Installed listen=10000/20000 opens discovery UDP on every IPv4 address; delete when unused.", "components": ["webmin", "usermin"], "sources": ["webmin:sa4f7ac343e85", "webmin:sb8fec2baa0f2", "usermin:s7fe74c9a3138"], "status": "REASONED"},
    "webmin-access": {"text": "Set management bind and allow networks, then restart; empty allow admits all except denied clients.", "components": ["webmin", "webmin-docs"], "sources": ["webmin:sb8fec2baa0f2", "webmin:sdb2ef2bf9978", "webmin-docs:s7a91f9f23044"], "status": "REASONED"},
    "webmin-tls": {"text": "Deb/RPM packages enable ssl=1 with a self-signed certificate.", "components": ["webmin"], "sources": ["webmin:sa4f7ac343e85", "webmin:sdd465cac1ff8", "webmin:s9ecba8f15014"], "status": "REASONED"},
    "webmin-root": {"text": "Installed root crypt=x accepts the Unix root password with all modules; Command Shell defaults to root.", "components": ["webmin"], "sources": ["webmin:sdd465cac1ff8", "webmin:s9ecba8f15014", "webmin:s1a1dbd21dddd"], "status": "REASONED"},
    "webmin-sudo": {"text": "Installed sudo=1 lets sudo-permitted Unix users log in effectively as root.", "components": ["webmin"], "sources": ["webmin:sdd465cac1ff8", "webmin:s9ecba8f15014", "webmin:sdb2ef2bf9978"], "status": "REASONED"},
    "webmin-mfa": {"text": "TOTP/Authy exists but is not configured at install; enable and enrol every user.", "components": ["webmin"], "sources": ["webmin:s2f3504ad1328"], "status": "REASONED"},
    "webmin-advisories": {"text": "Advisories list Basic-auth MFA bypasses CVE-2026-42210/CVE-2026-56022 under Webmin prior to 2.641; use a current release.", "components": ["webmin-docs"], "sources": ["webmin-docs:s8b072a3403d1"], "status": "REASONED"},
    "webmin-rate": {"text": "Defaults blockhost_failures=5/blockhost_time=60 block a host for 60 seconds, not a user lockout; Basic-auth failures count only with installed passdelay=1.", "components": ["webmin"], "sources": ["webmin:sa4f7ac343e85", "webmin:sdb2ef2bf9978"], "status": "REASONED"},
    "pve-bind": {"text": "pveproxy HTTPS API 8006 and spiceproxy 3128 share LISTEN_IP in /etc/default/pveproxy; new sockets without it try :: then 0.0.0.0. Dual-stack defaults and bindv6only=1 effects are documentation-backed; socket-library behaviour and installed versions remain unverified.", "components": ["pve-docs", "pve-manager", "pve-http", "pve-common"], "sources": ["pve-docs:s8538bab3d3fc", "pve-manager:s1507ce3e40b8", "pve-docs:s954445cf4e14", "pve-http:sb8d499c6bd8c", "pve-common:s062026297433", "pve-manager:s67c1a8621e22", "pve-manager:sb7f08e4e98ab", "pve-manager:s0b79b5bbd95f", "pve-http:s2f151d3facd0", "pve-common:s022a9e4640ab"], "status": "REASONED"},
    "pve-cluster": {"text": "The vendor warns against LISTEN_IP on clustered systems: nodes need peer pveproxy access, possibly across subnets. This guide advises management-only ACLs and firewall rules.", "components": ["pve-docs"], "sources": ["pve-docs:s8538bab3d3fc"], "status": "REASONED"},
    "pve-acl": {"text": "Both daemons share ALLOW_FROM/DENY_FROM/POLICY; default allow admits unmatched clients and dual matches. Deny rejects both cases. This guide advises ALLOW_FROM with DENY_FROM=all or POLICY=deny, one of the two, not both, because deny plus DENY_FROM=all refuses everyone.", "components": ["pve-docs", "pve-manager", "pve-http"], "sources": ["pve-docs:s8538bab3d3fc", "pve-manager:s1507ce3e40b8", "pve-docs:s954445cf4e14", "pve-http:sb8d499c6bd8c", "pve-manager:s67c1a8621e22", "pve-manager:sb7f08e4e98ab", "pve-manager:s0b79b5bbd95f", "pve-http:s2f151d3facd0", "pve-http:s753d88abe320"], "status": "REASONED"},
    "pve-firewall": {"text": "Firewall defaults disabled; enable and restrict 8006/22/3128 to management addresses.", "components": ["pve-docs"], "sources": ["pve-docs:sc6bbbfe64d09"], "status": "REASONED"},
    "pve-root": {"text": "root@pam can always log in as unconfined admin; installer sets the web-interface root password.", "components": ["pve-docs"], "sources": ["pve-docs:sdbc681682e8f"], "status": "REASONED"},
    "pve-shell": {"text": "Node shell opens /bin/login -f root without another password.", "components": ["pve-manager"], "sources": ["pve-manager:se4c11b901cf8"], "status": "REASONED"},
    "pve-mfa": {"text": "Configure TOTP, WebAuthn, recovery keys or realm-enforced TOTP/YubiKey OTP; no default second factor.", "components": ["pve-docs"], "sources": ["pve-docs:sdbc681682e8f"], "status": "REASONED"},
    "pve-lockout": {"text": "Eight TOTP failures disable TOTP; 100 WebAuthn/recovery-key failures block all factors for an hour. These are second-factor lockouts.", "components": ["pve-docs"], "sources": ["pve-docs:sdbc681682e8f"], "status": "REASONED"},
    "pve-password-delay": {"text": "Unauthorized API responses delay three seconds; this is not password lockout.", "components": ["pve-http"], "sources": ["pve-http:s753d88abe320"], "status": "REASONED"},
    "pve-certificates": {"text": "Each cluster creates its own self-signed CA.", "components": ["pve-docs"], "sources": ["pve-docs:s31f242f10eaa"], "status": "REASONED"},
    "pve-tokens": {"text": "API tokens default to separated privileges and cannot access VM/node consoles.", "components": ["pve-docs"], "sources": ["pve-docs:sdbc681682e8f"], "status": "REASONED"},
    "verify-cockpit": {"text": "Inspect effective socket reset/address and root deny file; bare port or missing deny file exposes documented defaults.", "components": ["cockpit"], "sources": ["cockpit:sc42ba09017c7", "cockpit:s0c1e0db624a4", "cockpit:sbdcd6e74a0c7", "cockpit:sc20103cfb39b"], "status": "REASONED"},
    "verify-pve": {"text": "Inspect the shared LISTEN_IP/ACL configuration for both daemons, enabled/running firewall and management-only rules, and every admin's second factor including root@pam. This guide assesses management bind on a single node or management ALLOW_FROM with DENY_FROM=all or POLICY=deny, one of the two, not both, as fixed; grep alone does not establish effective settings.", "components": ["pve-docs", "pve-manager", "pve-http", "pve-common"], "sources": ["pve-docs:s8538bab3d3fc", "pve-docs:sdbc681682e8f", "pve-docs:sc6bbbfe64d09", "pve-manager:s1507ce3e40b8", "pve-docs:s954445cf4e14", "pve-http:sb8d499c6bd8c", "pve-common:s062026297433", "pve-manager:s67c1a8621e22", "pve-manager:sb7f08e4e98ab", "pve-manager:s0b79b5bbd95f", "pve-http:s2f151d3facd0", "pve-common:s022a9e4640ab", "pve-http:s753d88abe320"], "status": "REASONED"},
    "verify-external": {"text": "Probe each public IP with a reachable control; refusal/timeout is only consistent with isolation. TCP does not test Webmin UDP.", "components": ["cockpit", "webmin", "usermin", "pve-docs"], "sources": ["cockpit:sc42ba09017c7", "webmin:sb8fec2baa0f2", "usermin:s7fe74c9a3138", "pve-docs:s8538bab3d3fc"], "status": "REASONED"},
    "webmin-loopback": {"text": "Loopback bind with no listen line produced one TCP socket and no UDP.", "components": ["webmin"], "sources": ["webmin:sb8fec2baa0f2"], "status": "DEMONSTRATED", "evidence": "its only socket was TCP `127.0.0.1` on the test port, with no UDP socket."},
    "webmin-rate-run": {"text": "Fifth wrong password exceeded a five-second timeout; then even the right password received host-block 403.", "components": ["webmin"], "sources": ["webmin:sa4f7ac343e85", "webmin:sdb2ef2bf9978"], "status": "DEMONSTRATED", "evidence": "the fifth wrong password was delayed past a five-second client timeout by miniserv's growing failure delay, and the right password was then refused with `403` \"Access denied for 127.0.0.1\"."},
    "verify-listeners": {"text": "Expect management TCP binds and no discovery UDP; this guide assesses clustered Proxmox wildcards as fixed only with management-only ACLs and firewall rules. Pinned new-socket code tries :: then 0.0.0.0; dual-stack operation remains documentation-backed and must be checked on the host.", "components": ["cockpit", "webmin", "usermin", "pve-docs", "pve-manager", "pve-http", "pve-common"], "sources": ["cockpit:sc42ba09017c7", "webmin:sb8fec2baa0f2", "usermin:s7fe74c9a3138", "pve-docs:s8538bab3d3fc", "pve-manager:s1507ce3e40b8", "pve-docs:s954445cf4e14", "pve-http:sb8d499c6bd8c", "pve-common:s062026297433", "pve-manager:s67c1a8621e22", "pve-manager:sb7f08e4e98ab", "pve-manager:s0b79b5bbd95f", "pve-http:s2f151d3facd0", "pve-common:s022a9e4640ab", "pve-http:s753d88abe320"], "status": "REASONED", "verify": [1]},
    "verify-webmin-parser": {"text": "Thirty fixtures matched miniserv parsing and bind/sockets/discovery/ACL outputs; unreadable paths were not checked. File inspection is not running-state proof. Runs covered an earlier form whose result arms ended with status 0; the current form was not re-run.", "components": ["webmin"], "sources": ["webmin:sb8fec2baa0f2", "webmin:sdb2ef2bf9978"], "status": "DEMONSTRATED", "evidence": "On each, the copy's parsed values matched Webmin 2.670's own `read_config_file` run on the same file, and the block printed the outcomes above; it reported an unreadable path as not checked.", "verify": [2]},
    "verify-tcp-loopback": {"text": "Copied probe has recorded loopback provenance, not live panel-isolation evidence; loopback and mapped hex addresses pass its guard. Runs covered an earlier form whose control and result arms ended with status 0; the current form was not re-run.", "components": ["cockpit", "webmin", "usermin", "pve-docs"], "sources": ["cockpit:sc42ba09017c7", "webmin:sb8fec2baa0f2", "usermin:s7fe74c9a3138", "pve-docs:s8538bab3d3fc"], "status": "DEMONSTRATED", "evidence": "loopback addresses pass, and hex spellings such as `::ffff:0:0` connected to a listener bound to 127.0.0.1", "verify": [3]}
  }
}
````
<!-- version-basis:end -->
