# RabbitMQ: users, TLS listener, and the guest account

RabbitMQ is a message broker: applications drop messages into its queues, and it delivers them to programs that process them. This guide helps your AI assistant configure it securely, including real users instead of the default guest account, a TLS listener, a protected management UI, and restricted Erlang distribution ports.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/rabbitmq.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against RabbitMQ source v4.4.0, rabbitmqadmin v2, RabbitMQ topic authorization introduction 3.7.0, Erlang/OTP distribution 27, and Pika source 1.3.2; 2 further sources are pinned to a commit and 3 carry no recorded version. Metadata reviewed 2026-11-07; documentation checked September 2026. The guide records 37 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

RabbitMQ's default `guest`/`guest` account can only connect from localhost, which protects fresh installs exactly until someone "fixes" it. The official Docker image ships that fix: its `/etc/rabbitmq/conf.d/10-defaults.conf` sets `loopback_users.guest = false`, so in a container from that image as shipped (a later configuration layer can set it back) the default `guest`/`guest` administrator, wherever it exists, can log in from any address that reaches the broker. The documented recommendation is to create real users and delete `guest` or change its password.

The settings below were checked against the current RabbitMQ 4.3 documentation in September 2026. These controls are available in open source RabbitMQ; no commercial edition is required. The export command specifically requires a current `rabbitmqadmin` v2, not v1.

## 1. Accounts

An unrestricted application grant on `/` lets a compromised application manipulate unrelated resources in that shared vhost. Give each application and environment its own user and vhost. For initial provisioning:

```bash
sudo rabbitmqctl add_vhost 'app-prod'
sudo rabbitmqctl add_user 'app'
# Enter a generated password at the interactive prompt.
# Permission order: configure, write, read.
sudo rabbitmqctl set_permissions -p 'app-prod' 'app' \
  '^app[.].*$' '^app[.].*$' '^app[.].*$'
sudo rabbitmqctl set_user_tags 'app'

sudo rabbitmqctl add_user 'ops'
# Enter a different generated password at the interactive prompt.
sudo rabbitmqctl set_user_tags 'ops' administrator

sudo rabbitmqctl add_user 'observer'
# Enter a third generated password at the interactive prompt.
sudo rabbitmqctl set_user_tags 'observer' monitoring
sudo rabbitmqctl set_permissions -p 'app-prod' 'observer' '^$' '^$' '^$'

sudo rabbitmqctl delete_user 'guest'
```

For existing accounts or vhosts, omit their creation commands. Provision the required topology in `app-prod`, migrate clients to that vhost, then remove the application's old grant:

```bash
sudo rabbitmqctl clear_permissions -p '/' 'app'
sudo rabbitmqctl list_user_permissions 'app'
```

The patterns permit resource names beginning `app.`. They exclude the default exchange, whose permission-check name is `amq.default`. Queue binding requires write permission on the queue and read permission on the exchange. Reconnect clients after permission changes. Review patterns explicitly for applications using generated queue names or shared resources; see [authentication.md](authentication.md). These commands manage RabbitMQ's internal authorization store; external backends need their own rules. Vhosts provide logical isolation, not dedicated CPU or memory. See [resource permissions](https://www.rabbitmq.com/docs/access-control) and [vhost isolation](https://www.rabbitmq.com/docs/vhosts).

Retain `ops` for administration and use `observer` for monitoring. Tags do not grant resource permissions; the observer's three `^$` patterns prevent message and topology operations. `set_user_tags` replaces existing tags.

| Tag | Relevant authority |
|---|---|
| No tags | No management-plugin access. |
| `management` | Management access within permitted vhosts. |
| `monitoring` | Management access plus cluster-wide operational visibility. |
| `policymaker` | Management access plus policy/parameter management in permitted vhosts. |
| `administrator` | Monitoring and policymaker authority plus user, vhost, and permission administration. |

Monitoring and policymaker are separate extensions of management access. Resource listings remain limited to vhosts with a permission entry. Review existing observer grants on other vhosts as well. See [management roles](https://www.rabbitmq.com/docs/management) and [tag replacement](https://www.rabbitmq.com/docs/man/rabbitmqctl.8).

Do not loosen the guest account's localhost restriction; in a container from the official image as shipped, where `10-defaults.conf` loosens it, delete `guest`, wherever it exists, as above. Exported definitions contain password hashes and hashing metadata; keep exports access-restricted and out of images and version control ([secrets.md](secrets.md)). Definitions imports are privileged provisioning input: a stale or untrusted file can introduce accounts, grants, policies, or plugin parameters.

For boot provisioning, use a reviewed local file in `rabbitmq.conf`:

```ini
definitions.import_backend = local_filesystem
definitions.local.path = /etc/rabbitmq/definitions/approved.json
```

Keep the directory administrator-owned and the file readable by RabbitMQ but not writable by it. Review accounts, permissions, policies, and runtime parameters before deployment. Core boot imports do not require management. They do not overwrite existing broker definitions, so they cannot reconcile or revoke stale grants. A blank node importing definitions does not create the default user and vhost; the approved file must supply the intended accounts and vhosts. See [boot import behaviour](https://www.rabbitmq.com/docs/definitions).

Runtime imports through `rabbitmqadmin definitions import` or `POST /api/definitions` merge with existing state: omitted objects remain, conflicting mutable objects are overwritten, and conflicting immutable queues, exchanges, and bindings retain their existing definitions. An error can leave a partial import. Do not treat runtime import as full reconciliation either. See [HTTP API import semantics](https://www.rabbitmq.com/docs/http-api-reference#post-apidefinitions).

For a reduced export, provision `$HOME/.rabbitmqadmin.conf` as an owner-only TOML file through your secret-management workflow. Replace the illustrative hostname and password, preserving valid TOML escaping:

```toml
[secureconfig]
hostname = "management.example.com"
port = 15671
username = "ops"
password = "REPLACE_WITH_OPS_PASSWORD"
```

Run this in a private directory, using a new output pathname:

```bash
( umask 077
  if [ -e ./definitions.redacted.json ] || [ -L ./definitions.redacted.json ]; then
    echo "choose a new export pathname; refusing to overwrite"
    exit 2
  fi
  rabbitmqadmin --config "$HOME/.rabbitmqadmin.conf" --node secureconfig \
    --use-tls --tls-ca-cert-file /etc/rabbitmq/tls/ca.pem \
    definitions export --file ./definitions.redacted.json \
    --transformations exclude_users,exclude_permissions,exclude_runtime_parameters
)
```

The v2 transformations remove users, permissions, and runtime parameters. Keep the result private pending review: arbitrary plugin data can still contain secrets. A sanitized export is not a complete account-recovery backup. See [export transformations](https://www.rabbitmq.com/docs/definitions) and [rabbitmqadmin configuration and TLS](https://www.rabbitmq.com/docs/management-cli).

## 2. TLS listener

In `rabbitmq.conf`, replace `listeners.ssl.default` with the private listener below; do not retain a wildcard TLS listener alongside it. Substitute the broker's private IPv4 address:

```ini
listeners.ssl.1 = REPLACE_WITH_BROKER_PRIVATE_IP:5671
ssl_options.cacertfile = /etc/rabbitmq/tls/ca.pem
ssl_options.certfile = /etc/rabbitmq/tls/server.pem
ssl_options.keyfile = /etc/rabbitmq/tls/server.key
ssl_options.verify = verify_peer
ssl_options.fail_if_no_peer_cert = true

# After migrating every client to TLS:
listeners.tcp = none
```

Certificates per [self-signed.md](self-signed.md) (an internal CA fits brokers well) or [free-certificates.md](free-certificates.md) cover the server certificate. Use a separate client certificate with `clientAuth` extended key usage and a chain trusted by `ssl_options.cacertfile`. Intermediate chains must fit `ssl_options.depth`; the documented default is 1. The Verify examples assume a client certificate issued directly by the trusted CA. Mutual TLS supplies a machine possession factor, not human MFA ([mfa.md](mfa.md)).

Requiring a trusted client certificate does not map it to a RabbitMQ username. Clients here still authenticate with their RabbitMQ username and password. Certificate-to-user authentication requires the separate certificate authentication plugin and the SASL `EXTERNAL` mechanism; it is not configured by these listener settings. See [TLS verification and certificate usage](https://www.rabbitmq.com/docs/ssl) and [certificate-based user authentication](https://www.rabbitmq.com/docs/access-control).

## 3. Management UI

The management plugin's web UI is an admin panel: keep it off public interfaces and reach it per [admin-uis.md](admin-uis.md) (SSH forward, tailnet, or Access), with its own TLS when remote. First add its independent restricted listener configuration to `rabbitmq.conf`, substituting the broker's private IPv4 address:

```ini
management.tcp.ip = 127.0.0.1
management.tcp.port = 15672

management.ssl.ip = REPLACE_WITH_BROKER_PRIVATE_IP
management.ssl.port = 15671
management.ssl.cacertfile = /etc/rabbitmq/tls/ca.pem
management.ssl.certfile = /etc/rabbitmq/tls/management.pem
management.ssl.keyfile = /etc/rabbitmq/tls/management.key
```

Start or restart the node through your deployment's service manager with this configuration in place BEFORE enabling the plugin. `rabbitmq.conf` changes require a node restart; editing the file alone does not update a running node. The plugin reads the effective listener configuration when it starts. Enabling it on a running broker starts it immediately; as of v4.4.0, with no management listener configured, the plugin starts a plain HTTP listener on port `15672`. That listener has no configured address, so at v4.4.0 `rabbit_networking:listener_per_ip_address/1` opens one socket per wildcard address, chosen by test binds when the listener starts. On a dual-stack host, where an IPv6 wildcard socket does not take IPv4 connections, it opens two sockets, `[::]:15672` and `0.0.0.0:15672`. On a single-stack host it opens `[::]:15672` alone, which also accepts IPv4 connections, and on an IPv4-only host `0.0.0.0:15672`. An example configuration in the RabbitMQ 4.3 management documentation, described as setting some parameters to their default values, includes `management.tcp.ip = 0.0.0.0` (all IPv4 interfaces). Set `management.tcp.ip` to an explicit loopback or private address before enabling the plugin, and check the actual listeners, IPv6 sockets included, with `ss` after startup. See [configuration application](https://www.rabbitmq.com/docs/configure#when-will-configuration-file-changes-be-applied) and [plugin activation](https://www.rabbitmq.com/docs/plugins#different-ways-to-enable-plugins).

Only after that start/restart succeeds, enable the plugin if it is not already enabled:

```bash
sudo rabbitmq-plugins enable rabbitmq_management
```

If the plugin is already enabled, apply the restricted configuration and restart the node before it becomes reachable, or keep management access firewalled until the restart and listener verification in check 2 are complete.

This deliberately retains HTTP on loopback and exposes HTTPS only on the selected private address. At v4.4.0, `management.ssl.ip` is what limits the HTTPS listener to that one address; without it, the HTTPS listener binds the same wildcard addresses as the default HTTP listener above. Restrict HTTPS reachability to administration hosts. The management certificate must cover the management hostname. AMQP `ssl_options` do not configure management TLS.

RabbitMQ 4.4.0 adds `management.listeners.tcp.<name>` and `management.listeners.ssl.<name>` entries, which start extra management listeners on top of the default ones. They do not disable the default listener: with only these entries set and no `management.tcp.*`, `management.ssl.*` or legacy `management.listener.*` settings, the plain HTTP listener on `15672` still starts on the wildcard addresses described above. An entry that gives only a port also drops `management.tcp.ip` or `management.ssl.ip` for that listener, which then binds without an address limit. Give each such entry an explicit private address as well as a port, and keep `management.tcp.ip` set so that the default HTTP listener stays on its chosen address, or leave these entries unset.

Standard internal-user HTTP authentication uses RabbitMQ credentials. Use the observer role from section 1 for monitoring and keep `ops` separate. Human MFA guidance remains in [admin-uis.md](admin-uis.md) and [mfa.md](mfa.md). See [management HTTPS and listener configuration](https://www.rabbitmq.com/docs/management) and [HTTP API authentication](https://www.rabbitmq.com/docs/http-api-reference).

## 4. epmd and the Erlang distribution port

Two more listeners exist beyond AMQP and management: epmd, the Erlang Port Mapper Daemon, defaults to `4369`; the distribution listener defaults to `25672`, derived from `RABBITMQ_NODE_PORT` plus 20000 (as of v4.4.0). A non-empty `RABBITMQ_DIST_PORT`, or its unprefixed form `DIST_PORT`, replaces that derived port, and RabbitMQ pins the distribution listener to the resulting single port by setting the Erlang kernel's `inet_dist_listen_min` and `inet_dist_listen_max` both to it. The `distribution.listener.port_range.min` and `.max` keys set below map to those same two kernel settings. This guide has not established which value applies when they differ from the derived port, so keep them equal to the port you intend. The distribution listener carries clustering and CLI traffic. Pin its private IPv4 address and port in `rabbitmq.conf`:

```ini
distribution.listener.interface = REPLACE_WITH_BROKER_PRIVATE_IP
distribution.listener.port_range.min = 25672
distribution.listener.port_range.max = 25672
```

When RabbitMQ starts epmd, supply this in the actual service/container launch environment, not merely an unrelated interactive shell:

```bash
export ERL_EPMD_ADDRESS='REPLACE_WITH_BROKER_PRIVATE_IP'
```

Changing `ERL_EPMD_ADDRESS` requires stopping both RabbitMQ and epmd before starting them with the new environment. Restarting RabbitMQ alone is insufficient. Socket-activated epmd instead needs its `epmd.socket` binding configured. epmd implicitly retains loopback access. Use a private address reachable by cluster peers; loopback-only distribution suits a single node with local CLI access.

Bindings do not replace firewall rules. Allow these ports only from cluster peers and authorized CLI hosts; do not publish them publicly in Compose port mappings. Remote CLI tools also use their own distribution-port range, by default `35672` through `35682` (as of v4.4.0, from `RABBITMQ_CTL_DIST_PORT_MIN` through ten above it unless `RABBITMQ_CTL_DIST_PORT_MAX` is set, where an empty value counts as unset and the unprefixed `CTL_DIST_PORT_MIN` or `CTL_DIST_PORT_MAX` then applies); restrict the actual range to the necessary peers. See [networking and epmd lifecycle](https://www.rabbitmq.com/docs/networking).

The Erlang cookie is a shared secret granting powerful node and CLI access. On typical Unix installations the server uses `/var/lib/rabbitmq/.erlang.cookie`, and CLI users use `$HOME/.erlang.cookie`. Keep matching copies owner-only, normally mode `600`, with a long random value supplied through secret management. Keep it out of images and Compose files, and never pass its value through command-line arguments. Cookie possession plus distribution reachability can give full broker control. See [CLI authentication](https://www.rabbitmq.com/docs/cli).

Restart the node through your deployment's service manager after applying listener configuration, including the separate epmd lifecycle change where needed.

## 5. Verify (REASONED: all checks 1-9, their fences, instructions, expected outcomes and authoring-record tables in this section; a live RabbitMQ stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. No live exposed/fixed broker, external vantage, allowed administration/application/cluster peers, matching cookies, broker logs or multi-node TLS comparison was established. Per the guide's cited sources this declaration lists in four parts, the exposed and fixed outcomes are those stated at each step. The guide's cited sources this declaration lists (1 of 4): RabbitMQ access control, guest restrictions, interactive user creation, and resource permissions; RabbitMQ virtual hosts and logical isolation; RabbitMQ CLI user, vhost, permission, and tag commands; RabbitMQ management listeners, HTTPS, and roles. The guide's cited sources this declaration lists (2 of 4): RabbitMQ HTTP API authentication and endpoints; RabbitMQ TLS, peer verification, certificate usage, and verification depth; RabbitMQ networking, epmd lifecycle, private bindings, and distribution ports; RabbitMQ diagnostics, remote node selection, and authenticated ping. The guide's cited sources this declaration lists (3 of 4): RabbitMQ CLI authentication and Erlang cookie handling; RabbitMQ definitions imports, sensitive exports, and export transformations; RabbitMQ administration CLI v2 configuration and TLS flags; RabbitMQ inter-node TLS (distribution over TLS); Erlang/OTP 27 distribution over TLS; RabbitMQ queues, durability, and exclusive queue behaviour. The guide's cited sources this declaration lists (4 of 4): RabbitMQ channel exceptions and access-refused errors; Pika TLS context and client certificate example; Pika connection parameters; Pika blocking connection and channel methods; Pika authentication and authorization exceptions; curl password prompts, TLS validation, and diagnostic flags. The exposed and fixed outcomes (1 of 2) per the guide's cited sources this declaration lists: excessive grants and forbidden connections versus scoped grants and denied connections with successful authorized controls; wildcard or public listeners and broad cookie modes versus private bindings and owner-only cookies. The exposed and fixed outcomes (2 of 2) per the guide's cited sources this declaration lists: optional versus required client certificates; unwanted versus approved definitions; plaintext versus authenticated TLS distribution; unrestricted versus tenant-scoped topic operations. Marking review ran 19 Bash blocks through bash -n and ShellCheck 0.11.0 with no findings, and an SC2086 canary produced its expected diagnostic. Stub-only Verify execution exercised argument dispatch and 32 guard refusals under bash -u, printing the corresponding refusal without external commands; valid substitutions reached only stubs. Any run recorded here of check 2's block covered an earlier form, without its check for a missing ss. Its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by local stub runs in which its ss part exited 0, 3 and 2 with ss passing, failing and missing. In a clean shell the block's own status stayed its last command's, and under an inherited set -e the first command or part that failed ended the pasted block with its status. Both embedded Python programs parsed in an earlier form, without the status 3 exception handlers and check 7's status 3 arm for a non-object export, and neither current form was re-run; the TOML example and four INI key/value structures parsed, without native schema validation. The reduced-export overwrite guard reached a stub for an absent path and refused both an existing file and a dangling symlink. The bash -n, ShellCheck and stub runs recorded here covered the section 1 reduced-export block and the guarded blocks of checks 3 to 6 in an earlier form, whose overwrite and placeholder refusals exited with status 1; none was re-run on the current form, whose refusals exit with status 2. That earlier form of checks 5 and 6 also exited with status 1 after a failed positive control, a certificate-absent run that exited 0 or an unexpected Python exception, where the current form exits with status 3 unless check 6 already reported an unexpected allow, which keeps status 1. Seven reduced-export JSON fixtures printed the empty-sections success, not a definitions object, or review required for each of the five nonempty sections. Those fixture runs and the bash -n and ShellCheck runs of check 7 covered an earlier form, which exited with status 1 for a non-object export or an unreadable or malformed file; none was re-run on the current form, which exits with status 3 there and keeps status 1 for review required. These local results do not demonstrate broker behaviour. Native RabbitMQ configuration parsing was not run in the October 2026 marking review and remains an open gap. All original absence statements and local-check counts below are historical authoring records, not new host observations; the original test receipts were not reauthenticated.)

Historical authoring record: service behaviour was not demonstrated in the authoring environment. The original review recorded the nine service checks below as REASONED: RabbitMQ/Erlang binaries, `rabbitmqadmin`, Pika, Docker, and Podman were absent, and no broker or external peer test environment was supplied; this marking review does not reassert those historical host observations. Expected service outcomes remain REASONED from the Sources entries named in the section declaration.

Use Bash and paste whole guarded blocks. Substitute inside the single quotes on each `set --` line, retaining the quotes; do not insert literal apostrophes. The guards assume real shell builtins. A fragment pasted below its guard is unguarded, and inherited arguments identical to the marker and expected values cannot be distinguished from a complete paste. Use curl 7.75.0 or newer for the diagnostic write-out fields. `--user` below contains only a username and prompts for the password; do not append a password.

**1. Accounts and roles - REASONED: no `rabbitmqctl` or broker was available at authoring.** Run after migration and reconnecting clients:

```bash
# Accounts and roles; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
sudo rabbitmqctl list_users
sudo rabbitmqctl list_user_permissions 'app'
sudo rabbitmqctl list_permissions -p 'app-prod'
sudo rabbitmqctl list_vhosts
```

Compare the exposed state's unrestricted `/` grant and excessive operator privileges with the fixed state: `app` has only the intended `app-prod` grant, `observer` has `monitoring` without `administrator` and three `^$` patterns, and `guest` is absent. A failed listing proves nothing. Confirm an existing ungranted vhost for the protocol test below; do not substitute a nonexistent vhost. The [CLI permission commands](https://www.rabbitmq.com/docs/man/rabbitmqctl.8) expose these records; checks 4 and 6 test their effect.

**2. Listener and cookie inventory - REASONED: no RabbitMQ node, epmd, or deployed cookie was available at authoring.** After the restart:

```bash
# Listener and cookie inventory; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
# This fence has no single exit status of its own: read each part's output, including the ss part's refusal or failure line, not only the status.
sudo rabbitmq-diagnostics -s listeners
(                                       # a subshell, so the exits below end only this part: 2 if ss is not installed, 3 if ss fails, otherwise 0
  command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
  ss -tlnp || { echo "ss -tlnp exit $?: the listener inventory failed; inconclusive"; exit 3; }
)
epmd -names
sudo stat -c '%a %U' /var/lib/rabbitmq/.erlang.cookie
```

Expect AMQPS on the selected private address at `5671`, HTTPS there at `15671`, HTTP only on `127.0.0.1:15672`, distribution on the private address at `25672`, and no plaintext AMQP listener on `5672`. epmd should bind privately and on loopback; `epmd -names` reports the registered distribution port, not epmd's interface bindings. Inspect all `ss` output, including IPv6 and additional plugin listeners. The exposed comparison has wildcard/public listeners or plaintext AMQP still enabled.

On the conventional installation above, the cookie should be owned by `rabbitmq` and mode `600` or `400`; broader access is a finding. Mode alone does not prove randomness or absence from images. Listener addresses alone do not establish firewall isolation. These expectations follow [listener configuration](https://www.rabbitmq.com/docs/networking) and [cookie permissions](https://www.rabbitmq.com/docs/cli).

**3. Reachability - REASONED: no broker, administration host, application host, or cluster peer was available at authoring.** Inventory actual ports first; update every corresponding probe if any port differs, and add probes for extra listeners.

From an external non-peer host, target the broker's public address:

```bash
# External reachability; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_PUBLIC_ADDR'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "need exactly 1 public address; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the public address; not probing"; exit 2 ;;
    *)
      for p in 4369 25672 15672 15671 5671; do
        nc -vz -w 5 "$1" "$p"
      done
      # Removed plaintext AMQP is checked separately.
      nc -vz -w 5 "$1" 5672
    ;;
  esac
)
```

From hosts allowed by the corresponding firewall rules, target the private address. Execute the cluster, application, and administration commands on their respective allowed hosts if those roles are separate:

```bash
# Allowed-peer controls; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_PRIVATE_ADDR'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "need exactly 1 private address; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the private address; not probing"; exit 2 ;;
    *)
      # Run from an allowed cluster/CLI host.
      for p in 4369 25672; do nc -vz -w 5 "$1" "$p"; done
      # Run these from the respective allowed application and administration hosts.
      nc -vz -w 5 "$1" 5671
      nc -vz -w 5 "$1" 15671
      # Neither listener should accept connections on the private interface.
      nc -vz -w 5 "$1" 15672
      nc -vz -w 5 "$1" 5672
    ;;
  esac
)
```

From an allowed CLI host with its owner-only matching cookie file, also require an authenticated distribution connection to the same broker. Supply its actual node name, such as the deployed `rabbit@` name. This form assumes short node names; add `--longnames` for a deployment using long names. The documented [diagnostics ping](https://www.rabbitmq.com/docs/man/rabbitmq-diagnostics.8) checks authentication as well as reachability:

```bash
# Authenticated distribution ping; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_NODE_NAME'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "need exactly 1 node name; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the broker node name; not probing"; exit 2 ;;
    *)
      sudo rabbitmq-diagnostics -n "$1" ping
    ;;
  esac
)
```

On the broker itself, confirm that the retained HTTP management listener works with authentication:

```bash
# Loopback management control; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
curl -q -g --noproxy '*' --connect-timeout 5 --max-time 20 \
  -sS --user observer -o /dev/null \
  -w 'loopback http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' \
  'http://127.0.0.1:15672/api/overview'
```

The exposed state accepts prohibited external connections; the fixed state refuses them while the allowed private ports connect and the loopback API returns HTTP 200. Pair these TCP controls with the authenticated API and AMQP checks below. Public and private targets must identify the same broker; do not reuse one split-DNS hostname for both. DNS/routing errors, a dead service, or an unidentified endpoint make a failure inconclusive.

For removed plaintext AMQP, first demonstrate a connection to its old listener in an isolated exposed deployment, then show both its absence from the fixed listener inventory and refusal on `5672`, with authenticated AMQPS still working. This distinguishes listener removal from a stopped broker. See [RabbitMQ ports and binding](https://www.rabbitmq.com/docs/networking).

**4. Management authentication and roles - REASONED: no broker or management endpoint was available at authoring.** From an allowed administration host, use the management certificate's hostname:

```bash
# Management authentication and roles; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_MANAGEMENT_HOSTNAME'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "need exactly 1 hostname; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the management hostname; not probing"; exit 2 ;;
    *)

      # Username only: curl prompts for the password.
      curl -q -g --noproxy '*' --cacert /etc/rabbitmq/tls/ca.pem \
        --connect-timeout 5 --max-time 20 -sS --user observer \
        -w 'observer http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' \
        "https://$1:15671/api/overview"
      curl -q -g --noproxy '*' --cacert /etc/rabbitmq/tls/ca.pem \
        --connect-timeout 5 --max-time 20 -sS \
        -w 'anonymous http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' \
        "https://$1:15671/api/overview"

      # Paired administrative authority check; each password is prompted separately.
      curl -q -g --noproxy '*' --cacert /etc/rabbitmq/tls/ca.pem \
        --connect-timeout 5 --max-time 20 -sS --user ops \
        -w 'ops http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' \
        "https://$1:15671/api/users"
      curl -q -g --noproxy '*' --cacert /etc/rabbitmq/tls/ca.pem \
        --connect-timeout 5 --max-time 20 -sS --user observer \
        -w 'observer http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' \
        "https://$1:15671/api/users"
    ;;
  esac
)
```

Require HTTP 200 for the observer's overview and the administrator's user listing. The anonymous overview must return an authentication refusal, and the observer's user listing must return an authorization refusal; inspect the response body and correlate authentication failures before accepting a denial. Transport failures, HTTP 000, redirects, and server errors are inconclusive. Retain output privately because administrative responses may contain sensitive account metadata.

An exposed management listener can still require authentication: external reachability is tested separately in check 3. For the excessive-role comparison, an observer carrying `administrator` can list users; after correction it retains overview access but loses that administrative access. If anonymous overview access succeeds through the deployed path, that is an additional finding. See [management roles](https://www.rabbitmq.com/docs/management) and the [overview and users endpoints](https://www.rabbitmq.com/docs/http-api-reference).

**5. Mutual TLS - REASONED: no broker, trusted test certificates, or broker logs were available at authoring.** From an allowed application host, place `ca.pem`, `client.pem`, and the protected `client.key` in the working directory. Use a valid client certificate with `clientAuth`, not a server-only certificate:

```bash
# Mutual TLS; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_AMQP_HOSTNAME'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "need exactly 1 hostname; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the AMQP hostname; not probing"; exit 2 ;;
    *)

      # Keep stdin open to allow a delayed TLS rejection to arrive.
      if sleep 10 | openssl s_client -connect "$1:5671" -servername "$1" \
        -CAfile ca.pem -cert client.pem -key client.key \
        -verify_hostname "$1" -verify_return_error; then
        echo "certificate-present run exited 0; inspect the handshake and broker log"
      else
        echo "positive control failed; the pair is inconclusive"
        exit 3
      fi

      if sleep 10 | openssl s_client -connect "$1:5671" -servername "$1" \
        -CAfile ca.pem -verify_hostname "$1" -verify_return_error; then
        echo "certificate-absent run exited 0; required rejection was not demonstrated"
        exit 3
      else
        echo "negative run failed; require a matching missing-client-certificate broker log"
      fi
    ;;
  esac
)
```

`Verification: OK` describes verification of the server certificate only. Require a successful certificate-present handshake plus a certificate-absent failure attributed by the broker to the missing client certificate. A DNS error, TCP failure, server-certificate failure, or unrelated timeout is not the required rejection.

Keeping stdin open helps expose delayed TLS 1.3 alerts; ten seconds is a timing-dependent observation window, not a guarantee. Both runs exiting zero is inconclusive. If the positive run closes because no AMQP protocol handshake followed, use the protocol client in check 6 and broker logs to resolve it. In the isolated exposed comparison with client certificates optional, the certificate-absent handshake succeeds too. See [peer verification](https://www.rabbitmq.com/docs/ssl).

**6. AMQP authentication and authorization - REASONED: no RabbitMQ broker or Pika client package was available at authoring.** Run with Python 3 and Pika 1.x using the TLS files from check 5. Passwords are prompted from the terminal. Use an isolated test deployment: the script creates a uniquely named durable queue and direct exchange and deletes them on normal completion; inspect and remove its `app.secureconfig.*` fixtures after an interrupted run.

The positive control declares, binds, publishes, and retrieves a message as `app`. Separate channels test resource denials. The shared queue is durable because RabbitMQ 4.3 disables transient non-exclusive queues by default; an exclusive queue would make the observer's read test ambiguous. The script uses the [documented permission model](https://www.rabbitmq.com/docs/access-control), [channel error codes](https://www.rabbitmq.com/docs/channels), [queue rules](https://www.rabbitmq.com/docs/queues), and [Pika's blocking client](https://pika.github.io/pika/latest/modules/adapters/blocking/).

```bash
# AMQP authentication and authorization; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_AMQP_HOSTNAME' 'REPLACE_WITH_EXISTING_UNGRANTED_VHOST'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "need hostname and existing ungranted vhost; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the AMQP hostname; not probing"; exit 2 ;;
    *)
      case "$2" in
        *REPLACE_WITH_*|"") echo "substitute the ungranted vhost; not probing"; exit 2 ;;
        *)
          python3 - "$1" "$2" <<'PY'
import getpass
import os
import ssl
import sys
import uuid
import warnings


def inconclusive(kind, value, tb):
    # An unexpected exception, including a failed positive control, is inconclusive:
    # exit with status 3, unless an unexpected allow was already reported, which keeps status 1.
    sys.__excepthook__(kind, value, tb)
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(1 if findings else 3)


findings = []
sys.excepthook = inconclusive

import pika

warnings.simplefilter("error", getpass.GetPassWarning)
host, other_vhost = sys.argv[1:]
context = ssl.create_default_context(cafile="ca.pem")
context.load_cert_chain("client.pem", "client.key")
app_password = getpass.getpass("app password: ")
observer_password = getpass.getpass("observer password: ")

def connect(user, password, vhost):
    return pika.BlockingConnection(pika.ConnectionParameters(
        host=host, port=5671, virtual_host=vhost,
        credentials=pika.PlainCredentials(user, password),
        ssl_options=pika.SSLOptions(context, host),
        socket_timeout=5, stack_timeout=15, blocked_connection_timeout=15))

def denied_operation(connection, label, operation):
    channel = connection.channel()
    channel.confirm_delivery()
    try:
        operation(channel)
    except pika.exceptions.ChannelClosedByBroker as exc:
        if exc.reply_code != 403:
            raise
        print(label + ": ACCESS_REFUSED; correlate with the broker log")
    else:
        findings.append(label)
        print(label + ": UNEXPECTED ALLOW")
    finally:
        if channel.is_open:
            channel.close()

def denied_connection(user, password, vhost, expected_error, label):
    try:
        connection = connect(user, password, vhost)
    except expected_error:
        print(label + ": refused; require the matching broker-log reason")
    else:
        connection.close()
        findings.append(label)
        print(label + ": UNEXPECTED ALLOW")

name = "app.secureconfig." + uuid.uuid4().hex
with connect("app", app_password, "app-prod") as app:
    channel = app.channel()
    channel.exchange_declare(exchange=name, exchange_type="direct", durable=True)
    try:
        channel.queue_declare(queue=name, durable=True,
                              arguments={"x-queue-type": "classic"})
        try:
            channel.queue_bind(queue=name, exchange=name, routing_key="verify")
            channel.confirm_delivery()
            channel.basic_publish(exchange=name, routing_key="verify",
                                  body=b"secureconfig", mandatory=True)
            method, properties, body = channel.basic_get(queue=name, auto_ack=True)
            if method is None or body != b"secureconfig":
                raise RuntimeError("positive message round trip failed")
            print("app: authenticated; declare, bind, publish and get succeeded")

            denied_operation(app, "app unrelated queue", lambda ch:
                ch.queue_declare(queue="unrelated." + uuid.uuid4().hex,
                                 exclusive=True))
            denied_operation(app, "app default exchange", lambda ch:
                ch.basic_publish(exchange="", routing_key=name,
                                 body=b"denial probe", mandatory=True))

            with connect("observer", observer_password, "app-prod") as observer:
                print("observer: authenticated to app-prod")
                denied_operation(observer, "observer configure", lambda ch:
                    ch.queue_declare(queue=name + ".observer", exclusive=True))
                denied_operation(observer, "observer publish", lambda ch:
                    ch.basic_publish(exchange=name, routing_key="verify",
                                     body=b"denial probe", mandatory=True))
                denied_operation(observer, "observer get", lambda ch:
                    ch.basic_get(queue=name, auto_ack=True))

            denied_connection("secureconfig-unknown-" + uuid.uuid4().hex,
                              "deliberately-invalid", "app-prod",
                              pika.exceptions.ProbableAuthenticationError,
                              "unknown user")
            denied_connection("app", app_password, other_vhost,
                              pika.exceptions.ProbableAccessDeniedError,
                              "app ungranted vhost")
        finally:
            if app.is_open:
                app.channel().queue_delete(queue=name)
    finally:
        if app.is_open:
            app.channel().exchange_delete(exchange=name)

if findings:
    raise SystemExit("unexpectedly allowed: " + ", ".join(findings))
print("Expected results observed by this run; retain the matching broker logs.")
PY
        ;;
      esac
    ;;
  esac
)
```

Require the positive message round trip and observer authentication, then resource-specific `403 ACCESS_REFUSED` responses. Unknown-user and ungranted-vhost connection errors must have matching broker-log reasons; Pika's `Probable*` exception names are not proof by themselves. Unexpected exceptions are inconclusive, not authorization successes.

For the exposed comparison, use an isolated fixture with unrestricted application permissions in `app-prod` and the second existing vhost, and an observer with excessive resource grants. The same script should report unexpected allows for those operations. An unknown user should still be refused when authentication is working in either state. The fixed deployment must retain the positive operations while removing those unexpected allows. Reconnect between states.

**7. Definitions provisioning and export - REASONED: no blank broker, `rabbitmqadmin`, or exported definitions file was available at authoring.** Boot an isolated blank node using the approved file and boot settings from section 1, then run:

```bash
# Definitions provisioning and export; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
sudo rabbitmqctl list_users
sudo rabbitmqctl list_permissions -p 'app-prod'

python3 - <<'PY'
import json
import os
import sys
from pathlib import Path


def inconclusive(kind, value, tb):
    # An unreadable or malformed export is inconclusive: exit with status 3,
    # keeping status 1 for the review-required findings below.
    sys.__excepthook__(kind, value, tb)
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(3)


sys.excepthook = inconclusive

data = json.loads(Path("definitions.redacted.json").read_text())
if not isinstance(data, dict):
    print("not a definitions object", file=sys.stderr)
    sys.exit(3)
for field in ("users", "permissions", "topic_permissions",
              "parameters", "global_parameters"):
    if data.get(field):
        raise SystemExit("review required: non-empty " + field)
print("Selected sensitive sections are absent or empty; review all other content.")
PY
```

Compare users and grants with the approved list, including absence of `guest`. For the exposed comparison, use a separately reviewed test fixture containing an unwanted test account or grant and confirm that the inventory detects it. Then repeat on another blank node with the approved file; importing over the first node is not reconciliation.

Run section 1's reduced export and compare it with a private untransformed export from the same test broker containing known test users, vhost grants, topic permissions, and runtime parameters. The selected sections must be removed or empty in the reduced JSON. The local JSON check is deliberately conservative: any retained topic permissions or global parameters also require review. It exits with status 1 when a selected section requires review, and with status 3 when the export cannot be read or is not a definitions object. Review all remaining fields for secrets; empty selected sections do not establish that the whole document is safe to share. See [definitions import and export](https://www.rabbitmq.com/docs/definitions) and [exported definition contents](https://www.rabbitmq.com/docs/http-api-reference#get-apidefinitions).

**8. Inter-node and CLI distribution TLS - REASONED: no Erlang runtime, RabbitMQ broker, or multi-node cluster was available at authoring.** On an authorized test cluster with the section 6 configuration, from an authorized CLI host holding the matching cookie and substituting the deployed long node name for `rabbit@node1.internal`:

```bash
# Distribution TLS; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
sudo rabbitmq-diagnostics --longnames -n rabbit@node1.internal ping
sudo rabbitmqctl --longnames -n rabbit@node1.internal cluster_status
```

With plaintext distribution a plaintext CLI authenticates; with TLS required, a plaintext CLI connection fails on the transport, while a CLI given the matching `RABBITMQ_CTL_ERL_ARGS` succeeds, and a CLI presenting a missing or untrusted client certificate is rejected. Two configured nodes must form a cluster over the selected TLS transport, and a plaintext node must not join. Correlate a failure with the TLS logs; a wrong cookie, bad DNS, or a stopped node is inconclusive, and `ping` and `cluster_status` alone do not prove every peer link is encrypted. See the [inter-node TLS guide](https://www.rabbitmq.com/docs/clustering-ssl).

**9. Topic-exchange routing-key authorization - REASONED: no RabbitMQ broker or AMQP client was available at authoring.** On an authorized broker with an administrator-provisioned `app.shared.topic` exchange, hold the section 1 resource permissions constant and vary only whether the section 7 topic permission exists:

```bash
# Topic routing-key authorization; no RabbitMQ/Erlang broker, clients or peer fixtures. Expected outcomes and vendor sources are recorded in this section.
sudo rabbitmqctl list_topic_permissions -p 'app-prod'
```

As the `app` user with publisher confirms, publish to `tenant1.created` and to `tenant2.created`, and bind a queue with each routing key, then repeat with `#` and `tenant1.#`. With no topic permission every publish and binding succeeds; with the section 7 permission `tenant1.created` succeeds while `tenant2.created`, `#`, and `tenant1.#` are refused with a broker-attributed `ACCESS_REFUSED`. Require that broker refusal rather than a client-side timeout; the listing shows the stored policy, not enforcement. Also test the exchange-to-exchange bypass across both grants. Under the baseline grant, where the `app` user can declare exchanges, it declares its own exchange, binds it to `app.shared.topic` with `tenant2.created`, and publishes through it; the message reaches the shared exchange, confirming that topic authorization alone is insufficient. Under the hardened grant, the exchange declaration is refused because the application has no configure permission, and an `exchange.bind` into `app.shared.topic` is refused with `ACCESS_REFUSED` because the application holds read permission on no exchange, so no relay route can be created. See the [topic authorization reference](https://www.rabbitmq.com/docs/access-control#topic-authorisation).

Local authoring checks, completed without a broker:

| Check | Observed result |
|---|---|
| Bash parsing and ShellCheck | All runnable Bash blocks passed `bash -n` and ShellCheck 0.11.0; an intentional SC2086 canary confirmed that lint diagnostics were active. These runs covered the section 1 reduced-export block and the guarded blocks of checks 3 to 6 in an earlier form, whose overwrite and placeholder refusals exited with status 1, and were not re-run on the current form. They also covered the check 7 block in an earlier form, which exited with status 1 for an unreadable, malformed or non-object export, and were not re-run on its current form, which exits with status 3 there. |
| Placeholder guards | 32 cases stopped locally under `bash -u`: unreplaced values, each empty value, embedded `REPLACE_WITH_*`, marker-only assignment, and omitted assignment with inherited non-marker arguments. These cases ran against an earlier form, whose placeholder refusals exited with status 1; none was re-run on the current form, whose placeholder refusals exit with status 2. |
| TOML | The example parsed with Python `tomllib`. |
| Embedded Python | Both programs passed Python syntax parsing. Those runs covered an earlier form, without check 6's status 3 exception handler and check 7's status 3 arms for an unreadable, malformed or non-object export, and neither current form was re-run. |
| RabbitMQ configuration | Key/value structure checked locally and settings traced to current vendor docs; native configuration/schema parsing remains unconfirmed because RabbitMQ and Erlang were absent at authoring. |

Historical authoring record: no broker, container, or whole-corpus gate suite was run in the original review. Local syntax checks do not demonstrate service behaviour.

| Check scope | Procedure and prerequisites | Status |
|---|---|---|
| Service checks | Demonstrate checks 1-9 against isolated exposed and fixed states (1 of 2): scoped grants and vhost refusal; monitoring versus administration and message operations; listener/epmd bindings, cookie permissions, external denial and allowed-peer controls including 15671 and removed 5672; management authenticated/anonymous responses; mutual TLS and AMQP user authentication. The items to demonstrate for checks 1-9 against isolated exposed and fixed states (2 of 2): approved blank-node imports and reduced exports; plaintext versus TLS-required inter-node and CLI distribution, with rejection of a missing or untrusted client certificate; and topic-exchange routing-key authorization, with a broker ACCESS_REFUSED for an out-of-pattern publish or binding. Include startup checks and retain commands, versions, outputs, and matching broker logs. | REASONED from the cited RabbitMQ documentation; missing RabbitMQ/Erlang, rabbitmqadmin, Pika, container runtime, test certificates, and peer infrastructure in the authoring environment. |
| Native configuration/schema parsing | Parse the RabbitMQ configuration with the native tools. | Unconfirmed because RabbitMQ and Erlang were absent at authoring; retained local work. |

## 6. Encrypt inter-node and CLI distribution traffic with TLS

Section 4 binds the Erlang distribution port privately but leaves that traffic in plaintext. Distribution carries clustering messages and the full authority of `rabbitmqctl` and `rabbitmq-diagnostics`, so encrypt it with mutually authenticated TLS across every node and CLI host. This is an Erlang runtime mechanism, not a `rabbitmq.conf` setting: it is selected through `rabbitmq-env.conf` and a separate Erlang-term options file. RabbitMQ 4.4.0 fully supports the Erlang/OTP 28 and 29 series, per the [v4.4.0 release notes](https://github.com/rabbitmq/rabbitmq-server/releases/tag/v4.4.0); this guide does not state a minimum Erlang/OTP version. This example was written against the OTP 27 references this section cites, so check them against the OTP release you run. See the [inter-node TLS guide](https://www.rabbitmq.com/docs/clustering-ssl) and the [OTP distribution-over-TLS reference](https://www.erlang.org/docs/27/apps/ssl/ssl_distribution.html).

In `/etc/rabbitmq/rabbitmq-env.conf`, select the TLS distribution module for both the server and the CLI tools, pointing each at the options file:

```bash
# shellcheck disable=SC2034  # rabbitmq-env.conf is sourced by RabbitMQ; these variables are read externally
ERL_SSL_PATH="REPLACE_WITH_INSTALLED_SSL_EBIN_DIRECTORY"
SERVER_ADDITIONAL_ERL_ARGS="-pa $ERL_SSL_PATH -proto_dist inet_tls -ssl_dist_optfile /etc/rabbitmq/inter_node_tls.config"
RABBITMQ_CTL_ERL_ARGS="-pa $ERL_SSL_PATH -proto_dist inet_tls -ssl_dist_optfile /etc/rabbitmq/inter_node_tls.config"
```

Determine the installed Erlang `ssl` application `ebin` directory on the host rather than copying a version-specific example. `SERVER_ADDITIONAL_ERL_ARGS` configures the broker's distribution; `RABBITMQ_CTL_ERL_ARGS` gives `rabbitmqctl` and `rabbitmq-diagnostics` the matching configuration so CLI connections are not refused. In a systemd or container launch environment the server variable's prefixed form is `RABBITMQ_SERVER_ADDITIONAL_ERL_ARGS`. See the [pinned launch-variable handling](https://raw.githubusercontent.com/rabbitmq/rabbitmq-server/v4.4.0/deps/rabbit/scripts/rabbitmq-env).

In `/etc/rabbitmq/inter_node_tls.config`, require and verify peer certificates in both directions, because a node both accepts and initiates distribution connections:

```erlang
[
  {server, [
    {cacertfile, "/etc/rabbitmq/distribution/ca.pem"},
    {certfile, "/etc/rabbitmq/distribution/server.pem"},
    {keyfile, "/etc/rabbitmq/distribution/server.key"},
    {verify, verify_peer},
    {fail_if_no_peer_cert, true}
  ]},
  {client, [
    {cacertfile, "/etc/rabbitmq/distribution/ca.pem"},
    {certfile, "/etc/rabbitmq/distribution/client.pem"},
    {keyfile, "/etc/rabbitmq/distribution/client.key"},
    {verify, verify_peer}
  ]}
].
```

Provision credentials readable by the effective process identity on every node and CLI host. Peer verification checks the certificate against the hostname portion of the target Erlang node name (the part after the `@`), so issue each distribution certificate with a subject or SAN DNS identity matching that hostname rather than assuming the AMQP hostname certificate satisfies it. This outbound hostname verification is distinct from the inbound client-certificate trust that `verify_peer` and `fail_if_no_peer_cert` enforce; never disable either to resolve a mismatch. Plan a coordinated switch: distribution endpoints with mismatched transports cannot communicate, so a plaintext node and a TLS node will not form a cluster during a rolling change. TLS does not remove the Erlang cookie, epmd, or firewall requirements from section 4. See the [OTP distribution semantics](https://www.erlang.org/docs/27/apps/ssl/ssl_distribution.html) and the [OTP 27 distribution TLS implementation](https://raw.githubusercontent.com/erlang/otp/OTP-27.0/lib/ssl/src/inet_tls_dist.erl).

## 7. Restrict routing keys on shared topic exchanges

Section 1 bounds which exchanges and queues a user may configure, write, and read, but on a shared topic exchange those permissions do not restrict which routing keys a user may publish or bind. Topic authorization adds that layer. It is off until configured: with no topic permission set, RabbitMQ authorizes every topic operation, subject only to the section 1 resource permissions. Topic authorization has been available since [RabbitMQ 3.7](https://github.com/rabbitmq/rabbitmq-server/releases/tag/v3.7.0). See the [topic authorization documentation](https://www.rabbitmq.com/docs/access-control#topic-authorisation).

Topic permissions are broker records managed with `rabbitmqctl`, not entries in `rabbitmq.conf` or `advanced.config`. For an administrator-provisioned topic exchange `app.shared.topic` where the `app` user should publish and bind only its own tenant's routing keys, grant the scoped topic permission. The argument order is the user, then the exchange, then the write and read patterns:

```bash
sudo rabbitmqctl set_topic_permissions -p 'app-prod' 'app' \
  'app.shared.topic' \
  '^tenant1[.][abcdefghijklmnopqrstuvwxyz0123456789_-]+$' \
  '^tenant1[.][abcdefghijklmnopqrstuvwxyz0123456789_-]+$'
```

The write pattern gates publishing and the read pattern gates the routing keys a binding may use; both are regular expressions, not AMQP topic wildcards, so this example admits exact `tenant1.<name>` keys and excludes `#` and `*` subscriptions. Consumers still read from their queues under ordinary queue permissions, so topic authorization does not filter messages already sitting in an accessible queue, nor does it remove existing broad bindings: audit current bindings and queue grants, and reconnect clients after changing them. Topic authorization checks routing keys only on a direct publish to the topic exchange. If the section 1 resource grant lets the application declare its own exchanges, the application can bind one to the shared exchange and route a disallowed key through it without the topic write check, because a resource-name grant does not distinguish an exchange from a queue. Strong tenant isolation therefore requires the administrator to own every route into the shared exchange: deny the application configure permission so it cannot declare a relay exchange, and scope its read grant so it matches no exchange at all (for example a queue-only naming scheme such as `^app[.]q[.]`). The read grant must match no exchange because binding any readable exchange into the shared exchange needs only the write grant the application already holds for publishing. The administrator provisions the application's queues, exchanges, and bindings. Clearing a topic permission returns that exchange to the unrestricted default; it is not a deny rule. Other authorization backends enforce their own topic rules. See the [topic authorization reference](https://www.rabbitmq.com/docs/access-control#topic-authorisation) and the [rabbitmqctl command reference](https://www.rabbitmq.com/docs/man/rabbitmqctl.8).

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- RabbitMQ access control, guest restrictions, interactive user creation, and resource permissions: https://www.rabbitmq.com/docs/access-control
- RabbitMQ virtual hosts and logical isolation: https://www.rabbitmq.com/docs/vhosts
- RabbitMQ CLI user, vhost, permission, and tag commands: https://www.rabbitmq.com/docs/man/rabbitmqctl.8
- RabbitMQ inter-node TLS (distribution over TLS): https://www.rabbitmq.com/docs/clustering-ssl
- Erlang/OTP 27 distribution over TLS: https://www.erlang.org/docs/27/apps/ssl/ssl_distribution.html
- OTP 27 distribution TLS implementation (hostname verification): https://raw.githubusercontent.com/erlang/otp/OTP-27.0/lib/ssl/src/inet_tls_dist.erl
- RabbitMQ v4.4.0 launch-variable handling (rabbitmq-env): https://raw.githubusercontent.com/rabbitmq/rabbitmq-server/v4.4.0/deps/rabbit/scripts/rabbitmq-env
- RabbitMQ v4.4.0 release notes (fully supports the Erlang/OTP 28 and 29 series; they state no minimum Erlang/OTP version): https://github.com/rabbitmq/rabbitmq-server/releases/tag/v4.4.0
- RabbitMQ v4.4.0 web dispatch listeners, split into one socket per address, each socket's `ip` becoming its bind address. RabbitMQ v4.4.0 web dispatch sources: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_web_dispatch/src/rabbit_web_dispatch_sup.erl#L39-L46 and https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_web_dispatch/src/rabbit_web_dispatch_sup.erl#L174-L188
- RabbitMQ v4.4.0 per-address listener split: a listener with no `ip` gets the IPv6 wildcard, the IPv4 wildcard or both, by the host's IPv6 behaviour. RabbitMQ v4.4.0 networking sources: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/src/rabbit_networking.erl#L226-L248 and https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/src/rabbit_networking.erl#L775-L795
- RabbitMQ v4.4.0 management schema `management.tcp.ip` mapping (no default value): https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/priv/schema/rabbitmq_management.schema#L58-L60
- RabbitMQ v4.4.0 management schema `management.ssl.ip` mapping: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/priv/schema/rabbitmq_management.schema#L104-L105
- RabbitMQ v4.4.0 management schema `management.listeners.tcp.<name>` and `management.listeners.ssl.<name>` settings: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/priv/schema/rabbitmq_management.schema#L187-L203
- RabbitMQ 3.7.0 release notes (topic authorization introduction): https://github.com/rabbitmq/rabbitmq-server/releases/tag/v3.7.0
- RabbitMQ management listeners, HTTPS, and roles: https://www.rabbitmq.com/docs/management
- RabbitMQ 4.3 management documentation source, example configuration described as setting some parameters to their default values, which includes `management.tcp.ip = 0.0.0.0` (rabbitmq-website commit db23826e): https://github.com/rabbitmq/rabbitmq-website/blob/db23826ebaa810b3cdd525fd290125d65f6c3005/versioned_docs/version-4.3/management/index.md#L1365-L1381
- RabbitMQ configuration files and restart requirements: https://www.rabbitmq.com/docs/configure
- RabbitMQ plugin activation: https://www.rabbitmq.com/docs/plugins
- RabbitMQ plugin enable command: https://www.rabbitmq.com/docs/man/rabbitmq-plugins.8
- RabbitMQ HTTP API authentication and endpoints: https://www.rabbitmq.com/docs/http-api-reference
- RabbitMQ TLS, peer verification, certificate usage, and verification depth: https://www.rabbitmq.com/docs/ssl
- RabbitMQ networking, epmd lifecycle, private bindings, and distribution ports: https://www.rabbitmq.com/docs/networking
- RabbitMQ management plugin default port 15672 and the plain HTTP listener it starts when no management listener is configured (pinned tag v4.4.0). RabbitMQ management plugin sources: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L23 and https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L102-L108. More RabbitMQ management plugin sources: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L203-L208 and https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L234-L242
- RabbitMQ management plugin extra listeners from `management.listeners.*`, added after the default listeners, with a port-only entry dropping the configured `ip`, and the HTTPS listener's `ip` as its bind address (pinned tag v4.4.0). RabbitMQ management listener sources: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L134-L152 and https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L164-L177. More RabbitMQ management listener sources: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L188-L201
- RabbitMQ Erlang distribution port: `RABBITMQ_NODE_PORT` (default 5672) plus 20000 unless `RABBITMQ_DIST_PORT` is set, pinned as both `inet_dist_listen_min` and `inet_dist_listen_max`, with each `RABBITMQ_*` variable falling back to its unprefixed form and an empty value treated as unset (pinned tag v4.4.0). RabbitMQ Erlang distribution port sources: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit_common/src/rabbit_env.erl#L1247-L1283 and https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit_common/src/rabbit_env.erl#L2083-L2099. More RabbitMQ Erlang distribution port sources: https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit_common/src/rabbit_env.erl#L361-L369
- RabbitMQ `distribution.listener.port_range.min` and `.max` mapped to the Erlang kernel's `inet_dist_listen_min` and `inet_dist_listen_max` (pinned tag v4.4.0): https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/priv/schema/rabbit.schema#L2287-L2293
- RabbitMQ CLI distribution port range `RABBITMQ_CTL_DIST_PORT_MIN` (default 35672) to `RABBITMQ_CTL_DIST_PORT_MAX` (default ten above it), each empty-as-unset and falling back to the unprefixed `CTL_DIST_PORT_MIN`/`CTL_DIST_PORT_MAX` (pinned tag v4.4.0): https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/scripts/rabbitmq-env#L143-L146
- RabbitMQ `default_user`/`default_pass` guest/guest with the administrator tag, and `loopback_users` [guest] (pinned tag v4.4.0): https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/Makefile#L33-L38
- Official RabbitMQ 4.3 Docker image: `10-defaults.conf` sets `loopback_users.guest = false`, and both variants copy it into `/etc/rabbitmq/conf.d/` (pinned commit 76efb370838e36e4b120e252e75cf0dac70a7d55). Official RabbitMQ 4.3 Docker image sources: https://github.com/docker-library/rabbitmq/blob/76efb370838e36e4b120e252e75cf0dac70a7d55/4.3/ubuntu/10-defaults.conf#L8 and https://github.com/docker-library/rabbitmq/blob/76efb370838e36e4b120e252e75cf0dac70a7d55/4.3/ubuntu/Dockerfile#L321. More official RabbitMQ 4.3 Docker image sources: https://github.com/docker-library/rabbitmq/blob/76efb370838e36e4b120e252e75cf0dac70a7d55/4.3/alpine/10-defaults.conf#L8 and https://github.com/docker-library/rabbitmq/blob/76efb370838e36e4b120e252e75cf0dac70a7d55/4.3/alpine/Dockerfile#L327
- RabbitMQ diagnostics, remote node selection, and authenticated ping: https://www.rabbitmq.com/docs/man/rabbitmq-diagnostics.8
- RabbitMQ CLI authentication and Erlang cookie handling: https://www.rabbitmq.com/docs/cli
- RabbitMQ definitions imports, sensitive exports, and export transformations: https://www.rabbitmq.com/docs/definitions
- RabbitMQ administration CLI v2 configuration and TLS flags: https://www.rabbitmq.com/docs/management-cli
- RabbitMQ queues, durability, and exclusive queue behaviour: https://www.rabbitmq.com/docs/queues
- RabbitMQ channel exceptions and access-refused errors: https://www.rabbitmq.com/docs/channels
- Pika TLS context and client certificate example (mutual authentication; checked October 2026): https://pika.github.io/pika/latest/examples/tls_mutual_authentication/
- Pika 1.x `SSLOptions(context, server_hostname)` class taking an `ssl.SSLContext` (pinned tag 1.3.2; checked October 2026): https://github.com/pika/pika/blob/1.3.2/pika/connection.py#L937-L958
- Pika 1.x `ConnectionParameters` `ssl_options` argument (pinned tag 1.3.2; checked October 2026): https://github.com/pika/pika/blob/1.3.2/pika/connection.py#L579-L580
- Pika connection parameters: https://pika.github.io/pika/latest/modules/parameters/
- Pika blocking connection and channel methods: https://pika.github.io/pika/latest/modules/adapters/blocking/
- Pika authentication and authorization exceptions: https://pika.github.io/pika/latest/modules/exceptions/
- curl password prompts, TLS validation, and diagnostic flags: https://curl.se/docs/manpage.html


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- source: RabbitMQ source (v4.4.0)
- admin: rabbitmqadmin (v2)
- topic-min: RabbitMQ topic authorization introduction (3.7.0)
- docs: RabbitMQ documentation (unknown)
- image: RabbitMQ image source (76efb370838e36e4b120e252e75cf0dac70a7d55)
- management-source: RabbitMQ management documentation source (db23826ebaa810b3cdd525fd290125d65f6c3005)
- otp: Erlang/OTP distribution (27)
- curl: curl documentation (unknown)
- pika: Pika documentation (unknown)
- pika-source: Pika source (1.3.2)

Claims (full source mapping in the JSON block below):

- guest (REASONED; docs, source): Upstream guest/guest is an administrator restricted to localhost; create real users and delete or change guest.
- docker-guest (REASONED; image): Shipped official 4.3 images disable guest loopback restriction; later configuration can restore it.
- vhosts (REASONED; docs): Separate users/vhosts and remove old grants; vhosts isolate resources, not CPU or memory.
- resource-grants (REASONED; docs): Configure/write/read regexes scope app.*; amq.default is excluded; binding needs queue write and exchange read.
- roles (REASONED; docs): Tags replace previous tags and grant management authority, not resource permissions; observer gets monitoring and empty grants.
- definitions-boot (REASONED; docs): Reviewed local boot imports need no management plugin, do not overwrite existing definitions, and suppress blank-node default creation.
- definitions-runtime (REASONED; docs): Runtime imports merge, retain omitted objects and immutable conflicts, and can fail partially; they are not reconciliation.
- definitions-export (REASONED; docs, admin): v2 export transformations remove users, permissions and runtime parameters; protect TOML credentials and review remaining secrets.
- amqp-tls (REASONED; docs): Private 5671 requires trusted client certificates; remove plaintext 5672 after migration.
- tls-depth (REASONED; docs): ssl_options.depth defaults to 1; clientAuth usage and intermediate-chain depth must fit deployed certificates.
- tls-identity (REASONED; docs): mTLS does not map a RabbitMQ username; password auth remains unless certificate plugin/SASL EXTERNAL is configured.
- management-bind (REASONED; docs): Apply and restart with loopback HTTP 15672/private HTTPS 15671 before enabling management.
- management-default (REASONED; source, management-source): v4.4.0 starts plain HTTP 15672 when no management listener is configured; with no address set it binds the IPv6 and IPv4 wildcards on dual stack, the IPv6 wildcard alone on single stack and the IPv4 wildcard on IPv4-only hosts; a 4.3 docs example includes management.tcp.ip = 0.0.0.0.
- management-listeners (REASONED; source): v4.4.0 management.listeners.tcp and .ssl entries add listeners on top of the defaults, so default HTTP 15672 still starts; a port-only entry drops management.tcp.ip or management.ssl.ip and binds without an address limit.
- management-ssl-ip (REASONED; source): At v4.4.0 management.ssl.ip limits the HTTPS listener to that address; without it, HTTPS binds the same wildcard addresses as the default HTTP listener.
- management-auth (REASONED; docs): Management has separate TLS and RabbitMQ HTTP credentials; restrict admin networks and human access.
- epmd (REASONED; docs): epmd defaults to 4369; ERL_EPMD_ADDRESS requires broker and epmd restart, or socket-unit changes; loopback remains.
- distribution-port (REASONED; source, docs): Distribution defaults to node port plus 20000 (25672), pinned as equal kernel min and max; nonempty DIST_PORT replaces it; port_range keys map to the same kernel settings, with precedence not established.
- cli-ports (REASONED; source, docs): CLI defaults 35672-35682; prefixed variables fall back to unprefixed forms, treating empty as unset.
- cookie (REASONED; docs): Matching owner-only cookie files grant powerful node/CLI access; protect secret delivery and restrict peer reachability.
- distribution-tls (REASONED; docs, otp, source): Use Erlang TLS distribution for server and CLI with matching launch arguments; 4.4.0 fully supports OTP 28 and 29, and no minimum is stated.
- distribution-identity (REASONED; otp): Verify peer certificates both ways and outbound node hostnames; coordinate transport changes and retain cookie/firewall controls.
- topic-default (REASONED; docs, topic-min): Topic authorization dates from 3.7; absent or cleared topic permissions leave topic operations unrestricted by that layer.
- topic-patterns (REASONED; docs): Topic write/read regexes gate publish/binding keys; tenant1 exact keys exclude wildcard bindings, not existing queued messages.
- topic-bypass (REASONED; docs): Exchange relay can bypass direct topic-write checks; strong isolation needs admin-owned routes, no configure and queue-only read grants.
- verify-accounts (REASONED; docs): Inspect migrated vhost grants, observer tags/empty patterns and guest removal; failed listings prove nothing.
- verify-inventory (REASONED; docs): Inventory all listeners and cookie ownership/mode; local binds and mode do not establish isolation or secrecy.
- verify-network (REASONED; docs): Forbidden external connections must fail while allowed private peers connect; confirm plaintext 5672 removal with live AMQPS.
- verify-distribution (REASONED; docs): Allowed CLI host must authenticate ping to the actual node with matching cookie; TCP reachability alone is insufficient.
- verify-loopback (REASONED; docs, curl): Authenticated loopback /api/overview must return 200 while private HTTP 15672 is unreachable.
- verify-management (REASONED; docs, curl): Observer overview and ops user listing return 200; anonymous overview and observer user listing refuse with actual auth errors.
- verify-mtls (REASONED; docs): Certificate-present handshake succeeds and absent certificate gets broker-attributed rejection; server Verification: OK is insufficient.
- queue-default (REASONED; docs): RabbitMQ 4.3 disables transient non-exclusive queues by default; the protocol fixture uses a durable queue.
- verify-amqp (REASONED; docs, pika, pika-source): Pika 1.x fixture requires app round trip, observer authentication and resource-specific 403 ACCESS_REFUSED; log connection refusal reasons.
- verify-definitions (REASONED; docs, admin): Compare approved blank-node users/grants and reduced versus private full exports; empty selected sections do not prove secrecy.
- verify-distribution-tls (REASONED; docs, otp): TLS CLI/nodes succeed; plaintext and missing/untrusted certificate peers fail with TLS evidence, not cookie/DNS errors.
- verify-topic (REASONED; docs): Tenant1 operations succeed; other keys/wildcards fail; compare relay bypass with hardened route-creation denial.

````json
{
  "schema": 1,
  "checked": "2026-11-07",
  "documentation_checked": "2026-09",
  "body_sha256": "3302113b933d3e62c7b2d97eed9a8bde5b170f9485c056be3d0473d7f9421de8",
  "components": {
    "source": {
      "name": "RabbitMQ source",
      "basis": "v4.4.0",
      "sources": {
        "s9f1f8db14acc": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/Makefile#L33-L38",
        "s3e14b93fd407": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L23",
        "sfcd87fb1a469": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L102-L108",
        "s19c597b9b0c4": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L203-L208",
        "s55fa6710ead4": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L234-L242",
        "sfecb265794ac": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L134-L152",
        "s7e312a375671": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L164-L177",
        "s58bda198ac55": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/src/rabbit_mgmt_app.erl#L188-L201",
        "s70d7b769d1de": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit_common/src/rabbit_env.erl#L1247-L1283",
        "s752f79a56561": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit_common/src/rabbit_env.erl#L2083-L2099",
        "sc0a5d56dfcce": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit_common/src/rabbit_env.erl#L361-L369",
        "s22313020f9fb": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/priv/schema/rabbit.schema#L2287-L2293",
        "s2b3127ddf2a9": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/scripts/rabbitmq-env#L143-L146",
        "s0ac4ba8e9551": "https://raw.githubusercontent.com/rabbitmq/rabbitmq-server/v4.4.0/deps/rabbit/scripts/rabbitmq-env",
        "s815b3e32b081": "https://github.com/rabbitmq/rabbitmq-server/releases/tag/v4.4.0",
        "s176c9d9d819c": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_web_dispatch/src/rabbit_web_dispatch_sup.erl#L39-L46",
        "s108676baa88f": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_web_dispatch/src/rabbit_web_dispatch_sup.erl#L174-L188",
        "s5c31104b0807": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/src/rabbit_networking.erl#L226-L248",
        "s38f7e5ca992d": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbit/src/rabbit_networking.erl#L775-L795",
        "s886babdfc3ec": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/priv/schema/rabbitmq_management.schema#L58-L60",
        "s85b75e716115": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/priv/schema/rabbitmq_management.schema#L104-L105",
        "s256c6b44600f": "https://github.com/rabbitmq/rabbitmq-server/blob/v4.4.0/deps/rabbitmq_management/priv/schema/rabbitmq_management.schema#L187-L203"
      }
    },
    "admin": {
      "name": "rabbitmqadmin",
      "basis": "v2",
      "sources": {
        "sdd5688854073": "https://www.rabbitmq.com/docs/management-cli"
      }
    },
    "topic-min": {
      "name": "RabbitMQ topic authorization introduction",
      "basis": "3.7.0",
      "sources": {
        "se34f4e7886f1": "https://github.com/rabbitmq/rabbitmq-server/releases/tag/v3.7.0"
      }
    },
    "docs": {
      "name": "RabbitMQ documentation",
      "basis": "unknown",
      "sources": {
        "s8f066afff416": "https://www.rabbitmq.com/docs/access-control",
        "s348b5e1d08ae": "https://www.rabbitmq.com/docs/vhosts",
        "sf81e470be6fa": "https://www.rabbitmq.com/docs/man/rabbitmqctl.8",
        "s021280c36c46": "https://www.rabbitmq.com/docs/management",
        "s62cc3cf19b55": "https://www.rabbitmq.com/docs/definitions",
        "s59532e00cbad": "https://www.rabbitmq.com/docs/http-api-reference",
        "sffc9f05633d5": "https://www.rabbitmq.com/docs/ssl",
        "s7d28cf5cc259": "https://www.rabbitmq.com/docs/configure",
        "s73c5514e15ab": "https://www.rabbitmq.com/docs/plugins",
        "s5a539132e128": "https://www.rabbitmq.com/docs/man/rabbitmq-plugins.8",
        "sc3e3083ffb2f": "https://www.rabbitmq.com/docs/networking",
        "sa40d365d073f": "https://www.rabbitmq.com/docs/cli",
        "s02ce3c777d63": "https://www.rabbitmq.com/docs/clustering-ssl",
        "sf274b2ed7c10": "https://www.rabbitmq.com/docs/man/rabbitmq-diagnostics.8",
        "sef3085ec2cc9": "https://www.rabbitmq.com/docs/queues",
        "s008b12a42f70": "https://www.rabbitmq.com/docs/channels"
      }
    },
    "image": {
      "name": "RabbitMQ image source",
      "basis": "76efb370838e36e4b120e252e75cf0dac70a7d55",
      "sources": {
        "s9d5790722619": "https://github.com/docker-library/rabbitmq/blob/76efb370838e36e4b120e252e75cf0dac70a7d55/4.3/ubuntu/10-defaults.conf#L8",
        "s6e9f51045566": "https://github.com/docker-library/rabbitmq/blob/76efb370838e36e4b120e252e75cf0dac70a7d55/4.3/ubuntu/Dockerfile#L321",
        "se5da6700ffd7": "https://github.com/docker-library/rabbitmq/blob/76efb370838e36e4b120e252e75cf0dac70a7d55/4.3/alpine/10-defaults.conf#L8",
        "sb5b8462e18fd": "https://github.com/docker-library/rabbitmq/blob/76efb370838e36e4b120e252e75cf0dac70a7d55/4.3/alpine/Dockerfile#L327"
      }
    },
    "management-source": {
      "name": "RabbitMQ management documentation source",
      "basis": "db23826ebaa810b3cdd525fd290125d65f6c3005",
      "sources": {
        "s0aa37c76e851": "https://github.com/rabbitmq/rabbitmq-website/blob/db23826ebaa810b3cdd525fd290125d65f6c3005/versioned_docs/version-4.3/management/index.md#L1365-L1381"
      }
    },
    "otp": {
      "name": "Erlang/OTP distribution",
      "basis": "27",
      "sources": {
        "s18749583e522": "https://www.erlang.org/docs/27/apps/ssl/ssl_distribution.html",
        "s2e4092cc0780": "https://raw.githubusercontent.com/erlang/otp/OTP-27.0/lib/ssl/src/inet_tls_dist.erl"
      }
    },
    "curl": {
      "name": "curl documentation",
      "basis": "unknown",
      "sources": {
        "s2b2686afaf41": "https://curl.se/docs/manpage.html"
      }
    },
    "pika": {
      "name": "Pika documentation",
      "basis": "unknown",
      "sources": {
        "sf5430d0d7914": "https://pika.github.io/pika/latest/examples/tls_mutual_authentication/",
        "s4a943925d547": "https://pika.github.io/pika/latest/modules/parameters/",
        "s2eb4516d20ec": "https://pika.github.io/pika/latest/modules/adapters/blocking/",
        "sbb232ff4c000": "https://pika.github.io/pika/latest/modules/exceptions/"
      }
    },
    "pika-source": {
      "name": "Pika source",
      "basis": "1.3.2",
      "sources": {
        "s1c536ddcecc3": "https://github.com/pika/pika/blob/1.3.2/pika/connection.py#L937-L958",
        "s60d4abe2318e": "https://github.com/pika/pika/blob/1.3.2/pika/connection.py#L579-L580"
      }
    }
  },
  "claims": {
    "guest": {"text": "Upstream guest/guest is an administrator restricted to localhost; create real users and delete or change guest.", "components": ["docs", "source"], "sources": ["docs:s8f066afff416", "source:s9f1f8db14acc"], "status": "REASONED"},
    "docker-guest": {"text": "Shipped official 4.3 images disable guest loopback restriction; later configuration can restore it.", "components": ["image"], "sources": ["image:s9d5790722619", "image:s6e9f51045566", "image:se5da6700ffd7", "image:sb5b8462e18fd"], "status": "REASONED"},
    "vhosts": {"text": "Separate users/vhosts and remove old grants; vhosts isolate resources, not CPU or memory.", "components": ["docs"], "sources": ["docs:s8f066afff416", "docs:s348b5e1d08ae", "docs:sf81e470be6fa"], "status": "REASONED"},
    "resource-grants": {"text": "Configure/write/read regexes scope app.*; amq.default is excluded; binding needs queue write and exchange read.", "components": ["docs"], "sources": ["docs:s8f066afff416", "docs:sf81e470be6fa"], "status": "REASONED"},
    "roles": {"text": "Tags replace previous tags and grant management authority, not resource permissions; observer gets monitoring and empty grants.", "components": ["docs"], "sources": ["docs:s021280c36c46", "docs:sf81e470be6fa"], "status": "REASONED"},
    "definitions-boot": {"text": "Reviewed local boot imports need no management plugin, do not overwrite existing definitions, and suppress blank-node default creation.", "components": ["docs"], "sources": ["docs:s62cc3cf19b55"], "status": "REASONED"},
    "definitions-runtime": {"text": "Runtime imports merge, retain omitted objects and immutable conflicts, and can fail partially; they are not reconciliation.", "components": ["docs"], "sources": ["docs:s59532e00cbad", "docs:s62cc3cf19b55"], "status": "REASONED"},
    "definitions-export": {"text": "v2 export transformations remove users, permissions and runtime parameters; protect TOML credentials and review remaining secrets.", "components": ["docs", "admin"], "sources": ["docs:s62cc3cf19b55", "admin:sdd5688854073"], "status": "REASONED"},
    "amqp-tls": {"text": "Private 5671 requires trusted client certificates; remove plaintext 5672 after migration.", "components": ["docs"], "sources": ["docs:sffc9f05633d5"], "status": "REASONED"},
    "tls-depth": {"text": "ssl_options.depth defaults to 1; clientAuth usage and intermediate-chain depth must fit deployed certificates.", "components": ["docs"], "sources": ["docs:sffc9f05633d5"], "status": "REASONED"},
    "tls-identity": {"text": "mTLS does not map a RabbitMQ username; password auth remains unless certificate plugin/SASL EXTERNAL is configured.", "components": ["docs"], "sources": ["docs:s8f066afff416", "docs:sffc9f05633d5"], "status": "REASONED"},
    "management-bind": {"text": "Apply and restart with loopback HTTP 15672/private HTTPS 15671 before enabling management.", "components": ["docs"], "sources": ["docs:s021280c36c46", "docs:s7d28cf5cc259", "docs:s73c5514e15ab", "docs:s5a539132e128"], "status": "REASONED"},
    "management-default": {"text": "v4.4.0 starts plain HTTP 15672 when no management listener is configured; with no address set it binds the IPv6 and IPv4 wildcards on dual stack, the IPv6 wildcard alone on single stack and the IPv4 wildcard on IPv4-only hosts; a 4.3 docs example includes management.tcp.ip = 0.0.0.0.", "components": ["source", "management-source"], "sources": ["source:s3e14b93fd407", "source:sfcd87fb1a469", "source:s19c597b9b0c4", "source:s55fa6710ead4", "source:s176c9d9d819c", "source:s108676baa88f", "source:s5c31104b0807", "source:s38f7e5ca992d", "source:s886babdfc3ec", "management-source:s0aa37c76e851"], "status": "REASONED"},
    "management-listeners": {"text": "v4.4.0 management.listeners.tcp and .ssl entries add listeners on top of the defaults, so default HTTP 15672 still starts; a port-only entry drops management.tcp.ip or management.ssl.ip and binds without an address limit.", "components": ["source"], "sources": ["source:s256c6b44600f", "source:sfecb265794ac", "source:s7e312a375671", "source:sfcd87fb1a469"], "status": "REASONED"},
    "management-ssl-ip": {"text": "At v4.4.0 management.ssl.ip limits the HTTPS listener to that address; without it, HTTPS binds the same wildcard addresses as the default HTTP listener.", "components": ["source"], "sources": ["source:s85b75e716115", "source:s58bda198ac55", "source:s5c31104b0807", "source:s38f7e5ca992d", "source:s108676baa88f"], "status": "REASONED"},
    "management-auth": {"text": "Management has separate TLS and RabbitMQ HTTP credentials; restrict admin networks and human access.", "components": ["docs"], "sources": ["docs:s021280c36c46", "docs:s59532e00cbad"], "status": "REASONED"},
    "epmd": {"text": "epmd defaults to 4369; ERL_EPMD_ADDRESS requires broker and epmd restart, or socket-unit changes; loopback remains.", "components": ["docs"], "sources": ["docs:sc3e3083ffb2f"], "status": "REASONED"},
    "distribution-port": {"text": "Distribution defaults to node port plus 20000 (25672), pinned as equal kernel min and max; nonempty DIST_PORT replaces it; port_range keys map to the same kernel settings, with precedence not established.", "components": ["source", "docs"], "sources": ["source:s70d7b769d1de", "source:s752f79a56561", "source:sc0a5d56dfcce", "source:s22313020f9fb", "docs:sc3e3083ffb2f"], "status": "REASONED"},
    "cli-ports": {"text": "CLI defaults 35672-35682; prefixed variables fall back to unprefixed forms, treating empty as unset.", "components": ["source", "docs"], "sources": ["source:s2b3127ddf2a9", "docs:sc3e3083ffb2f"], "status": "REASONED"},
    "cookie": {"text": "Matching owner-only cookie files grant powerful node/CLI access; protect secret delivery and restrict peer reachability.", "components": ["docs"], "sources": ["docs:sa40d365d073f"], "status": "REASONED"},
    "distribution-tls": {"text": "Use Erlang TLS distribution for server and CLI with matching launch arguments; 4.4.0 fully supports OTP 28 and 29, and no minimum is stated.", "components": ["docs", "otp", "source"], "sources": ["docs:s02ce3c777d63", "otp:s18749583e522", "source:s0ac4ba8e9551", "source:s815b3e32b081"], "status": "REASONED"},
    "distribution-identity": {"text": "Verify peer certificates both ways and outbound node hostnames; coordinate transport changes and retain cookie/firewall controls.", "components": ["otp"], "sources": ["otp:s18749583e522", "otp:s2e4092cc0780"], "status": "REASONED"},
    "topic-default": {"text": "Topic authorization dates from 3.7; absent or cleared topic permissions leave topic operations unrestricted by that layer.", "components": ["docs", "topic-min"], "sources": ["docs:s8f066afff416", "topic-min:se34f4e7886f1"], "status": "REASONED"},
    "topic-patterns": {"text": "Topic write/read regexes gate publish/binding keys; tenant1 exact keys exclude wildcard bindings, not existing queued messages.", "components": ["docs"], "sources": ["docs:s8f066afff416", "docs:sf81e470be6fa"], "status": "REASONED"},
    "topic-bypass": {"text": "Exchange relay can bypass direct topic-write checks; strong isolation needs admin-owned routes, no configure and queue-only read grants.", "components": ["docs"], "sources": ["docs:s8f066afff416"], "status": "REASONED"},
    "verify-accounts": {"text": "Inspect migrated vhost grants, observer tags/empty patterns and guest removal; failed listings prove nothing.", "components": ["docs"], "sources": ["docs:s8f066afff416", "docs:sf81e470be6fa"], "status": "REASONED", "verify": [1]},
    "verify-inventory": {"text": "Inventory all listeners and cookie ownership/mode; local binds and mode do not establish isolation or secrecy.", "components": ["docs"], "sources": ["docs:sc3e3083ffb2f", "docs:sf274b2ed7c10", "docs:sa40d365d073f"], "status": "REASONED", "verify": [2]},
    "verify-network": {"text": "Forbidden external connections must fail while allowed private peers connect; confirm plaintext 5672 removal with live AMQPS.", "components": ["docs"], "sources": ["docs:sc3e3083ffb2f"], "status": "REASONED", "verify": [3, 4]},
    "verify-distribution": {"text": "Allowed CLI host must authenticate ping to the actual node with matching cookie; TCP reachability alone is insufficient.", "components": ["docs"], "sources": ["docs:sf274b2ed7c10", "docs:sa40d365d073f"], "status": "REASONED", "verify": [5]},
    "verify-loopback": {"text": "Authenticated loopback /api/overview must return 200 while private HTTP 15672 is unreachable.", "components": ["docs", "curl"], "sources": ["docs:s021280c36c46", "docs:s59532e00cbad", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [6]},
    "verify-management": {"text": "Observer overview and ops user listing return 200; anonymous overview and observer user listing refuse with actual auth errors.", "components": ["docs", "curl"], "sources": ["docs:s021280c36c46", "docs:s59532e00cbad", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [7]},
    "verify-mtls": {"text": "Certificate-present handshake succeeds and absent certificate gets broker-attributed rejection; server Verification: OK is insufficient.", "components": ["docs"], "sources": ["docs:sffc9f05633d5"], "status": "REASONED", "verify": [8]},
    "queue-default": {"text": "RabbitMQ 4.3 disables transient non-exclusive queues by default; the protocol fixture uses a durable queue.", "components": ["docs"], "sources": ["docs:sef3085ec2cc9"], "status": "REASONED"},
    "verify-amqp": {"text": "Pika 1.x fixture requires app round trip, observer authentication and resource-specific 403 ACCESS_REFUSED; log connection refusal reasons.", "components": ["docs", "pika", "pika-source"], "sources": ["docs:s8f066afff416", "docs:sef3085ec2cc9", "docs:s008b12a42f70", "pika:sf5430d0d7914", "pika:s4a943925d547", "pika:s2eb4516d20ec", "pika:sbb232ff4c000", "pika-source:s1c536ddcecc3", "pika-source:s60d4abe2318e"], "status": "REASONED", "verify": [9]},
    "verify-definitions": {"text": "Compare approved blank-node users/grants and reduced versus private full exports; empty selected sections do not prove secrecy.", "components": ["docs", "admin"], "sources": ["docs:sf81e470be6fa", "docs:s62cc3cf19b55", "admin:sdd5688854073", "docs:s59532e00cbad"], "status": "REASONED", "verify": [10]},
    "verify-distribution-tls": {"text": "TLS CLI/nodes succeed; plaintext and missing/untrusted certificate peers fail with TLS evidence, not cookie/DNS errors.", "components": ["docs", "otp"], "sources": ["docs:s02ce3c777d63", "otp:s18749583e522"], "status": "REASONED", "verify": [11]},
    "verify-topic": {"text": "Tenant1 operations succeed; other keys/wildcards fail; compare relay bypass with hardened route-creation denial.", "components": ["docs"], "sources": ["docs:s8f066afff416", "docs:sf81e470be6fa"], "status": "REASONED", "verify": [12]}
  }
}
````
<!-- version-basis:end -->
