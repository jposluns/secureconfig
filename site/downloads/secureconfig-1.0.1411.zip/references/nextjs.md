# Next.js: authentication that actually gates Route Handlers, Server Actions, and data

Next.js is a React framework for web apps that combine pages and server code. This guide helps your AI assistant secure it, including auth checks next to the data at every entry point, hardened session cookies, a loopback bind when self-hosted, and no secrets in the browser bundle.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/nextjs.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Next.js listener source v16.3.6, Node.js listener source v22.22.1, and Commander 12.1.0; 6 further sources carry no recorded version. Metadata reviewed 2026-09-26; documentation checked September 2026. The guide records 32 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

A Next.js app has many entry points: pages, layouts, Route Handlers (`app/**/route.ts`), and every exported Server Action, which the Next.js docs describe as reachable by a direct POST whether or not your UI calls it. A check that lives only in a layout or in `proxy.ts` (the file Next.js 16 renamed from `middleware.ts`) leaves open the entry points it does not cover (a layout guards no Route Handler or Server Action; a `proxy.ts` matcher guards only the paths it matches), and authorization still belongs next to the data. Next.js supplies cookies and sessions as primitives, not a login system; the login is yours or a library's.

## 1. Bind privately; TLS comes from the platform or the proxy

On Vercel and similar platforms the platform terminates TLS; nothing to configure ([paas.md](paas.md)). Self-hosted, `next start` listens on every interface on port 3000 by default (as of v16.3.6 its `--port` defaults to 3000 and it passes no hostname to Node's `listen`, which binds `::` where IPv6 is available and `0.0.0.0` otherwise; its `-H` option's help text still says `(default: 0.0.0.0)`). The step for a self-hosted app is to bind to loopback and put a reverse proxy in front, which the Next.js self-hosting guide itself recommends, with TLS and headers per [nodejs.md](nodejs.md), [nginx.md](nginx.md), or [caddy.md](caddy.md).

```bash
next build && next start -H 127.0.0.1 -p 3000    # or PORT=3000; PORT cannot be set in .env
```

## 2. Put the check where the data is

The Next.js authentication guide's rule: create a Data Access Layer (DAL) with a `verifySession()` function and call it from every data request, Server Action, and Route Handler. Its reasons, paraphrased from the authentication and data-security guides:

- Layouts do not re-render on client navigation, so a session check there does not run on every route change, and a layout that returns `null` does not stop nested segments or Server Actions from running.
- Server Actions and Route Handlers get "the same security considerations as public-facing API endpoints"; a page-level check "does not extend to the Server Actions defined within it".
- Proxy "should not be your only line of defense": use it for optimistic redirects that read the cookie only, never database lookups. A `matcher` change can silently remove Proxy coverage from a Server Action.

```ts
// app/lib/dal.ts
import 'server-only'
import { cache } from 'react'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { decrypt } from '@/app/lib/session'

export const verifySession = cache(async () => {
  const session = await decrypt((await cookies()).get('session')?.value)
  if (!session?.userId) redirect('/login')
  return { isAuth: true, userId: session.userId, role: session.role }
})

// app/api/admin/route.ts: the handler checks for itself (return 401 here instead of redirecting if you prefer)
export async function GET() {
  const session = await verifySession()
  if (session.role !== 'admin') return new Response(null, { status: 403 })
}

// app/actions.ts: so does every Server Action; the page that renders the form does not count
'use server'
export async function deleteRecord(formData: FormData) {
  const session = await verifySession()
  if (session.role !== 'admin') return null
}
```

Also check ownership of the specific resource inside the DAL (authorization, not only authentication), and return only the fields the client needs. The snippets above are fragments: `session.role` must come from your trusted user store (not from the cookie alone for sensitive checks), and each handler still returns its real success response, so wire in your own imports and data calls.

## 3. Sessions: signed payload, hardened cookie

```bash
openssl rand -base64 32      # SESSION_SECRET, set in the environment; never with a NEXT_PUBLIC_ prefix
```

```ts
// app/lib/session.ts (the guide's stateless session, using jose)
import 'server-only'
import { SignJWT, jwtVerify } from 'jose'
import { cookies } from 'next/headers'
const key = new TextEncoder().encode(process.env.SESSION_SECRET)

export async function createSession(userId: string, role: string) {
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
  const session = await new SignJWT({ userId, role, expiresAt })
    .setProtectedHeader({ alg: 'HS256' }).setIssuedAt().setExpirationTime('7d').sign(key)
  ;(await cookies()).set('session', session, { httpOnly: true, secure: true, expires: expiresAt, sameSite: 'lax', path: '/' })
}
```

`decrypt()` is `jwtVerify(session, key, { algorithms: ['HS256'] })`, returning the payload or `undefined`. Cookies can only be set or deleted in a Server Function or Route Handler; logout is `(await cookies()).delete('session')`. Keep the payload to the user ID and role, no PII. For sensitive operations the guide recommends database sessions verified against the store, not the cookie alone.

## 4. Keep secrets out of the client bundle

- `NEXT_PUBLIC_*` variables are inlined into the JavaScript sent to the browser at `next build`; every other variable is server-only BY DEFAULT, but a variable placed in `next.config.js`'s `env` key is also inlined into the client bundle regardless of prefix, so never put a secret there. A secret with a `NEXT_PUBLIC_` prefix is published to every visitor ([secrets.md](secrets.md)). Only the DAL should read `process.env`; `.env*` files stay in `.gitignore`.
- More than one self-hosted instance: set `NEXT_SERVER_ACTIONS_ENCRYPTION_KEY` (base64, 16, 24, or 32 decoded bytes) at build so all instances share the Server Action closure key. The docs say not to rely on that encryption to hide secrets.
- Server Actions abort when `Origin` does not match `Host` (or `X-Forwarded-Host`). Behind a proxy whose host differs from the public domain, list the public origins in `experimental.serverActions.allowedOrigins` in `next.config.js`.

## 5. Libraries

**Auth.js** (https://authjs.dev/): `AUTH_SECRET` is the one mandatory variable; `npx auth secret` writes it to `.env.local`.

```ts
// auth.ts
import NextAuth from "next-auth"
export const { handlers, signIn, signOut, auth } = NextAuth({ providers: [] })
// app/api/auth/[...nextauth]/route.ts
import { handlers } from "@/auth"
export const { GET, POST } = handlers
```

Providers are configured from `AUTH_<PROVIDER>_ID`, `AUTH_<PROVIDER>_SECRET`, and for OIDC `AUTH_<PROVIDER>_ISSUER`; provider setup and the allowlist check are in [oidc-integration.md](oidc-integration.md) and [identity-providers.md](identity-providers.md). Behind a reverse proxy set `AUTH_TRUST_HOST=true` (automatic on Vercel). Server code calls `const session = await auth()`. Wrapping a Route Handler with `auth(...)` only fills in `req.auth`; nothing refuses the request for you, so the handler must check the session, then authorize, then touch data:

```ts
// app/api/notes/route.ts
import { NextResponse } from "next/server"
import { auth } from "@/auth"
// isAllowed and loadNotes are your app's own functions
export const GET = auth(async function GET(req) {
  if (!req.auth) return NextResponse.json({ message: "Not authenticated" }, { status: 401 })  // no automatic 401
  if (!isAllowed(req.auth.user)) return NextResponse.json({ message: "Forbidden" }, { status: 403 })  // your allowlist
  return NextResponse.json(await loadNotes(req.auth.user))
})
```

`export { auth as proxy }` in `proxy.ts` is the optimistic layer, but with an empty `providers` and no `callbacks.authorized` it authorizes every request by default, so add an `authorized` callback (or a redirecting wrapper) if you use it to gate; Auth.js says not to rely on it exclusively regardless. MFA is not part of this configuration; enforce it at the identity provider ([mfa.md](mfa.md)).

**Better Auth** (https://better-auth.com/docs/introduction): `BETTER_AUTH_SECRET` (32+ characters, `openssl rand -base64 32`) and `BETTER_AUTH_URL`; the placeholder default secret throws in production.

```ts
// lib/auth.ts
import { betterAuth } from "better-auth"
import { nextCookies } from "better-auth/next-js"
import { twoFactor } from "better-auth/plugins"
export const auth = betterAuth({
  baseURL: "https://app.example.com",             // set explicitly; the docs advise against request inference
  trustedOrigins: ["https://app.example.com"],    // scoped origin/CSRF + callbackURL validation; the general check skips GET/HEAD/OPTIONS (some endpoints still validate callbackURL on GET); NOT an app-route gate, so keep authn+authz per route
  emailAndPassword: { enabled: true },            // default false
  plugins: [twoFactor(), nextCookies()],          // nextCookies lets Server Actions set the session cookie
})
// app/api/auth/[...all]/route.ts
import { toNextJsHandler } from "better-auth/next-js"
export const { GET, POST } = toNextJsHandler(auth)
```

Server-side check: assign and REJECT - `const session = await auth.api.getSession({ headers: await headers() })`, then reject before authorizing. The rejection differs by surface: a Route Handler returns `new Response(null, { status: 401 })`; a Server Component redirects or throws; a Server Action redirects, throws, or returns a serializable error, since a `Response` is not a valid Server Component render result or Server Action return value. Do this in Route Handlers, Server Actions, and Server Components; calling `getSession` and discarding its result gates nothing. `getSessionCookie(request)` in `proxy.ts` only proves a cookie exists; Better Auth says to check in each page and route. `twoFactor()` makes TOTP (default), emailed or SMS OTP, and backup codes AVAILABLE, not enrolled or enforced: users must enroll, emailed or SMS OTP additionally needs `otpOptions.sendOTP`, and requiring 2FA for an operation is a separate check. Add `twoFactorClient()` from `better-auth/client/plugins` on the client and run the schema migration the plugin page documents before enabling it.

## 6. Vercel: Deployment Protection is not user authentication

Deployment Protection controls who can open a deployment URL: Vercel Authentication admits Vercel users with access to the project; Passport, Password Protection, and Trusted IPs are Enterprise or paid add-on options. Standard Protection covers previews and generated URLs but not production domains; selecting the All Deployments scope for Vercel Authentication extends it to production, and Vercel's changelog of 9 September 2026 makes that free on every plan including Hobby, where protecting production previously required a paid Advanced Deployment Protection add-on (at the time of writing). Availability is not activation: the production domain stays public until All Deployments is configured. It gates your team's previews; your users are not Vercel users, so production still needs section 2 ([paas.md](paas.md)).

## Verify

REASONED: following block; the listener inventory, with the anonymous route, authorized route and client-secret checks in the three blocks after it, each marked in its own first line. No deployed application or session controls are available, so no route or session outcome is recorded here; expectations are reasoned from the cited Next.js, auth-library, curl and grep sources. On 2026-10-13 (UTC), with Bash 5.3.9, a stubbed curl and dummy values typed at a pty's hidden prompts, the cookie and secret-scan subshells each traced two lines under `bash -x` (`trap -` and `set +x +a +e`), none holding a dummy value; with `set +x` removed, the dummies appeared in 3 and 1 trace lines. An interactive Bash given each subshell wrote a history file holding the block's lines and no dummy value, and the stub received each cookie only on stdin. Those bash -x, history and stub runs covered earlier forms, when all four checks shared one block: the cookie subshell before it took the application's host on a guarded `set --` line, and the secret scan while its FINDING and error arms ended with status 0. The repository gate suite's bash -n and ShellCheck 0.11.0 passes over every block cover the current forms of the four blocks. Stub runs on 2026-10-31 with Bash 5.3.9, stub curl and ss, real grep on a scratch build directory, a pty for the hidden prompts and no network ran the guards and every status below, on the current forms of the listener inventory and secret scan and on the earlier form of the two route checks, which lowercased the host with `tr` before refusing reserved names. The tracing and history runs were not repeated. The route checks now refuse a reserved name under bash's `nocasematch` option instead of through `tr`, and refuse with 2, saying the block needs bash, when `shopt` fails, as it does in dash. That current form is covered by curl-stub runs on 2026-11-01 with no network and no terminal. In bash, each route check refused example.com, example.net, example.org and their subdomains in lower, upper and mixed case with 2 and no curl call, also with `tr` absent from PATH or failing and under an inherited `nocasematch`, `readonly`, `declare -i` or `set -e`. A host name outside the reserved names reached the anonymous check's two curl calls and the authorized check's hidden prompt, which failed with 3 without a terminal. Under dash, stub runs of the current form refused every host name in each route check with 2 and the bash message before any curl call or prompt, except that under an inherited `set -e` the authorized check ended with status 1 at its `trap` line, which dash rejects, as it did before this change. Each block exits 2 when a guard refuses and 3 when a command it attempts fails, a hidden-prompt read included. The listener inventory refuses with status 2 when `ss` is not installed, and an `ss` that runs and fails gives 3. The secret scan exits 1 when grep finds the secret and 0 when it does not; the route answers and the listener table are left unclassified, and each block's last line names what it leaves for you to judge. Paste each cookie value and the secret alone at its hidden prompt: a multi-line paste feeds every line after the first to the next prompt or to your shell, which runs it.

```bash
(                                       # a subshell, so the exits below end only the subshell
  set +e                                # errexit off here, so a failed ss is reported below instead of ending the block
  command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }   # a missing ss is a guard refusal; an ss that runs and fails is 3 below
  ss -tlnp   # read every listener; 3000 on 127.0.0.1 only when self-hosted. ss shows the BIND, not the
             # firewall or the platform ingress, so confirm external reachability separately
  case "$?" in
    0) echo "unclassified observation: the listener table above is not classified, so judge it yourself"; exit 0 ;;
    *) echo "ss -tlnp exit $?: there is no listener table to judge; inconclusive"; exit 3 ;;
  esac
)
```

```bash
# REASONED: anonymous route checks follow the cited Next.js authentication guide and curl manual; no deployed application is available, so no route outcome is recorded.
# Protected routes WITHOUT a cookie. This guide's verifySession() redirects to /login, so an unauthenticated
# Route Handler or page returns a 3xx to /login (or 401/403 if you chose the "return 401" variant); a
# streamed redirect can instead be a 200 whose body is a client-side redirect shell, not the protected content, so read the BODY, not the status
# alone. --noproxy so no client proxy answers. Save each body and confirm it carries NO protected payload:
(                                       # a subshell, so your own script arguments are untouched
  set +e                                # errexit off here, so a failed request is recorded below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_APP_HOST'   # the public host name your Next.js app is served on, no scheme, user name, port, path, query, fragment, percent sign or trailing dot: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
  case "$1" in
    example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -u nocasematch   # every match below compares letter case exactly again
  set -- "$1" 0                         # the 2nd value is the block's status so far: 3 if a request fails, otherwise 0, because you judge the answers
  curl -q -g -sS --noproxy '*' -o admin-nocookie.txt -w 'http=%{http_code} loc=%{redirect_url}\n' "https://$1/api/admin"   # 3xx to /login, or 401/403; admin-nocookie.txt must hold no admin data
  case "$?" in 0) ;; *) echo "curl exit $?: the /api/admin request failed; inconclusive"; set -- "$1" 3 ;; esac
  curl -q -g -sS --noproxy '*' -o dash-nocookie.txt  -w 'http=%{http_code} loc=%{redirect_url}\n' "https://$1/dashboard"    # 3xx with loc=/login, or a 200 redirect shell; dash-nocookie.txt must NOT contain dashboard content (a streamed redirect saves a shell, not the login page)
  case "$?" in 0) ;; *) echo "curl exit $?: the /dashboard request failed; inconclusive"; set -- "$1" 3 ;; esac
  echo "block exit $2; the status codes, redirect targets and the bodies saved in admin-nocookie.txt and dash-nocookie.txt are not classified, so judge them yourself"
  exit "$2"
)
```

```bash
# REASONED: authorized route controls and hidden cookie input follow the cited Next.js authentication guide and curl manual; no deployed application or session cookies are available.
# POSITIVE controls, so a denial above is the auth check firing and not a route broken for everyone. Put the
# app's host name and then the cookie's NAME on the set -- line - this guide's example uses `session`, Better Auth uses
# `better-auth.session_token` (or `__Secure-better-auth.session_token` with secure cookies) - and paste a
# real, freshly issued cookie VALUE at each hidden prompt. Test the admin route with an admin AND a non-admin
# cookie (authorization, not only authentication), and confirm each success body is the real protected
# content, not a login page. Each cookie reaches curl on stdin (--header @-), never argv. The hidden prompt
# keeps the cookies out of shell history and the block's set +x keeps them out of set -x tracing; neither hides
# them from the account owner or root. Paste this subshell by itself: without bracketed paste, lines pasted
# after its closing ) are read as the cookies instead.
(
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  set +x +a +e
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_APP_HOST' 'session'   # the same app host name as the no-cookie check above, no scheme, user name, port, path, query, fragment, percent sign or trailing dot, then the cookie NAME: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo 'paste the whole block, including its set -- line; not probing'; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo 'the set -- line needs exactly 2 values; not probing'; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
  case "$1" in
    example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -u nocasematch   # every match below compares letter case exactly again
  case "$2" in
    ''|*[!abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-]*) echo 'the set -- line takes the cookie NAME second (letters, digits, . _ -); not probing'; exit 2 ;;
  esac
  { unset -n cookie_value && unset -v cookie_value; } 2>/dev/null ||
    { echo 'cannot initialize cookie input; not probing'; exit 2; }
  { unset -n IFS; } 2>/dev/null || { echo 'a readonly IFS is set in this shell; not probing'; exit 2; }
  set -- "$1" "$2" 0                    # the 3rd value is the block's status so far: 3 if a request fails, otherwise 0, because you judge the answers
  IFS= read -r -s -p 'ADMIN session cookie VALUE (input hidden), then Enter: ' cookie_value < /dev/tty ||
    { printf '\n'; echo 'admin cookie input failed; not probing'; exit 3; }
  printf '\n'
  case "$cookie_value" in
    ''|*[[:cntrl:]]*) echo 'a valid admin session cookie value is required; not probing'; exit 2 ;;
  esac
  printf 'Cookie: %s=%s\n' "$2" "$cookie_value" |
    curl -q -g -sS --noproxy '*' -o dash-auth.txt  -w 'http=%{http_code}\n' --header @- "https://$1/dashboard"   # expect 200; dash-auth.txt is the dashboard, not /login
  case "$?" in 0) ;; *) echo "curl exit $?: the admin /dashboard request failed; inconclusive"; set -- "$1" "$2" 3 ;; esac
  printf 'Cookie: %s=%s\n' "$2" "$cookie_value" |
    curl -q -g -sS --noproxy '*' -o admin-auth.txt -w 'http=%{http_code}\n' --header @- "https://$1/api/admin"    # admin cookie: 200
  case "$?" in 0) ;; *) echo "curl exit $?: the admin /api/admin request failed; inconclusive"; set -- "$1" "$2" 3 ;; esac
  IFS= read -r -s -p 'NON-ADMIN session cookie VALUE (input hidden), then Enter: ' cookie_value < /dev/tty ||
    { printf '\n'; echo 'non-admin cookie input failed; not probing'; exit 3; }
  printf '\n'
  case "$cookie_value" in
    ''|*[[:cntrl:]]*) echo 'a valid non-admin session cookie value is required; not probing'; case "$3" in 0) exit 2 ;; esac; exit "$3" ;;
  esac
  printf 'Cookie: %s=%s\n' "$2" "$cookie_value" |
    curl -q -g -sS --noproxy '*' -o admin-nonadmin.txt -w 'http=%{http_code} loc=%{redirect_url}\n' --header @- "https://$1/api/admin"   # a non-admin cookie here must be 403 or a /login redirect, and admin-nonadmin.txt must hold no admin data; this means nothing unless the admin run got 200
  case "$?" in 0) ;; *) echo "curl exit $?: the non-admin /api/admin request failed; inconclusive"; set -- "$1" "$2" 3 ;; esac
  echo "block exit $3; the status codes, redirect targets and the bodies saved in dash-auth.txt, admin-auth.txt and admin-nonadmin.txt are not classified, so judge them yourself"
  exit "$3"
)
```

```bash
# REASONED: the client-bundle secret scan follows the cited Next.js environment-variable guide and GNU grep manual; no application build is available.
# Secret scan of the client bundle: search the FULL secret (not a prefix), require the build to exist, and
# read grep's exit status separately (run inline under set -e, a clean grep's exit 1 would abort the block).
# Paste the session-signing secret at the hidden prompt; it reaches grep on stdin (-f - reads the patterns
# from stdin), never argv, with the same limits as above. Paste this subshell by itself too: without
# bracketed paste, a line pasted after its closing ) is searched for instead, and its clean result then means nothing.
(
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  set +x +a +e
  { unset -n session_secret && unset -v session_secret; } 2>/dev/null ||
    { echo 'cannot initialize secret input; not scanning'; exit 2; }
  { unset -n IFS; } 2>/dev/null || { echo 'a readonly IFS is set in this shell; not scanning'; exit 2; }
  [ -d .next/static ] || { echo 'no .next/static here: run next build first; not scanning'; exit 2; }
  IFS= read -r -s -p 'SESSION_SECRET value (input hidden), then Enter: ' session_secret < /dev/tty ||
    { printf '\n'; echo 'secret input failed; not scanning'; exit 3; }
  printf '\n'
  case "$session_secret" in
    ''|*[[:cntrl:]]*) echo 'the full secret is required; not scanning'; exit 2 ;;
  esac
  if printf '%s\n' "$session_secret" | grep -rIlF -f - -- .next/static; then
    echo "FINDING: the secret is in the browser bundle"; set -- 1
  else
    set -- "$?"                         # grep's exit status, taken in the else branch, so no named variable holds it
    case "$1" in
      1) echo "clean: secret not found in the bundle"; set -- 0 ;;
      *) echo "error: grep exited $1, result inconclusive"; set -- 3 ;;
    esac
  fi
  echo "block exit $1; a clean grep is evidence, not proof: an encoded or split value, your other secrets and the Server Action steps below are not checked here, so judge them yourself"
  exit "$1"
)
# a clean grep is evidence not proof (a bundler can split or encode a value); scan for your other secrets too.
# Server Action authorization: create a FRESH disposable record before EACH attempt (an authorized mutation
# changes the precondition - after a delete, a replay would 'not find' the record and look refused when it
# was merely gone). 1) authorized: run it and confirm the store changed (positive control). 2) recreate the
# record, replay the SAME request with no cookie, then as an unauthorized user - each must be refused by an
# authorization error (not not-found) with NO change to the store (check the store directly, not the UI).
```

## Common mistakes

- Checking the session in `app/layout.tsx` or `proxy.ts` only; a Server Action or `route.ts` outside its matcher coverage is still open.
- A Proxy `matcher` that excludes `/api`, with nothing in the Route Handlers themselves.
- Naming a secret `NEXT_PUBLIC_*`, or treating Vercel Authentication as production login.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- Next.js authentication guide: https://nextjs.org/docs/app/guides/authentication ; data security guide: https://nextjs.org/docs/app/guides/data-security
- Next.js `proxy.js`: https://nextjs.org/docs/app/api-reference/file-conventions/proxy ; `route.js`: https://nextjs.org/docs/app/api-reference/file-conventions/route ; `cookies`: https://nextjs.org/docs/app/api-reference/functions/cookies
- Next.js environment variables: https://nextjs.org/docs/app/guides/environment-variables ; CLI (`next start` defaults): https://nextjs.org/docs/app/api-reference/cli/next ; self-hosting: https://nextjs.org/docs/app/guides/self-hosting
- Auth.js protecting resources (Route Handler `req.auth` check): https://authjs.dev/getting-started/session-management/protecting
- Auth.js installation: https://authjs.dev/getting-started/installation ; deployment (`AUTH_SECRET`, `AUTH_TRUST_HOST`, provider variables): https://authjs.dev/getting-started/deployment ; protecting resources: https://authjs.dev/getting-started/session-management/protecting
- Better Auth introduction: https://better-auth.com/docs/introduction ; installation: https://better-auth.com/docs/installation ; options: https://better-auth.com/docs/reference/options ; Next.js integration: https://better-auth.com/docs/integrations/next ; two-factor plugin: https://better-auth.com/docs/plugins/2fa
- Vercel Deployment Protection: https://vercel.com/docs/deployment-protection
- Vercel changelog, protect production deployments for free on every plan (9 September 2026): https://vercel.com/changelog/protect-production-deployments-for-free-on-every-plan
- Next.js `next start` declares `-H, --hostname` with help text only and no default value, unlike `--port`'s `.default(3000)` just above it, both under `.command('start')` (pinned tag v16.3.6): https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/bin/next.ts#L436-L458
- Next.js `next start` copies `options.hostname` into `hostname` unchanged (pinned tag v16.3.6): https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/cli/next-start.ts#L44
- Next.js `next start` passes that `hostname` to `startServer({ ... hostname, ... })` (pinned tag v16.3.6): https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/cli/next-start.ts#L84-L87
- Next.js `startServer` destructures `hostname` from `serverOptions` with no default (pinned tag v16.3.6): https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/server/lib/start-server.ts#L187-L196
- Next.js calls `server.listen(port, hostname)` (pinned tag v16.3.6): https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/server/lib/start-server.ts#L309
- Node.js `server.listen()` without a host binds the unspecified IPv6 address `::` when available, otherwise `0.0.0.0`: https://github.com/nodejs/node/blob/v22.22.1/doc/api/net.md
- Commander 12.1.0 (the version Next.js v16.3.6 pins): an option that takes a value is `undefined` unless specified on the command line: https://github.com/tj/commander.js/blob/v12.1.0/Readme.md#L203-L205
- Next.js v16.3.6 pins `commander` at `12.1.0` (pinned tag v16.3.6): https://github.com/vercel/next.js/blob/v16.3.6/packages/next/package.json#L246
- curl `--header @-` (header lines read from stdin): https://curl.se/docs/manpage.html#-H . GNU grep `-f -` ("When file is '-', read patterns from standard input"), `-l` ("print the name of each input file from which output would normally have been printed") and its exit status (0 if a line is selected, 1 if none, 2 on error). GNU grep sources: https://www.gnu.org/software/grep/manual/html_node/Matching-Control.html , https://www.gnu.org/software/grep/manual/html_node/General-Output-Control.html and https://www.gnu.org/software/grep/manual/html_node/Exit-Status.html


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- next-pin: Next.js listener source (v16.3.6)
- next: Next.js documentation (unknown)
- node: Node.js listener source (v22.22.1)
- commander: Commander (12.1.0)
- authjs: Auth.js (unknown)
- better: Better Auth (unknown)
- vercel: Vercel documentation (unknown)
- curl: curl (unknown)
- grep: GNU grep (unknown)

Claims (full source mapping in the JSON block below):

- entrypoints (REASONED; next): Pages, layouts, handlers and exported Actions are distinct entry points; Actions accept direct POST. Next.js 16 renamed middleware.ts to proxy.ts; session primitives are not login.
- start-default (REASONED; next-pin, node, commander): v16.3.6 next start defaults 3000 and no hostname: Node binds :: when available, else 0.0.0.0 despite -H help. Pinned Commander leaves unspecified value options undefined.
- private-tls (REASONED; next): Build then next start -H 127.0.0.1 -p 3000 with TLS proxy; PORT cannot be set in .env. Hosted TLS comes from the platform.
- dal (REASONED; next): Call DAL verifySession for every data request, handler and Action; authorize resource ownership and return only needed fields.
- layouts (REASONED; next): Layouts do not rerender on every navigation; returning null does not stop nested segments or Actions.
- proxy (REASONED; next): Proxy is an optimistic cookie-only redirect layer, not sole authorization; avoid database lookups and account for matcher changes.
- role (REASONED; next): Handler/action examples independently require admin; sensitive roles come from trusted user storage. Fragments need imports, data calls and real success responses.
- session-secret (REASONED; next): Generate a 32-byte random SESSION_SECRET in server environment, never NEXT_PUBLIC_.
- session-jwt (REASONED; next): jose session signs HS256 with seven-day expiry; decrypt verifies only HS256 and returns payload/undefined. User ID/role only, no PII; sensitive work uses database-verified sessions.
- session-cookie (REASONED; next): Set HttpOnly, Secure, SameSite=Lax, path / and seven-day expiry; only Server Functions/handlers set/delete cookies, with logout deleting session.
- public-env (REASONED; next): NEXT_PUBLIC_ is inlined at build; next.config.js env is client-inlined regardless of prefix. Read secrets only in DAL and ignore .env files.
- action-key (REASONED; next): Self-hosted instances share NEXT_SERVER_ACTIONS_ENCRYPTION_KEY at build, base64 decoding to 16/24/32 bytes; closure encryption is not secret protection.
- action-origin (REASONED; next): Actions abort when Origin mismatches Host/X-Forwarded-Host; proxies can configure experimental.serverActions.allowedOrigins.
- authjs-secret (REASONED; authjs): AUTH_SECRET is mandatory; npx auth secret writes .env.local.
- authjs-providers (REASONED; authjs): Configure provider ID/SECRET and OIDC ISSUER variables, real providers and linked allowlist checks.
- authjs-trust (REASONED; authjs): Set AUTH_TRUST_HOST=true behind a reverse proxy; Vercel sets trust automatically.
- authjs-route (REASONED; authjs): auth() reads sessions; wrapped handlers only populate req.auth and must deny missing sessions and failed authorization before data.
- authjs-proxy (REASONED; authjs): auth as proxy with empty providers and no authorized callback permits all requests; add callback/wrapper and resource checks. Enforce MFA at the identity provider.
- better-secret (REASONED; better): BETTER_AUTH_SECRET needs 32+ characters; production rejects the placeholder default. Set BETTER_AUTH_URL/baseURL explicitly, not request inference.
- better-origins (REASONED; better): trustedOrigins scopes origin/CSRF and callbackURL checks, not app-route access; general checks skip GET/HEAD/OPTIONS with endpoint-specific GET callback checks.
- better-password (REASONED; better): Better Auth emailAndPassword defaults disabled; enable explicitly when used.
- better-next (REASONED; better): nextCookies enables Action session-cookie writes; toNextJsHandler exports auth GET/POST routes.
- better-session (REASONED; better): Reject missing getSession before authorization: handler 401, component redirect/throw, action redirect/throw/serializable error. Discarding results or checking cookie existence gates nothing.
- better-mfa (REASONED; better): twoFactor makes TOTP, emailed/SMS OTP and backups available, not enrolled/enforced; OTP needs sendOTP, client needs twoFactorClient and migration, operations need separate 2FA checks.
- vercel-methods (REASONED; vercel): Deployment Protection admits project-authorized Vercel users; Passport, Password Protection and Trusted IPs need Enterprise/paid add-ons, not app-user authentication.
- vercel-scope (REASONED; vercel): Standard Protection excludes production domains; enable All Deployments. Cited 9 September 2026 announcement makes Vercel Authentication production scope free on all plans including Hobby.
- verify-bind (REASONED; next): ss inventories loopback 3000; it does not prove firewall/platform ingress isolation.
- verify-anonymous (REASONED; next): Anonymous admin/dashboard must contain no protected data: login 3xx, chosen 401/403, or streamed 200 redirect shell require reading saved bodies.
- verify-authorized (REASONED; next): Authorized dashboard/admin controls must return real content; non-admin must deny admin data, meaningful only after admin success.
- verify-cookie-input (REASONED; curl): Prompt cookie values without echo and send through curl stdin; hidden prompt and set +x keep them from argv, history and tracing, not the account owner or root; assumes clean shell and separate subshell pastes.
- verify-secret (REASONED; next, grep): Require .next/static, prompt full literal secret and send to grep stdin: 0 leak, 1 no literal match, other codes inconclusive. Encoded/split secrets can escape.
- verify-action (REASONED; next): Fresh disposable record per Action attempt; authorized mutation changes store, anonymous/unauthorized replays deny without changes, not merely not-found.

````json
{
  "schema": 1,
  "checked": "2026-09-26",
  "documentation_checked": "2026-09",
  "body_sha256": "820ab8251dc6cf70aaabc5d5a5bc58ab9659a931c6b8b943dfc9cec806feff72",
  "components": {
    "next-pin": {
      "name": "Next.js listener source",
      "basis": "v16.3.6",
      "sources": {
        "s11ffc231f0c3": "https://github.com/vercel/next.js/blob/v16.3.6/packages/next/package.json#L246",
        "s3b0feef8ec0f": "https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/bin/next.ts#L436-L458",
        "s0ef9150d51e4": "https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/cli/next-start.ts#L44",
        "sefdefa3425c6": "https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/cli/next-start.ts#L84-L87",
        "s66bd2ed9c346": "https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/server/lib/start-server.ts#L187-L196",
        "s2b4479b3c1d2": "https://github.com/vercel/next.js/blob/v16.3.6/packages/next/src/server/lib/start-server.ts#L309"
      }
    },
    "next": {
      "name": "Next.js documentation",
      "basis": "unknown",
      "sources": {
        "s066f8a176a52": "https://nextjs.org/docs/app/api-reference/cli/next",
        "scd5749a71a79": "https://nextjs.org/docs/app/api-reference/file-conventions/proxy",
        "sc2a39ce10fe1": "https://nextjs.org/docs/app/api-reference/file-conventions/route",
        "sfbc4364fb5cc": "https://nextjs.org/docs/app/api-reference/functions/cookies",
        "sa45045bebccb": "https://nextjs.org/docs/app/guides/authentication",
        "s23a087193901": "https://nextjs.org/docs/app/guides/data-security",
        "s964651d4eed4": "https://nextjs.org/docs/app/guides/environment-variables",
        "s353c30dff99f": "https://nextjs.org/docs/app/guides/self-hosting"
      }
    },
    "node": {
      "name": "Node.js listener source",
      "basis": "v22.22.1",
      "sources": {
        "sfb3e306c102d": "https://github.com/nodejs/node/blob/v22.22.1/doc/api/net.md"
      }
    },
    "commander": {
      "name": "Commander",
      "basis": "12.1.0",
      "sources": {
        "s408eb603ae2e": "https://github.com/tj/commander.js/blob/v12.1.0/Readme.md#L203-L205"
      }
    },
    "authjs": {
      "name": "Auth.js",
      "basis": "unknown",
      "sources": {
        "sb4ac5f50ec66": "https://authjs.dev/getting-started/deployment",
        "s42365460cb4c": "https://authjs.dev/getting-started/installation",
        "s46bb80456d4f": "https://authjs.dev/getting-started/session-management/protecting"
      }
    },
    "better": {
      "name": "Better Auth",
      "basis": "unknown",
      "sources": {
        "s981751bcb554": "https://better-auth.com/docs/installation",
        "s2ac2e0926f25": "https://better-auth.com/docs/integrations/next",
        "s8677a74455a1": "https://better-auth.com/docs/plugins/2fa",
        "s4b3a514c43d9": "https://better-auth.com/docs/reference/options"
      }
    },
    "vercel": {
      "name": "Vercel documentation",
      "basis": "unknown",
      "sources": {
        "s7836e043434a": "https://vercel.com/changelog/protect-production-deployments-for-free-on-every-plan",
        "se6089d5c4e96": "https://vercel.com/docs/deployment-protection"
      }
    },
    "curl": {
      "name": "curl",
      "basis": "unknown",
      "sources": {
        "s5345a985007a": "https://curl.se/docs/manpage.html#-H"
      }
    },
    "grep": {
      "name": "GNU grep",
      "basis": "unknown",
      "sources": {
        "sea43e82b0753": "https://www.gnu.org/software/grep/manual/html_node/Exit-Status.html",
        "s2c1251092e66": "https://www.gnu.org/software/grep/manual/html_node/General-Output-Control.html",
        "sd00017f70dae": "https://www.gnu.org/software/grep/manual/html_node/Matching-Control.html"
      }
    }
  },
  "claims": {
    "entrypoints": {"text": "Pages, layouts, handlers and exported Actions are distinct entry points; Actions accept direct POST. Next.js 16 renamed middleware.ts to proxy.ts; session primitives are not login.", "components": ["next"], "sources": ["next:scd5749a71a79", "next:sc2a39ce10fe1", "next:sa45045bebccb", "next:s23a087193901"], "status": "REASONED"},
    "start-default": {"text": "v16.3.6 next start defaults 3000 and no hostname: Node binds :: when available, else 0.0.0.0 despite -H help. Pinned Commander leaves unspecified value options undefined.", "components": ["next-pin", "node", "commander"], "sources": ["next-pin:s3b0feef8ec0f", "next-pin:s0ef9150d51e4", "next-pin:sefdefa3425c6", "next-pin:s66bd2ed9c346", "next-pin:s2b4479b3c1d2", "node:sfb3e306c102d", "commander:s408eb603ae2e", "next-pin:s11ffc231f0c3"], "status": "REASONED"},
    "private-tls": {"text": "Build then next start -H 127.0.0.1 -p 3000 with TLS proxy; PORT cannot be set in .env. Hosted TLS comes from the platform.", "components": ["next"], "sources": ["next:s066f8a176a52", "next:s353c30dff99f"], "status": "REASONED"},
    "dal": {"text": "Call DAL verifySession for every data request, handler and Action; authorize resource ownership and return only needed fields.", "components": ["next"], "sources": ["next:sa45045bebccb", "next:s23a087193901"], "status": "REASONED"},
    "layouts": {"text": "Layouts do not rerender on every navigation; returning null does not stop nested segments or Actions.", "components": ["next"], "sources": ["next:sa45045bebccb", "next:s23a087193901"], "status": "REASONED"},
    "proxy": {"text": "Proxy is an optimistic cookie-only redirect layer, not sole authorization; avoid database lookups and account for matcher changes.", "components": ["next"], "sources": ["next:scd5749a71a79", "next:sa45045bebccb"], "status": "REASONED"},
    "role": {"text": "Handler/action examples independently require admin; sensitive roles come from trusted user storage. Fragments need imports, data calls and real success responses.", "components": ["next"], "sources": ["next:sa45045bebccb", "next:s23a087193901"], "status": "REASONED"},
    "session-secret": {"text": "Generate a 32-byte random SESSION_SECRET in server environment, never NEXT_PUBLIC_.", "components": ["next"], "sources": ["next:sa45045bebccb", "next:s964651d4eed4"], "status": "REASONED"},
    "session-jwt": {"text": "jose session signs HS256 with seven-day expiry; decrypt verifies only HS256 and returns payload/undefined. User ID/role only, no PII; sensitive work uses database-verified sessions.", "components": ["next"], "sources": ["next:sa45045bebccb"], "status": "REASONED"},
    "session-cookie": {"text": "Set HttpOnly, Secure, SameSite=Lax, path / and seven-day expiry; only Server Functions/handlers set/delete cookies, with logout deleting session.", "components": ["next"], "sources": ["next:sfbc4364fb5cc", "next:sa45045bebccb"], "status": "REASONED"},
    "public-env": {"text": "NEXT_PUBLIC_ is inlined at build; next.config.js env is client-inlined regardless of prefix. Read secrets only in DAL and ignore .env files.", "components": ["next"], "sources": ["next:s964651d4eed4", "next:s23a087193901"], "status": "REASONED"},
    "action-key": {"text": "Self-hosted instances share NEXT_SERVER_ACTIONS_ENCRYPTION_KEY at build, base64 decoding to 16/24/32 bytes; closure encryption is not secret protection.", "components": ["next"], "sources": ["next:s353c30dff99f", "next:s23a087193901"], "status": "REASONED"},
    "action-origin": {"text": "Actions abort when Origin mismatches Host/X-Forwarded-Host; proxies can configure experimental.serverActions.allowedOrigins.", "components": ["next"], "sources": ["next:s23a087193901", "next:s353c30dff99f"], "status": "REASONED"},
    "authjs-secret": {"text": "AUTH_SECRET is mandatory; npx auth secret writes .env.local.", "components": ["authjs"], "sources": ["authjs:sb4ac5f50ec66", "authjs:s42365460cb4c"], "status": "REASONED"},
    "authjs-providers": {"text": "Configure provider ID/SECRET and OIDC ISSUER variables, real providers and linked allowlist checks.", "components": ["authjs"], "sources": ["authjs:sb4ac5f50ec66", "authjs:s42365460cb4c"], "status": "REASONED"},
    "authjs-trust": {"text": "Set AUTH_TRUST_HOST=true behind a reverse proxy; Vercel sets trust automatically.", "components": ["authjs"], "sources": ["authjs:sb4ac5f50ec66"], "status": "REASONED"},
    "authjs-route": {"text": "auth() reads sessions; wrapped handlers only populate req.auth and must deny missing sessions and failed authorization before data.", "components": ["authjs"], "sources": ["authjs:s46bb80456d4f"], "status": "REASONED"},
    "authjs-proxy": {"text": "auth as proxy with empty providers and no authorized callback permits all requests; add callback/wrapper and resource checks. Enforce MFA at the identity provider.", "components": ["authjs"], "sources": ["authjs:s46bb80456d4f"], "status": "REASONED"},
    "better-secret": {"text": "BETTER_AUTH_SECRET needs 32+ characters; production rejects the placeholder default. Set BETTER_AUTH_URL/baseURL explicitly, not request inference.", "components": ["better"], "sources": ["better:s981751bcb554", "better:s4b3a514c43d9"], "status": "REASONED"},
    "better-origins": {"text": "trustedOrigins scopes origin/CSRF and callbackURL checks, not app-route access; general checks skip GET/HEAD/OPTIONS with endpoint-specific GET callback checks.", "components": ["better"], "sources": ["better:s4b3a514c43d9"], "status": "REASONED"},
    "better-password": {"text": "Better Auth emailAndPassword defaults disabled; enable explicitly when used.", "components": ["better"], "sources": ["better:s4b3a514c43d9"], "status": "REASONED"},
    "better-next": {"text": "nextCookies enables Action session-cookie writes; toNextJsHandler exports auth GET/POST routes.", "components": ["better"], "sources": ["better:s2ac2e0926f25"], "status": "REASONED"},
    "better-session": {"text": "Reject missing getSession before authorization: handler 401, component redirect/throw, action redirect/throw/serializable error. Discarding results or checking cookie existence gates nothing.", "components": ["better"], "sources": ["better:s2ac2e0926f25"], "status": "REASONED"},
    "better-mfa": {"text": "twoFactor makes TOTP, emailed/SMS OTP and backups available, not enrolled/enforced; OTP needs sendOTP, client needs twoFactorClient and migration, operations need separate 2FA checks.", "components": ["better"], "sources": ["better:s8677a74455a1"], "status": "REASONED"},
    "vercel-methods": {"text": "Deployment Protection admits project-authorized Vercel users; Passport, Password Protection and Trusted IPs need Enterprise/paid add-ons, not app-user authentication.", "components": ["vercel"], "sources": ["vercel:se6089d5c4e96"], "status": "REASONED"},
    "vercel-scope": {"text": "Standard Protection excludes production domains; enable All Deployments. Cited 9 September 2026 announcement makes Vercel Authentication production scope free on all plans including Hobby.", "components": ["vercel"], "sources": ["vercel:s7836e043434a", "vercel:se6089d5c4e96"], "status": "REASONED"},
    "verify-bind": {"text": "ss inventories loopback 3000; it does not prove firewall/platform ingress isolation.", "components": ["next"], "sources": ["next:s066f8a176a52", "next:s353c30dff99f"], "status": "REASONED", "verify": [1]},
    "verify-anonymous": {"text": "Anonymous admin/dashboard must contain no protected data: login 3xx, chosen 401/403, or streamed 200 redirect shell require reading saved bodies.", "components": ["next"], "sources": ["next:sa45045bebccb"], "status": "REASONED", "verify": [2]},
    "verify-authorized": {"text": "Authorized dashboard/admin controls must return real content; non-admin must deny admin data, meaningful only after admin success.", "components": ["next"], "sources": ["next:sa45045bebccb"], "status": "REASONED", "verify": [3]},
    "verify-cookie-input": {"text": "Prompt cookie values without echo and send through curl stdin; hidden prompt and set +x keep them from argv, history and tracing, not the account owner or root; assumes clean shell and separate subshell pastes.", "components": ["curl"], "sources": ["curl:s5345a985007a"], "status": "REASONED", "verify": [3]},
    "verify-secret": {"text": "Require .next/static, prompt full literal secret and send to grep stdin: 0 leak, 1 no literal match, other codes inconclusive. Encoded/split secrets can escape.", "components": ["next", "grep"], "sources": ["next:s964651d4eed4", "grep:sea43e82b0753", "grep:s2c1251092e66", "grep:sd00017f70dae"], "status": "REASONED", "verify": [4]},
    "verify-action": {"text": "Fresh disposable record per Action attempt; authorized mutation changes store, anonymous/unauthorized replays deny without changes, not merely not-found.", "components": ["next"], "sources": ["next:sa45045bebccb", "next:s23a087193901"], "status": "REASONED", "verify": [4]}
  }
}
````
<!-- version-basis:end -->
