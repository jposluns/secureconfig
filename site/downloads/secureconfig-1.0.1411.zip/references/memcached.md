# Memcached: bind privately; authentication and TLS are optional builds

Memcached is a cache that keeps data in memory so applications can read it quickly. This guide helps your AI assistant configure it securely, including a loopback or private bind with UDP off, an unprivileged account, and TLS and binary-protocol SASL login only on builds and clients that support them.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/memcached.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against memcached source 1.6.45 and OpenSSL CLI 3.0; 3 further sources are pinned to a commit and 4 carry no recorded version. Metadata reviewed 2026-10-15; documentation checked September 2026. The guide records 37 claims: 1 demonstrated by a check that ran; 36 reasoned from cited sources and any earlier-form run (not a live demonstration of the shipped form).

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Memcached has no authentication by default, and its `-l` option defaults to `INADDR_ANY`, so a stock start listens on every interface on TCP 11211 and serves any client that connects. The project's own wording: memcached "does not spend much, if any, effort in ensuring its defensibility from random internet connections", so it "must not" be exposed to the internet or to untrusted users. The practical control is network isolation; SASL and TLS exist, but each needs a build compiled with that feature. SASL adds no encryption; SASL PLAIN credentials need TLS. See the [server configuration documentation](https://docs.memcached.org/serverguide/configuring/) and [SASL documentation](https://docs.memcached.org/protocols/binarysasl/).

Use a maintained package carrying current security fixes. Feature introduction dates below describe availability, not a recommended deployment version. At the time of writing, [upstream lists 1.6.45 as current stable](https://memcached.org/). [1.6.42](https://github.com/memcached/memcached/wiki/ReleaseNotes1642) was explicitly security-focused and included SASL, authentication, and protocol fixes; [1.6.45](https://github.com/memcached/memcached/wiki/ReleaseNotes1645) contains further security and crash fixes. Review distribution backports and test upgrades on a canary before rollout.

The startup examples build on one another; apply the chosen arguments to one service instance, rather than starting every example concurrently. Distribution service accounts and configuration files vary.

## 1. Bind to loopback or a private interface, UDP off

```bash
memcached -l 127.0.0.1 -p 11211 -U 0
```

`-l` accepts an address or `host:port`; the man page calls it "an important option to consider as there is no other way to secure the installation". Put the same flags in your distribution's service configuration, and firewall 11211 per [cloud-firewalls.md](cloud-firewalls.md) or [host.md](host.md). For clients on other hosts, prefer a private network or a tailnet ([tailscale.md](tailscale.md)) over a public listener.

Use `-l 127.0.0.1` for local clients, or the actual private interface address for remote clients. Avoid wildcard listeners such as `0.0.0.0` and `::`. Permit only intended clients through the firewall. Repeated `-l` options and address-specific ports can create additional listeners; inspect every listener. See the [network configuration documentation](https://github.com/memcached/memcached/wiki/ConfiguringServer#networking).

Set both transport ports explicitly: `-p 11211 -U 0`. Changing the TCP port does not provide access control. `-p 0` disables TCP; `-U 0` disables UDP. These meanings are documented in the [1.6.45 man page](https://raw.githubusercontent.com/memcached/memcached/1.6.45/doc/memcached.1).

UDP defaults to disabled since 1.5.6. Retain explicit `-U 0` to override inherited package settings: public UDP enables reflection and amplification attacks. The older configuration wiki's illustrative `udpport 11211` output is not the desired state. See the [vendor DDoS advisory](https://docs.memcached.org/advisories/ddos/).

## 2. Run under a dedicated unprivileged account

Limit the host privileges available to a compromised cache process. Run the service as its dedicated account. If the launcher starts as root, add `-u memcache`, substituting the existing service account:

```bash
memcached -l 127.0.0.1 -p 11211 -U 0 -u memcache
```

`-u` changes identity only when started as root; it does not create the account. If the service manager already starts memcached as its dedicated unprivileged account, configure that identity there. Distribution account names vary. See the [1.6.45 man page](https://raw.githubusercontent.com/memcached/memcached/1.6.45/doc/memcached.1).

Supported builds also offer `-o drop_privileges` for additional syscall restrictions. This is separate from `-u`, and the [1.6.45 CLI help](https://raw.githubusercontent.com/memcached/memcached/1.6.45/memcached.c) documents it as disabled by default. Treat it as a follow-up control until tested with the deployed platform, build, and required operations.

## 3. Bound connections and item memory

Set a connection budget and an item-storage budget:

```bash
memcached -l 127.0.0.1 -p 11211 -U 0 -u memcache -c 256 -m 256
```

These are example capacities. Calculate the connection limit from application pools and leave operational headroom. Allow memory for connections, threads, and other overhead beyond `-m`. `-m` is not a total process-memory limit, and `-c` is not a request-rate limit. Network isolation remains necessary.

The documented upstream defaults are 1024 connections and 64 MB of item storage. Verify the service's effective configuration because package overrides can differ. See the [man page](https://raw.githubusercontent.com/memcached/memcached/1.6.45/doc/memcached.1) and [memory and connection guidance](https://github.com/memcached/memcached/wiki/ConfiguringServer).

Optionally, `-o idle_timeout=60` retires idle connections. Choose a timeout compatible with connection pools. The 1.6.45 default is zero, meaning no timeout; binary-protocol handling was fixed in 1.5.15. See the [CLI implementation](https://raw.githubusercontent.com/memcached/memcached/1.6.45/memcached.c) and [1.5.15 release notes](https://github.com/memcached/memcached/wiki/ReleaseNotes1515).

## 4. SASL authentication (binary protocol only)

For clients that require binary SASL, use a build configured with `--enable-sasl`; add `--enable-tls` when building the encrypted deployment:

```bash
./configure --enable-sasl --enable-tls
```

SASL support dates to 1.4.3 and requires a compatible client and build. Confirm the installed binary advertises `-S`, then retain `-S` in the service arguments. Install the Cyrus SASL mechanism required by the client. See the [SASL how-to](https://github.com/memcached/memcached/wiki/SASLHowto) and [TLS build documentation](https://docs.memcached.org/features/tls/).

Credentials come from the Cyrus SASL password database. The password command prompts interactively:

```bash
saslpasswd2 -a memcached -c cacheuser
memcached -l 10.0.0.5 -p 11211 -U 0 -u memcache -c 256 -m 256 -S
```

This demonstrates SASL enablement; add TLS as in step 5 before sending PLAIN credentials. The password database must be owned by, and readable only by, the account running memcached. SASL provides authentication without encrypting cache traffic and is intended to protect against neighbours and accidents inside a mostly trusted network, not to justify internet exposure. See the [SASL documentation](https://docs.memcached.org/protocols/binarysasl/).

`-S` enables SASL commands and requires the binary protocol. Protected operations such as GET require successful authentication. Binary VERSION and SASL negotiation commands are permitted before authentication, so a VERSION response does not demonstrate an authentication bypass. See the [1.6.45 binary dispatcher](https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_bin.c). Because SASL protects only the binary protocol, keep every listener on the binary protocol. memcached supports per-listener protocol overrides, and an ASCII connection, including one that selects ASCII on a negotiating listener, bypasses SASL even with `-S`, so such a listener would accept commands without credentials; a negotiated binary connection still undergoes the SASL check. Probe each listener with an unauthenticated ASCII GET as well as the binary no-credentials check, so an ASCII bypass on any listener is caught.

The binary protocol is [deprecated upstream](https://docs.memcached.org/protocols/). For new text/meta clients, use private networking and an appropriate authenticated TLS deployment. ASCII has no SASL authentication, but optional ASCII token authentication exists: `-Y /etc/memcached/authfile`.

Provision that file with one `username:password` pair per line, readable only by the service account. Configure a client that implements the token exchange: a fake `set` command carries `username password` as its value. Carry that exchange over TLS and keep passwords out of startup arguments. See the [authentication wire format](https://raw.githubusercontent.com/memcached/memcached/7278bdee96329915bbc87731ba005095453f5c2f/doc/protocol.txt).

`-Y` arrived in 1.5.15, is built in without SASL dependencies, and provides no per-user authorization after login. Choose it as an alternative to binary SASL. See the [1.5.15 release notes](https://github.com/memcached/memcached/wiki/ReleaseNotes1515). It remains experimental in 1.6.45. Binary operation is excluded; a nonzero UDP configuration is rejected at startup, rather than silently overridden, so retain `-U 0`. See the [1.6.45 option handling](https://raw.githubusercontent.com/memcached/memcached/1.6.45/memcached.c).

## 5. TLS (1.5.13 and later, build with `--enable-tls`)

The TLS documentation specifies a build configured with `--enable-tls` against OpenSSL 1.1.1 or later, and a client library that speaks TLS. TLS is off by default. This example combines the preceding controls with the command restrictions in steps 6 and 7:

```bash
memcached -l 10.0.0.5 -p 11211 -U 0 -u memcache -c 256 -m 256 -S -Z -F -X -W \
  -o ssl_chain_cert=/etc/memcached/tls/fullchain.pem,ssl_key=/etc/memcached/tls/privkey.pem
```

`--enable-tls` is the build option; `-Z` (`--enable-ssl`) enables TLS at runtime. `ssl_chain_cert` and `ssl_key` point at the PEM certificate chain and key ([free-certificates.md](free-certificates.md) or [self-signed.md](self-signed.md)). `-o` accepts comma-separated extended options.

`-o ssl_verify_mode=2` with `-o ssl_ca_cert=/path/ca.pem`, substituting the actual CA file, requires client certificates. This provides mutual TLS and a possession factor for machine clients ([machine-auth.md](machine-auth.md)). The default verification mode is `0`, which does not require client certificates. See the [TLS documentation](https://docs.memcached.org/features/tls/).

A `-l notls:127.0.0.1:11211` listener explicitly bypasses TLS for local tooling. It does not remove `-S`'s binary-protocol requirement. Keep this exception restricted to loopback if an existing deployment requires it; do not add a plaintext listener merely to obtain text administration commands.

On a text-capable listener, `refresh_certs` reloads certificates without a restart, and `stats settings` shows active `ssl_` values. Those text requests cannot simply be sent to the demonstrated `-S` listener. In 1.6.45, use the service manager to send SIGHUP to the verified memcached process for certificate reload, and use an authenticated binary client's STAT request with key `settings` for settings inspection. Retain the configured certificate paths; check reload errors and inspect the certificate on a new connection. Existing connections retain their established sessions. See the [TLS reload design](https://raw.githubusercontent.com/memcached/memcached/4b9e6198fc44c9eb3ae80802a1b0dcbaf9602969/doc/tls.txt), [1.6.45 signal handling](https://raw.githubusercontent.com/memcached/memcached/1.6.45/memcached.c), and [binary statistics implementation](https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_bin.c).

MFA: there is no login for a person, so no second factor applies; human access to the host goes behind MFA per [mfa.md](mfa.md).

## 6. Disable unnecessary cache-wide invalidation and keep shutdown disabled

If the application does not require cache-wide invalidation, add `-F`. This disables `flush_all`, reducing the risk of accidental or malicious cache eviction followed by a backend load spike. It does not prevent ordinary writes or individual deletions.

Leave `-A` absent so the ASCII `shutdown` command remains disabled. Check inherited service arguments as well as the configuration you edited.

Both controls are documented in the [1.6.45 man page](https://raw.githubusercontent.com/memcached/memcached/1.6.45/doc/memcached.1). A rejected flush still increments `cmd_flush`; that counter alone does not establish that flushing succeeded. Verify the command response and a previously readable test item. The [protocol reference](https://raw.githubusercontent.com/memcached/memcached/7278bdee96329915bbc87731ba005095453f5c2f/doc/protocol.txt) describes invalidation and shutdown; its general flush success description must be read with the `-F` restriction.

## 7. Disable key enumeration and live watch access

Cache keys and activity logs can disclose application identifiers and usage. Add `-X -W` when operations do not require key dumps or live watchers.

In 1.6.45, `-X` blocks `stats cachedump`, `stats detail`, `lru_crawler metadump`, and `lru_crawler mgdump`. The man page lists fewer commands than the implementation; do not generalize this coverage to older releases. `-W` blocks `watch`. These controls leave ordinary `stats`, `stats settings`, and reads of known keys available within the applicable protocol and authentication rules. Keep those capabilities behind the same network and authentication boundary. See the [1.6.45 command enforcement](https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_text.c).

`-W` was introduced in [1.5.21](https://github.com/memcached/memcached/wiki/ReleaseNotes1521). The flags are listed in the [1.6.45 CLI help](https://raw.githubusercontent.com/memcached/memcached/1.6.45/memcached.c).

Do not substitute `-o no_lru_crawler` for `-X`. It disables the background crawler, and protocol commands can enable the crawler again. It is a maintenance setting, not an authorization boundary. See the [crawler protocol](https://raw.githubusercontent.com/memcached/memcached/7278bdee96329915bbc87731ba005095453f5c2f/doc/protocol.txt).

## Verify

**REASONED:** the service-level checks V1 to V6, per the 15 Sources entries that this paragraph names. The first five of the 15 Sources entries are memcached documentation, binary protocol SASL authentication; memcached documentation, TLS; memcached documentation, configuring the server (`-l`, `-U`, exposure warning); memcached 1.6.42 security release notes; and memcached 1.6.45 security and crash fixes. The sixth to ninth of the 15 Sources entries are memcached UDP reflection and amplification advisory; memcached 1.6.45 man page, network, account, resource, flush, and shutdown options; memcached protocol reference (`-Y` text protocol authentication); and memcached 1.5.15 release notes, ASCII authentication and binary idle timeout fix. The tenth to fifteenth of the 15 Sources entries are memcached 1.6.45 CLI help, defaults, effective settings, and signal handling; memcached 1.6.45 text command enforcement; memcached 1.6.45 binary authentication, statistics, and flush enforcement; memcached TLS design and certificate reload; memcached basic text command semantics; and memcached binary requests and responses. The authoring environment has no memcached binary, no container runtime and no network access to obtain either, and no available authorized service environment for reproducing these states, so no exposed or fixed service state was observed; each step records its local runs and its expected exposed and fixed outcomes. Throwaway certificates were generated for the local OpenSSL checks recorded below; a TLS-enabled memcached service, configured authentication service and separate network observers remain unavailable. Expected outcomes come from the linked vendor sources; no live outcome is claimed.

**REASONED:** the syntax, lint and guard-validation record for the guide's 11 shell blocks only, not memcached; syntax and lint passes have no exposed-state comparison. The following local runs were recorded during marking review (October 2026) under bash 5.3.9 with logging stubs for memcached, ps, ss, nc and openssl first on PATH and no network. All 11 blocks passed `bash -n` and ShellCheck 0.11.0 with no findings, and `check_guard_conventions.py --strict-guards` on this guide printed PASS for 11 fences, 5 of them guard fences. Each of the five guarded blocks rejected six invalid values and two incomplete-assignment cases under `bash -u`; valid inputs reached instrumented probes. The rejected cases ran no stubs; valid cases reached the stubs with the block's arguments. This tests the guards, not memcached. The bash -n, ShellCheck, scanner and stub runs recorded here covered an earlier form of the five guarded blocks, whose refusals exited with status 1; the current form, whose refusals exit with status 2 and whose results set each block's exit status, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes, and no stub run of it is recorded here. Memcached startup/configuration parsing remains undemonstrated.

**REASONED:** the paste, quoting and builtin assumptions for every guarded block; only the V2 cases below were recorded during marking review (October 2026), and additional V2 interactive paste runs during marking review (October 2026) under bash 5.3.9 piped the block followed by `echo SESSION_SURVIVED` into `bash --norc --noprofile -i` with a stub nc first on PATH and no network. With the parentheses and unchanged placeholder, stdout printed `replace the address; not probing` then `SESSION_SURVIVED`; without the parentheses, it printed the refusal line and the guard's exit closed the shell before `SESSION_SURVIVED`. With 10.0.0.5 and the parentheses, stdout printed `STUB nc -vz -w 5 10.0.0.5 11211`, `TCP connection failed; inspect the error and matched positive control`, then `SESSION_SURVIVED`. The previously recorded V2 runs were under bash 5.3.9 with a stub nc and no network; not memcached. All V2 runs recorded here covered an earlier form of the V2 block, whose refusals exited with status 1 and whose `set --` line took one value; the current form, which also takes the observer and exits with a status for each outcome, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes, and no stub run of it is recorded here. A literal apostrophe inside the quotes on the `set --` line made `bash -n` fail with unexpected EOF, and the same value with the apostrophe shell-escaped parsed. With the builtin `[`, two values on the `set --` line were refused with `supply exactly one address; not probing`; with `[` shadowed by a shell function, the same block probed 10.0.0.5. The probe lines pasted without the guards ran nc against an empty target, or against `REPLACE_WITH_REAL_TARGET_IP` held by the calling shell, both of which the whole block refuses. Paste each complete block, including its parentheses, marker, and count checks. Substitute inside the single quotes on the `set --` line. Do not insert a literal apostrophe there without shell escaping. The guards assume normal shell builtins; fragments pasted below the guards are not protected.

### V1. Inspect the release, process identity, arguments, and every listener

```bash
# On the service host, first ensure memcached resolves to the same installed executable used by the service.
# Supply its actual PID. Run listener inspection with enough privilege to identify the process and in its
# network namespace; also inspect host-side published ports for container deployments.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_MEMCACHED_PID'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "supply exactly one PID; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "replace the PID; not probing"; exit 2 ;;
    *)
      case "$1" in
        *[!0123456789]*|0) echo "supply a positive numeric PID; not probing"; exit 2 ;;
        *)
          command -v memcached > /dev/null || { echo "memcached is not on PATH: put the executable the service runs first on PATH; not probing"; exit 2; }
          set -- "$1" 0                 # the 2nd value is the block's status so far: 3 (a command failed) outranks 2 (ss is not installed), which outranks 0; this block classifies no finding
          memcached -V || { echo "memcached -V exit $?; inconclusive"; set -- "$1" 3; }
          memcached -h || { echo "memcached -h exit $?; inconclusive"; set -- "$1" 3; }
          ps -o pid=,user=,group=,args= -p "$1" || { echo "ps exit $?: no process $1 was listed; inconclusive"; set -- "$1" 3; }
          if command -v ss >/dev/null; then
            ss -tlnup || { echo "ss -tlnup exit $?: the listener list failed; inconclusive"; set -- "$1" 3; }
            set -- "$1" "$2" listed     # the 3rd value says whether ss ran, so the last line names every listener only when it did
          else
            echo "ss is not installed here; not listing sockets"
            case "$2" in 0) set -- "$1" 2 ;; esac
            set -- "$1" "$2" unlisted
          fi
          case "$3" in
            listed) echo "block exit $2; the release, the options memcached -h lists, the process account and every listener are not classified, so judge them yourself" ;;
            *) echo "block exit $2; the release, the options memcached -h lists and the process account are not classified, so judge them yourself" ;;
          esac
          exit "$2"
          ;;
      esac
      ;;
  esac
)
```

**REASONED:** preceding block; the `memcached -V`, `memcached -h`, `ps` and `ss -tlnup` inventory in the preceding block and the release, option and account checks in this paragraph, per the guide's cited memcached 1.6.42 security release notes, memcached 1.6.45 security and crash fixes, memcached 1.6.45 CLI help and memcached 1.6.45 man page entries. No memcached executable or service process exists in the authoring environment, and no host listener was read. During marking review (October 2026) the block ran under `bash -u` with stub memcached, ps and ss: PID 1234 reached `memcached -V`, `memcached -h`, `ps -o pid=,user=,group=,args= -p 1234` and `ss -tlnup` in that order, and invalid PIDs were refused before any stub ran. Those stub runs covered an earlier form of the V1 block, whose refusals exited with status 1; the current form, which refuses a memcached missing from PATH, exits 3 when any of the four commands fails, otherwise 2 when `ss` is not installed, and otherwise 0, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes, and no stub run of it is recorded here. Expected exposed outcome: a release without the cited fixes or their backports, `-S` or `-Z` missing for the SASL/TLS deployment, or another process account; fixed: the fixes present, both options advertised and the dedicated account. Confirm the package's security-fix status, including distribution backports; a version string alone is insufficient. Confirm `-S` and `-Z` are advertised for the SASL/TLS deployment. The running process must use the intended dedicated account.

**REASONED:** the listener comparison in this paragraph, per the guide's cited memcached 1.6.45 man page and memcached UDP reflection and amplification advisory entries. No memcached service, published container port or second network position exists in the authoring environment, so no listener was read; the stub run of the V1 block is recorded in the previous paragraph. The expected exposed and fixed outcomes are those stated here. Read every listener: TCP 11211 on loopback or the intended private address only, no memcached UDP socket, and no unexpected address-specific port or published listener. An exposed comparison has a wildcard/unintended listener or UDP enabled; a fixed comparison has only the intended listeners while an allowed client's protected operation still succeeds. Use V2 and V6 as the positive controls. The [man page](https://raw.githubusercontent.com/memcached/memcached/1.6.45/doc/memcached.1) and [DDoS advisory](https://docs.memcached.org/advisories/ddos/) define the expected configuration.

**REASONED:** the effective-settings check in this paragraph, per the guide's cited memcached 1.6.45 CLI help, defaults, effective settings, and signal handling entry. No memcached service exists in the authoring environment, so no `stats settings` or binary STAT response was read. During marking review (October 2026) Python printed 268435456 and 67108864 for 256 and 64 multiplied by 1048576, matching the byte values given here for the example and upstream item budgets. Expected exposed outcome: upstream or package budgets, a nonzero `udpport`, or shutdown, flush or dumping enabled; fixed: the selected budgets with UDP `0`, shutdown `no`, flush `no` and dumping `no`. For capacity, request `stats settings` through V3's applicable text configuration, or authenticated binary STAT with key `settings` for `-S`. For the example budgets, expect `maxconns` of `256` and `maxbytes` of `268435456`; unchanged upstream defaults would report `1024` and `67108864`. Compare the actual selected budgets, not these numbers if you chose different capacities. Also inspect `tcpport`, `udpport`, `inter`, `shutdown_command`, `flush_enabled`, and `dump_enabled`. Expected restrictions are UDP `0`, shutdown `no`, flush `no`, and dumping `no`. See the [effective-settings implementation](https://raw.githubusercontent.com/memcached/memcached/1.6.45/memcached.c).

**REASONED:** the matched SET/GET positive control, per the guide's cited memcached basic text command semantics entry. No memcached service or application client exists in the authoring environment, so this has no local part. Expected in both comparisons: the application's GET returns the value its SET stored; without that, the settings observations above are unpaired. A successful application SET/GET after applying the budgets is the matched positive control. These observations establish effective settings and basic operation, not workload capacity or a total process-memory ceiling.

### V2. Pair outside denial with allowed-client success

**REASONED:** separate allowed and disallowed observers and a deployed cache are unavailable. Use the real address from the deployment inventory, not a documentation address. Run this block from both observers, with `disallowed` or `allowed` as its second value, and record their locations and targets.

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_REAL_TARGET_IP' 'REPLACE_WITH_disallowed_OR_allowed'   # the target address, then disallowed if this observer must be refused or allowed if it must connect
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "supply exactly one address and one observer; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|""|-*|*[[:space:]]*)
      echo "replace the address; not probing"; exit 2 ;;
    *)
      case "$2" in
        disallowed|allowed) ;;
        *) echo "substitute disallowed (an observer the bind and firewall must refuse) or allowed (an observer that must connect) on the set -- line above; not probing"; exit 2 ;;
      esac
      command -v nc > /dev/null || { echo "nc is not on PATH; not probing"; exit 2; }
      if nc -vz -w 5 "$1" 11211; then
        echo "TCP connection succeeded; compare the observer and expected policy"
        case "$2" in
          disallowed) echo "FINDING: the disallowed observer connected to $1 port 11211"; exit 1 ;;
          *) echo "block exit 0; the allowed observer connected, and V6's application request from it is still yours to complete"; exit 0 ;;
        esac
      else
        set -- "$1" "$2" "$?"
        echo "TCP connection failed; inspect the error and matched positive control"
        case "$2" in
          disallowed) echo "block exit 0; nc exit $3 is a refusal, a timeout or a wrong target, which this block cannot tell apart, so it is an unclassified observation: pair it with the allowed observer's success and V1's listener and firewall evidence"; exit 0 ;;
          *) echo "nc exit $3: the allowed observer could not connect, so the positive control failed; inconclusive"; exit 3 ;;
        esac
      fi
      ;;
  esac
)
```

**REASONED:** preceding block; the `nc -vz -w 5` TCP probe in the preceding block, run from both observers, and the comparison in this paragraph, per the guide's cited memcached documentation, configuring the server entry. No deployed cache and no separate allowed and disallowed network observers exist in the authoring environment. During marking review (October 2026) the block ran under `bash -u` with a stub nc: 10.0.0.5 reached `nc -vz -w 5 10.0.0.5 11211`, a stub exit of 0 printed the succeeded line and 1 the failed line, and the placeholder, an empty value, an angle-bracketed value, an example.com name, an option-like value and a value containing a space were refused before nc ran. Those stub runs covered an earlier form of the V2 block, whose refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes, and no stub run of it is recorded here. The current form exits 1 when a `disallowed` observer connects and 3 when an `allowed` observer cannot, and it exits 0 for the other two outcomes, a failed `disallowed` connection being an unclassified observation that it says to pair with the allowed run and V1. The expected exposed and fixed outcomes are those stated here. On an isolated test network, the exposed comparison allows the otherwise disallowed observer to connect. After fixing the bind/firewall, that observer must receive refusal or timeout while the allowed observer can still connect and complete V6's application request. Do not create public exposure to obtain a baseline.

**REASONED:** the observer positions and targets in this paragraph, per the guide's cited memcached documentation, configuring the server entry. No deployed cache or second network position exists in the authoring environment, so this has no local part beyond the V2 block runs recorded two paragraphs above. Expected: the loopback or private positive control connects, and once the bind and firewall are fixed the outside probe of each non-loopback or public address does not. For loopback-only service, the positive control runs on the service host against `127.0.0.1`; the outside probe targets the host's actual non-loopback address. For a private remote-client deployment, test the actual private endpoint from both relevant network positions, and any public address or port mapping separately.

**REASONED:** the timeout caveat in this paragraph, per the guide's cited memcached documentation, configuring the server entry. No deployed cache, firewall or second network position exists in the authoring environment. During marking review (October 2026) the V2 block with a stub nc exiting 1 printed `TCP connection failed; inspect the error and matched positive control`; the block branches only on the exit status of nc, so its own output does not separate a timeout from a refusal or a wrong target. That stub run covered an earlier form of the V2 block, whose refusals exited with status 1; the current form, which still branches only on the exit status of nc, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes, and no stub run of it is recorded here. Expected: a timeout is inconclusive in either comparison until paired with V1 listener and firewall evidence. A timeout alone proves nothing about isolation: a wrong target, unavailable service, or broken route can produce it. Correlate the pair with V1's process/listener evidence and the effective firewall rules. This follows the vendor's [network isolation guidance](https://docs.memcached.org/serverguide/configuring/).

### V3. Retain the loopback text probe for its applicable configuration

**REASONED:** no loopback memcached service is available. This probe is only for the no-authentication, no-TLS loopback configuration in step 1, or an isolated test instance with that transport.

```bash
(
  set -- PASTE_WHOLE_BLOCK '127.0.0.1'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "supply exactly one address; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "replace the address; not probing"; exit 2 ;;
    *)
      [ "$1" = 127.0.0.1 ] || { echo "this probe is only for loopback; not probing"; exit 2; }
      command -v nc > /dev/null || { echo "nc is not on PATH; not probing"; exit 2; }
      set -- "$1" 0 "$(if printf 'stats\r\nquit\r\n' | nc -w 5 "$1" 11211; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # the block's status so far (3, inconclusive, outranks 0; this block classifies no finding), then the reply and nc's exit status
      set -- "$1" "$2" "${3%$'\n'*}" "${3##*$'\n'}"
      printf '%s' "$3"
      if [ "$4" != 0 ]; then
        echo "nc exit $4: the stats request failed; inconclusive"; set -- "$1" 3
      else
        case "$3" in
          END$'\r'*|*$'\n'END$'\r'*) set -- "$1" "$2" ;;
          *) echo "the stats reply has no END line, so this is not the applicable text listener; inconclusive"; set -- "$1" 3 ;;
        esac
      fi
      set -- "$1" "$2" "$(if printf 'stats settings\r\nquit\r\n' | nc -w 5 "$1" 11211; then printf '\n0'; else printf '\n%s' "$?"; fi)"
      set -- "$1" "$2" "${3%$'\n'*}" "${3##*$'\n'}"
      printf '%s' "$3"
      if [ "$4" != 0 ]; then
        echo "nc exit $4: the stats settings request failed; inconclusive"; set -- "$1" 3
      else
        case "$3" in
          END$'\r'*|*$'\n'END$'\r'*) set -- "$1" "$2" ;;
          *) echo "the stats settings reply has no END line, so this is not the applicable text listener; inconclusive"; set -- "$1" 3 ;;
        esac
      fi
      echo "block exit $2; the statistics and settings values are not classified, so judge them yourself"
      exit "$2"
      ;;
  esac
)
```

**REASONED:** preceding block; the two text requests in the preceding block and the outcomes in this paragraph, per the guide's cited memcached protocol reference, memcached basic text command semantics, memcached 1.6.45 binary authentication, statistics, and flush enforcement, and memcached documentation, TLS entries. No loopback memcached service exists in the authoring environment. During marking review (October 2026) the block ran under `bash -u` with a stub nc: the shipped 127.0.0.1 value sent `stats\r\nquit\r\n` and then `stats settings\r\nquit\r\n` to port 11211, and 10.0.0.5 and 127.0.0.2 printed `this probe is only for loopback; not probing` without running nc. Those stub runs covered an earlier form of the V3 block, whose refusals exited with status 1; the current form, which exits 3 when either reply lacks an `END` line or nc fails and otherwise 0, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes, and no stub run of it is recorded here. The expected outcomes on the applicable listener and on the combined deployment are those stated here. Expect statistics terminated by `END` on the applicable text listener. On the combined private-address SASL/TLS deployment, this probe fails for independent reasons: nothing need listen on loopback, `-S` rejects text `stats`, and `-Z` requires TLS. That failure proves none of those controls individually. Pair it with V1's listener evidence and V6's successful authenticated request. See the [text protocol](https://raw.githubusercontent.com/memcached/memcached/7278bdee96329915bbc87731ba005095453f5c2f/doc/protocol.txt) and [binary dispatcher](https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_bin.c).

### V4. Verify TLS, certificate identity, and the existing mutual-TLS option

**REASONED:** following block; no TLS-enabled memcached service is available. The local V4 stub run recorded during marking review (October 2026) under `bash -u` refused a missing `ca.pem` and, with a readable `ca.pem`, reached the stub `openssl s_client -connect 10.0.0.5:11211 -CAfile ca.pem -verify_ip 10.0.0.5 -verify_return_error` command. This records argument construction and the file guard, not a TLS handshake. That stub run covered an earlier form of the V4 block, whose refusals exited with status 1; the current form, which also refuses a missing timeout or openssl and exits 3 when the command fails, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes, and no stub run of it is recorded here. Provide the trusted CA as `ca.pem` and the actual server IPv4 address:

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_SERVER_IPV4'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "supply exactly one address; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|""|-*|*[[:space:]]*)
      echo "replace the address; not probing"; exit 2 ;;
    *)
      [ -r ca.pem ] || { echo "provide the trusted CA file ca.pem; not probing"; exit 2; }
      command -v timeout > /dev/null || { echo "timeout is not on PATH; not probing"; exit 2; }
      command -v openssl > /dev/null || { echo "openssl is not on PATH; not probing"; exit 2; }
      if timeout 10 openssl s_client -connect "$1:11211" -CAfile ca.pem -verify_ip "$1" \
        -verify_return_error </dev/null; then
        echo "block exit 0; the handshake completed with ca.pem trust and IP verification for $1, and V6's application request is still yours to complete"; exit 0
      else
        echo "timeout or s_client exit $?: the connection, the handshake or certificate verification failed; read the error above; inconclusive"; exit 3
      fi
      ;;
  esac
)
```

**REASONED:** preceding block; the V4 guard, OpenSSL command construction, certificate identity and DNS adaptation here, per the guide's cited memcached documentation, TLS entry; `-verify_ip` and `-verify_hostname` identity checks and `-CAfile` trusted-certificate file per the cited OpenSSL 3.0 verification options entry. The basis for `-verify_ip` and `-verify_hostname` being `s_client` options and `-verify_return_error` typically aborting on a verification error is the cited OpenSSL 3.0 `s_client` verification options and `-verify_return_error` entry. Local marking review (October 2026, Bash 5.3.9) ran `bash -n` and ShellCheck 0.11.0 with Bash selected; both exited 0 without findings. Under `bash -u`, a stubbed `timeout` and `openssl` run refused a missing marker with `paste the whole block; not probing` and missing or extra values with `supply exactly one address; not probing`, each at exit 1 before either stub ran. The same stubbed run under `bash -u` refused placeholder, angle-bracket, example.com, empty, option-like and spaced values with `replace the address; not probing`, and a missing CA with `provide the trusted CA file ca.pem; not probing`, each at exit 1 before either stub ran. The valid 10.0.0.5 fixture exited 0 and printed `timeout 10 openssl s_client -connect 10.0.0.5:11211 -CAfile ca.pem -verify_ip 10.0.0.5 -verify_return_error`. The bash -n, ShellCheck and stubbed runs above covered an earlier form of the V4 block, whose refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes, and no stub run of it is recorded here. Local OpenSSL 3.5.5 `openssl x509 -noout -checkip` and `-checkhost` checks printed `IP 10.0.0.5 does match certificate`, `IP 10.0.0.6 does NOT match certificate`, `Hostname cache.example.com does match certificate` and `Hostname other.example.com does NOT match certificate`; the corresponding exits were 0, 1, 0 and 1. These local checks did not exercise a handshake. A live memcached stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. A compatible TLS application client for the V6 request is also needed, and its availability is unknown. The exposed service would fail the TLS handshake or present the wrong identity; the fixed service must complete trusted CA and matching IP or DNS verification and the V6 application request. For the original `10.0.0.5` example, the certificate needs an iPAddress SAN for `10.0.0.5`. `-verify_ip` binds trust to that address. For a DNS SAN, adapt the guarded block to the actual name and use `-verify_hostname` with that name instead. Chain checks alone accept other identities signed by the same CA.

**REASONED:** the public-trust alternative and hostname check here, per the guide's cited memcached documentation, TLS entry; the `-verify_hostname` identity check, `-CAfile` and default trusted-certificate file per the cited OpenSSL 3.0 verification options entry. The basis for `-verify_hostname` being an `s_client` option and `-verify_return_error` typically aborting on a verification error is the cited OpenSSL 3.0 `s_client` verification options and `-verify_return_error` entry. Local marking review (October 2026) ran OpenSSL 3.5.5 `s_client -help`, which exited 0 and listed `-verify_hostname` and `-verify_ip`. The same local marking review (October 2026) recorded that a server certificate signed by a locally generated CA passed `openssl verify -CAfile`, printing `OK` for the server certificate, while `openssl x509 -checkhost` printed `Hostname cache.example.com does match certificate` at exit 0 and `Hostname other.example.com does NOT match certificate` at exit 1. A publicly trusted certificate and a live TLS endpoint were not tested; their availability is unknown. A live memcached stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. A compatible TLS application client for the V6 request is also needed, and its availability is unknown. Expected exposed: a trusted chain for the wrong DNS name can pass a chain-only check, which is why the step uses `-verify_hostname`: set to the service's DNS name, it fails hostname verification for a certificate issued to another name, and `-verify_return_error` typically aborts the handshake; fixed: the trusted chain and matching DNS identity verify, followed by a successful V6 request. Omit `-CAfile` only for a publicly trusted certificate whose issuer is already in the system store. On that path, use `-verify_hostname` with the certificate's DNS name rather than expecting an iPAddress SAN.

**REASONED:** the plaintext and TLS service comparison and inconclusive results here, per the guide's cited memcached documentation, TLS and memcached basic text command semantics entries. The basis for `s_client` proceeding past verification errors unless `-verify_return_error` is used, so a bare handshake shows only that TLS is present, is the cited OpenSSL 3.0 `s_client` verification options and `-verify_return_error` entry. Local marking review (October 2026) ran the preceding V4 block through `bash -n` and ShellCheck 0.11.0 with no findings; its valid stub fixture printed `timeout 10 openssl s_client -connect 10.0.0.5:11211 -CAfile ca.pem -verify_ip 10.0.0.5 -verify_return_error` and exited 0. Those bash -n, ShellCheck and stub runs covered an earlier form of the V4 block, whose refusals exited with status 1; the current form, which exits 0 only when the handshake completes with that verification and 3 when it does not, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes, and no stub run of it is recorded here. A live memcached stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. No live TLS handshake or V6 request was observed. A compatible TLS application client for the V6 request is also needed, and its availability is unknown. Expected exposed: plaintext cannot complete the TLS handshake; fixed: trusted certificate and matching identity verify and the authorized V6 request succeeds. A timeout or absent CA file establishes neither state. A reachable plaintext comparison cannot complete this TLS handshake; the fixed TLS endpoint must complete certificate and identity verification and then support V6's application request. A bare handshake without the proper trust and identity checks establishes only that TLS is present. A timeout or missing certificate file is inconclusive.

**REASONED:** the default client-certificate setting and mode 2 comparison here, per the guide's cited memcached documentation, TLS entry. Local marking review (October 2026) ran OpenSSL 3.5.5 `s_client -help`, which exited 0 and listed `-cert` and `-key`; no client certificate exchange ran. A live memcached stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. A configured mode 2 service, approved client certificate and key, and compatible application client are also needed, and their availability is unknown. Expected exposed: the default mode allows the application request without a client certificate; fixed: mode 2 refuses that request without a client certificate while the approved certificate completes it. s_client's `Verification: OK` (server-certificate verification) alone does not distinguish these outcomes. The example matches the default server behavior, which does not require client certificates. With `-o ssl_verify_mode=2`, add `-cert` and `-key` pointing to the approved client certificate and key files. Compare a valid client certificate with an omitted certificate against the same service. Only the valid client must complete an application request. `Verification: OK` describes server-certificate verification and can still print when the server subsequently refuses the client.

**REASONED:** the certificate reload check in this paragraph, per the guide's cited memcached documentation, TLS, memcached TLS design and certificate reload, and memcached 1.6.45 CLI help, defaults, effective settings, and signal handling entries. No TLS-enabled memcached service or service manager exists in the authoring environment, so no SIGHUP was sent. During marking review (October 2026) two throwaway certificates with the same 10.0.0.5 SAN printed different SHA-256 fingerprints under `openssl x509 -noout -fingerprint -sha256`, one way to tell the new certificate from the old on a new connection. The expected exposed and fixed outcomes are those stated here. For certificate reload, replace the certificate material at the configured paths, send SIGHUP through the service manager to the verified process, and repeat on a new connection. Expect the new certificate and a successful application request; retaining the old certificate or reporting a reload error is not success. See the [TLS documentation](https://docs.memcached.org/features/tls/) and [reload design](https://raw.githubusercontent.com/memcached/memcached/4b9e6198fc44c9eb3ae80802a1b0dcbaf9602969/doc/tls.txt).

### V5. Exercise flush, dump, watch, and shutdown restrictions (REASONED: restriction comparisons from cited pinned memcached sources; no disposable runtime.)

**REASONED:** no disposable memcached runtime is available. This block deliberately sends `flush_all` and `shutdown`. Run it only against an otherwise empty disposable loopback instance, never a live application cache.

Use the same 1.6.45 build for both comparisons, with ordinary text transport, no authentication, no TLS, default slab geometry, and the crawler running. Keep automatic service restart disabled so it cannot conceal shutdown. The exposed comparison omits `-F -X -W` and enables `-A`; the fixed comparison adds `-F -X -W` and omits `-A`. Keep network isolation and the dedicated account in both.

Replace the address with `127.0.0.1` only after confirming that this port belongs to the disposable instance:

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_DISPOSABLE_LOOPBACK_IP'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "supply exactly one address; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "replace the disposable cache address; not probing"; exit 2 ;;
    *)
      [ "$1" = 127.0.0.1 ] || { echo "use the disposable loopback cache; not probing"; exit 2; }
      command -v nc > /dev/null || { echo "nc is not on PATH; not probing"; exit 2; }
      command -v timeout > /dev/null || { echo "timeout is not on PATH; not probing"; exit 2; }
      set -- "$1" 0 "$(if printf 'set sc:probe 0 300 2\r\nok\r\nget sc:probe\r\nquit\r\n' | nc -w 5 "$1" 11211; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # the block's status so far (3, inconclusive, outranks 0; this block classifies no finding), then the control's reply and nc's exit status
      set -- "$1" "$2" "${3%$'\n'*}" "${3##*$'\n'}"
      printf '%s' "$3"
      case "$4:$3" in
        0:*$'STORED\r\nVALUE sc:probe 0 2\r\nok\r\nEND\r'*) ;;
        0:*) echo "the initial SET/GET did not store and return ok, so the results below are inconclusive"; set -- "$1" 3 "$3" "$4" ;;
        *) echo "nc exit $4: the initial SET/GET request failed, so the results below are inconclusive"; set -- "$1" 3 "$3" "$4" ;;
      esac
      set -- "$1" "$2"
      sleep 2
      printf 'flush_all\r\nget sc:probe\r\nquit\r\n' | nc -w 5 "$1" 11211 ||
        { echo "nc exit $?: the flush request failed; inconclusive"; set -- "$1" 3; }
      printf 'set sc:probe 0 300 2\r\nok\r\nstats items\r\nquit\r\n' | nc -w 5 "$1" 11211 ||
        { echo "nc exit $?: the SET and item statistics request failed; inconclusive"; set -- "$1" 3; }
      set -- "$1" "$2" 'stats cachedump 1 10' 'stats detail dump' \
        'lru_crawler metadump all' 'lru_crawler mgdump all' 'watch'   # the requests sent below, one per pass, as positional parameters
      while [ "$#" -gt 2 ]; do
        printf 'request: %s\n' "$3"
        printf '%s\r\n' "$3" | timeout 5 nc -w 3 "$1" 11211 ||
          { echo "timeout or nc exit $?: the $3 request failed or timed out; inconclusive"; set -- "$1" 3 "${@:3}"; }
        set -- "$1" "$2" "${@:4}"
      done
      printf 'get sc:probe\r\ndelete sc:probe\r\nstats\r\nstats settings\r\nquit\r\n' | nc -w 5 "$1" 11211 ||
        { echo "nc exit $?: the GET, DELETE and statistics request failed; inconclusive"; set -- "$1" 3; }
      printf 'shutdown\r\n' | nc -w 5 "$1" 11211 ||
        { echo "nc exit $?: the shutdown request failed; inconclusive"; set -- "$1" 3; }
      printf 'stats\r\nquit\r\n' | nc -w 5 "$1" 11211 ||
        { echo "nc exit $?: the statistics request after shutdown failed, as when shutdown stopped the process; read it against the shutdown row; inconclusive"; set -- "$1" 3; }
      echo "block exit $2; every response after the initial SET/GET is not classified, so read it against the table below"
      exit "$2"
      ;;
  esac
)
```

Read the responses, not just the block's final exit status:

| Request | Exposed comparison | Fixed comparison and positive control |
| --- | --- | --- |
| Initial SET/GET | Stores and returns `ok` | Also stores and returns `ok`; otherwise subsequent results are inconclusive |
| `flush_all`, then GET | Flush succeeds; the previously readable item is absent | Explicit flush refusal; GET still returns `ok` |
| `stats cachedump 1 10` | Command accepted, with a normal dump terminator; an empty dump alone is not denial | Explicit dumping refusal; known-key GET still works |
| `stats detail dump` | Detail dump accepted, possibly empty | Explicit detail refusal |
| `lru_crawler metadump all` and `lru_crawler mgdump all` | Successful dumps from the populated fixture | Explicit dump refusal |
| `watch` | Watcher accepted | Explicit watch refusal |
| GET, DELETE, ordinary statistics | Ordinary operations succeed | Ordinary operations still succeed |
| `shutdown`, then fresh statistics request | Process stops; subsequent connection fails | Explicit shutdown refusal; the same process still answers statistics |

The short item uses slab class 1 with the stated default geometry; inspect `stats items` before interpreting that dump. A disabled or busy crawler, malformed request, connection failure, or protocol mismatch does not prove `-X`. A watcher timeout does not prove `-W`; inspect whether the watcher was accepted or explicitly refused. The two-second pause separates item creation from immediate flush timing.

These comparisons follow the [basic command semantics](https://docs.memcached.org/protocols/basic/), [1.6.45 restrictions](https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_text.c), and [shutdown protocol](https://raw.githubusercontent.com/memcached/memcached/7278bdee96329915bbc87731ba005095453f5c2f/doc/protocol.txt). The disposable text fixture isolates these flags; it does not demonstrate the production authentication or TLS configuration.

For a binary SASL deployment, also repeat SET, GET, FLUSH, and GET through the authenticated TLS client on a disposable equivalent. Without `-F`, FLUSH invalidates the item; with `-F`, FLUSH is refused and the item remains readable. See the [binary flush implementation](https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_bin.c).

### V6. Test authentication with a protected operation

**REASONED:** no memcached service, configured authentication database, or compatible client is available. Use the deployed application's client, with credentials obtained interactively or from its protected secret configuration, never password arguments.

**REASONED:** seeding the probe item and using fresh connections, per the guide's cited memcached documentation, binary protocol SASL authentication and memcached protocol reference entries. No memcached service, authentication database or compatible client exists in the authoring environment, so this has no local part. Expected in both comparisons: the authorized client reads back the seeded value. Seed `sc:auth-probe` with a short-lived known value through an authorized client. Use fresh connections for the following requests:

| Mode | Concrete request and exposed comparison | Fixed outcome and matched positive control |
| --- | --- | --- |
| Binary SASL | Binary GET, opcode `0x00`, key `sc:auth-probe`, without SASL authentication. A service without `-S` returns the item | **REASONED:** the binary SASL comparison in this row, per the guide's cited memcached documentation, binary protocol SASL authentication, memcached 1.6.45 binary authentication, statistics, and flush enforcement, and memcached binary requests and responses entries; no SASL-enabled memcached build or binary client exists in the authoring environment, so this row has no local part. With `-S`, the unauthenticated GET receives authentication-required/error status `0x20`. On a fresh connection, successful SASL authentication followed by the same GET returns the known value |
| ASCII token authentication | Text `get sc:auth-probe` without token exchange. A service without `-Y` returns the item | **REASONED:** the ASCII token comparison in this row, per the guide's cited memcached protocol reference and memcached 1.5.15 release notes entries; no memcached service with `-Y` or token-exchange client exists in the authoring environment, so this row has no local part. With `-Y`, it cannot retrieve the item before authentication. On a fresh connection, the client's fake SET token exchange succeeds, then the same GET returns the known value |

**REASONED:** the incorrect-password comparison and matched correct-credential request, per the guide's cited memcached documentation, binary protocol SASL authentication and memcached protocol reference entries. No memcached service, authentication database or compatible client exists in the authoring environment, so this has no local part. The expected exposed and fixed outcomes are those stated here and in the table above. Also test an intentionally incorrect password on a fresh connection and confirm it cannot retrieve the item; retain the successful correct-credential request against the same endpoint. Keep the same TLS and client-certificate conditions across each authentication comparison so a TLS failure cannot masquerade as authentication enforcement.

**REASONED:** the inconclusive-result rules in this paragraph, per the guide's cited memcached binary requests and responses, memcached documentation, binary protocol SASL authentication, memcached 1.6.45 binary authentication, statistics, and flush enforcement, and memcached protocol reference entries. No memcached service or client exists in the authoring environment, so this has no local part. Expected: binary VERSION and SASL negotiation can succeed in both comparisons, so only the protected GET distinguishes them. Binary VERSION and SASL negotiation success are not substitutes for GET. A missing key, closed connection, or unavailable server without the matched successful request is inconclusive. See the [binary protocol](https://docs.memcached.org/protocols/binary/), [SASL status codes](https://docs.memcached.org/protocols/binarysasl/), [binary enforcement](https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_bin.c), and [ASCII token exchange](https://raw.githubusercontent.com/memcached/memcached/7278bdee96329915bbc87731ba005095453f5c2f/doc/protocol.txt).

| Check scope | Status | Deployment comparison and prerequisites |
| --- | --- | --- |
| V1-V6 | REASONED from the cited memcached documentation and pinned protocol sources; not demonstrated | **REASONED:** the V1 to V6 summary in this row, per the Sources entries, which this cell lists in three parts. The Sources entries (1 of 3): memcached documentation, binary protocol SASL authentication; memcached documentation, TLS; memcached documentation, configuring the server (`-l`, `-U`, exposure warning); memcached 1.6.42 security release notes; memcached 1.6.45 security and crash fixes; memcached UDP reflection and amplification advisory. The Sources entries (2 of 3): memcached 1.6.45 man page, network, account, resource, flush, and shutdown options; memcached protocol reference (`-Y` text protocol authentication); memcached 1.5.15 release notes, ASCII authentication and binary idle timeout fix; memcached 1.6.45 CLI help, defaults, effective settings, and signal handling; memcached 1.6.45 text command enforcement. The Sources entries (3 of 3): memcached 1.6.45 binary authentication, statistics, and flush enforcement; memcached TLS design and certificate reload; memcached basic text command semantics; and memcached binary requests and responses. No memcached runtime, configured SASL or TLS service, or network observers exist in the authoring environment, and the local runs are recorded at each step and at the top of this section. Obtain an authorized memcached runtime, SASL/TLS client and certificate fixtures, and allowed/disallowed network observers. Run V1-V6 against matched exposed and fixed states; record package/build identity, service arguments, process ownership, listeners, effective budgets, requests, responses, and positive controls. Validate startup parsing and certificate reload. If optional idle timeout or privilege dropping is adopted, include its platform and application checks before claiming it effective. |

## Common mistakes

- A container or package that starts memcached without `-l`, so it listens on `INADDR_ANY` while a firewall rule is assumed but absent.
- `-S` on a distribution package built without SASL: the option is documented as meaningful only with SASL compiled in, so confirm it took effect rather than assuming.
- SASL without TLS across a shared network; the documentation is explicit that SASL adds no encryption, and PLAIN credentials need TLS.
- Changing `-p` and treating the new port as access control, or inheriting a nonzero UDP setting.
- Treating `-m` as a total process-memory limit or `-c` as a request-rate limit.
- Assuming a rejected text request proves authentication on a binary/TLS listener, or treating VERSION as a protected operation.
- Reading `cmd_flush` as proof that invalidation succeeded.
- Substituting `-o no_lru_crawler` for `-X`, or assuming `-X -W` disables ordinary statistics and known-key access.
- Adding a plaintext listener just to send text administration commands to a service configured for binary SASL.
- Calling an outside timeout a pass without confirming the real target and a successful allowed-client request.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- memcached documentation, binary protocol SASL authentication: https://docs.memcached.org/protocols/binarysasl/
- memcached documentation, TLS: https://docs.memcached.org/features/tls/
- OpenSSL 3.0 `s_client` verification options and `-verify_return_error` (checked October 2026): https://docs.openssl.org/3.0/man1/openssl-s_client/
- OpenSSL 3.0 verification options: `-verify_hostname`, `-verify_ip` and the trusted-certificate file options (checked October 2026): https://docs.openssl.org/3.0/man1/openssl-verification-options/
- memcached documentation, configuring the server (`-l`, `-U`, exposure warning): https://docs.memcached.org/serverguide/configuring/
- memcached man page (`-l` default `INADDR_ANY`, `-U` default 0, `-S`): https://raw.githubusercontent.com/memcached/memcached/5d17f8f4bb068a0bdd4809e80e3ed5d378ef2fad/doc/memcached.1
- memcached protocol reference (`-Y` text protocol authentication): https://raw.githubusercontent.com/memcached/memcached/7278bdee96329915bbc87731ba005095453f5c2f/doc/protocol.txt
- memcached current stable release: https://memcached.org/
- memcached 1.6.42 security release notes: https://github.com/memcached/memcached/wiki/ReleaseNotes1642
- memcached 1.6.45 security and crash fixes: https://github.com/memcached/memcached/wiki/ReleaseNotes1645/780e280d1a7f98f2981ffeb357ef0c9b182a9844
- memcached 1.6.45 man page, network, account, resource, flush, and shutdown options: https://raw.githubusercontent.com/memcached/memcached/1.6.45/doc/memcached.1
- memcached configuration wiki, networking and resource budgets: https://github.com/memcached/memcached/wiki/ConfiguringServer
- memcached UDP reflection and amplification advisory: https://docs.memcached.org/advisories/ddos/
- memcached SASL build and setup how-to: https://github.com/memcached/memcached/wiki/SASLHowto
- memcached protocol status and binary deprecation: https://docs.memcached.org/protocols/
- memcached 1.5.15 release notes, ASCII authentication and binary idle timeout fix: https://docs.memcached.org/releasenotes/releasenotes1515/
- memcached 1.5.21 release notes, watch disabling: https://github.com/memcached/memcached/wiki/ReleaseNotes1521
- memcached 1.6.45 CLI help, defaults, effective settings, and signal handling: https://raw.githubusercontent.com/memcached/memcached/1.6.45/memcached.c
- memcached 1.6.45 text command enforcement: https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_text.c
- memcached 1.6.45 binary authentication, statistics, and flush enforcement: https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_bin.c
- memcached TLS design and certificate reload: https://raw.githubusercontent.com/memcached/memcached/4b9e6198fc44c9eb3ae80802a1b0dcbaf9602969/doc/tls.txt
- memcached basic text command semantics: https://docs.memcached.org/protocols/basic/
- memcached binary requests and responses: https://docs.memcached.org/protocols/binary/


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- stable: memcached source (1.6.45)
- docs: memcached documentation (unknown)
- protocol: memcached protocol source (7278bdee96329915bbc87731ba005095453f5c2f)
- reload: memcached TLS design (4b9e6198fc44c9eb3ae80802a1b0dcbaf9602969)
- ascii: memcached ASCII authentication release notes (unknown)
- watch: memcached watch-control release notes (unknown)
- security: memcached security release notes (unknown)
- release-notes-source: memcached release notes revision (780e280d1a7f98f2981ffeb357ef0c9b182a9844)
- openssl: OpenSSL CLI (3.0)

Claims (full source mapping in the JSON block below):

- default (REASONED; docs, stable): Stock memcached has no authentication and binds INADDR_ANY on TCP11211; isolate it from the internet and untrusted users.
- releases (REASONED; security, docs, release-notes-source): Recorded current stable is 1.6.45 with further fixes after security-focused 1.6.42; check backports and canary upgrades, not feature-minimum releases.
- bind (REASONED; stable, docs): Use loopback or an intended private address with firewall restrictions; repeated -l/address-specific ports can add listeners that require inspection.
- ports (REASONED; stable): Set -p 11211 -U 0 explicitly; zero disables the corresponding transport and changing TCP port provides no access control.
- udp-default (REASONED; docs): UDP defaults disabled since 1.5.6; keep -U 0 against inherited settings and reflection/amplification exposure.
- account (REASONED; stable): Run a dedicated unprivileged account; -u changes identity only when launched as root and does not create the account.
- syscalls (REASONED; stable): Optional drop_privileges adds build/platform-dependent syscall restrictions, defaults disabled and needs deployment testing.
- connections (REASONED; stable, docs): -c bounds connections, not request rate; upstream default 1024, example 256 with operational headroom.
- memory (REASONED; stable, docs): -m budgets item memory, not total process memory; upstream default 64 MB, example 256 with extra process overhead.
- idle (REASONED; stable, ascii): Optional idle_timeout defaults zero/no timeout in 1.6.45; choose pool-compatible values; binary handling was fixed in 1.5.15.
- sasl-build (REASONED; docs): SASL support dates from 1.4.3 and requires --enable-sasl, advertised -S and compatible Cyrus mechanism/client; SASL PLAIN needs TLS.
- sasl-secrets (REASONED; docs): saslpasswd2 prompts; protect the Cyrus password database for the service account. SASL authenticates without encryption and does not justify public exposure.
- sasl-protocol (REASONED; stable): -S gates binary protected operations but permits VERSION/negotiation; ASCII per-listener overrides or negotiation bypass SASL, so test every listener.
- ascii-auth (REASONED; docs, protocol, ascii): Deprecated binary protocol has an alternative: -Y service-only username:password file and a client fake-SET token exchange over TLS, without per-user authorization.
- ascii-limits (REASONED; ascii, stable): -Y remains experimental in 1.6.45, needs no SASL dependency, excludes binary operation and rejects nonzero UDP at startup.
- tls (REASONED; docs): TLS dates from 1.5.13, needs --enable-tls/OpenSSL1.1.1+ and compatible clients; default off, runtime -Z uses PEM chain/key extended options.
- mtls (REASONED; docs): ssl_verify_mode defaults 0/no required client cert; mode 2 with ssl_ca_cert requires certificates, adding machine possession, not human MFA.
- notls (REASONED; docs, stable): A notls loopback listener bypasses TLS but does not remove -S binary requirements; do not add plaintext merely for text administration.
- reload (REASONED; reload, stable): Text refresh_certs/settings do not apply directly to -S; 1.6.45 SIGHUP reloads configured paths and authenticated binary STAT inspects settings; existing sessions persist.
- flush (REASONED; stable, protocol): -F blocks cache-wide invalidation but preserves ordinary writes/deletes; rejected flush increments cmd_flush, so inspect response and retained item.
- shutdown (REASONED; stable, protocol): Leave -A absent to keep ASCII shutdown disabled; inspect inherited arguments.
- dump (REASONED; stable): 1.6.45 -X blocks cachedump, stats detail and crawler meta/mgdump; ordinary statistics and known-key reads remain available.
- watch (REASONED; watch, stable): -W blocks watch and dates from 1.5.21; preserve network/authentication protection for other remaining capabilities.
- crawler (REASONED; protocol): no_lru_crawler is not an authorization boundary; protocol commands can re-enable the background crawler.
- verify-inventory (REASONED; stable, docs): Check executable/build capabilities, process account and every TCP/UDP/publication listener; pair intended listeners with allowed-client protected operations.
- verify-budgets (REASONED; stable): Effective example maxconns/maxbytes are 256/268435456 versus upstream 1024/67108864; verify disabled UDP/shutdown/flush/dump and matched SET/GET, not workload capacity.
- verify-isolation (REASONED; docs): Disallowed observer must lose TCP11211 while allowed observer still completes a protected request; timeout alone is inconclusive without target/listener/firewall evidence.
- verify-text (REASONED; protocol, stable): Loopback plaintext stats/settings end with END only in the applicable text configuration; SASL/TLS/private-bind failures prove none of those controls independently.
- verify-tls (REASONED; docs, openssl): Plaintext cannot complete TLS; fixed endpoint must verify CA and IP/DNS identity and support application operations; chain-only trust is insufficient. The check must fail closed on certificate verification errors; s_client continues the handshake after such errors unless -verify_return_error is given.
- verify-mtls (REASONED; docs): Under verify mode 2, only a valid client certificate completes the application request; server Verification: OK can precede client rejection.
- verify-reload (REASONED; reload, stable): After replacing material and SIGHUP, new connections must present the new certificate and complete an application request; errors or old certificates fail.
- verify-flush (REASONED; stable, docs): Disposable text/binary comparisons change flush success and lost item to explicit refusal and retained item; initial SET/GET and ordinary operations stay usable.
- verify-dump (REASONED; stable, protocol): Populated disposable fixtures must change dump acceptance to explicit refusal; empty dumps, crawler problems and protocol failures do not prove -X.
- verify-watch (REASONED; stable): Exposed watch acceptance must become explicit refusal; watcher timeout alone does not demonstrate -W.
- verify-shutdown (REASONED; protocol, stable): Disposable -A baseline stops; fixed state refuses shutdown while the same process answers statistics; disable restart masking and never use a live cache.
- verify-auth (REASONED; docs, stable, protocol): Fresh no-auth/wrong-password protected GETs must fail while correct SASL or ASCII token login returns a known item; binary SASL auth-required status is 0x20.
- local-guards (DEMONSTRATED; stable, docs): Historical shell/scanner checks and invalid-input rejection exercised guards and instrumented dispatch, not memcached startup or service behavior. Those checks covered an earlier form of the five guarded blocks, whose refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck passes.

````json
{
  "schema": 1,
  "checked": "2026-10-15",
  "documentation_checked": "2026-09",
  "body_sha256": "04e1d1db846e352bec655ee0cc4c00f5e5d75c0af4de1f0a62b27bc03b14d069",
  "components": {
    "stable": {
      "name": "memcached source",
      "basis": "1.6.45",
      "sources": {
        "s05c72b35637d": "https://raw.githubusercontent.com/memcached/memcached/1.6.45/doc/memcached.1",
        "s1310cfc0315d": "https://raw.githubusercontent.com/memcached/memcached/1.6.45/memcached.c",
        "sceaaea90ec60": "https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_bin.c",
        "sd40dab94f516": "https://raw.githubusercontent.com/memcached/memcached/1.6.45/proto_text.c"
      }
    },
    "docs": {
      "name": "memcached documentation",
      "basis": "unknown",
      "sources": {
        "sb2bb8731440a": "https://docs.memcached.org/serverguide/configuring/",
        "s75df2663dea3": "https://memcached.org/",
        "sf2153ed1541e": "https://github.com/memcached/memcached/wiki/ConfiguringServer",
        "s9b5a9f424414": "https://docs.memcached.org/advisories/ddos/",
        "sed14f4319d19": "https://github.com/memcached/memcached/wiki/SASLHowto",
        "s3b05fd21e910": "https://docs.memcached.org/protocols/binarysasl/",
        "s31b3834d23a2": "https://docs.memcached.org/protocols/",
        "s57f57201fc31": "https://docs.memcached.org/features/tls/",
        "sc0c6532a1ef5": "https://docs.memcached.org/protocols/basic/"
      }
    },
    "protocol": {
      "name": "memcached protocol source",
      "basis": "7278bdee96329915bbc87731ba005095453f5c2f",
      "sources": {
        "s625682583be8": "https://raw.githubusercontent.com/memcached/memcached/7278bdee96329915bbc87731ba005095453f5c2f/doc/protocol.txt"
      }
    },
    "reload": {
      "name": "memcached TLS design",
      "basis": "4b9e6198fc44c9eb3ae80802a1b0dcbaf9602969",
      "sources": {
        "s839f028f2a46": "https://raw.githubusercontent.com/memcached/memcached/4b9e6198fc44c9eb3ae80802a1b0dcbaf9602969/doc/tls.txt"
      }
    },
    "ascii": {
      "name": "memcached ASCII authentication release notes",
      "basis": "unknown",
      "sources": {
        "sdcc562ed68f7": "https://docs.memcached.org/releasenotes/releasenotes1515/"
      }
    },
    "watch": {
      "name": "memcached watch-control release notes",
      "basis": "unknown",
      "sources": {
        "sa3593ecebdce": "https://github.com/memcached/memcached/wiki/ReleaseNotes1521"
      }
    },
    "security": {
      "name": "memcached security release notes",
      "basis": "unknown",
      "sources": {
        "se456e52d21c6": "https://github.com/memcached/memcached/wiki/ReleaseNotes1642"
      }
    },
    "release-notes-source": {
      "name": "memcached release notes revision",
      "basis": "780e280d1a7f98f2981ffeb357ef0c9b182a9844",
      "sources": {
        "s0a46fce08585": "https://github.com/memcached/memcached/wiki/ReleaseNotes1645/780e280d1a7f98f2981ffeb357ef0c9b182a9844"
      }
    },
    "openssl": {
      "name": "OpenSSL CLI",
      "basis": "3.0",
      "sources": {
        "s00aaf106164f": "https://docs.openssl.org/3.0/man1/openssl-s_client/",
        "s8a7380c7371d": "https://docs.openssl.org/3.0/man1/openssl-verification-options/"
      }
    }
  },
  "claims": {
    "default": {"text": "Stock memcached has no authentication and binds INADDR_ANY on TCP11211; isolate it from the internet and untrusted users.", "components": ["docs", "stable"], "sources": ["docs:sb2bb8731440a", "stable:s05c72b35637d"], "status": "REASONED"},
    "releases": {"text": "Recorded current stable is 1.6.45 with further fixes after security-focused 1.6.42; check backports and canary upgrades, not feature-minimum releases.", "components": ["security", "docs", "release-notes-source"], "sources": ["release-notes-source:s0a46fce08585", "security:se456e52d21c6", "docs:s75df2663dea3"], "status": "REASONED"},
    "bind": {"text": "Use loopback or an intended private address with firewall restrictions; repeated -l/address-specific ports can add listeners that require inspection.", "components": ["stable", "docs"], "sources": ["stable:s05c72b35637d", "docs:sf2153ed1541e"], "status": "REASONED"},
    "ports": {"text": "Set -p 11211 -U 0 explicitly; zero disables the corresponding transport and changing TCP port provides no access control.", "components": ["stable"], "sources": ["stable:s05c72b35637d"], "status": "REASONED"},
    "udp-default": {"text": "UDP defaults disabled since 1.5.6; keep -U 0 against inherited settings and reflection/amplification exposure.", "components": ["docs"], "sources": ["docs:s9b5a9f424414"], "status": "REASONED"},
    "account": {"text": "Run a dedicated unprivileged account; -u changes identity only when launched as root and does not create the account.", "components": ["stable"], "sources": ["stable:s05c72b35637d"], "status": "REASONED"},
    "syscalls": {"text": "Optional drop_privileges adds build/platform-dependent syscall restrictions, defaults disabled and needs deployment testing.", "components": ["stable"], "sources": ["stable:s1310cfc0315d"], "status": "REASONED"},
    "connections": {"text": "-c bounds connections, not request rate; upstream default 1024, example 256 with operational headroom.", "components": ["stable", "docs"], "sources": ["stable:s05c72b35637d", "docs:sf2153ed1541e"], "status": "REASONED"},
    "memory": {"text": "-m budgets item memory, not total process memory; upstream default 64 MB, example 256 with extra process overhead.", "components": ["stable", "docs"], "sources": ["stable:s05c72b35637d", "docs:sf2153ed1541e"], "status": "REASONED"},
    "idle": {"text": "Optional idle_timeout defaults zero/no timeout in 1.6.45; choose pool-compatible values; binary handling was fixed in 1.5.15.", "components": ["stable", "ascii"], "sources": ["stable:s1310cfc0315d", "ascii:sdcc562ed68f7"], "status": "REASONED"},
    "sasl-build": {"text": "SASL support dates from 1.4.3 and requires --enable-sasl, advertised -S and compatible Cyrus mechanism/client; SASL PLAIN needs TLS.", "components": ["docs"], "sources": ["docs:sed14f4319d19", "docs:s3b05fd21e910"], "status": "REASONED"},
    "sasl-secrets": {"text": "saslpasswd2 prompts; protect the Cyrus password database for the service account. SASL authenticates without encryption and does not justify public exposure.", "components": ["docs"], "sources": ["docs:s3b05fd21e910"], "status": "REASONED"},
    "sasl-protocol": {"text": "-S gates binary protected operations but permits VERSION/negotiation; ASCII per-listener overrides or negotiation bypass SASL, so test every listener.", "components": ["stable"], "sources": ["stable:sceaaea90ec60"], "status": "REASONED"},
    "ascii-auth": {"text": "Deprecated binary protocol has an alternative: -Y service-only username:password file and a client fake-SET token exchange over TLS, without per-user authorization.", "components": ["docs", "protocol", "ascii"], "sources": ["docs:s31b3834d23a2", "protocol:s625682583be8", "ascii:sdcc562ed68f7"], "status": "REASONED"},
    "ascii-limits": {"text": "-Y remains experimental in 1.6.45, needs no SASL dependency, excludes binary operation and rejects nonzero UDP at startup.", "components": ["ascii", "stable"], "sources": ["ascii:sdcc562ed68f7", "stable:s1310cfc0315d"], "status": "REASONED"},
    "tls": {"text": "TLS dates from 1.5.13, needs --enable-tls/OpenSSL1.1.1+ and compatible clients; default off, runtime -Z uses PEM chain/key extended options.", "components": ["docs"], "sources": ["docs:s57f57201fc31"], "status": "REASONED"},
    "mtls": {"text": "ssl_verify_mode defaults 0/no required client cert; mode 2 with ssl_ca_cert requires certificates, adding machine possession, not human MFA.", "components": ["docs"], "sources": ["docs:s57f57201fc31"], "status": "REASONED"},
    "notls": {"text": "A notls loopback listener bypasses TLS but does not remove -S binary requirements; do not add plaintext merely for text administration.", "components": ["docs", "stable"], "sources": ["docs:s57f57201fc31", "stable:sceaaea90ec60"], "status": "REASONED"},
    "reload": {"text": "Text refresh_certs/settings do not apply directly to -S; 1.6.45 SIGHUP reloads configured paths and authenticated binary STAT inspects settings; existing sessions persist.", "components": ["reload", "stable"], "sources": ["reload:s839f028f2a46", "stable:s1310cfc0315d", "stable:sceaaea90ec60"], "status": "REASONED"},
    "flush": {"text": "-F blocks cache-wide invalidation but preserves ordinary writes/deletes; rejected flush increments cmd_flush, so inspect response and retained item.", "components": ["stable", "protocol"], "sources": ["stable:s05c72b35637d", "stable:sceaaea90ec60", "protocol:s625682583be8"], "status": "REASONED"},
    "shutdown": {"text": "Leave -A absent to keep ASCII shutdown disabled; inspect inherited arguments.", "components": ["stable", "protocol"], "sources": ["stable:s05c72b35637d", "protocol:s625682583be8"], "status": "REASONED"},
    "dump": {"text": "1.6.45 -X blocks cachedump, stats detail and crawler meta/mgdump; ordinary statistics and known-key reads remain available.", "components": ["stable"], "sources": ["stable:sd40dab94f516"], "status": "REASONED"},
    "watch": {"text": "-W blocks watch and dates from 1.5.21; preserve network/authentication protection for other remaining capabilities.", "components": ["watch", "stable"], "sources": ["watch:sa3593ecebdce", "stable:sd40dab94f516"], "status": "REASONED"},
    "crawler": {"text": "no_lru_crawler is not an authorization boundary; protocol commands can re-enable the background crawler.", "components": ["protocol"], "sources": ["protocol:s625682583be8"], "status": "REASONED"},
    "verify-inventory": {"text": "Check executable/build capabilities, process account and every TCP/UDP/publication listener; pair intended listeners with allowed-client protected operations.", "components": ["stable", "docs"], "sources": ["stable:s05c72b35637d", "docs:s9b5a9f424414"], "status": "REASONED", "verify": [1]},
    "verify-budgets": {"text": "Effective example maxconns/maxbytes are 256/268435456 versus upstream 1024/67108864; verify disabled UDP/shutdown/flush/dump and matched SET/GET, not workload capacity.", "components": ["stable"], "sources": ["stable:s1310cfc0315d"], "status": "REASONED", "verify": [1, 3]},
    "verify-isolation": {"text": "Disallowed observer must lose TCP11211 while allowed observer still completes a protected request; timeout alone is inconclusive without target/listener/firewall evidence.", "components": ["docs"], "sources": ["docs:sb2bb8731440a"], "status": "REASONED", "verify": [2]},
    "verify-text": {"text": "Loopback plaintext stats/settings end with END only in the applicable text configuration; SASL/TLS/private-bind failures prove none of those controls independently.", "components": ["protocol", "stable"], "sources": ["protocol:s625682583be8", "stable:sceaaea90ec60"], "status": "REASONED", "verify": [3]},
    "verify-tls": {"text": "Plaintext cannot complete TLS; fixed endpoint must verify CA and IP/DNS identity and support application operations; chain-only trust is insufficient. The check must fail closed on certificate verification errors; s_client continues the handshake after such errors unless -verify_return_error is given.", "components": ["docs", "openssl"], "sources": ["docs:s57f57201fc31", "openssl:s8a7380c7371d", "openssl:s00aaf106164f"], "status": "REASONED", "verify": [4]},
    "verify-mtls": {"text": "Under verify mode 2, only a valid client certificate completes the application request; server Verification: OK can precede client rejection.", "components": ["docs"], "sources": ["docs:s57f57201fc31"], "status": "REASONED", "verify": [4]},
    "verify-reload": {"text": "After replacing material and SIGHUP, new connections must present the new certificate and complete an application request; errors or old certificates fail.", "components": ["reload", "stable"], "sources": ["reload:s839f028f2a46", "stable:s1310cfc0315d"], "status": "REASONED", "verify": [4]},
    "verify-flush": {"text": "Disposable text/binary comparisons change flush success and lost item to explicit refusal and retained item; initial SET/GET and ordinary operations stay usable.", "components": ["stable", "docs"], "sources": ["stable:sd40dab94f516", "stable:sceaaea90ec60", "docs:sc0c6532a1ef5"], "status": "REASONED", "verify": [5]},
    "verify-dump": {"text": "Populated disposable fixtures must change dump acceptance to explicit refusal; empty dumps, crawler problems and protocol failures do not prove -X.", "components": ["stable", "protocol"], "sources": ["stable:sd40dab94f516", "protocol:s625682583be8"], "status": "REASONED", "verify": [5]},
    "verify-watch": {"text": "Exposed watch acceptance must become explicit refusal; watcher timeout alone does not demonstrate -W.", "components": ["stable"], "sources": ["stable:sd40dab94f516"], "status": "REASONED", "verify": [5]},
    "verify-shutdown": {"text": "Disposable -A baseline stops; fixed state refuses shutdown while the same process answers statistics; disable restart masking and never use a live cache.", "components": ["protocol", "stable"], "sources": ["protocol:s625682583be8", "stable:sd40dab94f516"], "status": "REASONED", "verify": [5]},
    "verify-auth": {"text": "Fresh no-auth/wrong-password protected GETs must fail while correct SASL or ASCII token login returns a known item; binary SASL auth-required status is 0x20.", "components": ["docs", "stable", "protocol"], "sources": ["docs:s3b05fd21e910", "stable:sceaaea90ec60", "protocol:s625682583be8"], "status": "REASONED"},
    "local-guards": {"text": "Historical shell/scanner checks and invalid-input rejection exercised guards and instrumented dispatch, not memcached startup or service behavior. Those checks covered an earlier form of the five guarded blocks, whose refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck passes.", "components": ["stable", "docs"], "sources": ["stable:s05c72b35637d", "docs:s57f57201fc31"], "status": "DEMONSTRATED", "evidence": "Each of the five guarded blocks rejected six invalid values and two incomplete-assignment cases under `bash -u`; valid inputs reached instrumented probes."}
  }
}
````
<!-- version-basis:end -->
