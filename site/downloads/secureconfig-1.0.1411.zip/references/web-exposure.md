# Files a web server must never serve: dotfiles, .git, dumps, backups, and client secrets

Web exposure means files a website serves by mistake, like configuration files, source history, database dumps and backups. This guide helps your AI assistant make sure nothing sensitive is served, including deny rules in nginx, Apache and Caddy, backups kept outside served folders, and no secrets built into browser code.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/web-exposure.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against nginx documentation (no recorded version), Apache documentation 2.4, Caddy documentation v2.11.4, Next.js browser source maps v16.3.6, Vite production source maps v8.3.1, Debian apache2 packaging 2.4.69-1, ACME HTTP-01 RFC 8555, and GNU grep 3.12; 1 further source is pinned to a commit and 5 carry no recorded version. Metadata reviewed 2026-10-18; documentation checked September 2026. The guide records 26 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Scanners request `/.env`, `/.git/config`, `/config.php.bak`, and `/db.sql` continuously, and any of these
under a web root hands over credentials or source regardless of what the application itself authenticates.
Anything a deploy step leaves inside the document root is served too, unless the server is told otherwise.

## nginx

Deny dotfiles by regex location, with the ACME challenge path carved out first, because `.well-known` also
starts with a dot. Also deny common backup and dump suffixes (case-insensitively):

```nginx
location ^~ /.well-known/acme-challenge/ {
    allow all;
}

location ~ /\. {
    deny all;
}

location ~* (\.(bak|old|orig|sql(\.gz)?|dump|tar\.gz)|~)$ {
    deny all;
}
```

Once nginx picks the `^~` location as the longest matching prefix, it skips regex locations entirely, so the
challenge path is served before the dotfile deny is reached (`allow`/`deny`: `ngx_http_access_module`;
`location` order and `^~`: `ngx_http_core_module`). Outside that challenge prefix, these rules deny
dot-prefixed path segments and paths ending in `.bak`, `.old`, `.orig`, `~`, `.sql`, `.sql.gz`, `.dump`,
or `.tar.gz`. Put these regex locations before other regex locations that could serve the same paths;
an exact location or another `^~` prefix can bypass them. Keep the challenge directory free of secrets.
Unlike the Apache and Caddy configs below, which exempt all of `/.well-known/`, this config exempts only
the ACME challenge prefix, so `/.well-known/security.txt` is denied; if you serve that file, add
`location = /.well-known/security.txt {}`, because nginx selects an exact match before it checks regex locations.

## Apache

```apache
<DirectoryMatch "/\.(?!well-known(?:/|$))">
    Require all denied
</DirectoryMatch>

<FilesMatch "(?i)(^\.|\.(bak|old|orig|sql(\.gz)?|dump|tar\.gz)$|~$)">
    Require all denied
</FilesMatch>

<Directory /var/www/>
    Options -Indexes
</Directory>
```

`<FilesMatch>` matches the request's basename, not its full path, so it alone does not catch
`/.git/config`: the matched name is `config`, which does not start with a dot (per the core module
documentation). The `<DirectoryMatch>` rule above matches any dot-prefixed path segment (`.git`, `.svn`,
and similar) as a substring of the filesystem path, because Apache's regex is not anchored unless the
pattern itself anchors it (per the core module documentation). A bare `(?!well-known)` lookahead only
rules out that literal substring, so it would still allow a directory that merely starts with
"well-known", such as `/.well-known-backup/config`. The `(?:/|$)` boundary requires the exempted
segment to be `well-known` exactly, ending at a slash or the path's end, so only a genuine `.well-known/`
path is exempt: the whole directory (acme-challenge, and anything else legitimately under it such as
`security.txt`), while a lookalike segment like `.well-known-backup` is not. Keep the `<FilesMatch>` rule as a case-insensitive backstop for the same backup and dump suffixes as
nginx, and for dotfile basenames like `/.env`. The suffix rule still applies inside `.well-known/`.

One default weakens this. Debian apache2 2.4.69-1's `apache2.conf` template sets `Options Indexes FollowSymLinks` on `<Directory /var/www/>`; `dir.conf` contains `DirectoryIndex index.html index.cgi index.pl index.php index.xhtml index.htm`, and `postinst` enables `dir` and `autoindex` on fresh installs (pinned Debian packaging in Sources). With these defaults, when a directory below the document root has no `DirectoryIndex` file, `mod_autoindex` returns a browsable listing of its contents, per the Apache core `Options` and mod_autoindex references. The earlier assertion of the same defaults on Ubuntu remains unchecked: this guide did not check Ubuntu's packaging. The deny rules above still hold, and the listing even omits the files they forbid, because `mod_autoindex` hides an entry whose subrequest returns 403 unless `IndexOptions ShowForbidden` is set. This guide's assessment of the exposure is everything else in the directory: a backup or export the deny rules do not match by name, an `archive.zip`, a `customers.csv`, or a datestamped dump, is listed for anyone who requests the directory, and the listing itself confirms the directory and reveals filenames you were relying on nobody guessing. Turn listing off with `Options -Indexes`, shown above; write it in the relative `-` form so it removes only `Indexes` and keeps the inherited `FollowSymLinks`, and never mix `+`/`-` options with bare ones in a single `Options` line, which Apache 2.4 rejects at startup. The web servers nginx (`autoindex` is `off` by default) and Caddy (`file_server` lists only with `browse`) do not need this; Apache with these Debian defaults does; this guide advises checking Ubuntu's effective configuration because its packaging was not checked here.

## Caddy

Matcher syntax checked against Caddy v2.11.4 source and the matcher reference; server execution was
not run in the authoring environment. Put these directives in the site's Caddyfile block:

```caddyfile
@dotfiles {
    path_regexp dotfiles /\.
    not path /.well-known/*
}
respond @dotfiles 404

@backups path *.bak *.old *.orig *~ *.sql *.sql.gz *.dump *.tar.gz
respond @backups 404
```

`path_regexp` uses Go regular expressions on the decoded path: `/\.` catches a dot-prefixed segment
at any depth, including `/.git`, `/.git/config`, `/.env`, and `/nested/.env`. Matchers within a named
set are ANDed, so `not path` exempts the root `/.well-known/` subtree from the dotfile rule, but not
`/.well-known-backup/`. Keep that public subtree free of secrets. The separate `path` matcher ORs
its case-insensitive suffix patterns and denies backups and dumps even under `/.well-known/`.
Thus `/config.php.bak` and `/db.sql` are denied too. Caddy serves its own ACME challenges outside the
file server. These filename rules cannot recognize every secret or backup; keep them out of the
served directory even when their names match none of these patterns.

## Keep dumps and backups out of the served directory

`.sql`, `.dump`, and backup archives should never land inside a directory a web root points at; the deny rules above are a backstop, not the control. Write exports and backups outside the document root, or to object storage ([object-storage.md](object-storage.md)), never `/var/www/html`. These rules also block intentionally public files with these suffixes, including release archives. Narrow the suffix policy for your site and verify that intended downloads remain accessible.

## Client bundles: secrets compiled into the browser

`NEXT_PUBLIC_`-prefixed variables in Next.js and `VITE_`-prefixed variables in Vite are inlined into the
browser JavaScript at build time; Create React App's `REACT_APP_` prefix does the same (Create React App is
deprecated as of this writing, but the convention persists in older projects). An LLM provider key pasted
into frontend code under one of these prefixes ships to every visitor's browser, not just your server. Only
genuinely public values belong behind these prefixes; call the provider from a backend route and keep the
key server-side. See [secrets.md](secrets.md) and [paas.md](paas.md) for the platform version of this.
ECMA-426 defines `sources` as original-source URLs (or null) and `sourcesContent` as optional original
source strings, with null entries allowed for sources retrieved by name. This guide's assessment is that
a production source map can expose original source when it embeds that content or its sources are
retrievable. A map may be a separate `.map` file; a `//# sourceMappingURL` comment links to a map URL,
including a `data:` URL for an inline map (pinned ECMA-426 fields and linking passages in Sources).
Next.js v16.3.6 disables production browser source maps unless `productionBrowserSourceMaps` is enabled;
when enabled, maps are output beside the JavaScript files and automatically served on request. Vite
v8.3.1 `build.sourcemap` defaults to `false` for production; `true` creates a separate map, `'inline'`
appends a data URI, and `'hidden'` creates a separate map while suppressing the bundle's map comment.
These defaults cover Next.js browser maps and Vite production maps only; this guide did not check
Create React App's source-map defaults. This guide's reasoning: removing the comment does not unpublish
a `.map` you already deployed, because removing a reference does not remove the served file. This guide's
advice: do not ship a source map, or leave one served, for code not already meant to be public.

## Verify

REASONED: following block; planted-file denial, directory listing and ACME/lookalike paths; the client-bundle scan has its own block after it. No configured web-server deployment or run outcome is recorded here; expectations are reasoned from the guide and its cited server and framework sources. The block exits 1 when a probe returns `PLANTED-SECRET` or a 2xx, `/uploads/` answers 200, the challenge token answers 403, or `/.well-known-backup/config` answers a 2xx while a real file is there. Otherwise it exits 3 when a step is inconclusive or a removal fails, including a bare 404 from that lookalike path with no file behind it. If neither applies, it exits 2 when the document root has no `.well-known/acme-challenge` directory, as with a server that answers challenges itself, so the challenge-token checks did not run, and 0 when every classified probe passes.

```bash
# Plant a real file at a denied dotfile path so a 403/404 proves the RULE fired, not that the file is
# absent (Caddy's `respond ... 404` is 404 BY DESIGN, and /.env may simply not exist). Put THIS host's real
# document root (nginx `root` / Apache DocumentRoot) on the set -- line; the check is INCONCLUSIVE unless the plant
# lands. mktemp creates the probe exclusively so it never clobbers a real file, and only that file is
# removed. --noproxy so no client proxy answers; the body is shown so leaked content is visible:
(                                       # a subshell, so your own script arguments are untouched
  set +e                                # errexit off here, so a probe that ends nonzero is folded into the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_HOST' 'REPLACE_WITH_YOUR_DOCUMENT_ROOT'   # this host's served host name, no scheme, user name, port, path, query, fragment, percent sign or trailing dot, then its document root as an absolute path: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
  case "$1" in
    example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -u nocasematch   # every match below compares letter case exactly again
  case "$2" in
    ""|*REPLACE_WITH_*|[!/]*|*[[:cntrl:]]*) echo "substitute this host's document root, an absolute path, inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  denied_probes() (                     # the host, then each path: every response must be 403 or 404 without PLANTED-SECRET
    set -- "$1" 0 "${@:2}"              # the host, these probes' status so far (1, a finding, outranks 3, inconclusive, which outranks 0), then the paths still to probe
    while [ "$#" -gt 2 ]; do
      set -- "$1" "$2" "$3" "$(if curl -q -g -sS --noproxy '*' -w "  <= %{http_code} $3\n" "https://$1$3"; then printf '\n0'; else printf '\n%s' "$?"; fi)" "${@:4}"
      set -- "$1" "$2" "$3" "${4%$'\n'*}" "${4##*$'\n'}" "${@:5}"   # the host, the status so far, the path, what curl printed, curl's exit status, then the paths still to probe
      printf '%s' "$4"
      case "$5:$4" in
        0:*PLANTED-SECRET*) echo "FINDING: $3 returned PLANTED-SECRET"; set -- "$1" 1 "${@:3}" ;;
        0:*'  <= 403 '*|0:*'  <= 404 '*) ;;
        0:*'  <= 2'??' '*) echo "FINDING: $3 answered with a 2xx, so the deny rule did not fire"; set -- "$1" 1 "${@:3}" ;;
        0:*) echo "inconclusive: $3 answered neither 403 nor 404"; [ "$2" = 1 ] || set -- "$1" 3 "${@:3}" ;;
        *) echo "inconclusive: curl exit $5 for $3"; [ "$2" = 1 ] || set -- "$1" 3 "${@:3}" ;;
      esac
      set -- "$1" "$2" "${@:6}"
    done
    exit "$2"
  )
  acme_probe() (                        # the host, the scheme, then the token's name: the response must be probe, never 403
    set -- "$1" "$2" "$3" "$(if curl -q -g -sS --noproxy '*' -w '\n%{http_code}' "$2://$1/.well-known/acme-challenge/$3"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "${4##*$'\n'}" "${4%$'\n'*}"             # the host, the scheme, the name, curl's exit status, then the body and HTTP code
    set -- "$1" "$2" "$3" "$4" "${5%$'\n'*}" "${5##*$'\n'}"        # ..., curl's exit status, the body, then the HTTP code
    printf '%s\n' "$5"
    case "$4:$6:$5" in
      0:200:probe) exit 0 ;;
      0:403:*) echo "FINDING: the challenge token answered 403 over $2, so the deny rules block the ACME exemption"; exit 1 ;;
      0:*) echo "inconclusive: the challenge token answered $6 over $2 without the body probe"; exit 3 ;;
      *) echo "inconclusive: curl exit $4 for the challenge token over $2"; exit 3 ;;
    esac
  )
  set -- "$1" "$2" 0                    # the 3rd value is the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 2 (the challenge-token checks refused), which outranks 0; the block exits with it after its cleanup
  set -- "$1" "$2" "$3" "$(if sudo mktemp "$2/.env.probeXXXXXX" 2>/dev/null; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "${4%%$'\n'*}" "${4##*$'\n'}"   # the host, the document root, the status so far, the probe's path, then mktemp's exit status
  if [ "$5" = 0 ]; then
    # mktemp makes it root-only (0600); chmod so the web-server worker can READ it, or its 403 is a FILE
    # PERMISSION denial (not the deny rule) and the check would false-pass with no rule configured:
    if printf 'PLANTED-SECRET' | sudo tee "$4" >/dev/null && sudo chmod 0644 "$4"; then
      denied_probes "$1" "/${4##*/}" /.git/config /config.php.bak /db.sql
      case "$?:$3" in 0:*) ;; 1:*) set -- "$1" "$2" 1 "$4" ;; *:1) ;; *) set -- "$1" "$2" 3 "$4" ;; esac   # fold those probes' status into the block's, ranked as above
      # every line must be 403 or 404 and must NOT print PLANTED-SECRET. The .env.probe* line is the POSITIVE
      # CONTROL (a world-readable real file under the deny rules), so its 403/404 is the rule, not permissions
      # or absence; a bare 404 on the others could be absence, so plant one at each to be sure
    else
      echo "inconclusive: could not prepare the probe file"
      [ "$3" = 1 ] || set -- "$1" "$2" 3 "$4"
    fi
    sudo rm -f "$4" || { [ "$3" = 1 ] || set -- "$1" "$2" 3 "$4"; }
  else
    echo "inconclusive: could not create a probe under $2; point it at the writable document root"
    set -- "$1" "$2" 3
  fi
  set -- "$1" "$2" "$3"
  # uploads/backups directory: an existing, non-empty, index-less dir must NOT return a 200 autoindex under
  # Options -Indexes. Plant a throwaway file so a listing would actually reveal something; inconclusive if the
  # directory does not exist:
  set -- "$1" "$2" "$3" "$(if sudo mktemp "$2/uploads/listcheckXXXXXX" 2>/dev/null; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "${4%%$'\n'*}" "${4##*$'\n'}"   # ..., the throwaway file's path, then mktemp's exit status
  if [ "$5" = 0 ]; then
    set -- "$1" "$2" "$3" "$4" "$(if curl -q -g -sS --noproxy '*' -o /dev/null -w '%{http_code}\n' "https://$1/uploads/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "$4" "${5##*$'\n'}" "${5%%$'\n'*}"   # ..., curl's exit status, then the HTTP code
    printf '%s\n' "$6"                  # 403/404, never a 200 listing
    case "$5:$6" in
      0:403|0:404) ;;
      0:200) echo "FINDING: /uploads/ answered 200, where an index-less directory must give 403 or 404; this check discards the body, so it did not see whether the 200 is a listing"; set -- "$1" "$2" 1 "$4" ;;
      0:*) echo "inconclusive: /uploads/ answered $6, neither 403 or 404 nor a 200 listing"; [ "$3" = 1 ] || set -- "$1" "$2" 3 "$4" ;;
      *) echo "inconclusive: curl exit $5 for /uploads/"; [ "$3" = 1 ] || set -- "$1" "$2" 3 "$4" ;;
    esac
    sudo rm -f "$4" || { [ "$3" = 1 ] || set -- "$1" "$2" 3 "$4"; }
  else
    echo "inconclusive: $2/uploads does not exist or is not writable"
    [ "$3" = 1 ] || set -- "$1" "$2" 3
  fi
  set -- "$1" "$2" "$3"

  if sudo test -d "$2/.well-known/acme-challenge"; then   # a guard: the challenge-token checks rely on a webroot challenge directory, which a server that answers challenges itself, such as Caddy, does not have
    set -- "$1" "$2" "$3" "$(if sudo mktemp "$2/.well-known/acme-challenge/probeXXXXXX" 2>/dev/null; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "${4%%$'\n'*}" "${4##*$'\n'}"   # ..., the token's path, then mktemp's exit status
    if [ "$5" = 0 ]; then
      if printf 'probe' | sudo tee "$4" >/dev/null && sudo chmod 0644 "$4"; then   # readable, or a 403 is a permission denial not the exemption
        acme_probe "$1" https "${4##*/}"  # must return "probe", never 403: the exemption lets a real challenge file through (HTTPS webroot access)
        case "$?:$3" in 0:*) ;; 1:*) set -- "$1" "$2" 1 "$4" ;; *:1) ;; *) set -- "$1" "$2" 3 "$4" ;; esac
        acme_probe "$1" http "${4##*/}"   # ACME HTTP-01 runs over HTTP:80, so fetch the SAME token over http to confirm that route
        case "$?:$3" in 0:*) ;; 1:*) set -- "$1" "$2" 1 "$4" ;; *:1) ;; *) set -- "$1" "$2" 3 "$4" ;; esac
      else
        echo "inconclusive: could not prepare the challenge file"
        [ "$3" = 1 ] || set -- "$1" "$2" 3 "$4"
      fi
      sudo rm -f "$4" || { [ "$3" = 1 ] || set -- "$1" "$2" 3 "$4"; }
    else
      echo "inconclusive: could not create a challenge token under $2/.well-known/acme-challenge"
      [ "$3" = 1 ] || set -- "$1" "$2" 3
    fi
  else
    echo "sudo test -d found no directory at $2/.well-known/acme-challenge, or sudo failed, so the challenge-token checks did not run; not probing the challenge token"
    [ "$3" = 0 ] && set -- "$1" "$2" 2
  fi
  set -- "$1" "$2" "$3"
  set -- "$1" "$2" "$3" "$(if curl -q -g -sS --noproxy '*' -o /dev/null -w '%{http_code}\n' "https://$1/.well-known-backup/config"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "${4##*$'\n'}" "${4%%$'\n'*}"   # ..., curl's exit status, then the HTTP code
  printf '%s\n' "$5"
  # must be 403 or 404: a directory that only starts with "well-known" must not inherit the exemption. A bare
  # 404 is inconclusive here (nothing is there); create a real .well-known-backup/config to be certain a
  # served 200 would be the finding, then remove it
  case "$4:$5" in
    0:403) ;;
    0:404|0:2??)
      if sudo test -f "$2/.well-known-backup/config"; then
        case "$5" in 404) ;; *) echo "FINDING: /.well-known-backup/config answered $5, so the lookalike directory inherited the exemption"; set -- "$1" "$2" 1 ;; esac
      else
        echo "inconclusive: sudo test -f found no file at $2/.well-known-backup/config, or sudo failed, so its $5 does not show whether the rule fired"; [ "$3" = 1 ] || set -- "$1" "$2" 3
      fi ;;
    0:*) echo "inconclusive: /.well-known-backup/config answered $5, neither 403 nor 404"; [ "$3" = 1 ] || set -- "$1" "$2" 3 ;;
    *) echo "inconclusive: curl exit $4 for /.well-known-backup/config"; [ "$3" = 1 ] || set -- "$1" "$2" 3 ;;
  esac
  echo "block exit $3; the response bodies, and a 404 from /.git/config, /config.php.bak or /db.sql, where nothing was planted, are not classified, so judge them yourself"
  exit "$3"                             # after every cleanup attempt above: 1 if a probe found a planted secret, a listing or a 403 on the challenge token, else 3 if any step was inconclusive or a removal failed, else 2 if the challenge-token checks did not run, else 0
)
```

```bash
# Client-bundle scan per the guide's cited Next.js environment variables and GNU grep 3.12 exit status and error handling; no built bundle was scanned here, and no deployment outcome is recorded.
(                                       # a subshell, so the exit below ends only this check
  set -- 0 0 .next/static build dist    # the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0), whether any directory was scanned, then the directories still to scan
  while [ "$#" -gt 2 ]; do
    if [ -d "$3" ]; then
      set -- "$1" 1 "${@:3}"
      if grep -rn "sk-\|AKIA\|ghp_\|sb_secret_\|-----BEGIN" "$3"; then set -- "$1" "$2" "$3" 0 "${@:4}"; else set -- "$1" "$2" "$3" "$?" "${@:4}"; fi; echo "$3 exit: $4"
      case "$4" in
        0) set -- 1 "${@:2}" ;;                     # a match is a finding, and it outranks an error
        1) ;;
        *) [ "$1" = 1 ] || set -- 3 "${@:2}" ;;     # a grep error is inconclusive
      esac
      set -- "$1" "$2" "${@:5}"
    else
      echo "$3: absent, nothing scanned"
      set -- "$1" "$2" "${@:4}"
    fi
  done
  [ "$2" = 1 ] || { echo "none of .next/static, build or dist is here, so nothing was scanned; run this from the directory that holds the build output"; set -- 2 "$2"; }   # a guard refusal: where the block was run is the reader's setup
  exit "$1"
)
# run against the built client bundle, not the source. Exit 1 with no output is clean, exit 0
# is a match, and exit 2 is a grep failure that is NOT clean. Do not send the errors to
# /dev/null and read silence as a pass: a missing directory is an error (exit 2), and
# discarding its error message leaves silence, which looks exactly like success. A clean result is evidence, not proof:
# a bundler can split or encode a value, so scan for the literal secret as well
# The bundle scan above exits 1 when any directory matched, 3 when a grep failed, 2 when no directory
# existed, so nothing was scanned, and 0 otherwise.
```

REASONED: preceding block; client-bundle scan, per the guide's cited Next.js environment variables and GNU grep 3.12 exit status and error handling, with the dotfile/backup denial, listing and ACME/lookalike checks of the block above it, per the cited nginx core module, nginx access module, Apache core Options, Caddy matchers and RFC 8555 section 8.3 HTTP-01 validation. No web-server deployment is available and local listeners are denied. bash -n and ShellCheck 0.11.0 exited 0 without diagnostics; the block with a scratch document root and curl stub exited 0, printed eight STUB curl lines and removed its planted files. Those runs covered the planted-file checks and the bundle scan as one block, before its host guard was added, and were not repeated on the guarded block. That earlier form ended its result arms with status 0. Those runs were not repeated on the form after the guarded block either, in which an inconclusive step or a failed removal exits 3 after its cleanup is attempted and a bundle match exits 1. On the form in which the two checks became separate blocks, the planted-file block takes its document root on its `set --` line and exits 1 on a finding, and both keep their values in positional parameters, bash -n in Bash 5.3.9 exited 0 and stub runs without network access checked its exit statuses. `tools/run_all_checks.sh` ran ShellCheck 0.11.0 over that form with no findings; no server run is recorded, and no demonstration was re-run. For the planted-file block, those runs covered the form whose reserved-name check lowercased the host with `tr`. Its current form, which matches reserved names in any letter case through bash's `nocasematch` option, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by November 2026 stub runs under bash 5.3.9 with curl stubbed, sudo replaced by a pass-through, a scratch document root and no network. In those runs eight reserved names in lower, upper and mixed case, bare and as subdomains, each exited 2 with the reserved-name message before any plant or request; two reserved names in upper or mixed case also did with `tr` absent from PATH, and under an inherited `nocasematch`, readonly and `declare -i` variables, or `set -e`, and a host outside those names reached the plants and requests. Under dash, which lacks bash's `shopt`, stub runs of the current form refused reserved and other host names alike with status 2 and its message that the block needs bash, before any plant or request. Real grep returned 1 silently for clean input, 0 with a matching fixture line and 2 with No such file or directory for missing input. Exposed servers disclose planted content or listings; fixed servers deny them, still serve challenge tokens and keep secrets out of bundles. HTTP outcomes remain unobserved. Any backup path known to have existed on the server should also return 403 or 404, without the file contents, at the deployed URL.

REASONED: following block; suffix and dotfile denial, per the guide's cited GNU coreutils mktemp, nginx access module, Apache mod_authz_core and Caddy matchers. No web-server deployment is available and local listeners are denied. bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. With a scratch document root and curl stub the block exited 0, printed nine STUB curl lines and removed the plants; independent fixtures confirmed all nine suffix/dotfile cases held PLANTED-SECRET at mode 0644. Those runs covered the block before its host guard was added and were not repeated on the guarded block. That earlier form ended its inconclusive arms with status 0. Those runs were not repeated on the form after the guarded block either, which exits 3 after attempting its cleanup when a plant or curl transfer was inconclusive or a removal failed. On the form after that, which also exits 1 when a probe returns PLANTED-SECRET, takes the document root on its `set --` line and keeps its values in positional parameters, bash -n in Bash 5.3.9 exited 0 and stub runs without network access checked its exit statuses. `tools/run_all_checks.sh` ran ShellCheck 0.11.0 over that form with no findings; no server run is recorded, and no demonstration was re-run. Those runs covered that form while its reserved-name check lowercased the host with `tr`. The current form, which matches reserved names in any letter case through bash's `nocasematch` option, is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by November 2026 stub runs under bash 5.3.9 with curl stubbed, sudo replaced by a pass-through, a scratch document root and no network. In those runs eight reserved names in lower, upper and mixed case, bare and as subdomains, each exited 2 with the reserved-name message before any plant or request; two reserved names in upper or mixed case also did with `tr` absent from PATH, and under an inherited `nocasematch`, readonly and `declare -i` variables, or `set -e`, and a host outside those names reached the plants and requests. Under dash, which lacks bash's `shopt`, stub runs of the current form refused reserved and other host names alike with status 2 and its message that the block needs bash, before any plant or request. Live exposed 200 responses with that body and fixed 403/404 responses without it remain unobserved. Also plant a readable file for each suffix and a generic dotfile, so the added classes are tested
against real content. Use GNU `mktemp`, and put this host's served host name and its document root on
the block's `set --` line. On an isolated test host, run before and after enabling the
deny rules: the exposed static server should return 200 with `PLANTED-SECRET`; the fixed server must
return 403 or 404 without that body. A failed plant or curl transfer is inconclusive, and so is a 200 without that body or any other code. The block attempts to remove every plant, and it exits 1 when a probe returned `PLANTED-SECRET`, otherwise 3 when a step was inconclusive or a removal failed, and otherwise 0.

```bash
# The following probes were not run against a server: no Caddy, nginx, Apache, or container
# runtime is available, and network restrictions prevent installing one. Expected exposed/fixed
# outcomes follow the Caddy path/path_regexp, nginx location/deny, and Apache FilesMatch/Require
# references in Sources. Local shell syntax and GNU mktemp suffix creation were checked only, on the
# block before its host guard was added. That form's inconclusive arms ended with status 0; the later
# forms, which exit 3 after attempting their cleanup when a step is inconclusive or a removal fails,
# were not re-checked, except that bash -n, stub runs and the ShellCheck 0.11.0 run in
# tools/run_all_checks.sh, which had no findings, checked the one that also exits 1 on PLANTED-SECRET
# while its host check lowercased with tr. This one, matching reserved names through nocasematch and
# refusing with status 2 outside bash, is covered by that suite's bash -n and ShellCheck 0.11.0 passes
# and by later stub runs.
(                                       # a subshell, so your own script arguments are untouched
  set +e                                # errexit off here, so a plant that ends nonzero is folded into the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_HOST' 'REPLACE_WITH_YOUR_DOCUMENT_ROOT'   # this host's served host name, no scheme, user name, port, path, query, fragment, percent sign or trailing dot, then its document root as an absolute path: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
  case "$1" in
    example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -u nocasematch   # every match below compares letter case exactly again
  case "$2" in
    ""|*REPLACE_WITH_*|[!/]*|*[[:cntrl:]]*) echo "substitute this host's document root, an absolute path, inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  plant_probe() (                       # the host, the document root, then one suffix ('' for the generic dotfile): plant, probe, then remove
    set -- "$1" "$2" "$3" "$2/probeXXXXXX"
    [ -n "$3" ] || set -- "$1" "$2" "$3" "$2/.probeXXXXXX"
    set -- "$1" "$2" "$3" "$(if sudo mktemp --suffix="$3" "$4" 2>/dev/null; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "$3" "${4%%$'\n'*}" "${4##*$'\n'}"   # the host, the document root, the suffix, the plant's path, then mktemp's exit status
    [ "$5" = 0 ] || { echo "inconclusive: could not plant suffix '$3' under $2"; exit 3; }
    set -- "$1" "$2" "$3" "$4" 0        # the 5th value is this plant's status so far, ranked as below
    if printf 'PLANTED-SECRET' | sudo tee "$4" >/dev/null && sudo chmod 0644 "$4"; then
      set -- "$1" "$2" "$3" "$4" "$5" "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 \
        -w "  <= %{http_code} /${4##*/}\n" "https://$1/${4##*/}"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
      set -- "$1" "$2" "$3" "$4" "$5" "${6%$'\n'*}" "${6##*$'\n'}"   # ..., what curl printed, then curl's exit status
      printf '%s' "$6"
      # Fixed: 403/404 and no PLANTED-SECRET. Exposed: 200 and PLANTED-SECRET.
      case "$7:$6" in
        0:*PLANTED-SECRET*) echo "FINDING: /${4##*/} returned PLANTED-SECRET"; set -- "$1" "$2" "$3" "$4" 1 ;;
        0:*'  <= 403 '*|0:*'  <= 404 '*) ;;
        0:*) echo "inconclusive: /${4##*/} answered without PLANTED-SECRET but with neither 403 nor 404"; set -- "$1" "$2" "$3" "$4" 3 ;;
        *) echo "inconclusive: curl failed"; set -- "$1" "$2" "$3" "$4" 3 ;;
      esac
    else
      echo "inconclusive: could not prepare $4"
      set -- "$1" "$2" "$3" "$4" 3
    fi
    sudo rm -f "$4" || { [ "$5" = 1 ] || set -- "$1" "$2" "$3" "$4" 3; }
    exit "$5"
  )
  set -- "$1" "$2" 0 '' .bak .old .orig '~' .sql .sql.gz .dump .tar.gz   # the host, the document root, the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0), then the suffixes still to plant
  while [ "$#" -gt 3 ]; do
    plant_probe "$1" "$2" "$4"
    case "$?:$3" in 0:*) ;; 1:*) set -- "$1" "$2" 1 "${@:4}" ;; *:1) ;; *) set -- "$1" "$2" 3 "${@:4}" ;; esac   # fold that plant's status into the block's, ranked as above
    set -- "$1" "$2" "$3" "${@:5}"
  done
  echo "block exit $3"
  exit "$3"                             # after every removal was attempted: 1 if a probe returned PLANTED-SECRET, else 3 if any step was inconclusive or a removal failed, else 0
)
```

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- nginx core module (`location`, `^~` modifier, matching order): https://nginx.org/en/docs/http/ngx_http_core_module.html
- nginx access module (`allow`, `deny`): https://nginx.org/en/docs/http/ngx_http_access_module.html
- Apache mod_authz_core (`Require all denied`): https://httpd.apache.org/docs/2.4/mod/mod_authz_core.html
- Apache core module (`<FilesMatch>`, `<DirectoryMatch>`): https://httpd.apache.org/docs/2.4/mod/core.html#filesmatch, https://httpd.apache.org/docs/2.4/mod/core.html#directorymatch
- Apache core `Options` (the `Indexes` option triggers a listing when there is no `DirectoryIndex`; the `-Indexes` relative form and the +/- merge rules): https://httpd.apache.org/docs/2.4/mod/core.html#options
- Apache mod_autoindex (the generated listing, and `ShowForbidden`, which by default hides entries a subrequest forbids): https://httpd.apache.org/docs/2.4/mod/mod_autoindex.html
- nginx autoindex module (`autoindex` is `off` by default): https://nginx.org/en/docs/http/ngx_http_autoindex_module.html
- Caddy `respond` directive (rolling documentation, checked September 2026): https://caddyserver.com/docs/caddyfile/directives/respond
- Caddy matchers, `path`, `path_regexp`, `not` and named matcher sets (rolling documentation, checked September 2026): https://caddyserver.com/docs/caddyfile/matchers
- Caddy v2.11.4 matcher implementation (`MatchPath`, `MatchPathRE`, `MatchNot`): https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/matchers.go
- GNU coreutils `mktemp` (`--suffix`): https://www.gnu.org/software/coreutils/manual/html_node/mktemp-invocation.html
- Next.js environment variables (`NEXT_PUBLIC_`): https://nextjs.org/docs/pages/guides/environment-variables
- Vite env variables (`VITE_`): https://vite.dev/guide/env-and-mode
- Create React App environment variables (`REACT_APP_`, deprecation notice): https://create-react-app.dev/docs/adding-custom-environment-variables/
- Caddy v2.11.4 file listings require the `browse` configuration (checked October 2026): https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/fileserver/staticfiles.go#L140-L142 ; https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/fileserver/staticfiles.go#L371-L374
- Caddy v2.11.4 ACME HTTP challenges precede user-defined handlers (checked October 2026): https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/server.go#L384-L388
- RFC 8555 section 8.3 HTTP-01 validation (checked October 2026): https://www.rfc-editor.org/rfc/rfc8555.html#section-8.3
- GNU grep 3.12 manual, Exit Status, lines 1110-1115 (checked October 2026): https://git.savannah.gnu.org/cgit/grep.git/tree/doc/grep.texi?h=v3.12#n1110
- GNU grep 3.12 manual, `-s`/`--no-messages`, lines 425-431 (checked October 2026): https://git.savannah.gnu.org/cgit/grep.git/tree/doc/grep.texi?h=v3.12#n425
- GNU grep 3.12 source, failed input open, lines 1756-1772 (checked October 2026): https://git.savannah.gnu.org/cgit/grep.git/tree/src/grep.c?h=v3.12#n1756
- GNU grep 3.12 source, input error diagnosis, lines 661-668 (checked October 2026): https://git.savannah.gnu.org/cgit/grep.git/tree/src/grep.c?h=v3.12#n661
- Debian apache2 packaging version 2.4.69-1 (checked October 2026): https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/changelog#L1
- Debian apache2 2.4.69-1 document-root Options template (checked October 2026): https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/config-dir/apache2.conf.in#L170-L174
- Debian apache2 2.4.69-1 DirectoryIndex list (checked October 2026): https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/config-dir/mods-available/dir.conf#L1
- Debian apache2 2.4.69-1 default modules on fresh installs and configure invocation (checked October 2026): https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/apache2.postinst#L38-L52 ; https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/apache2.postinst#L257-L266
- ECMA-426 c724f0f494b44b21b651fdbd6412d3437eef0e72 sources and optional sourcesContent (checked October 2026): https://github.com/tc39/ecma426/blob/c724f0f494b44b21b651fdbd6412d3437eef0e72/spec.emu#L584-L585
- ECMA-426 c724f0f494b44b21b651fdbd6412d3437eef0e72 data URI linking and sourceMappingURL comments (checked October 2026). ECMA-426 c724f0f494b44b21b651fdbd6412d3437eef0e72 data URI linking and sourceMappingURL comment sources: https://github.com/tc39/ecma426/blob/c724f0f494b44b21b651fdbd6412d3437eef0e72/spec.emu#L1294 ; https://github.com/tc39/ecma426/blob/c724f0f494b44b21b651fdbd6412d3437eef0e72/spec.emu#L1323 ; https://github.com/tc39/ecma426/blob/c724f0f494b44b21b651fdbd6412d3437eef0e72/spec.emu#L1415
- Next.js v16.3.6 production browser source maps default and opt-in serving (checked October 2026): https://github.com/vercel/next.js/blob/v16.3.6/docs/01-app/03-api-reference/05-config/01-next-config-js/productionBrowserSourceMaps.mdx#L8-L18
- Vite v8.3.1 build.sourcemap default and output modes (checked October 2026): https://github.com/vitejs/vite/blob/v8.3.1/docs/config/build-options.md#L145-L150


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- nginx: nginx documentation (unknown)
- apache: Apache documentation (2.4)
- caddy: Caddy documentation (v2.11.4)
- caddy-rolling: Caddy documentation (rolling) (unknown)
- next: Next.js documentation (unknown)
- vite: Vite documentation (unknown)
- cra: Create React App documentation (unknown)
- next-maps: Next.js browser source maps (v16.3.6)
- vite-maps: Vite production source maps (v8.3.1)
- debian-packaging: Debian apache2 packaging (2.4.69-1)
- acme-http01: ACME HTTP-01 (RFC 8555)
- ecma426: ECMA-426 (c724f0f494b44b21b651fdbd6412d3437eef0e72)
- coreutils: GNU coreutils documentation (unknown)
- grep: GNU grep (3.12)

Claims (full source mapping in the JSON block below):

- nginx-dotfiles (REASONED; nginx): Deny dot-prefixed path segments by regex; place deny regex locations before other matching regex locations. Exact locations or a longest matching ^~ prefix can bypass them.
- nginx-backups (REASONED; nginx): Case-insensitive suffix regex denies .bak, .old, .orig, ~, .sql, .sql.gz, .dump and .tar.gz outside the ACME exemption, subject to location precedence.
- nginx-acme (REASONED; nginx): Only /.well-known/acme-challenge/ is exempted: when its ^~ location is the longest matching prefix, it skips both deny regexes. Keep the challenge directory free of secrets.
- nginx-security-txt (REASONED; nginx): The ACME-only exemption leaves /.well-known/security.txt denied; add location = /.well-known/security.txt {} to serve it, because exact matches precede regex locations.
- apache-directories (REASONED; apache): DirectoryMatch denies dot-prefixed filesystem segments except an exact .well-known segment; .well-known-backup is not exempt. FilesMatch suffix denial still applies inside .well-known/.
- apache-files (REASONED; apache): Case-insensitive FilesMatch denies dotfile basenames and .bak, .old, .orig, ~, .sql, .sql.gz, .dump and .tar.gz suffixes; DirectoryMatch is still needed for .git/config.
- apache-listing (REASONED; apache, debian-packaging): Debian apache2 2.4.69-1 sets Indexes FollowSymLinks on /var/www/; DirectoryIndex lists index.html index.cgi index.pl index.php index.xhtml index.htm; dir and autoindex are enabled on fresh installs. With these defaults, index-less directories can expose other filenames. Ubuntu packaging was not checked by this guide.
- apache-forbidden (REASONED; apache): mod_autoindex hides entries whose subrequests return 403 unless ShowForbidden is enabled; unmatched exports such as archive.zip and customers.csv can still be listed.
- apache-options (REASONED; apache): Options -Indexes removes listing, preserving inherited options; Apache 2.4 rejects mixing relative +/- and bare options.
- nginx-listing (REASONED; nginx): nginx autoindex defaults off.
- caddy-listing (REASONED; caddy-rolling, caddy): Guide says Caddy lists only with file_server browse.
- caddy-deny (REASONED; caddy, caddy-rolling): Caddy v2.11.4 matchers return 404 for dot-prefixed segments at any depth outside root /.well-known/*, and case-insensitive .bak, .old, .orig, ~, .sql, .sql.gz, .dump and .tar.gz suffixes everywhere. Server execution was not run.
- caddy-acme (REASONED; caddy, caddy-rolling): ANDed path_regexp and not path matchers exempt the root /.well-known/ subtree only from dotfile denial; suffix denial still applies and .well-known-backup is not exempt. Keep the subtree free of secrets.
- backup-storage (REASONED; nginx, apache, caddy, caddy-rolling): Keep dumps and backups outside the document root or in object storage; filename denies are a backstop and cannot recognize secrets or backups with unmatched names.
- suffix-policy (REASONED; nginx, apache, caddy, caddy-rolling): Suffix denies also block intended public downloads, including release archives; narrow the policy for the site and verify intended downloads remain accessible.
- next-public (REASONED; next): NEXT_PUBLIC_ embeds values in browser JavaScript; keep provider keys server-side behind backend routes.
- vite-public (REASONED; vite): VITE_ embeds values in browser JavaScript; reserve for public values.
- cra-public (REASONED; cra): Deprecated Create React App embeds REACT_APP_ values in browser builds.
- source-maps (REASONED; next, vite, ecma426, next-maps, vite-maps): ECMA-426 sources are URLs or null; sourcesContent is optional. Guide assessment: maps can expose original source when embedded or retrievable, through separate files or sourceMappingURL data: URLs. Next.js v16.3.6 production browser maps default disabled; Vite v8.3.1 build.sourcemap defaults false. Create React App map defaults were not checked. Guide reasoning: removing the comment does not unpublish deployed maps. Guide advice: do not ship or leave served maps for code not meant to be public.
- verify-dotfiles (REASONED; nginx, apache, caddy, caddy-rolling): Plant an exclusive, readable .env.probe file; expect 403 or 404 without PLANTED-SECRET. Also probe .git/config, config.php.bak and db.sql; absent files are inconclusive, so plant real files to test each rule and remove only created probes.
- verify-listing (REASONED; apache): Plant a throwaway file in an existing index-less uploads directory; Options -Indexes should yield 403 or 404, never a 200 listing. An absent or unwritable directory is inconclusive; remove the probe afterward.
- verify-acme (REASONED; nginx, apache, acme-http01): Plant a readable challenge token; webroot requests over HTTPS and HTTP:80 should return probe, not 403. nginx exempts only the challenge prefix; Apache exempts .well-known segments. A missing challenge directory skips these checks (status 2); other failed preparation is inconclusive.
- verify-lookalike (REASONED; nginx, apache, caddy, caddy-rolling): Probe .well-known-backup/config across nginx, Apache and Caddy; expect 403 or 404. Plant a real readable file to distinguish denial from absence, then remove it.
- verify-bundle (REASONED; next, vite, cra, grep): Scan built client output for credential patterns/literal secrets; GNU grep 3.12 returns 0 for a selected line, 1 for none and 2 for an error. A missing directory is an error; discarding errors can leave silence without a clean result. Clean does not exclude transformed secrets.
- verify-backup (REASONED; nginx, apache, caddy, caddy-rolling): Known previously deployed backup URLs should return 403 or 404 without the file contents.
- verify-suffixes (REASONED; nginx, apache, caddy, coreutils, caddy-rolling): GNU mktemp --suffix plants readable files for .bak, .old, .orig, ~, .sql, .sql.gz, .dump and .tar.gz plus a dotfile. Exposed: 200 with PLANTED-SECRET; fixed: 403 or 404 without it. Failed planting or curl is inconclusive (status 3). Syntax and suffixes were checked on a form exiting 0 when inconclusive; a tr-based form and this one had bash -n, ShellCheck 0.11.0 and stub runs, none on a server.

````json
{
  "schema": 1,
  "checked": "2026-10-18",
  "documentation_checked": "2026-09",
  "body_sha256": "d986fd30ab3dd83def744dac305fb33c33ab6dd8d312f321793331a3afe12ed6",
  "components": {
    "nginx": {
      "name": "nginx documentation",
      "basis": "unknown",
      "sources": {
        "s0e5162d1ce2b": "https://nginx.org/en/docs/http/ngx_http_access_module.html",
        "sbd17bad53c9d": "https://nginx.org/en/docs/http/ngx_http_autoindex_module.html",
        "s40bdf1af1596": "https://nginx.org/en/docs/http/ngx_http_core_module.html"
      }
    },
    "apache": {
      "name": "Apache documentation",
      "basis": "2.4",
      "sources": {
        "s24f06763d14a": "https://httpd.apache.org/docs/2.4/mod/core.html#directorymatch",
        "se24e9bbc0443": "https://httpd.apache.org/docs/2.4/mod/core.html#filesmatch",
        "s97468bf1f299": "https://httpd.apache.org/docs/2.4/mod/core.html#options",
        "s7313b1b624d5": "https://httpd.apache.org/docs/2.4/mod/mod_authz_core.html",
        "sef5ff46eddf7": "https://httpd.apache.org/docs/2.4/mod/mod_autoindex.html"
      }
    },
    "caddy": {
      "name": "Caddy documentation",
      "basis": "v2.11.4",
      "sources": {
        "s450aa9ed710b": "https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/matchers.go",
        "se8dd8140d6b8": "https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/fileserver/staticfiles.go#L140-L142",
        "s86912a2959e0": "https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/fileserver/staticfiles.go#L371-L374",
        "s128797d9a40f": "https://github.com/caddyserver/caddy/blob/v2.11.4/modules/caddyhttp/server.go#L384-L388"
      }
    },
    "caddy-rolling": {
      "name": "Caddy documentation (rolling)",
      "basis": "unknown",
      "sources": {
        "se9ab71afc4ba": "https://caddyserver.com/docs/caddyfile/directives/respond",
        "s38b1b78ce980": "https://caddyserver.com/docs/caddyfile/matchers"
      }
    },
    "next": {
      "name": "Next.js documentation",
      "basis": "unknown",
      "sources": {
        "sb98bee5b61c8": "https://nextjs.org/docs/pages/guides/environment-variables"
      }
    },
    "vite": {
      "name": "Vite documentation",
      "basis": "unknown",
      "sources": {
        "s3fc0892e0f58": "https://vite.dev/guide/env-and-mode"
      }
    },
    "cra": {
      "name": "Create React App documentation",
      "basis": "unknown",
      "sources": {
        "scfb24624addd": "https://create-react-app.dev/docs/adding-custom-environment-variables/"
      }
    },
    "next-maps": {
      "name": "Next.js browser source maps",
      "basis": "v16.3.6",
      "sources": {
        "s6964da09fc21": "https://github.com/vercel/next.js/blob/v16.3.6/docs/01-app/03-api-reference/05-config/01-next-config-js/productionBrowserSourceMaps.mdx#L8-L18"
      }
    },
    "vite-maps": {
      "name": "Vite production source maps",
      "basis": "v8.3.1",
      "sources": {
        "sf12c9114bd79": "https://github.com/vitejs/vite/blob/v8.3.1/docs/config/build-options.md#L145-L150"
      }
    },
    "debian-packaging": {
      "name": "Debian apache2 packaging",
      "basis": "2.4.69-1",
      "sources": {
        "s62f6ed2866ab": "https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/changelog#L1",
        "s90898e0f03b6": "https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/config-dir/apache2.conf.in#L170-L174",
        "s6f77b580cc87": "https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/config-dir/mods-available/dir.conf#L1",
        "s7ea1fcaca182": "https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/apache2.postinst#L38-L52",
        "sd7d93d2a9705": "https://salsa.debian.org/apache-team/apache2/-/blob/fc6e58fa5248fc058591097c94ac8fde34283519/debian/apache2.postinst#L257-L266"
      }
    },
    "acme-http01": {
      "name": "ACME HTTP-01",
      "basis": "RFC 8555",
      "sources": {
        "se60bdd68e41d": "https://www.rfc-editor.org/rfc/rfc8555.html#section-8.3"
      }
    },
    "ecma426": {
      "name": "ECMA-426",
      "basis": "c724f0f494b44b21b651fdbd6412d3437eef0e72",
      "sources": {
        "s5de29cfb3e99": "https://github.com/tc39/ecma426/blob/c724f0f494b44b21b651fdbd6412d3437eef0e72/spec.emu#L584-L585",
        "s2af3a1c52b4a": "https://github.com/tc39/ecma426/blob/c724f0f494b44b21b651fdbd6412d3437eef0e72/spec.emu#L1294",
        "sfeb03b2200f4": "https://github.com/tc39/ecma426/blob/c724f0f494b44b21b651fdbd6412d3437eef0e72/spec.emu#L1323",
        "s94b6d647e4bc": "https://github.com/tc39/ecma426/blob/c724f0f494b44b21b651fdbd6412d3437eef0e72/spec.emu#L1415"
      }
    },
    "coreutils": {
      "name": "GNU coreutils documentation",
      "basis": "unknown",
      "sources": {
        "s4166af5265e7": "https://www.gnu.org/software/coreutils/manual/html_node/mktemp-invocation.html"
      }
    },
    "grep": {
      "name": "GNU grep",
      "basis": "3.12",
      "sources": {
        "s5170317ddea8": "https://git.savannah.gnu.org/cgit/grep.git/tree/doc/grep.texi?h=v3.12#n1110",
        "s057470125f4c": "https://git.savannah.gnu.org/cgit/grep.git/tree/doc/grep.texi?h=v3.12#n425",
        "sb18b36e247d7": "https://git.savannah.gnu.org/cgit/grep.git/tree/src/grep.c?h=v3.12#n1756",
        "s0c4ddbee9e68": "https://git.savannah.gnu.org/cgit/grep.git/tree/src/grep.c?h=v3.12#n661"
      }
    }
  },
  "claims": {
    "nginx-dotfiles": {"text": "Deny dot-prefixed path segments by regex; place deny regex locations before other matching regex locations. Exact locations or a longest matching ^~ prefix can bypass them.", "components": ["nginx"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596"], "status": "REASONED"},
    "nginx-backups": {"text": "Case-insensitive suffix regex denies .bak, .old, .orig, ~, .sql, .sql.gz, .dump and .tar.gz outside the ACME exemption, subject to location precedence.", "components": ["nginx"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596"], "status": "REASONED"},
    "nginx-acme": {"text": "Only /.well-known/acme-challenge/ is exempted: when its ^~ location is the longest matching prefix, it skips both deny regexes. Keep the challenge directory free of secrets.", "components": ["nginx"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596"], "status": "REASONED"},
    "nginx-security-txt": {"text": "The ACME-only exemption leaves /.well-known/security.txt denied; add location = /.well-known/security.txt {} to serve it, because exact matches precede regex locations.", "components": ["nginx"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596"], "status": "REASONED"},
    "apache-directories": {"text": "DirectoryMatch denies dot-prefixed filesystem segments except an exact .well-known segment; .well-known-backup is not exempt. FilesMatch suffix denial still applies inside .well-known/.", "components": ["apache"], "sources": ["apache:s24f06763d14a", "apache:s7313b1b624d5", "apache:se24e9bbc0443"], "status": "REASONED"},
    "apache-files": {"text": "Case-insensitive FilesMatch denies dotfile basenames and .bak, .old, .orig, ~, .sql, .sql.gz, .dump and .tar.gz suffixes; DirectoryMatch is still needed for .git/config.", "components": ["apache"], "sources": ["apache:se24e9bbc0443", "apache:s7313b1b624d5"], "status": "REASONED"},
    "apache-listing": {"text": "Debian apache2 2.4.69-1 sets Indexes FollowSymLinks on /var/www/; DirectoryIndex lists index.html index.cgi index.pl index.php index.xhtml index.htm; dir and autoindex are enabled on fresh installs. With these defaults, index-less directories can expose other filenames. Ubuntu packaging was not checked by this guide.", "components": ["apache", "debian-packaging"], "sources": ["apache:s97468bf1f299", "apache:sef5ff46eddf7", "debian-packaging:s62f6ed2866ab", "debian-packaging:s90898e0f03b6", "debian-packaging:s6f77b580cc87", "debian-packaging:s7ea1fcaca182", "debian-packaging:sd7d93d2a9705"], "status": "REASONED"},
    "apache-forbidden": {"text": "mod_autoindex hides entries whose subrequests return 403 unless ShowForbidden is enabled; unmatched exports such as archive.zip and customers.csv can still be listed.", "components": ["apache"], "sources": ["apache:sef5ff46eddf7"], "status": "REASONED"},
    "apache-options": {"text": "Options -Indexes removes listing, preserving inherited options; Apache 2.4 rejects mixing relative +/- and bare options.", "components": ["apache"], "sources": ["apache:s97468bf1f299"], "status": "REASONED"},
    "nginx-listing": {"text": "nginx autoindex defaults off.", "components": ["nginx"], "sources": ["nginx:sbd17bad53c9d"], "status": "REASONED"},
    "caddy-listing": {"text": "Guide says Caddy lists only with file_server browse.", "components": ["caddy-rolling", "caddy"], "sources": ["caddy-rolling:se9ab71afc4ba", "caddy-rolling:s38b1b78ce980", "caddy:se8dd8140d6b8", "caddy:s86912a2959e0"], "status": "REASONED"},
    "caddy-deny": {"text": "Caddy v2.11.4 matchers return 404 for dot-prefixed segments at any depth outside root /.well-known/*, and case-insensitive .bak, .old, .orig, ~, .sql, .sql.gz, .dump and .tar.gz suffixes everywhere. Server execution was not run.", "components": ["caddy", "caddy-rolling"], "sources": ["caddy-rolling:se9ab71afc4ba", "caddy-rolling:s38b1b78ce980", "caddy:s450aa9ed710b"], "status": "REASONED"},
    "caddy-acme": {"text": "ANDed path_regexp and not path matchers exempt the root /.well-known/ subtree only from dotfile denial; suffix denial still applies and .well-known-backup is not exempt. Keep the subtree free of secrets.", "components": ["caddy", "caddy-rolling"], "sources": ["caddy-rolling:se9ab71afc4ba", "caddy-rolling:s38b1b78ce980", "caddy:s450aa9ed710b", "caddy:s128797d9a40f"], "status": "REASONED"},
    "backup-storage": {"text": "Keep dumps and backups outside the document root or in object storage; filename denies are a backstop and cannot recognize secrets or backups with unmatched names.", "components": ["nginx", "apache", "caddy", "caddy-rolling"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596", "apache:se24e9bbc0443", "apache:s7313b1b624d5", "caddy-rolling:se9ab71afc4ba", "caddy-rolling:s38b1b78ce980", "caddy:s450aa9ed710b"], "status": "REASONED"},
    "suffix-policy": {"text": "Suffix denies also block intended public downloads, including release archives; narrow the policy for the site and verify intended downloads remain accessible.", "components": ["nginx", "apache", "caddy", "caddy-rolling"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596", "apache:se24e9bbc0443", "apache:s7313b1b624d5", "caddy-rolling:se9ab71afc4ba", "caddy-rolling:s38b1b78ce980", "caddy:s450aa9ed710b"], "status": "REASONED"},
    "next-public": {"text": "NEXT_PUBLIC_ embeds values in browser JavaScript; keep provider keys server-side behind backend routes.", "components": ["next"], "sources": ["next:sb98bee5b61c8"], "status": "REASONED"},
    "vite-public": {"text": "VITE_ embeds values in browser JavaScript; reserve for public values.", "components": ["vite"], "sources": ["vite:s3fc0892e0f58"], "status": "REASONED"},
    "cra-public": {"text": "Deprecated Create React App embeds REACT_APP_ values in browser builds.", "components": ["cra"], "sources": ["cra:scfb24624addd"], "status": "REASONED"},
    "source-maps": {"text": "ECMA-426 sources are URLs or null; sourcesContent is optional. Guide assessment: maps can expose original source when embedded or retrievable, through separate files or sourceMappingURL data: URLs. Next.js v16.3.6 production browser maps default disabled; Vite v8.3.1 build.sourcemap defaults false. Create React App map defaults were not checked. Guide reasoning: removing the comment does not unpublish deployed maps. Guide advice: do not ship or leave served maps for code not meant to be public.", "components": ["next", "vite", "ecma426", "next-maps", "vite-maps"], "sources": ["next:sb98bee5b61c8", "vite:s3fc0892e0f58", "ecma426:s5de29cfb3e99", "ecma426:s2af3a1c52b4a", "ecma426:sfeb03b2200f4", "ecma426:s94b6d647e4bc", "next-maps:s6964da09fc21", "vite-maps:sf12c9114bd79"], "status": "REASONED"},
    "verify-dotfiles": {"text": "Plant an exclusive, readable .env.probe file; expect 403 or 404 without PLANTED-SECRET. Also probe .git/config, config.php.bak and db.sql; absent files are inconclusive, so plant real files to test each rule and remove only created probes.", "components": ["nginx", "apache", "caddy", "caddy-rolling"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596", "apache:s24f06763d14a", "apache:s7313b1b624d5", "apache:se24e9bbc0443", "caddy-rolling:se9ab71afc4ba", "caddy-rolling:s38b1b78ce980", "caddy:s450aa9ed710b"], "status": "REASONED", "verify": [1]},
    "verify-listing": {"text": "Plant a throwaway file in an existing index-less uploads directory; Options -Indexes should yield 403 or 404, never a 200 listing. An absent or unwritable directory is inconclusive; remove the probe afterward.", "components": ["apache"], "sources": ["apache:s97468bf1f299", "apache:sef5ff46eddf7"], "status": "REASONED", "verify": [1]},
    "verify-acme": {"text": "Plant a readable challenge token; webroot requests over HTTPS and HTTP:80 should return probe, not 403. nginx exempts only the challenge prefix; Apache exempts .well-known segments. A missing challenge directory skips these checks (status 2); other failed preparation is inconclusive.", "components": ["nginx", "apache", "acme-http01"], "sources": ["nginx:s40bdf1af1596", "nginx:s0e5162d1ce2b", "apache:s24f06763d14a", "acme-http01:se60bdd68e41d"], "status": "REASONED", "verify": [1]},
    "verify-lookalike": {"text": "Probe .well-known-backup/config across nginx, Apache and Caddy; expect 403 or 404. Plant a real readable file to distinguish denial from absence, then remove it.", "components": ["nginx", "apache", "caddy", "caddy-rolling"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596", "apache:s24f06763d14a", "apache:s7313b1b624d5", "caddy-rolling:se9ab71afc4ba", "caddy-rolling:s38b1b78ce980", "caddy:s450aa9ed710b"], "status": "REASONED", "verify": [1]},
    "verify-bundle": {"text": "Scan built client output for credential patterns/literal secrets; GNU grep 3.12 returns 0 for a selected line, 1 for none and 2 for an error. A missing directory is an error; discarding errors can leave silence without a clean result. Clean does not exclude transformed secrets.", "components": ["next", "vite", "cra", "grep"], "sources": ["next:sb98bee5b61c8", "vite:s3fc0892e0f58", "cra:scfb24624addd", "grep:s5170317ddea8", "grep:s057470125f4c", "grep:sb18b36e247d7", "grep:s0c4ddbee9e68"], "status": "REASONED", "verify": [2]},
    "verify-backup": {"text": "Known previously deployed backup URLs should return 403 or 404 without the file contents.", "components": ["nginx", "apache", "caddy", "caddy-rolling"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596", "apache:se24e9bbc0443", "apache:s7313b1b624d5", "caddy-rolling:se9ab71afc4ba", "caddy-rolling:s38b1b78ce980", "caddy:s450aa9ed710b"], "status": "REASONED"},
    "verify-suffixes": {"text": "GNU mktemp --suffix plants readable files for .bak, .old, .orig, ~, .sql, .sql.gz, .dump and .tar.gz plus a dotfile. Exposed: 200 with PLANTED-SECRET; fixed: 403 or 404 without it. Failed planting or curl is inconclusive (status 3). Syntax and suffixes were checked on a form exiting 0 when inconclusive; a tr-based form and this one had bash -n, ShellCheck 0.11.0 and stub runs, none on a server.", "components": ["nginx", "apache", "caddy", "coreutils", "caddy-rolling"], "sources": ["nginx:s0e5162d1ce2b", "nginx:s40bdf1af1596", "apache:se24e9bbc0443", "apache:s7313b1b624d5", "caddy-rolling:se9ab71afc4ba", "caddy-rolling:s38b1b78ce980", "caddy:s450aa9ed710b", "coreutils:s4166af5265e7"], "status": "REASONED", "verify": [3]}
  }
}
````
<!-- version-basis:end -->
