# Time-series and metrics stores: InfluxDB, VictoriaMetrics, and QuestDB

InfluxDB, VictoriaMetrics and QuestDB are time-series databases: they store readings over time, like server metrics. This guide helps your AI assistant configure each securely, including InfluxDB 2.x setup finished privately and applications given scoped tokens, VictoriaMetrics cluster RPC ports limited to cluster members, and QuestDB's default database login changed.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/time-series-metrics-stores.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against InfluxDB OSS 2.x and 1.x, VictoriaMetrics single-node v1.155.0, VictoriaMetrics cluster v1.155.0-cluster, VictoriaMetrics shipped Compose image v1.154.1, and QuestDB Enterprise qualification 4.0.0; 2 further sources are pinned to a commit and 2 carry no recorded version. Metadata reviewed 2026-09-26; documentation checked September 2026. The guide records 45 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

A metrics store ingests over HTTP and answers queries over an HTTP API, and most ship a web console beside it. Several of them either authenticate nothing by default or ship a known default credential, so an instance that is reachable from off-host lets a stranger read your operational and business series, write false points that poison dashboards and alerts, or delete history. This guide covers three that AI-assisted projects commonly stand up. The controls are the same shape in each: bind the listeners privately, put authentication and TLS in front where the engine has none of its own, and change every default credential. [fronting-auth.md](fronting-auth.md) is the reverse-proxy pattern these lean on, [secrets.md](secrets.md) covers the tokens and passwords, and [mfa.md](mfa.md) is the account layer. All ports below bind all interfaces (`0.0.0.0`) unless noted, and native TLS is off unless you configure it. Replace every illustrative address and name.

## InfluxDB

### OSS 2.x

The HTTP API, the UI, and the write endpoint all share port `8086`. You cannot turn authentication off or on with a flag: a fresh instance is instead *un-set-up*, and `GET /api/v2/setup` returns `allowed: true` until someone completes onboarding. Whoever reaches an exposed, un-initialized instance first can `POST /api/v2/setup` to create the initial user, organization, and an all-access operator token, which is a full takeover. Complete setup privately, then hand applications *scoped* tokens rather than the operator token. Bind the listener privately and enable TLS in the config file (located through `INFLUXD_CONFIG_PATH`):

```yaml
http-bind-address: "127.0.0.1:8086"
tls-cert: "/etc/ssl/influxdb.crt"
tls-key: "/etc/ssl/influxdb.key"
```

### OSS 1.x

Port `8086` again carries query, write, and administrative statements, and the `[http]` setting `auth-enabled` is `false` by default. An unauthenticated caller can therefore read every database, write points, and run destructive statements such as `DROP DATABASE`. Create an administrator user first, then require authentication and turn on HTTPS:

```toml
[http]
  bind-address = "127.0.0.1:8086"
  auth-enabled = true
  https-enabled = true
  https-certificate = "/etc/ssl/influxdb.crt"
  https-private-key = "/etc/ssl/influxdb.key"
```

Enabling `auth-enabled` does not by itself authenticate the Prometheus remote-read API; set `prom-read-auth-enabled = true` as well, since it defaults to `false` and has no effect until `auth-enabled` is on. The backup and restore RPC on `8088` binds `127.0.0.1` by default; keep it there. Leave the optional Graphite, collectd, OpenTSDB, and UDP inputs disabled unless you are separately securing them, since each is another unauthenticated write path.

## VictoriaMetrics

### Single-node

At v1.155.0 single-node (commit `3fec2f72414d00d1acda807c8818d7af90cc966d`), the HTTP API, UI and HTTP ingest share the fallback address `-httpListenAddr=:8428` when no address is supplied. It listens on every IPv4 interface by default (`tcp4`); `-enableTCP6`, default `false`, enables IPv6 too. The shipped `deployment/docker/compose-vm-single.yml` publishes `8428:8428` without a host IP, so it requests publication on every host interface by default. That example selects image v1.154.1, despite being shipped at source tag v1.155.0; it also enables and publishes additional ingest listeners.

HTTP Basic authentication uses `-httpAuth.username` and `-httpAuth.password`, both empty by default. It is disabled whenever the username is empty, even if a password is set. With a username set, one credential covers ordinary query, UI and HTTP ingest routes, including `/api/v1/import`, `/api/v1/import/csv`, `/api/v1/import/native`, the `/api/v1/import/prometheus` prefix and their supported `/prometheus` aliases, remote write, InfluxDB writes, OpenTelemetry, DataDog, New Relic and Zabbix ingestion. These ingest routes have no separate endpoint auth key.

Basic auth does not cover `/health`, `/ping`, `/-/healthy`, `/-/ready`, `/robots.txt` or any path ending in `/favicon.ico`. `/ready` and `/influx/health` do pass through Basic auth. The wrapper also answers `OPTIONS` before authentication, and handles an optional `-http.pathPrefix` redirect or missing-prefix error before authentication. Paths here are relative to that configured prefix. These responses do not demonstrate protection of data or administrative operations.

Bind the HTTP listener privately, and configure HTTPS with `-tls`, `-tlsCertFile` and `-tlsKeyFile`:

```text
-httpListenAddr=127.0.0.1:8428
-httpAuth.username=REPLACE_WITH_A_NAME
-httpAuth.password=REPLACE_WITH_A_SECRET
-tls -tlsCertFile=/etc/ssl/vm.crt -tlsKeyFile=/etc/ssl/vm.key
```

The following handlers check their own keys. Every key defaults to empty:

| Handler | Flag |
| --- | --- |
| `/snapshot/create`, `/snapshot/list`, `/snapshot/delete`, `/snapshot/delete_all`, and creation through `/api/v1/admin/tsdb/snapshot` | `-snapshotAuthKey` |
| POST `/api/v1/admin/tsdb/delete_series` and `/prometheus/api/v1/admin/tsdb/delete_series`; POST `/tags/delSeries` and `/graphite/tags/delSeries` | `-deleteAuthKey` |
| `/internal/force_merge` | `-forceMergeAuthKey` |
| `/internal/force_flush` | `-forceFlushAuthKey` |
| `/internal/resetRollupResultCache` | `-search.resetCacheAuthKey` |
| `/internal/log_new_series` | `-logNewSeriesAuthKey` |
| `/api/v1/admin/status/metric_names_stats/reset` | `-metricNamesStatsResetAuthKey` |
| `/config`, `/api/v1/status/config`, and their `/prometheus` aliases | `-configAuthKey` |
| `/-/reload` and `/prometheus/-/reload` | `-reloadAuthKey` |
| `/metrics` | `-metricsAuthKey` |
| `/flags` | `-flagsAuthKey` |
| `/debug/pprof/*` (with the slash after `pprof`) | `-pprofAuthKey` |

For these registered routes, an empty key falls back to Basic auth, leaving the operation unauthenticated if the username is also empty. A nonempty key requires a matching `authKey` request parameter and skips Basic auth; it replaces that check rather than adding a second credential. Missing or wrong keys return `401`, even with correct Basic credentials. The override is limited to the registered paths: another alias accepted by an application handler can still require Basic auth before its endpoint-key check. Setting a key does not enable the operation or protect other routes. Keep administrative, configuration and debug routes private, and use `vmauth` or a reverse proxy with TLS and per-route restrictions for client access.

Other listener flags are `-graphiteListenAddr` (TCP and UDP), `-influxListenAddr` (TCP and UDP), `-opentsdbListenAddr` (TCP and UDP, with both telnet and HTTP put on TCP), `-opentsdbHTTPListenAddr` (HTTP over TCP), and `-vmselectAddr` (cluster-native query RPC). All default to empty and are disabled while empty. Leave them disabled unless needed; bind enabled listeners privately and restrict access to trusted clients separately from the main HTTP listener. None of these listeners is given a TLS configuration, so the HTTP `-tls` settings never apply to them. `-httpAuth.*` Basic auth is checked only on OpenTSDB HTTP put requests (`-opentsdbHTTPListenAddr`, and the HTTP branch of `-opentsdbListenAddr`); Graphite, InfluxDB line protocol over TCP and UDP, and OpenTSDB telnet and UDP accept data with no authentication at all.

### Cluster

At v1.155.0-cluster, the open-source cluster splits HTTP across three components: `vminsert` takes ingestion on `-httpListenAddr=:8480`, `vmselect` takes queries and the UI on `:8481`, and `vmstorage` exposes maintenance and metrics on `:8482`. These are the fallback addresses when no `-httpListenAddr` is supplied. Each binds every IPv4 interface by default; `-enableTCP6` also enables IPv6. Each HTTP component accepts `-httpAuth.username` and `-httpAuth.password`, both empty by default; Basic authentication is disabled while the username is empty.

On `vmstorage`, `-vminsertAddr=:8400` and `-vmselectAddr=:8401` also bind every IPv4 interface by default. These native RPC listeners have no authentication or native TLS in this open-source build. Their handshake checks a protocol identifier and negotiates compression, not a credential. A caller speaking the protocol can write arbitrary series through `8400`, or read and delete series through `8401`; the latter also exposes tenant enumeration, metric-name registration and usage-statistics reset. HTTP Basic auth, endpoint auth keys and `vmauth` do not protect these sockets. Bind `-vminsertAddr` and `-vmselectAddr` to each storage node's cluster-network IP and restrict access to trusted cluster members with firewall or network-policy rules. A private address alone is not an access control. The optional `-clusternativeListenAddr` on `vminsert` and `vmselect` is empty (disabled) by default; restrict it to the same trusted network if enabled for a multi-level cluster.

The HTTP maintenance and disclosure handlers have their own keys:

- On `vmstorage` (`8482`), `-snapshotAuthKey` gates `/snapshot/create`, `/snapshot/list`, `/snapshot/delete` and `/snapshot/delete_all`; `-forceMergeAuthKey` gates `/internal/force_merge`; `-forceFlushAuthKey` gates `/internal/force_flush`; and `-logNewSeriesAuthKey` gates `/internal/log_new_series`.
- On `vmselect` (`8481`), `-deleteAuthKey` gates POSTs to `/delete/{accountID}/prometheus/api/v1/admin/tsdb/delete_series` and `/select/{accountID}/graphite/tags/delSeries`. `-search.resetCacheAuthKey` gates `/internal/resetRollupResultCache`, and `-metricNamesStatsResetAuthKey` gates `/admin/api/v1/admin/status/metric_names_stats/reset`.
- On all three HTTP components, `-metricsAuthKey`, `-flagsAuthKey` and `-pprofAuthKey` gate `/metrics`, `/flags` and `/debug/pprof/*`, respectively.

These keys default to empty. An empty endpoint key falls back to HTTP Basic auth, so the handler is unauthenticated when `-httpAuth.username` is also empty. A nonempty endpoint key requires a matching `authKey` request parameter and overrides Basic auth for that handler; it does not add a second authentication requirement or authenticate other routes. Bind every HTTP component privately and route external traffic through `vmauth` over HTTPS with per-route or per-tenant restrictions, allowing only the operations clients need.

## QuestDB

QuestDB opens several protocols, each with its own default. The web console with its REST and SQL endpoints is on `9000`, and its Basic-auth keys `http.user` and `http.password` are unset by default, so the console and REST API answer unauthenticated in the open-source build. The PostgreSQL wire protocol on `8812` ships the default credential pair `admin` / `quest` in `pg.user` and `pg.password`. The InfluxDB line protocol on `9009` (TCP) has `line.tcp.auth.db.path` unset by default, so it accepts unauthenticated writes. Set each of these in the active `server.conf`:

```properties
http.user=REPLACE_WITH_A_NAME
http.password=REPLACE_WITH_A_SECRET
pg.user=REPLACE_WITH_A_NAME
pg.password=REPLACE_WITH_A_SECRET
line.tcp.auth.db.path=conf/auth.txt
```

`line.tcp.auth.db.path` points at a file of P-256 public keys. The [minimal health server](https://questdb.com/docs/configuration/http-min-server/) on `9003` requires authentication when the HTTP server does by default (`http.health.check.authentication.required=true`); setting this option to `false` independently permits unauthenticated health checks. The open-source build has no native TLS, so terminate it at a reverse proxy; QuestDB Enterprise instead uses role-based access control (since Enterprise 4.0.0 it refuses to start if the `http.user` and `http.password` keys are set) and its own `tls.enabled` settings.

## The pattern, any of these

Bind every listener to loopback or a private interface, and put authentication and TLS in a layer in front, because none of these engines authenticates by default: VictoriaMetrics ships its Basic auth empty, InfluxDB 1.x ships `auth-enabled` off, and QuestDB leaves its console keys and ILP auth unset while shipping a default database credential. Change every default credential (`admin` / `quest` first), and never place an ingest or query port on the public internet. A browser sign-in or MFA layer in front of the console does not authenticate the PostgreSQL wire or line-protocol ports, which are separate listeners: bind and front those too.

## Verify

REASONED: following block; every probe in this section, including the TCP and UDP listener inventory below for each port it names. Every probe in this section, including the TCP and UDP listener inventory below for each port it names, rests on the guide's cited InfluxDB 2.x configuration options, InfluxDB 1.x configuration, VictoriaMetrics v1.155.0 single-node HTTP fallback, VictoriaMetrics v1.155.0-cluster HTTP fallback binds, and QuestDB HTTP server, PostgreSQL wire protocol, ingestion and minimal HTTP server entries. No InfluxDB, VictoriaMetrics or QuestDB listener ran. During marking review (October 2026) all three Verify blocks passed bash -n under bash 5.3.9, and the inventory's two commands, run without sudo on the review host as ss -tlnp and ss -ulnp (iproute2 6.19.0), accepted their flags and showed none of the named TCP or UDP ports listening, with an empty process column, so they tested no target; the sudo form was not run. Those runs covered all three blocks in earlier forms, whose exit statuses did not classify their results. The current forms of all three pass bash -n and ShellCheck 0.11.0 in the repository's gate suite, which runs both over every block. Stub runs of the current inventory with stub ss and sudo commands and no network, in a clean shell and under an inherited `set -e`, `readonly` and `declare -i`, exited 0 when both tables showed only loopback listeners, 1 when one showed a named port on a wildcard address, 3 when an ss command failed and 2 when ss was missing. Exposed, a listed port shows a public or wildcard bind; fixed, only its intended private address. The inventory block exits 1 when a port it names is bound to a wildcard address, 3 when either ss command fails, 2 when ss is not installed, so neither table is listed, and otherwise 0, leaving public and private addresses for you to judge. Per the guide's cited sudo sudoers manual, secure_path entry, where sudoers sets `secure_path`, sudo looks `ss` up in that path instead of your PATH, so the `command -v ss` check can refuse although sudo would find `ss`, or pass and then end with status 3 when sudo cannot run it. Every probe below is **REASONED, not demonstrated**: the authoring host forbids opening listeners without an isolated network namespace, and has none. Outcomes are derived from the cited vendor sources rather than observed. A transport failure, a redirect, a 404, a 405 or a TLS error is inconclusive, never the fixed state.

```bash
# Listener inventory, REASONED as the paragraph above records: no isolated network namespace for listeners on the authoring host. Expected outcomes are recorded above and vendor sources below.
(                                   # a subshell, so the exits below end only the subshell
  command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
  # read the whole table: 8086 and loopback 8088; 8428, 8480, 8481, 8482 and native
  # RPC 8400, 8401; 9000, 9003, 8812, 9009, each only on its intended private
  # address, and no metrics or ingest port bound to a public interface
  set -- 0 "$(if sudo ss -tlnp; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0; a missing ss has already exited 2 above), then the TCP listeners
  set -- "$1" "${2%$'\n'*}" "${2##*$'\n'}"                                         # status, the TCP listener table, then ss's exit status
  printf '%s' "$2"
  [ "$3" = 0 ] || { echo "sudo ss -tlnp exit $3: the TCP listener inventory failed; inconclusive"; set -- 3 "$2" "$3"; }
  set -- "$1" "$2" "$(if sudo ss -ulnp; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # then the UDP listeners
  set -- "$1" "$2" "${3%$'\n'*}" "${3##*$'\n'}"                                    # status, both tables, then this ss's exit status
  printf '%s' "$3"
  [ "$4" = 0 ] || { echo "sudo ss -ulnp exit $4: the UDP listener inventory failed; inconclusive"; set -- 3 "$2" "$3" "$4"; }
  if printf '%s%s' "$2" "$3" | awk '$4 ~ /:(8086|8088|8428|8480|8481|8482|8400|8401|9000|9003|8812|9009)$/ && ($4 ~ /^0\.0\.0\.0:/ || index($4, "*:") == 1 || index($4, "[::]:") == 1 || index($4, ":::") == 1) { print; found = 1 } END { exit !found }'; then
    echo "FINDING: the rows just above bind a port this block names to a wildcard address, the exposed state"; set -- 1
  else
    case "$?" in 1) ;; *) echo "awk could not read the listener tables; inconclusive"; [ "$1" = 1 ] || set -- 3 ;; esac
  fi
  echo "block exit $1; public and private addresses are not classified, so judge every row against the comments yourself"
  exit "$1"
)
```

REASONED: the outside-host and trusted-host VictoriaMetrics cluster RPC reachability pair, per the guide's cited VictoriaMetrics v1.155.0-cluster HTTP fallback binds, RPC handshake and RPC capabilities entries and its VictoriaMetrics cluster security recommendations entry. During marking review (October 2026) the following block passed bash -n under bash 5.3.9 and ran with no network: unchanged, it printed the substitute-the-storage-node-IP refusal and exited 2; without its set -- line, the paste-the-whole-block refusal. The following block's no-network runs during marking review (October 2026) gave two further results: a host name was rejected by the block's Python ipaddress check with a ValueError; and 127.0.0.1, where nothing listened, printed connection failed with Connection refused and not proof of isolation for 8400 and 8401. Those runs covered an earlier form of the block, which took one value, let a host name end it with a Python traceback and exit status 1, and, once past its guards, otherwise exited 0 whatever it printed; none was repeated on the current form, which the repository's gate suite checks with bash -n and ShellCheck 0.11.0 like every block. **REASONED, not demonstrated:** the VictoriaMetrics cluster RPC check needs a running cluster and probe hosts inside and outside its protected network, unavailable because the authoring host forbids opening listeners without an isolated network namespace, and has none. The `ss` inventory above identifies local binds; it does not prove that `8400` and `8401` are unreachable from outside the cluster network. From an outside host, substitute each storage node's actual IP and `outside` below and run the whole block. Repeat from a trusted cluster host with `trusted` as the positive control. Use any configured replacement ports too, including enabled `-clusternativeListenAddr` listeners. The pinned RPC listener and handshake sources below explain why reachability matters.

```bash
# REASONED: cluster RPC isolation and trusted-host control; no isolated network namespace for listeners on the authoring host. Expected outcomes and vendor sources are recorded below.
(
  set +e                                # errexit off here, so the probe's status is read on the line after it instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_STORAGE_NODE_IP' 'REPLACE_WITH_outside_OR_trusted'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the storage node IP; not probing"; exit 2 ;;
  esac
  case "$2" in
    outside|trusted) : ;;
    *) echo "substitute outside (a probe from an outside host) or trusted (the trusted cluster host control) as the second value on the set -- line above; not probing"; exit 2 ;;
  esac
  command -v python3 > /dev/null || { echo "python3 is required for this probe; not probing"; exit 2; }
  python3 - "$1" <<'PY'
import ipaddress
import socket
import sys

_, host = sys.argv
try:
    ipaddress.ip_address(host)
except ValueError:
    print(f"{host} is not an IP address: substitute the storage node's actual IP; not probing")
    sys.exit(20)
reachable = 0
for port in (8400, 8401):
    try:
        with socket.create_connection((host, port), timeout=5):
            print(f"{host}:{port}: TCP REACHABLE")
            reachable += 1
    except OSError as exc:
        print(f"{host}:{port}: connection failed: {exc}; not proof of isolation")
sys.exit(21 + reachable)  # 21: neither port connected, 22: one did, 23: both did
PY
  set -- "$2" "$?"                      # outside or trusted, then the probe's exit status
  case "$1:$2" in
    *:20) set -- 2 ;;
    outside:22|outside:23) echo "FINDING: a storage RPC port accepted a TCP connection from outside, the exposed state"; set -- 1 ;;
    outside:21) echo "neither port connected from here: consistent with isolation, not proof; confirm the target, its running listeners and the firewall or network-policy rule responsible, and run the trusted-host control"; set -- 0 ;;
    trusted:23) echo "the trusted-host control connected to both listeners"; set -- 0 ;;
    trusted:21|trusted:22) echo "the trusted-host control did not connect to both listeners, so it failed; inconclusive"; set -- 3 ;;
    *) echo "python3 exit $2: the probe did not finish; inconclusive"; set -- 3 ;;
  esac
  echo "block exit $1; the per-port connection lines above, including any connection error, are not classified beyond this, so read them yourself"
  exit "$1"
)
```

REASONED: the expected exposed and fixed RPC outcomes, per the guide's cited VictoriaMetrics v1.155.0-cluster RPC handshake and RPC capabilities entries and vmauth authorization proxy entry; no cluster ran, so neither state was observed. An exposed listener is expected to report `TCP REACHABLE` from outside; this is an exposure failure even if an HTTP request to that port fails, since RPC is not HTTP. In the fixed state, outside connections must be blocked while the trusted-host control still connects to both running listeners. A timeout or refusal alone is inconclusive: confirm the target, running listener and firewall or network-policy rule responsible. With `outside`, the block exits 1 when either port reports `TCP REACHABLE` and 0 when neither connects, which it reports as consistent with isolation but not proof for that reason; with `trusted`, it exits 0 when both connect and 3 otherwise. It refuses an address that is not an IP literal with status 2, before any connection. A `401` from `vmauth` says nothing about RPC isolation.

```bash
# REASONED: HTTP setup, authentication and endpoint-key probes; no isolated network namespace for listeners on the authoring host. Expected outcomes and vendor sources are recorded below.
# Per-target discriminator: InfluxDB 2.x setup returns 200 in both states; read allowed
# (true before setup, false after). The other named data endpoints should return 401 with auth.
# Substitute a full URL on the set -- line
# and paste the whole block so the guard runs; use `http://` for the exposed check and the hardened `https://` entrypoint for the re-run, and the body is kept because one target discriminates on it.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_URL'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute a full URL on the set -- line above; not probing"; exit 2 ;;
    http://*|https://*) : ;;
    *) echo "expected an http:// or https:// URL; not probing"; exit 2 ;;
  esac
  set -- "$1" "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 \
    -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "${2##*$'\n'}" "${2%$'\n'*}"            # curl's exit status, then its output
  printf '%s' "$2"
  set -- "$1" "$2" "${2%$'\n'}"
  set -- "$1" "$2" "${3##*$'\n'}"                # curl's exit status, its output, then its http= exit= err= line
  case "$1:$3" in
    0:"http=401 "*) echo "HTTP 401: this endpoint requires authentication"; set -- 0 ;;
    0:"http=2"??" "*)
      case "$2" in
        *'"allowed":true'*|*'"allowed": true'*) echo "FINDING: the InfluxDB 2.x setup endpoint reports allowed true, so this instance has not been set up"; set -- 1 ;;
        *'"allowed":false'*|*'"allowed": false'*) echo "the InfluxDB 2.x setup endpoint reports allowed false: the instance is initialized"; set -- 0 ;;
        *) echo "unclassified observation: a URL alone does not tell this block which engine, or which proxy in front of one, answered, so it does not classify a data answer; read the body above against the expectations for this target; a 200 health response proves nothing on its own"; set -- 0 ;;
      esac ;;
    0:"http=3"??" "*|0:"http=404 "*|0:"http=405 "*) echo "a redirect, a 404 or a 405 is inconclusive, never the fixed state"; set -- 3 ;;
    0:*) echo "an HTTP status this block does not classify; inconclusive"; set -- 3 ;;
    *) echo "curl exit $1: a transport failure or a TLS error is inconclusive, never the fixed state"; set -- 3 ;;
  esac
  echo "block exit $1; a 2xx body other than the setup endpoint's is not classified, so judge it against the expectations below"
  exit "$1"
)
```

REASONED: preceding block; the guarded URL probe above for its setup, authentication and endpoint-key targets, and this paragraph's per-target InfluxDB, VictoriaMetrics and QuestDB expectations and PostgreSQL wire check. The declared scope rests on the guide's cited InfluxDB 2.x setup API, InfluxDB 1.x configuration, InfluxDB 1.x authentication and authorization, VictoriaMetrics v1.155.0 HTTP auth and TLS flags, QuestDB HTTP server and QuestDB PostgreSQL wire protocol entries. No InfluxDB, VictoriaMetrics or QuestDB instance ran; psql is installed in the authoring environment, but there was no QuestDB listener to refuse it. During marking review (October 2026) the block passed bash -n under bash 5.3.9 and ran with a stub curl and no network: unchanged, it printed the substitute-a-full-URL refusal and exited 2; a URL without a scheme drew the expected-http-or-https refusal; and the setup and snapshot-list URLs reached the stub unchanged. Those runs covered an earlier form of the block, which ended with curl's own status; none was repeated on the current form, which the repository's gate suite checks with bash -n and ShellCheck 0.11.0 like every block. The block exits 3 for a transport failure, a TLS error, a redirect, a `404`, a `405` or any other status it does not classify, 1 for a `2xx` body containing `"allowed":true`, and 0 for a `401`, for `"allowed":false`, or for any other `2xx`, whose body it leaves for you to read against these expectations. It does not classify a `2xx` data answer as exposed, because a URL alone does not tell it which engine, or which proxy in front of one, answered; a database list, series or a result set returned without credentials is the exposed state below. The expected exposed and fixed results are those stated here. Run that block once per target, over `http://` against the default plaintext listener. InfluxDB 2.x `http://tsdb.example.com:8086/api/v2/setup` returns a body containing `"allowed":true` on an un-set-up instance and `"allowed":false` once initialized; the HTTP status is `200` either way, so read the body, not the code. InfluxDB 1.x `http://tsdb.example.com:8086/query?q=SHOW+DATABASES` returns the database list when `auth-enabled` is off and `401` once it is on. VictoriaMetrics `http://tsdb.example.com:8428/api/v1/query?query=up` returns series until `-httpAuth.username` is set or it sits behind `vmauth`, then `401`. QuestDB `http://tsdb.example.com:9000/exec?query=SELECT+1` returns a result set with no `http.user` set and `401` once it is. For the PostgreSQL wire port, confirm separately that `admin` / `quest` is refused with a `psql` connection attempt. Once authentication and TLS are in front, re-run against the `https://` entrypoint to confirm the `401`, and separately confirm the plaintext port is closed from outside, since a `401` from the proxy does not prove the backend listener is unreachable. A `200` health response, a redirect, or a 404 proves none of this on its own.

REASONED: the VictoriaMetrics v1.155.0 single-node endpoint-key and Basic-auth cases, per the guide's cited VictoriaMetrics v1.155.0 key precedence and Basic fallback, built-in exemptions and key routes, and empty password/key defaults entries. No VictoriaMetrics instance ran; the guarded URL block's local runs are recorded in the previous paragraph. The expected exposed and fixed results are those stated here. **REASONED, not demonstrated:** for v1.155.0 single-node, use the guarded URL block above against `/snapshot/list` and `/metrics` with no credentials. With empty endpoint keys and an empty Basic username, expect `200` and snapshot JSON or metrics text; with a Basic username set and the keys still empty, expect `401`. With nonempty endpoint keys, a request lacking `authKey` must return `401`. In an isolated deployment, also confirm that a correct endpoint key succeeds without Basic credentials, that Basic credentials alone cannot satisfy a nonempty endpoint key, and that ordinary query and ingest requests still require Basic auth. Do not use snapshot creation, deletion or ingestion as a read-only probe. `/health` and `/-/ready` remain unauthenticated under native Basic auth; their success is not a failed data-auth check. Include every enabled optional listener in the `ss` inventory and outside-network isolation checks. The authoring host forbids opening listeners without an isolated network namespace, and has none; these expectations are REASONED from the pinned sources cited for these controls.

## Common mistakes

- Leaving an InfluxDB 2.x instance un-set-up on a reachable address, so the first stranger to `POST /api/v2/setup` becomes its operator.
- Running InfluxDB 1.x with the default `auth-enabled = false`, which leaves `DROP DATABASE` open to anyone who can reach `8086`.
- Leaving VictoriaMetrics reachable with its `-httpAuth.username` and `-httpAuth.password` empty (the default), or assuming `-deleteAuthKey` and its siblings authenticate the API when they gate only their own handlers.
- Leaving QuestDB's `admin` / `quest` PostgreSQL credential in place, or fronting only the `9000` console while `8812` and `9009` stay open.
- Terminating TLS and login at a proxy for the web console while the database and ingest protocols keep answering on their own ports.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- InfluxDB 2.x setup API (`GET /api/v2/setup`, the `allowed` field, `POST` onboarding): https://docs.influxdata.com/influxdb/v2/api/setup/
- InfluxDB 2.x configuration options (`http-bind-address`, `tls-cert`, `tls-key`, `INFLUXD_CONFIG_PATH`): https://docs.influxdata.com/influxdb/v2/reference/config-options/
- InfluxDB 1.x configuration (`[http] auth-enabled` default `false`, `bind-address` `:8086`, backup RPC `127.0.0.1:8088`): https://docs.influxdata.com/influxdb/v1/administration/config/
- InfluxDB 1.x authentication and authorization: https://docs.influxdata.com/influxdb/v1/administration/authentication_and_authorization/
- VictoriaMetrics v1.155.0 single-node (commit 3fec2f72414d00d1acda807c8818d7af90cc966d) [HTTP fallback and startup](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/victoria-metrics/main.go#L91-L115), [registered key routes and dispatch](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/victoria-metrics/main.go#L138-L202), [TCP listener](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/netutil/tcplistener.go#L16-L43) and [IPv4/IPv6 selection](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/netutil/tcplistener.go#L79-L85).
- VictoriaMetrics v1.155.0 [HTTP auth and TLS flags](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/httpserver/httpserver.go#L38-L57), [prefix and OPTIONS handling](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/httpserver/httpserver.go#L385-L419), [built-in exemptions and key routes](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/httpserver/httpserver.go#L425-L510), [key precedence and Basic fallback](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/httpserver/httpserver.go#L534-L573), and [empty password/key defaults](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/flagutil/password.go#L16-L30).
- VictoriaMetrics v1.155.0 [storage key flags and optional RPC address](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmstorage/main.go#L39-L47), [logging key](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmstorage/main.go#L112), [conditional RPC startup](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmstorage/main.go#L185-L198), and [maintenance and snapshot handlers](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmstorage/main.go#L251-L376).
- VictoriaMetrics v1.155.0 [query-side key flags](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmselect/main.go#L33-L37), [alias normalization](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmselect/main.go#L99-L111), [rollup-cache reset](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmselect/main.go#L174-L179), and [deletion and metric-name reset](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmselect/main.go#L377-L435).
- VictoriaMetrics v1.155.0 [optional ingest listeners and config/reload keys](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vminsert/main.go#L49-L70), [conditional listener startup](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vminsert/main.go#L90-L107), [HTTP ingest routes](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vminsert/main.go#L138-L309), and [configuration, reload and authenticated readiness handlers](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vminsert/main.go#L357-L393).
- VictoriaMetrics v1.155.0 (shipped image v1.154.1) [shipped Compose image, publications and listener flags](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/deployment/docker/compose-vm-single.yml#L18-L37).
- VictoriaMetrics v1.155.0 raw ingest listeners (no TLS configuration; Basic auth only on OpenTSDB HTTP): [Graphite](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/ingestserver/graphite/server.go#L46-L53), [InfluxDB](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/ingestserver/influx/server.go#L46-L52), [OpenTSDB mixed listener](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/ingestserver/opentsdb/server.go#L49-L60), [OpenTSDB HTTP listener](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/ingestserver/opentsdbhttp/server.go#L36-L36) and [its Basic-auth check](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/ingestserver/opentsdbhttp/server.go#L88-L92).
- VictoriaMetrics v1.155.0-cluster HTTP fallback binds: [vminsert](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vminsert/main.go#L110-L113), [vmselect](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L107-L110), [vmstorage](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/main.go#L171-L174), [RPC startup](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/main.go#L243-L257); [RPC address defaults and storage auth-key flags](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/main.go#L50-L72).
- VictoriaMetrics v1.155.0-cluster TCP bind implementation and IPv4 default: [listener](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/netutil/tcplistener.go#L16-L43), [network selection](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/netutil/tcplistener.go#L79-L85); optional cluster-native listeners: [vminsert](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vminsert/main.go#L53-L54), [vmselect](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L77-L78).
- VictoriaMetrics v1.155.0-cluster RPC handshake: [protocol identifiers](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/handshake/handshake.go#L17-L23), [insert hello check](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/handshake/handshake.go#L77-L109), [select hello check](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/handshake/handshake.go#L137-L158), [compression negotiation without credentials](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/handshake/handshake.go#L203-L233).
- VictoriaMetrics v1.155.0-cluster RPC capabilities: [storage writes](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/vmstorage.go#L110-L131), [plaintext select listener](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/vmselectapi/server.go#L96-L103), [RPC dispatch including deletion, registration and reset](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/vmselectapi/server.go#L560-L590), [storage deletion and mutations](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/vmstorage.go#L325-L359).
- VictoriaMetrics v1.155.0-cluster insert accept-to-write path: [listener and handshake setup](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/vminsertapi/server.go#L54-L75), [accept, handshake and connection processing](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/vminsertapi/server.go#L78-L144), [legacy and RPC dispatch](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/vminsertapi/server.go#L172-L226), [storage write callbacks](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/vminsertapi/server.go#L255-L267); [nil TLS config returns a plaintext connection](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/netutil/tcplistener.go#L107-L140) (vmstorage passes nil at the RPC startup cited above).
- VictoriaMetrics v1.155.0-cluster HTTP auth: [flags and HTTP TLS scope](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/httpserver/httpserver.go#L38-L57), [metrics, flags and pprof routes](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/httpserver/httpserver.go#L461-L510), [endpoint-key precedence and Basic-auth fallback](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/httpserver/httpserver.go#L534-L573).
- VictoriaMetrics v1.155.0-cluster password and auth-key defaults: [NewPassword stores an empty string](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/flagutil/password.go#L21-L30), [Get reads it unchanged when no source is configured](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/flagutil/password.go#L54-L68).
- VictoriaMetrics v1.155.0-cluster maintenance: [storage handler auth routing](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/main.go#L298-L307), [merge, flush, logging and snapshots](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/main.go#L329-L442), [select cache resets](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L271-L298), [rollup-cache key](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/prometheus/prometheus.go#L58-L61), [Graphite deletion](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L582-L596), [Prometheus deletion](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L869-L886).
- VictoriaMetrics cluster security recommendations (private network, HTTPS auth proxy and endpoint allowlists): https://docs.victoriametrics.com/victoriametrics/cluster-victoriametrics/#security
- vmauth authorization proxy: https://docs.victoriametrics.com/victoriametrics/vmauth/
- QuestDB HTTP server (Enterprise 4.0.0 qualification recorded above; `9000`, `http.user` / `http.password` unset by default): https://questdb.com/docs/configuration/http-server/
- QuestDB PostgreSQL wire protocol (`8812`, default `admin` / `quest`): https://questdb.com/docs/configuration/postgres-wire-protocol/
- QuestDB ingestion / line protocol (`9009`, `line.tcp.auth.db.path` default none): https://questdb.com/docs/configuration/ingestion/

- QuestDB minimal HTTP server (`9003`, `http.health.check.authentication.required` defaults to `true`; `false` permits unauthenticated health checks): https://questdb.com/docs/configuration/http-min-server/
- QuestDB TLS encryption (Enterprise only; `tls.enabled`): https://questdb.com/docs/configuration/tls/
- sudo SUDO_1_9_16p2 sudoers manual, secure_path (checked October 2026): https://github.com/sudo-project/sudo/blob/SUDO_1_9_16p2/docs/sudoers.man.in#L5650-L5655


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- influx2: InfluxDB OSS (2.x)
- influx1: InfluxDB OSS (1.x)
- single: VictoriaMetrics single-node (v1.155.0)
- cluster: VictoriaMetrics cluster (v1.155.0-cluster)
- image: VictoriaMetrics shipped Compose image (v1.154.1)
- enterprise: QuestDB Enterprise qualification (4.0.0)
- rpc: VictoriaMetrics cluster source (e4b1d55683f0da20410dc765787bd4e9b5afa0da)
- proxy: VictoriaMetrics security/vmauth documentation (unknown)
- single-commit: VictoriaMetrics single-node source commit (3fec2f72414d00d1acda807c8818d7af90cc966d)
- quest: QuestDB documentation (unknown)

Claims (full source mapping in the JSON block below):

- influx2-setup (REASONED; influx2): 8086 shares API/UI/write; private onboarding creates operator user/org/token, setup allowed changes true to false, scoped app tokens.
- influx2-tls (REASONED; influx2): INFLUXD_CONFIG_PATH selects config; http-bind-address, tls-cert and tls-key set private HTTPS.
- influx1-auth (REASONED; influx1): 8086 auth defaults off; create admin then set bind-address, auth-enabled and HTTPS certificate/key fields.
- influx1-other (REASONED; influx1): prom-read-auth-enabled=false by default; set it true with auth-enabled for remote-read auth; 8088 backup RPC defaults loopback; optional unauthenticated ingest stays disabled.
- vm-bind (REASONED; single, single-commit): Single-node HTTP fallback :8428, tcp4 default, enableTCP6 false; explicit private bind and TLS flags.
- vm-image (REASONED; single, image): Source tag ships Compose using image v1.154.1, wildcard 8428 publication and additional ingest listeners.
- vm-basic (REASONED; single): Empty username disables Basic auth even with password; ordinary query/UI/HTTP ingest and aliases share the credential.
- vm-exempt (REASONED; single): Health/ping/readiness/robots/favicon, OPTIONS and prefix handling exemptions differ from authenticated ready and influx/health.
- vm-keys (REASONED; single): Registered endpoint keys default empty and fall back to Basic; nonempty authKey replaces Basic, wrong/missing gives 401; other aliases may require both.
- vm-optional (REASONED; single): Graphite/Influx/OpenTSDB/native-query listeners default disabled; no TLS, and only OpenTSDB HTTP put checks Basic.
- cluster-http (REASONED; cluster, rpc): vminsert/vmselect/vmstorage fall back to 8480/8481/8482 on IPv4 wildcard; optional IPv6, empty Basic credentials and HTTP-only TLS.
- cluster-rpc (REASONED; cluster, rpc): 8400/8401 wildcard RPC has no credentials/TLS; handshake/compression permits writes, reads, deletion and metadata mutations, outside HTTP auth.
- cluster-native (REASONED; cluster, proxy): Optional clusternativeListenAddr is disabled by default; restrict enabled native listeners to trusted cluster peers.
- cluster-key-snapshot (REASONED; cluster): vmstorage: -snapshotAuthKey gates /snapshot/create, /snapshot/list, /snapshot/delete and /snapshot/delete_all.
- cluster-key-merge (REASONED; cluster): vmstorage: -forceMergeAuthKey gates /internal/force_merge.
- cluster-key-flush (REASONED; cluster): vmstorage: -forceFlushAuthKey gates /internal/force_flush.
- cluster-key-logging (REASONED; cluster): vmstorage: -logNewSeriesAuthKey gates /internal/log_new_series.
- cluster-key-delete (REASONED; cluster): vmselect: -deleteAuthKey gates POSTs to /delete/{accountID}/prometheus/api/v1/admin/tsdb/delete_series and /select/{accountID}/graphite/tags/delSeries.
- cluster-key-cache (REASONED; cluster): vmselect: -search.resetCacheAuthKey gates /internal/resetRollupResultCache.
- cluster-key-stats (REASONED; cluster): vmselect: -metricNamesStatsResetAuthKey gates /admin/api/v1/admin/status/metric_names_stats/reset.
- cluster-key-metrics (REASONED; cluster): All three HTTP components: -metricsAuthKey gates /metrics.
- cluster-key-flags (REASONED; cluster): All three HTTP components: -flagsAuthKey gates /flags.
- cluster-key-pprof (REASONED; cluster): All three HTTP components: -pprofAuthKey gates /debug/pprof/*.
- cluster-precedence (REASONED; cluster, rpc, proxy): Empty keys fall back to Basic; nonempty keys replace it, not add a factor or protect other routes; allowlist proxy routes.
- quest-http (REASONED; quest): 9000 HTTP/console/SQL defaults unauthenticated; set http.user/password in server.conf. 9003 health requires auth when HTTP does by default; http.health.check.authentication.required=false disables that health check requirement.
- quest-pg (REASONED; quest): 8812 PostgreSQL wire defaults admin/quest; replace pg.user/password and protect its separate listener.
- quest-ilp (REASONED; quest): 9009 TCP writes default unauthenticated; line.tcp.auth.db.path selects P-256 public-key file.
- quest-tls (REASONED; quest, enterprise): OSS requires proxy TLS; Enterprise uses RBAC/tls.enabled and rejects HTTP credential keys since stated Enterprise 4.0.0.
- verify-inventory (REASONED; influx1, single, cluster, quest): Inventory TCP/UDP and every enabled listener; local binds do not prove external isolation.
- verify-rpc (REASONED; cluster, rpc, proxy): Actual storage IPs must refuse outside TCP while permitted hosts connect; protocol is not HTTP and failure alone proves no isolation.
- verify-http (REASONED; influx2, influx1, single, quest): Setup body, Influx1 database list/401, VM query/401 and Quest SQL/401 discriminate per target; redirects/errors are inconclusive.
- verify-extra (REASONED; quest, proxy): Reject default PG credential separately; repeat HTTPS auth and plaintext isolation; console MFA does not protect native protocols.
- verify-keys (REASONED; single): Read-only snapshot/list and metrics probes test empty/Basic/endpoint-key cases; health exemptions and optional listeners need separate checks.
- key-snapshot (REASONED; single): snapshotAuthKey gates snapshot create/list/delete/delete_all and admin TSDB snapshot.
- key-delete (REASONED; single): deleteAuthKey gates Prometheus delete_series and Graphite delSeries aliases.
- key-merge (REASONED; single): forceMergeAuthKey gates internal/force_merge.
- key-flush (REASONED; single): forceFlushAuthKey gates internal/force_flush.
- key-cache (REASONED; single): search.resetCacheAuthKey gates internal/resetRollupResultCache.
- key-logging (REASONED; single): logNewSeriesAuthKey gates internal/log_new_series.
- key-stats (REASONED; single): metricNamesStatsResetAuthKey gates admin/status/metric_names_stats/reset.
- key-config (REASONED; single): configAuthKey gates config and API status/config with Prometheus aliases.
- key-reload (REASONED; single): reloadAuthKey gates -/reload and Prometheus alias.
- key-metrics (REASONED; single): metricsAuthKey gates metrics.
- key-flags (REASONED; single): flagsAuthKey gates flags.
- key-pprof (REASONED; single): pprofAuthKey gates debug/pprof/* including trailing slash.

````json
{
  "schema": 1,
  "checked": "2026-09-26",
  "documentation_checked": "2026-09",
  "body_sha256": "b18ec5016cf5967cefce53562caad8331513f75181adac1e3e3e69fbc59d37be",
  "components": {
    "influx2": {
      "name": "InfluxDB OSS",
      "basis": "2.x",
      "sources": {
        "sc9e982673a2c": "https://docs.influxdata.com/influxdb/v2/api/setup/",
        "s51be52d52f2d": "https://docs.influxdata.com/influxdb/v2/reference/config-options/"
      }
    },
    "influx1": {
      "name": "InfluxDB OSS",
      "basis": "1.x",
      "sources": {
        "s5b36c54676cf": "https://docs.influxdata.com/influxdb/v1/administration/config/",
        "s33366bcde097": "https://docs.influxdata.com/influxdb/v1/administration/authentication_and_authorization/"
      }
    },
    "single": {
      "name": "VictoriaMetrics single-node",
      "basis": "v1.155.0",
      "sources": {
        "scc6aebe6cdc3": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/victoria-metrics/main.go#L91-L115",
        "sc82affc59de9": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/victoria-metrics/main.go#L138-L202",
        "s7a187accc5e7": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/netutil/tcplistener.go#L16-L43",
        "s4615dcd8fb22": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/netutil/tcplistener.go#L79-L85",
        "s984fca6a36b1": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/httpserver/httpserver.go#L38-L57",
        "s97464fca7365": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/httpserver/httpserver.go#L385-L419",
        "s68202bb6da1e": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/httpserver/httpserver.go#L425-L510",
        "sa99901bcfdf0": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/httpserver/httpserver.go#L534-L573",
        "se099ff262b05": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/flagutil/password.go#L16-L30",
        "s80d416be2b69": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vminsert/main.go#L138-L309",
        "s11d0abb7ec48": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/deployment/docker/compose-vm-single.yml#L18-L37",
        "sf537ca3e8518": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vminsert/main.go#L49-L70",
        "s5ea63e7bf367": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/ingestserver/graphite/server.go#L46-L53",
        "sb59cd1494904": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/ingestserver/influx/server.go#L46-L52",
        "sa801df0e0cd9": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/ingestserver/opentsdb/server.go#L49-L60",
        "sb643edeb3afa": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/lib/ingestserver/opentsdbhttp/server.go#L88-L92",
        "s9e95e708aab5": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmstorage/main.go#L39-L47",
        "s5aa6d744b544": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/vmselect/main.go#L33-L37"
      }
    },
    "cluster": {
      "name": "VictoriaMetrics cluster",
      "basis": "v1.155.0-cluster",
      "sources": {
        "sb9c05ee73a91": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vminsert/main.go#L110-L113",
        "s917acf99b191": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L107-L110",
        "s4d3500bd10df": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/main.go#L171-L174",
        "s4e9fcbacb309": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/main.go#L50-L72",
        "sae0e9a94ca95": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/netutil/tcplistener.go#L79-L85",
        "s7ab43405843d": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/handshake/handshake.go#L203-L233",
        "scf6372175d7b": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/vmselectapi/server.go#L560-L590",
        "sed011fe70075": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vminsert/main.go#L53-L54",
        "s84668f7f18ce": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L77-L78",
        "s22168276316c": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/httpserver/httpserver.go#L38-L57",
        "s9b7dc7d2a089": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/httpserver/httpserver.go#L534-L573",
        "s48dccc3608ac": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/main.go#L329-L442",
        "s8db09299b6d9": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L271-L298",
        "s9470eaf64e21": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L582-L596",
        "s1c0dd8645aa8": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/main.go#L869-L886",
        "s4a4dcd49cd09": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/lib/httpserver/httpserver.go#L461-L510",
        "s0f2907547ee4": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmselect/prometheus/prometheus.go#L58-L61",
        "s0dbf8f9a75dd": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0-cluster/app/vmstorage/main.go#L243-L257"
      }
    },
    "image": {
      "name": "VictoriaMetrics shipped Compose image",
      "basis": "v1.154.1",
      "sources": {
        "s11d0abb7ec48": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/deployment/docker/compose-vm-single.yml#L18-L37"
      }
    },
    "enterprise": {
      "name": "QuestDB Enterprise qualification",
      "basis": "4.0.0",
      "sources": {
        "s3a0487771c1a": "https://questdb.com/docs/configuration/http-server/"
      }
    },
    "rpc": {
      "name": "VictoriaMetrics cluster source",
      "basis": "e4b1d55683f0da20410dc765787bd4e9b5afa0da",
      "sources": {
        "sca91785d878c": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/vminsertapi/server.go#L78-L144",
        "sdba733140e0c": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/vminsertapi/server.go#L255-L267",
        "sb17dce5a1339": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/netutil/tcplistener.go#L107-L140",
        "sa18d26bb1269": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/e4b1d55683f0da20410dc765787bd4e9b5afa0da/lib/flagutil/password.go#L21-L30"
      }
    },
    "proxy": {
      "name": "VictoriaMetrics security/vmauth documentation",
      "basis": "unknown",
      "sources": {
        "s185272dd320f": "https://docs.victoriametrics.com/victoriametrics/cluster-victoriametrics/#security",
        "s79ed3b00108a": "https://docs.victoriametrics.com/victoriametrics/vmauth/"
      }
    },
    "single-commit": {
      "name": "VictoriaMetrics single-node source commit",
      "basis": "3fec2f72414d00d1acda807c8818d7af90cc966d",
      "sources": {
        "scc6aebe6cdc3": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/v1.155.0/app/victoria-metrics/main.go#L91-L115"
      }
    },
    "quest": {
      "name": "QuestDB documentation",
      "basis": "unknown",
      "sources": {
        "s3a0487771c1a": "https://questdb.com/docs/configuration/http-server/",
        "s9c38998f3725": "https://questdb.com/docs/configuration/postgres-wire-protocol/",
        "se0fda155b33d": "https://questdb.com/docs/configuration/ingestion/",
        "s19f43451ff2b": "https://questdb.com/docs/configuration/http-min-server/",
        "s7ca922a2e0f5": "https://questdb.com/docs/configuration/tls/"
      }
    }
  },
  "claims": {
    "influx2-setup": {"text": "8086 shares API/UI/write; private onboarding creates operator user/org/token, setup allowed changes true to false, scoped app tokens.", "components": ["influx2"], "sources": ["influx2:sc9e982673a2c"], "status": "REASONED"},
    "influx2-tls": {"text": "INFLUXD_CONFIG_PATH selects config; http-bind-address, tls-cert and tls-key set private HTTPS.", "components": ["influx2"], "sources": ["influx2:s51be52d52f2d"], "status": "REASONED"},
    "influx1-auth": {"text": "8086 auth defaults off; create admin then set bind-address, auth-enabled and HTTPS certificate/key fields.", "components": ["influx1"], "sources": ["influx1:s5b36c54676cf", "influx1:s33366bcde097"], "status": "REASONED"},
    "influx1-other": {"text": "prom-read-auth-enabled=false by default; set it true with auth-enabled for remote-read auth; 8088 backup RPC defaults loopback; optional unauthenticated ingest stays disabled.", "components": ["influx1"], "sources": ["influx1:s5b36c54676cf"], "status": "REASONED"},
    "vm-bind": {"text": "Single-node HTTP fallback :8428, tcp4 default, enableTCP6 false; explicit private bind and TLS flags.", "components": ["single", "single-commit"], "sources": ["single:scc6aebe6cdc3", "single:s7a187accc5e7", "single:s4615dcd8fb22", "single:s984fca6a36b1", "single-commit:scc6aebe6cdc3"], "status": "REASONED"},
    "vm-image": {"text": "Source tag ships Compose using image v1.154.1, wildcard 8428 publication and additional ingest listeners.", "components": ["single", "image"], "sources": ["single:s11d0abb7ec48", "image:s11d0abb7ec48"], "status": "REASONED"},
    "vm-basic": {"text": "Empty username disables Basic auth even with password; ordinary query/UI/HTTP ingest and aliases share the credential.", "components": ["single"], "sources": ["single:s984fca6a36b1", "single:sa99901bcfdf0", "single:se099ff262b05", "single:s80d416be2b69"], "status": "REASONED"},
    "vm-exempt": {"text": "Health/ping/readiness/robots/favicon, OPTIONS and prefix handling exemptions differ from authenticated ready and influx/health.", "components": ["single"], "sources": ["single:s97464fca7365", "single:s68202bb6da1e", "single:s80d416be2b69"], "status": "REASONED"},
    "vm-keys": {"text": "Registered endpoint keys default empty and fall back to Basic; nonempty authKey replaces Basic, wrong/missing gives 401; other aliases may require both.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:s68202bb6da1e", "single:sa99901bcfdf0", "single:se099ff262b05", "single:sf537ca3e8518", "single:s9e95e708aab5", "single:s5aa6d744b544"], "status": "REASONED"},
    "vm-optional": {"text": "Graphite/Influx/OpenTSDB/native-query listeners default disabled; no TLS, and only OpenTSDB HTTP put checks Basic.", "components": ["single"], "sources": ["single:sf537ca3e8518", "single:s5ea63e7bf367", "single:sb59cd1494904", "single:sa801df0e0cd9", "single:sb643edeb3afa", "single:s9e95e708aab5"], "status": "REASONED"},
    "cluster-http": {"text": "vminsert/vmselect/vmstorage fall back to 8480/8481/8482 on IPv4 wildcard; optional IPv6, empty Basic credentials and HTTP-only TLS.", "components": ["cluster", "rpc"], "sources": ["cluster:sb9c05ee73a91", "cluster:s917acf99b191", "cluster:s4d3500bd10df", "cluster:s0dbf8f9a75dd", "cluster:sae0e9a94ca95", "cluster:s22168276316c", "rpc:sa18d26bb1269"], "status": "REASONED"},
    "cluster-rpc": {"text": "8400/8401 wildcard RPC has no credentials/TLS; handshake/compression permits writes, reads, deletion and metadata mutations, outside HTTP auth.", "components": ["cluster", "rpc"], "sources": ["cluster:s4e9fcbacb309", "cluster:s7ab43405843d", "cluster:scf6372175d7b", "rpc:sca91785d878c", "rpc:sdba733140e0c", "rpc:sb17dce5a1339"], "status": "REASONED"},
    "cluster-native": {"text": "Optional clusternativeListenAddr is disabled by default; restrict enabled native listeners to trusted cluster peers.", "components": ["cluster", "proxy"], "sources": ["cluster:sed011fe70075", "cluster:s84668f7f18ce", "proxy:s185272dd320f"], "status": "REASONED"},
    "cluster-key-snapshot": {"text": "vmstorage: -snapshotAuthKey gates /snapshot/create, /snapshot/list, /snapshot/delete and /snapshot/delete_all.", "components": ["cluster"], "sources": ["cluster:s48dccc3608ac"], "status": "REASONED"},
    "cluster-key-merge": {"text": "vmstorage: -forceMergeAuthKey gates /internal/force_merge.", "components": ["cluster"], "sources": ["cluster:s48dccc3608ac"], "status": "REASONED"},
    "cluster-key-flush": {"text": "vmstorage: -forceFlushAuthKey gates /internal/force_flush.", "components": ["cluster"], "sources": ["cluster:s48dccc3608ac"], "status": "REASONED"},
    "cluster-key-logging": {"text": "vmstorage: -logNewSeriesAuthKey gates /internal/log_new_series.", "components": ["cluster"], "sources": ["cluster:s48dccc3608ac"], "status": "REASONED"},
    "cluster-key-delete": {"text": "vmselect: -deleteAuthKey gates POSTs to /delete/{accountID}/prometheus/api/v1/admin/tsdb/delete_series and /select/{accountID}/graphite/tags/delSeries.", "components": ["cluster"], "sources": ["cluster:s9470eaf64e21", "cluster:s1c0dd8645aa8"], "status": "REASONED"},
    "cluster-key-cache": {"text": "vmselect: -search.resetCacheAuthKey gates /internal/resetRollupResultCache.", "components": ["cluster"], "sources": ["cluster:s8db09299b6d9", "cluster:s0f2907547ee4"], "status": "REASONED"},
    "cluster-key-stats": {"text": "vmselect: -metricNamesStatsResetAuthKey gates /admin/api/v1/admin/status/metric_names_stats/reset.", "components": ["cluster"], "sources": ["cluster:s8db09299b6d9"], "status": "REASONED"},
    "cluster-key-metrics": {"text": "All three HTTP components: -metricsAuthKey gates /metrics.", "components": ["cluster"], "sources": ["cluster:s4a4dcd49cd09"], "status": "REASONED"},
    "cluster-key-flags": {"text": "All three HTTP components: -flagsAuthKey gates /flags.", "components": ["cluster"], "sources": ["cluster:s4a4dcd49cd09"], "status": "REASONED"},
    "cluster-key-pprof": {"text": "All three HTTP components: -pprofAuthKey gates /debug/pprof/*.", "components": ["cluster"], "sources": ["cluster:s4a4dcd49cd09"], "status": "REASONED"},
    "cluster-precedence": {"text": "Empty keys fall back to Basic; nonempty keys replace it, not add a factor or protect other routes; allowlist proxy routes.", "components": ["cluster", "rpc", "proxy"], "sources": ["cluster:s9b7dc7d2a089", "rpc:sa18d26bb1269", "proxy:s185272dd320f", "proxy:s79ed3b00108a"], "status": "REASONED"},
    "quest-http": {"text": "9000 HTTP/console/SQL defaults unauthenticated; set http.user/password in server.conf. 9003 health requires auth when HTTP does by default; http.health.check.authentication.required=false disables that health check requirement.", "components": ["quest"], "sources": ["quest:s3a0487771c1a", "quest:s19f43451ff2b"], "status": "REASONED"},
    "quest-pg": {"text": "8812 PostgreSQL wire defaults admin/quest; replace pg.user/password and protect its separate listener.", "components": ["quest"], "sources": ["quest:s9c38998f3725"], "status": "REASONED"},
    "quest-ilp": {"text": "9009 TCP writes default unauthenticated; line.tcp.auth.db.path selects P-256 public-key file.", "components": ["quest"], "sources": ["quest:se0fda155b33d"], "status": "REASONED"},
    "quest-tls": {"text": "OSS requires proxy TLS; Enterprise uses RBAC/tls.enabled and rejects HTTP credential keys since stated Enterprise 4.0.0.", "components": ["quest", "enterprise"], "sources": ["quest:s3a0487771c1a", "enterprise:s3a0487771c1a", "quest:s7ca922a2e0f5"], "status": "REASONED"},
    "verify-inventory": {"text": "Inventory TCP/UDP and every enabled listener; local binds do not prove external isolation.", "components": ["influx1", "single", "cluster", "quest"], "sources": ["influx1:s5b36c54676cf", "single:sf537ca3e8518", "cluster:s4e9fcbacb309", "quest:s3a0487771c1a", "quest:s9c38998f3725", "quest:se0fda155b33d"], "status": "REASONED", "verify": [1]},
    "verify-rpc": {"text": "Actual storage IPs must refuse outside TCP while permitted hosts connect; protocol is not HTTP and failure alone proves no isolation.", "components": ["cluster", "rpc", "proxy"], "sources": ["cluster:s4e9fcbacb309", "cluster:s7ab43405843d", "rpc:sca91785d878c", "proxy:s185272dd320f"], "status": "REASONED", "verify": [2]},
    "verify-http": {"text": "Setup body, Influx1 database list/401, VM query/401 and Quest SQL/401 discriminate per target; redirects/errors are inconclusive.", "components": ["influx2", "influx1", "single", "quest"], "sources": ["influx2:sc9e982673a2c", "influx1:s33366bcde097", "single:sa99901bcfdf0", "quest:s3a0487771c1a"], "status": "REASONED", "verify": [3]},
    "verify-extra": {"text": "Reject default PG credential separately; repeat HTTPS auth and plaintext isolation; console MFA does not protect native protocols.", "components": ["quest", "proxy"], "sources": ["quest:s9c38998f3725", "proxy:s185272dd320f"], "status": "REASONED", "verify": [3]},
    "verify-keys": {"text": "Read-only snapshot/list and metrics probes test empty/Basic/endpoint-key cases; health exemptions and optional listeners need separate checks.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:s68202bb6da1e", "single:sa99901bcfdf0"], "status": "REASONED", "verify": [3]},
    "key-snapshot": {"text": "snapshotAuthKey gates snapshot create/list/delete/delete_all and admin TSDB snapshot.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:s9e95e708aab5"], "status": "REASONED"},
    "key-delete": {"text": "deleteAuthKey gates Prometheus delete_series and Graphite delSeries aliases.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:s5aa6d744b544"], "status": "REASONED"},
    "key-merge": {"text": "forceMergeAuthKey gates internal/force_merge.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:s9e95e708aab5"], "status": "REASONED"},
    "key-flush": {"text": "forceFlushAuthKey gates internal/force_flush.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:s9e95e708aab5"], "status": "REASONED"},
    "key-cache": {"text": "search.resetCacheAuthKey gates internal/resetRollupResultCache.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:s5aa6d744b544"], "status": "REASONED"},
    "key-logging": {"text": "logNewSeriesAuthKey gates internal/log_new_series.", "components": ["single"], "sources": ["single:sc82affc59de9"], "status": "REASONED"},
    "key-stats": {"text": "metricNamesStatsResetAuthKey gates admin/status/metric_names_stats/reset.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:s5aa6d744b544"], "status": "REASONED"},
    "key-config": {"text": "configAuthKey gates config and API status/config with Prometheus aliases.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:sf537ca3e8518"], "status": "REASONED"},
    "key-reload": {"text": "reloadAuthKey gates -/reload and Prometheus alias.", "components": ["single"], "sources": ["single:sc82affc59de9", "single:sf537ca3e8518"], "status": "REASONED"},
    "key-metrics": {"text": "metricsAuthKey gates metrics.", "components": ["single"], "sources": ["single:s68202bb6da1e"], "status": "REASONED"},
    "key-flags": {"text": "flagsAuthKey gates flags.", "components": ["single"], "sources": ["single:s68202bb6da1e"], "status": "REASONED"},
    "key-pprof": {"text": "pprofAuthKey gates debug/pprof/* including trailing slash.", "components": ["single"], "sources": ["single:s68202bb6da1e"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
