# Rented GPUs: RunPod, Vast.ai, Lambda, Modal

RunPod, Vast.ai, Lambda and Modal rent GPU computing, from whole machines to serverless functions. This guide helps your AI assistant expose only what you intend, including how each platform makes a port public, and every listener bound privately or protected by its own login or an authenticating gateway.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/gpu-clouds.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against RunPod documentation (no recorded version), Jupyter Server contents authentication v2.18.0, Ollama v0.34.2, iproute2 ss manual v6.12.0, and Linux network namespaces manual man-pages-5.13; 3 further sources are pinned to a commit and 5 carry no recorded version. Metadata reviewed 2026-10-21; documentation checked September 2026. The guide records 44 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Unlike the major clouds, most rented-GPU platforms put no default-deny firewall in front of the box. How a bound port becomes public differs by platform: on RunPod you expose a port (HTTP or TCP), on Vast.ai a launch mode or an added port maps it to a public port, on Lambda you open a firewall rule (its inbound firewall is deny-by-default), and on Modal it depends on the serverless construct. Raw port publication and a firewall allowance add NO authentication of their own, so a listener exposed that way is reachable with only whatever auth it has itself. An authenticating platform proxy is the exception (Modal's Endpoints and Servers require proxy auth by default and Shared Endpoints always do, only a public Web endpoint does not, and Vast.ai's Instance Portal gates the routes it proxies), but do not assume one is in front of a given port. Treat every listener the same way you would on your own hardware: bind it privately or authenticate it, per [ollama.md](ollama.md) and [model-servers.md](model-servers.md).

## RunPod

Exposed HTTP ports (the "Expose HTTP Ports" pod setting) go through RunPod's proxy at `https://[POD_ID]-[INTERNAL_PORT].proxy.runpod.net`. The proxy terminates HTTPS automatically, "All connections are secured with HTTPS, even if your internal service uses HTTP," but the resulting URL is publicly reachable by anyone who has it, so a bare Jupyter server or model API on an exposed HTTP port still needs its own authentication.

Exposed TCP ports get "direct TCP forwarding with a public IP address" instead, and TLS is not automatic there: RunPod's own docs say to "implement TLS in your application when handling sensitive data over TCP." Secure every template listener, including notebooks, before exposing its port; a notebook exposed as raw TCP with no application-level password is fully open.

A "symmetrical port mapping" option lets a template ask for matching internal and external port numbers by specifying a value above 70000 in its TCP configuration. That value is not a port: RunPod's documentation says such numbers are not valid ports and serve only to signal the request, and the real assignment arrives in the pod's environment (for example `$RUNPOD_TCP_PORT_70000`). It is a convenience for the pod's own scripts, not a security boundary, and the port is still public once mapped.

## Vast.ai

Rented instances open ports per launch mode (port 22 for SSH mode, port 22 plus 8080 for Jupyter mode by default); each internal port maps to a random external port on a shared public IP, and once a port is mapped it is reachable from the internet with no firewall step described in Vast.ai's docs.

The Instance Portal fronts web apps on the instance with a reverse proxy (Caddy) when the external and internal ports differ, and secures access with a token rather than a login: "a secure token is appended to the link to prevent unauthorised access to your applications." At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the README documents OPEN_BUTTON_TOKEN for Basic/Bearer access, WEB_PASSWORD as a custom password, ENABLE_AUTH=false to disable authentication (default true), and AUTH_EXCLUDE as external ports excluded from authentication. PORTAL_CONFIG defines portal entries and port routing; equal external/internal ports bypass proxying. The auth test code uses both tokens as Bearer credentials and WEB_PASSWORD for Basic auth; these are test expectations, not observed results. The Caddy launcher delegates configuration to portal-aio; the delegated configurator is now cited at the same commit, and the next two paragraphs trace variable precedence and route enforcement from it. In this guide's assessment, routing configuration is not a credential. A token-bearing link IS the credential: anyone who has that URL is authenticated, so treat it as a secret and share it only with intended recipients (stripping the token is useful for testing that anonymous access is refused). Do not assume an app is private just because it sits behind the portal's port remapping, and confirm the route is one the portal actually authenticates.

What the cited configurator shows, at the same commit: it reads `PORTAL_CONFIG` only when `/etc/portal.yaml` does not exist, writes the parsed entries back to that file (so the file, once written, takes precedence over the variable), and emits a Caddy listener only for an entry whose external and internal ports differ and whose external port has a `VAST_TCP_PORT` mapping in the environment. An entry with equal ports, or with an unmapped external port, gets no Caddy listener from the cited configurator at the same commit, so nothing in the generated configuration authenticates it. A boot script rewrites `PORTAL_CONFIG` for Jupyter: it drops Jupyter entries when `VAST_TCP_PORT_8080` is absent or empty, or when `/.launch` exists without a Jupyter match and `JUPYTER_OVERRIDE` is not `true` (case-insensitively). Re-addition requires no `/.launch`, a nonempty mapping, no existing Jupyter entry and `FORCE_JUPYTER` not equal to `false` (case-insensitively). When `/.launch` contains Jupyter and `JUPYTER_OVERRIDE` is not `true` (case-insensitively), it rewrites `localhost:8080:18080` to `localhost:8080:8080`; these equal-port entries get no generated Caddy listener or portal authentication only if the rewritten environment is used, since an existing `/etc/portal.yaml` takes precedence. Authentication stays on unless `ENABLE_AUTH` equals `false` case-insensitively; any other value, including unset, keeps it on. `WEB_PASSWORD` and `OPEN_BUTTON_TOKEN` have no precedence over each other: when neither is set, one generated value is used for both; when only one is set, the other mirrors it; when both are set, every matcher accepts either, so each is a full credential on every port the portal protects. A protected port accepts a `token` query parameter, an auth cookie named after the container label, or an `Authorization: Bearer` header, each matching either token, and falls back to HTTP Basic with `WEB_USERNAME` (default `vastai`) and a hash of `WEB_PASSWORD`; a valid query token sets the auth cookie. The generated listeners serve plain HTTP unless `ENABLE_HTTPS` is `true` and a valid instance certificate and key are present.

The exemptions are the part to check. `AUTH_EXCLUDE` is a comma-separated list matched on the EXTERNAL port, and an excluded port is proxied with no authentication at all, as is every port when `ENABLE_AUTH=false`: both are exposures. Even on an authenticated port, a fixed set of paths bypasses every credential check: `/portal-resolver` is answered directly with 200, and `/.well-known/acme-challenge/*`, `/.well-known/change-password`, `/manifest.json`, `/manifest.webmanifest`, `/site.webmanifest`, `/.well-known/security.txt` and `/security.txt` are reverse-proxied to the backend with no credential. An app that serves private content on one of those paths is therefore anonymously reachable through the portal, even on an authenticated port. The configurator prints the effective username and credentials to its console output. The `OPEN_BUTTON_TOKEN` value is reused beyond the web routes: the portal launcher and the Syncthing supervisor script use it as the Syncthing GUI API key (the supervisor script falls back to a random value only when the variable is unset or empty), and the desktop template's VNC password fallback under Common mistakes reuses it as well. A token-bearing link therefore shares those reused credentials too, in this guide's reasoning. The portal's capabilities manifest reports the same variables but is not the enforcement point: both reporting and enforcement lowercase `ENABLE_AUTH` and default an unset value to `"true"`; reporting tests equality to `"true"`, while enforcement tests inequality to `"false"`, so other values (including empty) are enforced but reported as disabled.

## Lambda

Lambda's Public Cloud firewall is deny-by-default for inbound traffic with two exceptions: "By default, Lambda allows only incoming ICMP traffic or TCP traffic on port 22 (SSH)." Everything else, a Jupyter notebook, a model server port, needs an explicit firewall rule (global, workspace-wide rules, or a per-instance ruleset attached at launch); Lambda's own guidance is blunt about the tradeoff: "Each port you open increases the attack surface of your instances."

Opening a rule makes the port reachable from whatever source range you allow, with no authentication of its own, so pair the rule with the listener's native auth or a proxy in front, not the firewall rule alone.

## Modal

Modal's serverless constructs default differently by shape, and the control differs too. Web endpoints (the current decorator is `modal.fastapi_endpoint`, which replaced `@web_endpoint`) are "publicly available by default" and stay public until the function sets `requires_proxy_auth=True`. A Dedicated Endpoint is made public with the `--unauthenticated` flag; a Server sets `unauthenticated=True` on `@app.server(...)` instead of that flag; and a Shared Endpoint always requires a Proxy Token. Modal's Shared Endpoints page says "Shared Endpoints always require a proxy token," and its Endpoints page's Proxy tokens section says Shared Endpoints always require one while "Dedicated Endpoints can also be created with `--unauthenticated`." The cited pages document the unauthenticated option for Dedicated Endpoints only, so, in this guide's assessment, a Shared Endpoint cannot be made public. Name the construct you are deploying and check its actual control rather than assuming one flag covers all of them.

Where proxy auth is enabled, callers authenticate with a Token ID and Token Secret pair, either as separate `Modal-Key` and `Modal-Secret` headers or combined as `Authorization: Bearer <token_id>.<token_secret>` (Modal notes this mirrors "the same scheme the OpenAI API uses"). A protected endpoint called without credentials returns 401 with "missing credentials for proxy authorization." Check which default your construct uses before deploying; do not assume a Web Function is private.

## The pattern, whatever the platform

The platform's own controls (RunPod's proxy TLS, Vast.ai's portal token, Lambda's firewall rules, Modal's proxy auth) are necessary but not sufficient on their own. How to bind the model server depends on which kind of proxy is in front of it. RunPod's HTTP proxy reaches the pod over its exposed network interface rather than through a local backend, so the service must bind `0.0.0.0` inside the pod; RunPod's own troubleshooting guidance is explicit that binding to `localhost` only will keep the proxy from reaching it. Vast.ai's Instance Portal is the opposite case: it is a local reverse proxy (Caddy) running on the instance itself, so the app it forwards to can stay on loopback behind it, the same pattern as an authenticating proxy on your own hardware. Whichever binding the platform's proxy needs, add the listener's OWN authentication where it supports one; where it does not, keep the unauthenticated backend private and put an authenticating gateway in front, so the gateway and not the bare listener is what the platform exposes, exactly as [ollama.md](ollama.md) and [model-servers.md](model-servers.md) describe. At Ollama v0.34.2, the cited local API route setup installs CORS and host filtering without an inbound credential check. Cloud sign-in and OLLAMA_AUTH client outbound signing are separate from local inbound authentication. A platform-level control that changes later, a firewall rule widened to a broader source range, a template rebuilt without a flag, should not be the only thing standing between the listener and the internet (deleting a Lambda allow rule, by contrast, closes the port rather than opening it).

MFA: this guide cites no platform feature that adds a second factor to the workload itself, so workload authentication must be verified separately.

RunPod's quickstart recommends setting up two-factor authentication; its account-management page documents Basic, Billing, Dev and Admin team roles, but these passages do not show factor methods, setup steps or enforcement. RunPod's product updates, at the same documentation commit, list "Passkey auth" under November 2024 as "Passwordless WebAuthn sign-in for phishing-resistant account access"; in this guide's assessment, they do not say whether a passkey serves as a second factor, or how it is set up or enforced. In this guide's search of the RunPod documentation at that commit, no page names 2FA factor types, a 2FA setup path, or a team or organization 2FA requirement; a search that finds nothing does not establish that RunPod lacks them. Vast.ai's two-factor authentication page requires configuring at least one authenticator-app (TOTP) or SMS method to use 2FA; email is a backup, used automatically when setting up the first method, and remains an explicit option at the verification prompt rather than being triggered automatically at login. At the same documentation commit, Vast.ai's 2FA API reference lists a `team_user_forbidden` error (HTTP 403) for an "Endpoint called from a Team Context (override)", stating "2FA actions must be performed in the personal context.", and its team-roles page lists a `user_write` scope that "Allows the ability to change account settings such as email, password, 2FA, etc." The permissions reference's `user_write` row, by contrast, reads "Creating/modifying API keys, SSH keys, environment variables, templates, teams", its `user_write` endpoint list names no 2FA endpoint, and which page reflects the scope's behaviour has not been established. In this guide's reading of the teams overview, managing-teams and team-roles guides, the API and CLI permissions references, the security FAQ, and the 2FA guide, CLI page and API reference at that commit, none documents an owner setting, role permission or policy that requires team members to enable 2FA. The team-roles page lists default Owner, Manager and Member roles, the managing-teams guide names Manager and Member as every team's two default roles, and the CLI permissions page says team roles use the same permission model as API keys. That reading, like this guide's earlier search of the Vast.ai documentation at that commit, does not establish that Vast.ai lacks such a control. Pages at that commit that were not read include the account-settings guide (the 2FA guide sends setup to Account Settings), the teams quickstart, legacy-teams and SDK permissions pages, the API, CLI and SDK authentication pages, the CLI and SDK team and member reference pages, the CLI `tfa` reference pages, and the team OpenAPI files. Lambda's console page says MFA can be set up in User settings and account admins can manage users, roles and workspaces; it does not specify factor methods, setup steps or enforcement.

Lambda's single sign-on (SSO) page documents letting users authenticate to Lambda Cloud through the organization's existing identity provider (IdP), chosen from a list of supported providers or set up as Custom SAML or Custom OIDC. At the time of writing, its prerequisites include a 1-Click Cluster (1CC) and the Admin role in the Lambda Cloud account, and setup starts from an invitation email requested from the Lambda account manager. Once the connection is enabled, the page says users can sign in through the IdP; it does not say whether other sign-in methods remain available, and it shows no Lambda-side MFA enforcement. In this guide's inference, an IdP that enforces MFA can enforce it for Lambda Cloud sign-ins through that SSO connection, but not for any sign-in that bypasses it.

Modal's Workspaces page notes that accounts can be provisioned through SAML SSO, points to separate SAML SSO documentation for configuring SSO for a Workspace, and directs users to contact Modal for SSO through Google or other providers. It also documents Owner, Manager and Member roles, with RBAC for more granular permissions. At the time of writing, Modal's Custom SAML SSO, Okta SSO and Microsoft Entra SSO pages each say that SSO option is available on the Enterprise plan, and each lists as prerequisites a Workspace on an Enterprise plan, admin access to that Workspace and admin privileges in the identity provider. Setup adds a Modal SAML application in the identity provider and links the Workspace to it by supplying the identity provider's SAML metadata on the Identity and Provisioning tab of Workspace Management. Each of the three pages says that enabling the "Require SSO" setting will force all users to sign in via SSO (the Okta and Microsoft Entra pages name their own provider), and that admins should confirm their admin access to the Workspace through the identity provider before enabling it. None of the three documents an owner, recovery or alternative-login exception to that setting, which does not establish that none exists. In this guide's inference, where a Workspace enables Require SSO, an IdP that enforces MFA can enforce it for members' sign-ins to that Workspace, but not for Workspace API tokens, which authenticate programmatic access separately; that enforcement has not been observed. Modal's security page requires phishing-resistant MFA for Modal's own employee accounts; that statement does not establish a customer-account second factor, and none of the cited Modal pages shows such a control or Modal-side MFA enforcement for customer accounts.

This guide's advice is to enable MFA on each RunPod, Vast.ai and Lambda platform account, and on Modal wherever a customer control is documented ([mfa.md](mfa.md)); wherever you use Lambda or Modal SSO, use an identity provider that enforces MFA and verify that enforcement for every member. No cited Modal page documents a customer-account second factor, so on Modal this guide's advice is to use SSO with Require SSO enabled where the plan allows, after confirming admin access to the Workspace through the identity provider, as Modal's SSO pages direct. This guide's advice is to confirm the available factor methods and setup steps with RunPod and Lambda, and verify account MFA enforcement on RunPod, Vast.ai and Lambda, and on Modal wherever a customer control is documented. These citations do not establish RunPod factor methods, setup steps or enforcement, Vast.ai team-wide enforcement, Lambda's own factor methods, setup steps or enforcement, whether Lambda SSO can be made the only sign-in path, any exception to Modal's Require SSO, or any Modal customer-account second-factor control or Modal-side MFA enforcement; these remain open in TODO.md under 1.264. In this guide's reasoning, an API key or proxy-auth token secures a machine client and is a separate control from the platform login.

SSH: authenticate with your own key, not a password. Lambda requires an SSH key at launch; Vast.ai disables password authentication and uses the key you register; RunPod recommends key auth and offers an optional password you should skip. Keep the private key off the instance, and treat SSH access as a control separate from the platform login above.

## Verify

REASONED: listener inventory and direct/proxied authentication pairs; no GPU-platform deployment, workload credentials or outside probe host was supplied for this metadata review, and no service run is recorded. Expected readings below follow the cited platform documentation, the Vast.ai base-image portal configurator at commit 00064421641881c1f83ff58c55f13cbc10cbea4d, Jupyter Server v2.18.0 implementation, REST specification and security documentation, iproute2 v6.12.0 ss manual and implementation, and Linux man-pages-5.13 network namespace isolation. This guide infers from the ss namespace switch and Linux namespace isolation that ss -tlnp inventories TCP listeners only in the current network namespace, assuming normal live kernel/proc inputs without input-file environment overrides. This is not a UDP, firewall-state or platform-publication check; this guide's test design requires cross-checking platform mappings and probing each mapped port from outside.

REASONED: following block; this guide's test design compares anonymous and valid-token requests directly to loopback `:8888/api/contents`. For Jupyter Server v2.18.0 with token authentication enabled, no session cookie, the route at that URL and an existing readable contents path, anonymous GET returns 403 without a login redirect; with default authorization, valid-token GET completes the JSON model. The REST specification documents HTTP 200 for this successful GET. Any anonymous data response is a finding, in this guide's assessment. Tokens are accepted in `Authorization: token` or the `token` query parameter; password-only and cookie-authenticated requests need separate controls. The Sources entries below pin the contents route, authenticated GET, API refusal, token handling and authentication/authorization defaults; the REST specification documents the successful GET response as HTTP 200. These are source-based expectations, not observed deployment results; the missing deployment and credentials prevent the live comparison here. The block exits 1 when the anonymous request gets a 2xx data response, 3 when `ss -tlnp` or a request fails, the anonymous request gets anything but 403 or a 2xx, or the valid-token positive control does not return 200, 2 when `ss` is not installed or its token guard refuses, and otherwise 0. It gives 2 only while no other part gave a finding or an inconclusive result, and it leaves any listener table it printed for you to judge.

```bash
(                                       # the whole block in one subshell, so one exit status covers every part of it
  set +e                                # errexit off here, so a part that ends nonzero is folded into the status below instead of ending the block
  set -- 0                              # the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 2 (ss is not installed, or a part refused its input), which outranks 0, so 2 stands only while nothing else was recorded
  # Inventory assumes normal live kernel/proc inputs, without ss input-file environment overrides.
  if command -v ss >/dev/null; then
    ss -tlnp ||  # TCP listening sockets in THIS network namespace only - not UDP, not a firewall, and not
                 # the platform's NAT/proxy publication. A port here may be private OR public (once exposed/
                 # mapped), and a port published by the platform need not appear here at all, so cross-check
                 # against the platform's port mappings and probe each MAPPED port from outside (next block).
      { echo "ss -tlnp exit $?; inconclusive"; set -- 3; }
  else
    echo "ss is not installed here; not listing sockets"
    case "$1" in 0) set -- 2 ;; esac
  fi
  # Does the LISTENER itself demand auth? Test it DIRECTLY on loopback, with no platform proxy in the path,
  # as a matched pair: this guide's test design. Jupyter Server v2.18.0 accepts
  # 'Authorization: token <token>' or ?token=. With token auth enabled and no session cookie,
  # /api/contents returns 403 without credentials, not a login redirect. For the route at this URL,
  # default authorization and an existing readable path, valid-token GET completes the JSON model;
  # the REST specification documents HTTP 200 for this successful GET.
  # Any anonymous data response is a finding. Substitute the real token.
  (
    # Feed the token to curl on stdin (curl --header @-), never in argv:
    # -H "Authorization: token TOKEN" is readable in ps / /proc/<pid>/cmdline.
    trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
    # The Jupyter token you substitute on the set -- line enters shell history.
    # Clear that history line afterward.
    # Stdin closes the argv channel only: it does not hide the token from set -x
    # tracing or your own account's view of the process.
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_JUPYTER_TOKEN'
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
    case "$1" in *REPLACE_WITH_*|""|*[[:cntrl:]]*) echo "substitute the Jupyter token on the set -- line above; not probing"; exit 2 ;; esac
    set -- "$1" 0                       # the 2nd value is this part's status so far, ranked as above
    set -- "$1" "$2" "$(if curl -q -g -sS -o /dev/null -w 'jupyter no-token=%{http_code} exit=%{exitcode}\n' --noproxy '*' \
      --connect-timeout 5 --max-time 10 http://127.0.0.1:8888/api/contents; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"   # curl's exit status, then its no-token line
    printf '%s\n' "$4"
    case "$3:$4" in
      0:'jupyter no-token=403 '*) ;;
      0:'jupyter no-token=2'??' '*) echo "FINDING: an anonymous request to /api/contents got a data response"; set -- "$1" 1 ;;
      0:*) echo "the no-token request got neither the 403 refusal nor a data response; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
      *) echo "curl exit $3: the no-token request failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    esac
    set -- "$1" "$2" "$(if printf 'Authorization: token %s\n' "$1" | curl -q -g -sS -o /dev/null -w 'jupyter with-token=%{http_code} exit=%{exitcode}\n' --noproxy '*' \
      --connect-timeout 5 --max-time 10 -H @- http://127.0.0.1:8888/api/contents; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"   # curl's exit status, then its with-token line
    printf '%s\n' "$4"
    case "$3:$4" in
      0:'jupyter with-token=200 '*) ;;
      0:*) echo "the valid-token request did not return 200, so the positive control failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
      *) echo "curl exit $3: the valid-token request failed, so the positive control failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    esac
    exit "$2"
  )
  case "$?:$1" in 0:*) ;; 1:*) set -- 1 ;; 2:0) set -- 2 ;; 2:*|*:1) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  echo "block exit $1; the listener table, if one was printed, is not classified, so judge it yourself, then probe each mapped port from outside with the next block"
  exit "$1"
)
```

```bash
# REASONED: outside probe of each exposed mapping, per the cited RunPod, Vast.ai, Modal and Jupyter sources; no platform deployment, outside probe host or workload credentials are available, and no run is recorded.
# Then confirm the SAME listener is authenticated FROM OUTSIDE, once PER exposed port/mapping. A probe of
# the platform proxy hostname shows reachability and that something gates the URL, but a 401/200 there can
# be the PLATFORM proxy rather than the listener, so read it with the direct-loopback pair above: a no-
# credential 200 returning app data is a finding; a 401 is only conclusive alongside a direct 200. The
# guard refuses while a placeholder remains; repeat for each mapped port.
(
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  # The token you substitute on the set -- line enters shell history.
  # Use a short-lived token or clear that history line afterward.
  # Stdin closes the argv channel only: it does not hide the token from set -x
  # tracing or your own account's view of the process.
  set -- PASTE_WHOLE_BLOCK 'https://REPLACE_WITH_POD_ID-REPLACE_WITH_PORT.proxy.runpod.net/REPLACE_WITH_PROTECTED_PATH' 'REPLACE_WITH_TOKEN'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in *REPLACE_WITH_*|"") echo "substitute the URL on the set -- line above; not probing"; exit 2 ;; esac
  case "$2" in *REPLACE_WITH_*|""|*[[:cntrl:]]*) echo "substitute the token on the set -- line above; not probing"; exit 2 ;; esac
  set -- "$1" "$2" 0                    # the 3rd value is the block's status: 3 once a request fails, otherwise 0
  curl -q -g -sS -o /dev/null -w 'no-cred=%{http_code} exit=%{exitcode}\n' --noproxy '*' --connect-timeout 5 --max-time 10 "$1" ||
    { echo "curl exit $?: the no-credential request failed; inconclusive"; set -- "$1" "$2" 3; }
  printf 'Authorization: Bearer %s\n' "$2" | curl -q -g -sS -o /dev/null -w 'with-cred=%{http_code} exit=%{exitcode}\n' --noproxy '*' --connect-timeout 5 --max-time 10 -H @- "$1" ||
    { echo "curl exit $?: the with-credential request failed; inconclusive"; set -- "$1" "$2" 3; }
  echo "block exit $3; neither code is classified, because this block cannot see whether a 200 returns app data or whose 401 it is: read them with the direct-loopback pair in the block above"
  exit "$3"
)
```

REASONED: exposure interpretation from the cited platform publication and Jupyter authentication documentation; no platform deployment or outside probe host is available. Every port `ss` shows listening should be either closed (not exposed at the platform layer) or authenticated (the listener itself demands a key, token, or login). In this guide's assessment, any anonymous Jupyter data response is a finding, whichever of these platforms it runs on; a valid session cookie is authentication, and a 403 error response is not data access. The outside block above exits 2 when its guard refuses, 3 when a request fails and otherwise 0, because it cannot see whether a 200 returns app data or which layer sent a 401, so read its codes with the direct-loopback pair.

REASONED: following block; this guide's test design for the Vast.ai portal's path exemptions and port exclusions has no live run: no Vast.ai instance or outside probe host is available. For an authenticated external mapping at base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the cited configurator lines 175-186 and 323-387 generate resolver 200, exempt-path backend responses and a Basic-auth challenge elsewhere. Before probing, establish harmless known private content at an exempt path and a non-exempt path, and obtain the portal's actual `WWW-Authenticate` header independently; confirm that the backend's own challenge differs. Substitute inside the quotes: mapped host:port, both paths starting with `/`, a distinctive non-secret body marker shared by those private resources, and that exact portal header line. If these prerequisites cannot be established, the result is INCONCLUSIVE. A public manifest is not private content merely because it returns 200. Anonymous matching content is a finding when that path is private; on the non-exempt private path, a 401 with the independently distinguished portal header matches the generated challenge, while a backend 401 or any unexplained response is INCONCLUSIVE. On the exempt path, which the configurator proxies to the backend with no credential, a complete response without the private marker is an unclassified observation for you to judge. Disabled authentication and excluded ports can expose the same content, but these probes cannot diagnose which setting caused access. The resolver's 200 tests reachability only. Headers and bodies remain visible for inspection; transport failures are INCONCLUSIVE. The block exits once, after all three probes: with status 1 if any probe printed FINDING, with status 0 only if the resolver probe printed REACHABLE, the exempt-path probe printed UNCLASSIFIED OBSERVATION and the private-path probe printed PORTAL CHALLENGE, and otherwise with status 3. A resolver 200 without the private marker prints REACHABLE, because that 200 tests reachability only, and any other resolver answer prints INCONCLUSIVE, so read each probe's line as well as the status. The block uses plain HTTP, the image default; with `ENABLE_HTTPS=true` and valid instance certificates, adjust the scheme. Repeat for each mapped port the portal proxies.

```bash
# Anonymous probes only; no credential enters this block.
(
  set +e
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_VAST_MAPPED_HOST_AND_PORT' '/REPLACE_WITH_EXEMPT_PATH' '/REPLACE_WITH_PRIVATE_PATH' 'REPLACE_WITH_PRIVATE_BODY_MARKER' 'REPLACE_WITH_PORTAL_CHALLENGE_HEADER'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 5 ] || { echo "the set -- line needs exactly 5 values; not probing"; exit 2; }
  [ -n "$1" ] && [ -n "$2" ] && [ -n "$3" ] && [ -n "$4" ] && [ -n "$5" ] || { echo "all five values are required; not probing"; exit 2; }
  case "$1$2$3$4$5" in *REPLACE_WITH_*|*[[:cntrl:]]*) echo "substitute inside the quotes on the set -- line above; not probing"; exit 2 ;; esac
  case "$2:$3" in /*:/*) ;; *) echo "both paths must start with /; not probing"; exit 2 ;; esac
  portal_probe() (
    # Positional values: host:port, path, private body marker, distinct portal header, then which probe this is (resolver, exempt or private).
    set -- "$@" "$(curl -q -g -sS -i -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' --noproxy '*' \
      --connect-timeout 5 --max-time 10 "http://$1$2"; printf '\nprobe-curl-rc=%s\n' "$?")"
    printf '%s\n%s\n' "Probe $2" "$6"
    case "$6" in *$'\nprobe-curl-rc=0') ;; *) echo 'INCONCLUSIVE: transport failure'; exit 3 ;; esac
    set -- "$1" "$2" "$3" "$4" "$5" "${6//$'\r'/}"
    case "$6" in *$'\n\n'*) ;; *) echo 'INCONCLUSIVE: no complete response headers'; exit 3 ;; esac
    set -- "$1" "$2" "$3" "$4" "$5" "${6%%$'\n\n'*}" "${6#*$'\n\n'}"
    case "${7%$'\nhttp='*}" in
      *"$3"*) echo 'FINDING: known private content returned anonymously'; exit 1 ;;
      *) case "$5:$7" in
        resolver:*$'\nhttp=200 exit=0 err=\n'*) echo 'REACHABLE: the resolver answered 200, which tests reachability only' ;;
        resolver:*) echo 'INCONCLUSIVE: the resolver did not answer 200'; exit 3 ;;
        exempt:*) echo 'UNCLASSIFIED OBSERVATION: no known private content; the cited configurator proxies this exempt path to the backend with no credential, so judge the response above yourself' ;;
        *$'\nhttp=401 exit=0 err=\n'*)
          case "$6"$'\n' in
            *$'\n'"$4"$'\n'*) echo 'PORTAL CHALLENGE: matches the independently distinguished header' ;;
            *) echo 'INCONCLUSIVE: 401 without the distinct portal challenge'; exit 3 ;;
          esac ;;
        *) echo 'INCONCLUSIVE: no known private content or distinct portal challenge'; exit 3 ;;
      esac ;;
    esac
  )
  # Each probe's status is appended to the positional values: 1 finding, 3 inconclusive, 0 for a resolver 200, an unclassified exempt-path response or a private-path portal challenge.
  portal_probe "$1" /portal-resolver "$4" "$5" resolver
  set -- "$@" "$?"
  portal_probe "$1" "$2" "$4" "$5" exempt
  set -- "$@" "$?"
  portal_probe "$1" "$3" "$4" "$5" private
  set -- "$@" "$?"
  # The block exits once: 1 if any probe found private content, else 0 only if the resolver answered 200, the exempt path's response was left unclassified and the private path saw the portal challenge, else 3.
  case "$6:$7:$8" in 1:*|*:1:*|*:1) exit 1 ;; 0:0:0) exit 0 ;; *) exit 3 ;; esac
)
```

## Common mistakes

- Assuming a rented box has a default-deny firewall like a major cloud's security group; most rented-GPU platforms do not.
- Treating a template's HTTPS proxy URL as proof the underlying service is authenticated; the proxy secures transport, not access.
- Overlooking a template's remote desktop: at Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the linux-desktop launcher configures x11vnc on port 5900 with a password from VNC_PASSWORD, falling back to OPEN_BUTTON_TOKEN when VNC_PASSWORD is unset or empty. The template README describes OPEN_BUTTON_TOKEN as randomly generated on first boot and visible in instance logs, and offers Selkies WebRTC and Guacamole browser VNC alongside direct VNC. These citations do not establish other templates' ports or password defaults, or the strength of the effective VNC password. This guide's advice: check both browser and direct VNC listeners and their public mappings for missing or weak authentication. In this guide's reasoning, the browser page's HTTPS does not protect a separately reachable VNC connection, so a direct VNC mapping needs its own strong password and an encrypted tunnel, or should be kept off the public mapping. This guide's advice: test a direct VNC mapping with a VNC client, since the browser access controls and the HTTP status checks above may not cover it.
- Leaving a Modal Web Function without `requires_proxy_auth=True` because Endpoints and Servers are private by default and it is easy to assume Web Functions are too.
- Reusing a rented box's platform login (RunPod/Vast.ai/Lambda/Modal account) as if it were the same thing as the workload's own authentication; they are separate controls.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- RunPod expose ports (proxy HTTPS, TCP forwarding): https://docs.runpod.io/pods/configuration/expose-ports
- Vast.ai networking and ports (default ports, port mapping): https://docs.vast.ai/guides/instances/connect/networking
- Vast.ai Instance Portal (PORTAL_CONFIG, Caddy reverse proxy, secure-token links): https://docs.vast.ai/guides/instances/connect/instance-portal
- Lambda Cloud firewalls (default-deny inbound, SSH/ICMP exception, rule types): https://docs.lambda.ai/public-cloud/firewalls/
- Modal proxy auth for web endpoints (Endpoints/Servers vs Web Functions defaults, headers): https://modal.com/docs/guide/webhook-proxy-auth
- Modal Shared Endpoints (Shared Endpoints always require a proxy token) (checked October 2026): https://modal.com/docs/guide/shared-endpoints
- Modal Endpoints, Proxy tokens section (Shared Endpoints always require a Proxy Token; Dedicated Endpoints can also be created with `--unauthenticated`) (checked October 2026): https://modal.com/docs/guide/endpoints
- Vast.ai base image (portal auth: `OPEN_BUTTON_TOKEN`, `WEB_PASSWORD`, `ENABLE_AUTH`/`AUTH_EXCLUDE`): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/README.md
- Jupyter Server security (token authentication; the pinned API handler below establishes the missing-credentials 403): https://jupyter-server.readthedocs.io/en/latest/operators/security.html
- Jupyter Server v2.18.0 contents handler inheritance, authenticated GET and JSON completion (checked October 2026): https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/services/contents/handlers.py#L83-L186
- Jupyter Server v2.18.0 contents route registration (checked October 2026): https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/services/contents/handlers.py#L436-L445
- Jupyter Server v2.18.0 API authentication failure without a login redirect (checked October 2026): https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/base/handlers.py#L782-L789
- Jupyter Server v2.18.0 optional contents path (checked October 2026): https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/base/handlers.py#L1201
- Jupyter Server v2.18.0 query and header token extraction and validation (checked October 2026): https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/auth/identity.py#L465-L516
- Jupyter Server v2.18.0 token and cookie identity and disabled authentication (checked October 2026): https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/auth/identity.py#L255-L298
- Jupyter Server v2.18.0 default token authentication and credential forms (checked October 2026): https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/docs/source/operators/security.rst#L6-L26
- Jupyter Server v2.18.0 authorization decisions and permissive default (checked October 2026): https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/docs/source/operators/security.rst#L315-L322
- Jupyter Server v2.18.0 REST specification for contents GET, including its HTTP 200 response (checked October 2026): https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/services/api/api.yaml#L82-L137
- Lambda SSH (an SSH key is required at launch): https://docs.lambda.ai/public-cloud/on-demand/connecting-instance/
- Vast.ai SSH (password authentication is disabled; register a key): https://docs.vast.ai/guides/instances/connect/ssh
- RunPod SSH (key authentication recommended, optional password): https://docs.runpod.io/pods/configuration/use-ssh
- iproute2 v6.12.0 `ss` manual (checked October 2026): [numeric output](https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L33-L34), [listening sockets](https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L43-L44), [process display](https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L162-L163), and [TCP sockets](https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L374-L375).
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d README authentication methods and variables (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/README.md#L175-L187
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d README portal entry fields (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/README.md#L135-L147
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d README proxy bypass and portal configuration (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/README.md#L154-L158
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d auth test credential expectations, not execution evidence (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/ROOT/opt/instance-tools/tests/base/26-caddy-auth.sh#L97-L110
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d Caddy configurator delegation; does not establish the delegated implementation (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/ROOT/opt/supervisor-scripts/caddy.sh#L9-L14
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator load order: `/etc/portal.yaml` preferred, `PORTAL_CONFIG` parsing and writeback (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L14-L40
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator `AUTH_EXCLUDE` parsing against the external port (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L68-L71
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator HTTPS off by default, authentication on unless `ENABLE_AUTH` is `false`, default username and dual-token defaults (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L75-L93
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator query, cookie and Bearer matchers accepting either token (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L125-L132
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator unauthenticated path matcher list (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L175-L186
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator per-port listener condition and per-port authentication selection (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L212-L240
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator unauthenticated port route generation (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L293-L308
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator basic-auth hashing of the web password (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L311-L321
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator authenticated route order: exempt-path proxying, cookie-setting token routes and basic-auth fallback (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L323-L387
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d configurator credential console output (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L400-L413
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d launcher reuse of `OPEN_BUTTON_TOKEN` as the Syncthing GUI API key (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/launch.sh#L77-L92
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d Syncthing supervisor API key from `OPEN_BUTTON_TOKEN` with a random fallback only when unset or empty (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/ROOT/opt/supervisor-scripts/syncthing.sh#L14-L16
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d boot-time `PORTAL_CONFIG` Jupyter rewrites (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/ROOT/etc/vast_boot.d/10-prep-env.sh#L12-L27
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d capabilities manifest auth descriptor; reporting, not enforcement (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/capabilities/manifest.py#L674-L694
- iproute2 v6.12.0 explicit network namespace selection (checked October 2026): https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L358-L359
- iproute2 v6.12.0 namespace switch option handling (checked October 2026): https://github.com/iproute2/iproute2/blob/v6.12.0/misc/ss.c#L6114-L6117
- iproute2 v6.12.0 TCP input overrides and normal netlink path (checked October 2026): https://github.com/iproute2/iproute2/blob/v6.12.0/misc/ss.c#L4235-L4240
- Linux man-pages-5.13 network namespace isolation of protocol stacks, firewall rules, /proc/net and port numbers (sockets) (checked October 2026): https://github.com/mkerrisk/man-pages/blob/man-pages-5.13/man7/network_namespaces.7#L30-L40
- Ollama v0.34.2 local API route setup, CORS and host filtering; does not establish inbound caller authentication (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/server/routes.go
- Ollama v0.34.2 client outbound signing, separate from inbound authentication (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/api/client.go
- Ollama v0.34.2 cloud sign-in command, separate from local inbound authentication (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/cmd/cmd.go
- Ollama v0.34.2 OLLAMA_AUTH setting definition (client consumption shown by the api/client.go citation) (checked October 2026): https://github.com/ollama/ollama/blob/v0.34.2/envconfig/config.go
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d linux-desktop x11vnc port and password fallback; does not establish password strength (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/derivatives/linux-desktop/ROOT/opt/supervisor-scripts/x11vnc.sh#L22-L24
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d linux-desktop browser and direct connection choices (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/derivatives/linux-desktop/README.template.md#L47-L50
- Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d linux-desktop documented VNC password and override (checked October 2026): https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/derivatives/linux-desktop/README.template.md#L76-L80
- RunPod account documentation at commit 85a9f105d28e37758a43a44b1e75dca08fc1c33c (quickstart recommendation to set up 2FA; no factor methods, setup steps or enforcement shown) (checked October 2026): https://github.com/runpod/docs/blob/85a9f105d28e37758a43a44b1e75dca08fc1c33c/get-started.mdx#L13-L17
- RunPod account documentation at commit 85a9f105d28e37758a43a44b1e75dca08fc1c33c (team roles and permission table; not a second-factor control) (checked October 2026): https://github.com/runpod/docs/blob/85a9f105d28e37758a43a44b1e75dca08fc1c33c/accounts-billing/manage-accounts.mdx#L57-L74
- RunPod account documentation at commit 85a9f105d28e37758a43a44b1e75dca08fc1c33c (product updates, November 2024: Passkey auth as passwordless WebAuthn sign-in; not stated to be a second factor; no setup steps or enforcement shown) (checked October 2026): https://github.com/runpod/docs/blob/85a9f105d28e37758a43a44b1e75dca08fc1c33c/release-notes.mdx#L387-L393
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (TOTP/SMS prerequisite and email backup/selection behaviour) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/reference/two-factor-authentication.mdx#L14-L18
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (2FA API reference: team-context error; 2FA actions must be performed in the personal context; no team-wide 2FA requirement shown) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/api-reference/two-factor-authentication-endpoints.mdx#L544
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (team-roles page's description of the `user_write` scope as allowing changes to account settings including 2FA; not a team-wide 2FA requirement) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/teams/teams-roles.mdx#L48-L52
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (permissions reference: permission categories, with `user_write` described without 2FA) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/api-reference/permissions.mdx#L14-L26
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (permissions reference: `user_write` endpoint list, with no 2FA endpoint) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/api-reference/permissions.mdx#L165-L181
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (CLI permissions page: team roles use the same permission model as API keys) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/cli/permissions.mdx#L102-L104
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (team-roles page: default Owner, Manager and Member roles and custom roles) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/teams/teams-roles.mdx#L16-L20
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (teams overview, read whole: team owners set custom access controls; no team-wide 2FA requirement shown) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/teams/teams-overview.mdx
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (managing-teams guide, read whole: default roles, invitations, team name and ownership transfer; no team-wide 2FA requirement shown) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/teams/managing-teams.mdx
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (security FAQ, read whole: account-security practices, which do not mention 2FA) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/reference/faq/security.mdx
- Vast.ai account authentication at commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d (CLI 2FA page, read whole: per-account `tfa` commands; no team-wide 2FA requirement shown) (checked October 2026): https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/cli/two-factor-authentication.mdx
- Lambda Public Cloud console (User settings MFA and account-admin management; no factor methods, setup steps or enforcement specified) (checked October 2026): https://docs.lambda.ai/public-cloud/console/
- Lambda Public Cloud single sign-on (sign-in through the organization's IdP with Custom SAML or Custom OIDC options; prerequisites include a 1-Click Cluster and the Admin role; invitation from the Lambda account manager; no MFA enforcement or SSO-only sign-in shown) (checked October 2026): https://docs.lambda.ai/public-cloud/enabling-sso/
- Modal account security (accounts provisioned through SAML SSO; separate SAML SSO docs linked; contact Modal for Google or other SSO providers; workspace roles and RBAC; no plan availability, customer second-factor control or MFA enforcement shown) (checked October 2026): https://modal.com/docs/guide/workspaces
- Modal account security (employee MFA and customer access controls; employee MFA does not establish customer MFA) (checked October 2026): https://modal.com/docs/guide/security
- Modal account security (Custom SAML SSO page: available on the Enterprise plan; prerequisites; IdP SAML application and Workspace link on the Identity and Provisioning tab; enabling "Require SSO" forces all users to sign in via SSO; no owner, recovery or alternative-login exception, customer second factor or MFA enforcement shown) (checked October 2026): https://modal.com/docs/guide/saml-sso
- Modal account security (Okta SSO page: available on the Enterprise plan; prerequisites; enabling "Require SSO" forces all users to sign in via Okta; no exception, customer second factor or MFA enforcement shown) (checked October 2026): https://modal.com/docs/guide/okta-sso
- Modal account security (Microsoft Entra SSO page: available on the Enterprise plan; prerequisites; enabling "Require SSO" forces all users to sign in via Microsoft Entra; no exception, customer second factor or MFA enforcement shown) (checked October 2026): https://modal.com/docs/guide/entra-sso


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- runpod: RunPod documentation (unknown)
- vast: Vast.ai documentation (unknown)
- vast-image: Vast.ai base image (00064421641881c1f83ff58c55f13cbc10cbea4d)
- lambda: Lambda Public Cloud documentation (unknown)
- modal: Modal proxy authentication (unknown)
- jupyter: Jupyter Server security (unknown)
- jupyter-contents: Jupyter Server contents authentication (v2.18.0)
- ollama: Ollama (v0.34.2)
- iproute2: iproute2 ss manual (v6.12.0)
- network-namespaces: Linux network namespaces manual (man-pages-5.13)
- runpod-account: RunPod account documentation (85a9f105d28e37758a43a44b1e75dca08fc1c33c)
- vast-account: Vast.ai account authentication (8629af9a05e884dd603b6a24bbb7c39826c1a10d)
- modal-account: Modal account security (unknown)

Claims (full source mapping in the JSON block below):

- publication (REASONED; runpod, vast, lambda, modal): Raw port publication or a firewall allowance adds no listener authentication; platform proxies authenticate only the routes they actually cover.
- runpod-http (REASONED; runpod): Expose HTTP Ports publishes https://[POD_ID]-[INTERNAL_PORT].proxy.runpod.net with automatic HTTPS; anyone with the URL can reach it, so the application still needs authentication.
- runpod-tcp (REASONED; runpod): Exposed TCP ports forward directly on a public IP without automatic TLS; secure template listeners before exposure and implement application TLS for sensitive TCP data.
- runpod-symmetry (REASONED; runpod): TCP configuration values above 70000 request symmetrical mapping rather than naming valid ports; read the assigned mapping from the pod environment, such as RUNPOD_TCP_PORT_70000. Mapping remains public.
- vast-ssh-port (REASONED; vast): Vast.ai SSH launch mode opens internal port 22 by default.
- vast-jupyter-port (REASONED; vast): Vast.ai Jupyter launch mode opens internal 8080 as well as SSH port 22 by default.
- vast-mapping (REASONED; vast): Each open Vast.ai internal port maps to a random external port on a usually shared public IP; the networking docs describe no additional firewall step.
- vast-proxy (REASONED; vast): Instance Portal uses local Caddy proxying when external and internal ports differ; forwarded apps can stay on loopback and PORTAL_CONFIG describes routing and presentation.
- vast-token (REASONED; vast): Portal links carry a credential token; protect the URL, test access without it and confirm the selected route actually authenticates.
- vast-auth-controls (REASONED; vast-image, vast): At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the README documents OPEN_BUTTON_TOKEN for Basic/Bearer access, WEB_PASSWORD as a custom password, ENABLE_AUTH=false to disable authentication (default true), and AUTH_EXCLUDE as external ports excluded from authentication. The cited portal-aio configurator implements these; auth test code records expectations, not observed results.
- vast-portal-routing (REASONED; vast-image): At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, portal-aio reads PORTAL_CONFIG only if /etc/portal.yaml is absent, writes it there, and emits a Caddy listener only where external and internal ports differ and the external port has a VAST_TCP_PORT mapping; other entries bypass proxying and portal authentication. In this guide's assessment, routing configuration is not a credential.
- vast-portal-jupyter (REASONED; vast-image): Boot edits PORTAL_CONFIG: absent/empty 8080 mapping drops Jupyter; non-Jupyter /.launch drops it and Jupyter /.launch rewrites 8080:18080 to equal ports unless JUPYTER_OVERRIDE=true (case-insensitive). Re-add needs no /.launch, a nonempty mapping, no Jupyter entry and FORCE_JUPYTER not false (case-insensitive); /etc/portal.yaml wins, so only effective equal-port entries lose portal authentication.
- vast-auth-defaults (REASONED; vast-image): At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the configurator keeps auth on unless ENABLE_AUTH is false case-insensitively, serves plain HTTP unless ENABLE_HTTPS is true with valid certs, and defaults WEB_USERNAME to vastai. At that commit it gives WEB_PASSWORD and OPEN_BUTTON_TOKEN no precedence: an unset one mirrors the other; if neither is set, one generated value serves both.
- vast-auth-routes (REASONED; vast-image): At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, a protected port accepts either token as a token query parameter, a container-label auth cookie or an Authorization: Bearer header, sets the cookie on a valid query token, and falls back to HTTP Basic whose hashed password is WEB_PASSWORD.
- vast-auth-exemptions (REASONED; vast-image): At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, AUTH_EXCLUDE ports, matched externally, and every port under ENABLE_AUTH=false are proxied unauthenticated, an exposure. Even on authenticated ports, /portal-resolver answers anonymously and ACME challenge, change-password, manifest and security.txt paths proxy to the backend with no credential, an exposure for private content there.
- vast-token-reuse (REASONED; vast-image): At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the configurator prints the effective credentials to its console output, and OPEN_BUTTON_TOKEN is also the Syncthing GUI API key in the launcher and supervisor scripts (the supervisor's random fallback only when unset or empty). In this guide's reasoning, sharing a token-bearing link shares these reused credentials too.
- vast-manifest-report (REASONED; vast-image): At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, manifest reporting and configurator enforcement lowercase ENABLE_AUTH and default unset to "true": reporting tests equality to "true", enforcement inequality to "false". Other values can be reported disabled yet enforced; the manifest reports, it does not enforce.
- lambda-default (REASONED; lambda): Lambda inbound firewall denies by default except ICMP and TCP 22; other listeners require explicit global/workspace rules or a per-instance ruleset attached at launch.
- lambda-rule (REASONED; lambda): An allow rule admits the specified source range without authenticating callers; pair it with listener or proxy authentication. Removing an allow rule closes access.
- modal-web (REASONED; modal): Web endpoints using modal.fastapi_endpoint, the replacement for @web_endpoint, are public by default; requires_proxy_auth=True enables proxy authentication.
- modal-dedicated (REASONED; modal): Dedicated Endpoints require proxy authentication by default; --unauthenticated makes them public.
- modal-server (REASONED; modal): Servers require proxy authentication by default; @app.server(unauthenticated=True) makes them public.
- modal-shared (REASONED; modal): Shared Endpoints always require a Proxy Token; the cited pages document the --unauthenticated option for Dedicated Endpoints only, so, in this guide's assessment, a Shared Endpoint cannot be made public.
- modal-credentials (REASONED; modal): Proxy authentication accepts Modal-Key and Modal-Secret or Authorization: Bearer &lt;token_id&gt;.&lt;token_secret&gt;; missing credentials on a protected endpoint return 401.
- runpod-bind (REASONED; runpod): RunPod HTTP proxy needs the exposed pod interface: bind the exposed service to 0.0.0.0 inside the pod, not localhost.
- listener-auth (REASONED; runpod, vast, jupyter): Whichever binding the platform's proxy needs, add the listener's OWN authentication where it supports one; otherwise keep the unauthenticated backend private and put an authenticating gateway in front, so the platform exposes the gateway rather than the bare listener.
- listener-auth-ollama (REASONED; ollama): At Ollama v0.34.2, the cited local API route setup installs CORS and host filtering without an inbound credential check. Cloud sign-in and OLLAMA_AUTH client outbound signing are separate from local inbound authentication.
- mfa (REASONED; modal, jupyter, runpod-account, vast-account, lambda, modal-account): Advice: enable account MFA on RunPod, Vast.ai and Lambda, and on Modal where a customer control is documented; verify enforcement. Use an MFA-enforcing IdP for SSO and, where Modal's plan allows, Require SSO after confirming Workspace admin access through the IdP; this guide cites no workload second factor and treats API keys and proxy tokens as separate machine-client controls.
- lambda-sso (REASONED; lambda): At the time of writing, Lambda's SSO page documents sign-in through an organization's IdP, with Custom SAML or Custom OIDC options; prerequisites include a 1-Click Cluster and the Admin role, and setup is by invitation from the Lambda account manager. This guide infers that an MFA-enforcing IdP can enforce MFA for SSO sign-ins; the page shows no Lambda-side MFA enforcement or SSO-only sign-in.
- modal-sso (REASONED; modal-account): At the time of writing, Modal's SAML, Okta and Entra SSO pages place SSO on the Enterprise plan and say enabling Require SSO forces all users to sign in via SSO, documenting no exception; the security page requires employee MFA. This guide infers an MFA-enforcing IdP can enforce MFA for SSO sign-ins but not API tokens; no cited page shows a customer second factor or customer MFA enforcement.
- account-mfa-gaps (REASONED; runpod-account, vast-account, lambda, modal-account): This guide's source assessment: RunPod's quickstart recommends 2FA, Vast.ai documents TOTP or SMS methods with an email backup, and Lambda's console page places MFA setup in User settings. These sources do not establish RunPod or Lambda factor methods, setup steps or enforcement, Vast.ai team-wide enforcement, whether Lambda SSO can be the only sign-in path, or exceptions to Modal's Require SSO.
- runpod-passkey (REASONED; runpod-account): RunPod's product updates at docs commit 85a9f105d28e37758a43a44b1e75dca08fc1c33c document Passkey auth (November 2024) as passwordless WebAuthn sign-in for phishing-resistant account access. In this guide's assessment, they do not say whether a passkey is a second factor; its search of that commit found no 2FA factor list, setup path or team 2FA requirement, which does not establish absence.
- vast-team-2fa (REASONED; vast-account): At docs commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d, Vast.ai's 2FA API reference requires 2FA actions in the personal context, and the team-roles page's user_write scope covers 2FA settings. In this guide's reading, none of nine team, permission, security and 2FA pages documents a team-wide 2FA requirement, which does not establish absence.
- lambda-ssh (REASONED; lambda): Lambda requires an SSH key at launch; keep the private key off the instance.
- vast-ssh (REASONED; vast): Vast.ai disables SSH password authentication and uses the registered public key; keep the private key off the instance.
- runpod-ssh (REASONED; runpod): RunPod recommends SSH keys and offers an optional password; use the key and skip the password.
- verify-inventory (REASONED; runpod, vast, iproute2, network-namespaces): This guide infers from the ss namespace switch and Linux namespace isolation that ss -tlnp inventories TCP listeners only in the current network namespace, assuming normal live kernel/proc inputs without input-file environment overrides. It is not a UDP, firewall-state or platform-publication check; this guide's test design requires cross-checking platform mappings and probing each from outside.
- verify-jupyter (REASONED; jupyter, jupyter-contents): This guide's test design compares anonymous and valid-token requests directly to loopback :8888/api/contents; any anonymous data response is a finding, in this guide's assessment. For Jupyter Server v2.18.0 with token authentication enabled, no session cookie, the route at that URL and an existing readable contents path, anonymous GET returns 403 without a login redirect.
- verify-jupyter-token (REASONED; jupyter, jupyter-contents): For Jupyter Server v2.18.0 with token authentication enabled, no session cookie, default authorization, the route at :8888/api/contents and an existing readable path, valid-token GET completes the JSON model (the REST specification documents HTTP 200). Tokens are accepted in Authorization: token or the token query parameter; password-only and cookie-authenticated requests need separate controls.
- verify-mapping (REASONED; runpod, vast, modal, jupyter): Repeat credential-free and authenticated requests per exposed mapping; anonymous app data fails, while a proxy 401 alone does not prove native listener auth and needs the direct positive control.
- verify-portal-exempt (REASONED; vast-image): For an authenticated portal mapping at the cited commit, this guide expects resolver 200, exempt-path backend replies and a Basic challenge elsewhere, told apart only by a portal header known to differ from the backend. Anonymous known private content is a finding; transport failures and private-path backend 401s or unexplained replies are INCONCLUSIVE; other exempt-path replies are unclassified.
- remote-desktop (REASONED; vast-image): At Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the linux-desktop launcher configures x11vnc on port 5900 with a password from VNC_PASSWORD, falling back to OPEN_BUTTON_TOKEN when VNC_PASSWORD is unset or empty. These citations do not establish other templates' ports or password defaults, or the strength of the effective VNC password.
- remote-desktop-browser (REASONED; runpod, vast, vast-image): At Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the linux-desktop template README describes OPEN_BUTTON_TOKEN as randomly generated on first boot and visible in instance logs, and offers Selkies WebRTC and Guacamole browser VNC alongside direct VNC. This guide's advice: check both browser and direct VNC listeners and their public mappings for missing or weak authentication.
- remote-desktop-direct (REASONED; runpod, vast, vast-image): In this guide's reasoning, a browser VNC page's HTTPS does not protect a separately reachable VNC connection, so a direct VNC mapping needs its own strong password and an encrypted tunnel, or should be kept off the public mapping. This guide's advice: test a direct VNC mapping with a VNC client, since browser VNC access controls and this guide's HTTP status checks may not cover it.

````json
{
  "schema": 1,
  "checked": "2026-10-21",
  "documentation_checked": "2026-09",
  "body_sha256": "dc56f7e2920fb41074b67339002a5d6ce91050c2ad499a84500d9c78c1717ea1",
  "components": {
    "runpod": {
      "name": "RunPod documentation",
      "basis": "unknown",
      "sources": {
        "s817198f039ee": "https://docs.runpod.io/pods/configuration/expose-ports",
        "s13c43b856d4f": "https://docs.runpod.io/pods/configuration/use-ssh"
      }
    },
    "vast": {
      "name": "Vast.ai documentation",
      "basis": "unknown",
      "sources": {
        "sc25989a1613e": "https://docs.vast.ai/guides/instances/connect/networking",
        "s0bdbda534723": "https://docs.vast.ai/guides/instances/connect/instance-portal",
        "s6e0303ef19fe": "https://docs.vast.ai/guides/instances/connect/ssh"
      }
    },
    "vast-image": {
      "name": "Vast.ai base image",
      "basis": "00064421641881c1f83ff58c55f13cbc10cbea4d",
      "sources": {
        "sf75c3c07819e": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/README.md",
        "s5d2b91002bac": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/README.md#L175-L187",
        "s229c9334547e": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/README.md#L135-L147",
        "s3b735c4b3632": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/README.md#L154-L158",
        "s037a7cbd778c": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/ROOT/opt/instance-tools/tests/base/26-caddy-auth.sh#L97-L110",
        "sdc669faa429d": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/ROOT/opt/supervisor-scripts/caddy.sh#L9-L14",
        "s0428d55e9145": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/derivatives/linux-desktop/ROOT/opt/supervisor-scripts/x11vnc.sh#L22-L24",
        "s1b8c6c46f358": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/derivatives/linux-desktop/README.template.md#L47-L50",
        "s44f3439f13de": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/derivatives/linux-desktop/README.template.md#L76-L80",
        "sd0ba21945c9a": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L14-L40",
        "sc77a7717bbc4": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L68-L71",
        "s3c43b58f9e41": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L75-L93",
        "sf1b910a375c6": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L125-L132",
        "sae1085635ff9": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L175-L186",
        "sd9c32e411f08": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L212-L240",
        "s5a43e0cf8348": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L293-L308",
        "sea35d951abe5": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L311-L321",
        "s4a05112af859": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L323-L387",
        "s5c18e60bb9e7": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/caddy_manager/caddy_config_manager.py#L400-L413",
        "s92be3bd5cdef": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/launch.sh#L77-L92",
        "s7ac7955e604d": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/ROOT/opt/supervisor-scripts/syncthing.sh#L14-L16",
        "s10acc068e127": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/ROOT/etc/vast_boot.d/10-prep-env.sh#L12-L27",
        "s6d0bc9f2a0da": "https://github.com/vast-ai/base-image/blob/00064421641881c1f83ff58c55f13cbc10cbea4d/portal-aio/capabilities/manifest.py#L674-L694"
      }
    },
    "lambda": {
      "name": "Lambda Public Cloud documentation",
      "basis": "unknown",
      "sources": {
        "se22064748974": "https://docs.lambda.ai/public-cloud/firewalls/",
        "sb12b4a953833": "https://docs.lambda.ai/public-cloud/on-demand/connecting-instance/",
        "s4d76884333e7": "https://docs.lambda.ai/public-cloud/console/",
        "s3b3e03a672e9": "https://docs.lambda.ai/public-cloud/enabling-sso/"
      }
    },
    "modal": {
      "name": "Modal proxy authentication",
      "basis": "unknown",
      "sources": {
        "s7d083f819a21": "https://modal.com/docs/guide/webhook-proxy-auth",
        "s12a4f5e04dbe": "https://modal.com/docs/guide/shared-endpoints",
        "s33e1c2c2faf3": "https://modal.com/docs/guide/endpoints"
      }
    },
    "jupyter": {
      "name": "Jupyter Server security",
      "basis": "unknown",
      "sources": {
        "sc703a8030c8f": "https://jupyter-server.readthedocs.io/en/latest/operators/security.html"
      }
    },
    "jupyter-contents": {
      "name": "Jupyter Server contents authentication",
      "basis": "v2.18.0",
      "sources": {
        "sdc3ad9152505": "https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/services/contents/handlers.py#L83-L186",
        "sf0a3ea8ee42e": "https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/services/contents/handlers.py#L436-L445",
        "s4bdc7b9183f3": "https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/base/handlers.py#L782-L789",
        "s4e7504ed1ac8": "https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/base/handlers.py#L1201",
        "s52316685e1e4": "https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/auth/identity.py#L465-L516",
        "s83f1081e863e": "https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/auth/identity.py#L255-L298",
        "s6c884bdf8fb4": "https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/docs/source/operators/security.rst#L6-L26",
        "sb7fab0e85c94": "https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/docs/source/operators/security.rst#L315-L322",
        "s58a8a77857b5": "https://github.com/jupyter-server/jupyter_server/blob/v2.18.0/jupyter_server/services/api/api.yaml#L82-L137"
      }
    },
    "ollama": {
      "name": "Ollama",
      "basis": "v0.34.2",
      "sources": {
        "s96f77aee8bdd": "https://github.com/ollama/ollama/blob/v0.34.2/server/routes.go",
        "sd146dc5d917d": "https://github.com/ollama/ollama/blob/v0.34.2/api/client.go",
        "s7478dad099ab": "https://github.com/ollama/ollama/blob/v0.34.2/cmd/cmd.go",
        "s2abe15b73bce": "https://github.com/ollama/ollama/blob/v0.34.2/envconfig/config.go"
      }
    },
    "iproute2": {
      "name": "iproute2 ss manual",
      "basis": "v6.12.0",
      "sources": {
        "s2afc4764d5bb": "https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L33-L34",
        "sfaa932c2ca13": "https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L43-L44",
        "sd295f82d643f": "https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L162-L163",
        "s65278ee45850": "https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L374-L375",
        "s6c87acff18cf": "https://github.com/iproute2/iproute2/blob/v6.12.0/man/man8/ss.8#L358-L359",
        "sf8fdfa16eb3f": "https://github.com/iproute2/iproute2/blob/v6.12.0/misc/ss.c#L6114-L6117",
        "s1e96518d2ede": "https://github.com/iproute2/iproute2/blob/v6.12.0/misc/ss.c#L4235-L4240"
      }
    },
    "network-namespaces": {
      "name": "Linux network namespaces manual",
      "basis": "man-pages-5.13",
      "sources": {
        "s427c923e346f": "https://github.com/mkerrisk/man-pages/blob/man-pages-5.13/man7/network_namespaces.7#L30-L40"
      }
    },
    "runpod-account": {
      "name": "RunPod account documentation",
      "basis": "85a9f105d28e37758a43a44b1e75dca08fc1c33c",
      "sources": {
        "sd631388ab114": "https://github.com/runpod/docs/blob/85a9f105d28e37758a43a44b1e75dca08fc1c33c/get-started.mdx#L13-L17",
        "se14f2c54dadd": "https://github.com/runpod/docs/blob/85a9f105d28e37758a43a44b1e75dca08fc1c33c/accounts-billing/manage-accounts.mdx#L57-L74",
        "s33231187aa09": "https://github.com/runpod/docs/blob/85a9f105d28e37758a43a44b1e75dca08fc1c33c/release-notes.mdx#L387-L393"
      }
    },
    "vast-account": {
      "name": "Vast.ai account authentication",
      "basis": "8629af9a05e884dd603b6a24bbb7c39826c1a10d",
      "sources": {
        "s34d7af02cefb": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/reference/two-factor-authentication.mdx#L14-L18",
        "s7d9050148a23": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/api-reference/two-factor-authentication-endpoints.mdx#L544",
        "s739e6a60fa5a": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/teams/teams-roles.mdx#L48-L52",
        "sc07eac4162b4": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/api-reference/permissions.mdx#L14-L26",
        "s955a47268112": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/api-reference/permissions.mdx#L165-L181",
        "s80c87ae72e03": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/cli/permissions.mdx#L102-L104",
        "s79c4266fb354": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/teams/teams-roles.mdx#L16-L20",
        "sca7b7577b245": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/teams/teams-overview.mdx",
        "s3da159748d09": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/teams/managing-teams.mdx",
        "s1d50ed14f409": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/guides/reference/faq/security.mdx",
        "s49f3fc581793": "https://github.com/vast-ai/docs/blob/8629af9a05e884dd603b6a24bbb7c39826c1a10d/cli/two-factor-authentication.mdx"
      }
    },
    "modal-account": {
      "name": "Modal account security",
      "basis": "unknown",
      "sources": {
        "sc231ebe09068": "https://modal.com/docs/guide/workspaces",
        "sbca5146e672b": "https://modal.com/docs/guide/security",
        "sda25bf7bdc76": "https://modal.com/docs/guide/saml-sso",
        "s50823c7faa20": "https://modal.com/docs/guide/okta-sso",
        "s3f8d08a8bfaf": "https://modal.com/docs/guide/entra-sso"
      }
    }
  },
  "claims": {
    "publication": {"text": "Raw port publication or a firewall allowance adds no listener authentication; platform proxies authenticate only the routes they actually cover.", "components": ["runpod", "vast", "lambda", "modal"], "sources": ["runpod:s817198f039ee", "vast:sc25989a1613e", "vast:s0bdbda534723", "lambda:se22064748974", "modal:s7d083f819a21"], "status": "REASONED"},
    "runpod-http": {"text": "Expose HTTP Ports publishes https://[POD_ID]-[INTERNAL_PORT].proxy.runpod.net with automatic HTTPS; anyone with the URL can reach it, so the application still needs authentication.", "components": ["runpod"], "sources": ["runpod:s817198f039ee"], "status": "REASONED"},
    "runpod-tcp": {"text": "Exposed TCP ports forward directly on a public IP without automatic TLS; secure template listeners before exposure and implement application TLS for sensitive TCP data.", "components": ["runpod"], "sources": ["runpod:s817198f039ee"], "status": "REASONED"},
    "runpod-symmetry": {"text": "TCP configuration values above 70000 request symmetrical mapping rather than naming valid ports; read the assigned mapping from the pod environment, such as RUNPOD_TCP_PORT_70000. Mapping remains public.", "components": ["runpod"], "sources": ["runpod:s817198f039ee"], "status": "REASONED"},
    "vast-ssh-port": {"text": "Vast.ai SSH launch mode opens internal port 22 by default.", "components": ["vast"], "sources": ["vast:sc25989a1613e"], "status": "REASONED"},
    "vast-jupyter-port": {"text": "Vast.ai Jupyter launch mode opens internal 8080 as well as SSH port 22 by default.", "components": ["vast"], "sources": ["vast:sc25989a1613e"], "status": "REASONED"},
    "vast-mapping": {"text": "Each open Vast.ai internal port maps to a random external port on a usually shared public IP; the networking docs describe no additional firewall step.", "components": ["vast"], "sources": ["vast:sc25989a1613e"], "status": "REASONED"},
    "vast-proxy": {"text": "Instance Portal uses local Caddy proxying when external and internal ports differ; forwarded apps can stay on loopback and PORTAL_CONFIG describes routing and presentation.", "components": ["vast"], "sources": ["vast:s0bdbda534723"], "status": "REASONED"},
    "vast-token": {"text": "Portal links carry a credential token; protect the URL, test access without it and confirm the selected route actually authenticates.", "components": ["vast"], "sources": ["vast:s0bdbda534723"], "status": "REASONED"},
    "vast-auth-controls": {"text": "At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the README documents OPEN_BUTTON_TOKEN for Basic/Bearer access, WEB_PASSWORD as a custom password, ENABLE_AUTH=false to disable authentication (default true), and AUTH_EXCLUDE as external ports excluded from authentication. The cited portal-aio configurator implements these; auth test code records expectations, not observed results.", "components": ["vast-image", "vast"], "sources": ["vast-image:sf75c3c07819e", "vast:s0bdbda534723", "vast-image:s5d2b91002bac", "vast-image:s229c9334547e", "vast-image:s3b735c4b3632", "vast-image:s037a7cbd778c", "vast-image:sdc669faa429d", "vast-image:sc77a7717bbc4", "vast-image:s3c43b58f9e41", "vast-image:sf1b910a375c6", "vast-image:sd9c32e411f08", "vast-image:sea35d951abe5", "vast-image:s4a05112af859"], "status": "REASONED"},
    "vast-portal-routing": {"text": "At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, portal-aio reads PORTAL_CONFIG only if /etc/portal.yaml is absent, writes it there, and emits a Caddy listener only where external and internal ports differ and the external port has a VAST_TCP_PORT mapping; other entries bypass proxying and portal authentication. In this guide's assessment, routing configuration is not a credential.", "components": ["vast-image"], "sources": ["vast-image:sd0ba21945c9a", "vast-image:sd9c32e411f08"], "status": "REASONED"},
    "vast-portal-jupyter": {"text": "Boot edits PORTAL_CONFIG: absent/empty 8080 mapping drops Jupyter; non-Jupyter /.launch drops it and Jupyter /.launch rewrites 8080:18080 to equal ports unless JUPYTER_OVERRIDE=true (case-insensitive). Re-add needs no /.launch, a nonempty mapping, no Jupyter entry and FORCE_JUPYTER not false (case-insensitive); /etc/portal.yaml wins, so only effective equal-port entries lose portal authentication.", "components": ["vast-image"], "sources": ["vast-image:s10acc068e127", "vast-image:sd9c32e411f08", "vast-image:sd0ba21945c9a"], "status": "REASONED"},
    "vast-auth-defaults": {"text": "At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the configurator keeps auth on unless ENABLE_AUTH is false case-insensitively, serves plain HTTP unless ENABLE_HTTPS is true with valid certs, and defaults WEB_USERNAME to vastai. At that commit it gives WEB_PASSWORD and OPEN_BUTTON_TOKEN no precedence: an unset one mirrors the other; if neither is set, one generated value serves both.", "components": ["vast-image"], "sources": ["vast-image:s3c43b58f9e41"], "status": "REASONED"},
    "vast-auth-routes": {"text": "At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, a protected port accepts either token as a token query parameter, a container-label auth cookie or an Authorization: Bearer header, sets the cookie on a valid query token, and falls back to HTTP Basic whose hashed password is WEB_PASSWORD.", "components": ["vast-image"], "sources": ["vast-image:sf1b910a375c6", "vast-image:s4a05112af859", "vast-image:sea35d951abe5"], "status": "REASONED"},
    "vast-auth-exemptions": {"text": "At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, AUTH_EXCLUDE ports, matched externally, and every port under ENABLE_AUTH=false are proxied unauthenticated, an exposure. Even on authenticated ports, /portal-resolver answers anonymously and ACME challenge, change-password, manifest and security.txt paths proxy to the backend with no credential, an exposure for private content there.", "components": ["vast-image"], "sources": ["vast-image:sc77a7717bbc4", "vast-image:sd9c32e411f08", "vast-image:s5a43e0cf8348", "vast-image:sae1085635ff9", "vast-image:s4a05112af859"], "status": "REASONED"},
    "vast-token-reuse": {"text": "At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the configurator prints the effective credentials to its console output, and OPEN_BUTTON_TOKEN is also the Syncthing GUI API key in the launcher and supervisor scripts (the supervisor's random fallback only when unset or empty). In this guide's reasoning, sharing a token-bearing link shares these reused credentials too.", "components": ["vast-image"], "sources": ["vast-image:s5c18e60bb9e7", "vast-image:s92be3bd5cdef", "vast-image:s7ac7955e604d"], "status": "REASONED"},
    "vast-manifest-report": {"text": "At base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, manifest reporting and configurator enforcement lowercase ENABLE_AUTH and default unset to \"true\": reporting tests equality to \"true\", enforcement inequality to \"false\". Other values can be reported disabled yet enforced; the manifest reports, it does not enforce.", "components": ["vast-image"], "sources": ["vast-image:s6d0bc9f2a0da", "vast-image:s3c43b58f9e41"], "status": "REASONED"},
    "lambda-default": {"text": "Lambda inbound firewall denies by default except ICMP and TCP 22; other listeners require explicit global/workspace rules or a per-instance ruleset attached at launch.", "components": ["lambda"], "sources": ["lambda:se22064748974"], "status": "REASONED"},
    "lambda-rule": {"text": "An allow rule admits the specified source range without authenticating callers; pair it with listener or proxy authentication. Removing an allow rule closes access.", "components": ["lambda"], "sources": ["lambda:se22064748974"], "status": "REASONED"},
    "modal-web": {"text": "Web endpoints using modal.fastapi_endpoint, the replacement for @web_endpoint, are public by default; requires_proxy_auth=True enables proxy authentication.", "components": ["modal"], "sources": ["modal:s7d083f819a21"], "status": "REASONED"},
    "modal-dedicated": {"text": "Dedicated Endpoints require proxy authentication by default; --unauthenticated makes them public.", "components": ["modal"], "sources": ["modal:s7d083f819a21"], "status": "REASONED"},
    "modal-server": {"text": "Servers require proxy authentication by default; @app.server(unauthenticated=True) makes them public.", "components": ["modal"], "sources": ["modal:s7d083f819a21"], "status": "REASONED"},
    "modal-shared": {"text": "Shared Endpoints always require a Proxy Token; the cited pages document the --unauthenticated option for Dedicated Endpoints only, so, in this guide's assessment, a Shared Endpoint cannot be made public.", "components": ["modal"], "sources": ["modal:s7d083f819a21", "modal:s12a4f5e04dbe", "modal:s33e1c2c2faf3"], "status": "REASONED"},
    "modal-credentials": {"text": "Proxy authentication accepts Modal-Key and Modal-Secret or Authorization: Bearer <token_id>.<token_secret>; missing credentials on a protected endpoint return 401.", "components": ["modal"], "sources": ["modal:s7d083f819a21"], "status": "REASONED"},
    "runpod-bind": {"text": "RunPod HTTP proxy needs the exposed pod interface: bind the exposed service to 0.0.0.0 inside the pod, not localhost.", "components": ["runpod"], "sources": ["runpod:s817198f039ee"], "status": "REASONED"},
    "listener-auth": {"text": "Whichever binding the platform's proxy needs, add the listener's OWN authentication where it supports one; otherwise keep the unauthenticated backend private and put an authenticating gateway in front, so the platform exposes the gateway rather than the bare listener.", "components": ["runpod", "vast", "jupyter"], "sources": ["runpod:s817198f039ee", "vast:s0bdbda534723", "jupyter:sc703a8030c8f"], "status": "REASONED"},
    "listener-auth-ollama": {"text": "At Ollama v0.34.2, the cited local API route setup installs CORS and host filtering without an inbound credential check. Cloud sign-in and OLLAMA_AUTH client outbound signing are separate from local inbound authentication.", "components": ["ollama"], "sources": ["ollama:s96f77aee8bdd", "ollama:sd146dc5d917d", "ollama:s7478dad099ab", "ollama:s2abe15b73bce"], "status": "REASONED"},
    "mfa": {"text": "Advice: enable account MFA on RunPod, Vast.ai and Lambda, and on Modal where a customer control is documented; verify enforcement. Use an MFA-enforcing IdP for SSO and, where Modal's plan allows, Require SSO after confirming Workspace admin access through the IdP; this guide cites no workload second factor and treats API keys and proxy tokens as separate machine-client controls.", "components": ["modal", "jupyter", "runpod-account", "vast-account", "lambda", "modal-account"], "sources": ["modal:s7d083f819a21", "jupyter:sc703a8030c8f", "runpod-account:sd631388ab114", "runpod-account:se14f2c54dadd", "vast-account:s34d7af02cefb", "lambda:s4d76884333e7", "lambda:s3b3e03a672e9", "modal-account:sc231ebe09068", "modal-account:sbca5146e672b", "modal-account:sda25bf7bdc76", "modal-account:s50823c7faa20", "modal-account:s3f8d08a8bfaf"], "status": "REASONED"},
    "lambda-sso": {"text": "At the time of writing, Lambda's SSO page documents sign-in through an organization's IdP, with Custom SAML or Custom OIDC options; prerequisites include a 1-Click Cluster and the Admin role, and setup is by invitation from the Lambda account manager. This guide infers that an MFA-enforcing IdP can enforce MFA for SSO sign-ins; the page shows no Lambda-side MFA enforcement or SSO-only sign-in.", "components": ["lambda"], "sources": ["lambda:s3b3e03a672e9"], "status": "REASONED"},
    "modal-sso": {"text": "At the time of writing, Modal's SAML, Okta and Entra SSO pages place SSO on the Enterprise plan and say enabling Require SSO forces all users to sign in via SSO, documenting no exception; the security page requires employee MFA. This guide infers an MFA-enforcing IdP can enforce MFA for SSO sign-ins but not API tokens; no cited page shows a customer second factor or customer MFA enforcement.", "components": ["modal-account"], "sources": ["modal-account:sc231ebe09068", "modal-account:sbca5146e672b", "modal-account:sda25bf7bdc76", "modal-account:s50823c7faa20", "modal-account:s3f8d08a8bfaf"], "status": "REASONED"},
    "account-mfa-gaps": {"text": "This guide's source assessment: RunPod's quickstart recommends 2FA, Vast.ai documents TOTP or SMS methods with an email backup, and Lambda's console page places MFA setup in User settings. These sources do not establish RunPod or Lambda factor methods, setup steps or enforcement, Vast.ai team-wide enforcement, whether Lambda SSO can be the only sign-in path, or exceptions to Modal's Require SSO.", "components": ["runpod-account", "vast-account", "lambda", "modal-account"], "sources": ["runpod-account:sd631388ab114", "runpod-account:se14f2c54dadd", "vast-account:s34d7af02cefb", "lambda:s4d76884333e7", "lambda:s3b3e03a672e9", "modal-account:sda25bf7bdc76", "modal-account:s50823c7faa20", "modal-account:s3f8d08a8bfaf"], "status": "REASONED"},
    "runpod-passkey": {"text": "RunPod's product updates at docs commit 85a9f105d28e37758a43a44b1e75dca08fc1c33c document Passkey auth (November 2024) as passwordless WebAuthn sign-in for phishing-resistant account access. In this guide's assessment, they do not say whether a passkey is a second factor; its search of that commit found no 2FA factor list, setup path or team 2FA requirement, which does not establish absence.", "components": ["runpod-account"], "sources": ["runpod-account:s33231187aa09"], "status": "REASONED"},
    "vast-team-2fa": {"text": "At docs commit 8629af9a05e884dd603b6a24bbb7c39826c1a10d, Vast.ai's 2FA API reference requires 2FA actions in the personal context, and the team-roles page's user_write scope covers 2FA settings. In this guide's reading, none of nine team, permission, security and 2FA pages documents a team-wide 2FA requirement, which does not establish absence.", "components": ["vast-account"], "sources": ["vast-account:s7d9050148a23", "vast-account:s739e6a60fa5a", "vast-account:s34d7af02cefb", "vast-account:sc07eac4162b4", "vast-account:s955a47268112", "vast-account:s80c87ae72e03", "vast-account:s79c4266fb354", "vast-account:sca7b7577b245", "vast-account:s3da159748d09", "vast-account:s1d50ed14f409", "vast-account:s49f3fc581793"], "status": "REASONED"},
    "lambda-ssh": {"text": "Lambda requires an SSH key at launch; keep the private key off the instance.", "components": ["lambda"], "sources": ["lambda:sb12b4a953833"], "status": "REASONED"},
    "vast-ssh": {"text": "Vast.ai disables SSH password authentication and uses the registered public key; keep the private key off the instance.", "components": ["vast"], "sources": ["vast:s6e0303ef19fe"], "status": "REASONED"},
    "runpod-ssh": {"text": "RunPod recommends SSH keys and offers an optional password; use the key and skip the password.", "components": ["runpod"], "sources": ["runpod:s13c43b856d4f"], "status": "REASONED"},
    "verify-inventory": {"text": "This guide infers from the ss namespace switch and Linux namespace isolation that ss -tlnp inventories TCP listeners only in the current network namespace, assuming normal live kernel/proc inputs without input-file environment overrides. It is not a UDP, firewall-state or platform-publication check; this guide's test design requires cross-checking platform mappings and probing each from outside.", "components": ["runpod", "vast", "iproute2", "network-namespaces"], "sources": ["runpod:s817198f039ee", "vast:sc25989a1613e", "iproute2:s2afc4764d5bb", "iproute2:sfaa932c2ca13", "iproute2:sd295f82d643f", "iproute2:s65278ee45850", "iproute2:s6c87acff18cf", "iproute2:sf8fdfa16eb3f", "iproute2:s1e96518d2ede", "network-namespaces:s427c923e346f"], "status": "REASONED", "verify": [1]},
    "verify-jupyter": {"text": "This guide's test design compares anonymous and valid-token requests directly to loopback :8888/api/contents; any anonymous data response is a finding, in this guide's assessment. For Jupyter Server v2.18.0 with token authentication enabled, no session cookie, the route at that URL and an existing readable contents path, anonymous GET returns 403 without a login redirect.", "components": ["jupyter", "jupyter-contents"], "sources": ["jupyter:sc703a8030c8f", "jupyter-contents:sdc3ad9152505", "jupyter-contents:sf0a3ea8ee42e", "jupyter-contents:s4bdc7b9183f3", "jupyter-contents:s4e7504ed1ac8", "jupyter-contents:s83f1081e863e", "jupyter-contents:s6c884bdf8fb4"], "status": "REASONED", "verify": [1]},
    "verify-jupyter-token": {"text": "For Jupyter Server v2.18.0 with token authentication enabled, no session cookie, default authorization, the route at :8888/api/contents and an existing readable path, valid-token GET completes the JSON model (the REST specification documents HTTP 200). Tokens are accepted in Authorization: token or the token query parameter; password-only and cookie-authenticated requests need separate controls.", "components": ["jupyter", "jupyter-contents"], "sources": ["jupyter:sc703a8030c8f", "jupyter-contents:sdc3ad9152505", "jupyter-contents:sf0a3ea8ee42e", "jupyter-contents:s4e7504ed1ac8", "jupyter-contents:s52316685e1e4", "jupyter-contents:s83f1081e863e", "jupyter-contents:s6c884bdf8fb4", "jupyter-contents:sb7fab0e85c94", "jupyter-contents:s58a8a77857b5"], "status": "REASONED", "verify": [1]},
    "verify-mapping": {"text": "Repeat credential-free and authenticated requests per exposed mapping; anonymous app data fails, while a proxy 401 alone does not prove native listener auth and needs the direct positive control.", "components": ["runpod", "vast", "modal", "jupyter"], "sources": ["runpod:s817198f039ee", "vast:sc25989a1613e", "vast:s0bdbda534723", "modal:s7d083f819a21", "jupyter:sc703a8030c8f"], "status": "REASONED", "verify": [2]},
    "verify-portal-exempt": {"text": "For an authenticated portal mapping at the cited commit, this guide expects resolver 200, exempt-path backend replies and a Basic challenge elsewhere, told apart only by a portal header known to differ from the backend. Anonymous known private content is a finding; transport failures and private-path backend 401s or unexplained replies are INCONCLUSIVE; other exempt-path replies are unclassified.", "components": ["vast-image"], "sources": ["vast-image:sae1085635ff9", "vast-image:s4a05112af859", "vast-image:sd9c32e411f08", "vast-image:s3c43b58f9e41"], "status": "REASONED", "verify": [3]},
    "remote-desktop": {"text": "At Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the linux-desktop launcher configures x11vnc on port 5900 with a password from VNC_PASSWORD, falling back to OPEN_BUTTON_TOKEN when VNC_PASSWORD is unset or empty. These citations do not establish other templates' ports or password defaults, or the strength of the effective VNC password.", "components": ["vast-image"], "sources": ["vast-image:s0428d55e9145", "vast-image:s44f3439f13de"], "status": "REASONED"},
    "remote-desktop-browser": {"text": "At Vast.ai base-image commit 00064421641881c1f83ff58c55f13cbc10cbea4d, the linux-desktop template README describes OPEN_BUTTON_TOKEN as randomly generated on first boot and visible in instance logs, and offers Selkies WebRTC and Guacamole browser VNC alongside direct VNC. This guide's advice: check both browser and direct VNC listeners and their public mappings for missing or weak authentication.", "components": ["runpod", "vast", "vast-image"], "sources": ["runpod:s817198f039ee", "vast:sc25989a1613e", "vast-image:s1b8c6c46f358", "vast-image:s44f3439f13de"], "status": "REASONED"},
    "remote-desktop-direct": {"text": "In this guide's reasoning, a browser VNC page's HTTPS does not protect a separately reachable VNC connection, so a direct VNC mapping needs its own strong password and an encrypted tunnel, or should be kept off the public mapping. This guide's advice: test a direct VNC mapping with a VNC client, since browser VNC access controls and this guide's HTTP status checks may not cover it.", "components": ["runpod", "vast", "vast-image"], "sources": ["runpod:s817198f039ee", "vast:sc25989a1613e", "vast-image:s1b8c6c46f358"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
