# Apache Kafka: SASL_SSL listeners, SCRAM credentials, and ACLs

Apache Kafka is a message broker: applications write records to named topics and other applications read them. This guide helps your AI assistant make sure it is configured securely, including the plaintext listener replaced, TLS on the broker, SASL/SCRAM credentials, ACL authorization, bounded connection pressure, and authorization decisions logged.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/kafka.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Kafka listener default 4.3.1, Kafka documentation 4.3, Kafka source 4.3.0, Kafka legacy authorization 3.9, and OpenSSL documentation 3.5; 2 further sources carry no recorded version. Metadata reviewed 2026-09-26; documentation checked September 2026. The guide records 41 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Kafka's broker defaults are `listeners=PLAINTEXT://:9092` (as of Kafka 4.3.1), `security.inter.broker.protocol=PLAINTEXT`, and no authorizer, so anyone who reaches port 9092 can read every topic, produce to it, and create or delete topics with no credential and no encryption. Property names below come from the Kafka 4.x documentation (KRaft mode).

The examples below target Kafka 4.3. Kafka 4.0 and later support KRaft only; the ZooKeeper authorizer note applies to legacy 3.9 deployments. Replace example addresses, certificate subjects, and secrets before deployment.

## 1. Replace the plaintext listener

A client-facing socket should not also be the cluster's replication socket. Give clients, brokers, and controllers distinct listeners. Bind internal listeners to private addresses, restrict their network reachability, and authenticate them even on the private network. Remove the plaintext listener entirely: an unadvertised or loopback-bound socket still accepts direct connections.

This example uses SCRAM over TLS for applications and mutual TLS for internal traffic. Keep step 2's keystore/truststore settings on every node. Each node needs its own certificate, with SANs matching the hostnames used to reach it. Internal truststores must trust the intended internal certificate issuers.

These are security overlays for separate KRaft roles. Retain each node's unique `node.id` and storage configuration. Apply the common settings to brokers and controllers:

```properties
listener.security.protocol.map=CLIENT:SASL_SSL,INTERNAL:SSL,CONTROLLER:SSL
inter.broker.listener.name=INTERNAL
controller.listener.names=CONTROLLER
controller.quorum.bootstrap.servers=controller-1.internal:9094,controller-2.internal:9094,controller-3.internal:9094
listener.name.internal.ssl.client.auth=required
listener.name.controller.ssl.client.auth=required
ssl.endpoint.identification.algorithm=https
```

Broker-specific settings, substituting the broker's real private address and advertised hostnames:

```properties
process.roles=broker
listeners=CLIENT://0.0.0.0:9093,INTERNAL://10.0.0.11:9095
advertised.listeners=CLIENT://kafka.example.com:9093,INTERNAL://broker-1.internal:9095
sasl.enabled.mechanisms=SCRAM-SHA-512
listener.name.client.sasl.enabled.mechanisms=SCRAM-SHA-512
listener.name.client.scram-sha-512.sasl.jaas.config=org.apache.kafka.common.security.scram.ScramLoginModule required;
```

Restrict access to `CLIENT` to the intended application networks too. Its wildcard bind is not a firewall policy.

Controller-specific settings, substituting that controller's real private address:

```properties
process.roles=controller
listeners=CONTROLLER://10.0.0.21:9094
```

For this layout, advertise only `CLIENT` and `INTERNAL` on brokers; omit `advertised.listeners` from the controller overlay. Broker-only nodes still need the controller listener's protocol mapping and security settings for outbound connections, although they do not bind that listener. The first entry in `controller.listener.names` selects outbound controller traffic.

Replace the previous listener definitions and obsolete listener-prefixed properties. Remove the previous controller PLAIN JAAS configuration, `sasl.mechanism.controller.protocol`, and `sasl.mechanism.inter.broker.protocol`: the internal connections now use certificate authentication. Select the inter-broker listener by name with `inter.broker.listener.name=INTERNAL`; do not also set `security.inter.broker.protocol`. Setting both is a startup error. The shipped configuration already selects an inter-broker listener, so replace that selection.

The prefix in `listener.name.<name>.*` uses the listener name lowercased. Rename every affected prefix when renaming a listener; properties under an unused listener name do not configure the intended listener.

Kafka advises against combined broker/controller roles for critical deployments. If retaining a combined node, its `listeners` must include the controller listener as well as the broker listeners. Keep distinct ports for this layout. The distribution's example controller uses 9093, which this guide assigns to clients; move both the controller binding and quorum bootstrap endpoints to 9094. Otherwise overlapping listener bindings can prevent startup.

The quorum example is for a dynamic KRaft quorum. Do not combine it with a static `controller.quorum.voters` configuration. An existing static quorum needs the documented migration procedure, not just replacement of its voter list with bootstrap addresses. See [KRaft process roles and quorum provisioning](https://kafka.apache.org/43/operations/kraft/) and [listener configuration](https://kafka.apache.org/43/security/listener-configuration/).

Retain the controller SCRAM caution narrowly: at the time of writing, [KAFKA-15513](https://issues.apache.org/jira/browse/KAFKA-15513) remains unresolved, lists affected versions 3.5.1 and 3.6.0, and lists no fixed version. It describes controller-to-controller SCRAM bootstrap failures; it does not establish a reproduced failure on every Kafka 4.3 deployment. Internal mutual TLS avoids relying on controller SCRAM bootstrap here.

Apply step 4's deny-by-default authorizer and authorize the actual internal certificate principals before starting a new quorum. Controllers must be authenticated and private.

## 2. TLS on the broker

Get a certificate ([free-certificates.md](free-certificates.md) or [self-signed.md](self-signed.md); an internal CA fits a cluster) and point the broker at it. Kafka 2.7.0 and later also take PEM: `ssl.keystore.type=PEM` with `ssl.keystore.certificate.chain` and `ssl.keystore.key` (PKCS#8), and `ssl.truststore.type=PEM` with `ssl.truststore.certificates`. Hostname verification (`ssl.endpoint.identification.algorithm`) is on by default since 2.0.0; the documentation discourages blanking it.

Keep these settings in the service-owned server properties file, with mode 0600 established before populating it. Protect keystores, private keys, JAAS files, client properties, and secret provisioning files the same way; restrict their parent directories. Passwords belong in those files, never in command-line arguments.

```properties
ssl.keystore.location=/var/private/ssl/server.keystore.jks
ssl.keystore.password=REPLACE_WITH_LONG_RANDOM_VALUE
ssl.key.password=REPLACE_WITH_LONG_RANDOM_VALUE
ssl.truststore.location=/var/private/ssl/server.truststore.jks
ssl.truststore.password=REPLACE_WITH_LONG_RANDOM_VALUE
# Client certificates on CLIENT: none (default), requested (optional), or required (mutual TLS).
# On a SASL_SSL listener this property needs the listener prefix.
listener.name.client.ssl.client.auth=none
```

Install the keystore/truststore settings on controllers too, using each node's own files. The last line belongs on brokers exposing `CLIENT`; it does not override the required client certificates on `INTERNAL` and `CONTROLLER`.

The unprefixed `ssl.client.auth` applies to `SSL` listeners; a `SASL_SSL` listener needs the listener-prefixed setting. `requested` permits clients without certificates and is not equivalent to `required`.

For PEM, store passwords are not supported; an encrypted PKCS#8 key uses `ssl.key.password`. Keep the inline PEM material in a protected properties file if using that form.

Do not copy the old TLSv1/TLSv1.1 examples still present on the SSL page. The generated Kafka 4.3 reference gives `TLSv1.2,TLSv1.3` as the `ssl.enabled.protocols` default. See [SSL configuration](https://kafka.apache.org/43/security/encryption-and-authentication-using-ssl/) and the [broker configuration reference](https://kafka.apache.org/43/configuration/broker-configs/).

## 3. SASL/SCRAM credentials

The documentation says SCRAM should be used only with TLS, hence `SASL_SSL` rather than `SASL_PLAINTEXT`. Give each application role its own credential ([authentication.md](authentication.md)). Keep SCRAM-SHA-512 and the listener JAAS configuration from step 1.

KRaft SCRAM identities reside in the metadata log. Protect controller storage, snapshots/backups, and controller access. Legacy ZooKeeper credential-store descriptions do not describe this deployment.

If inter-broker communication uses SCRAM, its credentials must exist before brokers start. This guide instead uses internal mutual TLS, so no inter-broker SCRAM password is needed during storage formatting.

For a new dynamic quorum, generate the cluster ID once and reuse that exact value on every node. The following bootstraps only the first controller:

```bash
# Run ONCE; retain the same cluster ID for every node.
if CLUSTER_ID="$(bin/kafka-storage.sh random-uuid)" && [ -n "$CLUSTER_ID" ]; then
  printf 'Cluster ID: %s\n' "$CLUSTER_ID"
  # First controller only, when bootstrapping a new dynamic quorum with one voter:
  bin/kafka-storage.sh format --cluster-id "$CLUSTER_ID" \
    --config config/controller.properties --standalone
else
  echo "cluster ID generation failed or printed nothing; storage not formatted"
fi
```

The `if` keeps `CLUSTER_ID` in your shell for the later nodes, and when generation fails or prints nothing the block prints a message instead of formatting storage. The block runs no `exit` itself and assumes a fresh shell, as [CONTRIBUTING.md](CONTRIBUTING.md) rule 6 does for Verify blocks; a shell with `set -e` in effect still closes if `format` fails.

Do not run `--standalone` independently on every controller. Follow the documented membership workflow to add the remaining controllers before relying on quorum redundancy. New brokers and controllers joining an existing dynamic quorum are formatted with the same cluster ID and `--no-initial-controllers`. Alternatively, bootstrap multiple controllers with `--initial-controllers`, using the same complete `id@hostname:port:directory-id` list on every initial controller and a distinct directory ID for each controller. Generate directory IDs separately from the shared cluster ID. Formatting is for new storage, not an authentication migration on an existing cluster. See [KRaft provisioning](https://kafka.apache.org/43/operations/kraft/).

Before starting the nodes, configure the certificate super users in step 4. Then use an administrative mTLS client on the private broker `INTERNAL` listener to provision the first SCRAM administrator. Its restricted `bootstrap-admin.properties` contains:

```properties
security.protocol=SSL
ssl.truststore.location=/var/private/ssl/client.truststore.jks
ssl.truststore.password=REPLACE_WITH_LONG_RANDOM_VALUE
ssl.keystore.location=/var/private/ssl/bootstrap-admin.keystore.jks
ssl.keystore.password=REPLACE_WITH_LONG_RANDOM_VALUE
ssl.key.password=REPLACE_WITH_LONG_RANDOM_VALUE
```

The client certificate must have the exact bootstrap administrator principal authorized in step 4.

Create separate service-owned, mode-0600 files for `admin`, `orders-writer`, and `orders-reader`, establishing permissions before writing secrets. For example, `/etc/kafka/secrets/orders-writer.scram.properties` contains:

```properties
SCRAM-SHA-512=iterations=8192,password=REPLACE_WITH_LONG_RANDOM_VALUE
```

Use a different long random password in each file. This is Java properties syntax: there are no square brackets around the value. The inline `--add-config` parser removes brackets; the `--add-config-file` path does not. Preserve any necessary Java properties escaping when inserting a real secret.

Bootstrap the administrator through the private listener:

```bash
bin/kafka-configs.sh --bootstrap-server broker-1.internal:9095 \
  --command-config bootstrap-admin.properties \
  --alter --entity-type users --entity-name admin \
  --add-config-file /etc/kafka/secrets/admin.scram.properties
```

Create `admin.properties` using step 7's SASL client configuration with username `admin` and its own password. Once that credential works, provision the application roles:

```bash
bin/kafka-configs.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --alter --entity-type users --entity-name orders-writer \
  --add-config-file /etc/kafka/secrets/orders-writer.scram.properties

bin/kafka-configs.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --alter --entity-type users --entity-name orders-reader \
  --add-config-file /etc/kafka/secrets/orders-reader.scram.properties
```

On an already running cluster, an existing authorized administrator can use these file-based commands directly. Keep provisioning files and diagnostic output private: malformed SCRAM input can be included in CLI error messages. Do not substitute a file's contents into `--add-scram` or `--add-config`; that still puts the password in argv. The storage tool is not used here as a password-file interface.

The empty server-side SCRAM login module options in step 1 are intentional: these brokers accept application SCRAM connections but authenticate their own internal connections with certificates. See [SASL/SCRAM configuration and credential storage](https://kafka.apache.org/43/security/authentication-using-sasl/) and [ConfigCommand's file loading and SCRAM parser](https://github.com/apache/kafka/blob/4.3.0/core/src/main/scala/kafka/admin/ConfigCommand.scala).

## 4. Authorization

Without an authorizer every authenticated user can do everything. Enable the KRaft authorizer on every broker and controller and keep deny-by-default. A fresh quorum also needs its internal node identities authorized before ACL metadata is available.

Enumerate the exact certificate principals for every broker, every controller, and the bootstrap administrator. The following is an example only where the certificates' complete subjects are exactly the shown CNs:

```properties
authorizer.class.name=org.apache.kafka.metadata.authorizer.StandardAuthorizer
allow.everyone.if.no.acl.found=false
super.users=User:admin;User:CN=broker-1;User:CN=controller-1;User:CN=controller-2;User:CN=controller-3;User:CN=bootstrap-admin
```

Expand the list for the actual cluster. A certificate subject containing other components needs its complete principal, not just its CN. The separator between super users is a semicolon, because certificate subjects can contain commas. Never add application principals. Protect node and bootstrap administrator private keys as administrative credentials. See [KIP-801 bootstrapping](https://cwiki.apache.org/confluence/spaces/KAFKA/pages/195728007/KIP-801+Implement+an+Authorizer+that+stores+metadata+in+__cluster_metadata).

For a legacy ZooKeeper deployment on Kafka 3.9, the authorizer class is `kafka.security.authorizer.AclAuthorizer`, not `kafka.security.auth.SimpleAclAuthorizer`. Do not substitute that class into Kafka 4.3. See the [3.9 authorization reference](https://kafka.apache.org/39/security/authorization-and-acls/).

A producer credential should not also read orders, and a consumer credential should not write them. Provision separate `orders-writer` and `orders-reader` identities. Create topics through an administrative workflow and grant applications only the operations they need.

Disable automatic topic creation in the broker configuration:

```properties
auto.create.topics.enable=false
```

Create `orders` administratively before starting the applications, using the partition count and replication factor appropriate to the deployment. Grant the application roles:

```bash
bin/kafka-acls.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --add --allow-principal User:orders-writer \
  --operation Write --operation Describe \
  --topic orders --resource-pattern-type literal

bin/kafka-acls.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --add --allow-principal User:orders-reader \
  --operation Read --operation Describe \
  --topic orders --resource-pattern-type literal

bin/kafka-acls.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --add --allow-principal User:orders-reader \
  --operation Read --group app-workers --resource-pattern-type literal
```

Replace the old grants rather than accumulating permissions. After migrating the application, remove the previous shared `User:app` grants:

```bash
bin/kafka-acls.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --remove --force --allow-principal User:app --producer \
  --topic orders --resource-pattern-type literal

bin/kafka-acls.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --remove --force --allow-principal User:app --consumer \
  --topic orders --group app-workers --resource-pattern-type literal
```

Each removal here and in Verify passes `--force`. Without it, Kafka 4.3.0's `kafka-acls.sh` prints a confirmation question before every removal, reads the answer with `System.console().readLine()` and removes nothing unless the answer is `y` or `Y`. If Java provides no console, that call fails and `main`'s handler exits with status 1; whether a console exists without a terminal depends on the Java version. See [AclCommand's removal](https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/AclCommand.java#L130-L148), [confirmation](https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/AclCommand.java#L383-L389) and [error exit](https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/AclCommand.java#L84-L88).

Inspect matching wildcard and prefix ACLs, including grants to `User:*`, and cluster-level grants. Removing these literal grants does not remove permissions conferred elsewhere. Retire the old shared credential after its remaining uses have been removed.

The `--producer` convenience option grants topic `Create` as well as `Write` and `Describe`; use the explicit grants above for the new writer. Disabling automatic creation alone does not remove explicit creation rights.

If the producer uses transactions, additionally authorize its specific transaction identity:

```bash
bin/kafka-acls.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --add --allow-principal User:orders-writer \
  --operation Write --transactional-id orders-writer-1 \
  --resource-pattern-type literal
```

Use that identity as the producer's `transactional.id`. Do not automatically add cluster-wide `IdempotentWrite`: Kafka 4.3.0's non-transactional producer initialization also accepts a principal with topic `Write` permission. The manual's authorization table is less precise on this point; the tagged [InitProducerId implementation](https://github.com/apache/kafka/blob/4.3.0/core/src/main/scala/kafka/server/KafkaApis.scala) supplies the distinction.

See [Authorization and ACLs](https://kafka.apache.org/43/security/authorization-and-acls/) and [multi-tenancy topic-creation controls](https://kafka.apache.org/43/operations/multi-tenancy/).

## 5. Bound authenticated traffic and connection pressure

Authentication does not stop a compromised application from exhausting broker resources. Set quotas by authenticated user, and limit connections on the client listener. Tune these example values against normal traffic before rollout.

```bash
bin/kafka-configs.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --alter --entity-type users --entity-name orders-writer \
  --add-config 'producer_byte_rate=1048576,request_percentage=25'

bin/kafka-configs.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --alter --entity-type users --entity-name orders-reader \
  --add-config 'consumer_byte_rate=2097152,request_percentage=25'
```

These byte rates apply per broker. `request_percentage=25` permits processing time equivalent to 25 percent of one thread, accumulated across the broker's network and request-handler I/O threads. It is not 25 percent of the whole machine.

A client chooses its own `client.id`; use authenticated-user quotas as the primary boundary. Inspect more-specific user/client quotas and user/default-client overrides, which take precedence over a user-only quota. See [setting quotas](https://kafka.apache.org/43/operations/basic-kafka-operations/) and [quota grouping, precedence, and enforcement](https://kafka.apache.org/43/design/design/).

In broker `server.properties`:

```properties
listener.name.client.max.connections=500
listener.name.client.max.connection.creation.rate=50
```

The first limit bounds simultaneous client connections; the second bounds new connections per second. They act on connection pressure before a client has necessarily authenticated. Keep replication on its separate listener. Kafka 4.3 supports these listener-specific limits; inter-broker connections have documented exceptions to broker-wide limits. These controls supplement network filtering and do not prevent upstream network saturation. See the [connection-limit configuration reference](https://kafka.apache.org/43/configuration/broker-configs/).

For a tenant that is separately authorized to create, delete, or alter topics, an additional conditional quota is:

```bash
bin/kafka-configs.sh --bootstrap-server kafka.example.com:9093 \
  --command-config admin.properties \
  --alter --entity-type users --entity-name topic-provisioner \
  --add-config 'controller_mutation_rate=10'
```

This bounds partition mutations, not ordinary message throughput, and does not grant topic-management permissions. See [multi-tenancy quotas and rate limiting](https://kafka.apache.org/43/operations/multi-tenancy/).

## 6. Retain authorization decisions

Authentication failures and authorization denials need an operational record. Kafka provides authorizer logging; it is not a complete audit trail of every administrative change or message. Authentication failures occur before authorization and need separate collection from the normal broker/controller logs.

In the distribution's `config/log4j2.yaml`, replace the existing `kafka.authorizer.logger` entry under `Configuration.Loggers.Logger` with the following, matching the surrounding indentation. Retain the existing `AuthorizerAppender`:

```yaml
- name: kafka.authorizer.logger
  level: DEBUG
  additivity: false
  AppenderRef:
    ref: AuthorizerAppender
```

Collect `kafka-authorizer.log` from brokers and controllers, alongside their normal server logs. Protect the collector and retention policy independently of broker access. Estimate logging volume before enabling allowed-access records.

Kafka 4.0 migrated to Log4j2; do not paste legacy `log4j.logger...` syntax into its YAML configuration. The tagged 4.3.0 distribution defines this logger, appender, and filename.

`StandardAuthorizer` logs explicitly requested denials at INFO and allowed access at DEBUG when the corresponding audit flag is set. Some filtering and introspection decisions use TRACE instead. DEBUG therefore does not mean every authorization evaluation.

The manual does not document this logger's full configuration. This recipe is additionally checked against the [tagged logging configuration](https://github.com/apache/kafka/blob/4.3.0/config/log4j2.yaml), [StandardAuthorizer's audit implementation](https://github.com/apache/kafka/blob/4.3.0/metadata/src/main/java/org/apache/kafka/metadata/authorizer/StandardAuthorizerData.java#L279-L308), and the [Action audit-logging API](https://kafka.apache.org/43/javadoc/org/apache/kafka/server/authorizer/Action.html). The migration is documented in [upgrading to Kafka 4.0](https://kafka.apache.org/43/getting-started/upgrade/).

## 7. Client side

Keep `client.properties` out of the repository ([secrets.md](secrets.md)), owned by the account that needs it, with mode 0600 established before writing secrets. Use separate copies as `orders-writer.properties` and `orders-reader.properties`, with the corresponding username and distinct password. Keep `admin.properties` separate from application deployments.

MFA: the Kafka protocol has no second-factor dialogue. `listener.name.client.ssl.client.auth=required` adds mutual TLS as a possession control for machine clients ([machine-auth.md](machine-auth.md)); the unprefixed `ssl.client.auth` applies only to `SSL` listeners, and Kafka warns when it is set without the prefix on a `SASL_SSL` broker. Each client then presents its own keystore as in the last three lines below. Human paths to brokers or a management UI go behind MFA per [mfa.md](mfa.md).

Example `orders-writer.properties`:

```properties
security.protocol=SASL_SSL
sasl.mechanism=SCRAM-SHA-512
sasl.jaas.config=org.apache.kafka.common.security.scram.ScramLoginModule required username="orders-writer" password="REPLACE_WITH_LONG_RANDOM_VALUE";
ssl.truststore.location=/var/private/ssl/client.truststore.jks
ssl.truststore.password=REPLACE_WITH_LONG_RANDOM_VALUE
# only when the listener requires client certificates
ssl.keystore.location=/var/private/ssl/client.keystore.jks
ssl.keystore.password=REPLACE_WITH_LONG_RANDOM_VALUE
ssl.key.password=REPLACE_WITH_LONG_RANDOM_VALUE
```

For the reader, change the username to `orders-reader` and use its password. For the administrator, use `admin` and its password. Omit the optional keystore lines when client certificates are not required. Leave hostname verification enabled.

The commands below use Kafka 4.3's `--command-config` option, including on the console producer and consumer. Older distributions may use different client-file flags; use the CLI shipped with the documented version.

## 8. Redpanda (and other Kafka-API-compatible systems)

Redpanda implements the Kafka wire protocol, so the client-side and protocol-level controls above carry over: SASL/SCRAM authentication, TLS, and ACL management through the Kafka API all work the same way against a Redpanda cluster, and the same fronting rules apply too. What does not carry over is how you wire that up on the broker: Redpanda configures brokers through `redpanda.yaml` and the `rpk` CLI, not Kafka's `server.properties`, JAAS configuration files, or `kafka-storage.sh`. Redpanda Console, its bundled web UI, ships without its own login screen: it only gains one once you configure OIDC or basic authentication, and that built-in Console login requires an enterprise licence, so until you configure it anyone who reaches Console reaches the cluster behind it. Enabling the enterprise features without a valid licence does not open Console: it restricts access to a licence-expiration page instead. Front Console the same way as any other admin panel: never public, reached through SSH forwarding, a tailnet, or an access proxy, with MFA at that layer. See the [Redpanda security documentation](https://docs.redpanda.com/streaming/current/manage/security/).

Check Redpanda's own references for listener separation, quotas, and logging; the Kafka server configuration additions above are not Redpanda configuration.

## Verify

REASONED: Service-comparison prerequisites and overall scope; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no Kafka broker or KRaft controller deployment, deployed node certificates, provisioned client principals, external test hosts, quota metrics or collected broker/controller logs. The locally executed stub, parser and certificate checks below do not demonstrate deployment exposure. The bash -n, ShellCheck, guard, stub and fixture-log runs below of the ten guarded blocks used an earlier form of those blocks, whose placeholder refusal arm left each subshell with status 0 and whose paste and value-count refusals exited with status 1. Those runs did not cover the current form, whose placeholder, paste and value-count refusals leave each subshell with status 2 and which the gate suite's bash -n and ShellCheck 0.11.0 passes cover. That earlier form also exited with status 1 after a failed control, check or cleanup that was not a finding, and its three blocks with temporary ACLs or topics stopped before their cleanup; the current form exits with status 3 after such a failure, and those three blocks run their cleanup before they exit. The marker round-trip, deny-by-default and topic-creation blocks changed again after those runs: every ACL removal now passes `--force`, the deny-by-default block removes its temporary topic ACL outside its probes whatever the positive control reports, and the topic-creation cleanup message changed; those runs did not cover that current form either. The listener-inventory and client TLS block changed again after those runs: it now checks `command -v ss` before running `ss -tlnp` and refuses with status 2 when `ss` is not installed, so those runs covered an earlier form of it, and its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs. Expect exposed access and fixed enforcement as specified by each check, per the guide's cited Kafka security overview (Kafka 4.3 documentation).
This guide has not been demonstrated against a running Kafka cluster. The service checks below are **REASONED**: a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available; the authoring environment therefore has no Kafka broker or KRaft controller deployment, deployed node certificates, provisioned client principals, external test hosts, quota metrics or collected broker/controller logs. These missing capabilities prevent the exposed/fixed service comparisons here.

REASONED: exit status meanings, per CONTRIBUTING.md rule 6. A block that sets its exit status uses 0 for a pass, or for an observation the block cannot classify and says so; 1 for a finding; 2 for a guard refusal; and 3 for a failed or inconclusive check.

REASONED: Historical local-run narrative; live Kafka comparisons require a Kafka broker or KRaft controller deployment, which opens listeners; the authoring host forbids that without an isolated network namespace, and none was available during marking review (October 2026). The original runs and tagged-parser comparison are not independently authenticated by this review. Local runs during marking review (October 2026) gave empty successful bash -n and ShellCheck 0.11.0 output for all ten Verify shell blocks, YAML OK, eleven properties lexical OK results and metadata JSON OK; six unsafe inputs per block printed not probing without stub calls. Substituted inputs reached stubs for service commands and grep over fixture logs for the logging block. The marking-review bash -n, ShellCheck, guard, stub and fixture-log runs of the ten guarded blocks used an earlier form of those blocks, whose placeholder refusal arm left each subshell with status 0 and whose paste and value-count refusals exited with status 1. Those runs did not cover the current form, whose placeholder, paste and value-count refusals leave each subshell with status 2 and which the gate suite's bash -n and ShellCheck 0.11.0 passes cover. That earlier form also exited with status 1 after a failed control, check or cleanup that was not a finding, and its three blocks with temporary ACLs or topics stopped before their cleanup; the current form exits with status 3 after such a failure, and those three blocks run their cleanup before they exit. The marker round-trip, deny-by-default and topic-creation blocks changed again after those runs: every ACL removal now passes `--force`, the deny-by-default block removes its temporary topic ACL outside its probes whatever the positive control reports, and the topic-creation cleanup message changed; those runs did not cover that current form either. The listener-inventory and client TLS block changed again after those runs: it now checks `command -v ss` before running `ss -tlnp` and refuses with status 2 when `ss` is not installed, so those runs covered an earlier form of it, and its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs. No live enforcement was observed; the service expectations remain source reasoning per the guide's cited Kafka security overview (Kafka 4.3 documentation).
Locally, the shell blocks passed `bash -n`, ShellCheck, and the repository's guard-convention scanner. YAML parsing, properties lexical checks, and the bracket-free SCRAM value's match against the tagged parser expression were checked. For each of the ten guarded blocks, six unsafe inputs were exercised: the original placeholder, an embedded placeholder, each angle bracket, an `example.com` hostname, and an empty value. All rejected without executing a probe. Isolated positive controls confirmed that a substituted value reaches each guard's intended arm. These are bounded local results, not a claim of aggregate bypass resistance or Kafka enforcement. The shell-block runs recorded in this paragraph, in marking review and in the original local pass, used an earlier form of the ten guarded blocks, whose placeholder refusal arm left each subshell with status 0 and whose paste and value-count refusals exited with status 1. Those runs did not cover the current form, whose placeholder, paste and value-count refusals leave each subshell with status 2 and which the gate suite's bash -n and ShellCheck 0.11.0 passes cover. That earlier form also exited with status 1 after a failed control, check or cleanup that was not a finding, and its three blocks with temporary ACLs or topics stopped before their cleanup; the current form exits with status 3 after such a failure, and those three blocks run their cleanup before they exit. The marker round-trip, deny-by-default and topic-creation blocks changed again after those runs: every ACL removal now passes `--force`, the deny-by-default block removes its temporary topic ACL outside its probes whatever the positive control reports, and the topic-creation cleanup message changed; those runs did not cover that current form either. If the original local pass also covered the step 3 cluster ID block and the step 4 grant removals, it covered earlier forms of both: the cluster ID block now formats storage inside an `if` instead of ending with `|| exit 1`, the grant removals now pass `--force`, and that pass did not cover either current form, which the gate suite's bash -n and ShellCheck 0.11.0 passes cover. The listener-inventory and client TLS block changed again after every run recorded in this paragraph: it now checks `command -v ss` before running `ss -tlnp` and refuses with status 2 when `ss` is not installed, so those runs covered an earlier form of it, and its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs.

REASONED: Whole-block substitution and network vantage; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available; the authoring environment therefore has no Kafka node network namespaces or second host for public IPv4/IPv6 and allowed/disallowed network comparisons. All ten blocks passed syntax/lint; six unsafe inputs printed not probing without stub calls, and wrong marker or value count exited 1. Those runs used an earlier form of the ten blocks, whose placeholder refusal arm left each subshell with status 0 and whose paste and value-count refusals exited with status 1. Those runs did not cover the current form, whose placeholder, paste and value-count refusals leave each subshell with status 2 and which the gate suite's bash -n and ShellCheck 0.11.0 passes cover. That earlier form also exited with status 1 after a failed control, check or cleanup that was not a finding, and its three blocks with temporary ACLs or topics stopped before their cleanup; the current form exits with status 3 after such a failure, and those three blocks run their cleanup before they exit. The marker round-trip, deny-by-default and topic-creation blocks changed again after those runs: every ACL removal now passes `--force`, the deny-by-default block removes its temporary topic ACL outside its probes whatever the positive control reports, and the topic-creation cleanup message changed; those runs did not cover that current form either. The listener-inventory and client TLS block changed again after those runs: it now checks `command -v ss` before running `ss -tlnp` and refuses with status 2 when `ss` is not installed, so those runs covered an earlier form of it, and its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs. Expect exposed reachability versus blocked unauthorized paths with working authorized controls, per the guide's cited Listener configuration (controller listener, combined-node requirement, protocol map) (Kafka 4.3 documentation).
Substitute inside the single quotes and paste each whole block. A literal apostrophe requires proper shell escaping. Run external checks from another host over the actual public IPv4 and IPv6 paths; run the listener inventory in each Kafka node's network namespace.

REASONED: Disposable topics, credentials, diagnostics and cleanup; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no isolated Kafka deployment with an orders topic fixture, provisioned administrator/writer/reader credentials and ACLs, or live topic and ACL administration endpoint. Local syntax/lint and guard checks passed; lifecycle stubs printed positive control OK, topic deny-by-default observed and application creation denied; early failure paths printed findings requiring manual cleanup. Those syntax/lint, guard and stub runs used an earlier form of the guarded blocks, whose placeholder refusal arm left each subshell with status 0 and whose paste and value-count refusals exited with status 1. Those runs did not cover the current form, whose placeholder, paste and value-count refusals leave each subshell with status 2 and which the gate suite's bash -n and ShellCheck 0.11.0 passes cover. That earlier form also exited with status 1 after a failed control, check or cleanup that was not a finding, and its three blocks with temporary ACLs or topics stopped before their cleanup; the current form exits with status 3 after such a failure, and those three blocks run their cleanup before they exit. The marker round-trip, deny-by-default and topic-creation blocks changed again after those runs: every ACL removal now passes `--force`, the deny-by-default block removes its temporary topic ACL outside its probes whatever the positive control reports, and the topic-creation cleanup message changed; those runs did not cover that current form either. The listener-inventory and client TLS block changed again after those runs: it now checks `command -v ss` before running `ss -tlnp` and refuses with status 2 when `ss` is not installed, so those runs covered an earlier form of it, and its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs. Expect exposed unauthorized operations versus fixed denials with successful administrator controls, per the guide's cited Basic Kafka operations, topic administration, and quota commands (Kafka 4.3 documentation).
Use an isolated test deployment with an administratively created `orders` fixture for commands that produce records or create topics. Provision the named credentials and ACLs first. The single-replica temporary topics below are disposable test fixtures, not a production replication recommendation. Keep diagnostics private. If a block reports a failure or stops early, remove any of its temporary ACLs and topics that remain, using the printed names.

### Listener inventory and client TLS

**REASONED:** No Kafka node namespace, deployed certificate, or external network vantage is available here. On an exposed deployment, the inventory can show a plaintext or publicly bound internal listener. The fixed inventory should show client 9093, private broker-internal 9095, and private controller 9094 only where their roles require them. `ss` is an inventory in this namespace, not proof of firewall enforcement.

REASONED: Optional client-certificate and encrypted-key handling; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no deployed Kafka client listener or deployed client certificate credentials (distinct from the synthetic fixture generated in the review) for comparing optional and required client authentication. Local OpenSSL generated an encrypted fixture key and certificate; file-based password loading printed Key is valid, while matching/wrong hostname checks printed OK/hostname mismatch. Expect an exposed optional-client-cert listener to accept missing credentials and a fixed required-cert listener to reject them while accepting valid credentials, per the guide's cited Encryption and authentication using SSL (Kafka 4.3 documentation) and the guide's cited OpenSSL file-based private-key passphrases.
The probe below matches the default client listener above, which does not require client certificates. If setting `listener.name.client.ssl.client.auth=required`, add the client's `-cert` and `-key`, and use `-pass file:client-key.pass` for an encrypted key. Protect that password file. `Verification: OK` alone does not prove the broker accepted the client certificate; it can appear before the server rejects the connection.

REASONED: following block; inventory and hostname/chain verification; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no Kafka node network namespace, deployed broker certificate and its CA trust material, or external client host. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. Stub inventory and TLS printed STUB LISTEN and STUB TLS; local OpenSSL verification printed OK for the matching hostname and hostname mismatch for the wrong one. The bash -n, ShellCheck, guard and stub runs recorded here covered the listener-inventory and client TLS block in an earlier form, whose placeholder refusal arm left the subshell with status 0, whose paste and value-count refusals exited with status 1 and which ran `ss` without first checking that it is installed. Its current form leaves the subshell with status 2 on a placeholder, paste or value-count refusal and when `ss` is not installed, which it checks with `command -v ss` before any probe, so a missing `ss` also skips the TLS check; it is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs with `ss` present and passing, present and failing, and missing. That earlier form also exited with status 1 after a failed listener inventory or TLS check, where the current form exits with status 3. Expect exposed plaintext/public internal listeners versus private role-specific listeners and verified client TLS, per the guide's cited Encryption and authentication using SSL (Kafka 4.3 documentation), Listener configuration (controller listener, combined-node requirement, protocol map) (Kafka 4.3 documentation), and OpenSSL s_client certificate and hostname verification.
The client TLS positive control must validate the broker hostname and certificate chain. A plaintext endpoint cannot complete this TLS exchange. A certificate error is a TLS defect; a DNS or local failure is inconclusive. Sources: [listener configuration](https://kafka.apache.org/43/security/listener-configuration/), [Kafka SSL](https://kafka.apache.org/43/security/encryption-and-authentication-using-ssl/), and [OpenSSL s_client](https://docs.openssl.org/3.5/man1/openssl-s_client/). Point `ca.pem` at the CA that signed the broker certificate. Omit `-CAfile` only when using an appropriate public CA already trusted by OpenSSL. Without the verification flags, a completed handshake shows only that TLS is present.

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_HOST'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one broker hostname; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the broker hostname; not probing"; exit 2 ;;
    *)
      command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
      ss -tlnp || { echo "listener inventory failed"; exit 3; }
      openssl s_client -connect "$1:9093" -servername "$1" \
        -verify_hostname "$1" -verify_return_error -CAfile ca.pem </dev/null \
        || { echo "TLS check failed; inspect the diagnostic"; exit 3; }
      ;;
  esac
)
```

### Internal mutual TLS and network isolation

**REASONED:** No private broker listener, deployed certificates, or allowed/disallowed network vantage is available here. Prepare `internal-no-cert.properties` from `bootstrap-admin.properties` with all client keystore/key settings removed. Prepare `internal-untrusted-cert.properties` with an otherwise valid client certificate signed by a CA the broker does not trust; retain the correct server truststore.

REASONED: following block; internal certificate controls and network isolation; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no private Kafka broker listener, deployed administrator certificate credentials and untrusted-client test credentials, allowed/disallowed network hosts or collected broker logs. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. Stubs printed the TLS rejection inspection messages for missing/untrusted certificates and FINDING for accepted missing certificates. The bash -n, ShellCheck, guard and stub runs recorded here covered the internal mutual TLS block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after a failed valid-certificate control, where the current form exits with status 3. Expect valid private access, TLS rejection of missing/untrusted certificates and blocked disallowed paths after fixing, versus acceptance or reachability when exposed, per the guide's cited Encryption and authentication using SSL (Kafka 4.3 documentation).
On the same allowed private path, the valid administrator certificate must permit the positive Kafka control. Missing and untrusted client certificates must fail at TLS. With client-certificate enforcement absent, the TLS handshake may succeed even if the authorizer subsequently rejects an anonymous principal; an authorization failure is not proof of mutual TLS. Inspect the TLS diagnostic and broker logs. Source: [Kafka SSL client authentication](https://kafka.apache.org/43/security/encryption-and-authentication-using-ssl/).
Repeat the valid-certificate control from a network that must not reach `INTERNAL`. The exposed state is reachable from that network; the fixed state blocks it while the allowed-network control still works. Correlate blocked attempts with network policy evidence: a timeout alone cannot distinguish filtering from a broken route.

```bash
# Internal mutual TLS; no live Kafka cluster, deployed broker certificates or deployed client credentials (distinct from synthetic certificate fixtures) or external test hosts. Expected outcomes are per the guide's cited Encryption and authentication using SSL (Kafka 4.3 documentation).
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_INTERNAL_BROKER_HOST:9095'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one broker endpoint; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the broker endpoint; not probing"; exit 2 ;;
    *)
      bin/kafka-broker-api-versions.sh --bootstrap-server "$1" \
        --command-config bootstrap-admin.properties \
        || { echo "valid internal mTLS control failed"; exit 3; }
      if bin/kafka-broker-api-versions.sh --bootstrap-server "$1" \
        --command-config internal-no-cert.properties; then
        echo "FINDING: internal Kafka access without a client certificate"
        exit 1
      else
        echo "Inspect for a TLS client-certificate rejection; other failures are inconclusive"
      fi
      if bin/kafka-broker-api-versions.sh --bootstrap-server "$1" \
        --command-config internal-untrusted-cert.properties; then
        echo "FINDING: internal Kafka access with an untrusted client certificate"
        exit 1
      else
        echo "Inspect for a TLS trust rejection; other failures are inconclusive"
      fi
      ;;
  esac
)
```

**REASONED:** No controller listener, deployed node certificate, or controller logs are available here. Test each controller with a valid node certificate, then without a certificate. Fixed TLS must accept the valid certificate and reject the missing one; an exposed listener without client-certificate enforcement can complete both handshakes. Source: [controller listeners](https://kafka.apache.org/43/security/listener-configuration/) and [OpenSSL verification](https://docs.openssl.org/3.5/man1/openssl-s_client/).

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_CONTROLLER_HOST'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one controller hostname; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the controller hostname; not probing"; exit 2 ;;
    *)
      openssl s_client -connect "$1:9094" -servername "$1" \
        -verify_hostname "$1" -verify_return_error -CAfile ca.pem \
        -cert node.crt -key node.key -pass file:node-key.pass </dev/null \
        || { echo "node-certificate TLS control failed"; exit 3; }
      if openssl s_client -connect "$1:9094" -servername "$1" \
        -verify_hostname "$1" -verify_return_error -CAfile ca.pem </dev/null; then
        echo "No-certificate result needs TLS alert and controller-log inspection"
      else
        echo "Inspect for a missing-client-certificate TLS alert"
      fi
      ;;
  esac
)
```

REASONED: preceding block; controller valid/missing/untrusted certificates, network isolation and quorum limitations; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no KRaft controller deployment, deployed node certificate credentials and untrusted-node test credentials, allowed/disallowed network hosts or collected controller logs. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. Stub exchanges printed Inspect for a missing-client-certificate TLS alert or No-certificate result needs TLS alert and controller-log inspection; a failed positive control stopped. The bash -n, ShellCheck, guard and stub runs recorded here covered the controller TLS block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after a failed node-certificate control, where the current form exits with status 3. Local encrypted-key and hostname checks passed/rejected as intended. Expect exposed missing-cert acceptance versus fixed rejection with valid access; network and quorum health require live evidence, per the guide's cited Encryption and authentication using SSL (Kafka 4.3 documentation) and the guide's cited KRaft provisioning / storage formatting (`--standalone`, cluster ID reuse) (Kafka 4.3 documentation).
Also repeat with an untrusted node certificate and from disallowed networks. Inspect the full exchange and server logs; `s_client` status and server-certificate verification alone are insufficient evidence of client acceptance. Successful TLS does not demonstrate quorum or replication health. Those comparisons remain REASONED from the cited Kafka TLS and quorum documentation, not observed here.

### Plaintext refusal and wrong-password rejection

REASONED: Plaintext client fixture; local INI parsing returned exactly security.protocol=PLAINTEXT. Live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available; the authoring environment therefore has no Kafka broker endpoint for comparing plaintext service with a fixed SASL_SSL listener. Expect exposed plaintext service to answer and fixed SASL_SSL to refuse this fixture, per the guide's cited Encryption and authentication using SSL (Kafka 4.3 documentation).
Create `plain.properties` containing only:

REASONED: plaintext client fixture; no deployed Kafka broker endpoint is available to serve or refuse this plaintext fixture. Local parsing returned security.protocol=PLAINTEXT; expect exposed plaintext access versus fixed plaintext refusal. Expected outcomes are per the guide's cited Encryption and authentication using SSL (Kafka 4.3 documentation).

```properties
security.protocol=PLAINTEXT
```

**REASONED:** following block; no live broker or external client host is available here. Create `wrong.properties` from `orders-reader.properties`, changing only its password to a deliberately incorrect value. Use a seeded `orders` fixture with records available at the `app-workers` group's current offsets for the matched authenticated consumer control. A local fixture comparison confirmed that only the reader JAAS password changed. The authenticated control must work first. A plaintext Kafka service would answer the plaintext tool; the fixed `SASL_SSL` listener must not serve it. The wrong-password consumer must report `SaslAuthenticationException`; an empty result, timeout, group denial, DNS error, or local failure is not that result. Sources: [SASL/SCRAM](https://kafka.apache.org/43/security/authentication-using-sasl/), [broker API versions CLI](https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/BrokerApiVersionsCommand.java), and [console-consumer options](https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/consumer/ConsoleConsumerOptions.java).

REASONED: following block; authenticated controls, plaintext refusal and wrong-password diagnostics independent of consumer exit status; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no Kafka broker deployment, provisioned reader credentials and ACLs, seeded orders topic at readable app-workers offsets or external client host. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. A zero-exit stub with SaslAuthenticationException printed wrong password rejected at SASL authentication; returned records printed FINDING and unrelated errors printed not the expected authentication denial. The bash -n, ShellCheck, guard and stub runs recorded here covered the plaintext and wrong-password block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after a results-directory failure, a failed authenticated control or an unexpected denial, where the current form exits with status 3. Expect plaintext access when exposed and refusal when fixed, with valid consumers working and wrong credentials denied, per the guide's cited Console consumer exception logging and exit behavior, tagged 4.3.0; and Authentication using SASL (SCRAM) (Kafka 4.3 documentation).
Kafka 4.3.0's [ConsoleConsumer implementation](https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/consumer/ConsoleConsumer.java) catches and logs exceptions from `receive()` inside `process()`, then returns; only exceptions escaping to `main()` cause its explicit exit with status 1. A consumer's exit status therefore does not prove denial. Both consumer denial checks below inspect the specific exception in stderr, regardless of exit status; records returned by a denied probe are a finding.

```bash
# Plaintext refusal and password rejection; no live Kafka cluster, deployed broker certificates or deployed client credentials (distinct from synthetic certificate fixtures) or external test hosts. Expected outcomes are per the guide's cited Console consumer exception logging and exit behavior, tagged 4.3.0; and Authentication using SASL (SCRAM) (Kafka 4.3 documentation).
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_HOST:9093'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one broker endpoint; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the broker endpoint; not probing"; exit 2 ;;
    *)
      umask 077
      set -- "$1" "$(mktemp -d)"
      [ -d "$2" ] || { echo "cannot create private results directory"; exit 3; }
      printf 'Results: %s\n' "$2"
      bin/kafka-broker-api-versions.sh --bootstrap-server "$1" \
        --command-config orders-reader.properties \
        || { echo "authenticated positive control failed"; exit 3; }
      if bin/kafka-broker-api-versions.sh --bootstrap-server "$1" \
        --command-config plain.properties >"$2/plain.log" 2>&1; then
        echo "FINDING: plaintext Kafka is served"
        exit 1
      else
        echo "Plaintext failed; inspect plain.log and broker logs to exclude local, DNS and routing errors"
      fi
      bin/kafka-console-consumer.sh --bootstrap-server "$1" \
        --command-config orders-reader.properties --group app-workers \
        --topic orders --from-beginning --max-messages 1 --timeout-ms 10000 \
        >"$2/authenticated.out" 2>"$2/authenticated.log" \
        || { echo "authenticated consumer control failed; inspect authenticated.log"; exit 3; }
      [ -s "$2/authenticated.out" ] \
        || { echo "authenticated consumer returned no records; not probing denial"; exit 3; }
      bin/kafka-console-consumer.sh --bootstrap-server "$1" \
        --command-config wrong.properties --group app-workers \
        --topic orders --from-beginning --max-messages 1 --timeout-ms 10000 \
        >"$2/wrong.out" 2>"$2/wrong.log" \
        || printf 'Consumer exit=%s; checking wrong.log for the specific denial\n' "$?"
      if [ -s "$2/wrong.out" ]; then
        echo "FINDING: wrong-password consumer returned records"
        exit 1
      fi
      grep -F 'SaslAuthenticationException' "$2/wrong.log" >/dev/null \
        || { echo "not the expected authentication denial; inspect wrong.log"; exit 3; }
      echo "wrong password rejected at SASL authentication"
      ;;
  esac
)
```

### Marker round trip and split application permissions

**REASONED:** No live broker, test topic, or application identities are available here. The matched positive control produces a unique marker as the writer and reads that exact marker as the reader using a fresh consumer group. Then the same reader identity attempts a write. An overprivileged reader can write; the fixed reader receives `TopicAuthorizationException`.

REASONED: following block; marker delivery, reader-write denial and temporary group ACL cleanup; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no Kafka deployment with an orders topic fixture and provisioned writer, reader and administrator principals for marker delivery, write-denial and temporary group ACL checks. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. Stubs printed positive control OK and reader write denied at topic authorization; accepted writes printed FINDING. The bash -n, ShellCheck, guard and stub runs recorded here covered the marker round-trip block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after a failed control, an unexpected denial or a failed cleanup, and it stopped before removing its temporary group ACL, after a finding too; the current form exits with status 3 after such a failure and runs that cleanup before it exits. The current form's temporary group ACL removal also passes `--force`; the runs recorded here covered an earlier form without it, and the current form was not re-run. It also exited with status 1 when it could not create its private results directory, where the current form exits with status 3 before creating any broker fixture. Expect an exposed reader to write and a fixed reader to receive TopicAuthorizationException while the marker round trip succeeds, per the guide's cited Authorization and ACLs (`allow.everyone.if.no.acl.found`, resource-pattern-type) (Kafka 4.3 documentation). A stub consumer returning the marker with nonzero status still printed positive control OK; a mismatched marker printed marker missing. Idle-timeout semantics remain source reasoning per the guide's cited Console consumer exception logging and exit behavior, tagged 4.3.0.
Only the negative producer probe disables idempotence, so a producer-ID authorization check does not mask the topic-write check. This is a test override, not an application configuration recommendation. Sources: [ACL operations](https://kafka.apache.org/43/security/authorization-and-acls/), [producer configuration](https://kafka.apache.org/43/configuration/producer-configs/), and the tagged console-tool sources in Sources.
The consumer timeout is an idle timeout, not a wall-clock limit. Use a quiet test fixture. Receiving the exact marker proves that round trip even if the consumer subsequently exits on idle timeout; it does not turn unrelated errors into success. Preserve and inspect stderr separately.

```bash
# Writer/reader separation; no live Kafka cluster, deployed broker certificates or deployed client credentials (distinct from synthetic certificate fixtures) or external test hosts. Expected outcomes are per the guide's cited Authorization and ACLs (`allow.everyone.if.no.acl.found`, resource-pattern-type) (Kafka 4.3 documentation).
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_HOST:9093'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one broker endpoint; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the broker endpoint; not probing"; exit 2 ;;
    *)
      umask 077
      set -- "$1" "verify-$(date +%s)-$$" "$(mktemp -d)"
      [ -d "$3" ] || { echo "cannot create private results directory"; exit 3; }
      printf 'Results: %s\n' "$3"
      bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
        --add --allow-principal User:orders-reader --operation Read \
        --group "$2" --resource-pattern-type prefixed \
        || { echo "temporary group ACL failed"; exit 3; }
      # The probes run in a nested subshell, so the cleanup below runs whatever they report.
      (
        printf '%s\n' "$2" | bin/kafka-console-producer.sh \
          --bootstrap-server "$1" --command-config orders-writer.properties \
          --topic orders --sync \
          || { echo "writer positive control failed"; exit 3; }
        if bin/kafka-console-consumer.sh --bootstrap-server "$1" \
          --command-config orders-reader.properties --group "$2" --topic orders \
          --from-beginning --timeout-ms 15000 >"$3/records" 2>"$3/consumer.log"; then
          echo "consumer exited normally"
        else
          echo "Consumer exited nonzero; inspect consumer.log, including any idle timeout"
        fi
        grep -Fx -- "$2" "$3/records" >/dev/null \
          || { echo "marker missing: positive control FAILED or inconclusive"; exit 3; }
        echo "positive control OK: exact marker received"
        if printf '%s\n' "$2-denied" | bin/kafka-console-producer.sh \
          --bootstrap-server "$1" --command-config orders-reader.properties \
          --command-property enable.idempotence=false \
          --topic orders --sync >"$3/reader-write.log" 2>&1; then
          echo "FINDING: reader produced a record"
          exit 1
        else
          grep -F 'TopicAuthorizationException' "$3/reader-write.log" >/dev/null \
            || { echo "not the expected topic denial; inspect reader-write.log"; exit 3; }
          echo "reader write denied at topic authorization"
        fi
      ) || set -- "$@" "$?"
      bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
        --remove --force --allow-principal User:orders-reader --operation Read \
        --group "$2" --resource-pattern-type prefixed \
        || { echo "remove the temporary group ACL manually"; set -- "$@" 3; }
      # Status: 1 after a finding; otherwise 3 after a failed control, check or cleanup; otherwise 0.
      case "${4-}" in 1) exit 1 ;; ?*) exit 3 ;; esac
      ;;
  esac
)
```

### Topic deny-by-default with an authenticated low-privilege user

REASONED: Low-user credential and privilege preconditions; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no Kafka deployment with a provisioned low-user SCRAM principal, inspectable effective privileges and administrator credentials for temporary topic and ACL lifecycle checks. The local deny-by-default block passed syntax/lint and guards; stubs printed topic deny-by-default observed or FINDING for unauthorized marker delivery. Those syntax/lint, guard and stub runs covered the deny-by-default block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after a failed control, an unconfirmed ACL precondition, an unexpected denial or a failed cleanup, and it stopped before removing its temporary group ACL and topic, after a finding too; the current form exits with status 2 for a declined ACL confirmation and with status 3 after the other failures, and runs that cleanup before it exits. The current form also passes `--force` to both ACL removals, removes its temporary topic ACL outside its probes whatever the positive control reports, and runs its denial probe only after that removal succeeds; the runs recorded here covered an earlier form, and the current form was not re-run. It also exited with status 1 when it could not create its private results directory, where the current form exits with status 3 before creating any broker fixture. Actual SCRAM provisioning and absence of super-user/other grants were not observed. Expect a valid low user to read under the temporary grant and be denied after removal in the fixed state, per the guide's cited Authorization and ACLs (`allow.everyone.if.no.acl.found`, resource-pattern-type) (Kafka 4.3 documentation).
Provision `low` through the same restricted-file SCRAM procedure as step 3. Its `low.properties` uses its own valid credential. It must not be a super user or have other grants.

**REASONED:** No live authorizer, low-privilege identity, or seeded topic is available here. This block creates and seeds a real temporary topic, grants `low` a fresh group prefix and a temporary topic `Read`, and proves that `low` receives the marker. It then removes only the topic permission and checks the same topic with a fresh group. That removal runs outside the nested subshells, so it also runs when seeding, a grant or the positive control fails, and the denial check runs only after the positive control and the removal succeed. Kafka 4.3.0's AclCommand passes a removal to the Admin API's `deleteAcls` without first checking for a matching ACL, and an exception from that call reaches the handler in its `main`, which exits with status 1 ([removal](https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/AclCommand.java#L182-L189), [error exit](https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/AclCommand.java#L84-L88)). Whether the broker's reply to a removal that matches nothing raises such an exception is outside that file. A clean run removes the topic permission only once, while it exists, so an ACL that is already gone cannot turn a clean run into status 3; when no ACL matches because an earlier step failed, the run already has status 3.

REASONED: following block; temporary topic creation/seeding, low-user positive control, ACL removal/inspection, denial and cleanup; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no Kafka deployment with a provisioned low-user SCRAM principal, inspectable effective privileges and administrator credentials for temporary topic and ACL lifecycle checks. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. Stubs printed topic deny-by-default observed for the fixed response and FINDING for unauthorized marker delivery. The bash -n, ShellCheck, guard and stub runs recorded here covered the deny-by-default block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after a failed control, an unconfirmed ACL precondition, an unexpected denial or a failed cleanup, and it stopped before removing its temporary group ACL and topic, after a finding too; the current form exits with status 2 for a declined ACL confirmation and with status 3 after the other failures, and runs that cleanup before it exits. The current form also passes `--force` to both ACL removals, removes its temporary topic ACL outside its probes whatever the positive control reports, and runs its denial probe only after that removal succeeds; the runs recorded here covered an earlier form, and the current form was not re-run. The current form also exits with status 2, not 3, for a declined ACL confirmation, and its closing `case` carries that status: a finding (1) outranks a failed cleanup (3), which outranks a decline (2). A stub run for this change, with Bash 5.3.9 and stub Kafka commands (no broker, no listener), exited 2 for a declined confirmation, 3 for a declined confirmation with a failed group ACL removal, 1 for a finding with a failed group ACL removal, 3 for ended input and 0 for an observed denial. That stub run observed no Kafka behaviour, and the earlier forms of the declined-confirmation arm (status 1 in the runs recorded above, status 3 just before this change) were not re-run. It also exited with status 1 when it could not create its private results directory, where the current form exits with status 3 before creating any broker fixture. Expect exposed marker access versus TopicAuthorizationException without a matching topic ACL, per the guide's cited Authorization and ACLs (`allow.everyone.if.no.acl.found`, resource-pattern-type) (Kafka 4.3 documentation). Effective configuration attribution and absence of wildcard/prefix grants still require live inspection.
After ACL propagation, the fixed state must report `TopicAuthorizationException`. In an isolated exposed configuration with no matching topic ACL and `allow.everyone.if.no.acl.found=true`, the marker can be read. A group error tests the wrong boundary. Empty output, offsets, and timeouts remain inconclusive. Source: [behavior without ACLs and matching resource patterns](https://kafka.apache.org/43/security/authorization-and-acls/).
The ACL inspection must show no literal, wildcard, or prefix match for the temporary topic. Do not remove unrelated production ACLs to manufacture that condition. Run the comparison in an isolated fixture. A successful unauthorized read is a finding, but attributing it specifically to `allow.everyone.if.no.acl.found` also requires checking the effective authorizer configuration.

```bash
# Deny-by-default ACLs; no live Kafka cluster, deployed broker certificates or deployed client credentials (distinct from synthetic certificate fixtures) or external test hosts. Expected outcomes are per the guide's cited Authorization and ACLs (`allow.everyone.if.no.acl.found`, resource-pattern-type) (Kafka 4.3 documentation).
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_HOST:9093'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one broker endpoint; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the broker endpoint; not probing"; exit 2 ;;
    *)
      umask 077
      set -- "$1" "verify-deny-$(date +%s)-$$" "$(mktemp -d)"
      [ -d "$3" ] || { echo "cannot create private results directory"; exit 3; }
      printf 'Test topic/group: %s; results: %s\n' "$2" "$3"
      bin/kafka-topics.sh --bootstrap-server "$1" --command-config admin.properties \
        --create --topic "$2" --partitions 1 --replication-factor 1 \
        || { echo "isolated test-topic creation failed"; exit 3; }
      # The grants and positive control run in a nested subshell, so the topic ACL removal below runs whatever they report.
      (
        printf '%s\n' "$2" | bin/kafka-console-producer.sh \
          --bootstrap-server "$1" --command-config admin.properties --topic "$2" --sync \
          || { echo "seeding the test topic failed"; exit 3; }
        bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
          --add --allow-principal User:low --operation Read \
          --group "$2" --resource-pattern-type prefixed \
          || { echo "low user's group ACL failed"; exit 3; }
        bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
          --add --allow-principal User:low --operation Read \
          --topic "$2" --resource-pattern-type literal \
          || { echo "temporary positive-control topic ACL failed"; exit 3; }
        bin/kafka-console-consumer.sh --bootstrap-server "$1" \
          --command-config low.properties --group "$2-positive" --topic "$2" \
          --from-beginning --max-messages 1 --timeout-ms 10000 \
          >"$3/positive" 2>"$3/positive.log" \
          || { echo "low-user positive control failed"; exit 3; }
        grep -Fx -- "$2" "$3/positive" >/dev/null \
          || { echo "low-user positive marker missing"; exit 3; }
      ) || set -- "$@" "$?"
      bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
        --remove --force --allow-principal User:low --operation Read \
        --topic "$2" --resource-pattern-type literal \
        || { echo "temporary topic ACL removal failed; remove it manually if it remains"; set -- "$@" 3; }
      # The denial probe runs only after a clean positive control and topic ACL removal.
      if [ "$#" -eq 3 ]; then
        (
          bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
            --list --topic "$2" --resource-pattern-type match \
            || { echo "matching ACL inspection failed"; exit 3; }
          printf 'Type NO_TOPIC_ACLS only after confirming no matching topic ACL remains: '
          read -r REPLY || { echo "ACL confirmation unavailable"; exit 3; }
          [ "$REPLY" = NO_TOPIC_ACLS ] || { echo "ACL precondition not confirmed"; exit 2; }
          bin/kafka-console-consumer.sh --bootstrap-server "$1" \
            --command-config low.properties --group "$2-negative" --topic "$2" \
            --from-beginning --max-messages 1 --timeout-ms 10000 \
            >"$3/negative" 2>"$3/negative.log" \
            || printf 'Consumer exit=%s; checking negative.log for the specific denial\n' "$?"
          if grep -Fx -- "$2" "$3/negative" >/dev/null; then
            echo "FINDING: low user read the marker without a matching topic ACL"
            exit 1
          fi
          if [ -s "$3/negative" ]; then
            echo "FINDING: low user returned records without a matching topic ACL"
            exit 1
          fi
          grep -F 'TopicAuthorizationException' "$3/negative.log" >/dev/null \
            || { echo "not the expected topic denial; inspect negative.log"; exit 3; }
          echo "topic deny-by-default observed"
        ) || set -- "$@" "$?"
      fi
      bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
        --remove --force --allow-principal User:low --operation Read \
        --group "$2" --resource-pattern-type prefixed \
        || { echo "remove the temporary group ACL manually if it remains"; set -- "$@" 3; }
      bin/kafka-topics.sh --bootstrap-server "$1" --command-config admin.properties \
        --delete --topic "$2" || { echo "remove the test topic manually"; set -- "$@" 3; }
      # Status: 1 after a finding; otherwise 3 after a failed control, check or cleanup; otherwise 2 after a declined ACL confirmation; otherwise 0.
      case "${4-}" in 1) exit 1 ;; 2) [ "$#" -eq 4 ] && exit 2; exit 3 ;; ?*) exit 3 ;; esac
      ;;
  esac
)
```

### Application topic creation

REASONED: following block; writer and reader creation denial, administrator control, cleanup and old literal grants; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no Kafka deployment with provisioned writer, reader and administrator principals and inspectable topic-creation ACLs. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. Both identity variants printed application creation denied; matching admin creation succeeded for denial stubs and FINDING: application created a topic for accepting stubs. The bash -n, ShellCheck, guard and stub runs recorded here covered the topic-creation block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after an unexpected denial, a failed administrator control or a failed cleanup, and it stopped before deleting its test topic, after a finding too; the current form exits with status 3 after such a failure and deletes the test topic before it exits. The current form's failed-deletion message also asks for manual removal only if the test topic remains; the runs recorded here covered an earlier form, and the current form was not re-run. It also exited with status 1 when it could not create its private results directory, where the current form exits with status 3 before creating any broker fixture. Expect exposed application creation versus fixed denial with administrator success; old literal grants still require inspection, per the guide's cited Authorization and ACLs (`allow.everyone.if.no.acl.found`, resource-pattern-type) (Kafka 4.3 documentation) and the guide's cited Basic Kafka operations, topic administration, and quota commands (Kafka 4.3 documentation).
No live cluster with the application roles is available here. First complete the writer/reader marker control above. An overprivileged writer can create a new topic; the fixed writer must receive a topic authorization denial, while the administrator can create that same topic. This tests explicit creation rights independently of automatic creation. After an unexpected creation denial or a failed administrator control, the test topic may not exist, but the cleanup still tries to delete it, because a client can fail after the broker has created a topic. That run already has status 3, so a failed deletion of a missing topic cannot change the status; a clean run or a finding always leaves a topic to delete. Sources: [ACL protocol operations](https://kafka.apache.org/43/security/authorization-and-acls/) and [topic administration](https://kafka.apache.org/43/operations/basic-kafka-operations/). Repeat for the reader identity. This new-name probe must be combined with ACL inspection: an old literal `Create` grant on `orders` could permit recreating `orders` while still denying the new test name.

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_HOST:9093'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one broker endpoint; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the broker endpoint; not probing"; exit 2 ;;
    *)
      umask 077
      set -- "$1" "verify-create-$(date +%s)-$$" "$(mktemp -d)"
      [ -d "$3" ] || { echo "cannot create private results directory"; exit 3; }
      printf 'Test topic: %s; results: %s\n' "$2" "$3"
      # The probes run in a nested subshell, so the cleanup below runs whatever they report.
      (
        if bin/kafka-topics.sh --bootstrap-server "$1" \
          --command-config orders-writer.properties \
          --create --topic "$2" --partitions 1 --replication-factor 1 \
          >"$3/create.log" 2>&1; then
          echo "FINDING: application created a topic"
          exit 1
        else
          grep -F 'TopicAuthorizationException' "$3/create.log" >/dev/null \
            || { echo "not the expected creation denial; inspect create.log"; exit 3; }
        fi
        bin/kafka-topics.sh --bootstrap-server "$1" --command-config admin.properties \
          --create --topic "$2" --partitions 1 --replication-factor 1 \
          || { echo "admin creation control failed"; exit 3; }
        echo "application creation denied; matching admin creation succeeded"
      ) || set -- "$@" "$?"
      bin/kafka-topics.sh --bootstrap-server "$1" --command-config admin.properties \
        --delete --topic "$2" || { echo "remove the test topic manually if it remains"; set -- "$@" 3; }
      # Status: 1 after a finding; otherwise 3 after a failed control, check or cleanup; otherwise 0.
      case "${4-}" in 1) exit 1 ;; ?*) exit 3 ;; esac
      ;;
  esac
)
```

### ACL, quota, and connection-limit inspection

**REASONED:** No live admin endpoint is available here. These commands inspect configuration; they do not demonstrate enforcement. Expected exposed state: overly broad matching grants, application `Create`, missing quotas, or unrestricted client connection settings. Expected fixed state: the intended topic/group grants, no application creation grants, explicit user quotas, and the client limits from step 5.

REASONED: following block; topic/group/cluster ACLs, user/client quotas and effective broker settings; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no live Kafka administrative endpoint and credentials for describing matching ACLs, user/client quotas and every broker's effective settings. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. Stubs printed three STUB ACL and four STUB config description lines; failed inspection printed ACL inspection failed. The bash -n, ShellCheck, guard and stub runs recorded here covered the ACL and quota inspection block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after a failed inspection, where the current form exits with status 3. Expect broad grants and absent limits when exposed, versus intended grants and explicit limits after fixing; descriptions alone do not establish enforcement, per the guide's cited Basic Kafka operations, topic administration, and quota commands (Kafka 4.3 documentation). Transaction identities and conditional provisioner quotas require their own live descriptions.
The successful administrative descriptions establish that the inspection path works; the marker and denial comparisons above test application behavior. Sources: [ACL listing](https://kafka.apache.org/43/security/authorization-and-acls/), [quota description](https://kafka.apache.org/43/operations/basic-kafka-operations/), and [broker configuration](https://kafka.apache.org/43/configuration/broker-configs/).
Inspect every broker's effective values and their configuration sources. For a transactional writer, also inspect matching ACLs for its transaction identity. If using the conditional topic-provisioner quota, describe that user too.

```bash
# ACL/quota/connection inspection; no live Kafka cluster, deployed broker certificates or deployed client credentials (distinct from synthetic certificate fixtures) or external test hosts. Expected outcomes are per the guide's cited Basic Kafka operations, topic administration, and quota commands (Kafka 4.3 documentation).
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_HOST:9093'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one broker endpoint; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the broker endpoint; not probing"; exit 2 ;;
    *)
      bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
        --list --topic orders --resource-pattern-type match \
        || { echo "ACL inspection failed"; exit 3; }
      bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
        --list --group app-workers --resource-pattern-type match \
        || { echo "group ACL inspection failed"; exit 3; }
      bin/kafka-acls.sh --bootstrap-server "$1" --command-config admin.properties \
        --list --cluster || { echo "cluster ACL inspection failed"; exit 3; }
      bin/kafka-configs.sh --bootstrap-server "$1" --command-config admin.properties \
        --describe --entity-type users --entity-name orders-writer \
        || { echo "writer quota inspection failed"; exit 3; }
      bin/kafka-configs.sh --bootstrap-server "$1" --command-config admin.properties \
        --describe --entity-type users --entity-name orders-reader \
        || { echo "reader quota inspection failed"; exit 3; }
      bin/kafka-configs.sh --bootstrap-server "$1" --command-config admin.properties \
        --describe --entity-type users --entity-type clients \
        || { echo "user/client quota override inspection failed"; exit 3; }
      bin/kafka-configs.sh --bootstrap-server "$1" --command-config admin.properties \
        --describe --entity-type brokers --all \
        || { echo "effective broker configuration inspection failed"; exit 3; }
      ;;
  esac
)
```

### Bounded quota comparison

**REASONED:** No isolated Kafka workload environment or quota metrics are available here. On an isolated one-partition `orders` fixture, run this identical bounded producer workload before and after applying the writer quota. Keep authentication and ACLs fixed. The baseline must be capable of exceeding the configured byte rate; otherwise the comparison is inconclusive.

REASONED: following block; bounded producer workload and limits of quota/connection evidence; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no isolated Kafka workload deployment, one-partition orders fixture, provisioned writer credentials or live quota and connection metrics. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. The stub printed 100000 records sent with synthetic produce-throttle-time-avg values 0 and 5; its failure printed bounded workload failed. The bash -n, ShellCheck, guard and stub runs recorded here covered the bounded quota block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after a failed workload, where the current form exits with status 3. Real exposed/fixed runs must deliver records with zero/nonzero throttling when exceeding the quota; consumer, request, mutation and connection limits need separate live workloads, per the guide's cited Quota grouping, precedence, request-time accounting, and enforcement (Kafka 4.3 documentation) and Kafka monitoring and quota-throttle metrics (Kafka 4.3 documentation).
Both runs must deliver the requested records without authorization or delivery errors. With no applicable quota, quota throttle time should remain zero; with the workload exceeding the fixed quota, `produce-throttle-time-avg` or `produce-throttle-time-max` should become nonzero. Inspect request-quota metrics separately to distinguish request-time throttling from bandwidth throttling. A low-rate successful marker round trip is the positive control that the fixed system still serves the application. Sources: [quota enforcement](https://kafka.apache.org/43/design/design/), [monitoring metrics](https://kafka.apache.org/43/operations/monitoring/), and [ProducerPerformance options](https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/ProducerPerformance.java).
This producer workload does not demonstrate consumer quotas, controller mutation quotas, or connection-limit enforcement. Those need their own bounded workloads. In particular, compare accepted client connections and connection-creation throttling around the configured limits while confirming that replication and quorum operation remain healthy; a TCP connect result or a configuration listing alone is insufficient.

```bash
# Bounded producer quota comparison; no live Kafka cluster, deployed broker certificates or deployed client credentials (distinct from synthetic certificate fixtures) or external test hosts. Expected outcomes are per the guide's cited Quota grouping, precedence, request-time accounting, and enforcement (Kafka 4.3 documentation) and Kafka monitoring and quota-throttle metrics (Kafka 4.3 documentation).
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BROKER_HOST:9093'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one broker endpoint; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the broker endpoint; not probing"; exit 2 ;;
    *)
      bin/kafka-producer-perf-test.sh --bootstrap-server "$1" \
        --command-config orders-writer.properties --topic orders \
        --num-records 100000 --record-size 1024 --throughput -1 --print-metrics \
        || { echo "bounded workload failed; inspect authentication, authorization and delivery errors"; exit 3; }
      ;;
  esac
)
```

### Authorization logging

**REASONED:** No live authorizer or collected logs are available here. Run the marker/write-denial pair above in a quiet test window, then inspect only that window's collected authorizer log. Correlate timestamps, client host, principal, operation, resource, and outcome so old records cannot satisfy the check.

REASONED: following block; DEBUG log filtering, INFO comparison and broker/controller collection; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no live Kafka authorizer or collected broker/controller logs from matched INFO/DEBUG requests. Local bash -n and ShellCheck 0.11.0 exited 0; six unsafe inputs printed not probing without stub calls. Grep over fixture logs printed both matching records, allowed write record missing, or denied write record missing. The bash -n, ShellCheck, guard and stub runs recorded here covered the authorization-logging block in an earlier form, whose placeholder refusal arm left the subshell with status 0 and whose paste and value-count refusals exited with status 1; none was re-run on the current form, whose placeholder, paste and value-count refusals leave the subshell with status 2. That earlier form also exited with status 1 after a missing log record, where the current form exits with status 3. Expect requested denials at INFO and both outcomes at DEBUG; absent denial records indicate failed collection, per the guide's cited StandardAuthorizer audit levels and message fields, tagged 4.3.0. No audit generation was observed. Authentication failures belong to server-log review, per the guide's cited Authentication using SASL (SCRAM) (Kafka 4.3 documentation).
At INFO, the requested denial should be present while the allowed write is absent. At DEBUG, both should be present. If the denied record is also absent, logger routing or collection has failed; absence of an allowed record alone is not proof of the intended INFO behavior. Sources: [StandardAuthorizer audit messages](https://github.com/apache/kafka/blob/4.3.0/metadata/src/main/java/org/apache/kafka/metadata/authorizer/StandardAuthorizerData.java) and [the logging configuration](https://github.com/apache/kafka/blob/4.3.0/config/log4j2.yaml).
The block checks the DEBUG outcome. Repeat the same requests at INFO to establish the matched comparison. Check controller log collection with known controller-authorized operations as well. The wrong-password probe belongs in the authentication-failure review of normal server logs, not in an expectation that the authorizer records failed authentication.

```bash
# Authorization logging; no collected broker or controller authorizer log from matched requests is available. Expected outcomes are per the guide's cited StandardAuthorizer audit levels and message fields, tagged 4.3.0.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_COLLECTED_AUTHORIZER_LOG'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "provide exactly one log path; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the log path; not probing"; exit 2 ;;
    *)
      grep -F 'Principal = User:orders-writer is Allowed operation = WRITE' "$1" \
        | grep -F 'on resource = Topic:LITERAL:orders' \
        || { echo "allowed write record missing"; exit 3; }
      grep -F 'Principal = User:orders-reader is Denied operation = WRITE' "$1" \
        | grep -F 'on resource = Topic:LITERAL:orders' \
        || { echo "denied write record missing"; exit 3; }
      ;;
  esac
)
```

### REASONED service checks

REASONED: Service-check inventory and evidence boundary; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no Kafka broker or KRaft controller deployment, deployed node certificates, provisioned client principals, external test hosts, quota metrics or collected broker/controller logs. Ten blocks passed syntax/lint; unsafe inputs printed not probing, stub comparisons exercised the documented branches, and local certificate verification accepted/rejected matching/wrong hostnames. The syntax/lint, guard and stub runs used an earlier form of the ten blocks, whose placeholder refusal arm left each subshell with status 0 and whose paste and value-count refusals exited with status 1. Those runs did not cover the current form, whose placeholder, paste and value-count refusals leave each subshell with status 2 and which the gate suite's bash -n and ShellCheck 0.11.0 passes cover. That earlier form also exited with status 1 after a failed control, check or cleanup that was not a finding, and its three blocks with temporary ACLs or topics stopped before their cleanup; the current form exits with status 3 after such a failure, and those three blocks run their cleanup before they exit. The marker round-trip, deny-by-default and topic-creation blocks changed again after those runs: every ACL removal now passes `--force`, the deny-by-default block removes its temporary topic ACL outside its probes whatever the positive control reports, and the topic-creation cleanup message changed; those runs did not cover that current form either. The listener-inventory and client TLS block changed again after those runs: it now checks `command -v ss` before running `ss -tlnp` and refuses with status 2 when `ss` is not installed, so those runs covered an earlier form of it, and its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs. Expect the exposed/fixed outcomes listed in the table, per the guide's cited Kafka security overview (Kafka 4.3 documentation); real listeners, identities, quotas, quorum and logs remain unobserved.
The checks below remain REASONED from the cited Kafka documentation and pinned sources. No live service behavior is claimed.

| Scope | Exposed/fixed checks and prerequisites | Status |
| --- | --- | --- |
| Kafka controls | REASONED: Entire service-check inventory; live Kafka comparisons are unavailable because a Kafka deployment opens listeners, which the authoring host forbids without an isolated network namespace, and none was available. The authoring environment therefore has no Kafka broker or KRaft controller deployment, deployed node certificates, provisioned client principals, external test hosts, quota metrics or collected broker/controller logs. Ten blocks passed bash -n and ShellCheck 0.11.0; six unsafe inputs per block printed not probing without stub calls. Stub comparisons printed findings for accepted unauthorized operations and the intended denial messages for fixed responses; fixture logs matched or reported missing records. Those bash -n, ShellCheck, guard, stub and fixture-log runs used an earlier form of the ten blocks, whose placeholder refusal arm left each subshell with status 0 and whose paste and value-count refusals exited with status 1. Those runs did not cover the current form, whose placeholder, paste and value-count refusals leave each subshell with status 2 and which the gate suite's bash -n and ShellCheck 0.11.0 passes cover. That earlier form also exited with status 1 after a failed control, check or cleanup that was not a finding, and its three blocks with temporary ACLs or topics stopped before their cleanup; the current form exits with status 3 after such a failure, and those three blocks run their cleanup before they exit. The marker round-trip, deny-by-default and topic-creation blocks changed again after those runs: every ACL removal now passes `--force`, the deny-by-default block removes its temporary topic ACL outside its probes whatever the positive control reports, and the topic-creation cleanup message changed; those runs did not cover that current form either. The listener-inventory and client TLS block changed again after those runs: it now checks `command -v ss` before running `ss -tlnp` and refuses with status 2 when `ss` is not installed, so those runs covered an earlier form of it, and its current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs. Local OpenSSL printed OK/hostname mismatch. Expect the exposed/fixed outcomes detailed above; live network, Kafka, quorum, quota and log-generation evidence remains unavailable, per the guide's cited sources (part 1 of 2): Kafka security overview (Kafka 4.3 documentation); Authorization and ACLs (`allow.everyone.if.no.acl.found`, resource-pattern-type) (Kafka 4.3 documentation). The guide's cited sources for the same expectation and evidence limit as part 1 (part 2 of 2): Kafka monitoring and quota-throttle metrics (Kafka 4.3 documentation); and StandardAuthorizer audit levels and message fields, tagged 4.3.0. Run every REASONED check above on a pinned Kafka deployment. Cover (part 1 of 3): namespace inventory and real IPv4/IPv6 exposure; client TLS and plaintext refusal; correct and wrong SCRAM credentials; marker round trip; authenticated low-user topic denial with no matching ACL; writer/reader separation and application-create denial with administrator success. The run on that pinned Kafka deployment is to cover (part 2 of 3): allowed/disallowed networks for each listener; valid, missing, and untrusted internal certificates; healthy replication and controller quorum after bootstrap; producer, consumer, request-time, and conditional partition-mutation quotas with matched bounded workloads and throttle metrics. The run on that pinned Kafka deployment is to cover (part 3 of 3): simultaneous-connection and connection-creation limits while internal traffic remains healthy; and INFO/DEBUG authorization records collected from brokers and controllers, plus authentication-failure records. Record commands, versions, diagnostics, matched positive controls, and cleanup. Configuration inspection alone does not demonstrate service behavior. | REASONED from the cited documentation and pinned sources; service behavior is not demonstrated. |

## Common mistakes

- `SASL_SSL` added as a second listener while `PLAINTEXT://:9092` stays advertised, so clients quietly keep using it.
- Authorizer enabled with `allow.everyone.if.no.acl.found=true` "temporarily". The flag opens only resources that have no ACL at all; existing ACLs are still enforced. That still means every new topic is world-readable and world-writable until someone adds its first ACL, so keep it `false`.
- Treating an unadvertised, loopback, or private controller socket as a substitute for authentication.
- Starting a deny-by-default quorum before authorizing its actual node certificate principals.
- Adding narrow writer/reader ACLs without removing the old shared, wildcard, prefix, or cluster-level grants.
- Assuming `auto.create.topics.enable=false` removes an application's explicit `Create` permission.
- Treating a quota listing as an enforcement test, or DEBUG authorizer logging as a complete audit trail.
- Treating an empty consumer result, a timeout, or `Verification: OK` alone as proof of the intended security boundary.

## Sources (checked September 2026)

The month in this heading is the month of the whole-guide documentation pass, and an item that carries its own later "checked" month was rechecked individually after that pass, so the later month applies to that item only.

- Kafka security overview (Kafka 4.3 documentation): https://kafka.apache.org/43/security/security-overview/
- Listener configuration (controller listener, combined-node requirement, protocol map) (Kafka 4.3 documentation): https://kafka.apache.org/43/security/listener-configuration/
- Encryption and authentication using SSL (Kafka 4.3 documentation): https://kafka.apache.org/43/security/encryption-and-authentication-using-ssl/
- Authentication using SASL (SCRAM) (Kafka 4.3 documentation): https://kafka.apache.org/43/security/authentication-using-sasl/
- Authorization and ACLs (`allow.everyone.if.no.acl.found`, resource-pattern-type) (Kafka 4.3 documentation): https://kafka.apache.org/43/security/authorization-and-acls/
- KRaft provisioning / storage formatting (`--standalone`, cluster ID reuse) (Kafka 4.3 documentation): https://kafka.apache.org/43/operations/kraft/
- Broker configuration reference (defaults for `listeners`, `sasl.enabled.mechanisms`, `inter.broker.listener.name`) (Kafka 4.3 documentation): https://kafka.apache.org/43/configuration/broker-configs/
- SSL client authentication on `SASL_SSL` listeners needs the listener prefix (source, `ChannelBuilders.java`, tagged 4.3.0): https://raw.githubusercontent.com/apache/kafka/4.3.0/clients/src/main/java/org/apache/kafka/common/network/ChannelBuilders.java
- Redpanda security documentation: https://docs.redpanda.com/streaming/current/manage/security/
- Redpanda Console authentication (built-in login requires an enterprise licence): https://docs.redpanda.com/streaming/current/console/config/security/authentication/
- Apache Kafka controller SCRAM bootstrap issue (KAFKA-15513): https://issues.apache.org/jira/browse/KAFKA-15513
- Kafka 3.9 authorization and ZooKeeper AclAuthorizer: https://kafka.apache.org/39/security/authorization-and-acls/
- KIP-801 authorizer bootstrapping and early-start listeners: <https://cwiki.apache.org/confluence/spaces/KAFKA/pages/195728007/KIP-801+Implement+an+Authorizer+that+stores+metadata+in+__cluster_metadata>
- Basic Kafka operations, topic administration, and quota commands (Kafka 4.3 documentation): https://kafka.apache.org/43/operations/basic-kafka-operations/
- Multi-tenancy, topic-creation controls, and partition-mutation quotas (Kafka 4.3 documentation): https://kafka.apache.org/43/operations/multi-tenancy/
- Quota grouping, precedence, request-time accounting, and enforcement (Kafka 4.3 documentation): https://kafka.apache.org/43/design/design/
- Producer configuration, idempotence, and transactional identity (Kafka 4.3 documentation): https://kafka.apache.org/43/configuration/producer-configs/
- Consumer configuration and client security properties (Kafka 4.3 documentation): https://kafka.apache.org/43/configuration/consumer-configs/
- Admin client configuration and security properties (Kafka 4.3 documentation): https://kafka.apache.org/43/configuration/admin-configs/
- Kafka upgrades, ZooKeeper removal, and the Log4j2 migration (Kafka 4.3 documentation): https://kafka.apache.org/43/getting-started/upgrade/
- Kafka monitoring and quota-throttle metrics (Kafka 4.3 documentation): https://kafka.apache.org/43/operations/monitoring/
- ConfigCommand file loading, SCRAM parsing, and configuration descriptions, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/core/src/main/scala/kafka/admin/ConfigCommand.scala
- InitProducerId authorization, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/core/src/main/scala/kafka/server/KafkaApis.scala
- Distribution server configuration and example listener ports, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/config/server.properties
- Distribution Log4j2 configuration, authorizer appender, and log filenames, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/config/log4j2.yaml
- StandardAuthorizer audit levels and message fields, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/metadata/src/main/java/org/apache/kafka/metadata/authorizer/StandardAuthorizerData.java
- Authorizer Action audit-logging flags (Kafka 4.3 documentation): https://kafka.apache.org/43/javadoc/org/apache/kafka/server/authorizer/Action.html
- Console producer options, configuration files, and synchronous sends, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/ConsoleProducer.java
- Console consumer options, configuration files, groups, and timeouts, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/consumer/ConsoleConsumerOptions.java
- Console consumer exception logging and exit behavior, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/consumer/ConsoleConsumer.java
- Broker API versions CLI options, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/BrokerApiVersionsCommand.java
- Topic administration CLI options and error handling, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/TopicCommand.java
- ACL CLI removal, confirmation prompt, `--force` option and error exit, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/AclCommand.java
- Producer performance CLI options and metrics, tagged 4.3.0: https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/ProducerPerformance.java
- OpenSSL s_client certificate and hostname verification: https://docs.openssl.org/3.5/man1/openssl-s_client/
- OpenSSL file-based private-key passphrases: https://docs.openssl.org/3.5/man1/openssl-passphrase-options/
- Kafka `LISTENERS_DEFAULT = "PLAINTEXT://:9092"` (pinned tag 4.3.1): https://github.com/apache/kafka/blob/4.3.1/server/src/main/java/org/apache/kafka/network/SocketServerConfigs.java#L64
- Kafka defines the `listeners` config with that default (pinned tag 4.3.1): https://github.com/apache/kafka/blob/4.3.1/server/src/main/java/org/apache/kafka/network/SocketServerConfigs.java#L156


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- default: Kafka listener default (4.3.1)
- docs: Kafka documentation (4.3)
- source: Kafka source (4.3.0)
- legacy: Kafka legacy authorization (3.9)
- kafka-design: Apache Kafka issue tracker and KIPs (unknown)
- redpanda: Redpanda documentation (unknown)
- openssl: OpenSSL documentation (3.5)

Claims (full source mapping in the JSON block below):

- plaintext (REASONED; default): Default listener is PLAINTEXT://:9092 as of 4.3.1.
- internal-default (REASONED; docs): security.inter.broker.protocol defaults to PLAINTEXT.
- authorizer-default (REASONED; docs): No authorizer by default; reachable clients can read, write, create and delete topics.
- roles (REASONED; docs): Examples target 4.3; 4.0+ is KRaft-only; critical deployments should separate broker/controller roles.
- listeners (REASONED; docs, source): CLIENT 9093 uses SASL_SSL; private INTERNAL 9095 and CONTROLLER 9094 use mutual TLS; remove plaintext.
- advertise (REASONED; docs): Advertise broker CLIENT/INTERNAL only; broker-only nodes still need outbound controller security.
- listener-selection (REASONED; docs): Use inter.broker.listener.name without security.inter.broker.protocol; lowercase listener prefixes must match.
- quorum (REASONED; docs): Dynamic quorum bootstrap is not static-voter migration; reuse cluster ID and use the documented membership workflow.
- controller-scram (REASONED; kafka-design): KAFKA-15513 lists 3.5.1/3.6.0 and no fix; it does not prove failure on every 4.3 deployment.
- tls-files (REASONED; docs): Protect per-node keystores, truststores, keys and properties before writing secrets; require matching SANs.
- pem (REASONED; docs): PEM is supported since 2.7.0; PKCS#8 key passwords use ssl.key.password, not PEM store passwords.
- hostname (REASONED; docs): Hostname verification defaults on since 2.0.0; leave it enabled.
- client-cert (REASONED; docs, source): SASL_SSL needs listener-prefixed ssl.client.auth; none is default, requested is optional, required enforces mTLS.
- tls-protocols (REASONED; docs): Generated 4.3 reference defaults ssl.enabled.protocols to TLSv1.2,TLSv1.3.
- scram (REASONED; docs): Use distinct SCRAM-SHA-512 identities only over TLS; KRaft credentials reside in the metadata log.
- scram-files (REASONED; source): Bootstrap through authorized internal mTLS; protected --add-config-file values omit brackets and need Java escaping.
- bootstrap-acl (REASONED; docs, kafka-design): StandardAuthorizer on every broker/controller denies by default; authorize exact node/admin principals before quorum startup.
- legacy-authorizer (REASONED; legacy): Legacy 3.9 ZooKeeper uses kafka.security.authorizer.AclAuthorizer, not SimpleAclAuthorizer or the KRaft class.
- topic-grants (REASONED; docs, source): Separate writer Write/Describe from reader Read/Describe and app-workers group Read; remove broader old grants.
- topic-create (REASONED; docs): Disable auto.create.topics.enable; this does not revoke explicit Create rights.
- producer-grants (REASONED; docs): --producer includes Create; use explicit writer grants and inspect wildcard, prefix and cluster ACLs.
- transactions (REASONED; docs, source): Grant the specific transactional ID; 4.3.0 non-transactional initialization also accepts topic Write without IdempotentWrite.
- quotas (REASONED; docs): Per-broker user byte quotas and request_percentage (one thread's time) need sizing; user/client overrides take precedence.
- connections (REASONED; docs): Client listener connection and connection-creation limits are separate from traffic quotas and internal health.
- mutation-quota (REASONED; docs): Conditional controller_mutation_rate bounds partition mutations, not throughput or permissions.
- logging (REASONED; docs, source): 4.0+ uses Log4j2; requested denials log at INFO, allows at DEBUG, some evaluations at TRACE; collect authentication separately.
- clients (REASONED; docs, source): Protect separate client properties; 4.3 CLI uses --command-config, including console producer/consumer.
- mfa (REASONED; docs, source): Kafka has no second-factor dialogue; client mTLS is a machine possession control; human access needs an MFA layer.
- redpanda (REASONED; redpanda): Protocol controls carry over, but Redpanda uses redpanda.yaml/rpk; check its own quotas, listeners and logging.
- console (REASONED; redpanda): Console login needs configured OIDC/basic auth and enterprise licence; enabled features without valid licence show an expiry page.
- verify-tls (REASONED; docs, openssl): Inventory role-specific listeners and verify hostname/chain; TLS errors differ from inconclusive DNS/local failures.
- verify-internal (REASONED; docs, source): Valid internal certificate must permit Kafka access; missing/untrusted certificates need TLS-attributed rejection.
- verify-controller (REASONED; docs, openssl): Controller valid/missing/untrusted certificate and allowed/disallowed-network pairs need logs; TLS alone proves no quorum health.
- verify-password (REASONED; docs, source): Authenticated control succeeds; plaintext is refused and wrong password reports SaslAuthenticationException, not merely nonzero exit.
- verify-acl (REASONED; docs, source): Require marker delivery and opposite-role operation denials; an empty consumer result is inconclusive.
- verify-idempotence (REASONED; docs, source): Only the negative producer probe sets enable.idempotence=false, so IdempotentWrite authorization cannot mask the topic-write denial; test override only.
- verify-default-deny (REASONED; docs, source): Authenticated low-user access to a fixture with no matching ACL must yield TopicAuthorizationException; inspect effective authorizer.
- verify-create (REASONED; docs, source): Application creation must be denied while administrator creation succeeds; inspect old literal Create grants too.
- verify-inspection (REASONED; docs, source): Inspect matching ACLs, user/client quotas and every broker's effective limits; listings do not establish enforcement.
- verify-quota (REASONED; docs, source): Matched bounded producer runs must deliver records and discriminate nonzero throttle metrics; other limits need separate workloads.
- verify-logs (REASONED; source, docs): Matched INFO/DEBUG requests need correlated denial/allow records; missing denial means collection failed.

````json
{
  "schema": 1,
  "checked": "2026-09-26",
  "documentation_checked": "2026-09",
  "body_sha256": "167627b086a0840043a709f03e20c9269ed04efb59e43992afa81ae3446fb3e2",
  "components": {
    "default": {
      "name": "Kafka listener default",
      "basis": "4.3.1",
      "sources": {
        "s2ede3d269b73": "https://github.com/apache/kafka/blob/4.3.1/server/src/main/java/org/apache/kafka/network/SocketServerConfigs.java#L64",
        "saec05a4d2baa": "https://github.com/apache/kafka/blob/4.3.1/server/src/main/java/org/apache/kafka/network/SocketServerConfigs.java#L156"
      }
    },
    "docs": {
      "name": "Kafka documentation",
      "basis": "4.3",
      "sources": {
        "s580ea02caa84": "https://kafka.apache.org/43/configuration/broker-configs/",
        "sd24b0c4f4311": "https://kafka.apache.org/43/security/authorization-and-acls/",
        "s7fba6211f3a6": "https://kafka.apache.org/43/operations/kraft/",
        "s30363626e954": "https://kafka.apache.org/43/getting-started/upgrade/",
        "s4afda8ace175": "https://kafka.apache.org/43/security/listener-configuration/",
        "sd9b5ccc53563": "https://kafka.apache.org/43/security/encryption-and-authentication-using-ssl/",
        "s91a5821170c7": "https://kafka.apache.org/43/security/authentication-using-sasl/",
        "sfba7bc13e360": "https://kafka.apache.org/43/operations/multi-tenancy/",
        "sbd4fe5c33a0a": "https://kafka.apache.org/43/configuration/producer-configs/",
        "sd350211459d4": "https://kafka.apache.org/43/operations/basic-kafka-operations/",
        "sc61f06541d5d": "https://kafka.apache.org/43/design/design/",
        "s1eed378849f6": "https://kafka.apache.org/43/javadoc/org/apache/kafka/server/authorizer/Action.html",
        "sbe7bcb0772dd": "https://kafka.apache.org/43/configuration/consumer-configs/",
        "s8e46d7864976": "https://kafka.apache.org/43/configuration/admin-configs/",
        "sc76c88a31320": "https://kafka.apache.org/43/security/security-overview/",
        "s4d4a39897877": "https://kafka.apache.org/43/operations/monitoring/"
      }
    },
    "source": {
      "name": "Kafka source",
      "basis": "4.3.0",
      "sources": {
        "s6daae2bb5f15": "https://github.com/apache/kafka/blob/4.3.0/config/server.properties",
        "s91dba4e26cbb": "https://raw.githubusercontent.com/apache/kafka/4.3.0/clients/src/main/java/org/apache/kafka/common/network/ChannelBuilders.java",
        "sf7d512582608": "https://github.com/apache/kafka/blob/4.3.0/core/src/main/scala/kafka/admin/ConfigCommand.scala",
        "s9976d63fb7b3": "https://github.com/apache/kafka/blob/4.3.0/core/src/main/scala/kafka/server/KafkaApis.scala",
        "sa25d406ac801": "https://github.com/apache/kafka/blob/4.3.0/config/log4j2.yaml",
        "s2252053e1108": "https://github.com/apache/kafka/blob/4.3.0/metadata/src/main/java/org/apache/kafka/metadata/authorizer/StandardAuthorizerData.java",
        "s3ee12f40f1fb": "https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/ConsoleProducer.java",
        "s3d5d50816fb9": "https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/consumer/ConsoleConsumerOptions.java",
        "s12ac0c3869f7": "https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/BrokerApiVersionsCommand.java",
        "s50461fdc2c6e": "https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/consumer/ConsoleConsumer.java",
        "s0f1e046e30fd": "https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/TopicCommand.java",
        "se259d0150b9c": "https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/ProducerPerformance.java",
        "sf40d74b6484b": "https://github.com/apache/kafka/blob/4.3.0/tools/src/main/java/org/apache/kafka/tools/AclCommand.java"
      }
    },
    "legacy": {
      "name": "Kafka legacy authorization",
      "basis": "3.9",
      "sources": {
        "se10d0fcd0e46": "https://kafka.apache.org/39/security/authorization-and-acls/"
      }
    },
    "kafka-design": {
      "name": "Apache Kafka issue tracker and KIPs",
      "basis": "unknown",
      "sources": {
        "s2083e6339454": "https://issues.apache.org/jira/browse/KAFKA-15513",
        "sdeef4a8b642f": "https://cwiki.apache.org/confluence/spaces/KAFKA/pages/195728007/KIP-801+Implement+an+Authorizer+that+stores+metadata+in+__cluster_metadata"
      }
    },
    "redpanda": {
      "name": "Redpanda documentation",
      "basis": "unknown",
      "sources": {
        "s4261500401cb": "https://docs.redpanda.com/streaming/current/manage/security/",
        "sec8155c4a049": "https://docs.redpanda.com/streaming/current/console/config/security/authentication/"
      }
    },
    "openssl": {
      "name": "OpenSSL documentation",
      "basis": "3.5",
      "sources": {
        "s6338b4e2e47d": "https://docs.openssl.org/3.5/man1/openssl-s_client/",
        "sccd4f8550707": "https://docs.openssl.org/3.5/man1/openssl-passphrase-options/"
      }
    }
  },
  "claims": {
    "plaintext": {"text": "Default listener is PLAINTEXT://:9092 as of 4.3.1.", "components": ["default"], "sources": ["default:s2ede3d269b73", "default:saec05a4d2baa"], "status": "REASONED"},
    "internal-default": {"text": "security.inter.broker.protocol defaults to PLAINTEXT.", "components": ["docs"], "sources": ["docs:s580ea02caa84"], "status": "REASONED"},
    "authorizer-default": {"text": "No authorizer by default; reachable clients can read, write, create and delete topics.", "components": ["docs"], "sources": ["docs:sd24b0c4f4311", "docs:s580ea02caa84"], "status": "REASONED"},
    "roles": {"text": "Examples target 4.3; 4.0+ is KRaft-only; critical deployments should separate broker/controller roles.", "components": ["docs"], "sources": ["docs:s7fba6211f3a6", "docs:s30363626e954"], "status": "REASONED"},
    "listeners": {"text": "CLIENT 9093 uses SASL_SSL; private INTERNAL 9095 and CONTROLLER 9094 use mutual TLS; remove plaintext.", "components": ["docs", "source"], "sources": ["docs:s4afda8ace175", "source:s6daae2bb5f15"], "status": "REASONED"},
    "advertise": {"text": "Advertise broker CLIENT/INTERNAL only; broker-only nodes still need outbound controller security.", "components": ["docs"], "sources": ["docs:s4afda8ace175", "docs:s580ea02caa84"], "status": "REASONED"},
    "listener-selection": {"text": "Use inter.broker.listener.name without security.inter.broker.protocol; lowercase listener prefixes must match.", "components": ["docs"], "sources": ["docs:s4afda8ace175", "docs:s580ea02caa84"], "status": "REASONED"},
    "quorum": {"text": "Dynamic quorum bootstrap is not static-voter migration; reuse cluster ID and use the documented membership workflow.", "components": ["docs"], "sources": ["docs:s7fba6211f3a6"], "status": "REASONED"},
    "controller-scram": {"text": "KAFKA-15513 lists 3.5.1/3.6.0 and no fix; it does not prove failure on every 4.3 deployment.", "components": ["kafka-design"], "sources": ["kafka-design:s2083e6339454"], "status": "REASONED"},
    "tls-files": {"text": "Protect per-node keystores, truststores, keys and properties before writing secrets; require matching SANs.", "components": ["docs"], "sources": ["docs:sd9b5ccc53563"], "status": "REASONED"},
    "pem": {"text": "PEM is supported since 2.7.0; PKCS#8 key passwords use ssl.key.password, not PEM store passwords.", "components": ["docs"], "sources": ["docs:sd9b5ccc53563"], "status": "REASONED"},
    "hostname": {"text": "Hostname verification defaults on since 2.0.0; leave it enabled.", "components": ["docs"], "sources": ["docs:sd9b5ccc53563"], "status": "REASONED"},
    "client-cert": {"text": "SASL_SSL needs listener-prefixed ssl.client.auth; none is default, requested is optional, required enforces mTLS.", "components": ["docs", "source"], "sources": ["docs:sd9b5ccc53563", "source:s91dba4e26cbb"], "status": "REASONED"},
    "tls-protocols": {"text": "Generated 4.3 reference defaults ssl.enabled.protocols to TLSv1.2,TLSv1.3.", "components": ["docs"], "sources": ["docs:s580ea02caa84"], "status": "REASONED"},
    "scram": {"text": "Use distinct SCRAM-SHA-512 identities only over TLS; KRaft credentials reside in the metadata log.", "components": ["docs"], "sources": ["docs:s91a5821170c7"], "status": "REASONED"},
    "scram-files": {"text": "Bootstrap through authorized internal mTLS; protected --add-config-file values omit brackets and need Java escaping.", "components": ["source"], "sources": ["source:sf7d512582608"], "status": "REASONED"},
    "bootstrap-acl": {"text": "StandardAuthorizer on every broker/controller denies by default; authorize exact node/admin principals before quorum startup.", "components": ["docs", "kafka-design"], "sources": ["docs:sd24b0c4f4311", "kafka-design:sdeef4a8b642f"], "status": "REASONED"},
    "legacy-authorizer": {"text": "Legacy 3.9 ZooKeeper uses kafka.security.authorizer.AclAuthorizer, not SimpleAclAuthorizer or the KRaft class.", "components": ["legacy"], "sources": ["legacy:se10d0fcd0e46"], "status": "REASONED"},
    "topic-grants": {"text": "Separate writer Write/Describe from reader Read/Describe and app-workers group Read; remove broader old grants.", "components": ["docs", "source"], "sources": ["docs:sd24b0c4f4311", "source:sf40d74b6484b"], "status": "REASONED"},
    "topic-create": {"text": "Disable auto.create.topics.enable; this does not revoke explicit Create rights.", "components": ["docs"], "sources": ["docs:s580ea02caa84", "docs:sfba7bc13e360"], "status": "REASONED"},
    "producer-grants": {"text": "--producer includes Create; use explicit writer grants and inspect wildcard, prefix and cluster ACLs.", "components": ["docs"], "sources": ["docs:sd24b0c4f4311"], "status": "REASONED"},
    "transactions": {"text": "Grant the specific transactional ID; 4.3.0 non-transactional initialization also accepts topic Write without IdempotentWrite.", "components": ["docs", "source"], "sources": ["docs:sbd4fe5c33a0a", "source:s9976d63fb7b3"], "status": "REASONED"},
    "quotas": {"text": "Per-broker user byte quotas and request_percentage (one thread's time) need sizing; user/client overrides take precedence.", "components": ["docs"], "sources": ["docs:sd350211459d4", "docs:sc61f06541d5d"], "status": "REASONED"},
    "connections": {"text": "Client listener connection and connection-creation limits are separate from traffic quotas and internal health.", "components": ["docs"], "sources": ["docs:s580ea02caa84"], "status": "REASONED"},
    "mutation-quota": {"text": "Conditional controller_mutation_rate bounds partition mutations, not throughput or permissions.", "components": ["docs"], "sources": ["docs:sfba7bc13e360"], "status": "REASONED"},
    "logging": {"text": "4.0+ uses Log4j2; requested denials log at INFO, allows at DEBUG, some evaluations at TRACE; collect authentication separately.", "components": ["docs", "source"], "sources": ["docs:s30363626e954", "source:sa25d406ac801", "source:s2252053e1108", "docs:s1eed378849f6"], "status": "REASONED"},
    "clients": {"text": "Protect separate client properties; 4.3 CLI uses --command-config, including console producer/consumer.", "components": ["docs", "source"], "sources": ["docs:sbd4fe5c33a0a", "docs:sbe7bcb0772dd", "docs:s8e46d7864976", "source:s3ee12f40f1fb", "source:s3d5d50816fb9"], "status": "REASONED"},
    "mfa": {"text": "Kafka has no second-factor dialogue; client mTLS is a machine possession control; human access needs an MFA layer.", "components": ["docs", "source"], "sources": ["docs:sc76c88a31320", "docs:sd9b5ccc53563", "source:s91dba4e26cbb"], "status": "REASONED"},
    "redpanda": {"text": "Protocol controls carry over, but Redpanda uses redpanda.yaml/rpk; check its own quotas, listeners and logging.", "components": ["redpanda"], "sources": ["redpanda:s4261500401cb"], "status": "REASONED"},
    "console": {"text": "Console login needs configured OIDC/basic auth and enterprise licence; enabled features without valid licence show an expiry page.", "components": ["redpanda"], "sources": ["redpanda:sec8155c4a049"], "status": "REASONED"},
    "verify-tls": {"text": "Inventory role-specific listeners and verify hostname/chain; TLS errors differ from inconclusive DNS/local failures.", "components": ["docs", "openssl"], "sources": ["docs:s4afda8ace175", "docs:sd9b5ccc53563", "openssl:s6338b4e2e47d"], "status": "REASONED", "verify": [1]},
    "verify-internal": {"text": "Valid internal certificate must permit Kafka access; missing/untrusted certificates need TLS-attributed rejection.", "components": ["docs", "source"], "sources": ["docs:sd9b5ccc53563", "source:s12ac0c3869f7"], "status": "REASONED", "verify": [2]},
    "verify-controller": {"text": "Controller valid/missing/untrusted certificate and allowed/disallowed-network pairs need logs; TLS alone proves no quorum health.", "components": ["docs", "openssl"], "sources": ["docs:s4afda8ace175", "docs:sd9b5ccc53563", "openssl:s6338b4e2e47d", "openssl:sccd4f8550707"], "status": "REASONED", "verify": [3]},
    "verify-password": {"text": "Authenticated control succeeds; plaintext is refused and wrong password reports SaslAuthenticationException, not merely nonzero exit.", "components": ["docs", "source"], "sources": ["docs:s91a5821170c7", "source:s3d5d50816fb9", "source:s50461fdc2c6e", "source:s12ac0c3869f7"], "status": "REASONED", "verify": [4]},
    "verify-acl": {"text": "Require marker delivery and opposite-role operation denials; an empty consumer result is inconclusive.", "components": ["docs", "source"], "sources": ["docs:sd24b0c4f4311", "source:s3ee12f40f1fb", "source:s3d5d50816fb9", "source:s50461fdc2c6e", "source:sf40d74b6484b"], "status": "REASONED", "verify": [5]},
    "verify-idempotence": {"text": "Only the negative producer probe sets enable.idempotence=false, so IdempotentWrite authorization cannot mask the topic-write denial; test override only.", "components": ["docs", "source"], "sources": ["docs:sd24b0c4f4311", "docs:sbd4fe5c33a0a", "source:s3ee12f40f1fb"], "status": "REASONED", "verify": [5]},
    "verify-default-deny": {"text": "Authenticated low-user access to a fixture with no matching ACL must yield TopicAuthorizationException; inspect effective authorizer.", "components": ["docs", "source"], "sources": ["docs:sd24b0c4f4311", "source:sf40d74b6484b"], "status": "REASONED", "verify": [6]},
    "verify-create": {"text": "Application creation must be denied while administrator creation succeeds; inspect old literal Create grants too.", "components": ["docs", "source"], "sources": ["docs:sd24b0c4f4311", "docs:sd350211459d4", "source:s0f1e046e30fd"], "status": "REASONED", "verify": [7]},
    "verify-inspection": {"text": "Inspect matching ACLs, user/client quotas and every broker's effective limits; listings do not establish enforcement.", "components": ["docs", "source"], "sources": ["docs:sd24b0c4f4311", "docs:s580ea02caa84", "docs:sd350211459d4", "source:sf7d512582608"], "status": "REASONED", "verify": [8]},
    "verify-quota": {"text": "Matched bounded producer runs must deliver records and discriminate nonzero throttle metrics; other limits need separate workloads.", "components": ["docs", "source"], "sources": ["docs:sc61f06541d5d", "docs:s4d4a39897877", "source:se259d0150b9c"], "status": "REASONED", "verify": [9]},
    "verify-logs": {"text": "Matched INFO/DEBUG requests need correlated denial/allow records; missing denial means collection failed.", "components": ["source", "docs"], "sources": ["source:sa25d406ac801", "source:s2252053e1108", "docs:s1eed378849f6"], "status": "REASONED", "verify": [10]}
  }
}
````
<!-- version-basis:end -->
