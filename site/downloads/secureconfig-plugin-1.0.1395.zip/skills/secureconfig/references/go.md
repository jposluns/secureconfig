# Go: TLS and authentication with net/http

Go is a programming language whose standard `net/http` package can serve web apps and APIs. This guide helps your AI assistant deploy a Go service securely, including a loopback bind behind a TLS proxy or HTTPS in Go itself, authentication, private diagnostic endpoints, and request limits with server timeouts.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/go.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Go certificate-store qualification 1.27, Go header-count qualification 1.27, Go per-request deadline minimum 1.20+, Go Request.Host source 1.27.0, Go environment source go1.27.0, go-oidc documentation v3, pquerna/otp v1.5.0, and Authelia source v4.39.28; 1 further source is pinned to a commit and 8 carry no recorded version. Metadata reviewed 2026-10-19; documentation checked September 2026. The guide records 38 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Preferred production layout: bind the Go server to `127.0.0.1` and terminate TLS in a reverse proxy ([caddy.md](caddy.md), [nginx.md](nginx.md)) or behind [cloudflare.md](cloudflare.md). `net/http` can also terminate TLS itself, shown below. Certificates: [free-certificates.md](free-certificates.md) or [self-signed.md](self-signed.md).

## 1. HTTPS directly in Go

```go
const canonicalHost = "app.example.com"   // r.Host comes from the client; never reflect it in the redirect.
go http.ListenAndServe(":80", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {   // port 80 only redirects
    target := r.URL.RequestURI()
    // Opaque or absolute-form targets can yield non-path values; only append an origin-form path.
    if len(target) == 0 || target[0] != '/' {
        target = "/"
    }
    http.Redirect(w, r, "https://"+canonicalHost+target, http.StatusMovedPermanently)
}))
srv := &http.Server{
    Addr:              ":443",
    Handler:           mux,
    ReadHeaderTimeout: 10 * time.Second,
    TLSConfig:         &tls.Config{MinVersion: tls.VersionTLS12},
}
log.Fatal(srv.ListenAndServeTLS("/etc/ssl/certs/server.crt", "/etc/ssl/private/server.key"))   // cert file: leaf, then intermediates
```

Set `canonicalHost` to your canonical hostname (no scheme or path) and append only an origin-form path (falling back to `/` for non-path values from opaque or absolute-form targets), so neither a forged Host nor a crafted request target can turn this into an open redirect.

crypto/tls already defaults to a TLS 1.2 minimum (as of September 2026); setting `MinVersion` keeps that true when a config is copied or a default shifts. Binding ports below 1024 needs root or `CAP_NET_BIND_SERVICE` on Linux's usual configuration (the per-namespace `net.ipv4.ip_unprivileged_port_start` defaults to 1024 but is configurable), one more reason to prefer the proxy layout.

## 2. Behind a proxy

```go
srv := &http.Server{Addr: "127.0.0.1:8080", Handler: mux, ReadHeaderTimeout: 10 * time.Second}
log.Fatal(srv.ListenAndServe())
```

`http.Server` has no trusted-proxy setting: `r.RemoteAddr` is the proxy, and `X-Forwarded-For` and `X-Forwarded-Proto` are ordinary request headers that anyone who can reach the port could set. Read them only when the listener is loopback-only and the proxy overwrites them, and set `Strict-Transport-Security` and the other headers at the proxy per [headers.md](headers.md).

## 3. Authentication

Follow [authentication.md](authentication.md). Password hashing with `golang.org/x/crypto/bcrypt`:

```go
hash, err := bcrypt.GenerateFromPassword([]byte(password), 12)   // DefaultCost is 10; input above 72 bytes is rejected
err = bcrypt.CompareHashAndPassword(hash, []byte(password))     // nil on match
```

`golang.org/x/crypto/argon2` is the alternative: `argon2.IDKey(password, salt, time, memory, threads, keyLen)` returns raw bytes, so you store the random salt and the parameters next to the result. Its documentation carries the RFC 9106 parameter sets (`time=1, memory=2 GiB, threads=4`, or `time=3, memory=64 MiB, threads=4` where memory is short).

Session cookie with the flags set:

```go
http.SetCookie(w, &http.Cookie{
    Name: "session", Value: token, Path: "/",
    Secure: true, HttpOnly: true, SameSite: http.SameSiteLaxMode,
})
```

Rate-limit the login handler with `golang.org/x/time/rate` (one limiter here; key a map of limiters by the proxy-supplied client address for per-client limits):

```go
var loginLimiter = rate.NewLimiter(rate.Every(3*time.Second), 5)   // about 20 per minute, burst 5
if !loginLimiter.Allow() { http.Error(w, "too many requests", http.StatusTooManyRequests); return }
```

Guide advice: API keys and tokens come from the environment, never from literals in the source; generate them per [authentication.md](authentication.md). Go go1.27.0 documents [`os.Getenv(key)` and `os.LookupEnv(key)`](https://github.com/golang/go/blob/go1.27.0/src/os/env.go#L98-L115): `Getenv` returns the value, or an empty string when unset; `LookupEnv` returns the value (possibly empty) and `true` when present, or an empty string and `false` when unset. If configuration needs to distinguish an unset token from an empty one, use the boolean returned by `LookupEnv`. These APIs load values; token generation stays delegated to [authentication.md](authentication.md).

SSO: `github.com/coreos/go-oidc/v3/oidc` pairs with `golang.org/x/oauth2`; `oidc.NewProvider(ctx, issuer)` discovers the provider and `provider.Verifier(&oidc.Config{ClientID: clientID})` checks ID token signature, issuer, audience, and expiry. The allowlist checks that follow are in [oidc-integration.md](oidc-integration.md).

MFA: this guide advises app-level TOTP with [pquerna/otp](https://github.com/pquerna/otp) (v1.5.0), or a fronting identity layer such as Cloudflare Access or Authelia; requirements in [mfa.md](mfa.md). Cloudflare Access [independent MFA](https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/access-settings/independent-mfa.mdx#L15-L24) can require a TOTP authenticator or WebAuthn security key after IdP login; its [MFA settings](https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/policies/mfa-requirements.mdx#L17-L85) require organization-level enablement before application or policy configuration, and policy settings override application settings, which override organization settings. Authelia v4.39.28 [passkey login](https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/second-factor/webauthn.md#L69-L75) counts as a single factor and, by default, prompts for a password when the request requires MFA. Guide advice: require MFA in the effective policy and test that access without the second factor is denied; these citations do not establish MFA enforcement by default or enforcement in your Go deployment.

## 4. Client-side TLS discipline

Never set `InsecureSkipVerify: true`; the crypto/tls docs state it accepts any certificate and any host name, a machine-in-the-middle position unless you supply your own checks through `VerifyConnection` or `VerifyPeerCertificate` (which is not a deployment pattern to reach for casually). For an internal CA, trust the CA instead (see [self-signed.md](self-signed.md) for producing the file): `SSL_CERT_FILE=/path/ca.crt` (or `SSL_CERT_DIR`) overrides the system locations that `x509.SystemCertPool` reads, or add it in code:

```go
pool, err := x509.SystemCertPool()
if err != nil { log.Fatal(err) }
pem, err := os.ReadFile("/path/ca.crt")
if err != nil { log.Fatal(err) }
if !pool.AppendCertsFromPEM(pem) { log.Fatal("no certificate parsed from /path/ca.crt") }
client := &http.Client{Transport: &http.Transport{TLSClientConfig: &tls.Config{RootCAs: pool}}}
```

On Go 1.27, setting `SSL_CERT_FILE` or `SSL_CERT_DIR` bypasses the platform certificate-verification APIs on macOS and Windows unless you also set `GODEBUG=x509sslcertoverrideplatform=0`.

## 5. Keep diagnostic endpoints private

Importing `net/http/pprof` for its side effect registers `/debug/pprof/` (profiles, traces, `cmdline`, and requests that force a GC) on `http.DefaultServeMux`, and `expvar` registers `/debug/vars` (exposing `cmdline` and `memstats`) the same way. Neither package starts a listener by itself, but `http.ListenAndServe(addr, nil)`, or any server with a nil handler, serves the default mux, so a single stray import turns a public port into an information-disclosure and resource-exhaustion surface. Give the application its own mux and never mount diagnostics on it:

```go
mux := http.NewServeMux()          // the app mux; assign it to Server.Handler, not the default mux
// ... register application routes on mux ...
```

If you need pprof or expvar, register them on a separate mux and serve it on loopback only, never through the public proxy:

```go
diag := http.NewServeMux()
diag.HandleFunc("/debug/pprof/", pprof.Index)              // import "net/http/pprof"; Index serves the named runtime profiles but not profile/trace/cmdline/symbol
diag.HandleFunc("/debug/pprof/profile", pprof.Profile)
diag.HandleFunc("/debug/pprof/trace", pprof.Trace)
diag.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
diag.HandleFunc("/debug/pprof/symbol", pprof.Symbol)
diag.Handle("/debug/vars", expvar.Handler())
go func() { log.Fatal((&http.Server{Addr: "127.0.0.1:6060", Handler: diag, ReadHeaderTimeout: 10 * time.Second}).ListenAndServe()) }()
```

## 6. Bound request resources

Cap request bodies per endpoint so a large or slow upload cannot exhaust memory. `http.MaxBytesReader` wraps the body and makes reads past the limit fail; it does not send the 413 for you, so handle the error:

```go
r.Body = http.MaxBytesReader(w, r.Body, 1<<20)   // 1 MiB example policy, choose per endpoint
dec := json.NewDecoder(r.Body)                   // build the decoder AFTER wrapping, or the cap is not applied
if err := dec.Decode(&v); err != nil {           // v is the endpoint's destination value
    var mbe *http.MaxBytesError
    if errors.As(err, &mbe) { http.Error(w, "request body too large", http.StatusRequestEntityTooLarge); return }
    http.Error(w, "bad request", http.StatusBadRequest); return
}
```

Header size is a separate control: `Server.MaxHeaderBytes` defaults to `1 << 20` (1 MiB, covering the request line and headers, not the body), and Go 1.27 adds `Server.MaxHeaderValueCount` (default 500) to bound the number of header values. Neither substitutes for the body limit above; set the body limit where you read untrusted input.

## 7. Set server deadlines

The `ReadHeaderTimeout` in the examples above bounds only header reading; add the rest of the `http.Server` deadlines so a slow body, a slow reader, or an idle keep-alive connection cannot hold a goroutine open:

```go
srv := &http.Server{
    Addr:              "127.0.0.1:8080",
    Handler:           mux,
    ReadHeaderTimeout: 10 * time.Second,   // slow-header / Slowloris
    ReadTimeout:       30 * time.Second,   // whole request incl. body
    WriteTimeout:      60 * time.Second,   // slow readers
    IdleTimeout:       60 * time.Second,   // keep-alive between requests
}
```

These are a starting policy for short, bounded requests, not Go defaults. For `ReadTimeout` and `WriteTimeout`, a zero or negative value disables that timeout; for `ReadHeaderTimeout` and `IdleTimeout`, zero instead falls back to `ReadTimeout`, so a negative value disables them, as does zero when `ReadTimeout` is itself zero or negative. Give the port-80 redirect server the same deadlines (the `http.ListenAndServe` helper sets none). For genuinely long uploads or streaming, keep the server defaults generous and set a per-request budget with `http.NewResponseController(w)` (`SetReadDeadline`/`SetWriteDeadline`, Go 1.20+), handling the unsupported-operation error.

## 8. Security headers when Go terminates TLS

Section 2 sets `Strict-Transport-Security` and the rest at the proxy. When Go terminates its own TLS instead, set them in a middleware wrapper that runs before the handler commits the response, and send HSTS only over TLS:

```go
func secure(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("X-Content-Type-Options", "nosniff")
        if r.TLS != nil { w.Header().Set("Strict-Transport-Security", "max-age=63072000; includeSubDomains") }
        next.ServeHTTP(w, r)
    })
}
```

Defer the full header catalogue and values to [headers.md](headers.md); do not send HSTS over plain HTTP. Install it with `srv.Handler = secure(mux)` (or wrap your router); defining the wrapper alone adds no headers. (Go enables HTTP/2 automatically for HTTPS servers, and a `Server.HTTP2` field (`HTTP2Config`) tunes it on current releases, but leave the maintained cipher and curve defaults and the TLS 1.2 minimum from section 1 alone unless you have a specific requirement.)

## 9. Verify (REASONED: TLS, authentication, listener and diagnostic expectations follow the Go Sources below; no deployment run or outcome is recorded in this guide. This metadata-only review has no deployed Go service, proxy or outside-network probe host.)

```bash
(                                       # a subshell, so your own script arguments are untouched
  set +e                                # errexit off here, so a check that ends nonzero is recorded below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_HOST'   # the deployment's public host name, no scheme, user name, port, path, query, fragment, percent sign or trailing dot: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
  case "$1" in
    example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -u nocasematch   # every match below compares letter case exactly again
  set -- "$1" 0                         # the 2nd value is the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 2 (ss or curl is missing, recorded only while nothing else was), which outranks 0
  if command -v curl >/dev/null; then   # a missing curl skips the three requests below and is recorded as a refusal, ranked as above
    curl -q -g -sI "http://$1/"       # expect 301 with a https:// Location
    set -- "$1" "$2" "$?"               # the 3rd value is that request's exit status
    [ "$3" = 0 ] || { echo "curl exit $3: the redirect request failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3; }
    curl -q -g -sI "https://$1/"      # succeeds without -k
    set -- "$1" "$2" "$?"               # the 3rd value is that request's exit status
    [ "$3" = 0 ] || { echo "curl exit $3: the HTTPS request failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3; }
    set -- "$1" "$2" "$(if curl -q -g -sS -o /dev/null -w '%{http_code}\n' "https://$1/api"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}" # curl's exit status, then the HTTP code
    printf '%s\n' "$4"                  # 401 or 403 without credentials
    case "$3:$4" in
      0:401|0:403) ;;
      0:2??) echo "FINDING: /api answered $4 without credentials"; set -- "$1" 1 ;;
      0:*) echo "HTTP $4 from /api is neither the 401 or 403 pass nor a 2xx finding; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
      *) echo "curl exit $3: the /api request failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    esac
  else
    echo "curl is not installed here; not probing the redirect, HTTPS and /api routes"
    case "$2" in 0) set -- "$1" 2 ;; esac
  fi
  if command -v ss >/dev/null; then
    ss -tlnp   # read every listener; REPLACE_WITH_BINARY_NAME: behind a proxy: 127.0.0.1 only
    set -- "$1" "$2" "$?"               # the 3rd value is ss's exit status
    [ "$3" = 0 ] || { echo "ss -tlnp exit $3: the listener list failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3; }
  else
    echo "ss is not installed here; not listing sockets"
    case "$2" in 0) set -- "$1" 2 ;; esac   # the refusal is the block's status only while no other part found something or was inconclusive
  fi
  if command -v curl >/dev/null; then   # a missing curl skips both diagnostic requests below and is recorded as a refusal, ranked as above
    set -- "$1" "$2" "$(if curl -q -g -sS --noproxy '*' -o /dev/null -w '%{http_code}\n' http://127.0.0.1:6060/debug/pprof/; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}" # curl's exit status, then the HTTP code
    printf '%s\n' "$4"                  # local availability only: 200 here just means you enabled a diagnostic listener (section 5). What matters is off-host reachability, checked next.
    case "$3" in
      0) ;;
      7) echo "curl exit 7: nothing answers on loopback port 6060 at 127.0.0.1; the listener list above, if one was printed, shows any 6060 listener on another address" ;;
      *) echo "curl exit $3: the local diagnostic request failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    esac
    set -- "$1" "$2" "$(if curl -q -g -sS -o /dev/null -w '%{http_code}\n' "https://$1/debug/pprof/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}" # curl's exit status, then the HTTP code
    printf '%s\n' "$4"                  # diagnostics must never be routed on your PUBLIC app: expect 404, never 200
    case "$3:$4" in
      0:404) ;;
      0:200) echo "FINDING: /debug/pprof/ answered 200 on your public app"; set -- "$1" 1 ;;
      0:*) echo "HTTP $4 from /debug/pprof/ is neither the 404 pass nor the 200 finding; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
      *) echo "curl exit $3: the /debug/pprof/ request failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    esac
  else
    echo "curl is not installed here; not probing the diagnostic routes"
    case "$2" in 0) set -- "$1" 2 ;; esac
  fi
  echo "block exit $2; the redirect and HTTPS headers, any listener list printed above and the local diagnostic answer are not classified, so judge them yourself"
  exit "$2"
)
```

REASONED: the missing-`ss` and missing-`curl` handling in the block above, per CONTRIBUTING rule 6 and the block's own text. When `command -v ss` finds no `ss`, the block prints `ss is not installed here; not listing sockets`, skips the listener list and still runs its other probes. When `command -v curl` finds no `curl`, the block prints a `curl is not installed here` line for each of its two groups of curl requests, skips those requests and still lists sockets. Either refusal makes the block's status 2 only while no other part has found something or been inconclusive, so a finding still exits 1 and an inconclusive part 3, whether it comes before or after the refusal, and a block that would otherwise pass exits 2, never 0. A `ss` that runs and fails is inconclusive and records 3.

```bash
(                                       # a subshell, so your own script arguments are untouched
  set +e                                # errexit off here, so the probe's status is classified below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_THE_SERVER_PUBLIC_IP'   # replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the server's public address on the set -- line above; not probing"; exit 2 ;;
  esac
  command -v curl >/dev/null || { echo "curl is not installed here; not probing"; exit 2; }
  set -- "$1" "$(if curl -q -g -sS -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 10 \
       -w 'diag_6060 http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "http://$1:6060/debug/pprof/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # run from a machine OUTSIDE the server's network: the diagnostic listener (section 5) must be UNREACHABLE (a refusal or timeout, never a 200)
  set -- "$1" "${2##*$'\n'}" "${2%%$'\n'*}"   # curl's exit status, then its diag_6060 line
  printf '%s\n' "$3"
  case "$3" in
    'diag_6060 http=000 '*)
      case "$2" in
        7|28) set -- "$1" 0 ;;          # a refusal or a timeout: the pass
        *) echo "curl exit $2 is neither a refusal nor a timeout; inconclusive"; set -- "$1" 3 ;;
      esac ;;
    *) echo "FINDING: the diagnostic listener answered HTTP from outside, so it is reachable"; set -- "$1" 1 ;;
  esac
  echo "block exit $2; the err text is not classified: a refusal or timeout passes only if err names the server's address, not a local socket or resolver error, so judge it yourself"
  exit "$2"
)
```

## Sources (checked September 2026)

- net/http (Server, ListenAndServeTLS, Cookie, SameSite, Redirect, Transport.TLSClientConfig): https://pkg.go.dev/net/http
- net/http Request.Host (Go 1.27.0, supplied by the client): https://pkg.go.dev/net/http@go1.27.0#Request
- crypto/tls (Config.MinVersion, InsecureSkipVerify, RootCAs): https://pkg.go.dev/crypto/tls
- crypto/x509 (SystemCertPool, SSL_CERT_FILE, AppendCertsFromPEM) (Go 1.27): https://pkg.go.dev/crypto/x509@go1.27.0
- golang.org/x/crypto/bcrypt: https://pkg.go.dev/golang.org/x/crypto/bcrypt
- golang.org/x/crypto/argon2: https://pkg.go.dev/golang.org/x/crypto/argon2
- golang.org/x/time/rate: https://pkg.go.dev/golang.org/x/time/rate
- go-oidc: https://pkg.go.dev/github.com/coreos/go-oidc/v3/oidc
- net/http/pprof and expvar register on DefaultServeMux: https://pkg.go.dev/net/http/pprof
- net/http MaxBytesReader, MaxBytesError, Server.MaxHeaderBytes / MaxHeaderValueCount (Go 1.27): https://pkg.go.dev/net/http@go1.27.0#MaxBytesReader
- net/http Server timeouts (ReadTimeout, WriteTimeout, IdleTimeout, ReadHeaderTimeout): https://pkg.go.dev/net/http#Server
- net/http ResponseController (per-request deadlines) (Go 1.20+): https://pkg.go.dev/net/http#ResponseController
- expvar (registers /debug/vars on the default mux): https://pkg.go.dev/expvar
- Linux ip-sysctl, ip_unprivileged_port_start (the privileged-port threshold is configurable): https://docs.kernel.org/networking/ip-sysctl.html#ip-unprivileged-port-start
- pquerna/otp TOTP support (v1.5.0, checked October 2026): https://github.com/pquerna/otp/blob/v1.5.0/README.md#L9
- Go environment loading (`go1.27.0`, checked October 2026), Getenv and LookupEnv including unset and empty values; token generation remains delegated to authentication.md: https://github.com/golang/go/blob/go1.27.0/src/os/env.go#L98-L115
- Cloudflare documentation `c896795b8e8bab68d05ae78d64c9cbcda1fdb104`, independent MFA and TOTP/WebAuthn factors (checked October 2026): https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/access-settings/independent-mfa.mdx#L15-L24
- Cloudflare documentation `c896795b8e8bab68d05ae78d64c9cbcda1fdb104`, MFA enforcement, policy precedence and organization-level prerequisite (checked October 2026): https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/policies/mfa-requirements.mdx#L17-L85
- Authelia source `v4.39.28`, single-factor passkey login and password prompt when a request requires MFA (checked October 2026): https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/second-factor/webauthn.md#L69-L75


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- x509: Go certificate-store qualification (1.27)
- headers: Go header-count qualification (1.27)
- deadlines: Go per-request deadline minimum (1.20+)
- request: Go Request.Host source (1.27.0)
- go-env: Go environment source (go1.27.0)
- http: Go net/http documentation (unknown)
- tls: Go crypto/tls documentation (unknown)
- bcrypt: Go bcrypt documentation (unknown)
- argon: Go Argon2 documentation (unknown)
- rate: Go rate documentation (unknown)
- pprof: Go pprof documentation (unknown)
- expvar: Go expvar documentation (unknown)
- oidc: go-oidc documentation (v3)
- otp: pquerna/otp (v1.5.0)
- cf-docs: Cloudflare documentation (c896795b8e8bab68d05ae78d64c9cbcda1fdb104)
- authelia-source: Authelia source (v4.39.28)
- linux: Linux port-threshold documentation (unknown)

Claims (full source mapping in the JSON block below):

- tls (REASONED; http, tls): Direct TLS listens on :443 using the leaf-plus-intermediates certificate and private key; ReadHeaderTimeout is 10 seconds.
- redirect (REASONED; http, request): Port :80 sends a 301 to https:// plus the fixed canonicalHost and an origin-form request path; empty or non-path RequestURI values fall back to /. Never build the destination from r.Host.
- tls-min (REASONED; tls): crypto/tls defaults to TLS 1.2 minimum as of September 2026; explicitly set MinVersion=VersionTLS12.
- privilege (REASONED; linux): Linux privileged-port threshold defaults to 1024 but is configurable per namespace; root or CAP_NET_BIND_SERVICE is needed below it in the usual configuration.
- proxy (REASONED; http): Bind 127.0.0.1:8080 behind a TLS proxy; net/http has no proxy trust setting, so accept forwarded headers only from the isolated, overwriting proxy.
- proxy-headers (REASONED; http): Set HSTS and other security headers at the proxy per the linked headers guide.
- bcrypt (REASONED; bcrypt): Use bcrypt cost 12; DefaultCost is 10, inputs over 72 bytes are rejected and CompareHashAndPassword returns nil on match.
- argon (REASONED; argon): IDKey returns raw bytes; retain random salt and parameters. RFC 9106 choices are time=1/memory=2 GiB/threads=4 or time=3/memory=64 MiB/threads=4.
- cookies (REASONED; http): Set session cookie Path=/, Secure, HttpOnly and SameSite=Lax.
- login-limit (REASONED; rate): A limiter every three seconds with burst five allows about 20/minute; use separate limiters keyed by trusted client address for per-client limits.
- tokens (REASONED; oidc, go-env): Guide advice: load tokens from the environment, never source literals, and generate them per authentication.md; generation stays delegated. Go go1.27.0 Getenv returns an empty string when unset or empty; use LookupEnv's boolean to distinguish them (false when unset, true when present).
- oidc (REASONED; oidc): NewProvider discovers the issuer; Verifier with ClientID checks ID-token signature, issuer, audience and expiry; apply separate allowlists.
- mfa (REASONED; oidc, otp, cf-docs, authelia-source): Guide advice: use app-level TOTP with pquerna/otp v1.5.0 or a fronting layer such as Cloudflare Access or Authelia; follow mfa.md. Configured Access policies or Authelia's MFA-required passkey flow can add a factor; the citations do not establish default MFA or deployed enforcement.
- client-validation (REASONED; tls): InsecureSkipVerify accepts any certificate and hostname unless custom VerifyConnection/VerifyPeerCertificate checks replace validation.
- client-ca (REASONED; tls, x509): Use SystemCertPool plus a checked AppendCertsFromPEM result and RootCAs, or override CA locations with SSL_CERT_FILE/SSL_CERT_DIR.
- platform-ca (REASONED; x509): Go 1.27 certificate-file/directory overrides bypass macOS/Windows platform verification unless GODEBUG=x509sslcertoverrideplatform=0 is also set.
- pprof (REASONED; pprof): Importing pprof registers /debug/pprof/ on DefaultServeMux; profiles, traces, cmdline and forced GC can disclose data or exhaust resources.
- expvar (REASONED; expvar): Importing expvar registers /debug/vars with cmdline and memstats on DefaultServeMux.
- diag-bind (REASONED; http, pprof, expvar): Imports do not start listeners; nil handlers serve DefaultServeMux. Give the app its own mux and diagnostics a separate 127.0.0.1:6060 mux, never public proxy routing.
- body-limit (REASONED; headers): Wrap the body with MaxBytesReader before decoding; the example 1 MiB policy requires explicit MaxBytesError handling to return 413.
- header-size (REASONED; http): MaxHeaderBytes defaults to 1 MiB for request line and headers, independently of body limits.
- header-count (REASONED; headers): Go 1.27 adds MaxHeaderValueCount with default 500; this is separate from body limits.
- read-timeout (REASONED; http): ReadTimeout bounds the whole request including body; example 30 seconds, zero or negative disables it.
- write-timeout (REASONED; http): WriteTimeout bounds writing; example 60 seconds, zero or negative disables it.
- header-timeout (REASONED; http): ReadHeaderTimeout bounds headers; example 10 seconds, zero falls back to ReadTimeout and negative disables it.
- idle-timeout (REASONED; http): IdleTimeout bounds keep-alive idle time; example 60 seconds, zero falls back to ReadTimeout and negative disables it.
- redirect-timeout (REASONED; http): Apply deadlines to the redirect server too; ListenAndServe sets none.
- request-deadlines (REASONED; deadlines): For long uploads/streaming, use generous server budgets and Go 1.20+ ResponseController read/write deadlines, handling unsupported operations.
- headers (REASONED; http): Install secure(mux) before response commit for nosniff and TLS-only HSTS max-age=63072000 with includeSubDomains.
- http2 (REASONED; http, tls): HTTPS enables HTTP/2 automatically; Server.HTTP2 tunes it on current releases; retain maintained cipher/curve defaults.
- verify-redirect (REASONED; http): HTTP should return 301 with an HTTPS Location.
- verify-tls (REASONED; http, tls): HTTPS must succeed without -k.
- verify-auth (REASONED; http): The guide expects /api to return 401/403 without credentials; it records no valid-credential positive control.
- verify-bind (REASONED; http): Inspect every listener for loopback-only application binding behind the proxy.
- verify-diag-local (REASONED; pprof): A local 6060/debug/pprof/ response of 200 establishes local availability only.
- verify-diag-route (REASONED; http, pprof): The public application /debug/pprof/ route should return 404, never 200.
- verify-diag-external (REASONED; http, pprof): From outside the server network, the actual public IP on 6060 must be unreachable; the guide expects refusal or timeout, never 200.
- request-host (REASONED; request): Go 1.27.0 Request.Host is supplied by the client; a fixed canonical hostname plus an origin-form path prevents forged Host or crafted request targets from selecting the redirect destination.

````json
{
  "schema": 1,
  "checked": "2026-10-19",
  "documentation_checked": "2026-09",
  "body_sha256": "27254cf29e129dbd4e9064e104fc8d26a855dbef8f98a4d0568a88e438120347",
  "components": {
    "x509": {
      "name": "Go certificate-store qualification",
      "basis": "1.27",
      "sources": {
        "se65b937f9e1e": "https://pkg.go.dev/crypto/x509@go1.27.0"
      }
    },
    "headers": {
      "name": "Go header-count qualification",
      "basis": "1.27",
      "sources": {
        "sa4a9473fc6f8": "https://pkg.go.dev/net/http@go1.27.0#MaxBytesReader"
      }
    },
    "deadlines": {
      "name": "Go per-request deadline minimum",
      "basis": "1.20+",
      "sources": {
        "s251e0db38b90": "https://pkg.go.dev/net/http#ResponseController"
      }
    },
    "request": {
      "name": "Go Request.Host source",
      "basis": "1.27.0",
      "sources": {
        "sfdeabbeca746": "https://pkg.go.dev/net/http@go1.27.0#Request"
      }
    },
    "go-env": {
      "name": "Go environment source",
      "basis": "go1.27.0",
      "sources": {
        "s41d67ab4a28d": "https://github.com/golang/go/blob/go1.27.0/src/os/env.go#L98-L115"
      }
    },
    "http": {
      "name": "Go net/http documentation",
      "basis": "unknown",
      "sources": {
        "s75405f80decc": "https://pkg.go.dev/net/http",
        "s6ab9e32b7795": "https://pkg.go.dev/net/http#Server"
      }
    },
    "tls": {
      "name": "Go crypto/tls documentation",
      "basis": "unknown",
      "sources": {
        "se2152a9c28fc": "https://pkg.go.dev/crypto/tls"
      }
    },
    "bcrypt": {
      "name": "Go bcrypt documentation",
      "basis": "unknown",
      "sources": {
        "s99bb1157593c": "https://pkg.go.dev/golang.org/x/crypto/bcrypt"
      }
    },
    "argon": {
      "name": "Go Argon2 documentation",
      "basis": "unknown",
      "sources": {
        "s95fa46eac674": "https://pkg.go.dev/golang.org/x/crypto/argon2"
      }
    },
    "rate": {
      "name": "Go rate documentation",
      "basis": "unknown",
      "sources": {
        "s5c3fdae5a0af": "https://pkg.go.dev/golang.org/x/time/rate"
      }
    },
    "pprof": {
      "name": "Go pprof documentation",
      "basis": "unknown",
      "sources": {
        "s0246034dddd1": "https://pkg.go.dev/net/http/pprof"
      }
    },
    "expvar": {
      "name": "Go expvar documentation",
      "basis": "unknown",
      "sources": {
        "se49529035a0c": "https://pkg.go.dev/expvar"
      }
    },
    "oidc": {
      "name": "go-oidc documentation",
      "basis": "v3",
      "sources": {
        "s60cc1d7a8fe6": "https://pkg.go.dev/github.com/coreos/go-oidc/v3/oidc"
      }
    },
    "otp": {
      "name": "pquerna/otp",
      "basis": "v1.5.0",
      "sources": {
        "scdd6f451714e": "https://github.com/pquerna/otp/blob/v1.5.0/README.md#L9"
      }
    },
    "cf-docs": {
      "name": "Cloudflare documentation",
      "basis": "c896795b8e8bab68d05ae78d64c9cbcda1fdb104",
      "sources": {
        "s7e793d13cf31": "https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/access-settings/independent-mfa.mdx#L15-L24",
        "s6f6104362214": "https://github.com/cloudflare/cloudflare-docs/blob/c896795b8e8bab68d05ae78d64c9cbcda1fdb104/src/content/docs/cloudflare-one/access-controls/policies/mfa-requirements.mdx#L17-L85"
      }
    },
    "authelia-source": {
      "name": "Authelia source",
      "basis": "v4.39.28",
      "sources": {
        "s38726e46de86": "https://github.com/authelia/authelia/blob/v4.39.28/docs/content/configuration/second-factor/webauthn.md#L69-L75"
      }
    },
    "linux": {
      "name": "Linux port-threshold documentation",
      "basis": "unknown",
      "sources": {
        "s12e5a0911ec2": "https://docs.kernel.org/networking/ip-sysctl.html#ip-unprivileged-port-start"
      }
    }
  },
  "claims": {
    "tls": {"text": "Direct TLS listens on :443 using the leaf-plus-intermediates certificate and private key; ReadHeaderTimeout is 10 seconds.", "components": ["http", "tls"], "sources": ["http:s75405f80decc", "tls:se2152a9c28fc"], "status": "REASONED"},
    "redirect": {"text": "Port :80 sends a 301 to https:// plus the fixed canonicalHost and an origin-form request path; empty or non-path RequestURI values fall back to /. Never build the destination from r.Host.", "components": ["http", "request"], "sources": ["http:s75405f80decc", "request:sfdeabbeca746"], "status": "REASONED"},
    "tls-min": {"text": "crypto/tls defaults to TLS 1.2 minimum as of September 2026; explicitly set MinVersion=VersionTLS12.", "components": ["tls"], "sources": ["tls:se2152a9c28fc"], "status": "REASONED"},
    "privilege": {"text": "Linux privileged-port threshold defaults to 1024 but is configurable per namespace; root or CAP_NET_BIND_SERVICE is needed below it in the usual configuration.", "components": ["linux"], "sources": ["linux:s12e5a0911ec2"], "status": "REASONED"},
    "proxy": {"text": "Bind 127.0.0.1:8080 behind a TLS proxy; net/http has no proxy trust setting, so accept forwarded headers only from the isolated, overwriting proxy.", "components": ["http"], "sources": ["http:s75405f80decc"], "status": "REASONED"},
    "proxy-headers": {"text": "Set HSTS and other security headers at the proxy per the linked headers guide.", "components": ["http"], "sources": ["http:s75405f80decc"], "status": "REASONED"},
    "bcrypt": {"text": "Use bcrypt cost 12; DefaultCost is 10, inputs over 72 bytes are rejected and CompareHashAndPassword returns nil on match.", "components": ["bcrypt"], "sources": ["bcrypt:s99bb1157593c"], "status": "REASONED"},
    "argon": {"text": "IDKey returns raw bytes; retain random salt and parameters. RFC 9106 choices are time=1/memory=2 GiB/threads=4 or time=3/memory=64 MiB/threads=4.", "components": ["argon"], "sources": ["argon:s95fa46eac674"], "status": "REASONED"},
    "cookies": {"text": "Set session cookie Path=/, Secure, HttpOnly and SameSite=Lax.", "components": ["http"], "sources": ["http:s75405f80decc"], "status": "REASONED"},
    "login-limit": {"text": "A limiter every three seconds with burst five allows about 20/minute; use separate limiters keyed by trusted client address for per-client limits.", "components": ["rate"], "sources": ["rate:s5c3fdae5a0af"], "status": "REASONED"},
    "tokens": {"text": "Guide advice: load tokens from the environment, never source literals, and generate them per authentication.md; generation stays delegated. Go go1.27.0 Getenv returns an empty string when unset or empty; use LookupEnv's boolean to distinguish them (false when unset, true when present).", "components": ["oidc", "go-env"], "sources": ["oidc:s60cc1d7a8fe6", "go-env:s41d67ab4a28d"], "status": "REASONED"},
    "oidc": {"text": "NewProvider discovers the issuer; Verifier with ClientID checks ID-token signature, issuer, audience and expiry; apply separate allowlists.", "components": ["oidc"], "sources": ["oidc:s60cc1d7a8fe6"], "status": "REASONED"},
    "mfa": {"text": "Guide advice: use app-level TOTP with pquerna/otp v1.5.0 or a fronting layer such as Cloudflare Access or Authelia; follow mfa.md. Configured Access policies or Authelia's MFA-required passkey flow can add a factor; the citations do not establish default MFA or deployed enforcement.", "components": ["oidc", "otp", "cf-docs", "authelia-source"], "sources": ["oidc:s60cc1d7a8fe6", "otp:scdd6f451714e", "cf-docs:s7e793d13cf31", "cf-docs:s6f6104362214", "authelia-source:s38726e46de86"], "status": "REASONED"},
    "client-validation": {"text": "InsecureSkipVerify accepts any certificate and hostname unless custom VerifyConnection/VerifyPeerCertificate checks replace validation.", "components": ["tls"], "sources": ["tls:se2152a9c28fc"], "status": "REASONED"},
    "client-ca": {"text": "Use SystemCertPool plus a checked AppendCertsFromPEM result and RootCAs, or override CA locations with SSL_CERT_FILE/SSL_CERT_DIR.", "components": ["tls", "x509"], "sources": ["tls:se2152a9c28fc", "x509:se65b937f9e1e"], "status": "REASONED"},
    "platform-ca": {"text": "Go 1.27 certificate-file/directory overrides bypass macOS/Windows platform verification unless GODEBUG=x509sslcertoverrideplatform=0 is also set.", "components": ["x509"], "sources": ["x509:se65b937f9e1e"], "status": "REASONED"},
    "pprof": {"text": "Importing pprof registers /debug/pprof/ on DefaultServeMux; profiles, traces, cmdline and forced GC can disclose data or exhaust resources.", "components": ["pprof"], "sources": ["pprof:s0246034dddd1"], "status": "REASONED"},
    "expvar": {"text": "Importing expvar registers /debug/vars with cmdline and memstats on DefaultServeMux.", "components": ["expvar"], "sources": ["expvar:se49529035a0c"], "status": "REASONED"},
    "diag-bind": {"text": "Imports do not start listeners; nil handlers serve DefaultServeMux. Give the app its own mux and diagnostics a separate 127.0.0.1:6060 mux, never public proxy routing.", "components": ["http", "pprof", "expvar"], "sources": ["http:s75405f80decc", "pprof:s0246034dddd1", "expvar:se49529035a0c"], "status": "REASONED"},
    "body-limit": {"text": "Wrap the body with MaxBytesReader before decoding; the example 1 MiB policy requires explicit MaxBytesError handling to return 413.", "components": ["headers"], "sources": ["headers:sa4a9473fc6f8"], "status": "REASONED"},
    "header-size": {"text": "MaxHeaderBytes defaults to 1 MiB for request line and headers, independently of body limits.", "components": ["http"], "sources": ["http:s75405f80decc"], "status": "REASONED"},
    "header-count": {"text": "Go 1.27 adds MaxHeaderValueCount with default 500; this is separate from body limits.", "components": ["headers"], "sources": ["headers:sa4a9473fc6f8"], "status": "REASONED"},
    "read-timeout": {"text": "ReadTimeout bounds the whole request including body; example 30 seconds, zero or negative disables it.", "components": ["http"], "sources": ["http:s6ab9e32b7795"], "status": "REASONED"},
    "write-timeout": {"text": "WriteTimeout bounds writing; example 60 seconds, zero or negative disables it.", "components": ["http"], "sources": ["http:s6ab9e32b7795"], "status": "REASONED"},
    "header-timeout": {"text": "ReadHeaderTimeout bounds headers; example 10 seconds, zero falls back to ReadTimeout and negative disables it.", "components": ["http"], "sources": ["http:s6ab9e32b7795"], "status": "REASONED"},
    "idle-timeout": {"text": "IdleTimeout bounds keep-alive idle time; example 60 seconds, zero falls back to ReadTimeout and negative disables it.", "components": ["http"], "sources": ["http:s6ab9e32b7795"], "status": "REASONED"},
    "redirect-timeout": {"text": "Apply deadlines to the redirect server too; ListenAndServe sets none.", "components": ["http"], "sources": ["http:s75405f80decc", "http:s6ab9e32b7795"], "status": "REASONED"},
    "request-deadlines": {"text": "For long uploads/streaming, use generous server budgets and Go 1.20+ ResponseController read/write deadlines, handling unsupported operations.", "components": ["deadlines"], "sources": ["deadlines:s251e0db38b90"], "status": "REASONED"},
    "headers": {"text": "Install secure(mux) before response commit for nosniff and TLS-only HSTS max-age=63072000 with includeSubDomains.", "components": ["http"], "sources": ["http:s75405f80decc"], "status": "REASONED"},
    "http2": {"text": "HTTPS enables HTTP/2 automatically; Server.HTTP2 tunes it on current releases; retain maintained cipher/curve defaults.", "components": ["http", "tls"], "sources": ["http:s75405f80decc", "tls:se2152a9c28fc"], "status": "REASONED"},
    "verify-redirect": {"text": "HTTP should return 301 with an HTTPS Location.", "components": ["http"], "sources": ["http:s75405f80decc"], "status": "REASONED", "verify": [1]},
    "verify-tls": {"text": "HTTPS must succeed without -k.", "components": ["http", "tls"], "sources": ["http:s75405f80decc", "tls:se2152a9c28fc"], "status": "REASONED", "verify": [1]},
    "verify-auth": {"text": "The guide expects /api to return 401/403 without credentials; it records no valid-credential positive control.", "components": ["http"], "sources": ["http:s75405f80decc"], "status": "REASONED", "verify": [1]},
    "verify-bind": {"text": "Inspect every listener for loopback-only application binding behind the proxy.", "components": ["http"], "sources": ["http:s75405f80decc"], "status": "REASONED", "verify": [1]},
    "verify-diag-local": {"text": "A local 6060/debug/pprof/ response of 200 establishes local availability only.", "components": ["pprof"], "sources": ["pprof:s0246034dddd1"], "status": "REASONED", "verify": [1]},
    "verify-diag-route": {"text": "The public application /debug/pprof/ route should return 404, never 200.", "components": ["http", "pprof"], "sources": ["http:s75405f80decc", "pprof:s0246034dddd1"], "status": "REASONED", "verify": [1]},
    "verify-diag-external": {"text": "From outside the server network, the actual public IP on 6060 must be unreachable; the guide expects refusal or timeout, never 200.", "components": ["http", "pprof"], "sources": ["http:s75405f80decc", "pprof:s0246034dddd1"], "status": "REASONED", "verify": [2]},
    "request-host": {"text": "Go 1.27.0 Request.Host is supplied by the client; a fixed canonical hostname plus an origin-form path prevents forged Host or crafted request targets from selecting the redirect destination.", "components": ["request"], "sources": ["request:sfdeabbeca746"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
