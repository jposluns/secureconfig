# Mosquitto (MQTT): no anonymous clients, TLS listener

Mosquitto is an MQTT broker: devices and programs publish short messages to named topics, and it passes them to whoever has subscribed. This guide helps your AI assistant make sure it is configured securely, including credentials for each device, no anonymous clients, a TLS listener, and access checked per topic.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/mosquitto.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Mosquitto v2.0.22 and v2.1.2 and Mosquitto legacy v1.6.15; 2 further sources are pinned to a commit and 2 carry no recorded version. Metadata reviewed 2026-10-05; documentation checked October 2026. The guide records 45 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

MQTT brokers back IoT and agent projects, and open brokers leak live telemetry and accept injected commands. Mosquitto's defaults are sane on version 2.0 and later (with a listener defined, anonymous access is off; without any listener it binds the loopback interface only); the job is to keep them sane while adding real listeners.

The no-listener loopback mode allows anonymous clients by default; it is not authenticated. Defining an explicit listener in 2.0 changes the default to rejecting clients unless authentication is configured. See [migrating to 2.0](https://mosquitto.org/documentation/migrating-to-2-0/).

The official Docker images do not all keep those defaults. The `latest`, `2`, `alpine`, `2.1-alpine` and `2.1.2-alpine` tags (Mosquitto 2.1.2 at the pinned library commit) ship their own `/mosquitto/config/mosquitto.conf`: `listener 1883` with `allow_anonymous true`, and `listener 9883` with `protocol http_api`. The 9883 listener in those tags serves the web dashboard and a read-only HTTP API (JSON from `/api/v1/systree` and `/api/v1/listeners`, and the version as plain text from `/api/v1/version`). Neither listener names an address, so the MQTT listener binds the IPv4 wildcard, and the IPv6 one where the container has IPv6, and the HTTP API listener starts on a single dual-stack socket. Both listeners as shipped, with no password file, authentication plugin or ACL, serve clients that give no credentials. Anything that can reach the container on 9883 (another container on its network, a published port, or host networking) therefore gets broker statistics and listener details without a login. The `1.6-openssl` and `1.6.15-openssl` tags ship upstream's configuration, every line commented, so 1.6's defaults apply: a listener on 1883 with no address, on the IPv4 wildcard and the IPv6 one where available, that allows anonymous clients. The 2.0 tags (`2.0`, `2.0.22`, `2.0-openssl`, `2.0.22-openssl`, `2-openssl` and `openssl`; Mosquitto 2.0.22) ship upstream's 2.0.22 configuration, also every line commented, and keep 2.0's loopback-only default. To use one of the 2.1 or 1.6 images, mount your own `/mosquitto/config/mosquitto.conf` (or give the container a whole `mosquitto -c <file>` command naming another) that sets `allow_anonymous false` and a password file and drops the 9883 listener or binds it to `127.0.0.1`, and publish 1883 only to host loopback or a private network.

The file-based examples below target Mosquitto 2.0.22 and remain available, but deprecated, in 2.1. At the time of writing, `password_file`, `acl_file`, and `per_listener_settings` are deprecated in 2.1, with removal announced for 3.0. Plan migration to the password-file and ACL-file plugins; section 5 identifies the listener-policy replacements. See the [2.1 release notes](https://mosquitto.org/blog/2026/01/version-2-1-0-released/).

## 1. Credentials per device

Use the `mosquitto_passwd` shipped with your broker version. These commands prompt for passwords; do not use its batch option to put passwords in command arguments. Run the first command only when creating the password file: `-c` overwrites an existing file.

```bash
sudo mosquitto_passwd -c /etc/mosquitto/passwd device-01     # -c only the first time
sudo mosquitto_passwd /etc/mosquitto/passwd device-02
```

`/etc/mosquitto/conf.d/secure.conf`:

```
per_listener_settings false
allow_anonymous false
password_file /etc/mosquitto/passwd
```

One credential per device, so a leaked unit can be revoked alone; add an `acl_file` to limit each identity to its own topics.

`per_listener_settings false` is valid when all listeners deliberately share authentication and ACL policy. It is deprecated in 2.1 along with `true`; changing the boolean is not the migration. For separate policies on 2.0, use the complete alternative in section 5.

To remove a compromised device, substitute the password-file path and its MQTT username inside the quotes, then paste the whole block:

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_PASSWORD_FILE' 'REPLACE_WITH_REVOKED_USERNAME'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not changing anything"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "provide exactly 2 values; not changing anything"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the password-file path"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the revoked username"; exit 2 ;;
    *) sudo mosquitto_passwd -D "$1" "$2" ;;
  esac
)
```

`mosquitto_passwd -D` edits the file; it does not terminate existing connections or update the running broker's loaded credentials. Reload the broker with SIGHUP through your deployment's service-management procedure so new authentication uses the changed file. Incident response also needs connection termination, or a controlled broker restart, and confirmation that the revoked identity cannot reconnect. See [password-file authentication and reload](https://mosquitto.org/documentation/authentication-methods/) and [mosquitto_passwd](https://mosquitto.org/man/mosquitto_passwd-1.html).

Do not assume uniform connection handling on reload: the `password_file` manual says connected clients are unaffected, while the [2.0.22 implementation](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/security_default.c) rechecks connected credentials and disconnects failures. File deletion alone is not connection termination; confirm termination on the deployed version and authentication backend.

## 2. TLS listener

```
listener 8883
cafile   /etc/mosquitto/tls/ca.pem
certfile /etc/mosquitto/tls/server.pem
keyfile  /etc/mosquitto/tls/server.key
# mutual TLS: clients must present certificates
# require_certificate true
```

Port 8883 is the conventional MQTT-over-TLS port. Certificates per [self-signed.md](self-signed.md) (an internal CA suits device fleets) or [free-certificates.md](free-certificates.md). `require_certificate true` makes a client certificate a possession factor for the connecting device, stronger than a password alone but not MFA for a person ([mfa.md](mfa.md)). Remove or firewall any plaintext `listener 1883` that is not strictly local. These snippets take effect only if the running broker loads `/etc/mosquitto/conf.d/` (confirm `include_dir` in the active config); a `listener` change is not applied on a reload signal, so restart the broker and check its startup log after editing.

## 3. Authorize topics, not just connections

Password authentication alone does not restrict topics: without ACLs or another authorization mechanism, authenticated clients can read and write every application topic. Add this to the shared-policy configuration in section 1:

```
acl_file /etc/mosquitto/acl
```

A complete `/etc/mosquitto/acl` for two devices and a separate command controller:

```
# Rules before the first user apply only to anonymous clients.
topic deny $SYS/#

user device-01
topic deny $SYS/#
topic read fleet/device-01/telemetry/#
topic write fleet/device-01/telemetry/#
topic read fleet/device-01/commands/#

user device-02
topic deny $SYS/#
topic read fleet/device-02/telemetry/#
topic write fleet/device-02/telemetry/#
topic read fleet/device-02/commands/#

user controller
topic deny $SYS/#
topic write fleet/device-01/commands/#
topic write fleet/device-02/commands/#
```

Create the controller's separate credential at the password prompt:

```bash
sudo mosquitto_passwd /etc/mosquitto/passwd controller
```

Unlisted access is denied. `user` names the MQTT username, not the client id. A `topic` rule before any `user` applies to anonymous clients, not every user; that is why the explicit `$SYS` denial is repeated under each identity. Reload after changing the password or ACL file. See the [ACL-file syntax](https://mosquitto.org/documentation/plugins/acl-file/) and [authentication reload instructions](https://mosquitto.org/documentation/authentication-methods/).

For a uniform fleet, replace the device-specific telemetry and command-read grants with these patterns, retaining the controller's explicit grants and the `$SYS` deny entries:

```
pattern read fleet/%u/telemetry/#
pattern write fleet/%u/telemetry/#
pattern read fleet/%u/commands/#
```

Patterns apply to all users, regardless of preceding `user` lines. `%u` substitutes the username; `%c` substitutes the client id. Each substitution must occupy a whole topic level: `fleet/%u/telemetry/#` is valid; embedding `%u` inside a level is not. Prefer authenticated `%u` because a client ordinarily chooses its own client id. Provision usernames as single topic levels. See [pattern ACLs](https://mosquitto.org/documentation/plugins/acl-file/).

Keep `$SYS`, the broker's telemetry hierarchy, ungranted to devices. `topic deny $SYS/#` makes that decision explicit for each listed user; it is not a global denial merely because it appears at the top of the file. `deny` was added in 2.0. Subscribing to `#` does not include `$SYS`; testing telemetry isolation requires an explicit `$SYS/#` subscription. See the [2.0 release notes](https://mosquitto.org/blog/2020/12/version-2-0-0-released/) and [broker status and wildcard subscriptions](https://mosquitto.org/man/mosquitto-8.html).

File ACLs filter message access, not SUBSCRIBE requests. An accepted `#` subscription is not by itself an ACL bypass. Test actual delivery and rejected writes with matched authorized delivery, as in Verify. This distinction is explicit in the [2.0.22 built-in ACL implementation](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/security_default.c) and [2.1.2 ACL-file plugin](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/plugins/acl-file/acl_check.c).

## 4. Bound resource use

Authentication does not stop a compromised device exhausting the broker. These defaults were checked against the versioned configuration and source at the time of writing:

| Option | Scope | Default |
| --- | --- | --- |
| `max_connections` | Per listener | `-1`, unlimited by this setting |
| `max_packet_size` | Global; incoming MQTT packet size | Unset in 2.0.22, with no configured cap; 2,000,000 bytes in 2.1 |
| `message_size_limit` | Global; PUBLISH payload size | `0`, no configured payload limit |
| `max_inflight_messages` | Global setting, enforced per client for outgoing QoS 1/2 messages | `20` |
| `max_queued_messages` | Global setting, enforced per client above inflight messages | `1000` in 2.x; `100` before 2.0 |
| `max_queued_bytes` | Global setting, enforced per client for queued outgoing messages | `0`, unlimited by this setting |
| `max_keepalive` | Global; client keepalive ceiling in seconds | `0` in 2.0.22 and 2.1.2, permitting unlimited keepalive |

Sources: [2.0.22 configuration](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/mosquitto.conf), [2.0.22 initialized defaults](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/conf.c), [2.1.2 initialized defaults](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/src/conf.c), and [the 2.0 queue-default change](https://mosquitto.org/blog/2020/12/version-2-0-0-released/). The 2.0.22 sample configuration's `max_keepalive 65535` commentary is stale; the implementation initializes it to `0`. Do not copy the sample's commented `max_packet_size 0` as an explicit setting: the parser requires a configured value of at least 20.

Illustrative global values:

```
max_packet_size 65536
message_size_limit 32768
max_inflight_messages 10
max_queued_messages 100
max_queued_bytes 1048576
max_keepalive 60
```

Within each explicit listener's configuration, choose a connection limit, for example:

```
max_connections 200
```

These are values to size against real traffic, client counts, reconnect behaviour, and available memory, not universal safe limits. Packet budgets need room for topic names and protocol overhead as well as payloads.

On 2.0.22 TCP listeners, `max_packet_size` rejects oversized packets before incoming-body allocation in the [packet reader](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/lib/packet_mosq.c). The [2.0.22 WebSockets receive callback](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/websockets.c) instead allocates the declared MQTT body without checking this limit before dispatch. The [2.1.2 libwebsockets callback](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/src/websockets.c) retains this allocation gap; do not generalize across WebSockets implementations. TLS termination does not fix it. Disable affected WebSockets listeners unless an independent boundary enforces the MQTT declared packet length before forwarding it, or use an implementation whose allocation bound has been demonstrated.

`message_size_limit` rejects an oversized PUBLISH without forwarding it, while completing the QoS 1/2 acknowledgement flow; it is not a packet-allocation defence. The [PUBLISH handler](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/handle_publish.c) checks the payload after packet reception.

Queue limits can cause message loss. When both queue limits are set, the first reached limits further queuing. Inflight limits bound concurrent outstanding delivery, not messages per second. A positive `max_keepalive` supplies a server override to MQTT 5 clients requesting an excessive interval; MQTT 3.1.1 clients requesting an incompatible interval are refused with identifier-rejected. Keepalive does not disconnect a client that keeps sending traffic. See the [resource-limit reference](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/man/mosquitto.conf.5.xml).

Mosquitto 2.1 adds these optional global controls; do not put them in a 2.0 configuration:

```
global_max_connections 500
global_max_clients 1000
```

Both default to `-1`. The first bounds connected clients across listeners; the second also counts disconnected persistent sessions. A connection cap alone does not bound that session population. See [global connection and session limits](https://mosquitto.org/man/mosquitto-conf-5.html).

On 2.0, repeatedly connecting with different IDs and leaving persistent sessions can grow broker state despite connection and per-client queue limits. Restrict the allowed identities and client IDs. Choose a global expiration policy, for example `persistent_client_expiration 14d`, to remove sessions that remain disconnected beyond that interval. Expiration is not a hard population cap. See the [2.0.22 expiration reference](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/man/mosquitto.conf.5.xml) and [expiry implementation](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/session_expiry.c).

## 5. Scope every listener, including WebSockets

An explicit `listener 1883` without a bind address listens on all interfaces. The no-listener loopback default does not carry over. Omit plaintext MQTT unless needed locally; if needed, use `listener 1883 127.0.0.1`. `bind_address` is deprecated and affects only the implicit default listener. See [2.0 listener changes](https://mosquitto.org/documentation/migrating-to-2-0/) and the [listener reference](https://mosquitto.org/man/mosquitto-conf-5.html).

For separate policies on 2.0, replace the shared authentication and listener snippets with this alternative; do not append it to them. Put `per_listener_settings true` before every listener and before other security settings, including settings in earlier included files. Create each referenced password and ACL file using the formats above.

```
per_listener_settings true

listener 8883
allow_anonymous false
password_file /etc/mosquitto/passwd
acl_file /etc/mosquitto/acl
cafile   /etc/mosquitto/tls/ca.pem
certfile /etc/mosquitto/tls/server.pem
keyfile  /etc/mosquitto/tls/server.key
# require_certificate true
max_connections 200

# Optional local plaintext MQTT; omit this entire listener if unnecessary.
listener 1883 127.0.0.1
allow_anonymous false
password_file /etc/mosquitto/passwd-local
acl_file /etc/mosquitto/acl-local
max_connections 20

# Optional local WebSockets; requires a build with WebSockets support.
listener 9001 127.0.0.1
protocol websockets
allow_anonymous false
password_file /etc/mosquitto/passwd-ws
acl_file /etc/mosquitto/acl-ws
max_connections 20
```

Do not merely flip the original `false` to `true`: move each listener's `allow_anonymous`, `password_file`, and `acl_file` into its scope. Keep its TLS directives after that listener as well. The ordering requirement is enforced by the [2.0.22 configuration parser](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/conf.c).

The WebSockets example is local plaintext transport. A public WebSockets endpoint needs TLS plus its own authentication and ACL policy. For broker-terminated TLS, configure `cafile`, `certfile`, and `keyfile` on that WebSockets listener as in section 2, with certificates for its real endpoint. A TLS-terminating proxy must keep the backend private. Do not assume the MQTT listener's TLS configuration protects a separate WebSockets listener. See [protocol and WebSockets TLS settings](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/man/mosquitto.conf.5.xml).

On 2.0.22 WebSockets listeners, `max_connections` is ineffective: the [establishment callback](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/websockets.c) checks `client_count` without incrementing it. The example's `max_connections 20` therefore does not enforce a WebSockets connection cap. Require an independently enforced concurrent-connection limit with no backend bypass, or a version and WebSockets implementation whose cap is demonstrated. The [2.1.2 ChangeLog](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/ChangeLog.txt) records the libwebsockets fix for issue #3455 under 2.1.1; verify the deployed build across disconnect/reconnect cycles. TLS alone supplies neither this cap nor the packet-allocation protection missing in section 4.

Listeners are not separate topic or session namespaces. With per-listener settings, a disconnected persistent client retains the ACL policy of the listener it most recently used. See [per-listener policy behaviour](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/mosquitto.conf).

A valid password does not authorize a client ID: [2.0.22 duplicate-ID handling](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/handle_connect.c) can disconnect another device when a client authenticates with its own credentials but supplies that device's ID. For one connection per identity, set `use_username_as_clientid true` on every applicable listener. It replaces the supplied ID with the authenticated username; a second connection with that username displaces the first. Usernames must identify the same principal globally across all listeners and authentication stores, never different devices. Every other listener must also prevent unauthorized use of those IDs. If multiple connections per identity are needed, require authenticated client-ID authorization before session takeover, with a bounded set of IDs per identity; topic ACLs alone do not provide it. See the [2.0.22 mosquitto.conf(5) entry](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/man/mosquitto.conf.5.xml): this option is per listener and requires a restart, not SIGHUP.

In 2.1, replace `per_listener_settings` with explicit listener policy: `listener_allow_anonymous` controls anonymous access, and `plugin_load` plus `plugin_use` loads and attaches authentication/ACL plugins to selected listeners. Use the `mosquitto_password_file` and `mosquitto_acl_file` plugins for the corresponding file-based controls. Follow the vendor's [replacement procedure](https://mosquitto.org/documentation/listeners/per-listener-settings/); this is a configuration migration, not a boolean change.

## 6. Secure bridges when present

A bridge creates another route into and out of the topic tree. Configure TLS explicitly; putting `:8883` in `address` does not enable bridge TLS.

Store this connection stanza in a protected configuration file loaded by the broker:

```
connection site-01-upstream
address upstream.example.com:8883
bridge_cafile /etc/mosquitto/tls/upstream-ca.pem
bridge_insecure false
remote_username bridge-site-01
remote_password REPLACE_WITH_REMOTE_BRIDGE_PASSWORD
topic fleet/device-01/telemetry/# out 1
topic fleet/device-01/commands/# in 1
try_private true
restart_timeout 10 60
notifications false
# If the remote broker requires a client certificate:
# bridge_certfile /etc/mosquitto/tls/bridge-client.pem
# bridge_keyfile /etc/mosquitto/tls/bridge-client.key
```

`out` forwards local telemetry to the remote broker; `in` brings remote commands into the local broker. Avoid broad `topic # both` forwarding. Require a trusted upstream: locally configured bridge contexts bypass local ACL checks in [2.0.22](https://github.com/eclipse-mosquitto/mosquitto/blob/v2.0.22/src/security.c#L691-L693) and [2.1.2](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/src/plugin_acl_check.c). Bridge topic declarations control routing and subscriptions, not a local ingress ACL; the [2.1.2 incoming remapper](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/src/bridge_topic.c) returns success for unmatched topics. Neither these declarations nor the remote account's ACL contains a malicious upstream. If upstream trust is insufficient, replace the direct bridge with an independently enforced boundary, such as an isolated gateway that republishes only allowed topics through an ordinary authenticated client subject to the local broker's ACL.

On the trusted remote broker, give this dedicated username only the matching permissions:

```
user bridge-site-01
topic deny $SYS/#
topic write fleet/device-01/telemetry/#
topic read fleet/device-01/commands/#
```

`bridge_insecure false` keeps hostname verification enabled. `try_private true` identifies a bridge to peers that support it, helping loop detection and retained-message handling; it is not authentication. `restart_timeout 10 60` uses reconnect backoff rather than an immediate retry loop. `notifications false` suppresses the bridge's default `$SYS` status publications, so this example needs no `$SYS` write grant. Monitor bridge health through protected logs.

The remote password is plaintext in the configuration file. Restrict that file and its backups as credentials; there is no universal credential-redaction switch to rely on. Add `bridge_certfile` and `bridge_keyfile` only when the remote requires a client certificate.

Syntax and behaviour: [bridge configuration and TLS options](https://mosquitto.org/man/mosquitto-conf-5.html) and the [2.0.22 bridge configuration reference](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/mosquitto.conf).

## 7. Protect the runtime account and files

Use a dedicated runtime account. For a deployment that intentionally enables built-in persistence:

```
user mosquitto
persistence true
persistence_location /var/lib/mosquitto/
log_dest file /var/log/mosquitto/mosquitto.log
```

`persistence_location` only sets the path; persistence defaults to `false`. The example explicitly enables it. When started as root on POSIX systems, `user mosquitto` drops privileges; it does not change the account of an already unprivileged process. Ensure the account exists. See [`user`, persistence, and file logging](https://mosquitto.org/man/mosquitto-conf-5.html).

Protect persistence data, logs, password files, ACL files, TLS private keys, and bridge configuration containing `remote_password`. As deployment guidance, use 0700 private directories and 0600 sensitive files, owned by the account that must access them; these are filesystem modes, not Mosquitto directives. Account for parent-directory traversal and protect backups and log rotation output too. The broker needs to read credentials, ACLs, certificates, and keys, and write its persistence and log locations.

Mosquitto 2.0 drops privileges immediately after reading configuration, earlier than 1.x. Root-readable files alone are therefore insufficient: the required paths must be accessible to the runtime account after the drop. See [privilege-drop changes](https://mosquitto.org/documentation/migrating-to-2-0/).

## 8. Verify

**REASONED:** whole Verify section; every service comparison below rests on the Sources entries cited at that comparison, and no exposed or fixed broker behaviour has been observed. The October 2026 marking pass also had no Mosquitto broker or client binaries, no container runtime and no network access; it ran only the shell, guard, stub, Python file-mode and shlex, and OpenSSL fixture checks recorded at the units below that record them, and none of them exercised Mosquitto. Those checks ran the section 1 credential-removal block in an earlier form, whose guard refusals exited with status 1; none was re-run on that block's current form, whose guard refusals exit with status 2. They also ran the connection, observer and publisher blocks in an earlier form, whose guard refusals exited with status 1, and the section 8 listener checks, then one block, in an earlier form whose guard refusals left the subshell with status 0. The current forms of those checks, now five blocks, exit 2 on a guard refusal and otherwise with one status for each block; they are covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes, and no stub run of them is recorded here. This guide's service checks are **REASONED, not demonstrated**. The authoring environment has no Mosquitto broker or client binaries, container runtime, deployment credentials, or external test hosts. Filesystem and network restrictions prevent provisioning a live comparison here. Exposed/fixed behaviour is REASONED from the cited documentation and pinned sources; broker configuration acceptance remains unconfirmed.

**REASONED:** run provenance for this section's local checks, none of which exercised Mosquitto. The last four sentences of this paragraph record the original authoring pass, whose counts this marking pass did not rerun. Separately, in the October 2026 marking pass, with no Mosquitto broker or client binaries in the authoring environment, `bash -n` and ShellCheck 0.11.0 printed nothing for each of the four bash blocks this section then had, and under Bash 5.3.9 each block ran against stub `mosquitto_sub`, `mosquitto_pub`, `nc` and `ss` commands that print their arguments. The output of each October 2026 marking-pass run is recorded at the unit covering the block that the run exercised. For the listener checks, then one block, the runs recorded in this paragraph, in the marking pass and in the original authoring pass, used an earlier form, whose guard refusals left the subshell with status 0. For the section 1 credential-removal block, the runs recorded in this paragraph used an earlier form, whose guard refusals exited with status 1; none was re-run on that block's current form, whose guard refusals exit with status 2. For the connection, observer and publisher blocks, they used an earlier form, whose guard refusals exited with status 1. The current forms of the connection, listener-inventory, listener-probe, observer and publisher blocks are covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. Local validation covered all seven fenced shell blocks with `bash -n`, ShellCheck 0.11.0, and the repository's strict guard-convention scanner. Guard-only tests rejected 90 invalid positional inputs; five substituted controls reached local markers. These checks exercised shell behaviour, not Mosquitto. No repository files were changed and the whole-corpus gate suite was not run.

**REASONED:** client-version guidance for every client command below; no Mosquitto 2.0 or 2.1 client binaries in the authoring environment, so how a client treats `-o` and its default configuration was not observed, per the guide's cited mosquitto_sub manual and Mosquitto publisher manual (protected configuration files) entries. Locally, each of the 16 stubbed `mosquitto_sub` and `mosquitto_pub` calls made in this marking pass received `-o` followed by the protected configuration path. Those calls came from runs of the connection, observer and publisher blocks in an earlier form, whose guard refusals exited with status 1; their current forms, which still pass `-o` with the protected configuration path, are covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. Expected, from this paragraph and the connection block's comments: a 2.1 client given `-o` skips the default client configuration, so a default file carrying credentials, a SOCKS proxy or `--insecure` cannot change the result; a 2.0 client has no `-o`, so there an unchecked default file can. Use Mosquitto 2.1 client tools for the commands below, including when testing a 2.0 broker. Their `-o` option selects an explicit configuration file and skips the default client configuration. On 2.0 clients, use protected default configuration files in isolated test accounts instead; `-o` is unavailable. See [client configuration files](https://mosquitto.org/man/mosquitto_sub-1.html).

**REASONED:** paste, quoting and credential handling for every block below; no Mosquitto client binaries in the authoring environment, per the guide's cited mosquitto_sub manual and Mosquitto publisher manual (protected configuration files) entries. Locally, none of the 16 stubbed `mosquitto_sub` and `mosquitto_pub` calls received `-P` or the password placeholder, since each took its identity from a protected file through `-o`, and every block refused a paste without its `set --` line even with caller arguments present, as recorded at each block. For the listener checks, then one block, the recorded refusal runs used an earlier form, whose guard refusals left the subshell with status 0. For the connection, observer and publisher blocks, the runs recorded here used an earlier form, whose guard refusals exited with status 1. The current forms of those blocks, in which every guard refusal exits with status 2, are covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. In the observer block, a configuration path with its apostrophe escaped as `'\''` inside the quotes reached the stub as one argument ending `it's.conf`, while the same apostrophe left raw made bash print an "unexpected EOF while looking for matching" error and exit 2 without calling the stub. Expected, from this paragraph: credentials stay in the protected files and out of command arguments, shell history and recordings; a password passed as a command argument is the case this paragraph rules out. Paste whole blocks and substitute inside the single quotes. A literal apostrophe needs proper shell escaping. Keep credentials out of command arguments, shell history, recordings, and debug-log sharing. The `-P` line in the example below belongs in the protected file, not the shell.

**REASONED:** preparation of the protected client configuration files; no Mosquitto client binaries in the authoring environment, so no client read these files, per the guide's cited mosquitto_sub manual and Mosquitto publisher manual (protected configuration files) entries. Locally, Python created a mode 0700 directory holding `device-01.conf`, `device-02.conf` and `controller.conf`, each written with mode 0600 from the two lines below with its identity substituted and the password placeholder left in place, and an empty mode 0600 `anonymous.conf`; `os.stat` reported those modes. Expected, from this paragraph: each identity's password stays in its owner-readable file and off every command line; a file other accounts can read would expose it. Prepare an owner-readable file, mode 0600 inside a private directory, for each test identity; the two-line block after the next paragraph is `device-01.conf`.

**REASONED:** following block; covers its two protected client credential configuration lines and the further test configurations this paragraph describes. No Mosquitto client binaries, broker, client-certificate deployment or other deployment fixtures in the authoring environment, so no client parsed these files, per the guide's cited mosquitto_sub manual (`-u`/`-P`, `--cert`/`--key`) and mosquitto.conf manual (require_certificate) entries. Locally, Python's `shlex`, which is not the client's parser, split each of the block's two lines into one option and one value. The local test files were created as the preparation paragraph above records. The local mode 0600 `device-01-mtls.conf` and `anonymous-mtls.conf` variants added `--cert` and `--key` lines naming a throwaway client certificate made with OpenSSL 3.5.5. A local `openssl verify` against the throwaway CA printed `client.pem: OK` for that throwaway client certificate, and the certificate's public key matched its key file. A local `openssl verify` against the throwaway CA printed `error 18 at 0 depth lookup: self-signed certificate` for a self-signed certificate outside that CA. Expected: the anonymous configuration, carrying no username or password, is refused at CONNECT (fixed) or accepted (exposed) while the authenticated one connects; with mutual TLS, the configuration without a client certificate fails during TLS (fixed) or connects (exposed). Prepare corresponding files for `device-02` and `controller`, with their distinct passwords. Create a separate empty `anonymous.conf`. Inspect these files: use only the intended authentication options, with no proxy, insecure TLS, extra subscriptions, fixed client id, or persistent-session options. If mutual TLS is required, add the valid client certificate and key paths to both the authenticated and anonymous test configurations; the latter then tests absence of MQTT username/password. Use a separate configuration without the client certificate for the missing-certificate check.

```
-u device-01
-P REPLACE_WITH_DEVICE_PASSWORD
```

### Connection authentication and TLS

```bash
# The block reads the -d CONNACK output, not the exit status: mosquitto_sub exits 27 on a
# -W timeout even after a successful connect, and nonzero on a refusal, so each is wrapped to capture its
# status without aborting under set -e. Keep the client config clean: a default mosquitto client config
# (e.g. ~/.config/mosquitto_sub) can carry credentials, a SOCKS proxy, or an insecure-TLS setting, so run
# these where there is none, or inspect it first. If require_certificate true is set, TLS rejects before
# the password check, so add --cert 'client.pem' --key 'client.key' (your paths, inside the quotes) to BOTH controls below and test a
# missing-client-certificate connection separately. -x sets MQTT session expiry (NOT a TLS bypass), and
# the clients' insecure-TLS option disables hostname verification; use neither here.
# With 2.1 clients, that option disables all server-certificate verification.
# Positive control: a valid device connects. Expect "received CONNACK (0)" in the output; the block takes
# acceptance from that CONNACK alone. Exit 27 is only a timeout, even if messages arrived first.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_THE_BROKER_PUBLIC_HOST' \
    'REPLACE_WITH_CA_FILE' 'REPLACE_WITH_DEVICE_01_CONFIG' 'REPLACE_WITH_ANONYMOUS_CONFIG'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "provide exactly 4 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the broker host"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the CA path"; exit 2 ;;
  esac
  case "$3" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the device config path"; exit 2 ;;
  esac
  case "$4" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the anonymous config path"; exit 2 ;;
  esac
  set -- "$1" "$2" "$3" "$4" 0          # the 5th value is the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 0
  set -- "$@" "$(if mosquitto_sub -o "$3" -d -W 2 -h "$1" -p 8883 --cafile "$2" -t 'test' -u device-01 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "$4" "$5" "${6%$'\n'*}" "${6##*$'\n'}"   # the four values, the status, the client's output, then its exit status
  printf '%s' "$6"
  case "$7" in
    0) echo "exit 0; confirm CONNACK (0) above" ;;
    *) echo "exit $7; confirm CONNACK separately; 27 means timeout" ;;
  esac
  case "$6" in
    *'received CONNACK (0)'*) ;;
    *) echo "no CONNACK (0) for device-01, so the positive control failed; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
  esac
  # Negative control: NO credentials must be refused AT CONNECT, not merely denied the subscription.
  # Expect "received CONNACK (5)" (MQTT 3.1.1 not authorized) or "(135)" (MQTT 5). An anonymous CONNECT
  # that succeeds (CONNACK (0)) and only fails the SUBSCRIBE (e.g. under an acl_file) means the broker
  # still accepts anonymous clients: that is a finding.
  set -- "$1" "$2" "$3" "$4" "$5" "$(if mosquitto_sub -o "$4" -d -W 2 -h "$1" -p 8883 --cafile "$2" -t 'test' 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "$4" "$5" "${6%$'\n'*}" "${6##*$'\n'}"
  printf '%s' "$6"
  case "$7" in
    0) echo "exit 0; FINDING if anonymous CONNACK (0) appears" ;;
    *) echo "exit $7 (expected: CONNACK 5/135 refusal - confirm above, NOT a SUBACK denial)" ;;
  esac
  case "$6" in
    *'received CONNACK (0)'*) echo "FINDING: the anonymous client received CONNACK (0), so the broker accepts anonymous clients"; set -- "$1" "$2" "$3" "$4" 1 ;;
    *'received CONNACK (5)'*|*'received CONNACK (135)'*) echo "the anonymous client was refused at CONNECT" ;;
    *) echo "no CONNACK (0), (5) or (135) for the anonymous client: a DNS, TCP, TLS or local-file failure, or another CONNACK code, is inconclusive"; [ "$5" = 1 ] || set -- "$1" "$2" "$3" "$4" 3 ;;
  esac
  echo "block exit $5; the rest of the -d output above is not classified, so judge it yourself"
  exit "$5"
)
```

**REASONED:** preceding block; covers every check in it: the guard, the authenticated positive control and the anonymous negative control, each read from the `-d` CONNACK output rather than the exit status. No Mosquitto broker, client binaries, TLS fixture, device credentials or client certificates in the authoring environment; the CONNECT outcomes rest on the guide's cited Authentication methods, mosquitto.conf manual and mosquitto_sub manual entries, and the accepted SUBACK on its cited Mosquitto 2.0.22 built-in security implementation and Mosquitto 2.1.2 ACL-file plugin implementation entries. Run locally against a stub `mosquitto_sub`: `bash -n` and ShellCheck 0.11.0 printed nothing; the block as written, an angle-bracket host and a host under example.com printed "substitute the broker host", an unsubstituted CA path printed "substitute the CA path", and an empty anonymous path printed "substitute the anonymous config path", each exiting 1 without calling the stub. Five values passed to the block locally printed "provide exactly 4 values; not probing", and a paste without the `set --` lines printed "paste the whole block; not probing" despite four caller arguments, each also exiting 1 without calling the stub. Substituted values reached the stub as two calls carrying `-o`, `-d`, `-W 2`, port 8883 and `--cafile`, the first also passing the username device-01. The block printed "exit 0; confirm CONNACK (0) above" and "exit 0; FINDING if anonymous CONNACK (0) appears" for stub status 0 and "exit 27; confirm CONNACK separately; 27 means timeout" for 27, and under `bash -e -u` with stub status 5 both controls still ran. The bash -n, ShellCheck and stub runs recorded here covered the connection block in an earlier form, whose guard refusals exited with status 1. The current form exits 2 on a guard refusal and otherwise once: 1 when the anonymous client receives CONNACK (0), 3 when the device control shows no CONNACK (0) or the anonymous client shows none of CONNACK (0), (5) and (135), and 0 otherwise. It is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. Expected: the device control shows CONNACK (0) in both states; the anonymous control shows CONNACK (0) when anonymous clients are accepted (exposed) and CONNACK (5) or (135) when they are refused at CONNECT (fixed); with file ACLs the subscription is accepted and only message access is filtered. The SUBACK warning above concerns the distinction between authentication and authorization. With file ACLs specifically, expect the subscription itself to be accepted and unauthorized message access to be filtered, as section 3 explains. The `test` topic is deliberately ungranted; this first pair establishes CONNECT behaviour only. Run both controls against the intended exposed endpoint. The authenticated control must produce successful CONNACK; the anonymous control must be refused at CONNECT. Anonymous CONNACK success is the exposed outcome even if no messages arrive. DNS, TCP, TLS, and local-file failures are inconclusive authentication results. The discriminators come from [authentication configuration](https://mosquitto.org/documentation/authentication-methods/) and [client CONNACK reporting](https://mosquitto.org/man/mosquitto_sub-1.html).

**REASONED:** exit-status interpretation for the connection and observer blocks; no Mosquitto client binaries in the authoring environment, per the guide's cited Mosquitto 2.1.2 subscriber implementation (timeout result independent of message receipt) and Mosquitto 2.1 release notes entries. Locally, with a stub `mosquitto_sub` exiting 27, the connection block printed "exit 27; confirm CONNACK separately; 27 means timeout" and the observer block printed "exit 27; inspect CONNACK and deliveries; timeout alone proves no ACL result"; the stub's status is not the client's, so this shows only how the blocks report 27. Those stub runs covered the connection and observer blocks in an earlier form, whose guard refusals exited with status 1; their current forms, which still print those lines for exit 27, are covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. No `--insecure` run was made. Expected: a 2.1 client exits 27 on a `-W` timeout whether or not it was accepted or received messages, so that status separates neither state; with 2.1 clients `--insecure` disables all server-certificate verification, so a run using it could connect to an untrusted broker. Exit 27 is a timeout, including after received messages; it is never shorthand for accepted authentication. See the [client timeout implementation](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/client/sub_client.c). The [2.1 release notes](https://mosquitto.org/blog/2026/01/version-2-1-0-released/) also document the broader effect of `--insecure`.

**REASONED:** Where `require_certificate true` is enabled, repeat the authenticated request with the no-client-certificate configuration. The fixed outcome is TLS rejection before CONNACK, paired with successful connection using the trusted certificate. Acceptance without a certificate is the exposed outcome. This comparison is unavailable here because there is no broker or deployed client-certificate fixture. See [`require_certificate`](https://mosquitto.org/man/mosquitto-conf-5.html).

### Listener exposure

**REASONED:** following block; covers the `ss` listener inventory on the broker host. No deployed broker namespace, Mosquitto broker, deployed listener or external probe host is available in the authoring environment, per the guide's cited Migrating to 2.0 (anonymous loopback mode, explicit-listener exposure and authentication) and Mosquitto 2.1.2 MQTT listener with no address entries. Run the inventory on the broker host and the network probe from another host. Check every actual public IPv4 and IPv6 address, including NAT paths. The inventory's earlier stub runs, from the form in which the inventory and the probe were one block, are recorded after the probe block below. Its current form refuses with status 2, printing `ss is not installed here; not listing sockets`, when `ss` is missing, exits 3 if `ss` fails and otherwise exits 0 with an unclassified-observation line, because `ss` shows a bind, not a firewall. It is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes and by stub runs with `ss` replaced by a stub, in which a missing `ss` exited 2, a failing `ss` 3 and a working one 0. Expected: a 1883 listener on a non-loopback address that is not firewalled to localhost (exposed) or none (fixed).

```bash
(                              # a subshell, so the exits below end only the subshell
  command -v ss >/dev/null 2>&1 || { echo 'ss is not installed here; not listing sockets'; exit 2; }
  if ss -tlnp; then   # inventory the listeners (needs sudo for the process column); ss shows a local BIND, not a
                      # firewall or external reachability. There must be no 1883 listener on ANY non-loopback
                      # address - 0.0.0.0, ::, or a specific external IP, IPv4 or IPv6 - unless it is firewalled to
                      # localhost. The plaintext 1883 listener is the main exposure (section 2), so also probe each
                      # public address from ANOTHER host with the block below
    echo "unclassified observation: a 1883 listener on a non-loopback address is the exposure unless a firewall limits it to localhost, which ss cannot show; probe from another host with the block below"
  else
    echo "ss -tlnp exit $?: the listener inventory failed; inconclusive"; exit 3
  fi
)
```

```bash
# Probe each public address from ANOTHER host, using the corpus guard so an unsubstituted target cannot
# masquerade as a pass:
(                              # a subshell, so your own script arguments are untouched
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_THE_BROKER_PUBLIC_HOST'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the broker's public host on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- "$1" "$(if nc -vz -w 5 "$1" 1883 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # refused/timeout = TCP 1883 unreachable from here (the pass); a completed connect means TCP 1883 is reachable off-host. nc sends no MQTT, so this shows reachability, not the service or its encryption; the positive control against the intended endpoint must have succeeded first
  set -- "$1" "${2%$'\n'*}" "${2##*$'\n'}"   # the host, nc's report, then its exit status
  printf '%s' "$2"
  # This block expects OpenBSD netcat, whose refusal and timeout wording the pass arm below matches; another netcat may word them differently, and then a refusal or timeout exits 3, so read its diagnostic above yourself
  case "$3:$2" in
    0:*) echo "FINDING: TCP 1883 is reachable off-host"; exit 1 ;;
    *'Connection refused'*|*'timed out'*) echo "TCP 1883 is unreachable from here; this is the pass only after the positive control against the intended endpoint succeeded"; exit 0 ;;
    *) echo "nc exit $3 without a refusal or timeout: a DNS failure, wrong destination or local socket error is inconclusive"; exit 3 ;;
  esac
)
```

**REASONED:** preceding block; covers every check in it: the guard and the off-host `nc` reachability probe. No Mosquitto broker, deployed listener, second host or network access in the authoring environment, per the guide's cited Migrating to 2.0 (anonymous loopback mode, explicit-listener exposure and authentication) and Mosquitto 2.1.2 MQTT listener with no address entries. Run locally against stub `ss` and `nc` commands, in an earlier form in which the inventory above and this probe were one block: `bash -n` and ShellCheck 0.11.0 printed nothing; the stub `ss` received `-tlnp` first in every run, because the inventory preceded the guard. The block as written, an angle-bracket host and an empty host printed "substitute the broker's public host on the set -- line above; not probing" in the local stub runs, each without calling `nc` and each exiting 0. Two values passed to the block locally printed "the set -- line needs exactly 1 value; not probing", and a paste without the `set --` line printed "paste the whole block, including its set -- line; not probing" despite a caller argument, each also without calling `nc` and each exiting 0. A substituted `broker.internal` reached the stub `nc` with `-vz -w 5` and port 1883, and the block exited 0 whether the stub `nc` exited 0 or 1, also under `bash -e -u`. The bash -n, ShellCheck and stub runs recorded here covered that earlier single block, whose guard refusals left the subshell with status 0. The current probe block exits 2 on a guard refusal, 1 when `nc` connects, 0 when `nc` reports a refusal or a timeout in the OpenBSD netcat wording its comment says it expects, and 3 otherwise, so a refusal or timeout that another netcat words otherwise exits 3. It is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes and by stub runs with `nc` replaced by a stub, in which a completed connect exited 1, a line containing `Connection refused` or `timed out` exited 0, and other text exited 3. Expected: from another host, a completed connection to 1883 (exposed) or a refusal or timeout after the positive control succeeded (fixed). A DNS failure, wrong destination, or local socket error is not a pass. Confirm the address belongs to this broker and inspect the actual diagnostic. A refusal or timeout exits 0 because it is the fixed outcome, and it is a pass only after the connection block's device control succeeded against the intended endpoint. Repeat for port 9001 if using the local-only WebSockets example. The fixed state has no externally reachable plaintext endpoint; a completed external connection is the exposure. See [listener binding behaviour](https://mosquitto.org/documentation/migrating-to-2-0/).

### Actual topic access

**REASONED:** No live broker, scoped identities, or disposable topic fixtures are available here. Use an isolated deployment with the section 3 ACL and the three test credentials. Keep real actuators and command consumers disconnected. Compare the same requests with password authentication alone and with the ACL applied; never remove production ACLs for this test.

**REASONED:** the `use_username_as_clientid true` variant; no Mosquitto broker, client binaries or long-lived test clients in the authoring environment, and the separate-client blocks below cannot show it, so nothing in this variant ran locally, per the guide's cited Mosquitto authenticated duplicate client-ID displacement (pinned tag v2.0.22) entry. Expected: under this policy a separate publisher using an observer's username displaces that observer, so separate clients lose delivery for a reason unrelated to the ACL; with one long-lived client per identity, the table's cross-identity deliveries occur without the ACL (exposed) and are absent while authorized deliveries arrive with it (fixed). With `use_username_as_clientid true`, a separate publisher using an observer's username disconnects that observer. For this policy, reproduce the table below using one long-lived client per identity that both subscribes and publishes, retaining the before-and-after delivery controls. This variant is REASONED from the pinned session-takeover source; the separate-client commands below cannot demonstrate it. See [session takeover](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/src/handle_connect.c).

**REASONED:** following block; covers every check in it: the guard and one observer subscribed to `#` and `$SYS/#` at QoS 1 for 60 seconds. No Mosquitto broker, client binaries or scoped test identities in the authoring environment, per the guide's cited ACL-file plugin, Mosquitto 2.1.2 ACL-file plugin implementation and Mosquitto broker manual entries. Run locally against a stub `mosquitto_sub`: `bash -n` and ShellCheck 0.11.0 printed nothing. The block as written printed "substitute the broker host", an unsubstituted observer path printed "substitute the observer config path", four values printed "provide exactly 3 values; not probing", and a paste without the `set --` lines printed "paste the whole block; not probing" despite three caller arguments, each exiting 1 without calling the stub. With `device-01.conf` and then `device-02.conf` substituted, the stub received `-o` with that path, `-d -v -q 1 -W 60` and the topic filters `#` and `$SYS/#`, and the block printed "exit 0; inspect received topics and this run's markers" for stub status 0 and "exit 27; inspect CONNACK and deliveries; timeout alone proves no ACL result" for 27, also under `bash -e -u`. The bash -n, ShellCheck and stub runs recorded here covered the observer block in an earlier form, whose guard refusals exited with status 1. The current form exits 2 on a guard refusal, 0 when the client exits 0 or with the `-W` timeout's 27, and 3 for any other client status; the deliveries it prints stay for you to judge. It is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. Expected: each observer receives its own identity's markers in both states; without the ACL it also receives the other device's telemetry and, when broker telemetry publication is enabled, `$SYS` topics (exposed), and with it neither (fixed). Otherwise, run this observer block in separate terminals once with `device-01.conf` and once with `device-02.conf`. Where client-ID authorization is enforced, give each observer and publisher a distinct authorized ID in its protected test configuration, as an explicit exception to the preparation rule against fixed IDs. Wait for successful CONNACK and SUBACK in both observers before publishing. Keep both running throughout each comparison; repeat the window if either exits.

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_THE_BROKER_PUBLIC_HOST' \
    'REPLACE_WITH_CA_FILE' 'REPLACE_WITH_OBSERVER_CONFIG'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "provide exactly 3 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the broker host"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the CA path"; exit 2 ;;
  esac
  case "$3" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the observer config path"; exit 2 ;;
  esac
  if mosquitto_sub -o "$3" -h "$1" -p 8883 --cafile "$2" \
    -d -v -q 1 -W 60 -t '#' -t "\$SYS/#"
  then echo "exit 0; inspect received topics and this run's markers"
  else
    set -- "$?"
    echo "exit $1; inspect CONNACK and deliveries; timeout alone proves no ACL result"
    case "$1" in
      27) ;;
      *) echo "exit $1 is neither 0 nor the -W timeout's 27, so this observer may not have watched its whole window; inconclusive"; exit 3 ;;
    esac
  fi
  echo "unclassified observation: the deliveries above are not classified, so judge them against the table below"
  exit 0
)
```

**REASONED:** following block; the publisher block and the instructions for it. No Mosquitto broker, client binaries or test identities in the authoring environment, per the guide's cited Mosquitto publisher manual (protected configuration files, QoS, protocol selection, message publishing) and Mosquitto 2.0.22 PUBLISH handler (payload-size checks, denied writes, QoS responses) entries. Run locally against a stub `mosquitto_pub`: `bash -n` and ShellCheck 0.11.0 printed nothing for that block. The block as written printed "substitute the broker host", an unsubstituted marker printed "substitute the non-secret marker", six values printed "provide exactly 5 values; not probing", and a paste without the `set --` lines printed "paste the whole block; not probing" despite five caller arguments, each exiting 1 without calling the stub. Each table row's identity file, topic and a distinct marker reached the stub with `-o`, `-d -V mqttv5 -q 1`, `-t` and `-m` and no retain option, and the block printed "publisher exited 0; check PUBACK reason and actual observer delivery" for stub status 0 and "publisher exit 5; inspect the broker response, not just this status" for 5 under `bash -e -u`. The bash -n, ShellCheck and stub runs recorded here covered the publisher block in an earlier form, whose guard refusals exited with status 1 and which took five values. The current form takes a sixth value, `allowed` or `denied`, exits 2 on a guard refusal and exits 3 when the publisher shows no CONNACK (0). With `allowed` it then exits 3 if the publisher fails and 0 otherwise; with `denied` it exits 0 when the publisher's output shows a PUBACK, leaving the broker's response for you to judge with the observers' deliveries, and 3 when it shows none, because the publish then failed before its result. It is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes and by stub runs with `mosquitto_pub` replaced by a stub, in which the denied row exited 0 with a `received PUBACK` line and 3 without one, and the allowed row exited 0 on success and 3 on failure. Expected: authorized rows deliver their markers in both states; device-01's write to device-02's command topic reaches device-02 without the ACL (exposed) and is denied with it (fixed). Run this publisher block for each row below, substituting the selected credential-file path, topic, and a distinct non-secret marker for this run, with `denied` for the row in which device-01 writes to device-02's command topic and `allowed` for every other row. It does not retain messages.

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_THE_BROKER_PUBLIC_HOST' \
    'REPLACE_WITH_CA_FILE' 'REPLACE_WITH_PUBLISHER_CONFIG' \
    'REPLACE_WITH_TEST_TOPIC' 'REPLACE_WITH_NONSECRET_UNIQUE_MARKER' \
    'REPLACE_WITH_allowed_OR_denied'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 6 ] || { echo "provide exactly 6 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the broker host"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the CA path"; exit 2 ;;
  esac
  case "$3" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the publisher config path"; exit 2 ;;
  esac
  case "$4" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the test topic"; exit 2 ;;
  esac
  case "$5" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute the non-secret marker"; exit 2 ;;
  esac
  case "$6" in
    allowed|denied) ;;
    *) echo "substitute allowed, or denied for the row whose write the fixed state denies; not probing"; exit 2 ;;
  esac
  set -- "$@" "$(if mosquitto_pub -o "$3" -h "$1" -p 8883 --cafile "$2" \
    -d -V mqttv5 -q 1 -t "$4" -m "$5" 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "$4" "$5" "$6" "${7%$'\n'*}" "${7##*$'\n'}"   # the six values, the publisher's output, then its exit status
  printf '%s' "$7"
  case "$8" in
    0) echo "publisher exited 0; check PUBACK reason and actual observer delivery" ;;
    *) echo "publisher exit $8; inspect the broker response, not just this status" ;;
  esac
  case "$7" in
    *'received CONNACK (0)'*) ;;
    *) echo "no CONNACK (0) for the publisher, so it did not connect and this row shows nothing; inconclusive"; exit 3 ;;
  esac
  case "$6:$8" in
    allowed:0) echo "unclassified observation: the authorized write was sent; judge the observers' deliveries against the table below"; exit 0 ;;
    allowed:*) echo "the authorized write failed after CONNACK (0), so this row's positive control failed; inconclusive"; exit 3 ;;
  esac
  case "$7" in   # the denied row: a publish that completed shows the broker's PUBACK, whatever its reason
    *'received PUBACK'*) echo "unclassified observation: read the PUBACK reason above and the observers' deliveries; this row's fixed outcome is a denied write that device-02 never receives"; exit 0 ;;
    *) echo "no PUBACK for the denied row's publish, so it failed before the broker answered and this row shows nothing; inconclusive"; exit 3 ;;
  esac
)
```

| Publisher identity | Topic | Fixed outcome |
| --- | --- | --- |
| `device-01` | `fleet/device-01/telemetry/check` | **REASONED:** whole row; no Mosquitto broker, client binaries or test identities in the authoring environment, per the guide's cited ACL-file plugin and Mosquitto 2.1.2 ACL-file plugin implementation entries. Locally, the publisher block with `device-01.conf`, this topic and a distinct marker reached only a stub `mosquitto_pub`, with those values. The stub runs recorded in this row covered the publisher block in an earlier form, whose guard refusals exited with status 1; the current form, which takes `allowed` for this row, is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. Expected: without the ACL both observers receive the marker (exposed); with it device-01 receives it and device-02 does not (fixed). Device-01 receives its marker; device-02 does not |
| `device-02` | `fleet/device-02/telemetry/check` | **REASONED:** whole row; no Mosquitto broker, client binaries or test identities in the authoring environment, per the guide's cited ACL-file plugin and Mosquitto 2.1.2 ACL-file plugin implementation entries. Locally, the publisher block with `device-02.conf`, this topic and a distinct marker reached only a stub `mosquitto_pub`, with those values. The stub runs recorded in this row covered the publisher block in an earlier form, whose guard refusals exited with status 1; the current form, which takes `allowed` for this row, is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. Expected: without the ACL both observers receive the marker (exposed); with it device-02 receives it and device-01 does not (fixed). Device-02 receives its marker; device-01 does not |
| `controller` | `fleet/device-02/commands/check` | **REASONED:** whole row; no Mosquitto broker, client binaries or test identities in the authoring environment, per the guide's cited ACL-file plugin and Mosquitto 2.1.2 ACL-file plugin implementation entries. Locally, the publisher block with `controller.conf`, this topic and a distinct marker reached only a stub `mosquitto_pub`, with those values. The stub runs recorded in this row covered the publisher block in an earlier form, whose guard refusals exited with status 1; the current form, which takes `allowed` for this row, is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. Expected: device-02 receives the marker in both states, the authorized positive control; without the ACL device-01 also receives it (exposed), and with it device-01 does not (fixed). Device-02 receives the authorized command marker |
| `device-01` | `fleet/device-02/commands/check` | **REASONED:** whole row; no Mosquitto broker, client binaries or test identities in the authoring environment, per the guide's cited ACL-file plugin and Mosquitto 2.0.22 PUBLISH handler (payload-size checks, denied writes, QoS responses) entries. Locally, the publisher block with `device-01.conf`, this topic and a distinct marker reached only a stub `mosquitto_pub`, with those values; with the stub exiting 5 under `bash -e -u` it printed "publisher exit 5; inspect the broker response, not just this status". The stub runs recorded in this row covered the publisher block in an earlier form, whose guard refusals exited with status 1; the current form, which takes `denied` for this row, is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. Expected: without the ACL device-02 receives the injected marker (exposed); with it the MQTT 5 QoS 1 write is denied with a PUBACK reason and device-02 receives nothing (fixed). Write is denied; device-02 receives no injected marker |
| `controller` | `fleet/device-02/commands/check` | **REASONED:** whole row; no Mosquitto broker, client binaries or test identities in the authoring environment, per the guide's cited ACL-file plugin and Mosquitto 2.1.2 ACL-file plugin implementation entries. Locally, the publisher block with `controller.conf`, this topic and a fresh distinct marker reached only a stub `mosquitto_pub`, with those values. The stub runs recorded in this row covered the publisher block in an earlier form, whose guard refusals exited with status 1; the current form, which takes `allowed` for this row, is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes. Expected: device-02 receives this marker in both states; after the denied attempt (fixed) its arrival shows the observer still works, so the missing injected marker was a denial. Device-02 receives a fresh authorized marker after the denied attempt |

Without ACLs, the authenticated observers can receive each other's telemetry and device-01 can inject the command. With the ACL, require both isolation and successful authorized deliveries. The controller's before-and-after messages distinguish write denial from a broken observer. MQTT 5 QoS 1 supplies a PUBACK reason for denied writes; actual delivery remains part of the decision. See the [ACL check](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/plugins/acl-file/acl_check.c), [PUBLISH denial handling](https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/handle_publish.c), and [publisher options](https://mosquitto.org/man/mosquitto_pub-1.html).

The explicit `$SYS/#` subscription should receive broker telemetry in the exposed comparison when telemetry publication is enabled, and none under either device's fixed ACL. Require that exposed positive control and the device's authorized live marker; an empty `$SYS` result alone proves nothing. See [broker status publication](https://mosquitto.org/man/mosquitto-8.html).

### Verification scope

| Check scope | Status | Deployment comparison and prerequisites |
| --- | --- | --- |
| Service behaviour | **REASONED:** every comparison listed in this row; none ran, because the authoring environment has no Mosquitto broker or client binaries, container runtime or network access and none of the listed fixtures. It rests on the Sources entries cited at each Verify comparison above and on the guide's cited entries for the other behaviours named here. The other behaviours named here have cited entries in the guide, including the Mosquitto 2.0.22 packet reader, Mosquitto libwebsockets connection-cap implementation, Mosquitto disconnected-session expiry scheduling and timed cleanup, Mosquitto authenticated duplicate client-ID displacement and Mosquitto local bridge contexts bypassing ACL checks entries. Only the shell, guard, stub, Python file-mode and shlex, and OpenSSL fixture checks recorded at the units above ran locally, and none exercised Mosquitto. Those checks ran the section 1 credential-removal block in an earlier form, whose guard refusals exited with status 1; none was re-run on that block's current form, whose guard refusals exit with status 2. They also ran the connection, observer and publisher blocks in an earlier form, whose guard refusals exited with status 1, and the section 8 listener checks, then one block, in an earlier form whose guard refusals left the subshell with status 0. The current forms of those checks, now five blocks, exit 2 on a guard refusal and otherwise with one status for each block; they are covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes, and no stub run of them is recorded here. Expected, as the next cell states item by item: the exposed state accepts the excess, foreign or unauthorized input, for example device-01 credentials with device-02's active ID disconnecting device-02, and the fixed state refuses or neutralizes it while a matched positive control succeeds. REASONED from the cited 2.0.22 and 2.1.2 sources and vendor documentation; broker configuration acceptance and service behaviour not demonstrated | On pinned 2.0.22 and 2.1.2 deployments, load the applicable configurations and reproduce exposed/fixed authentication, TLS/client-certificate, listener, WebSockets, and actual-message ACL comparisons above. Confirm credential reload and termination of revoked connections. Exercise packet and payload limits separately on TCP and each deployed WebSockets implementation, including declared-length probes without the body; instrument allocation to distinguish rejection before allocation from rejection after receipt. Demonstrate the section 4 WebSockets gap and the chosen boundary or replacement implementation's rejection before oversized allocation, with an accepted packet below the limit. Exercise queue loss and inflight bounds with slow clients, keepalive negotiation/refusal, per-listener connection caps, and 2.1 global connection/session caps. For each listener cap N, hold N connections with distinct authorized identities/IDs and attempt N+1; demonstrate the 2.0.22 WebSockets failure without an independent cap and refusal with the chosen enforcement. Release a slot, confirm a replacement connects, refill to N, and repeat the excess attempt across multiple disconnect/reconnect cycles; distinguish cap refusal from authentication or transport failure. Test device-01 credentials with device-02's active ID: the exposed state disconnects device-02; the fixed state rejects or rewrites the claimant's ID and preserves device-02's connection and delivery. Repeat across listeners, and confirm the documented same-identity takeover when username binding is enabled. Run message ACL comparisons with one publishing/subscribing client per identity under that policy. On 2.0, demonstrate persistent-session growth with varying IDs, the chosen ID restriction, and expiration after the configured disconnected interval; do not treat expiration as a population cap. Where bridges exist, demonstrate trusted TLS and hostname rejection, optional client certificates, scoped inbound/outbound delivery, remote ACL denial, and reconnect backoff. Separately use a controlled upstream that sends outside the configured inbound topics despite its account ACL; demonstrate the direct bridge's missing ingress containment and, where required, denial at the independent boundary with matched allowed delivery. Confirm runtime ownership, readable security files, writable protected state/log paths, and persistence only when enabled. Record versions, WebSockets implementations, commands, diagnostics, matched positive controls, and cleanup without credentials. Configuration inspection alone does not demonstrate service behaviour. |

## Sources (checked October 2026)

- Official eclipse-mosquitto Docker images: the tag-to-directory map (library file pinned commit 920b00976e6e8335bab0a3fd293b95b6b2404ce3). The image source at pinned commit 5b74cce8a4fe2a73b57df6c703bfde2cfd535d60 covers the 2.1-alpine build's 2.1.2 release download, configuration and dashboard install and `CMD`, an entrypoint that only sets data-directory ownership, its `mosquitto.conf` (`listener 1883`, `allow_anonymous true`, `listener 9883` with `protocol http_api`), and the README's description of it. The image source at pinned commit 5b74cce8a4fe2a73b57df6c703bfde2cfd535d60 also covers the 2.0-openssl and 1.6-openssl builds installing upstream's `mosquitto.conf`. Sources for this item (1 of 5): https://github.com/docker-library/official-images/blob/920b00976e6e8335bab0a3fd293b95b6b2404ce3/library/eclipse-mosquitto#L3-L13 and https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/Dockerfile#L30. Sources for this item (2 of 5): https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/Dockerfile#L77-L80 and https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/Dockerfile#L99-L101. Sources for this item (3 of 5): https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/mosquitto.conf (identical in the v2.1.2 release it is installed from: https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/docker/2.1-alpine/mosquitto.conf). Sources for this item (4 of 5): https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/docker-entrypoint.sh and https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/README.md#L27-L28. Sources for this item (5 of 5): https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.0-openssl/Dockerfile#L69 and https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/1.6-openssl/Dockerfile#L66
- Mosquitto 2.1.2 MQTT listener with no address (a passive `getaddrinfo` over both families, binding each result), the HTTP API listener with no address (libmicrohttpd with `MHD_USE_DUAL_STACK`), the `http_api` endpoints, and their JSON and plain-text handlers and their access check (pinned tag v2.1.2). This item's Mosquitto 2.1.2 sources also cover a `listener` line resetting that listener's `allow_anonymous` to unset so the global value applies, anonymous success with no authentication plugin, ACL success with no ACL plugin, and the manual's `http_api` entry (pinned tag v2.1.2). Sources for this item (1 of 3): https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/net.c#L815-L918, https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L449-L545, https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L160-L163 and https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L224. Sources for this item (2 of 3): https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L251, https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L336-L378, https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/conf.c#L2001 and https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/listeners.c#L27-L42. Sources for this item (3 of 3): https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/plugin_basic_auth.c#L56-L113, https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/plugin_acl_check.c#L141-L201 and https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/man/mosquitto.conf.5.xml#L1663-L1671
- Mosquitto 1.6.15 default listener on 1883 with no address when no listener is configured, and `allow_anonymous` defaulting to true, with upstream's `mosquitto.conf` having no active line (pinned tags v1.6.15 and v2.0.22). Sources for this item (1 of 2): https://github.com/eclipse-mosquitto/mosquitto/blob/v1.6.15/src/conf.c#L420-L468, https://github.com/eclipse-mosquitto/mosquitto/blob/v1.6.15/src/net.c#L605-L690 and https://github.com/eclipse-mosquitto/mosquitto/blob/v1.6.15/man/mosquitto.conf.5.xml#L167-L185. Sources for this item (2 of 2): https://github.com/eclipse-mosquitto/mosquitto/blob/v1.6.15/mosquitto.conf and https://github.com/eclipse-mosquitto/mosquitto/blob/v2.0.22/mosquitto.conf
- mosquitto.conf manual (allow_anonymous defaults, password_file, listener, certfile/keyfile/cafile, require_certificate): https://mosquitto.org/man/mosquitto-conf-5.html
- mosquitto_sub manual (`-d` debug/CONNACK, `-W` timeout, `-u`/`-P`, `--cafile`, `--cert`/`--key`, `-x` session expiry, `--insecure`): https://mosquitto.org/man/mosquitto_sub-1.html
- mosquitto_passwd manual (`-c` creates/overwrites the password file): https://mosquitto.org/man/mosquitto_passwd-1.html
- Migrating to 2.0 (anonymous loopback mode, explicit-listener exposure and authentication, early privilege drop): https://mosquitto.org/documentation/migrating-to-2-0/
- Authentication methods (password files and SIGHUP reload): https://mosquitto.org/documentation/authentication-methods/
- Mosquitto 2.0 release notes (`deny` ACLs and queue-default change): https://mosquitto.org/blog/2020/12/version-2-0-0-released/
- Mosquitto 2.1 release notes (deprecations, announced 3.0 removals, packet-size default, global limits, client TLS behaviour): https://mosquitto.org/blog/2026/01/version-2-1-0-released/
- Replacing per_listener_settings (listener_allow_anonymous, plugin_load, plugin_use, file plugins): https://mosquitto.org/documentation/listeners/per-listener-settings/
- ACL-file plugin (user/topic rules, deny, patterns, username and client-id substitutions): https://mosquitto.org/documentation/plugins/acl-file/
- Mosquitto broker manual ($SYS telemetry, wildcard exclusions, reload signals): https://mosquitto.org/man/mosquitto-8.html
- Mosquitto publisher manual (protected configuration files, QoS, protocol selection, message publishing): https://mosquitto.org/man/mosquitto_pub-1.html
- Mosquitto 2.0.22 sample configuration (listener connection defaults, per-listener policy, bridge options): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/mosquitto.conf
- Mosquitto 2.0.22 configuration implementation (actual resource defaults, numeric validation, per-listener ordering): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/conf.c
- Mosquitto 2.1.2 configuration implementation (actual packet, keepalive, queue, and global-limit defaults): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/src/conf.c
- Mosquitto 2.0.22 configuration manual source (resource-limit mechanisms, listener policy, WebSockets TLS): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/man/mosquitto.conf.5.xml
- Mosquitto 2.0.22 built-in security implementation (message ACL checks, accepted subscriptions, credential rechecks on reload): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/security_default.c
- Mosquitto 2.1.2 ACL-file plugin implementation (subscription acceptance and message-access filtering): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/plugins/acl-file/acl_check.c
- Mosquitto 2.0.22 packet reader (packet-size enforcement before incoming-body allocation): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/lib/packet_mosq.c
- Mosquitto 2.0.22 PUBLISH handler (payload-size checks, denied writes, QoS responses): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/handle_publish.c
- Mosquitto 2.1.2 subscriber implementation (timeout result independent of message receipt): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/client/sub_client.c
- Mosquitto libwebsockets packet allocation before a packet-size check (pinned tags v2.0.22 and v2.1.2): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/websockets.c, https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/websockets.c#L296-L324
- Mosquitto libwebsockets connection-cap implementation (v2.0.22) and fix recorded under 2.1.1 in the v2.1.2 ChangeLog: https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/websockets.c, https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/ChangeLog.txt#L14-L27
- Mosquitto disconnected-session expiry scheduling and timed cleanup (pinned tag v2.0.22): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/session_expiry.c
- Mosquitto authenticated duplicate client-ID displacement (pinned tag v2.0.22): https://github.com/eclipse-mosquitto/mosquitto/blob/v2.0.22/src/handle_connect.c#L120-L133
- Mosquitto local bridge contexts bypassing ACL checks (pinned tags v2.0.22 and v2.1.2): https://github.com/eclipse-mosquitto/mosquitto/blob/v2.0.22/src/security.c#L691-L693, https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/plugin_acl_check.c#L149-L151
- Mosquitto incoming topic remapping returning success after unmatched topics (pinned tag v2.1.2): https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/src/bridge_topic.c


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- v20: Mosquitto (v2.0.22)
- v21: Mosquitto (v2.1.2)
- v16: Mosquitto legacy (v1.6.15)
- docs: Mosquitto documentation (unknown)
- library: Mosquitto image catalogue (920b00976e6e8335bab0a3fd293b95b6b2404ce3)
- image: Mosquitto image source (5b74cce8a4fe2a73b57df6c703bfde2cfd535d60)
- release-notes: Mosquitto release announcements (unknown)

Claims (full source mapping in the JSON block below):

- loopback-default (REASONED; docs): 2.0+ without listeners binds loopback and permits anonymous clients; it is not authenticated.
- listener-default (REASONED; docs, v20): Explicit 2.0 listeners default to rejecting unauthenticated clients; an unspecified bind address is wildcard.
- image21 (REASONED; library, image): Recorded 2.1.2 Alpine tags ship anonymous MQTT 1883 and HTTP API/dashboard 9883; override configuration and restrict publication.
- image-api (REASONED; v21): 2.1.2 HTTP API uses a dual-stack socket and exposes systree/listeners JSON and version text without shipped credentials/ACLs.
- image16 (REASONED; image, v16): Recorded 1.6.15 image tags ship commented upstream config: wildcard 1883 and anonymous access.
- image20 (REASONED; image, v20): Recorded 2.0.22 image tags ship commented upstream config and retain loopback-only defaults.
- deprecation (REASONED; docs, release-notes): File-based examples target 2.0.22; password_file, acl_file and per_listener_settings are deprecated in 2.1, removal announced for 3.0.
- password-file (REASONED; docs): Prompt for distinct device credentials; -c overwrites, and -D edits the file without terminating connections by itself.
- reload (REASONED; docs, v20): Reload changed credentials/ACLs; manual says connections unaffected, but 2.0.22 rechecks credentials; confirm deployed termination.
- shared-policy (REASONED; v20): per_listener_settings false shares authentication/ACL policy; flipping it is neither separation nor 2.1 migration.
- tls (REASONED; docs, v20): 8883 TLS needs CA/certificate/key; optional require_certificate adds machine possession, not human MFA.
- listener-apply (REASONED; docs): Remove/firewall plaintext; confirm include_dir and restart for listener changes, which reload does not apply.
- acl-default (REASONED; docs, v20): Password authentication alone leaves application topics unrestricted without an authorization mechanism.
- acl-users (REASONED; docs, v20): Unlisted access is denied; user means username; pre-user topic rules apply only to anonymous clients.
- acl-patterns (REASONED; docs): Patterns apply to all users; %u/%c must occupy a whole topic level; prefer authenticated usernames over chosen client IDs.
- sys (REASONED; docs, release-notes): deny was added in 2.0; repeat $SYS denial per user and probe $SYS/# explicitly because # excludes it.
- subscription (REASONED; v20, v21): File ACLs filter message access, not SUBSCRIBE acceptance; accepted # alone is no bypass.
- connection-default (REASONED; v20): Per-listener max_connections defaults to -1, unlimited by this setting.
- packet-default (REASONED; v20, v21, release-notes): max_packet_size is unset in 2.0.22 and 2,000,000 bytes in 2.1; explicit 2.0.22 values must be at least 20.
- payload-default (REASONED; v20): message_size_limit defaults to 0; payload rejection follows reception and completes QoS acknowledgements.
- inflight-default (REASONED; v20): max_inflight_messages defaults to 20 per client for outgoing QoS 1/2; it is not a message-rate limit.
- queue-default (REASONED; v20, release-notes): max_queued_messages defaults to 1000 in 2.x, 100 earlier; queue overflow can lose messages.
- queue-bytes (REASONED; v20): max_queued_bytes defaults to 0; when both queue limits are set the first reached stops further queuing.
- keepalive (REASONED; v20, v21): max_keepalive defaults to 0 in 2.0.22/2.1.2; positive limits override MQTT 5 and reject incompatible MQTT 3.1.1.
- packet-boundary (REASONED; v20, v21): 2.0.22 TCP checks size before body allocation; 2.0.22/2.1.2 libwebsockets allocate without that check; require an independent boundary.
- global-limits (REASONED; docs, v21, release-notes): 2.1 global_max_connections/global_max_clients default to -1; the latter also counts disconnected persistent sessions.
- session-expiry (REASONED; v20): 2.0 persistent-session growth needs identity/client-ID limits; persistent_client_expiration is not a hard population cap.
- listener-policy (REASONED; v20): 2.0 per-listener settings must precede listeners/security options; place each listener's auth, ACL and TLS in its scope.
- websockets (REASONED; v20, v21): Local 9001 needs separate auth/ACL/TLS; 2.0.22 WebSockets connection cap is ineffective; 2.1.1 fix needs deployed-build testing.
- persistent-policy (REASONED; v20): Listeners share topic/session namespaces; disconnected persistent clients retain their most recent listener's ACL policy.
- client-id (REASONED; v20): use_username_as_clientid is per-listener and needs restart; globally consistent usernames prevent cross-identity ID takeover, not same-user displacement.
- migration (REASONED; docs): 2.1 listener_allow_anonymous and plugin_load/plugin_use replace listener policy; attach password-file and ACL-file plugins explicitly.
- bridge-tls (REASONED; v20): Port 8883 alone enables no bridge TLS; require CA/hostname verification, protected remote password and optional client certificate.
- bridge-topics (REASONED; v20, v21): Bridge contexts bypass local ACLs and 2.1.2 accepts unmatched ingress topics; narrow routes/remote ACLs do not contain malicious upstream.
- bridge-options (REASONED; v20): try_private aids bridge handling, not auth; restart_timeout supplies backoff; notifications false suppresses default $SYS status writes.
- runtime (REASONED; docs): Dedicated runtime identity needs readable security files and writable protected state/log paths after the early 2.0 privilege drop.
- persistence (REASONED; docs): Persistence defaults false; persistence_location alone does not enable it; protect data, logs, secrets and backups.
- client-config (REASONED; docs): Verify uses protected 2.1 client -o files; 2.0 lacks -o and needs isolated default configurations.
- verify-auth (REASONED; docs, v21): Authenticated CONNACK succeeds and anonymous CONNECT rejects; timeout exit 27, SUBACK and transport failures prove no authentication.
- verify-mtls (REASONED; docs): Missing certificate must fail at TLS while trusted certificate succeeds; then separately test MQTT credentials.
- verify-network (REASONED; docs, v20): Inspect actual namespace and external IPv4/IPv6/NAT paths; removed plaintext/WebSocket endpoints must not answer.
- verify-delivery (REASONED; docs, v20, v21): Require own telemetry, cross-device isolation and controller before/after markers around denied injection; inspect PUBACK and delivery.
- verify-sys (REASONED; docs): Require exposed telemetry plus authorized marker control; fixed devices receive no $SYS messages.
- verify-resources (REASONED; v20, v21): Separate packet allocation, payload, queue, inflight, keepalive, connection and session tests need matched healthy controls.
- verify-bridges (REASONED; v20): Test scoped delivery, TLS identity, remote ACLs and malicious-upstream containment independently; inspect runtime permissions and persistence.

````json
{
  "schema": 1,
  "checked": "2026-10-05",
  "documentation_checked": "2026-10",
  "body_sha256": "1a338374bc949536319551bfd205fe9cee9b44986c2d2bb5521ddf90c2955941",
  "components": {
    "v20": {
      "name": "Mosquitto",
      "basis": "v2.0.22",
      "sources": {
        "se7823193963b": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/man/mosquitto.conf.5.xml",
        "s10aff5e66af1": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.0.22/mosquitto.conf",
        "s06316e74cf90": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/security_default.c",
        "s0705841d4141": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/mosquitto.conf",
        "s1f256b35dde7": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/conf.c",
        "sa4ab07ef74c3": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/handle_publish.c",
        "se4dab27858b2": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/lib/packet_mosq.c",
        "s1172d84efc29": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/websockets.c",
        "saf5cd7c6f12b": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.0.22/src/session_expiry.c",
        "saff73f3b983e": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.0.22/src/handle_connect.c#L120-L133",
        "sa116e59b51a4": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.0.22/src/security.c#L691-L693"
      }
    },
    "v21": {
      "name": "Mosquitto",
      "basis": "v2.1.2",
      "sources": {
        "s539d2574fc70": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/net.c#L815-L918",
        "s7f6c7c2e6cff": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L449-L545",
        "sca7b250a1900": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L160-L163",
        "s9c9708acb8f8": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L224",
        "sedb9b3beddce": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L251",
        "s5fbac0184a26": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/http_api.c#L336-L378",
        "sd54804631b53": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/conf.c#L2001",
        "sb292974b4326": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/listeners.c#L27-L42",
        "s7d30df48bf91": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/plugin_basic_auth.c#L56-L113",
        "sfe5a6152e92f": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/plugin_acl_check.c#L141-L201",
        "s12077f64a53c": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/man/mosquitto.conf.5.xml#L1663-L1671",
        "sfe6c64ab8f91": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/plugins/acl-file/acl_check.c",
        "sd5c8a4af302f": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/src/conf.c",
        "s2ad092f62c47": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/client/sub_client.c",
        "s36fbdb22e941": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/websockets.c#L296-L324",
        "s77ce3e259e2e": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/ChangeLog.txt#L14-L27",
        "sccb5a918eab8": "https://github.com/eclipse-mosquitto/mosquitto/blob/v2.1.2/src/plugin_acl_check.c#L149-L151",
        "sac794dfa8179": "https://raw.githubusercontent.com/eclipse-mosquitto/mosquitto/v2.1.2/src/bridge_topic.c"
      }
    },
    "v16": {
      "name": "Mosquitto legacy",
      "basis": "v1.6.15",
      "sources": {
        "scddf9e86ad6b": "https://github.com/eclipse-mosquitto/mosquitto/blob/v1.6.15/src/conf.c#L420-L468",
        "seb5311de9f93": "https://github.com/eclipse-mosquitto/mosquitto/blob/v1.6.15/src/net.c#L605-L690",
        "sbfaf2572ea61": "https://github.com/eclipse-mosquitto/mosquitto/blob/v1.6.15/man/mosquitto.conf.5.xml#L167-L185",
        "s0d1a10094e93": "https://github.com/eclipse-mosquitto/mosquitto/blob/v1.6.15/mosquitto.conf"
      }
    },
    "docs": {
      "name": "Mosquitto documentation",
      "basis": "unknown",
      "sources": {
        "s4d96861c4f39": "https://mosquitto.org/documentation/migrating-to-2-0/",
        "s66b826cab3e9": "https://mosquitto.org/documentation/listeners/per-listener-settings/",
        "sddca3657b9c1": "https://mosquitto.org/man/mosquitto_passwd-1.html",
        "s9aa3260c5b79": "https://mosquitto.org/documentation/authentication-methods/",
        "s1791866ca31b": "https://mosquitto.org/man/mosquitto-conf-5.html",
        "s280527f289d0": "https://mosquitto.org/documentation/plugins/acl-file/",
        "sd34bd50f5f0f": "https://mosquitto.org/man/mosquitto-8.html",
        "s6711164e3e5f": "https://mosquitto.org/man/mosquitto_sub-1.html",
        "s1476cea737a4": "https://mosquitto.org/man/mosquitto_pub-1.html"
      }
    },
    "library": {
      "name": "Mosquitto image catalogue",
      "basis": "920b00976e6e8335bab0a3fd293b95b6b2404ce3",
      "sources": {
        "s0d99329a59ae": "https://github.com/docker-library/official-images/blob/920b00976e6e8335bab0a3fd293b95b6b2404ce3/library/eclipse-mosquitto#L3-L13"
      }
    },
    "image": {
      "name": "Mosquitto image source",
      "basis": "5b74cce8a4fe2a73b57df6c703bfde2cfd535d60",
      "sources": {
        "sdfa81718b7ff": "https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/Dockerfile#L30",
        "s38217a9ac8cc": "https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/Dockerfile#L77-L80",
        "see5ae9bc6aa9": "https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/Dockerfile#L99-L101",
        "s90852e30653e": "https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/mosquitto.conf",
        "s2653cf87d9d0": "https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/docker-entrypoint.sh",
        "s48d123c4c6d9": "https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.1-alpine/README.md#L27-L28",
        "s270129425e74": "https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/1.6-openssl/Dockerfile#L66",
        "sd127367f6308": "https://github.com/eclipse-mosquitto/mosquitto/blob/5b74cce8a4fe2a73b57df6c703bfde2cfd535d60/docker/2.0-openssl/Dockerfile#L69"
      }
    },
    "release-notes": {
      "name": "Mosquitto release announcements",
      "basis": "unknown",
      "sources": {
        "s0c9ec2d6b65b": "https://mosquitto.org/blog/2026/01/version-2-1-0-released/",
        "s5529605a6416": "https://mosquitto.org/blog/2020/12/version-2-0-0-released/"
      }
    }
  },
  "claims": {
    "loopback-default": {"text": "2.0+ without listeners binds loopback and permits anonymous clients; it is not authenticated.", "components": ["docs"], "sources": ["docs:s4d96861c4f39"], "status": "REASONED"},
    "listener-default": {"text": "Explicit 2.0 listeners default to rejecting unauthenticated clients; an unspecified bind address is wildcard.", "components": ["docs", "v20"], "sources": ["docs:s4d96861c4f39", "v20:se7823193963b"], "status": "REASONED"},
    "image21": {"text": "Recorded 2.1.2 Alpine tags ship anonymous MQTT 1883 and HTTP API/dashboard 9883; override configuration and restrict publication.", "components": ["library", "image"], "sources": ["library:s0d99329a59ae", "image:sdfa81718b7ff", "image:s38217a9ac8cc", "image:see5ae9bc6aa9", "image:s90852e30653e", "image:s2653cf87d9d0", "image:s48d123c4c6d9"], "status": "REASONED"},
    "image-api": {"text": "2.1.2 HTTP API uses a dual-stack socket and exposes systree/listeners JSON and version text without shipped credentials/ACLs.", "components": ["v21"], "sources": ["v21:s539d2574fc70", "v21:s7f6c7c2e6cff", "v21:sca7b250a1900", "v21:s9c9708acb8f8", "v21:sedb9b3beddce", "v21:s5fbac0184a26", "v21:sd54804631b53", "v21:sb292974b4326", "v21:s7d30df48bf91", "v21:sfe5a6152e92f", "v21:s12077f64a53c"], "status": "REASONED"},
    "image16": {"text": "Recorded 1.6.15 image tags ship commented upstream config: wildcard 1883 and anonymous access.", "components": ["image", "v16"], "sources": ["image:s270129425e74", "v16:scddf9e86ad6b", "v16:seb5311de9f93", "v16:sbfaf2572ea61", "v16:s0d1a10094e93"], "status": "REASONED"},
    "image20": {"text": "Recorded 2.0.22 image tags ship commented upstream config and retain loopback-only defaults.", "components": ["image", "v20"], "sources": ["image:sd127367f6308", "v20:s10aff5e66af1"], "status": "REASONED"},
    "deprecation": {"text": "File-based examples target 2.0.22; password_file, acl_file and per_listener_settings are deprecated in 2.1, removal announced for 3.0.", "components": ["docs", "release-notes"], "sources": ["release-notes:s0c9ec2d6b65b", "docs:s66b826cab3e9"], "status": "REASONED"},
    "password-file": {"text": "Prompt for distinct device credentials; -c overwrites, and -D edits the file without terminating connections by itself.", "components": ["docs"], "sources": ["docs:sddca3657b9c1", "docs:s9aa3260c5b79"], "status": "REASONED"},
    "reload": {"text": "Reload changed credentials/ACLs; manual says connections unaffected, but 2.0.22 rechecks credentials; confirm deployed termination.", "components": ["docs", "v20"], "sources": ["docs:s9aa3260c5b79", "v20:s06316e74cf90"], "status": "REASONED"},
    "shared-policy": {"text": "per_listener_settings false shares authentication/ACL policy; flipping it is neither separation nor 2.1 migration.", "components": ["v20"], "sources": ["v20:s0705841d4141", "v20:se7823193963b"], "status": "REASONED"},
    "tls": {"text": "8883 TLS needs CA/certificate/key; optional require_certificate adds machine possession, not human MFA.", "components": ["docs", "v20"], "sources": ["docs:s1791866ca31b", "v20:se7823193963b"], "status": "REASONED"},
    "listener-apply": {"text": "Remove/firewall plaintext; confirm include_dir and restart for listener changes, which reload does not apply.", "components": ["docs"], "sources": ["docs:s1791866ca31b", "docs:s4d96861c4f39"], "status": "REASONED"},
    "acl-default": {"text": "Password authentication alone leaves application topics unrestricted without an authorization mechanism.", "components": ["docs", "v20"], "sources": ["docs:s9aa3260c5b79", "v20:s06316e74cf90"], "status": "REASONED"},
    "acl-users": {"text": "Unlisted access is denied; user means username; pre-user topic rules apply only to anonymous clients.", "components": ["docs", "v20"], "sources": ["docs:s280527f289d0", "v20:s06316e74cf90"], "status": "REASONED"},
    "acl-patterns": {"text": "Patterns apply to all users; %u/%c must occupy a whole topic level; prefer authenticated usernames over chosen client IDs.", "components": ["docs"], "sources": ["docs:s280527f289d0"], "status": "REASONED"},
    "sys": {"text": "deny was added in 2.0; repeat $SYS denial per user and probe $SYS/# explicitly because # excludes it.", "components": ["docs", "release-notes"], "sources": ["release-notes:s5529605a6416", "docs:sd34bd50f5f0f"], "status": "REASONED"},
    "subscription": {"text": "File ACLs filter message access, not SUBSCRIBE acceptance; accepted # alone is no bypass.", "components": ["v20", "v21"], "sources": ["v20:s06316e74cf90", "v21:sfe6c64ab8f91"], "status": "REASONED"},
    "connection-default": {"text": "Per-listener max_connections defaults to -1, unlimited by this setting.", "components": ["v20"], "sources": ["v20:s0705841d4141"], "status": "REASONED"},
    "packet-default": {"text": "max_packet_size is unset in 2.0.22 and 2,000,000 bytes in 2.1; explicit 2.0.22 values must be at least 20.", "components": ["v20", "v21", "release-notes"], "sources": ["v20:s1f256b35dde7", "v21:sd5c8a4af302f", "release-notes:s0c9ec2d6b65b"], "status": "REASONED"},
    "payload-default": {"text": "message_size_limit defaults to 0; payload rejection follows reception and completes QoS acknowledgements.", "components": ["v20"], "sources": ["v20:s0705841d4141", "v20:sa4ab07ef74c3"], "status": "REASONED"},
    "inflight-default": {"text": "max_inflight_messages defaults to 20 per client for outgoing QoS 1/2; it is not a message-rate limit.", "components": ["v20"], "sources": ["v20:s0705841d4141"], "status": "REASONED"},
    "queue-default": {"text": "max_queued_messages defaults to 1000 in 2.x, 100 earlier; queue overflow can lose messages.", "components": ["v20", "release-notes"], "sources": ["v20:s0705841d4141", "release-notes:s5529605a6416"], "status": "REASONED"},
    "queue-bytes": {"text": "max_queued_bytes defaults to 0; when both queue limits are set the first reached stops further queuing.", "components": ["v20"], "sources": ["v20:s0705841d4141"], "status": "REASONED"},
    "keepalive": {"text": "max_keepalive defaults to 0 in 2.0.22/2.1.2; positive limits override MQTT 5 and reject incompatible MQTT 3.1.1.", "components": ["v20", "v21"], "sources": ["v20:s1f256b35dde7", "v21:sd5c8a4af302f", "v20:se7823193963b"], "status": "REASONED"},
    "packet-boundary": {"text": "2.0.22 TCP checks size before body allocation; 2.0.22/2.1.2 libwebsockets allocate without that check; require an independent boundary.", "components": ["v20", "v21"], "sources": ["v20:se4dab27858b2", "v20:se7823193963b", "v20:s1172d84efc29", "v21:s36fbdb22e941"], "status": "REASONED"},
    "global-limits": {"text": "2.1 global_max_connections/global_max_clients default to -1; the latter also counts disconnected persistent sessions.", "components": ["docs", "v21", "release-notes"], "sources": ["docs:s1791866ca31b", "release-notes:s0c9ec2d6b65b", "v21:sd5c8a4af302f"], "status": "REASONED"},
    "session-expiry": {"text": "2.0 persistent-session growth needs identity/client-ID limits; persistent_client_expiration is not a hard population cap.", "components": ["v20"], "sources": ["v20:se7823193963b", "v20:saf5cd7c6f12b"], "status": "REASONED"},
    "listener-policy": {"text": "2.0 per-listener settings must precede listeners/security options; place each listener's auth, ACL and TLS in its scope.", "components": ["v20"], "sources": ["v20:s1f256b35dde7", "v20:se7823193963b"], "status": "REASONED"},
    "websockets": {"text": "Local 9001 needs separate auth/ACL/TLS; 2.0.22 WebSockets connection cap is ineffective; 2.1.1 fix needs deployed-build testing.", "components": ["v20", "v21"], "sources": ["v20:se7823193963b", "v20:s1172d84efc29", "v21:s77ce3e259e2e"], "status": "REASONED"},
    "persistent-policy": {"text": "Listeners share topic/session namespaces; disconnected persistent clients retain their most recent listener's ACL policy.", "components": ["v20"], "sources": ["v20:s0705841d4141"], "status": "REASONED"},
    "client-id": {"text": "use_username_as_clientid is per-listener and needs restart; globally consistent usernames prevent cross-identity ID takeover, not same-user displacement.", "components": ["v20"], "sources": ["v20:se7823193963b", "v20:saff73f3b983e"], "status": "REASONED"},
    "migration": {"text": "2.1 listener_allow_anonymous and plugin_load/plugin_use replace listener policy; attach password-file and ACL-file plugins explicitly.", "components": ["docs"], "sources": ["docs:s66b826cab3e9"], "status": "REASONED"},
    "bridge-tls": {"text": "Port 8883 alone enables no bridge TLS; require CA/hostname verification, protected remote password and optional client certificate.", "components": ["v20"], "sources": ["v20:s0705841d4141", "v20:se7823193963b"], "status": "REASONED"},
    "bridge-topics": {"text": "Bridge contexts bypass local ACLs and 2.1.2 accepts unmatched ingress topics; narrow routes/remote ACLs do not contain malicious upstream.", "components": ["v20", "v21"], "sources": ["v20:s0705841d4141", "v20:s06316e74cf90", "v21:sfe5a6152e92f", "v20:sa116e59b51a4", "v21:sccb5a918eab8", "v21:sac794dfa8179"], "status": "REASONED"},
    "bridge-options": {"text": "try_private aids bridge handling, not auth; restart_timeout supplies backoff; notifications false suppresses default $SYS status writes.", "components": ["v20"], "sources": ["v20:s0705841d4141"], "status": "REASONED"},
    "runtime": {"text": "Dedicated runtime identity needs readable security files and writable protected state/log paths after the early 2.0 privilege drop.", "components": ["docs"], "sources": ["docs:s1791866ca31b", "docs:s4d96861c4f39"], "status": "REASONED"},
    "persistence": {"text": "Persistence defaults false; persistence_location alone does not enable it; protect data, logs, secrets and backups.", "components": ["docs"], "sources": ["docs:s1791866ca31b"], "status": "REASONED"},
    "client-config": {"text": "Verify uses protected 2.1 client -o files; 2.0 lacks -o and needs isolated default configurations.", "components": ["docs"], "sources": ["docs:s6711164e3e5f", "docs:s1476cea737a4"], "status": "REASONED"},
    "verify-auth": {"text": "Authenticated CONNACK succeeds and anonymous CONNECT rejects; timeout exit 27, SUBACK and transport failures prove no authentication.", "components": ["docs", "v21"], "sources": ["docs:s6711164e3e5f", "docs:s9aa3260c5b79", "v21:s2ad092f62c47"], "status": "REASONED", "verify": [1]},
    "verify-mtls": {"text": "Missing certificate must fail at TLS while trusted certificate succeeds; then separately test MQTT credentials.", "components": ["docs"], "sources": ["docs:s1791866ca31b", "docs:s6711164e3e5f"], "status": "REASONED", "verify": [1]},
    "verify-network": {"text": "Inspect actual namespace and external IPv4/IPv6/NAT paths; removed plaintext/WebSocket endpoints must not answer.", "components": ["docs", "v20"], "sources": ["docs:s4d96861c4f39", "v20:se7823193963b"], "status": "REASONED", "verify": [2, 3]},
    "verify-delivery": {"text": "Require own telemetry, cross-device isolation and controller before/after markers around denied injection; inspect PUBACK and delivery.", "components": ["docs", "v20", "v21"], "sources": ["docs:s280527f289d0", "docs:s1476cea737a4", "v20:s06316e74cf90", "v21:sfe6c64ab8f91", "v20:sa4ab07ef74c3"], "status": "REASONED", "verify": [4, 5]},
    "verify-sys": {"text": "Require exposed telemetry plus authorized marker control; fixed devices receive no $SYS messages.", "components": ["docs"], "sources": ["docs:sd34bd50f5f0f"], "status": "REASONED", "verify": [4]},
    "verify-resources": {"text": "Separate packet allocation, payload, queue, inflight, keepalive, connection and session tests need matched healthy controls.", "components": ["v20", "v21"], "sources": ["v20:s1f256b35dde7", "v21:sd5c8a4af302f", "v20:se7823193963b", "v20:se4dab27858b2", "v20:sa4ab07ef74c3"], "status": "REASONED"},
    "verify-bridges": {"text": "Test scoped delivery, TLS identity, remote ACLs and malicious-upstream containment independently; inspect runtime permissions and persistence.", "components": ["v20"], "sources": ["v20:s0705841d4141", "v20:s06316e74cf90"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
