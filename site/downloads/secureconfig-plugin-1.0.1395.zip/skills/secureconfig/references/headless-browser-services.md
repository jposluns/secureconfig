# Headless browser services: Chrome DevTools Protocol, Selenium Grid, browserless, and Playwright server

Chrome DevTools Protocol, Selenium Grid, browserless and Playwright server let programs control a real browser for testing, scraping or AI agents. This guide helps your AI assistant configure each securely, including automation ports on loopback or a restricted private network, authenticated remote access, limited browser egress, and protected connection URLs.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/headless-browser-services.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Chromium 154.0.8037.57, browserless (open source) 2.56.7, browserless Playwright file-protocol fix 2.51.0, Playwright source v1.58.2, and curl documentation curl-8_14_1; 2 further sources are pinned to a commit and 6 carry no recorded version. Metadata reviewed 2026-10-05; documentation checked October 2026. The guide records 32 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Agent and scraping stacks run these to drive a real browser, and that is exactly the exposure: whoever
reaches the endpoint gets JavaScript execution inside the pages the browser opens, the profile's cookie
jar, and a pivot from the service's own network position, including internal panels and the cloud
metadata endpoint ([egress-metadata.md](egress-metadata.md)). An exposed browser automation port is
usually unauthenticated code execution and credential theft, not just data. None of these command-line
automation endpoints requires authentication by default. Inspect the actual listeners and any
forwarders: the headline mistake is letting the network reach the port at all. Restrict the
service's own egress as well as its inbound reach, front the listeners per
[fronting-auth.md](fronting-auth.md), [nginx.md](nginx.md) or [caddy.md](caddy.md), keep them private
per [docker.md](docker.md) and [tunnels.md](tunnels.md), and treat every connection URL as a secret
([secrets.md](secrets.md)).

## Chrome DevTools Protocol

A Chrome or Chromium started with `--remote-debugging-port=9222` speaks the DevTools Protocol without
client authentication. At `154.0.8037.57` (commit
`73c14f6228d7cd537c855007e8f88678969cc0eb`), the full browser, including `--headless`, and
`chrome-headless-shell` bind that TCP listener only to `127.0.0.1`, trying `::1` if the IPv4 bind
fails. Neither has a `--remote-debugging-address` switch at this version. A non-loopback DevTools
listener therefore means a forwarder or a modified build, not an address flag on either stock binary.
Publishing a container port cannot reach a socket that is still loopback-bound inside the container;
inspect the process that actually binds the published port, not only the compose file.

For an explicit nonzero port, both try the same port on IPv6 and fail to start the listener if both
binds fail. They do not silently choose another port when `9222` is busy. Explicit
`--remote-debugging-port=0` requests an ephemeral port. The full browser also has a separate,
feature-gated approval mode enabled through `chrome://inspect`: it reads the previous port from
`DevToolsActivePort` or starts with `9222`. For a nonzero requested port, it tries IPv4 at that port,
IPv4 at port `0`, IPv6 at the requested port, and IPv6 at port `0`, stopping at the first success.
This mode asks for user approval; the command-line port and pipe modes take precedence over it. Inspect the actual listening address and port in
`ss -tlnp` and the `DevTools listening on` stderr message, plus `DevToolsActivePort` when written,
rather than assuming every debugging session uses `9222`.

In command-line port mode, `GET /json` lists target WebSocket debugger URLs and `/json/version`
returns the browser WebSocket debugger URL. A client on that socket has `Runtime.evaluate`
(arbitrary JavaScript in pages), the Network domain (cookies and credentials), and control of tabs.
The Host and WebSocket Origin checks are not client authentication. There is no password flag for this
mode, so keep the port on loopback and reach it over an SSH tunnel ([tunnels.md](tunnels.md)), or use
an authenticating proxy on a private network. Never expose an unauthenticated forward or proxy.
Approval mode rejects the JSON discovery routes with `404`, so that status is not proof of isolation.

The Chrome 136 change ignores `--remote-debugging-port` and `--remote-debugging-pipe` when they
would debug the default user data directory. At the pinned source this check applies to
`GOOGLE_CHROME_BRANDING` desktop builds on Windows, macOS and Linux, not normal Chromium builds
(a test-only hook can enable it there). Use an explicit, non-default `--user-data-dir`.
The `RemoteDebuggingAllowed` enterprise policy can disable remote debugging: the browser checks
`prefs::kDevToolsRemoteDebuggingAllowed` before starting either command-line mode or approval mode.
The separate headless-shell startup path has no corresponding profile or policy check.
The existing Chrome vendor announcement says Chrome for Testing retains the older behaviour; the
source subset reviewed here does not establish its build branding, so that exemption rests on the
vendor announcement, not an inferred branding equivalence.

`--remote-debugging-pipe` uses pipes, not a TCP listener. Supplying it alone opens no DevTools TCP
port; supplying `--remote-debugging-port` as well can still start the independent TCP listener in
both the browser and headless shell. Pipe access still grants browser control.

## Selenium Grid

Selenium Grid ships with no authentication enabled: the Router's basic-auth credentials (`--username`
and `--password`, or the `SE_ROUTER_USERNAME` and `SE_ROUTER_PASSWORD` variables on the Docker images)
are unset by default. Its default bind is not a loopback guarantee: the docs describe `--host` as
"usually determined automatically", the Docker images leave `SE_BIND_HOST` unset, and Grid 3 binds
`0.0.0.0` outright, so treat any Grid whose bind you have not set and observed as reachable, and set an
explicit `--host` (with `--bind-host`) to a private interface. The Router, Hub, Standalone and the Grid
web UI share port `4444`; a Node listens on `5555`. Distributed deployments add more unauthenticated
listeners: the event bus on `4442` and `4443`, and the Distributor, Session Map, event bus HTTP, and
New Session Queue on `5553`, `5556`, `5557` and `5559`. Firewall all of them. The event bus is not
protected by the Router's basic auth; `--registration-secret` makes participants validate each other's
event messages, but it is carried in those messages rather than encrypting the transport, so it does
not make a reachable bus safe on its own: run the bus on a private, trusted network with matching
secrets on every component.

`--password` and `--registration-secret` are command-line values: each puts its secret in the argv
of every process that receives it, from its start until the process overwrites its arguments, if it
does, readable through `ps` and `/proc/<pid>/cmdline` by other local accounts as well as by the same
account and root, and command-line auditing on the host can record it beyond that. Sources has no
reference for a Grid input outside argv for either secret. Do not assume `SE_ROUTER_PASSWORD`
avoids this. Sources has no reference for how the Docker images' start scripts pass that variable
to the Router, so it may still reach the `java` command line as `--password`; read the start script
in the image you run before relying on the variable. Wherever either secret reaches a command line (always for the flags; for `SE_ROUTER_PASSWORD` unless the start script shows otherwise), run Grid components only on
hosts where every local account other than the one running them and root is trusted with these
secrets. A secret that does stay in a process's environment is still readable through
`/proc/<pid>/environ` by the same account and root while that process, or any process that inherited it, runs.

The Docker browser images add two more listeners: they start VNC by default (`SE_START_VNC` defaults to
`true`) on `5900` with noVNC on `7900`, and the vendor's own example connects with the password
`secret`; change it with `SE_VNC_PASSWORD`, disable the prompt deliberately only with
`SE_VNC_NO_PASSWORD`, or turn VNC off with `SE_START_VNC=false`. `SE_VNC_PASSWORD` is an environment
credential: it is readable through `/proc/<pid>/environ` by the same account and root while any process
holding it runs. Sources has no reference for how the image passes `SE_VNC_PASSWORD` to the VNC server, so, as with `SE_ROUTER_PASSWORD`, that variable may reach a command line. The guidance for `SE_VNC_PASSWORD` is to read the image's start script before relying on the variable, and to apply the trusted-host condition above if the variable reaches a command line.
Selenium can terminate TLS itself with
`--https-certificate` and `--https-private-key`, but it is not enabled by default, and the Router's
basic auth travels in clear text without it; enabling native HTTPS or, more commonly, fronting the Grid
per [nginx.md](nginx.md), [caddy.md](caddy.md) and [fronting-auth.md](fronting-auth.md) is what protects
the credentials in transit.

## browserless

Open-source browserless `2.56.7` listens on port `3000` and reads `TOKEN` as
`process.env.TOKEN || null`: an unset or empty value becomes `null`, with no generated token.
Its default is unauthenticated endpoints, including routes that run caller-supplied browser code.
The current Docker configuration reference agrees; the older quickstart's generated-token claim
does not match this release. The current reference documents the same default for Enterprise,
but its private image was not inspected or run here, so equivalence is not source-verified.
Always set a long, randomized `TOKEN` (never a vendor sample, never committed), and publish the port to
loopback (`-p 127.0.0.1:3000:3000`) or keep it on an internal container network with no host mapping. `TOKEN` reaches the server through its environment, which keeps it out of the server's argv (a value typed on a launcher's command line, such as after `-e TOKEN=`, is in that launcher's argv instead) but not out of reach: it is readable through `/proc/<pid>/environ` by the same account and root for as long as the server, or any process that inherited it, runs.
The token is presented in the connection URL, so proxy and access logs become credential stores; front
the service with TLS so it is unreadable in transit, and handle the token as [secrets.md](secrets.md)
describes.

Require browserless **2.51.0 or later containing
[fix a18a1231ead2ecc4114347d5d1fafd69bffeb735](https://github.com/browserless/browserless/commit/a18a1231ead2ecc4114347d5d1fafd69bffeb735)**,
and keep `ALLOW_FILE_PROTOCOL=false`. Earlier builds can allow authenticated Playwright WebSocket
clients to read container files despite that setting (CVE-2026-92811). The
[v2.51.0 changelog](https://raw.githubusercontent.com/browserless/browserless/v2.51.0/CHANGELOG.md)
records the fix; the [CVE record](https://raw.githubusercontent.com/CVEProject/cvelistV5/b0b0976792a7c9d6d66ee553050c21cb088a0659/cves/2026/92xxx/CVE-2026-92811.json)
lists a conflicting affected range of 1.44.0 through 2.56.7 inclusive, so run the file-protocol check
below rather than rely on the version alone. browserless terminates no TLS of its own, so the
fronting layer is where HTTPS lives.

## Playwright server

`browserType.launchServer()` and `playwright run-server` expose a `ws://` endpoint, and there is no
password or user model. Do not rely on the endpoint path as a secret: `run-server` defaults its
`--path` to `/`, so the CLI form has no secret path at all, and while `launchServer()` generates an
unguessable path, the server answers `GET /json` with its own endpoint path, so a client that can reach
the port can discover it. Treat a reachable Playwright port as the finding. The exposure is binding it
outward, which the Docker documentation's own `run-server --host 0.0.0.0` example does; Playwright's
documentation warns that a process that reaches the endpoint "can take control of the OS user". Bind the
server to `127.0.0.1` explicitly, never log or commit the `wsEndpoint` URL or bake it into an image, and
put a reverse proxy in front that authenticates both the WebSocket upgrade and the discovery routes and
terminates `wss://` (`connect()` accepts custom `headers` a proxy can require) per
[fronting-auth.md](fronting-auth.md) and [nginx.md](nginx.md). Playwright serves no TLS itself.

## Shared exposures

Every one of these drives a real browser, so an exposed endpoint is typically unauthenticated code
execution plus session theft plus a pivot: the browser can reach internal panels, unauthenticated
internal APIs, and the cloud metadata endpoint from inside your network
([egress-metadata.md](egress-metadata.md)), which is why restricting the service's egress matters as
much as its inbound reach. Local-file reads through `file://` are part of that reach for a raw CDP,
Selenium, or Playwright browser, though a fronting tool may block them (browserless requires the
fixed version and setting described above, plus the file-protocol check below).
One path ties the four together: Selenium, Playwright and browserless all drive Chromium over the
DevTools Protocol in the common case, so a debug port opened "just to inspect" a Node or a browserless
container (a stray `-p 9222:9222`) bypasses whatever authentication the front tool has. Keep 9222
unpublished wherever these run.

## Verify

REASONED: following block; this introduction and the listener inventory below for every DevTools, Grid, browserless, VNC and Playwright port it names, per the guide's cited Selenium Grid getting started, Selenium Docker images env vars, browserless Docker configuration and Chromium 154.0.8037.57 browser and headless-shell loopback factory entries. No isolated network namespace was available for a live listener, so no exposed or fixed service ran. During marking review (October 2026) both Verify blocks passed bash -n under bash 5.3.9, and the inventory's command, run without sudo on the review host as ss -tlnp (iproute2 6.19.0), showed none of these ports listening, with an empty process column, so it tested no target. The bash -n and ss runs recorded here covered both blocks in earlier forms: the inventory then ran ss at top level with no status of its own, and the guarded probe block's guard refusals left the subshell with status 0. The inventory's current form and the guarded probe block's previous form, which had no `curl` guard, passed bash -n and ShellCheck 0.11.0 in the repository's gate suite. The guarded probe block's current form adds a `command -v curl` guard, which refuses with status 2 and no curl call when curl is not installed; this guide records no run of the `curl`-guarded form. Stub runs of the current inventory with no network, in a clean shell and under an inherited `set -e`, `readonly` and `declare -i`, exited 0 when the stub ss listed only loopback listeners, 1 when it listed a named port on a wildcard address, 3 when it failed and 2 when ss was missing. Exposed, a listed port shows a wildcard or public bind; fixed, loopback or an internal address only. The inventory block exits 1 when a port it names is bound to a wildcard address, 3 when ss fails, 2 when ss is not installed, so nothing is listed, and otherwise 0, leaving every other address for you to judge. Every live check below is **REASONED**, not demonstrated: the authoring host forbids opening listeners
without an isolated network namespace, and has none. No exposed or fixed service was run.
Each names its expected exposed and fixed result so
it discriminates when run against a live instance, based on the cited vendor documentation and pinned sources. Run each
probe from an external vantage, not the service host, and run its positive control (for a token-gated
service, an authorized request that succeeds) so a dead service or a blocked local socket is not
misread as fixed. A transport failure is inconclusive on its own: read the `err` field and confirm the
failure happened while connecting to the target (a connection refusal from that vantage), not because a
local policy blocked the probe or a slow response outlasted `--max-time`. These write-out fields need
curl 7.75.0 or newer, and an IPv6 literal needs brackets in the URL.

```bash
# Listener inventory, REASONED as the paragraph above records: it follows the cited vendor documentation and pinned sources;
# the authoring host lacks an isolated network namespace for authorized live listeners.
# On the host: these listeners should be bound to loopback or an internal interface, not a wildcard.
# The block also checks the distributed Grid ports (5553, 5556, 5557, 5559); judge your Playwright port yourself if you run it.
(                                   # a subshell, so the exits below end only the subshell
  command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
  set -- 0 "$(if ss -tlnp; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0; a missing ss has already exited 2 above), then the listeners
  set -- "$1" "${2%$'\n'*}" "${2##*$'\n'}"                                    # status, the listener table, then ss's exit status
  printf '%s' "$2"   # read every listener; 9222/4442/4443/4444/5555/3000/5900/7900/5553/5556/5557/5559: loopback or internal only
  [ "$3" = 0 ] || { echo "ss -tlnp exit $3: the listener inventory failed; inconclusive"; set -- 3 "$2" "$3"; }
  if printf '%s' "$2" | awk '$4 ~ /:(9222|4442|4443|4444|5555|3000|5900|7900|5553|5556|5557|5559)$/ && ($4 ~ /^0\.0\.0\.0:/ || index($4, "*:") == 1 || index($4, "[::]:") == 1 || index($4, ":::") == 1) { print; found = 1 } END { exit !found }'; then
    echo "FINDING: the rows just above bind a port this block names to a wildcard address, the exposed state"; set -- 1 "$2" "$3"
  else
    case "$?" in 1) ;; *) echo "awk could not read the listener list; inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" "$3" ;; esac
  fi
  echo "block exit $1; every address that is not a wildcard, and your Playwright port, is left for you to judge"
  exit "$1"
)
```

### DevTools listener and service probes

REASONED: the listener inventory above for every port it names, and this DevTools TCP listener check, per the guide's cited Chromium 154.0.8037.57 entries for the browser loopback factories, the headless-shell loopback factory and the actual bound address and DevToolsActivePort output. The same REASONED marking also rests on the guide's cited Selenium Grid getting started, Selenium Docker images env vars and browserless Docker configuration entries for the other ports. A google-chrome binary of unchecked version is present in the authoring environment, but no isolated network namespace was available (creating one was refused), so no DevTools listener or forwarder was started and neither state was observed; the expected exposed and fixed results are those stated here. **REASONED DevTools listener check:** for the pinned stock browser and headless shell, expect only
`127.0.0.1` or `::1` for the DevTools TCP listener. Inspect both address families and every actual
port, including ephemeral ports, plus forwarders in the host and container network namespaces.
Exposed, a forwarder supplies a reachable non-loopback listener; fixed, no unauthenticated external
path remains while the local browser endpoint still answers. The pinned socket factories and HTTP
handler below establish these expected results.

REASONED: the guard and substitution instructions for the DevTools, Grid, browserless and Playwright probes, per the guide's cited curl diagnostic variables entry (pinned tag curl-8_14_1) and Chromium 154.0.8037.57 host check entry. During marking review (October 2026) the guarded block ran in bash 5.3.9 with a stub curl and no network: unchanged, it printed its substitute-your-own-address refusal; without its set -- line, the paste-the-whole-block refusal; with two values, the exactly-1-value refusal. The guarded block's marking-review testing (October 2026, bash 5.3.9, stub curl, no network) also showed that, with 203.0.113.10 substituted, the stub received http://203.0.113.10:9222/json/version, and the 4444/status and 3000/pressure edits reached the stub as written. The stub runs recorded here covered the guarded block in an earlier form, which took one value, ended with curl's own status and whose guard refusals left the subshell with status 0; none was re-run on the previous form, which had no `curl` guard and passed bash -n and ShellCheck 0.11.0 in the repository's gate suite. The current form adds a `command -v curl` guard, which refuses with status 2 and no curl call when curl is not installed; this guide records no run of the `curl`-guarded form. No endpoint was probed, so the exposed and fixed results below remain unobserved. For the DevTools, Grid, browserless and Playwright ports, guard the address in the block below so it
forces a real substitution, and read the write-out. Replace `9222` in the curl URL with the actual
externally forwarded port if different. Substitute `external` as the block's second value for the
probe from another host. For the local positive control, run the same guarded block inside the
browser's network namespace with its actual loopback address and DevTools port, and `control` as its
second value. Substitute an IP literal, not a name, for the DevTools probe, because the endpoint
rejects a forwarded `Host` that is not an address or localhost.

REASONED: following block; external discovery/authentication probes and local positive controls follow the cited vendor documentation and pinned sources; the authoring host has no isolated network namespace for authorized live listeners.

```bash
(                              # a subshell, so your own script arguments are untouched
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_PUBLIC_IP' 'REPLACE_WITH_external_OR_control'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$2" in
    external|control) : ;;
    *) echo "substitute external (the probe from another host) or control (the local positive control) as the second value on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$1" in
    *REPLACE_WITH_*|*YOUR_PUBLIC_IP*|"") echo "substitute your own address on the set -- line above; not probing"; exit 2 ;;
    *) command -v curl >/dev/null || { echo "curl is not installed here; not probing"; exit 2; }
       set -- "$1" "$2" "$(if curl -q -g -sS -i --noproxy '*' --connect-timeout 5 --max-time 20 \
         -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "http://$1:9222/json/version"; then printf '\n0'; else printf '\n%s' "$?"; fi)" ;;
  esac
  set -- "$2" "${3##*$'\n'}" "${3%$'\n'*}"       # external or control, then curl's exit status and its output
  printf '%s' "$3"
  set -- "$1" "$2" "${3%$'\n'}"
  set -- "$1" "$2" "${3##*$'\n'}"                # external or control, curl's exit status, then its http= exit= err= line
  case "$1:$2:$3" in
    external:0:"http=404 "*) echo "HTTP 404: approval mode's 404 is not a pass, and this block cannot tell it from another 404; inconclusive"; set -- 3 ;;
    external:0:*) echo "FINDING: an HTTP answer from this vantage, so the endpoint is reachable, which is not the fixed state"; set -- 1 ;;
    external:7:*) echo "curl exit 7: no connection from this vantage, consistent with isolation but not proof of the configuration; read err to confirm the target refused it, and run the local positive control"; set -- 0 ;;
    control:0:"http=2"??" "*) echo "the positive control answered; read its body (for DevTools, JSON containing webSocketDebuggerUrl)"; set -- 0 ;;
    control:0:*) echo "the positive control did not answer with a 2xx, so it failed; inconclusive"; set -- 3 ;;
    *) echo "curl exit $2: a transport failure is inconclusive on its own, and a timeout may have come after the connect; read err"; set -- 3 ;;
  esac
  echo "block exit $1; the headers and body above are left for you to judge against the expectations for the port you probed"
  exit "$1"
)
```

REASONED: preceding block; the external DevTools, Selenium Grid Router and Node, browserless and Playwright probes and their local positive controls, per the guide's cited Chromium 154.0.8037.57 host check, JSON discovery, approval-mode 404 and browser WebSocket URL entry, Selenium Grid CLI options, browserless 2.56.7 TOKEN initialization and HTTP and WebSocket authentication rejection entries. The same REASONED marking also rests on the guide's cited browserless pressure API entry, Playwright Docker entry, Playwright BrowserType.launchServer and connect entry, Playwright run-server default path, generated launchServer path and GET /json discovery (pinned tag v1.58.2) entry, and curl diagnostic variables added in 7.75.0 and configuration input from stdin (pinned tag curl-8_14_1) entry. No container runtime or isolated network namespace was available, so no service ran. During marking review (October 2026) the guard branches ran with a stub curl as recorded above, and the token configuration pattern, run as an author-built block following this paragraph's instructions (the guide prints no such block) with a stub curl and a dummy token holding a double quote and a backslash, kept the token out of argv and sent the escaped url line on stdin. The guard-branch stub runs covered the guarded block in an earlier form, which took one value, ended with curl's own status and whose guard refusals left the subshell with status 0; none was re-run on the previous form, which had no `curl` guard and passed bash -n and ShellCheck 0.11.0 in the repository's gate suite. The current form adds a `command -v curl` guard, which refuses with status 2 and no curl call when curl is not installed; this guide records no run of the `curl`-guarded form. The expected exposed and fixed results are those stated here. **REASONED command-line DevTools port probe:** exposed through an unauthenticated forwarder, it returns
a `200` JSON body containing `webSocketDebuggerUrl`. Fixed, the external request cannot reach that
endpoint while the local positive control still returns it. A `404` from approval mode is not a pass.
A connection refused or a timeout that happened during the connect is consistent with
isolation from that vantage, not proof of the configuration. The block exits 2, before any request,
when a guard refuses its input or curl is not installed. With `external`, the block exits 1
for any HTTP answer except a `404`; 3 for a `404`, which it cannot tell from approval mode's, and
for any failure other than curl exit 7, including a timeout it cannot place before or after the
connect; and 0 for curl exit 7, which it reports as consistent with isolation but not proof. A
`404` from a Playwright port, which is already the finding, therefore also exits 3. With
`control`, it exits 0 for a `2xx` answer and 3 otherwise. To check the other services, change the
URL in the block's `curl` line, leaving the guard lines intact, to each port in turn:
`http://$1:4444/status` for a Selenium Grid Router, Hub or Standalone, `http://$1:5555/status`
for a Node, `http://$1:3000/pressure` for open-source browserless `2.56.7`. The Selenium Grid
`4444/status` result reads as follows: a `200` JSON `ready` and node inventory is exposure; the
`-i` prints the headers, so a `401` with `WWW-Authenticate: Basic` means the Router auth is on but
the port is still reachable, which is not the fixed state. The open-source browserless `2.56.7`
`3000/pressure` instruction is: with `TOKEN` unset or empty, expect `200` with load JSON; with a
nonempty `TOKEN`, expect `401` for both the tokenless request and a deliberately wrong `?token=`
value, then confirm the correct token returns the load JSON.
These are REASONED expectations from the cited configuration, API documentation and HTTP rejection
handler, not live observations; this authoring environment has no container runtime and cannot
fetch runtime dependencies. A `401` establishes authentication, not network isolation: the fixed
deployment must also deny the external path while an authorized internal control still succeeds.
Pass the correct token through curl's stdin configuration, as a `url = "...?token=..."` line fed to
`--config -`, not a literal URL in shell history or argv. Because the config value is double-quoted,
escape a backslash and then a double quote in the token before substituting it, and refuse a token
containing a control character, so a pasted newline cannot inject a second directive. Enter the
token at a hidden prompt in a clean shell under the `read` exception guards of
CONTRIBUTING rule 7 (`search-engines.md`'s paired block is the model): `trap - DEBUG RETURN ERR`
first, then `set +x +a +e` before the read, `unset -n` and then `unset -v` on the variable, failing
closed if either fails, and a refusal of a readonly `IFS`. Without `+a`, an inherited `set -a` would
export the token. A token typed into the command still enters shell history and `set -x` tracing,
and stdin closes the argv channel only, so the token stays visible to the account owner and root.
For the Playwright server on the port you configured
(`launchServer` uses an ephemeral port unless you set one; `run-server` takes `--port`), any HTTP
answer means the port is reachable and is already the finding. The distinguishing behaviour for
each is in the cited vendor pages.

REASONED: browserless Playwright WebSocket file-protocol enforcement on every enabled route, per the guide's cited browserless 2.51.0 Playwright WebSocket route table, browserless 2.51.0 Playwright WebSocket enforcement and blocked-URL policy close, and Browserless ALLOW_FILE_PROTOCOL configuration and false default entries. It needs a running browserless 2.51.0 container and a compatible Playwright client; the authoring environment has no container runtime, no Playwright or browserless package and no network to fetch them, and the check has no shell block, so nothing here ran locally. Exposed, page.evaluate returns the canary contents; fixed, the navigation is refused with a blocked-URL policy close. **REASONED browserless file-protocol check:** no live instance was tested: the authoring host forbids
opening listeners without an isolated network namespace, and has none. With
`ALLOW_FILE_PROTOCOL=false`, use a valid token and a compatible Playwright client on each enabled
Playwright WebSocket route. The v2.51.0
[route table](https://github.com/browserless/browserless/blob/v2.51.0/src/http.ts#L91-L103) defines
`/chromium/playwright`, `/chrome/playwright`, `/edge/playwright`, `/firefox/playwright` and
`/webkit/playwright`, plus the `/playwright/chromium`, `/playwright/chrome`, `/playwright/firefox` and
`/playwright/webkit` aliases; test every one that is enabled. First confirm ordinary HTTP navigation
succeeds. Then call `page.goto('file:///tmp/secureconfig-canary.txt')` against a harmless canary with
known contents already confirmed readable by the browser process inside the container. On an exposed
build, expect `page.evaluate(() => document.body.innerText)` to return the canary contents. The
[fixed implementation](https://raw.githubusercontent.com/browserless/browserless/v2.51.0/src/browsers/browsers.playwright.ts)
refuses the navigation and closes the session with a blocked-URL policy reason. Confirm that reason;
missing files, authentication failures, connection failures, and timeouts are inconclusive. Passing
`/pressure` or a CDP-only check does not establish Playwright enforcement.

## Sources (checked October 2026)

- Chromium 154.0.8037.57 browser loopback factories and approval-mode port fallback: https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/chrome/browser/devtools/remote_debugging_server.cc#L69-L158
- Chromium 154.0.8037.57 browser branding/profile and policy checks; approval-mode startup, with the `kDefaultDevToolsPort` 9222 fallback. Chromium 154.0.8037.57 sources: https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/chrome/browser/devtools/remote_debugging_server.cc#L160-L282 and https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/chrome/browser/devtools/remote_debugging_server.h#L26
- Browser command-line pipe/port startup and precedence over approval mode (Chromium 154.0.8037.57): https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/chrome/browser/devtools/remote_debugging_server.cc#L325-L417
- Headless-shell loopback factory and pipe/port startup (Chromium 154.0.8037.57): https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/headless/lib/browser/headless_devtools.cc#L31-L145
- Headless-shell command-line port and pipe handling (Chromium 154.0.8037.57): https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/headless/lib/browser/command_line_handler.cc#L199-L206
- Content pipe and port switch definitions (Chromium 154.0.8037.57): https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/public/common/content_switches.cc#L596-L607
- Actual bound address, stderr endpoint and DevToolsActivePort output (Chromium 154.0.8037.57): https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/browser/devtools/devtools_http_handler.cc#L267-L312
- Host check, JSON discovery, approval-mode 404 and browser WebSocket URL (Chromium 154.0.8037.57): https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/browser/devtools/devtools_http_handler.cc#L459-L630
- WebSocket Origin check, approval mode and unauthenticated command-line mode (Chromium 154.0.8037.57): https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/browser/devtools/devtools_http_handler.cc#L811-L880
- Target WebSocket URL serialization (Chromium 154.0.8037.57): https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/browser/devtools/devtools_http_handler.cc#L1032-L1055
- Chrome DevTools Protocol remote debugging: https://developer.chrome.com/docs/devtools/remote-debugging/
- Chrome DevTools Protocol domains (Runtime, Network, Page): https://chromedevtools.github.io/devtools-protocol/
- Chrome 136 user-data-dir change and Chrome for Testing exemption: https://developer.chrome.com/blog/remote-debugging-port
- Selenium Grid CLI options (host, bind-host, username, password, https-certificate): https://www.selenium.dev/documentation/grid/configuration/cli_options/
- Selenium Grid getting started (components, ports, distributed topology): https://www.selenium.dev/documentation/grid/getting_started/
- Selenium Docker images env vars (SE_START_VNC, SE_VNC_PASSWORD, SE_BIND_HOST, SE_ROUTER_USERNAME): https://github.com/SeleniumHQ/docker-selenium/blob/aafe4d6136f3bb5afcd9b7cb691c624516d06e1b/ENV_VARIABLES.md
- browserless Docker configuration (TOKEN, ALLOW_FILE_PROTOCOL, port 3000): https://docs.browserless.io/enterprise/docker/config
- CVE-2026-92811 record (affected range 1.44.0 through 2.56.7 inclusive; conflicts with the vendor fix record): https://raw.githubusercontent.com/CVEProject/cvelistV5/b0b0976792a7c9d6d66ee553050c21cb088a0659/cves/2026/92xxx/CVE-2026-92811.json
- browserless 2.51.0 Playwright WebSocket route table: https://github.com/browserless/browserless/blob/v2.51.0/src/http.ts#L91-L103
- browserless 2.51.0 changelog (Playwright WebSocket file-protocol fix): https://raw.githubusercontent.com/browserless/browserless/v2.51.0/CHANGELOG.md
- browserless 2.51.0 pinned Playwright file-protocol fix a18a1231ead2ecc4114347d5d1fafd69bffeb735 (PR #5407): https://github.com/browserless/browserless/commit/a18a1231ead2ecc4114347d5d1fafd69bffeb735
- browserless 2.51.0 Playwright WebSocket enforcement and blocked-URL policy close: https://raw.githubusercontent.com/browserless/browserless/v2.51.0/src/browsers/browsers.playwright.ts
- browserless 2.56.7 TOKEN initialization: https://github.com/browserless/browserless/blob/v2.56.7/src/config.ts#L250
- browserless 2.56.7 HTTP and WebSocket authentication rejection: https://github.com/browserless/browserless/blob/v2.56.7/src/server.ts#L103-L117
- browserless 2.56.7 HTTP route authentication dispatch: https://github.com/browserless/browserless/blob/v2.56.7/src/server.ts#L264-L271
- browserless 2.56.7 WebSocket route authentication dispatch: https://github.com/browserless/browserless/blob/v2.56.7/src/server.ts#L445-L454
- browserless open-source Docker default and management endpoints (rolling documentation, checked September 2026): https://docs.browserless.io/enterprise/open-source
- browserless pressure API request and response (rolling documentation, checked September 2026): https://docs.browserless.io/enterprise/utility-functions/pressure
- Playwright BrowserType.launchServer and connect: https://playwright.dev/docs/api/class-browsertype
- Playwright Docker (run-server remote connection): https://playwright.dev/docs/docker
- Browserless ALLOW_FILE_PROTOCOL configuration and false default (pinned tag v2.51.0; version basis 2.51.0): https://raw.githubusercontent.com/browserless/browserless/v2.51.0/src/config.ts
- Playwright run-server default path, generated launchServer path and GET /json discovery (pinned tag v1.58.2). Playwright sources (pinned tag v1.58.2): https://github.com/microsoft/playwright/blob/v1.58.2/packages/playwright-core/src/cli/program.ts#L292-L307, https://raw.githubusercontent.com/microsoft/playwright/v1.58.2/packages/playwright-core/src/browserServerImpl.ts, https://raw.githubusercontent.com/microsoft/playwright/v1.58.2/packages/playwright-core/src/remote/playwrightServer.ts
- curl diagnostic variables added in 7.75.0 and configuration input from stdin (pinned tag curl-8_14_1): https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/write-out.md#L75-L79, https://raw.githubusercontent.com/curl/curl/curl-8_14_1/docs/cmdline-opts/config.md


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- chromium: Chromium (154.0.8037.57)
- browserless-token-default: browserless (open source) (2.56.7)
- browserless-file-fix: browserless Playwright file-protocol fix (2.51.0)
- playwright-source: Playwright source (v1.58.2)
- cdp: Chrome DevTools Protocol (unknown)
- chrome-change: Chrome remote-debugging announcement (unknown)
- selenium: Selenium Grid (unknown)
- selenium-docker: Selenium Docker images (aafe4d6136f3bb5afcd9b7cb691c624516d06e1b)
- browserless: browserless (unknown)
- browserless-docs: browserless documentation (rolling) (unknown)
- playwright: Playwright (unknown)
- curl-docs: curl documentation (curl-8_14_1)
- cve-record-source: CVE-2026-92811 record snapshot (b0b0976792a7c9d6d66ee553050c21cb088a0659)

Claims (full source mapping in the JSON block below):

- cdp-bind (REASONED; chromium): Command-line DevTools binds 127.0.0.1, falling back to ::1; stock browser and headless shell have no remote-debugging-address switch.
- cdp-port (REASONED; chromium): Explicit nonzero DevTools ports do not fall back to another port; port 0 requests an ephemeral port.
- cdp-approval (REASONED; chromium): Feature-gated approval mode uses DevToolsActivePort or 9222, with requested/ephemeral IPv4 then IPv6 fallback; command-line modes take precedence.
- cdp-discovery (REASONED; chromium): Command-line /json and /json/version disclose debugger URLs; approval-mode 404 does not establish isolation.
- cdp-auth (REASONED; chromium): Command-line CDP has no client authentication or password flag; Host and Origin checks do not authenticate clients.
- cdp-capabilities (REASONED; cdp): CDP grants page JavaScript, cookie/credential and tab control; restrict ingress, browser egress and local-file reach.
- cdp-private (REASONED; chromium): Keep DevTools loopback/private behind authenticated access; inspect forwarders and container namespaces, since publishing cannot reach container loopback.
- cdp-profile (REASONED; chrome-change, chromium): Chrome 136 requires non-default user data; pinned desktop branding check excludes normal Chromium, and Chrome for Testing exemption rests on the announcement.
- cdp-policy (REASONED; chromium): RemoteDebuggingAllowed gates browser command-line and approval modes; headless-shell startup lacks the corresponding profile/policy check.
- cdp-pipe (REASONED; chromium): Pipe mode alone opens no TCP port; supplying a port too can start an independent listener, and pipe access still grants browser control.
- grid-auth (REASONED; selenium, selenium-docker): Router username/password are unset by default, including Docker SE_ROUTER_USERNAME and SE_ROUTER_PASSWORD.
- grid-bind (REASONED; selenium, selenium-docker): Grid host is usually autodetected; Docker SE_BIND_HOST is unset and historical Grid 3 binds 0.0.0.0. Set and observe a private host with bind-host.
- grid-ports (REASONED; selenium): Router, Hub, Standalone and UI use 4444; Nodes use 5555. Keep all private.
- grid-distributed (REASONED; selenium): Distributed event bus uses 4442/4443; Distributor, Session Map, bus HTTP and New Session Queue add 5553/5556/5557/5559.
- grid-bus (REASONED; selenium): Router Basic auth does not protect the bus; registration-secret validates event messages without encrypting transport, so isolate every participant.
- grid-vnc (REASONED; selenium-docker): Docker enables VNC by default on 5900 and noVNC on 7900; replace the example secret password or disable VNC, and avoid passwordless mode.
- grid-tls (REASONED; selenium): Native https-certificate/https-private-key or a TLS proxy protects Router Basic credentials; TLS is not on by default.
- browserless-auth (REASONED; browserless-token-default, browserless-docs): Open-source 2.56.7 reads an unset or empty TOKEN as null; no token is generated and endpoints are unauthenticated by default.
- browserless-bind (REASONED; browserless): browserless uses 3000; publish 127.0.0.1:3000:3000 or keep an internal network with no host mapping.
- browserless-token (REASONED; browserless): Use a randomized TOKEN, protect token-bearing connection URLs and logs, and terminate TLS at the fronting layer.
- browserless-file (REASONED; browserless, browserless-file-fix): Require browserless 2.51.0 or later containing the pinned Playwright fix, keep ALLOW_FILE_PROTOCOL=false, and run the file-protocol check.
- playwright-auth (REASONED; playwright): Playwright server has no password/user model; reachable endpoints grant OS-user control, so bind 127.0.0.1 and protect endpoint URLs.
- playwright-discovery (REASONED; playwright, playwright-source): Guide records run-server path / and launchServer random paths discoverable through GET /json; a secret path is not an access boundary.
- playwright-tls (REASONED; playwright): Authenticate WebSocket upgrades and discovery at a wss proxy; connect accepts custom headers and the server supplies no native TLS.
- debug-bypass (REASONED; cdp, selenium, browserless, playwright): A separately forwarded Chromium debug endpoint bypasses front-tool authentication; keep 9222 unpublished and restrict browser egress.
- verify-listeners (REASONED; chromium, selenium, selenium-docker, browserless, playwright): Inventory every listener, including distributed Grid and configured Playwright ports, and require intended loopback/private addresses.
- verify-cdp (REASONED; chromium, curl-docs): External command-line CDP returns 200 with webSocketDebuggerUrl when forwarded; fixed isolation retains a working local control. Approval-mode 404 is inconclusive.
- verify-grid (REASONED; selenium, curl-docs): Grid /status returns ready/node JSON when exposed; Router 401 with Basic challenge shows auth but still proves reachability. Probe Nodes separately.
- verify-browserless (REASONED; browserless-token-default, browserless-docs, curl-docs): For open-source 2.56.7, expect /pressure load JSON without a configured TOKEN; with a nonempty TOKEN, expect 401 for missing/wrong tokens and JSON for a correct-token control.
- verify-playwright (REASONED; playwright, playwright-source): Any HTTP answer proves Playwright reachability; launchServer uses an ephemeral port unless set, while run-server takes --port.
- browserless-file-cve (REASONED; browserless-file-fix, cve-record-source): CVE-2026-92811 describes authenticated Playwright file reads despite ALLOW_FILE_PROTOCOL=false; its affected range 1.44.0 through 2.56.7 conflicts with the vendor 2.51.0 fix.
- verify-browserless-file (REASONED; browserless-file-fix, cve-record-source): With a valid token on every enabled Playwright WebSocket route, confirm HTTP navigation first, then attempt a readable container canary: exposed returns contents; fixed refuses with a blocked-URL policy reason.

````json
{
  "schema": 1,
  "checked": "2026-10-05",
  "documentation_checked": "2026-10",
  "body_sha256": "e3ec106629244441687d5c36d3d27d69ea54f519f8bcf8df6fb8a559c89382b5",
  "components": {
    "chromium": {
      "name": "Chromium",
      "basis": "154.0.8037.57",
      "sources": {
        "s087ba883abe3": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/chrome/browser/devtools/remote_debugging_server.cc#L69-L158",
        "s65073710f8bd": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/chrome/browser/devtools/remote_debugging_server.cc#L160-L282",
        "sc62d44c2dee6": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/chrome/browser/devtools/remote_debugging_server.cc#L325-L417",
        "s6e1b34a120d1": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/headless/lib/browser/headless_devtools.cc#L31-L145",
        "sdf5f61d9b325": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/headless/lib/browser/command_line_handler.cc#L199-L206",
        "s005d90d4912a": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/public/common/content_switches.cc#L596-L607",
        "s804c1266fb81": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/browser/devtools/devtools_http_handler.cc#L267-L312",
        "s66b210123ff8": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/browser/devtools/devtools_http_handler.cc#L459-L630",
        "s1044899c624a": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/browser/devtools/devtools_http_handler.cc#L811-L880",
        "s1ca85f782546": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/content/browser/devtools/devtools_http_handler.cc#L1032-L1055",
        "s0a2a5fec4975": "https://github.com/chromium/chromium/blob/73c14f6228d7cd537c855007e8f88678969cc0eb/chrome/browser/devtools/remote_debugging_server.h#L26"
      }
    },
    "browserless-token-default": {
      "name": "browserless (open source)",
      "basis": "2.56.7",
      "sources": {
        "s87c144d59098": "https://github.com/browserless/browserless/blob/v2.56.7/src/config.ts#L250",
        "sdf3b808e8920": "https://github.com/browserless/browserless/blob/v2.56.7/src/server.ts#L103-L117",
        "se8b696d56eda": "https://github.com/browserless/browserless/blob/v2.56.7/src/server.ts#L264-L271",
        "sc7973e3e21df": "https://github.com/browserless/browserless/blob/v2.56.7/src/server.ts#L445-L454"
      }
    },
    "browserless-file-fix": {
      "name": "browserless Playwright file-protocol fix",
      "basis": "2.51.0",
      "sources": {
        "s94f1d485c2b7": "https://raw.githubusercontent.com/browserless/browserless/v2.51.0/CHANGELOG.md",
        "s90a20f6566c9": "https://github.com/browserless/browserless/commit/a18a1231ead2ecc4114347d5d1fafd69bffeb735",
        "sf2642da1de49": "https://raw.githubusercontent.com/browserless/browserless/v2.51.0/src/browsers/browsers.playwright.ts",
        "s7ee912fa0a9a": "https://github.com/browserless/browserless/blob/v2.51.0/src/http.ts#L91-L103",
        "sa985cbba01ad": "https://raw.githubusercontent.com/browserless/browserless/v2.51.0/src/config.ts"
      }
    },
    "playwright-source": {
      "name": "Playwright source",
      "basis": "v1.58.2",
      "sources": {
        "scb030dc29caf": "https://github.com/microsoft/playwright/blob/v1.58.2/packages/playwright-core/src/cli/program.ts#L292-L307",
        "sbbcd84289455": "https://raw.githubusercontent.com/microsoft/playwright/v1.58.2/packages/playwright-core/src/browserServerImpl.ts",
        "s5a6acbd08927": "https://raw.githubusercontent.com/microsoft/playwright/v1.58.2/packages/playwright-core/src/remote/playwrightServer.ts"
      }
    },
    "cdp": {
      "name": "Chrome DevTools Protocol",
      "basis": "unknown",
      "sources": {
        "s523649d3b233": "https://chromedevtools.github.io/devtools-protocol/"
      }
    },
    "chrome-change": {
      "name": "Chrome remote-debugging announcement",
      "basis": "unknown",
      "sources": {
        "s643c9edab288": "https://developer.chrome.com/blog/remote-debugging-port"
      }
    },
    "selenium": {
      "name": "Selenium Grid",
      "basis": "unknown",
      "sources": {
        "sb304923778ab": "https://www.selenium.dev/documentation/grid/configuration/cli_options/",
        "s0a0129b8dd37": "https://www.selenium.dev/documentation/grid/getting_started/"
      }
    },
    "selenium-docker": {
      "name": "Selenium Docker images",
      "basis": "aafe4d6136f3bb5afcd9b7cb691c624516d06e1b",
      "sources": {
        "s992336986b07": "https://github.com/SeleniumHQ/docker-selenium/blob/aafe4d6136f3bb5afcd9b7cb691c624516d06e1b/ENV_VARIABLES.md"
      }
    },
    "browserless": {
      "name": "browserless",
      "basis": "unknown",
      "sources": {
        "sc0a7a8f6c093": "https://docs.browserless.io/enterprise/docker/config"
      }
    },
    "browserless-docs": {
      "name": "browserless documentation (rolling)",
      "basis": "unknown",
      "sources": {
        "sa189d41ee219": "https://docs.browserless.io/enterprise/open-source",
        "sf1ec52c41f54": "https://docs.browserless.io/enterprise/utility-functions/pressure"
      }
    },
    "playwright": {
      "name": "Playwright",
      "basis": "unknown",
      "sources": {
        "sc13c2e85f08c": "https://playwright.dev/docs/api/class-browsertype",
        "s94dfef953286": "https://playwright.dev/docs/docker"
      }
    },
    "curl-docs": {
      "name": "curl documentation",
      "basis": "curl-8_14_1",
      "sources": {
        "s5e1383feef7d": "https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/write-out.md#L75-L79",
        "s82a34ee18632": "https://raw.githubusercontent.com/curl/curl/curl-8_14_1/docs/cmdline-opts/config.md"
      }
    },
    "cve-record-source": {
      "name": "CVE-2026-92811 record snapshot",
      "basis": "b0b0976792a7c9d6d66ee553050c21cb088a0659",
      "sources": {
        "sba82c9b5f230": "https://raw.githubusercontent.com/CVEProject/cvelistV5/b0b0976792a7c9d6d66ee553050c21cb088a0659/cves/2026/92xxx/CVE-2026-92811.json"
      }
    }
  },
  "claims": {
    "cdp-bind": {"text": "Command-line DevTools binds 127.0.0.1, falling back to ::1; stock browser and headless shell have no remote-debugging-address switch.", "components": ["chromium"], "sources": ["chromium:s087ba883abe3", "chromium:s6e1b34a120d1", "chromium:s005d90d4912a"], "status": "REASONED"},
    "cdp-port": {"text": "Explicit nonzero DevTools ports do not fall back to another port; port 0 requests an ephemeral port.", "components": ["chromium"], "sources": ["chromium:s087ba883abe3", "chromium:s6e1b34a120d1"], "status": "REASONED"},
    "cdp-approval": {"text": "Feature-gated approval mode uses DevToolsActivePort or 9222, with requested/ephemeral IPv4 then IPv6 fallback; command-line modes take precedence.", "components": ["chromium"], "sources": ["chromium:s087ba883abe3", "chromium:s65073710f8bd", "chromium:sc62d44c2dee6", "chromium:s0a2a5fec4975"], "status": "REASONED"},
    "cdp-discovery": {"text": "Command-line /json and /json/version disclose debugger URLs; approval-mode 404 does not establish isolation.", "components": ["chromium"], "sources": ["chromium:s66b210123ff8", "chromium:s1ca85f782546"], "status": "REASONED", "verify": [2]},
    "cdp-auth": {"text": "Command-line CDP has no client authentication or password flag; Host and Origin checks do not authenticate clients.", "components": ["chromium"], "sources": ["chromium:s66b210123ff8", "chromium:s1044899c624a"], "status": "REASONED"},
    "cdp-capabilities": {"text": "CDP grants page JavaScript, cookie/credential and tab control; restrict ingress, browser egress and local-file reach.", "components": ["cdp"], "sources": ["cdp:s523649d3b233"], "status": "REASONED"},
    "cdp-private": {"text": "Keep DevTools loopback/private behind authenticated access; inspect forwarders and container namespaces, since publishing cannot reach container loopback.", "components": ["chromium"], "sources": ["chromium:s087ba883abe3", "chromium:s6e1b34a120d1", "chromium:s804c1266fb81"], "status": "REASONED"},
    "cdp-profile": {"text": "Chrome 136 requires non-default user data; pinned desktop branding check excludes normal Chromium, and Chrome for Testing exemption rests on the announcement.", "components": ["chrome-change", "chromium"], "sources": ["chrome-change:s643c9edab288", "chromium:s65073710f8bd"], "status": "REASONED"},
    "cdp-policy": {"text": "RemoteDebuggingAllowed gates browser command-line and approval modes; headless-shell startup lacks the corresponding profile/policy check.", "components": ["chromium"], "sources": ["chromium:s65073710f8bd", "chromium:sc62d44c2dee6", "chromium:s6e1b34a120d1"], "status": "REASONED"},
    "cdp-pipe": {"text": "Pipe mode alone opens no TCP port; supplying a port too can start an independent listener, and pipe access still grants browser control.", "components": ["chromium"], "sources": ["chromium:sc62d44c2dee6", "chromium:s6e1b34a120d1", "chromium:sdf5f61d9b325"], "status": "REASONED"},
    "grid-auth": {"text": "Router username/password are unset by default, including Docker SE_ROUTER_USERNAME and SE_ROUTER_PASSWORD.", "components": ["selenium", "selenium-docker"], "sources": ["selenium:sb304923778ab", "selenium-docker:s992336986b07"], "status": "REASONED"},
    "grid-bind": {"text": "Grid host is usually autodetected; Docker SE_BIND_HOST is unset and historical Grid 3 binds 0.0.0.0. Set and observe a private host with bind-host.", "components": ["selenium", "selenium-docker"], "sources": ["selenium:sb304923778ab", "selenium-docker:s992336986b07"], "status": "REASONED"},
    "grid-ports": {"text": "Router, Hub, Standalone and UI use 4444; Nodes use 5555. Keep all private.", "components": ["selenium"], "sources": ["selenium:s0a0129b8dd37"], "status": "REASONED"},
    "grid-distributed": {"text": "Distributed event bus uses 4442/4443; Distributor, Session Map, bus HTTP and New Session Queue add 5553/5556/5557/5559.", "components": ["selenium"], "sources": ["selenium:sb304923778ab", "selenium:s0a0129b8dd37"], "status": "REASONED"},
    "grid-bus": {"text": "Router Basic auth does not protect the bus; registration-secret validates event messages without encrypting transport, so isolate every participant.", "components": ["selenium"], "sources": ["selenium:sb304923778ab", "selenium:s0a0129b8dd37"], "status": "REASONED"},
    "grid-vnc": {"text": "Docker enables VNC by default on 5900 and noVNC on 7900; replace the example secret password or disable VNC, and avoid passwordless mode.", "components": ["selenium-docker"], "sources": ["selenium-docker:s992336986b07"], "status": "REASONED"},
    "grid-tls": {"text": "Native https-certificate/https-private-key or a TLS proxy protects Router Basic credentials; TLS is not on by default.", "components": ["selenium"], "sources": ["selenium:sb304923778ab"], "status": "REASONED"},
    "browserless-auth": {"text": "Open-source 2.56.7 reads an unset or empty TOKEN as null; no token is generated and endpoints are unauthenticated by default.", "components": ["browserless-token-default", "browserless-docs"], "sources": ["browserless-token-default:s87c144d59098", "browserless-docs:sa189d41ee219"], "status": "REASONED"},
    "browserless-bind": {"text": "browserless uses 3000; publish 127.0.0.1:3000:3000 or keep an internal network with no host mapping.", "components": ["browserless"], "sources": ["browserless:sc0a7a8f6c093"], "status": "REASONED"},
    "browserless-token": {"text": "Use a randomized TOKEN, protect token-bearing connection URLs and logs, and terminate TLS at the fronting layer.", "components": ["browserless"], "sources": ["browserless:sc0a7a8f6c093"], "status": "REASONED"},
    "browserless-file": {"text": "Require browserless 2.51.0 or later containing the pinned Playwright fix, keep ALLOW_FILE_PROTOCOL=false, and run the file-protocol check.", "components": ["browserless", "browserless-file-fix"], "sources": ["browserless:sc0a7a8f6c093", "browserless-file-fix:s94f1d485c2b7", "browserless-file-fix:s90a20f6566c9", "browserless-file-fix:sa985cbba01ad"], "status": "REASONED"},
    "playwright-auth": {"text": "Playwright server has no password/user model; reachable endpoints grant OS-user control, so bind 127.0.0.1 and protect endpoint URLs.", "components": ["playwright"], "sources": ["playwright:sc13c2e85f08c", "playwright:s94dfef953286"], "status": "REASONED"},
    "playwright-discovery": {"text": "Guide records run-server path / and launchServer random paths discoverable through GET /json; a secret path is not an access boundary.", "components": ["playwright", "playwright-source"], "sources": ["playwright:sc13c2e85f08c", "playwright:s94dfef953286", "playwright-source:scb030dc29caf", "playwright-source:sbbcd84289455", "playwright-source:s5a6acbd08927"], "status": "REASONED"},
    "playwright-tls": {"text": "Authenticate WebSocket upgrades and discovery at a wss proxy; connect accepts custom headers and the server supplies no native TLS.", "components": ["playwright"], "sources": ["playwright:sc13c2e85f08c", "playwright:s94dfef953286"], "status": "REASONED"},
    "debug-bypass": {"text": "A separately forwarded Chromium debug endpoint bypasses front-tool authentication; keep 9222 unpublished and restrict browser egress.", "components": ["cdp", "selenium", "browserless", "playwright"], "sources": ["cdp:s523649d3b233", "selenium:s0a0129b8dd37", "browserless:sc0a7a8f6c093", "playwright:sc13c2e85f08c"], "status": "REASONED"},
    "verify-listeners": {"text": "Inventory every listener, including distributed Grid and configured Playwright ports, and require intended loopback/private addresses.", "components": ["chromium", "selenium", "selenium-docker", "browserless", "playwright"], "sources": ["chromium:s087ba883abe3", "chromium:s6e1b34a120d1", "selenium:sb304923778ab", "selenium:s0a0129b8dd37", "selenium-docker:s992336986b07", "browserless:sc0a7a8f6c093", "playwright:sc13c2e85f08c"], "status": "REASONED", "verify": [1]},
    "verify-cdp": {"text": "External command-line CDP returns 200 with webSocketDebuggerUrl when forwarded; fixed isolation retains a working local control. Approval-mode 404 is inconclusive.", "components": ["chromium", "curl-docs"], "sources": ["chromium:s804c1266fb81", "chromium:s66b210123ff8", "curl-docs:s5e1383feef7d"], "status": "REASONED", "verify": [2]},
    "verify-grid": {"text": "Grid /status returns ready/node JSON when exposed; Router 401 with Basic challenge shows auth but still proves reachability. Probe Nodes separately.", "components": ["selenium", "curl-docs"], "sources": ["selenium:sb304923778ab", "selenium:s0a0129b8dd37", "curl-docs:s5e1383feef7d"], "status": "REASONED", "verify": [2]},
    "verify-browserless": {"text": "For open-source 2.56.7, expect /pressure load JSON without a configured TOKEN; with a nonempty TOKEN, expect 401 for missing/wrong tokens and JSON for a correct-token control.", "components": ["browserless-token-default", "browserless-docs", "curl-docs"], "sources": ["browserless-token-default:s87c144d59098", "browserless-token-default:sdf3b808e8920", "browserless-token-default:se8b696d56eda", "browserless-token-default:sc7973e3e21df", "browserless-docs:sa189d41ee219", "browserless-docs:sf1ec52c41f54", "curl-docs:s5e1383feef7d", "curl-docs:s82a34ee18632"], "status": "REASONED", "verify": [2]},
    "verify-playwright": {"text": "Any HTTP answer proves Playwright reachability; launchServer uses an ephemeral port unless set, while run-server takes --port.", "components": ["playwright", "playwright-source"], "sources": ["playwright:sc13c2e85f08c", "playwright:s94dfef953286", "playwright-source:scb030dc29caf", "playwright-source:sbbcd84289455", "playwright-source:s5a6acbd08927"], "status": "REASONED", "verify": [2]},
    "browserless-file-cve": {"text": "CVE-2026-92811 describes authenticated Playwright file reads despite ALLOW_FILE_PROTOCOL=false; its affected range 1.44.0 through 2.56.7 conflicts with the vendor 2.51.0 fix.", "components": ["browserless-file-fix", "cve-record-source"], "sources": ["cve-record-source:sba82c9b5f230", "browserless-file-fix:s94f1d485c2b7", "browserless-file-fix:s90a20f6566c9"], "status": "REASONED"},
    "verify-browserless-file": {"text": "With a valid token on every enabled Playwright WebSocket route, confirm HTTP navigation first, then attempt a readable container canary: exposed returns contents; fixed refuses with a blocked-URL policy reason.", "components": ["browserless-file-fix", "cve-record-source"], "sources": ["cve-record-source:sba82c9b5f230", "browserless-file-fix:sf2642da1de49", "browserless-file-fix:s7ee912fa0a9a", "browserless-file-fix:sa985cbba01ad"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
