# Self-hosted chat and agent UIs: AnythingLLM, LobeChat, Chainlit, OpenHands

AnythingLLM, LobeChat, Chainlit and OpenHands are self-hosted web apps for AI chat and agents. This guide helps your AI assistant configure them securely, including loopback-only ports, LobeChat's registration allowlist, a Chainlit auth callback, and OpenHands reached only through an authenticated tunnel.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/chat-uis.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against AnythingLLM documentation (no recorded version), LobeHub v2.2.16, Docker CLI v27.5.1, Docker Compose v2.32.4, compose-go v2.4.7, Moby v27.5.1, and curl minimum write-out version 7.75.0; 6 further sources carry no recorded version. Metadata reviewed 2026-09-26; documentation checked September 2026. The guide records 30 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

These tools hold provider API keys and full conversation history, and several are wide open the moment they start. Bind every one to loopback, front it with TLS and a login ([caddy.md](caddy.md)/[nginx.md](nginx.md), [free-certificates.md](free-certificates.md)), and turn on the tool's own authentication as a second layer, never as a substitute for the network boundary. See also [open-webui.md](open-webui.md) for the Open WebUI case, [secrets.md](secrets.md) for the provider keys these apps store, and [fronting-auth.md](fronting-auth.md)/[mfa.md](mfa.md) for the identity layer in front.

## AnythingLLM

Security features apply to the Docker deployment. Single-user mode offers an optional "Password Protect Instance" toggle: once set, anyone with that one password can use the instance, change any setting, and read every chat, so treat it as a screen door, not a real access-control boundary. Multi-user mode is the documented preferred setup: it adds Admin (full access including logs and analytics), Manager (all workspaces, no LLM/embedder/vector-database settings), and Default (only explicitly assigned workspaces) roles, each requiring its own login. Multi-user mode cannot be reverted to single-user once enabled, so decide before turning it on.

```bash
docker run -d -p 127.0.0.1:3001:3001 mintplexlabs/anythingllm
```

Keep it on loopback regardless of which mode you choose, and put the proxy's own TLS and login in front.

## LobeChat

`KEY_VAULTS_SECRET` is the key that encrypts stored provider credentials (AES-GCM); generate it with `openssl rand -base64 32`, and once set, never change it, or previously encrypted data becomes unreadable. LobeHub's own basic-variables page describes it loosely as "a password to access the LobeHub service", but its own warning on the same entry says the key is used to encrypt sensitive data: treat it as the encryption key, not the deployment's login gate. Real per-user login comes from LobeChat's Better Auth service: `AUTH_SECRET` (required, generated the same way) signs sessions, and `AUTH_SSO_PROVIDERS` lists enabled SSO providers (for example `google,github,microsoft`) alongside the matching provider credentials each one needs (for example `AUTH_GOOGLE_ID`/`AUTH_GOOGLE_SECRET`). LobeChat's Better Auth service also takes `AUTH_DISABLE_EMAIL_PASSWORD=1`, which forces SSO-only login, hiding the password form entirely. `AUTH_ALLOWED_EMAILS` restricts registration to specific addresses or domains, but it defaults to empty, which allows every email through, so set it explicitly rather than relying on federation alone to gate access.

Keep the three secrets, `KEY_VAULTS_SECRET`, `AUTH_SECRET` and the Google OAuth client secret, off the `docker run` command line: a value given as `-e NAME=value` is in the docker CLI's argv, where `ps` and `/proc/<pid>/cmdline` show it to other local accounts while that command runs, and quoting does not change that. At docker/cli v27.5.1, `--env-file` reads environment variables from a file, through a loader that opens the named path and has no `-` stdin form, and `-e NAME` with no value takes the value from the CLI's own environment. Docker Compose's `env_file` reads a file of variables for a service through its own loader in compose-go (v2.4.7, the version Docker Compose v2.32.4 pins). A Compose `secrets` entry puts a value in a file under `/run/secrets/` instead: a file-sourced secret is bind-mounted read-only, and an environment-sourced one is copied into the container, mode `0444` by default, rather than mounted. That only helps if something reads the file into these variables, and LobeHub documents them as environment variables only; a search of its v2.2.16 tree finds no `KEY_VAULTS_SECRET_FILE`, `AUTH_SECRET_FILE` or `AUTH_GOOGLE_SECRET_FILE`. Use the `--env-file` file: `KEY_VAULTS_SECRET` must stay the same for the life of the data it encrypts, so it needs a durable home anyway, and a file keeps the values out of the CLI's own environment too. Create it once, as the account that runs `docker`. The block prompts for the Google client secret without echo, under CONTRIBUTING rule 7's `read` exception, and assumes a clean shell:

```bash
(
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  set +x +a +e
  set -eC
  umask 077
  if [ -e "$HOME/.config/lobechat/secrets.env" ] || [ -L "$HOME/.config/lobechat/secrets.env" ]; then
    echo 'a secrets.env already exists in ~/.config/lobechat; nothing written'; exit 2
  fi
  { unset -n gsec && unset -v gsec; } 2>/dev/null ||
    { echo 'cannot clear gsec in this shell; nothing written'; exit 2; }
  { unset -n IFS; } 2>/dev/null || { echo 'a readonly IFS is set in this shell; nothing written'; exit 2; }
  command -v openssl >/dev/null || { echo 'openssl not found, so the keys cannot be generated; nothing written'; exit 2; }
  command -v ls >/dev/null || { echo 'ls not found, so the mode of secrets.env cannot be checked after the write; nothing written'; exit 2; }
  printf 'Google OAuth client secret (input hidden): '
  IFS= read -r -s gsec || { printf '\n'; echo 'no client secret read; nothing written'; exit 3; }
  printf '\n'
  case "$gsec" in
    ""|*REPLACE_WITH_*|*[[:cntrl:]]*) echo 'empty client secret, placeholder or control character; nothing written'; exit 2 ;;
  esac
  set -- "$(openssl rand -base64 32)" "$(openssl rand -base64 32)"
  [ "${#1}" -eq 44 ] || { echo 'key generation failed; nothing written'; exit 3; }
  [ "${#2}" -eq 44 ] || { echo 'key generation failed; nothing written'; exit 3; }
  case "$1$2" in *[!ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=]*) echo 'key generation failed; nothing written'; exit 3 ;; esac
  mkdir -p -- "$HOME/.config/lobechat"
  chmod 700 -- "$HOME/.config/lobechat"
  command -v getfacl >/dev/null || { echo 'getfacl not found, so a default ACL on ~/.config/lobechat cannot be ruled out; install the acl package; nothing written'; exit 2; }
  case "$(getfacl -d -c -p -- "$HOME/.config/lobechat"; echo "getfacl-status=$?")" in
    getfacl-status=0) ;;
    *getfacl-status=0) echo 'the directory ~/.config/lobechat has a default ACL, which a new file inherits in place of umask 077; nothing written'; exit 2 ;;
    *) echo 'getfacl could not read the ACL of ~/.config/lobechat; nothing written'; exit 3 ;;
  esac
  printf 'KEY_VAULTS_SECRET=%s\nAUTH_SECRET=%s\nAUTH_GOOGLE_SECRET=%s\n' "$1" "$2" "$gsec" > "$HOME/.config/lobechat/secrets.env"
  case "$(ls -ln -- "$HOME/.config/lobechat/secrets.env")" in
    '-rw------- '*|'-rw-------.'*) ;;
    *) echo 'secrets.env is not mode 0600, so other accounts may read it; delete ~/.config/lobechat/secrets.env, do not use the values in it, and rotate the Google client secret'; exit 3 ;;
  esac
)
```

REASONED: exit status meanings, per CONTRIBUTING.md rule 6. A block that sets its exit status uses 0 for a pass, or for an observation the block cannot classify and says so; 1 for a finding; 2 for a guard refusal; and 3 for a failed or inconclusive check. The block above sets its own status with 2 when a guard refuses, as when `openssl`, `getfacl` or `ls` is not found, and with 3 when the hidden prompt fails to read, key generation or `getfacl` fails, or the written file is not mode `0600`. Under its `set -e`, a command it does not check, such as `mkdir`, `chmod` or the write itself, ends it with that command's own status if it fails; otherwise it ends with the status of its last command, the `case` that checks the file's mode.

The block refuses to run when `~/.config/lobechat/secrets.env` already exists in any form, a dangling symlink included, before it prompts or generates anything, so a rerun cannot replace a `KEY_VAULTS_SECRET` that already encrypts data. `set -C` adds overwrite protection for an existing regular file only, not for every kind of target, and the existence check runs before the write rather than atomically with it, so both hold only in directories that no other account can write to or replace: `$HOME`, `~/.config` and the owner-only directory the block creates. For a deployment that already has these values, put its existing values in such a file instead of generating new ones. `umask 077` creates the directory mode `0700` and the file mode `0600`, unless the directory, or the parent it is created in, carries a default ACL: new files inherit that ACL in place of the umask, and `chmod 700` on the directory does not remove it. So once it has created the directory, which is after the prompt, the block runs `getfacl -d -c -p` on it, which prints the directory's default ACL and nothing else, and writes nothing when that prints anything, when `getfacl` fails, or when `getfacl` is not installed, leaving the directory behind; remove a default ACL you do not need with `setfacl -k ~/.config/lobechat` and run the block again. A missing `getfacl` fails closed because the block then cannot tell, before the write, whether the file would be private; `getfacl` comes from the `acl` package, and where it is not installed the block refuses to run. After the write the block reads the file's permission field from `ls -ln` and fails unless it is exactly `-rw-------` followed by a space or a `.`; any other field fails the check, including the `+`-marked field a named ACL entry produced in the recorded runs. If the check fails, delete the file, do not use the values in it, and rotate the Google client secret. Without these checks, the block wrote `secrets.env` mode `0644` when `~/.config` carried a default ACL (run in a scratch home directory with bash 5.3.9, acl 2.3.2 and `openssl` stubbed). That run covered an earlier form of the block, and the current form was not re-run. The block writes nothing unless both generated values are 44 base64 characters and the prompted secret is non-empty, is not the placeholder and holds no control character. `read` stops at the first newline, so a newline cannot enter the value; the check refuses a carriage return or any other control character. Paste the secret alone at the hidden prompt: a multi-line paste leaves every line after the first for your shell to run. The generated values pass only through the subshell's positional parameters and the builtin `printf`, and the client secret through one variable local to the subshell, never a command line; the block clears inherited traps first because a DEBUG, RETURN or ERR trap from your shell could otherwise read them. A write failure can leave a partial file. The launch block below refuses the shapes it can detect, a generated value that is not 44 base64 characters, a missing or duplicated line, or any other line, but a client secret cut short still looks like a valid value and cannot be detected, so delete a file left by a failed run and create it again rather than starting on it. The file holds the secrets in plaintext at rest, readable by that account, by root and by any backup that copies it, so keep it and its backups out of source control ([secrets.md](secrets.md)). Start LobeChat from the file, with only non-secret values on its command line. Substitute your Google OAuth client ID and the addresses or domains allowed to register inside the single quotes on the `set --` line:

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_GOOGLE_OAUTH_CLIENT_ID' 'admin@example.com,example.com'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo 'paste the whole block, including its set -- line; not starting'; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo 'the set -- line needs exactly 2 values; not starting'; exit 2; }
  case "$1|$2" in *REPLACE_WITH_*) echo 'substitute the client ID inside the quotes on the set -- line; not starting'; exit 2 ;; esac
  { [ -n "$1" ] && [ -n "$2" ]; } || { echo 'empty value on the set -- line; not starting'; exit 2; }
  case "$1$2" in *[[:space:][:cntrl:]]*) echo 'whitespace or a control character on the set -- line; not starting'; exit 2 ;; esac
  command -v grep >/dev/null || { echo 'grep not found, so ~/.config/lobechat/secrets.env cannot be checked; not starting'; exit 2; }
  f="$HOME/.config/lobechat/secrets.env"
  { [ -f "$f" ] && [ ! -L "$f" ]; } ||
    { echo 'need ~/.config/lobechat/secrets.env to be a regular file (it is missing, a symlink or another kind of file); not starting'; exit 2; }
  if grep -Eavqx -- 'KEY_VAULTS_SECRET=[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/]{43}=|AUTH_SECRET=[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/]{43}=|AUTH_GOOGLE_SECRET=[^[:cntrl:]]+' "$f"; then
    echo 'a line in ~/.config/lobechat/secrets.env is not one of the three secret lines; not starting'; exit 2
  else
    rc=$?; [ "$rc" -eq 1 ] || { echo 'could not check ~/.config/lobechat/secrets.env; not starting'; exit 3; }
  fi
  if grep -aq -- 'REPLACE_WITH_' "$f"; then
    echo 'a placeholder is still in ~/.config/lobechat/secrets.env; not starting'; exit 2
  else
    rc=$?; [ "$rc" -eq 1 ] || { echo 'could not check ~/.config/lobechat/secrets.env; not starting'; exit 3; }
  fi
  c=$(grep -Eacx -- 'KEY_VAULTS_SECRET=[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/]{43}=' "$f") ||
    { rc=$?; [ "$rc" -eq 1 ] || { echo 'could not check the KEY_VAULTS_SECRET lines in ~/.config/lobechat/secrets.env; not starting'; exit 3; }; }
  [ "$c" = 1 ] ||
    { echo 'need exactly one generated KEY_VAULTS_SECRET line in ~/.config/lobechat/secrets.env; not starting'; exit 2; }
  c=$(grep -Eacx -- 'AUTH_SECRET=[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/]{43}=' "$f") ||
    { rc=$?; [ "$rc" -eq 1 ] || { echo 'could not check the AUTH_SECRET lines in ~/.config/lobechat/secrets.env; not starting'; exit 3; }; }
  [ "$c" = 1 ] ||
    { echo 'need exactly one generated AUTH_SECRET line in ~/.config/lobechat/secrets.env; not starting'; exit 2; }
  c=$(grep -Eacx -- 'AUTH_GOOGLE_SECRET=[^[:cntrl:]]+' "$f") ||
    { rc=$?; [ "$rc" -eq 1 ] || { echo 'could not check the AUTH_GOOGLE_SECRET lines in ~/.config/lobechat/secrets.env; not starting'; exit 3; }; }
  [ "$c" = 1 ] ||
    { echo 'need exactly one AUTH_GOOGLE_SECRET line in ~/.config/lobechat/secrets.env; not starting'; exit 2; }
  docker run -d -p 127.0.0.1:3210:3210 \
    --env-file "$HOME/.config/lobechat/secrets.env" \
    -e AUTH_DISABLE_EMAIL_PASSWORD=1 \
    -e AUTH_SSO_PROVIDERS=google \
    -e "AUTH_GOOGLE_ID=$1" \
    -e "AUTH_ALLOWED_EMAILS=$2" \
    lobehub/lobe-chat
)
```

REASONED: exit status meanings, per CONTRIBUTING.md rule 6. A block that sets its exit status uses 0 for a pass, or for an observation the block cannot classify and says so; 1 for a finding; 2 for a guard refusal; and 3 for a failed or inconclusive check. The block above sets its own status with 2 when a guard refuses, as when `grep` is not found or the file does not hold exactly the three secret lines, and with 3 when `grep` cannot check the file; otherwise it ends with the status of its last command, `docker run`.

The block refuses the placeholder, an empty value, and whitespace or a control character on the `set --` line. It checks first that `~/.config/lobechat/secrets.env` is a regular file and not a symlink, so a FIFO in its place can neither block the check nor be read by it. It then reads the file as text (`grep -a`: without `-a`, a NUL could make a malformed line look valid to grep) and refuses to start unless the file holds exactly one line for each generated value and exactly one client secret line, no other line and no placeholder. The block makes that check because at v27.5.1 an env-file line holding only a name takes its value from the CLI's own environment, which would bring back the channel the file replaces. It uses the count that `grep -c` prints even when `grep` finds no matching line, so a file missing a line gives a count of 0 and is refused with 2, as is one with a duplicated line; when `grep` fails, as when it cannot read the file, the block says that it could not check and stops with status 3. It gives the same result in a shell that has `set -e` on. The patterns for the two generated values spell out their ASCII character sets rather than ranges such as `A-Z`, whose meaning can depend on the locale. The client secret pattern, `[^[:cntrl:]]+`, is the exception and depends on the locale: it refuses only control characters, and the locale decides which characters are control characters, as it does for the other `[:cntrl:]` checks, in the block that creates the file and on the `set --` line. A key of another shape from an existing deployment needs the matching pattern relaxed. This moves the secrets out of argv, not out of reach. Docker hands them to the container as environment variables, so anyone who can use the Docker socket can read them back with `docker inspect`, which returns the container's configuration with its `Env` list, for as long as the container exists, running or stopped; and the same user as the container's process, or root, can read them from that process's `/proc/<pid>/environ` for its whole lifetime. Socket access is root-equivalent already ([container-hardening.md](container-hardening.md)); grant it to nobody you would not trust with these keys. `-e NAME` with no value would keep them out of argv as well, but only under rule 7's guarded one-command prefix assignment, never an `export`, and the values would then sit in the CLI's own environment too. Neither form erases a value already recorded in shell history, tracing or a log.

MFA: enforce it at whichever SSO provider you list in `AUTH_SSO_PROVIDERS`; LobeChat's own login has no second factor of its own.

## Chainlit

Chainlit applications are public by default: no login, no gate, anyone who reaches the port gets the chat. Set `CHAINLIT_AUTH_SECRET` (generate one with `chainlit create-secret`; changing it logs out every user) and implement at least one auth callback: password authentication, OAuth, or header-based authentication. A callback that returns `None` refuses the login. There is no built-in MFA; put it behind an identity provider that enforces a second factor, or an [Authelia](https://www.authelia.com/)-fronted proxy.

```python
import hmac
import os
from typing import Optional

import chainlit as cl

# Read the credential from the environment, never from source. Chainlit's own example
# compares a literal "admin" against a literal "admin", which is a demonstration rather
# than a deployment. These two names are this application's own, not Chainlit's.
# Indexing os.environ raises KeyError if either is unset, which stops the process before
# the callback is ever registered; the explicit test is for a variable that is SET and
# empty, which indexing accepts and which would otherwise be a usable password.
EXPECTED_USER = os.environ["CHAINLIT_USER"].encode()
EXPECTED_PASSWORD = os.environ["CHAINLIT_PASSWORD"].encode()
if not EXPECTED_USER or not EXPECTED_PASSWORD:
    raise SystemExit("CHAINLIT_USER and CHAINLIT_PASSWORD must both be set and non-empty")


@cl.password_auth_callback
def auth_callback(username: str, password: str) -> Optional[cl.User]:
    # compare_digest avoids content-based short-circuiting, so it does not leak how much of
    # the password was right; Python notes it can still reveal "the types and lengths of a
    # and b, but not their values". Both comparisons run before the `and` so that a short
    # circuit there cannot reveal which half failed. The callback as a whole is not constant
    # time and does not need to be; the point is that the secret is not compared with ==.
    ok_user = hmac.compare_digest(username.encode(), EXPECTED_USER)
    ok_password = hmac.compare_digest(password.encode(), EXPECTED_PASSWORD)
    if ok_user and ok_password:
        return cl.User(identifier=username)
    return None
```

That is one shared credential, which is a gate on the deployment rather than user accounts: everyone who gets in is the same `identifier`, and there is nobody to revoke individually.

Rotating it is two steps, not one. Changing the environment variable does nothing until the process restarts, because the value above is read once at import. And a new password stops future logins without ending current ones: Chainlit issues a session token signed with `CHAINLIT_AUTH_SECRET`, and that secret, not this password, is what invalidates the sessions already handed out. Change both when you mean to lock everyone out.

For real accounts, this callback is one of the options rather than the only one. Chainlit also supports OAuth and header-based authentication, which move the decision to an identity provider and are usually the better answer ([identity-providers.md](identity-providers.md), [oidc-integration.md](oidc-integration.md)). If you do manage passwords yourself, Chainlit persists user records but provides no password-account management, so the store and the verification are yours: keep a per-user hash from a slow algorithm, Argon2id for anything new, and call it inside this callback in place of the comparison above. The vendor's own advice is the short version of this, "hash password before storing them". A shared service credential still belongs in the environment ([secrets.md](secrets.md)); a per-user password hash belongs in the account store.

## OpenHands

OpenHands is built for a single user on their own workstation: the project's own FAQ states there is no built-in authentication, isolation, or scalability for shared use, and the open-source build authorizes API access with one shared key rather than per-user identity. It also executes agent-generated code against your workspace, with the isolation depending entirely on your deployment choice (a local process backend runs with your user's permissions; container backends can be weakened by broad mounts, privileged mode, or Docker-socket access). Do not expose it to anyone you would not hand a shell to. The project documents a Hardened Docker Installation guide for deployments that must sit on a shared network; multi-tenant use is an enterprise offering, not something the open-source build supports.

The documented quickstart itself runs `docker run ... -p 3000:3000 ... openhands/openhands`, which maps every interface, not loopback; change that to `-p 127.0.0.1:3000:3000` before anything else. Reach it only through an authenticated tunnel; there is no login screen to add in front of it, so identity has to come entirely from the proxy or tunnel layer.

## Verify

REASONED: the cited UI binding references support this host-side inventory, which is prose rather than part of the block below, because it runs on the UI's host and the block runs from another host. On the UI's host, run `ss -tlnp` and read every listener: 3001/3210/3000, each UI on 127.0.0.1 only. The authoring host lacks an isolated network namespace for authorized live listeners, so no listing is recorded.

REASONED: following block; isolation comparison, listener and external-reachability checks, API authentication, proxy TLS/login, LobeChat registration and multi-user isolation follow the cited UI binding/authentication references, LobeChat AUTH_ALLOWED_EMAILS source, AnythingLLM workspace roles and linked pgvector guidance. No live UI/RAG deployment, external test path or paired identities are available, and the authoring host lacks an isolated network namespace for authorized live listeners. The anonymous API probe's flags were run locally with curl 8.18.0 against loopback stub listeners, not a UI, and a closed loopback port: the old `-s` form printed only the response body for a 401 and for a 200, and nothing for the closed port (exit 7), while the `-sS -o /dev/null -w '%{http_code}\n'` form printed `401`, `200`, and `000` with curl's connection error. That `000` is the value those runs observed, not a cited one: the installed curl 8.18.0 manual describes `http_code` only as "The numerical response code that was found in the last retrieved HTTP(S) or FTP(s) transfer." The proxy probe uses `-sSI` rather than `-sI` because the manual says `-s` shows no error messages and `-S` with it shows an error message if curl fails, so a TLS, DNS or connection failure prints curl's error instead of nothing. Run locally with curl 8.18.0 against a closed loopback port, the `-sI` form exited 7 and printed nothing, and the `-sSI` form exited 7 and printed curl's connection error. Those curl 8.18.0 runs covered the earlier form of the two probes, before the probes took the chat host on a guarded `set --` line and gained `-g`; that guarded form, which refuses example.com, example.net, example.org and their subdomains, was not run. The current form leaves the listener inventory to the section's first paragraph and gives the whole block one exit status: 1 if port 3210 answers with an HTTP code, 3 if a request fails or port 3210 gives neither an HTTP code nor a refusal or timeout, 2 if a guard refuses and nothing was found or failed, and otherwise 0. A refusal or timeout on port 3210, an API answer other than 401, the proxy's headers and the LobeChat registration check are left for you to judge, and the block's last line names them. Those 2026-10-31 checks, with bash -n and with curl stubs and no network, covered the earlier form of the block, in which the second part lowercased the host with `tr` before refusing a reserved name; they covered each status, an earlier finding or failure followed by passing later checks, and an inherited `readonly`, `declare -i` or `set -e`. The stub runs covered the refusals of a missing marker, too few or too many values, and an empty or placeholder value in each part, and in the second part of a host name with a scheme, port, trailing dot, `@`, `?`, `%`, `#` or space and of an example.com, example.net or example.org host including `App.Example.COM`; each refused part made no curl call. ShellCheck 0.11.0 passed on that form in the repository's gate suite. The current form refuses a reserved name under bash's `nocasematch` option instead of through `tr`, and its second part refuses with 2, saying the block needs bash, when `shopt` fails, as it does in dash. It is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by curl-stub runs on 2026-11-01 with no network. In bash, that part refused `example.com`, `EXAMPLE.NET`, `App.Example.COM`, `api.EXAMPLE.org` and seven other reserved spellings with 2 and no curl call, also with `tr` absent from PATH or failing and under an inherited `nocasematch`, `readonly`, `declare -i` or `set -e`, and a host name outside the reserved names reached its probe. Under dash, that part refused every host name with 2 and the bash message before its probe, and the whole block exited 3, because dash reads the first part's `$'\n'` differently and that part reported an inconclusive result. For a multi-user chat or RAG deployment (AnythingLLM workspaces, or a shared assistant over shared documents), verify isolation at the data layer, not only at login. First, as user A, ask a question whose answer lives only in user A's documents or past conversations and confirm A's own document supplies the answer, the positive control that retrieval works at all; then ask the same question as user B and confirm B gets nothing of A's. A retrieval step that searches every user's embeddings without enforcing per-document access hands one user's content into another's session even though each logged in separately; scope retrieval to the requesting user's own documents or workspace, and where the store is pgvector the tenant row-level-security check in [vector-databases.md](vector-databases.md) is the store-side half. A retrieval filter alone does not isolate conversation history, memory, or a shared cache; check each of those the same way. This isolation check is REASONED, not demonstrated: the authoring environment has no live multi-user RAG deployment. Its expected isolation rests on the cited AnythingLLM workspace-role documentation and the pgvector row-level-security guidance linked above.

```bash
# Run this block from another host. Read err, not the number: it must name a refusal or timeout reaching YOUR
# address. An HTTP code means the port answered. A resolver failure, a local socket error, or a
# timeout that did not come from the remote address is inconclusive, never a pass.
(                                       # the whole block in one subshell, so one exit status covers every part of it
  set +e                                # errexit off here, so a part that ends nonzero is folded into the status below instead of ending the block
  set -- 0                              # the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 2 (a part refused its input), which outranks 0
  (                                                       # a subshell, so your own script arguments are untouched
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_PUBLIC_IP'   # replace inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
    case "$1" in
      *REPLACE_WITH_*|*YOUR_PUBLIC_IP*|"") echo "substitute your own address on the set -- line above; not probing"; exit 2 ;;
    esac
    set -- "$1" "$(if curl -q -g -s -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "http://$1:3210/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "${2##*$'\n'}" "${2%%$'\n'*}"             # curl's exit status, then its http= exit= err= line
    printf '%s\n' "$3"
    case "$2:$3" in
      7:*"http=000 "*|28:*"http=000 "*) echo "unclassified: read err above; a refusal or timeout reaching YOUR address is the pass, and any other cause is inconclusive"; exit 0 ;;
      *"http=000 "*|*:) echo "curl exit $2 with no HTTP code and no refusal or timeout; inconclusive"; exit 3 ;;
      *"http="*) echo "FINDING: port 3210 answered with an HTTP code, so it is reachable from this host"; exit 1 ;;
      *) echo "curl exit $2 printed no http= line; inconclusive"; exit 3 ;;
    esac
  )
  case "$?:$1" in 0:*) ;; 1:*) set -- 1 ;; 2:0) set -- 2 ;; 2:*|*:1) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  (                                       # a subshell, so your own script arguments are untouched
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_CHAT_HOST'   # the public host name your proxy serves the chat UI on, no scheme, user name, port, path, query, fragment, percent sign or trailing dot: replace inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
    case "$1" in
      ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
    case "$1" in
      example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -u nocasematch   # every match below compares letter case exactly again
    set -- "$1" 0                         # the 2nd value is this part's status so far: 3 (inconclusive) outranks 0
    set -- "$1" "$2" "$(if curl -q -g -sS -o /dev/null -w '%{http_code}\n' "https://$1/api/some-endpoint"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"        # curl's exit status, then the HTTP code
    printf '%s\n' "$4"                    # without a key/token: 401; 000 and curl's error mean no answer, never a pass
    case "$3:$4" in
      0:401) ;;
      0:*) echo "unclassified: HTTP $4 is not the 401 expected without a key or token, so read it against an actual protected route of your deployment" ;;
      *) echo "curl exit $3: the API request got no answer, never a pass; inconclusive"; set -- "$1" 3 ;;
    esac
    if curl -q -g -sSI "https://$1/"; then :; else   # via the proxy: TLS, login required
      echo "curl exit $?: the request through the proxy failed; inconclusive"; set -- "$1" 3
    fi
    exit "$2"
  )
  case "$?:$1" in 0:*) ;; 1:*) set -- 1 ;; 2:0) set -- 2 ;; 2:*|*:1) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  # LobeChat SSO: attempt to register/sign in with a Google account that has never registered and is
  #   NOT listed in AUTH_ALLOWED_EMAILS; expect rejection at registration, before any account or session
  #   is created (AUTH_ALLOWED_EMAILS gates new registration; it does not revoke an already-registered
  #   user's existing session)
  echo "block exit $1; a refusal or timeout on port 3210, an API answer other than 401, the proxy's TLS and login headers and the LobeChat registration check are not classified, so judge them yourself"
  exit "$1"
)
```

## Common mistakes

- Leaving Chainlit unauthenticated because "it's just for testing"; public by default means public the moment it is reachable.
- Treating AnythingLLM's single instance password as equivalent to per-user accounts; it grants full admin to whoever has it.
- Running OpenHands with a shared, long-lived API key exposed on the same network as untrusted users.
- Rotating LobeChat's `KEY_VAULTS_SECRET` after data has been encrypted with it, which makes that data unreadable.
- Passing `KEY_VAULTS_SECRET`, `AUTH_SECRET` or `AUTH_GOOGLE_SECRET` as `-e NAME=value`, which puts the value in the docker CLI's argv for other local accounts to read while the command runs.

## Sources (checked September 2026)

- AnythingLLM security and access documentation: https://docs.anythingllm.com/features/security-and-access
- LobeHub environment variables (KEY_VAULTS_SECRET; pinned tag v2.2.16): https://github.com/lobehub/lobehub/blob/v2.2.16/docs/self-hosting/environment-variables/basic.mdx#L22-L32
- LobeHub authentication service environment variables (Better Auth; rolling documentation, checked September 2026): https://lobehub.com/only-ai/markdown/docs/en/self-hosting/environment-variables/auth
- LobeHub `KEY_VAULTS_SECRET` callout, "This key is used to encrypt sensitive data." (pinned tag v2.2.16): https://github.com/lobehub/lobehub/blob/v2.2.16/docs/self-hosting/environment-variables/basic.mdx#L22-L32
- LobeHub `AUTH_SECRET` generated with `openssl rand -base64 32`, and `AUTH_GOOGLE_SECRET` as the "Client Secret of the Google OAuth application." (pinned tag v2.2.16): https://github.com/lobehub/lobehub/blob/v2.2.16/docs/self-hosting/environment-variables/auth.mdx
- Docker `container run` reference, `--env-file` ("Read in a file of environment variables"; pinned tag v27.5.1): https://github.com/docker/cli/blob/v27.5.1/docs/reference/commandline/container_run.md
- Docker `container run` reference, `--env VAR` with no value, which "checks the value the variable has in your local environment and passes it to the container" (pinned tag v27.5.1): https://github.com/docker/cli/blob/v27.5.1/docs/reference/commandline/container_run.md#L626-L640 and the `-e` validator's `os.LookupEnv`: https://github.com/docker/cli/blob/v27.5.1/opts/env.go#L18-L31
- Docker CLI env-file loading through `kvfile.Parse`, with `-e` parsed after the file "to allow override" (pinned tag v27.5.1): https://github.com/docker/cli/blob/v27.5.1/opts/parse.go#L19-L39
- Docker CLI key/value file parser, which opens the named path (`os.Open(filename)`) with no `-` stdin form, and looks up a line that holds only a name in the CLI's environment (pinned tag v27.5.1): https://github.com/docker/cli/blob/v27.5.1/pkg/kvfile/kvfile.go#L54-L69 and https://github.com/docker/cli/blob/v27.5.1/pkg/kvfile/kvfile.go#L121-L126
- Docker Compose pins compose-go v2.4.7 (pinned tag v2.32.4): https://github.com/docker/compose/blob/v2.32.4/go.mod#L5-L18
- compose-go service `env_file` resolution ("parses env_files set for services to resolve the actual environment map for services"; pinned tag v2.4.7): https://github.com/compose-spec/compose-go/blob/v2.4.7/types/project.go#L631-L664
- Docker Compose file-sourced secrets bind-mounted read-only under `/run/secrets/`, environment-sourced ones skipped there (pinned tag v2.32.4): https://github.com/docker/compose/blob/v2.32.4/pkg/compose/create.go#L1029-L1084
- Docker Compose environment-sourced secrets copied into the container under `/run/secrets/`, mode `0444` by default (pinned tag v2.32.4): https://github.com/docker/compose/blob/v2.32.4/pkg/compose/secrets.go#L31-L61 and https://github.com/docker/compose/blob/v2.32.4/pkg/compose/secrets.go#L101
- Moby container inspect returns `Config: ctr.Config`, whose `Env []string` holds the environment (pinned tag v27.5.1): https://github.com/moby/moby/blob/v27.5.1/daemon/inspect.go#L107-L110 and https://github.com/moby/moby/blob/v27.5.1/api/types/container/config.go#L55
- Chainlit authentication overview: https://docs.chainlit.io/authentication/overview
- Chainlit password authentication (`@cl.password_auth_callback` signature and example): https://docs.chainlit.io/authentication/password
- Python `hmac.compare_digest`, for what it does and does not conceal: https://docs.python.org/3/library/hmac.html
- Python `os.environ`, for what indexing a missing key does: https://docs.python.org/3/library/os.html
- OWASP Password Storage Cheat Sheet, for Argon2id over bcrypt in anything new: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
- OpenHands FAQs (single-user design, no built-in auth, sandboxing, hardened deployment): https://docs.openhands.dev/overview/faqs
- OpenHands local setup (default docker port mapping): https://docs.openhands.dev/openhands/usage/run-openhands/local-setup
- curl manual (the `exitcode` and `errormsg` write-out variables, both added in curl 7.75.0; `-s`/`--silent`, which shows no progress meter or error messages; `-S`/`--show-error`, which with `--silent` shows an error message if curl fails; `-o /dev/null` to suppress the response body). The curl manual is also cited for `-I`/`--head`, which fetches the headers only with a HEAD request, and the `http_code` write-out variable, the numerical response code found in the last retrieved HTTP(S) transfer. This Sources item's wording was checked against the installed curl 8.18.0 manual, which does not say what `http_code` prints when no response arrives. The curl manual source: https://curl.se/docs/manpage.html
- Linux ACLs, acl(5): default ACL inheritance and how a default ACL takes the place of the umask for new files (man-pages; checked against the local acl 2.3.2 manual, October 2026): https://man7.org/linux/man-pages/man5/acl.5.html
- getfacl(1): `-d` (default ACL), `-c` (omit the header) and `-p` (keep leading `/`) options (man-pages; checked against the local acl 2.3.2 manual, October 2026): https://man7.org/linux/man-pages/man1/getfacl.1.html


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- anything: AnythingLLM documentation (unknown)
- lobe: LobeHub (v2.2.16)
- lobe-docs: LobeHub documentation (rolling) (unknown)
- chainlit: Chainlit documentation (unknown)
- openhands: OpenHands documentation (unknown)
- docker: Docker CLI (v27.5.1)
- compose: Docker Compose (v2.32.4)
- compose-go: compose-go (v2.4.7)
- moby: Moby (v27.5.1)
- python: Python documentation (unknown)
- owasp: OWASP password guidance (unknown)
- curl: curl minimum write-out version (7.75.0)
- linux: Linux permissions and tools (unknown)

Claims (full source mapping in the JSON block below):

- anything-single (REASONED; anything): Docker single-user password protection is optional and grants every holder settings/admin/chat access, not per-user isolation.
- anything-roles (REASONED; anything): Multi-user mode is preferred: Admin has full access, Manager all workspaces without provider/store settings, Default only assigned workspaces.
- anything-mode (REASONED; anything): Enabling multi-user mode cannot be reverted to single-user; choose deliberately.
- anything-bind (REASONED; anything, docker): Publish AnythingLLM only on loopback 3001 and put proxy TLS/login in front.
- lobe-vault (REASONED; lobe): KEY_VAULTS_SECRET encrypts stored provider credentials; generate with openssl rand -base64 32 and preserve it for the data lifetime, not as a login password.
- lobe-session (REASONED; lobe, lobe-docs): Better Auth requires AUTH_SECRET, generated the same way, to sign sessions.
- lobe-sso (REASONED; lobe, lobe-docs): AUTH_SSO_PROVIDERS selects providers and matching credentials; AUTH_DISABLE_EMAIL_PASSWORD=1 forces SSO-only login.
- lobe-admission (REASONED; lobe, lobe-docs): AUTH_ALLOWED_EMAILS defaults empty, permitting all emails; set explicit addresses/domains for registration.
- lobe-mfa (REASONED; lobe-docs): Enforce MFA at the configured SSO provider; LobeChat login has no second factor of its own.
- docker-input (REASONED; docker): Docker --env-file reads a named file, not stdin; -e NAME uses CLI environment, while -e NAME=value exposes argv.
- docker-envfile (REASONED; docker): Bare names in env files import CLI environment; validate exactly the intended secret assignments and reject extra/missing/duplicate lines.
- compose-envfile (REASONED; compose, compose-go): Compose env_file resolves environment via compose-go v2.4.7, pinned by Compose v2.32.4.
- compose-secrets (REASONED; compose): Compose file secrets mount read-only under /run/secrets; environment secrets are copied there, default 0444, and need an application reader.
- lobe-file-input (REASONED; lobe): LobeHub documents environment inputs; the recorded v2.2.16 search found no KEY_VAULTS_SECRET_FILE, AUTH_SECRET_FILE or AUTH_GOOGLE_SECRET_FILE.
- lobe-file (REASONED; lobe, docker, linux): Create the durable plaintext env file once in protected directories; never replace a live encryption key, refuse a default ACL or missing getfacl, check mode 0600 after the write and discard partial failed writes.
- lobe-launch (REASONED; lobe, docker): Use validated env-file with loopback 3210 publication and non-secret SSO/admission settings on argv.
- container-secrets (REASONED; moby, docker): Environment values remain readable through Docker inspect for running/stopped containers and process environ during lifetime; env-file avoids CLI argv, not operator access.
- chainlit-default (REASONED; chainlit): Chainlit applications are public by default; set CHAINLIT_AUTH_SECRET and at least one password/OAuth/header callback.
- chainlit-callback (REASONED; chainlit): Password callback returns a user on success and None on refusal; shared credential creates one identity without individual revocation.
- chainlit-environment (REASONED; python, chainlit): Example reads credentials once at import, fails on missing or empty values, and requires restart to adopt replacements.
- chainlit-comparison (REASONED; python): Both compare_digest calls run before combining results; content-based short-circuiting is avoided, but types/lengths and whole callback timing are not concealed.
- chainlit-rotation (REASONED; chainlit): Password replacement stops new logins, not existing signed sessions; rotate CHAINLIT_AUTH_SECRET too to invalidate them.
- chainlit-accounts (REASONED; chainlit, owasp): Chainlit persists users but supplies no password-account management; per-user store/verification are the application's responsibility, with Argon2id for new hashes.
- chainlit-mfa (REASONED; chainlit): Chainlit has no built-in MFA; use an enforcing identity provider or authenticating proxy.
- openhands-boundary (REASONED; openhands): OpenHands is single-user; shared-key API access is not per-user identity, and execution isolation depends on backend/mount/socket choices.
- openhands-bind (REASONED; openhands): Quickstart publishes 3000 on every interface; use 127.0.0.1:3000:3000 and an authenticated tunnel.
- verify-listeners (REASONED; docker, openhands, curl): Inventory loopback UI listeners 3001/3210/3000; external refusal must name the real remote path, with DNS/local failures inconclusive.
- verify-login (REASONED; anything, chainlit, openhands, lobe-docs, curl): Verify proxy HTTPS and login requirement; generic API refusal is a deployment-specific check requiring an actual protected route.
- verify-registration (REASONED; lobe, lobe-docs): A new Google identity absent from AUTH_ALLOWED_EMAILS should fail registration; this does not revoke an existing user's session.
- verify-isolation (REASONED; anything): User A's retrieval must succeed before user B is checked for denial; independently test documents, history, memory and caches, not login alone.

````json
{
  "schema": 1,
  "checked": "2026-09-26",
  "documentation_checked": "2026-09",
  "body_sha256": "da77f1c2ed52eca4ba010260e2fecfc66b28f979654b5a47ca65240a6d8c1907",
  "components": {
    "anything": {
      "name": "AnythingLLM documentation",
      "basis": "unknown",
      "sources": {
        "s6b5aa8c91ad3": "https://docs.anythingllm.com/features/security-and-access"
      }
    },
    "lobe": {
      "name": "LobeHub",
      "basis": "v2.2.16",
      "sources": {
        "s977fd003b436": "https://github.com/lobehub/lobehub/blob/v2.2.16/docs/self-hosting/environment-variables/basic.mdx#L22-L32",
        "sdb87ee6e14a5": "https://github.com/lobehub/lobehub/blob/v2.2.16/docs/self-hosting/environment-variables/auth.mdx"
      }
    },
    "lobe-docs": {
      "name": "LobeHub documentation (rolling)",
      "basis": "unknown",
      "sources": {
        "s84e88654e760": "https://lobehub.com/only-ai/markdown/docs/en/self-hosting/environment-variables/auth"
      }
    },
    "chainlit": {
      "name": "Chainlit documentation",
      "basis": "unknown",
      "sources": {
        "sa8ffef5a2afe": "https://docs.chainlit.io/authentication/overview",
        "sfc1842532120": "https://docs.chainlit.io/authentication/password"
      }
    },
    "openhands": {
      "name": "OpenHands documentation",
      "basis": "unknown",
      "sources": {
        "s1756d23e1d0b": "https://docs.openhands.dev/overview/faqs",
        "s0ceb47353632": "https://docs.openhands.dev/openhands/usage/run-openhands/local-setup"
      }
    },
    "docker": {
      "name": "Docker CLI",
      "basis": "v27.5.1",
      "sources": {
        "s52c162a9786f": "https://github.com/docker/cli/blob/v27.5.1/docs/reference/commandline/container_run.md",
        "s8c2adc7212d7": "https://github.com/docker/cli/blob/v27.5.1/docs/reference/commandline/container_run.md#L626-L640",
        "s2611a6021e2f": "https://github.com/docker/cli/blob/v27.5.1/opts/env.go#L18-L31",
        "s9a4c6197f246": "https://github.com/docker/cli/blob/v27.5.1/pkg/kvfile/kvfile.go#L54-L69",
        "sdc1935b6999f": "https://github.com/docker/cli/blob/v27.5.1/opts/parse.go#L19-L39",
        "sd1025af9c6ff": "https://github.com/docker/cli/blob/v27.5.1/pkg/kvfile/kvfile.go#L121-L126"
      }
    },
    "compose": {
      "name": "Docker Compose",
      "basis": "v2.32.4",
      "sources": {
        "s14c0c0a70b7e": "https://github.com/docker/compose/blob/v2.32.4/go.mod#L5-L18",
        "se594167796f7": "https://github.com/docker/compose/blob/v2.32.4/pkg/compose/create.go#L1029-L1084",
        "sf6263e4f21f0": "https://github.com/docker/compose/blob/v2.32.4/pkg/compose/secrets.go#L101",
        "s0d8af80827c8": "https://github.com/docker/compose/blob/v2.32.4/pkg/compose/secrets.go#L31-L61"
      }
    },
    "compose-go": {
      "name": "compose-go",
      "basis": "v2.4.7",
      "sources": {
        "s25bb7bb5626f": "https://github.com/compose-spec/compose-go/blob/v2.4.7/types/project.go#L631-L664"
      }
    },
    "moby": {
      "name": "Moby",
      "basis": "v27.5.1",
      "sources": {
        "s638ae9c795a2": "https://github.com/moby/moby/blob/v27.5.1/api/types/container/config.go#L55",
        "sa3cf5ca8ad4d": "https://github.com/moby/moby/blob/v27.5.1/daemon/inspect.go#L107-L110"
      }
    },
    "python": {
      "name": "Python documentation",
      "basis": "unknown",
      "sources": {
        "se86233c0ce69": "https://docs.python.org/3/library/os.html",
        "s7a54556e5dac": "https://docs.python.org/3/library/hmac.html"
      }
    },
    "owasp": {
      "name": "OWASP password guidance",
      "basis": "unknown",
      "sources": {
        "s49e8d76431d9": "https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html"
      }
    },
    "curl": {
      "name": "curl minimum write-out version",
      "basis": "7.75.0",
      "sources": {
        "s2b2686afaf41": "https://curl.se/docs/manpage.html"
      }
    },
    "linux": {
      "name": "Linux permissions and tools",
      "basis": "unknown",
      "sources": {
        "s31f41c54750c": "https://man7.org/linux/man-pages/man5/acl.5.html",
        "s08902025e5f9": "https://man7.org/linux/man-pages/man1/getfacl.1.html"
      }
    }
  },
  "claims": {
    "anything-single": {"text": "Docker single-user password protection is optional and grants every holder settings/admin/chat access, not per-user isolation.", "components": ["anything"], "sources": ["anything:s6b5aa8c91ad3"], "status": "REASONED"},
    "anything-roles": {"text": "Multi-user mode is preferred: Admin has full access, Manager all workspaces without provider/store settings, Default only assigned workspaces.", "components": ["anything"], "sources": ["anything:s6b5aa8c91ad3"], "status": "REASONED"},
    "anything-mode": {"text": "Enabling multi-user mode cannot be reverted to single-user; choose deliberately.", "components": ["anything"], "sources": ["anything:s6b5aa8c91ad3"], "status": "REASONED"},
    "anything-bind": {"text": "Publish AnythingLLM only on loopback 3001 and put proxy TLS/login in front.", "components": ["anything", "docker"], "sources": ["anything:s6b5aa8c91ad3", "docker:s52c162a9786f"], "status": "REASONED"},
    "lobe-vault": {"text": "KEY_VAULTS_SECRET encrypts stored provider credentials; generate with openssl rand -base64 32 and preserve it for the data lifetime, not as a login password.", "components": ["lobe"], "sources": ["lobe:s977fd003b436"], "status": "REASONED"},
    "lobe-session": {"text": "Better Auth requires AUTH_SECRET, generated the same way, to sign sessions.", "components": ["lobe", "lobe-docs"], "sources": ["lobe-docs:s84e88654e760", "lobe:sdb87ee6e14a5"], "status": "REASONED"},
    "lobe-sso": {"text": "AUTH_SSO_PROVIDERS selects providers and matching credentials; AUTH_DISABLE_EMAIL_PASSWORD=1 forces SSO-only login.", "components": ["lobe", "lobe-docs"], "sources": ["lobe-docs:s84e88654e760", "lobe:sdb87ee6e14a5"], "status": "REASONED"},
    "lobe-admission": {"text": "AUTH_ALLOWED_EMAILS defaults empty, permitting all emails; set explicit addresses/domains for registration.", "components": ["lobe", "lobe-docs"], "sources": ["lobe-docs:s84e88654e760", "lobe:sdb87ee6e14a5"], "status": "REASONED"},
    "lobe-mfa": {"text": "Enforce MFA at the configured SSO provider; LobeChat login has no second factor of its own.", "components": ["lobe-docs"], "sources": ["lobe-docs:s84e88654e760"], "status": "REASONED"},
    "docker-input": {"text": "Docker --env-file reads a named file, not stdin; -e NAME uses CLI environment, while -e NAME=value exposes argv.", "components": ["docker"], "sources": ["docker:s52c162a9786f", "docker:s8c2adc7212d7", "docker:s2611a6021e2f", "docker:s9a4c6197f246"], "status": "REASONED"},
    "docker-envfile": {"text": "Bare names in env files import CLI environment; validate exactly the intended secret assignments and reject extra/missing/duplicate lines.", "components": ["docker"], "sources": ["docker:sdc1935b6999f", "docker:sd1025af9c6ff"], "status": "REASONED"},
    "compose-envfile": {"text": "Compose env_file resolves environment via compose-go v2.4.7, pinned by Compose v2.32.4.", "components": ["compose", "compose-go"], "sources": ["compose:s14c0c0a70b7e", "compose-go:s25bb7bb5626f"], "status": "REASONED"},
    "compose-secrets": {"text": "Compose file secrets mount read-only under /run/secrets; environment secrets are copied there, default 0444, and need an application reader.", "components": ["compose"], "sources": ["compose:se594167796f7", "compose:sf6263e4f21f0", "compose:s0d8af80827c8"], "status": "REASONED"},
    "lobe-file-input": {"text": "LobeHub documents environment inputs; the recorded v2.2.16 search found no KEY_VAULTS_SECRET_FILE, AUTH_SECRET_FILE or AUTH_GOOGLE_SECRET_FILE.", "components": ["lobe"], "sources": ["lobe:s977fd003b436", "lobe:sdb87ee6e14a5"], "status": "REASONED"},
    "lobe-file": {"text": "Create the durable plaintext env file once in protected directories; never replace a live encryption key, refuse a default ACL or missing getfacl, check mode 0600 after the write and discard partial failed writes.", "components": ["lobe", "docker", "linux"], "sources": ["lobe:s977fd003b436", "lobe:sdb87ee6e14a5", "docker:s52c162a9786f", "linux:s31f41c54750c", "linux:s08902025e5f9"], "status": "REASONED"},
    "lobe-launch": {"text": "Use validated env-file with loopback 3210 publication and non-secret SSO/admission settings on argv.", "components": ["lobe", "docker"], "sources": ["lobe:sdb87ee6e14a5", "docker:s52c162a9786f"], "status": "REASONED"},
    "container-secrets": {"text": "Environment values remain readable through Docker inspect for running/stopped containers and process environ during lifetime; env-file avoids CLI argv, not operator access.", "components": ["moby", "docker"], "sources": ["moby:s638ae9c795a2", "moby:sa3cf5ca8ad4d", "docker:s52c162a9786f"], "status": "REASONED"},
    "chainlit-default": {"text": "Chainlit applications are public by default; set CHAINLIT_AUTH_SECRET and at least one password/OAuth/header callback.", "components": ["chainlit"], "sources": ["chainlit:sa8ffef5a2afe"], "status": "REASONED"},
    "chainlit-callback": {"text": "Password callback returns a user on success and None on refusal; shared credential creates one identity without individual revocation.", "components": ["chainlit"], "sources": ["chainlit:sfc1842532120"], "status": "REASONED"},
    "chainlit-environment": {"text": "Example reads credentials once at import, fails on missing or empty values, and requires restart to adopt replacements.", "components": ["python", "chainlit"], "sources": ["python:se86233c0ce69", "chainlit:sfc1842532120"], "status": "REASONED"},
    "chainlit-comparison": {"text": "Both compare_digest calls run before combining results; content-based short-circuiting is avoided, but types/lengths and whole callback timing are not concealed.", "components": ["python"], "sources": ["python:s7a54556e5dac"], "status": "REASONED"},
    "chainlit-rotation": {"text": "Password replacement stops new logins, not existing signed sessions; rotate CHAINLIT_AUTH_SECRET too to invalidate them.", "components": ["chainlit"], "sources": ["chainlit:sa8ffef5a2afe"], "status": "REASONED"},
    "chainlit-accounts": {"text": "Chainlit persists users but supplies no password-account management; per-user store/verification are the application's responsibility, with Argon2id for new hashes.", "components": ["chainlit", "owasp"], "sources": ["chainlit:sfc1842532120", "owasp:s49e8d76431d9"], "status": "REASONED"},
    "chainlit-mfa": {"text": "Chainlit has no built-in MFA; use an enforcing identity provider or authenticating proxy.", "components": ["chainlit"], "sources": ["chainlit:sa8ffef5a2afe"], "status": "REASONED"},
    "openhands-boundary": {"text": "OpenHands is single-user; shared-key API access is not per-user identity, and execution isolation depends on backend/mount/socket choices.", "components": ["openhands"], "sources": ["openhands:s1756d23e1d0b"], "status": "REASONED"},
    "openhands-bind": {"text": "Quickstart publishes 3000 on every interface; use 127.0.0.1:3000:3000 and an authenticated tunnel.", "components": ["openhands"], "sources": ["openhands:s0ceb47353632"], "status": "REASONED"},
    "verify-listeners": {"text": "Inventory loopback UI listeners 3001/3210/3000; external refusal must name the real remote path, with DNS/local failures inconclusive.", "components": ["docker", "openhands", "curl"], "sources": ["docker:s52c162a9786f", "openhands:s0ceb47353632", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [1]},
    "verify-login": {"text": "Verify proxy HTTPS and login requirement; generic API refusal is a deployment-specific check requiring an actual protected route.", "components": ["anything", "chainlit", "openhands", "lobe-docs", "curl"], "sources": ["anything:s6b5aa8c91ad3", "lobe-docs:s84e88654e760", "chainlit:sa8ffef5a2afe", "openhands:s1756d23e1d0b", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [1]},
    "verify-registration": {"text": "A new Google identity absent from AUTH_ALLOWED_EMAILS should fail registration; this does not revoke an existing user's session.", "components": ["lobe", "lobe-docs"], "sources": ["lobe-docs:s84e88654e760", "lobe:sdb87ee6e14a5"], "status": "REASONED", "verify": [1]},
    "verify-isolation": {"text": "User A's retrieval must succeed before user B is checked for denial; independently test documents, history, memory and caches, not login alone.", "components": ["anything"], "sources": ["anything:s6b5aa8c91ad3"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
