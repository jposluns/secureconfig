# HashiCorp Vault

HashiCorp Vault is a secrets manager: applications fetch passwords, API keys and other credentials from it instead of keeping them in files. This guide helps your AI assistant make sure it is configured securely, including no dev mode in production, an enabled audit device, and narrowly scoped policies and tokens.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/vault.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Vault loopback run 2.1.1, Vault handler source v2.2.1, Vault forwarding source v2.2.1, Vault JWT audience minimum 1.17, Vault historical wrapping qualification 0.8, and curl minimum write-out version 7.75.0; 1 further source carries no recorded version. Metadata reviewed 2026-09-26; documentation checked September 2026. The guide records 36 claims: 16 demonstrated by a check that ran; 20 reasoned from cited sources and any earlier-form run (not a live demonstration of the shipped form).

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Vault's own defaults are careful: the listener binds loopback, TLS is assumed (`tls_disable` is
`false`), and the web UI is off. The exposures are the deployment decisions you make on top of that,
and the corpus points you here from [machine-auth.md](machine-auth.md)
without saying how to stand one up safely. Five decisions decide it: not running dev mode, keeping TLS
on the listener you expose, choosing and guarding the seal, enabling an audit device, and retiring the
initial root token. OpenBao is the Linux Foundation open-source fork after Vault's move to the BUSL
licence; the controls below are written for Vault, and OpenBao shares the model but differs in some
commands, so check its own docs if you run it.

At the time of writing, the defaults and configuration below follow the current
[Vault configuration reference](https://developer.hashicorp.com/vault/docs/configuration) and
[TCP listener reference](https://developer.hashicorp.com/vault/docs/configuration/listener/tcp).
The application ACL, AppRole, response-wrapping, and authenticated-monitoring controls below are
available in Vault Community. Edition and version qualifications appear where they matter.

## 1. Never run dev mode in production

`vault server -dev` runs entirely in memory, initializes and unseals itself with a single key, serves
plain HTTP, and prints a root token to the console. The `-dev-tls` variant adds a throwaway
certificate but is still a development server: by default it binds loopback rather than the world,
stores nothing durably, and writes its printed root token into your token helper unless
`-dev-no-store-token` is set. It does not provide the production protections below.
Run a real server from a config file under your service manager
(`vault server -config=/etc/vault.d/vault.hcl`), and audit the systemd unit and its environment so no
`-dev` flag or dev-token override slips into production.
See [dev mode](https://developer.hashicorp.com/vault/docs/concepts/dev-server) and
[server flags](https://developer.hashicorp.com/vault/docs/commands/server).

## 2. Bind and front the listeners deliberately

The API listener answers on `8200` (and serves the UI at `/ui` on that same listener when `ui = true`),
and cluster peers forward requests and run Raft over `8201`. Bind the API to the private address that
clients actually use rather than a wildcard, keep `8201` reachable only by the other Vault nodes, and
put a default-deny firewall around both. `api_addr` and `cluster_addr` only advertise where peers and
redirects should point; they do not restrict what the listener binds, so set the `address` explicitly.
Expose the API to anything wider than a trusted network only behind the corpus's fronting controls
([fronting-auth.md](fronting-auth.md), [nginx.md](nginx.md), [caddy.md](caddy.md)), and enforce
Vault's Login MFA on the
human auth methods, not only at a UI proxy, since the token method cannot use it ([mfa.md](mfa.md));
the cluster port must keep Vault's own end-to-end TLS regardless of any proxy.
Other listeners exist only if you configure them (a KMIP listener on Enterprise, a Vault Agent or Proxy
listener), and an external storage backend is an outbound connection to a separate service with its own
listeners, so add each to your own network-surface inventory.
See [HA communication](https://developer.hashicorp.com/vault/docs/concepts/ha) and
[Login MFA](https://developer.hashicorp.com/vault/docs/auth/login-mfa).

Monitoring endpoints expose operational information. Keep anonymous metrics and profiling access
disabled on every API listener. The listener in section 3 explicitly sets
`unauthenticated_metrics_access = false` and `unauthenticated_pprof_access = false`;
both default to false in the current reference at the time of writing. Enabling monitoring is not a
reason to change them.
See [listener telemetry and profiling parameters](https://developer.hashicorp.com/vault/docs/configuration/listener/tcp#telemetry-parameters).

Give the metrics collector a separate identity with this policy:

```hcl
path "sys/metrics" {
  capabilities = ["read"]
}
```

The collector requests `GET /v1/sys/metrics`; its token should have no application-secret access.
Keep monitoring traffic on the permitted network. The metrics and profiling APIs must be called
from the root namespace, including on Enterprise deployments that use namespaces. The metrics
policy does not grant profiling access.
See the [metrics API](https://developer.hashicorp.com/vault/api-docs/system/metrics),
[profiling API](https://developer.hashicorp.com/vault/api-docs/system/pprof), and
[policy capabilities](https://developer.hashicorp.com/vault/docs/concepts/policies#capabilities).

## 3. Keep TLS on the listener

Vault assumes TLS, so `tls_disable = true` is an explicit choice to put every token and secret on the
wire in plaintext; never set it on a listener anything reaches. Give the listener a real certificate
and key with `tls_cert_file` and `tls_key_file`, keep the key `0400` and owned by the vault user, and
set `tls_min_version = "tls12"` or higher. Certificates come from [free-certificates.md](free-certificates.md)
or, for an internal CA, [self-signed.md](self-signed.md). A minimal Raft node configuration:

```hcl
ui            = false
disable_mlock = true            # Raft memory-maps its data; disable swap at the OS instead (section 8)
api_addr      = "https://vault-1.internal:8200"
cluster_addr  = "https://vault-1.internal:8201"   # Raft requires this, distinct from the listener

storage "raft" {
  path    = "/var/lib/vault/raft"
  node_id = "vault-1"
}

listener "tcp" {
  address         = "10.20.0.11:8200"
  cluster_address = "10.20.0.11:8201"
  tls_cert_file   = "/etc/vault.d/tls/server-fullchain.pem"
  tls_key_file    = "/etc/vault.d/tls/server.key"
  tls_min_version = "tls12"

  telemetry {
    unauthenticated_metrics_access = false
  }

  profiling {
    unauthenticated_pprof_access = false
  }
}
```

Substitute the node's actual addresses and certificate paths.
See the [TCP listener reference](https://developer.hashicorp.com/vault/docs/configuration/listener/tcp)
and [Integrated Storage configuration](https://developer.hashicorp.com/vault/docs/configuration/storage/raft).

## 4. Choose the seal, and initialize once

A fresh server starts sealed: the storage is encrypted and Vault cannot read it until it is unsealed,
and the seal you pick decides who or what does that. Shamir splits the unseal capability into key
shares (`vault operator init -key-shares=5 -key-threshold=3`), and a threshold of custodians must each
supply a share at the hidden prompt to unseal; never pass a share on the command line. The prompt
keeps the share out of the command text, shell history and tracing; the account owner and root can
still read it in the `vault` process. Auto-unseal
uses the configured external seal service, such as AWS KMS (`seal "awskms" { ... }`) or another
Vault's Transit secrets engine, and instead emits recovery keys for privileged operations.
Transit auto-unseal is available in Community; seal wrapping requires Enterprise.
See [initialization](https://developer.hashicorp.com/vault/docs/commands/operator/init),
[the unseal prompt](https://developer.hashicorp.com/vault/docs/commands/operator/unseal),
[AWS KMS seals](https://developer.hashicorp.com/vault/docs/configuration/seal/awskms), and
[Transit seals](https://developer.hashicorp.com/vault/docs/configuration/seal/transit).

Initialize a cluster exactly once and join the other nodes to it. Capture initialization output
securely, including the unseal or recovery material and initial root token, and preserve split
custody of the shares. Later quorum-authorized rekey operations can replace unseal or recovery
shares. The trade cuts both ways: a threshold of unseal shares plus a copy of the storage is an
offline path to your data, while losing the required shares, or permanently losing the external
seal mechanism and its keys, can make the ciphertext, backups included, permanently unreadable.
See [operator rekey](https://developer.hashicorp.com/vault/docs/commands/operator/rekey).

Recovery keys authorize recovery operations but cannot decrypt the root key when the auto-unseal
mechanism is unavailable. A temporary outage prevents recovery until the mechanism returns;
permanent loss can make the cluster and backups unrecoverable. Enterprise seal HA is a separate
feature, not a Community fallback.
See [seal and recovery behavior](https://developer.hashicorp.com/vault/docs/concepts/seal).

## 5. Enable an audit device

A new cluster has no audit device, so requests are served with no durable record; server logs are not
a substitute. Enable one (`vault audit enable file file_path=/var/log/vault/audit.log`), and add a
second, independent one (`vault audit enable syslog` shipping to a SEPARATE host or failure domain: a local
syslog agent that writes the same disk is not independent). The reason is that auditing is fail-closed: when Vault
cannot write to at least one enabled device it "refuses to service the corresponding API request", so a
full disk on your only device is an outage. Collect both devices: either device alone can have gaps
when it was unavailable. The syslog device sends to the local syslog agent; configure that agent's
remote delivery and monitor it.
See [audit-device availability](https://developer.hashicorp.com/vault/docs/audit#availability-of-audit-devices)
and the [syslog device](https://developer.hashicorp.com/vault/docs/audit/syslog).

Monitor the disk and rotate the file: rename the audit file and send the Vault process `SIGHUP`
to reopen it, rather than truncating it.
See [file audit rotation](https://developer.hashicorp.com/vault/docs/audit/file#log-file-rotation).

Vault writes a keyed HMAC-SHA256 of most string values by default, so a
leaked string value is hashed rather than exposed; leave that on and never enable `log_raw`, but non-string
values are not hashed, so still restrict who can read the log and treat it as sensitive. A handful of endpoints,
including `sys/health` and `sys/seal-status`, are exempt from auditing, which matters when you verify
delivery below.
See [audit hashing and exemptions](https://developer.hashicorp.com/vault/docs/audit) and
[audit-device options](https://developer.hashicorp.com/vault/api-docs/system/audit).

## 6. Revoke the initial root token

The initial root token has unlimited access and no expiry, so it is a bootstrap credential, not an
operating one. Retire it in order: enable an audit device, configure an auth method and write scoped
admin policies, then actually log in as a non-root admin and confirm that identity works, and only then
revoke the root token from its own session with `vault token revoke -self`. Log in through the auth method, not with a non-orphan token made by
`vault token create` while the root token is selected: that token is the root token's child and is
revoked with it (observed on the loopback run in Verify). Confirm the revocation (the
Verify section does), and delete any token-helper copy left in `~/.vault-token`. Keep no live root
token afterward; if you genuinely need root again, `vault operator generate-root` issues a new
one through the unseal quorum, or the recovery-key quorum under auto-unseal, which is the point of not
leaving one lying around.
See [token behavior](https://developer.hashicorp.com/vault/docs/concepts/tokens),
[self-revocation](https://developer.hashicorp.com/vault/docs/commands/token/revoke), and
[root generation](https://developer.hashicorp.com/vault/docs/commands/operator/generate-root).

For CLI authentication, select tokens through a securely injected `VAULT_TOKEN` environment variable
or a token helper. `VAULT_TOKEN` moves a token out of argv, not out of reach: while exported it is in the environment of every program the shell starts, readable through `/proc/<pid>/environ` by the same account and root, and where the shell received it at startup, in the shell's own. Enter interactive login credentials and unseal shares at the prompt.
The prompt keeps them out of the command text, shell history and tracing; the account owner and
root can still read them in the `vault` process.
Never put credentials in command arguments, URLs, shell history, or build logs.
See [CLI authentication](https://developer.hashicorp.com/vault/docs/commands) and
[login prompts](https://developer.hashicorp.com/vault/docs/commands/login).

## 7. Scope policies and tokens

The root policy bypasses every rule; every other identity gets only the capabilities its policies
grant, on a deny-by-default basis. Write narrow policies with `vault policy write`, prefer logins
through an auth method over long-lived tokens, and give tokens bounded TTLs so a leaked one expires.

An application that can read another application's secrets can turn one compromise into several.
For an existing KV v2 mount at `kv/`, grant only the required data path:

```bash
vault policy write payments-read - <<'HCL'
path "kv/data/payments/config" {
  capabilities = ["read"]
}
HCL
```

KV v2 policies use the API's `data/` path. This example grants neither writes nor metadata listing.
Give applications no `root` policy or `sudo` capability, and review every policy attached through
tokens and identities; one narrow policy does not cancel broader grants elsewhere. This Community
example is specifically for KV v2; do not copy its path unchanged for KV v1.
See [KV v2 API paths](https://developer.hashicorp.com/vault/api-docs/secret/kv/kv-v2),
[ACL policy semantics](https://developer.hashicorp.com/vault/docs/concepts/policies), and
[policy write](https://developer.hashicorp.com/vault/docs/commands/policy/write).

A short-lived Vault token does not help if its login credential can mint replacements indefinitely.
For a bounded batch job using AppRole, limit both the SecretID and the resulting token. Enable the
mount only if it does not already exist; substitute the application's actual source network for the
example CIDR.

```bash
# Enable only if approle/ does not already exist.
vault auth enable approle
vault write auth/approle/role/payments \
  bind_secret_id=true \
  secret_id_ttl=10m \
  secret_id_num_uses=1 \
  secret_id_bound_cidrs=10.20.30.0/24 \
  token_policies=payments-read \
  token_no_default_policy=true \
  token_type=service \
  token_ttl=5m \
  token_max_ttl=15m \
  token_explicit_max_ttl=15m \
  token_period=0 \
  token_num_uses=100 \
  token_bound_cidrs=10.20.30.0/24
```

SecretID limits govern login; token limits govern subsequent requests. An expired SecretID can still
log in until AppRole's once-a-minute tidy deletes it (observed in Verify). Zero use limits mean
unlimited use. `token_explicit_max_ttl` supplies a hard lifetime ceiling. This role excludes the
default policy, so clients must not assume its self-service permissions. The values are an example
workload budget, not Vault defaults; server and mount limits can shorten issued token lifetimes.
These are current Community role parameters, not a universal Vault Agent configuration.
See [AppRole configuration](https://developer.hashicorp.com/vault/docs/auth/approle),
[exact role parameters](https://developer.hashicorp.com/vault/api-docs/auth/approle), and
[token lifetime rules](https://developer.hashicorp.com/vault/docs/concepts/tokens).

A one-use SecretID requires fresh delivery for another login. Count the client's actual requests
before choosing a token use limit; limited-use tokens cannot create child tokens. HashiCorp generally
recommends batch tokens for AppRole, but service tokens are intentional here for use limiting and
individual revocation. Batch tokens have different renewal and revocation behavior.
See [AppRole constraints](https://developer.hashicorp.com/vault/docs/auth/approle) and
[token types](https://developer.hashicorp.com/vault/docs/concepts/tokens).

Passing a SecretID through deployment systems exposes it to every intermediary. Deliver a
short-lived, single-use wrapping token instead, and require wrapping in the delivery identity's
policy:

```bash
vault policy write payments-delivery - <<'HCL'
path "auth/approle/role/payments/secret-id" {
  capabilities = ["create", "update"]
  min_wrapping_ttl = "1s"
  max_wrapping_ttl = "60s"
}
HCL
```

Attach this policy to the deployment identity, not the application. A positive minimum wrapping
TTL requires wrapping on this path. Review the delivery identity's other policies as well; the
effective permissions and wrapping limits must preserve this restriction.
See [required response-wrapping TTLs](https://developer.hashicorp.com/vault/docs/concepts/policies#required-response-wrapping-ttls).

As that deployment identity:

```bash
vault write -wrap-ttl=60s -f auth/approle/role/payments/secret-id
```

Treat the returned wrapping token as a credential. Keep it out of build logs and transfer it
through the protected delivery channel. Before unwrapping, the recipient must use wrapping lookup
to validate its lifetime and exact `creation_path`, here
`auth/approle/role/payments/secret-id`. Unexpected, expired, or already-consumed tokens require
investigation. Wrapping-token expiry does not replace the SecretID's own TTL.
See [response wrapping and validation](https://developer.hashicorp.com/vault/docs/concepts/response-wrapping).

For an explicit lookup request, have the protected delivery mechanism populate an owner-readable
JSON file at `/run/secrets/payments-wrapping-lookup.json` with the wrapping token in its `token`
field. Pass that request on stdin:

```bash
vault write -format=json sys/wrapping/lookup - \
  < /run/secrets/payments-wrapping-lookup.json
```

The wrapping token reaches `vault` from the request file on its stdin, so it is not in the
command's arguments, and because the command never types it or expands a variable holding it,
neither shell history nor `set -x` tracing records it from this command, provided the delivery
mechanism, not a shell command containing the token, writes the file. Stdin closes the argv channel only: the account
owner and root can still read the file and the `vault` process's memory.

Check `data.creation_path`, `data.creation_time`, and `data.creation_ttl`; the latter is the
original TTL, not the remaining lifetime. Confirm the token is still within that lifetime before
proceeding. Protect and remove the request file when finished.
See the [wrapping lookup API](https://developer.hashicorp.com/vault/api-docs/system/wrapping-lookup)
and [JSON input to write](https://developer.hashicorp.com/vault/docs/commands/write).

With that same wrapping token selected through securely injected `VAULT_TOKEN`, unwrap without a
token argument:

```bash
vault unwrap
```

No token is typed into this command, so the wrapping token is not in `vault`'s arguments, and
neither shell history nor `set -x` tracing records it from this command. `VAULT_TOKEN` moves it out
of argv, not out of reach: while the variable is exported, the token is in the environment of every
program the shell starts, including `vault`, readable through `/proc/<pid>/environ` by the same
account and root while each runs, and where the shell received `VAULT_TOKEN` in its initial
environment, that file also shows it for the shell itself. Whoever reads it there before the unwrap
can unwrap it first, which leaves the recipient's unwrap failing on a consumed token; investigate
that as above. The opportunity to unwrap ends when the token is consumed or expires; its bytes can remain exposed in process environments afterward.

Protect the output, which contains the SecretID. Response wrapping is available in Community;
this example targets current behavior. The conceptual reference notes that some wrapping-token
features date from Vault 0.8 and may be unavailable before that version.
See [unwrap](https://developer.hashicorp.com/vault/docs/commands/unwrap) and
[response wrapping](https://developer.hashicorp.com/vault/docs/concepts/response-wrapping).

Where workload identity already exists, use Kubernetes or JWT authentication instead of distributing
AppRole credentials. Kubernetes roles should bind explicit service-account names and namespaces.
JWT roles should constrain the intended identity and audience; since Vault 1.17, a JWT containing
`aud` requires an exact match with at least one configured `bound_audiences` value. These are
alternative integrations, not additional prerequisites for this example.
See [AppRole integration guidance](https://developer.hashicorp.com/vault/docs/auth/approle/approle-pattern),
[Kubernetes role bindings](https://developer.hashicorp.com/vault/api-docs/auth/kubernetes), and
[JWT authentication](https://developer.hashicorp.com/vault/docs/auth/jwt).

Do not try to "block all `sys/`": some system paths answer without authentication by design, both the
`sys/seal-status` and `sys/health` monitors need and the `sys/init` and `sys/leader` bootstrap paths,
and policy cannot close a bootstrap path, so keep an uninitialized or unsealed Vault off untrusted
networks (whoever reaches `sys/init` first can initialize it and take the root token). Other
authenticated system
operations are policy-gated, while recovery paths such as `sys/unseal` carry their own authorization, so
the control is correct policies plus network isolation, not blanket denial.
See [initialization](https://developer.hashicorp.com/vault/api-docs/system/init),
[leader status](https://developer.hashicorp.com/vault/api-docs/system/leader), and
[seal status](https://developer.hashicorp.com/vault/api-docs/system/seal-status).

## 8. Protect storage, memory, and backups

Encryption at rest protects confidentiality, not availability: whoever can reach the storage can still
delete or corrupt it, and a backup carries exactly the sensitivity of the live data. Run Vault as a
dedicated unprivileged user that cannot overwrite its own binary or configuration, keep the Raft
directory owned by that user and mode-restricted, take snapshots with
`vault operator raft snapshot save /var/backups/vault.snap` and guard them like the unseal material,
and give an external
backend its own TLS and access controls. Two memory paths leak live key material regardless of the
storage: swap and core dumps. Disable swap on the host so the OS cannot page secrets to disk (the Raft
configuration above disables `mlock` because Raft memory-maps its data, and disabling swap is the
compensating control), and disable core dumps for the service (`LimitCORE=0` in the systemd unit).
See [production hardening](https://developer.hashicorp.com/vault/docs/concepts/production-hardening)
and [Raft snapshots](https://developer.hashicorp.com/vault/docs/commands/operator/raft#snapshot-save).

Deployments using other storage backends should not generalize the Raft recommendation:
HashiCorp discourages disabling `mlock` outside Integrated Storage.
See [memory-locking configuration](https://developer.hashicorp.com/vault/docs/configuration#disable_mlock).

## Verify

DEMONSTRATED: the loopback runs recorded here and at the blocks that record them.
Most checks below were **demonstrated on loopback** against Vault 2.1.1, the release binary with its
checksum verified against HashiCorp's published SHA256SUMS: a single Raft node running the section 3
configuration unchanged apart from addresses and paths. The Raft node ran with the API on
127.0.0.1:8200, the cluster listener on 127.0.0.1:8201, a private test CA, a file audit device, and
the section 2 and section 7 policies and AppRole role with `127.0.0.1/32` as the CIDR. Each block
ran as printed, with only its placeholders substituted, except where a step says otherwise. Exposed
states ran in further runs of the same binary: one with both anonymous-access settings `true`
throughout, one with `tls_disable = true` on the listener (a health check only), and one with the
section 3 configuration unchanged apart from addresses and paths. The exposed-state runs also
included a follow-up run with the same section 3 configuration, then stopped for a health-output
check, then with one added listener stanza on 127.0.0.2:8200 (which also bound 127.0.0.2:8201). The
first, third and follow-up runs exercised the policies, roles or delivery policy under test without
their limits. What these runs do not show is marked **REASONED** where it occurs, with the reason:
HA behavior (no multi-node cluster was set up for these runs), a second audit device in a separate
failure domain (the host has no second network), and the recipient's own validation (it belongs to
the receiving application). The other items these runs do not show, each marked **REASONED** where
it occurs, with the reason, are a wildcard bind (the host forbids binding every interface), `ss` run
as root (the host has no `sudo`), and real network paths and firewalls (the host has no second
network). These expectations follow the cited Vault documentation. The authoring host has no `sudo`,
so the first block's `sudo ss -tlnp` ran through a stand-in that runs `ss` without it; as the same
account, `ss` still showed the Vault process. The runs of the first block used an earlier form of it;
the gate suite's bash -n and ShellCheck 0.11.0 passes and the stub runs recorded after the two
inspection blocks cover its current form, which checks for `ss` before running it.

REASONED: curl result interpretation: transport or TLS failure is inconclusive, and only matched authenticated controls support a fixed outcome. Per the guide's cited curl options (write-out fields require 7.75.0; header files, TLS verification, direct connections, and write-out fields). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2. Stub runs of the current form of the two inspection blocks are recorded in the paragraph after those blocks; they do not establish live Vault behavior, and no live run of the current form is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. The curl `exitcode` and `errormsg` write-out fields require curl 7.75.0 or newer.
For authenticated and on-host checks, transport failure, TLS failure, an unexpected redirect, or a
missing positive control is inconclusive, never the fixed state.
See [curl write-out fields](https://curl.se/docs/manpage.html#-w).

REASONED: from the Vault CLI environment and token-helper documentation and the curl manual page
cited in Sources, and from the guards in the blocks below, not from the loopback runs, which record
no run with altered shell builtins, an apostrophe in a placeholder, or inherited proxy settings or
Vault proxy overrides. The `VAULT_TOKEN` environment exposure rests on the stubbed QA runs recorded
at the wrapping-lookup blocks below (same-account observers, no real `vault` client, root not tested).
Paste whole blocks and substitute inside the single quotes. Use the base HTTPS URL without a
trailing slash where a block appends an API path. Never embed credentials in a URL. These guards
assume ordinary shell builtins; do not insert a literal apostrophe into a single-quoted placeholder.
Use a clean shell without inherited HTTP proxy settings or Vault proxy overrides for direct CLI
checks. Select each CLI identity through securely injected `VAULT_TOKEN` or its token helper;
do not paste token values into commands. An exported `VAULT_TOKEN` is still readable through process environments (section 6). Keep credential-bearing CLI output out of recordings and
build logs.

**Listener, health, audit, root revocation, and role inspection (demonstrated on loopback):** run
this on the Vault host as a non-root admin authorized to inspect audit devices, look up its own token,
and read the example AppRole:

```bash
# DEMONSTRATED: loopback listener, health, file audit, root revocation and role runs recorded below; ss used the documented non-root stand-in. The loopback runs used an earlier form of the block, whose guard refusals exited with status 1, which took two values and which ended with the role read's status; the current form, which takes INSPECT or REVOKED_ROOT as a third value and exits once with one status for its classified checks, has not been demonstrated. The current form also checks for ss before running sudo ss, exits 2 when ss is missing and no other check found something or was inconclusive, and is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by the stub runs recorded after the second block, which do not establish live Vault behavior.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_VAULT_HTTPS_URL' \
    'REPLACE_WITH_CA_FILE' \
    'REPLACE_WITH_INSPECT_OR_REVOKED_ROOT'
  # Value 3 is INSPECT as the scoped admin, or REVOKED_ROOT for the repeat with the revoked root token selected.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 3 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 2; not probing"; exit 2 ;;
  esac
  case "$1" in https://*) ;; *) echo "use an HTTPS URL"; exit 2 ;; esac
  [ -r "$2" ] || { echo "CA file is not readable"; exit 2; }
  case "$3" in
    INSPECT|REVOKED_ROOT) ;;
    *) echo "set value 3 to INSPECT as the scoped admin, or REVOKED_ROOT with the revoked root token selected; not probing"; exit 2 ;;
  esac
  unset VAULT_SKIP_VERIFY VAULT_AGENT_ADDR VAULT_NAMESPACE VAULT_WRAP_TTL VAULT_ADDR VAULT_CACERT || exit 2
  export VAULT_ADDR="$1" VAULT_CACERT="$2" || exit 2
  set -- "$1" "$2" "$3" 0   # the 4th value is the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 2 (a refused part, such as a missing ss), which outranks 0
  if command -v ss >/dev/null; then
    if sudo ss -tlnp; then :; else
      echo "sudo ss -tlnp exit $?: no socket table to read; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3
    fi
  else
    echo "ss is not installed here; not listing sockets"
    case "$4" in 0) set -- "$1" "$2" "$3" 2 ;; esac
  fi
  if vault status -format=json; then :; else
    echo "vault status exit $? (2 means sealed, 1 an error): not the initialized, unsealed operating state; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3
  fi
  set -- "$1" "$2" "$3" "$4" "$(if curl -q -g -sS -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
    --cacert "$2" -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1/v1/sys/health"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  printf '%s' "${5% *}"
  case "${5##* }:${5% *}" in
    0:"http=200 "*) ;;
    0:*) echo "unclassified observation: read the health code above against the list below; a healthy response is a connectivity control, not proof of hardening" ;;
    *) echo "curl exit ${5##* }: the health request failed, as a transport or certificate verification failure does; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
  esac
  set -- "$1" "$2" "$3" "$4" "$(if vault audit list -detailed 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"
  printf '%s' "${5% *}"
  case "$3:${5##* }:${5% *}" in
    INSPECT:*:*"No audit devices are enabled."*) echo "FINDING: no audit device is enabled, so requests are served unlogged"; set -- "$1" "$2" "$3" 1 ;;
    INSPECT:0:*) echo "unclassified observation: the devices are listed above; check delivery by correlating a request_id, as described below" ;;
    INSPECT:*) echo "vault audit list exit ${5##* }: a failed or denied inspection; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
    REVOKED_ROOT:0:*) echo "unclassified observation: the audit list succeeded with the revoked root token selected; the token lookups below decide whether that token is live" ;;
    *) echo "with the revoked root token selected the audit list is expected to fail; not classified" ;;
  esac
  # In the two lookups, vault's own output goes straight to you and only its error text is held, so no token enters a value.
  { set -- "$1" "$2" "$3" "$4" "$(if { vault token lookup >&3; } 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"; } 3>&1
  printf '%s' "${5% *}"
  case "$3:${5##* }:${5% *}" in
    INSPECT:0:*) ;;
    INSPECT:*) echo "vault token lookup exit ${5##* }: the scoped admin's lookup, the positive control, failed; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
    REVOKED_ROOT:0:*) echo "FINDING: the revoked root token's lookup succeeded, so that token is still live"; set -- "$1" "$2" "$3" 1 ;;
    REVOKED_ROOT:*:*"permission denied"*|REVOKED_ROOT:*:*"invalid token"*) echo "Vault refused the revoked root token's lookup, the fixed outcome" ;;
    *) echo "vault token lookup exit ${5##* } without a permission-denied or invalid-token error; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
  esac
  { set -- "$1" "$2" "$3" "$4" "$(if { vault token lookup -format=json >&3; } 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"; } 3>&1
  printf '%s' "${5% *}"
  case "$3:${5##* }:${5% *}" in
    INSPECT:0:*) ;;
    INSPECT:*) echo "vault token lookup exit ${5##* }: the scoped admin's lookup, the positive control, failed; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
    REVOKED_ROOT:0:*) echo "FINDING: the revoked root token's lookup succeeded, so that token is still live"; set -- "$1" "$2" "$3" 1 ;;
    REVOKED_ROOT:*:*"permission denied"*|REVOKED_ROOT:*:*"invalid token"*) echo "Vault refused the revoked root token's lookup, the fixed outcome" ;;
    *) echo "vault token lookup exit ${5##* } without a permission-denied or invalid-token error; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
  esac
  if vault read -format=json auth/approle/role/payments; then :; else
    set -- "$1" "$2" "$3" "$4" "$?"
    case "$3" in
      INSPECT) echo "vault read exit $5: a missing role or denied inspection; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
      *) echo "with the revoked root token selected the role read is expected to fail; not classified" ;;
    esac
  fi
  case "$3" in
    INSPECT) echo "block exit $4; the socket table, any health code but 200, audit delivery and the role parameters are not classified, so judge them yourself" ;;
    *) echo "block exit $4; with the revoked root token selected only the token lookups decide whether that token is live, and the socket table and any health code but 200 are not classified, so judge them yourself" ;;
  esac
  exit "$4"
)
```

```bash
# Scope of this repeat: wildcard binds, ss as root, HA health and independent audit delivery; the host lacks the capabilities listed below. Repeat these commands for those scenarios using the cited listener, health and audit sources.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_VAULT_HTTPS_URL' \
    'REPLACE_WITH_CA_FILE' \
    'REPLACE_WITH_INSPECT_OR_REVOKED_ROOT'
  # Value 3 is INSPECT as the scoped admin, or REVOKED_ROOT for the repeat with the revoked root token selected.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 3 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 2; not probing"; exit 2 ;;
  esac
  case "$1" in https://*) ;; *) echo "use an HTTPS URL"; exit 2 ;; esac
  [ -r "$2" ] || { echo "CA file is not readable"; exit 2; }
  case "$3" in
    INSPECT|REVOKED_ROOT) ;;
    *) echo "set value 3 to INSPECT as the scoped admin, or REVOKED_ROOT with the revoked root token selected; not probing"; exit 2 ;;
  esac
  unset VAULT_SKIP_VERIFY VAULT_AGENT_ADDR VAULT_NAMESPACE VAULT_WRAP_TTL VAULT_ADDR VAULT_CACERT || exit 2
  export VAULT_ADDR="$1" VAULT_CACERT="$2" || exit 2
  set -- "$1" "$2" "$3" 0   # the 4th value is the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 2 (a refused part, such as a missing ss), which outranks 0
  if command -v ss >/dev/null; then
    if sudo ss -tlnp; then :; else
      echo "sudo ss -tlnp exit $?: no socket table to read; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3
    fi
  else
    echo "ss is not installed here; not listing sockets"
    case "$4" in 0) set -- "$1" "$2" "$3" 2 ;; esac
  fi
  if vault status -format=json; then :; else
    echo "vault status exit $? (2 means sealed, 1 an error): not the initialized, unsealed operating state; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3
  fi
  set -- "$1" "$2" "$3" "$4" "$(if curl -q -g -sS -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
    --cacert "$2" -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1/v1/sys/health"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  printf '%s' "${5% *}"
  case "${5##* }:${5% *}" in
    0:"http=200 "*) ;;
    0:*) echo "unclassified observation: read the health code above against the list below; a healthy response is a connectivity control, not proof of hardening" ;;
    *) echo "curl exit ${5##* }: the health request failed, as a transport or certificate verification failure does; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
  esac
  set -- "$1" "$2" "$3" "$4" "$(if vault audit list -detailed 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"
  printf '%s' "${5% *}"
  case "$3:${5##* }:${5% *}" in
    INSPECT:*:*"No audit devices are enabled."*) echo "FINDING: no audit device is enabled, so requests are served unlogged"; set -- "$1" "$2" "$3" 1 ;;
    INSPECT:0:*) echo "unclassified observation: the devices are listed above; check delivery by correlating a request_id, as described below" ;;
    INSPECT:*) echo "vault audit list exit ${5##* }: a failed or denied inspection; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
    REVOKED_ROOT:0:*) echo "unclassified observation: the audit list succeeded with the revoked root token selected; the token lookups below decide whether that token is live" ;;
    *) echo "with the revoked root token selected the audit list is expected to fail; not classified" ;;
  esac
  # In the two lookups, vault's own output goes straight to you and only its error text is held, so no token enters a value.
  { set -- "$1" "$2" "$3" "$4" "$(if { vault token lookup >&3; } 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"; } 3>&1
  printf '%s' "${5% *}"
  case "$3:${5##* }:${5% *}" in
    INSPECT:0:*) ;;
    INSPECT:*) echo "vault token lookup exit ${5##* }: the scoped admin's lookup, the positive control, failed; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
    REVOKED_ROOT:0:*) echo "FINDING: the revoked root token's lookup succeeded, so that token is still live"; set -- "$1" "$2" "$3" 1 ;;
    REVOKED_ROOT:*:*"permission denied"*|REVOKED_ROOT:*:*"invalid token"*) echo "Vault refused the revoked root token's lookup, the fixed outcome" ;;
    *) echo "vault token lookup exit ${5##* } without a permission-denied or invalid-token error; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
  esac
  { set -- "$1" "$2" "$3" "$4" "$(if { vault token lookup -format=json >&3; } 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"; } 3>&1
  printf '%s' "${5% *}"
  case "$3:${5##* }:${5% *}" in
    INSPECT:0:*) ;;
    INSPECT:*) echo "vault token lookup exit ${5##* }: the scoped admin's lookup, the positive control, failed; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
    REVOKED_ROOT:0:*) echo "FINDING: the revoked root token's lookup succeeded, so that token is still live"; set -- "$1" "$2" "$3" 1 ;;
    REVOKED_ROOT:*:*"permission denied"*|REVOKED_ROOT:*:*"invalid token"*) echo "Vault refused the revoked root token's lookup, the fixed outcome" ;;
    *) echo "vault token lookup exit ${5##* } without a permission-denied or invalid-token error; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
  esac
  if vault read -format=json auth/approle/role/payments; then :; else
    set -- "$1" "$2" "$3" "$4" "$?"
    case "$3" in
      INSPECT) echo "vault read exit $5: a missing role or denied inspection; inconclusive"; [ "$4" = 1 ] || set -- "$1" "$2" "$3" 3 ;;
      *) echo "with the revoked root token selected the role read is expected to fail; not classified" ;;
    esac
  fi
  case "$3" in
    INSPECT) echo "block exit $4; the socket table, any health code but 200, audit delivery and the role parameters are not classified, so judge them yourself" ;;
    *) echo "block exit $4; with the revoked root token selected only the token lookups decide whether that token is live, and the socket table and any health code but 200 are not classified, so judge them yourself" ;;
  esac
  exit "$4"
)
```

REASONED: preceding block; all listener, health, audit, root-token and AppRole inspection commands: require intended private sockets, verified TLS, initialized and unsealed status, delivered audit records, revoked-root lookup denial and the section 7 role bounds; unintended listeners, absent logs, successful revoked-root lookup or missing bounds are findings. The inspection checks follow the guide's cited Vault TCP listener (address defaults, tls_disable, cluster_address); Vault sys/health status codes; Vault status command (JSON output and exit codes); Vault audit devices (fail-closed, HMAC default, exempt endpoints). The inspection checks also follow the guide's cited Vault audit entry schema (request IDs and token-use fields); Vault token lookup command (selected-token lookup and JSON output); Vault token revoke command (self-revocation); Vault AppRole API (role parameters, SecretID generation, and login). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. In this follow-up review, both inspection blocks ran with every external command stubbed: `vault status -format=json` returned 2, while all other stub commands returned 0; the subsequent curl health request, audit list, both token lookups and AppRole read still ran, and each block exited 0. These stub results do not establish live Vault behavior. The bash -n, ShellCheck and stub runs recorded above in this paragraph covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2. Stub runs of an earlier form of both inspection blocks, each pasted whole with every external command stubbed, exited 0 for the fixed `INSPECT` and `REVOKED_ROOT` states, 3 when `sudo ss` failed, 2 when `ss` was missing and every other check passed, 3 when `ss` was missing and a later check failed, and 1 when `ss` was missing and the audit list was empty. They gave the same statuses under an inherited `readonly` variable, an inherited `declare -i` variable and an inherited `set -e`. Like the earlier stub runs, they do not establish live Vault behavior, and no live run of the current form is recorded. In the form those runs covered, the `REVOKED_ROOT` audit-list and closing lines said the token lookups decide this run. On 2026-11-02, the current form of both blocks, each pasted whole into GNU bash 5.3.9 with `sudo`, `ss`, `vault` and `curl` stubbed, exited 0 for the fixed `INSPECT` and `REVOKED_ROOT` states, 3 when `sudo ss` failed, 2 when `ss` was missing and every other check passed, 3 when `ss` was missing and a later check failed, and 1 when `ss` was missing and the audit list was empty. With `REVOKED_ROOT`, those runs printed that the token lookups decide whether that token is live after a successful audit list and in the closing line, also when the stubbed `vault status` failed and the block exited 3, and they do not establish live Vault behavior either. The current form of both blocks, not yet demonstrated, takes `INSPECT` for the scoped admin or `REVOKED_ROOT` for the revoked-root repeat as its third value and exits once: 1 for an empty audit list or a successful revoked-root lookup, 3 for a failed command or positive control with `INSPECT`, 2 when `ss` is missing and no other check found something or was inconclusive, and 0 otherwise. With `REVOKED_ROOT`, each exits with 3 only for a failed `ss`, `vault status` or health request or a lookup that fails without the expected error. Each block checks for `ss` before running `sudo ss -tlnp`. Where sudoers sets `secure_path`, sudo looks `ss` up in that path instead of your PATH, so the `command -v ss` check can refuse although sudo would find `ss`, or pass and then end with status 3 when sudo cannot run it and no check found something, per the guide's cited sudo sudoers manual, secure_path entry. When `ss` is missing, the closing line still names the socket table, though none was printed. The socket table, health codes other than `200`, audit delivery and the role bounds stay for you to judge, as the items below describe:

- REASONED: bind and TLS comparison: unintended listeners are findings; intended private binds with verified TLS and matched firewall controls are required. The parenthetical host limitations below describe the historical run. Per the guide's cited Vault TCP listener (address defaults, tls_disable, cluster_address); Vault production hardening (root token, swap, core dumps). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2. Stub runs of the current form of the two inspection blocks are recorded in the paragraph after those blocks; they do not establish live Vault behavior, and no live run of the current form is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. **Bind and TLS (demonstrated, TLS in both states; a wildcard bind, `ss` as root and the firewall
  REASONED: the host forbids binding every interface, has no `sudo`, and has no second network):** read the whole socket table. Confirm `8200` is bound to the intended
  private address and `8201` to the cluster address, with nothing unexpected. A wildcard or unintended
  listener is a finding. The TLS health request must reach the intended server with certificate
  verification enabled. `ss` shows the bind, not the firewall; "only between nodes" is a firewall
  property. Confirm it with firewall rules and the permitted/forbidden-source probes below.
  See the [listener reference](https://developer.hashicorp.com/vault/docs/configuration/listener/tcp).
- REASONED: status and health interpretation: initialized and unsealed is the intended operating state; sealed, uninitialized and standby responses must be distinguished as specified here, without treating health as proof of hardening. Per the guide's cited Vault status command (JSON output and exit codes); Vault sys/health status codes. Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2. Stub runs of the current form of the two inspection blocks are recorded in the paragraph after those blocks; they do not establish live Vault behavior, and no live run of the current form is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. The demonstrated label below records the historical loopback run, not this review. **Server state (demonstrated for `501`, `503` and `200`; the standby and removed-node codes
  REASONED, since no multi-node cluster was set up):** status should report `initialized: true` and `sealed: false`.
  Status exit code `2` means sealed; an unsealed standby returns `0`; `1` means an error.
  Health codes `200` active, `429` standby, `501` uninitialized, and `503` sealed are common
  examples, not an exhaustive list. Current documentation also includes `474` for an unhealthy
  standby unable to reach the active node and `530` for a removed node. Codes `472` and `473`
  concern Enterprise disaster-recovery and performance-standby roles. Query parameters can change
  returned codes. A healthy response is a connectivity control, not proof of hardening.
  See [status](https://developer.hashicorp.com/vault/docs/commands/status) and the
  [health API](https://developer.hashicorp.com/vault/api-docs/system/health).
- REASONED: audit configuration and delivery: no devices or missing delivery is a finding; require the matching request ID at both independent destinations. The parenthetical host limitation below describes the historical run. Per the guide's cited Vault audit devices (fail-closed, HMAC default, exempt endpoints); Vault audit list command; Vault audit entry schema (request IDs and token-use fields). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2. Stub runs of the current form of the two inspection blocks are recorded in the paragraph after those blocks; they do not establish live Vault behavior, and no live run of the current form is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. **Audit configuration and delivery (demonstrated for an empty list and for one and two file devices; a
  second device in a separate failure domain REASONED, since the host has no second network):** an empty audit list means requests are served
  unlogged. The fixed configuration lists the intended independent devices. Correlate the successful
  non-root JSON token lookup's `request_id` with `request.id` in the collected audit entries;
  the default table output omits the request ID. Check delivery to both destinations while both are
  healthy and retain both streams, since either can have gaps during an outage. A listed device
  without delivered records is not a successful delivery check. Do not use health requests for
  correlation because they are exempt from auditing.
  See [audit availability and exemptions](https://developer.hashicorp.com/vault/docs/audit),
  [audit listing](https://developer.hashicorp.com/vault/docs/commands/audit/list), and the
  [audit schema](https://developer.hashicorp.com/vault/docs/audit/schema).
- REASONED: root revocation: a revoked root lookup must fail while an independently authenticated scoped admin succeeds; successful root lookup is the exposed outcome. Per the guide's cited Vault token lookup command (selected-token lookup and JSON output); Vault token revoke command (self-revocation); Vault token concepts (token prefixes, parent and child revocation, root tokens, TTLs, service and batch behavior). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2. Stub runs of the current form of the two inspection blocks are recorded in the paragraph after those blocks; they do not establish live Vault behavior, and no live run of the current form is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. The demonstrated label below records the historical loopback run, not this review. **Root revocation (demonstrated):** the scoped-admin token lookup is the positive control. Log that
  admin in through an auth method: a non-orphan token made with `vault token create` while the root
  token is selected is the root token's child and is revoked with it.
  Repeat the guarded block with the revoked initial root credential still selected and `REVOKED_ROOT`
  as its third value, and judge its token-lookup results: Vault must return permission-denied or
  invalid-token errors. Other authenticated commands in that repeat will also fail. A successful
  root-token lookup is the exposed state, and the block then exits with status 1. This proves that
  one token is dead, not that no root token exists; do not retain or generate a live root credential
  for testing.
  See [token lookup](https://developer.hashicorp.com/vault/docs/commands/token/lookup) and
  [self-revocation](https://developer.hashicorp.com/vault/docs/commands/token/revoke).
- REASONED: AppRole inspection: require every section 7 bound; absent limits or broader policies are findings, while denied inspection is inconclusive. Per the guide's cited Vault AppRole API (role parameters, SecretID generation, and login). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2. Stub runs of the current form of the two inspection blocks are recorded in the paragraph after those blocks; they do not establish live Vault behavior, and no live run of the current form is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. The demonstrated label below records the historical loopback run, not this review. **AppRole configuration (demonstrated):** compare the role read with every parameter in section 7,
  including both CIDR restrictions, SecretID TTL/use limits, service-token type, token TTL/max TTL/
  explicit max TTL, zero period, use limit, and exclusion of the default policy. Durations may be
  returned in seconds. A missing role or denied inspection is inconclusive; zero use limits,
  missing bounds, or broader attached policies do not satisfy this example. This read establishes
  configuration, not runtime enforcement.
  See the [AppRole role API](https://developer.hashicorp.com/vault/api-docs/auth/approle).

DEMONSTRATED: the loopback runs recorded in this section's introduction.
On the loopback run, `ss` showed only `127.0.0.1:8200` and `127.0.0.1:8201` for the Vault process.
Health returned `501` before initialization, `503` while sealed (status exit code `2`) and `200` once
unsealed (exit code `0`); a plaintext request got `400` "Client sent an HTTP request to an HTTPS
server", and a request without the CA failed certificate verification. The audit list showed the file
device, and the JSON token lookup's `request_id` matched two audit entries, the request and its
response. The role read returned every section 7 value, with durations in seconds. After `vault token
revoke -self`, the block with the revoked root token selected got `403` `invalid token` for the audit
list, both token lookups and the role read. A scoped admin created as a child of the root token lost
access with it, while an orphan token and a userpass login kept working. In the exposed states, before
any audit device was enabled the audit list printed `No audit devices are enabled.`, and before
revocation the root token's lookup succeeded with policy `root` and `ttl` `0s`. With `tls_disable =
true` on the listener, a plaintext health request was answered (`501`, uninitialized) and an HTTPS
request failed. A `payments` role written without limits or bounds read back with
`secret_id_num_uses` `0`, `secret_id_ttl` `0`, no CIDRs, `token_num_uses` `0` and zero TTLs. In a
follow-up run, the health request printed `http=200 exit=0 err=` on the healthy node and `http=000
exit=7 err=Failed to connect ...` with the server stopped; with two file audit devices, one request's
`request_id` appeared twice in each file. The same follow-up run had a second listener stanza on
127.0.0.2:8200, and the socket table also showed `127.0.0.2:8200` and `127.0.0.2:8201`, an
unintended listener with its own cluster port, because `cluster_address` defaults to one port above
`address`. The runs of the first block recorded here used an earlier form of it; the gate suite's
bash -n and ShellCheck 0.11.0 passes and the stub runs recorded after the two inspection blocks
cover its current form, which checks for `ss` before running it.

REASONED: header-file preparation for the ACL and monitoring comparisons: use the intended identity's actual header; the paired requests must distinguish authorized success from anonymous or cross-application denial. Stub arguments contained the header-file path, not its dummy token. Per the guide's cited curl options (write-out fields require 7.75.0; header files, TLS verification, direct connections, and write-out fields); Vault KV v2 API (data paths and read operations); Vault metrics API (GET, JSON format, and root namespace); Vault profiling API (index path and root namespace). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. The demonstrated label below records the historical loopback run, not this review. **Application ACLs and authenticated monitoring (demonstrated on loopback):** for API authentication, provision an
owner-readable header file containing the selected identity's `X-Vault-Token` header through a
protected mechanism. The file must contain the actual header, not a shell variable reference.
Use only the intended authentication header, and remove the file when finished.

REASONED: from curl's header-file input in the manual page cited in Sources, not from the loopback
runs, which did not observe it. In the two blocks below, of the credential, only the header file's path enters curl's
argv, through `--header "@$3"`; curl reads the `X-Vault-Token` header from the file. The blocks
never type the token or expand a variable holding it, so neither shell history nor `set -x` tracing
records it from the blocks, provided the file is prepared through protected delivery rather than by
a shell command that contains the token. A header file closes the argv channel only: the account
owner and root can still read the file and the memory of each curl process while it runs.

Run this block for each full endpoint URL and identity described below. It reports an anonymous
request followed by the same request with the selected credential; response bodies are discarded
to avoid printing secrets or profiles.

```bash
# DEMONSTRATED: loopback ACL and active-node monitoring pairs recorded below. The loopback runs used an earlier form of the block, whose guard refusals exited with status 1, which took three values and which ended with the authenticated request's curl status; the current form, which takes EXPECT_200 or EXPECT_403 as a fourth value and classifies both requests, has not been demonstrated.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_FULL_HTTPS_API_URL' \
    'REPLACE_WITH_CA_FILE' \
    'REPLACE_WITH_TOKEN_HEADER_FILE' \
    'REPLACE_WITH_EXPECT_200_OR_EXPECT_403'
  # Value 4 is EXPECT_200 or EXPECT_403, the authenticated outcome the table row below expects for this identity.
  # Take it from the row's fixed outcome for the selected identity. These expectations follow that table and
  # the guide's cited Vault policies and tokens, not the loopback runs, which used an earlier form of this block.
  # With EXPECT_200, a 2xx is the pass and any other answer gives status 3, a failed control. With EXPECT_403,
  # 403 is the pass, a 2xx is a finding with status 1 and any other answer gives 3. Where a row pairs a 403
  # with another identity's 200, run the block for each.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "the set -- line needs exactly 4 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 2; not probing"; exit 2 ;;
  esac
  case "$3" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 3; not probing"; exit 2 ;;
  esac
  case "$1" in https://*) ;; *) echo "use an HTTPS URL"; exit 2 ;; esac
  [ -r "$2" ] || { echo "CA file is not readable"; exit 2; }
  [ -r "$3" ] || { echo "header file is not readable"; exit 2; }
  case "$4" in
    EXPECT_200|EXPECT_403) ;;
    *) echo "set value 4 to EXPECT_200 or EXPECT_403, the authenticated outcome the table row below expects for this identity; not probing"; exit 2 ;;
  esac
  set -- "$1" "$2" "$3" "$4" "$(if curl -q -g -sS -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
    --cacert "$2" -w 'anonymous http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  printf '%s' "${5% *}"
  # Status: 1 for an anonymous 2xx; 3 for any other anonymous answer but 403, or a failed request; otherwise 0.
  case "${5##* }:${5% *}" in
    0:"anonymous http=403 "*) set -- "$1" "$2" "$3" "$4" 0 ;;
    0:"anonymous http=2"??" "*) echo "FINDING: the anonymous request got an HTTP 2xx, so the endpoint answers without a token"; set -- "$1" "$2" "$3" "$4" 1 ;;
    0:*) echo "the anonymous request got neither 403 nor a 2xx, and a 404, redirect or standby answer is not an ACL result; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
    *) echo "curl exit ${5##* }: the anonymous request failed; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
  esac
  # Only the header file's path enters curl's argv; the response body is discarded, so the held write-out line holds no token.
  set -- "$1" "$2" "$3" "$4" "$5" "$(if curl -q -g -sS -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
    --cacert "$2" --header "@$3" \
    -w 'authenticated http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  printf '%s' "${6% *}"
  # Status: with EXPECT_200, 3 unless the authenticated request got a 2xx (a failed control); with EXPECT_403,
  # 1 for a 2xx and 3 for any other answer but 403, or a failed request. A finding outranks 3.
  case "$4:${6##* }:${6% *}" in
    EXPECT_200:0:"authenticated http=2"??" "*|EXPECT_403:0:"authenticated http=403 "*) ;;
    EXPECT_403:0:"authenticated http=2"??" "*) echo "FINDING: the authenticated request got an HTTP 2xx where the table row expects 403, so this identity reaches the path"; set -- "$1" "$2" "$3" "$4" 1 ;;
    EXPECT_200:0:*) echo "the authenticated request did not get the 2xx the table row expects, so this positive control failed; inconclusive"; [ "$5" = 1 ] || set -- "$1" "$2" "$3" "$4" 3 ;;
    EXPECT_403:0:*) echo "the authenticated request got neither 403 nor a 2xx, and a 404, redirect or standby answer is not an ACL result; inconclusive"; [ "$5" = 1 ] || set -- "$1" "$2" "$3" "$4" 3 ;;
    *) echo "curl exit ${6##* }: the authenticated request failed; inconclusive"; [ "$5" = 1 ] || set -- "$1" "$2" "$3" "$4" 3 ;;
  esac
  echo "block exit $5; where the table row below pairs a 403 with another identity's 200, repeat this block for that identity with EXPECT_200"
  exit "$5"
)
```

```bash
# REASONED: HA standby monitoring; no multi-node cluster was set up. Repeat these requests against the node roles described below; the cited handler sources distinguish the outcomes. Stub runs on 2026-11-02 in GNU bash 5.3.9, the block pasted whole with `curl` stubbed, covered this form: with `EXPECT_200` and an anonymous `403`, an authenticated `307` or `400` printed the line to repeat this block on the active node and exited 3, and an authenticated `200` exited 0. They do not establish live Vault behavior.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_FULL_HTTPS_API_URL' \
    'REPLACE_WITH_CA_FILE' \
    'REPLACE_WITH_TOKEN_HEADER_FILE' \
    'REPLACE_WITH_EXPECT_200_OR_EXPECT_403'
  # Value 4 is EXPECT_200 or EXPECT_403, the authenticated outcome the table row below expects for this identity.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "the set -- line needs exactly 4 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 2; not probing"; exit 2 ;;
  esac
  case "$3" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 3; not probing"; exit 2 ;;
  esac
  case "$1" in https://*) ;; *) echo "use an HTTPS URL"; exit 2 ;; esac
  [ -r "$2" ] || { echo "CA file is not readable"; exit 2; }
  [ -r "$3" ] || { echo "header file is not readable"; exit 2; }
  case "$4" in
    EXPECT_200|EXPECT_403) ;;
    *) echo "set value 4 to EXPECT_200 or EXPECT_403, the authenticated outcome the table row below expects for this identity; not probing"; exit 2 ;;
  esac
  set -- "$1" "$2" "$3" "$4" "$(if curl -q -g -sS -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
    --cacert "$2" -w 'anonymous http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  printf '%s' "${5% *}"
  # Status: 1 for an anonymous 2xx; 3 for any other anonymous answer but 403, or a failed request; otherwise 0.
  case "${5##* }:${5% *}" in
    0:"anonymous http=403 "*) set -- "$1" "$2" "$3" "$4" 0 ;;
    0:"anonymous http=2"??" "*) echo "FINDING: the anonymous request got an HTTP 2xx, so the endpoint answers without a token"; set -- "$1" "$2" "$3" "$4" 1 ;;
    0:*) echo "the anonymous request got neither 403 nor a 2xx, and a 404, redirect or standby answer is not an ACL result; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
    *) echo "curl exit ${5##* }: the anonymous request failed; inconclusive"; set -- "$1" "$2" "$3" "$4" 3 ;;
  esac
  # Only the header file's path enters curl's argv; the response body is discarded, so the held write-out line holds no token.
  set -- "$1" "$2" "$3" "$4" "$5" "$(if curl -q -g -sS -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
    --cacert "$2" --header "@$3" \
    -w 'authenticated http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$1"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  printf '%s' "${6% *}"
  # Status: with EXPECT_200, 3 unless the authenticated request got a 2xx (a failed control, or a standby's answer to repeat on the active node); with EXPECT_403,
  # 1 for a 2xx and 3 for any other answer but 403, or a failed request. A finding outranks 3.
  case "$4:${6##* }:${6% *}" in
    EXPECT_200:0:"authenticated http=2"??" "*|EXPECT_403:0:"authenticated http=403 "*) ;;
    EXPECT_403:0:"authenticated http=2"??" "*) echo "FINDING: the authenticated request got an HTTP 2xx where the table row expects 403, so this identity reaches the path"; set -- "$1" "$2" "$3" "$4" 1 ;;
    EXPECT_200:0:*) echo "the authenticated request did not get the 2xx the table row expects; a standby's 307 redirect or local-only 400 is not an authentication result, so for either, repeat this block on the active node; any other answer means this positive control failed; inconclusive"; [ "$5" = 1 ] || set -- "$1" "$2" "$3" "$4" 3 ;;
    EXPECT_403:0:*) echo "the authenticated request got neither 403 nor a 2xx, and a 404, redirect or standby answer is not an ACL result; inconclusive"; [ "$5" = 1 ] || set -- "$1" "$2" "$3" "$4" 3 ;;
    *) echo "curl exit ${6##* }: the authenticated request failed; inconclusive"; [ "$5" = 1 ] || set -- "$1" "$2" "$3" "$4" 3 ;;
  esac
  echo "block exit $5; where the table row below pairs a 403 with another identity's 200, repeat this block for that identity with EXPECT_200"
  exit "$5"
)
```

| Check | Request and identity | Fixed outcome and matched positive control | Exposed outcome |
| --- | --- | --- | --- |
| REASONED: own-secret positive control: expect authenticated 200 for the existing fixture; failure makes the cross-application comparison inconclusive. Per the guide's cited Vault KV v2 API (data paths and read operations); Vault policies and tokens. Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Application's own secret | `GET /v1/kv/data/payments/config`, payments application token | Authenticated `200` for an existing, readable test fixture | Failure makes the cross-application denial inconclusive |
| REASONED: cross-application denial: expect application 403 and fixture-reader 200 for the same path; application 200 is exposed. Per the guide's cited Vault KV v2 API (data paths and read operations); Vault policies and tokens. Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Another application's secret | `GET /v1/kv/data/inventory/config`, payments application token | Application receives `403`; repeat the same URL with a fixture-reader identity authorized for that existing path and require `200` | Application receives `200` |
| REASONED: active-node metrics: expect anonymous 403 and collector 200; anonymous 200 is exposed. Per the guide's cited Vault TCP listener (address defaults, tls_disable, cluster_address); Vault metrics API (GET, JSON format, and root namespace). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Metrics | `GET /v1/sys/metrics`, metrics collector token, directly on the active node | Anonymous `403`, collector `200`, on each API listener of the active node | Anonymous `200` |
| REASONED: active-node profiling: expect anonymous 403 and authorized operator 200; anonymous 200 is exposed. Per the guide's cited Vault TCP listener (address defaults, tls_disable, cluster_address); Vault profiling API (index path and root namespace). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Profiling | `GET /v1/sys/pprof/`, separate operator with `read` on `sys/pprof/*`, directly on the active node | Anonymous `403`, authorized operator `200`, on each API listener of the active node | Anonymous `200` |
| REASONED: collector isolation: expect collector 403 and payments application 200 on the same fixture; collector 200 is exposed. Per the guide's cited Vault KV v2 API (data paths and read operations); Vault policies and tokens. Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Collector isolation | `GET /v1/kv/data/payments/config`, metrics collector token | Collector receives `403`; payments application receives `200` for the same existing fixture | Collector receives `200` |

REASONED: fixture and active-node controls: require the authorized 200 control before counting a 403 denial; a 404 or standby selection is inconclusive. Per the guide's cited Vault KV v2 API (data paths and read operations); Vault metrics API (GET, JSON format, and root namespace); Vault profiling API (index path and root namespace). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Use non-sensitive fixtures in an isolated test deployment. A `404` is not proof of an ACL denial.
For metrics, use the default JSON representation so the positive control does not depend on enabling
Prometheus output. For both monitoring checks, target the active node directly, or the sole server
in a single-node deployment. Confirm its role with the guarded status/health check above before
running the paired requests. Do not use a load balancer that can select a standby.

On the loopback run, every row gave its fixed outcome: anonymous `403` throughout; the payments token
`200` on its own secret and `403` on the inventory secret, where the fixture reader got `200`; the
collector `200` on `sys/metrics` and `403` on `sys/pprof/` and on the payments secret; the profiling
operator `200` on `sys/pprof/`. With the listener's two anonymous-access settings set to `true`,
anonymous requests got `200` on `sys/metrics` and `sys/pprof/`, and a token with a broad `kv/data/*`
read policy got `200` on the inventory secret: the exposed outcomes. In the run with the section 3
configuration and its anonymous-access settings left `false`, a collector whose policy added
`kv/data/*` got `200` on the payments secret, the collector-isolation exposed outcome.

REASONED: HA monitoring: expect an ordinary standby's 307 redirect or the documented local-only forwarding rejection, neither an authentication pass; repeat on the active node for anonymous 403 and authorized 200. No multi-node environment was available. Per the guide's cited Vault HA redirect implementation (pinned v2.2.1); Vault local-only forwarding implementation (pinned v2.2.1); Vault metrics API (GET, JSON format, and root namespace); Vault profiling API (index path and root namespace). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture or live run of it is recorded, while the HA standby block's leading comment records its stub runs. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. **REASONED (no multi-node cluster was set up for these runs):** authenticated metrics and profiling use local-only HTTP handlers. An ordinary HA standby returns
`307` to the active node's advertised API address when a leader is available; that redirect is not
an authentication result. Performance standbys can serve local requests, but the local-only handler
rejects requests that require forwarding with `400` in the inspected implementation. Do not follow
redirects with the token or count redirects, forwarding errors, or missing positive controls as
passes; reconfirm the active node and repeat the pair. See the
[HTTP route and standby redirect implementation](https://raw.githubusercontent.com/hashicorp/vault/v2.2.1/http/handler.go)
and [local-only forwarding handling](https://raw.githubusercontent.com/hashicorp/vault/v2.2.1/http/logical.go).
Keep both anonymous-access settings disabled on every node's API listeners. Inspect each listener's
configuration and repeat the paired checks on each node when it is active during an authorized HA
test; a pair on the current active node does not verify other nodes' listener settings.

REASONED: separate profiling authorization: collector credentials do not establish a profiling control; require the profiling operator's 200 against anonymous 403, with anonymous 200 the exposed state. Per the guide's cited Vault policies and tokens; Vault profiling API (index path and root namespace); Vault metrics API (GET, JSON format, and root namespace); Vault KV v2 API (data paths and read operations); Vault TCP listener (address defaults, tls_disable, cluster_address). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. A collector's metrics-only policy is not a positive control for profiling; use the separately
authorized operator. HashiCorp's [debug permissions](https://developer.hashicorp.com/vault/docs/commands/debug#permissions)
grant `read` on `sys/pprof/*`, covering the trailing-slash index and profiling subpaths without
`sudo`. Leave the collector's policy unchanged. These checks follow the
[KV v2 API](https://developer.hashicorp.com/vault/api-docs/secret/kv/kv-v2),
[ACL capabilities](https://developer.hashicorp.com/vault/docs/concepts/policies#capabilities),
[listener authentication settings](https://developer.hashicorp.com/vault/docs/configuration/listener/tcp#telemetry-parameters),
[metrics API](https://developer.hashicorp.com/vault/api-docs/system/metrics), and
[profiling API](https://developer.hashicorp.com/vault/api-docs/system/pprof).

REASONED: from the shell behaviour of file input on stdin, not from the loopback runs below, which
did not test it. What was run: on 2026-10-13 UTC a QA review ran the following block under `bash -x`
with its external commands stubbed and a dummy secret as the credential; no trace line carried the
dummy secret, while a positive control that printed the file with a traced builtin `printf` did.
A second run the same day pasted the block into Bash 5.3.9 (`bash --noprofile --norc -i`) on a
pseudo-terminal with history enabled, with a `vault` stub that read stdin and slept four seconds
and the observing and inspected processes under the same account. The second run's history file
held no contents of the JSON request file, and neither `/proc/<pid>/cmdline` (the stub's arguments were
`write -format=json auth/approle/login -`) nor `/proc/<pid>/environ` of the stub and the block's
subshell contained the dummy secret. In that run the observer was an ancestor of the inspected
processes. A third run the same day, on the QA review's evaluation host, repeated the observation
with same-account observers that were siblings of the block's shells rather than ancestors: neither
`/proc/<pid>/cmdline` nor `/proc/<pid>/environ` of any sampled process, including the `vault`
recording stub, the block's subshell and the outer shell, contained the dummy secret. What was not
run: the contents of process memory are unknown, because every attempt by those observers to open
`/proc/<pid>/mem` was refused with EACCES (Permission denied) on the evaluation host, where
`/proc/sys/kernel/yama/ptrace_scope` read `1`. Root was not tested as the observer, because the
evaluation host refused privilege elevation (`sudo -n id` failed because the no-new-privileges flag
was set), and no real `vault` client or live Vault service ran, because `vault` was not on the
evaluation host's PATH. These three runs covered an earlier form of the following block, whose guard
refusals exited with status 1 and which ended with the login's own status; none was re-run on the
current form, which takes `EXPECT_SUCCESS` or `EXPECT_REFUSAL` as a fourth value and classifies the
login, and which holds only `vault`'s error text in a value. The following login request takes
`role_id` and `secret_id` from the request file on
`vault`'s stdin: no credential is typed into the command or held in a shell variable, so neither
shell history nor `set -x` tracing records it, provided the file is prepared through protected
delivery rather than by a shell command that contains the credentials. Stdin closes the argv
channel only: the account owner and root can still read the file and the `vault` process's memory.

**Bounded credentials and tokens (demonstrated on loopback):** prepare an owner-readable
JSON request file containing `role_id` and `secret_id` through protected delivery. The following
login request reads the credentials from stdin, not argv. Its successful output contains a token;
handle it only in a protected session.

```bash
# DEMONSTRATED: loopback AppRole SecretID, CIDR and token-limit runs recorded below. The loopback runs used an earlier form of the block, whose guard refusals exited with status 1, which took three values and which ended with the login's status; the current form, which takes EXPECT_SUCCESS or EXPECT_REFUSAL as a fourth value and classifies the login, has not been demonstrated.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_VAULT_HTTPS_URL' \
    'REPLACE_WITH_CA_FILE' \
    'REPLACE_WITH_LOGIN_JSON_FILE' \
    'REPLACE_WITH_EXPECT_SUCCESS_OR_EXPECT_REFUSAL'
  # Value 4 is EXPECT_SUCCESS for a fresh credential from an allowed source, or EXPECT_REFUSAL for a reused one,
  # one whose SecretID expired more than two minutes ago or a disallowed-source one, as the cases below describe.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "the set -- line needs exactly 4 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 2; not probing"; exit 2 ;;
  esac
  case "$3" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 3; not probing"; exit 2 ;;
  esac
  case "$1" in https://*) ;; *) echo "use an HTTPS URL"; exit 2 ;; esac
  [ -r "$2" ] || { echo "CA file is not readable"; exit 2; }
  case "$4" in
    EXPECT_SUCCESS|EXPECT_REFUSAL) ;;
    *) echo "set value 4 to EXPECT_SUCCESS for a fresh credential from an allowed source, or EXPECT_REFUSAL for a reused one, one whose SecretID expired more than two minutes ago or a disallowed-source one; not probing"; exit 2 ;;
  esac
  unset VAULT_SKIP_VERIFY VAULT_AGENT_ADDR VAULT_NAMESPACE VAULT_WRAP_TTL VAULT_ADDR VAULT_CACERT || exit 2
  export VAULT_ADDR="$1" VAULT_CACERT="$2" || exit 2
  [ -r "$3" ] || { echo "login request file is not readable"; exit 2; }
  # The login's output, which holds a token, goes straight to you; only vault's error text is held as a value.
  { set -- "$4" "$(if { vault write -format=json auth/approle/login - < "$3" >&3; } 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"; } 3>&1
  printf '%s' "${2% *}"
  # Status: with EXPECT_SUCCESS, 0 when the login succeeds and 3 when it fails; with EXPECT_REFUSAL, 1 when it
  # succeeds, 0 for Vault's invalid role or secret ID or CIDR refusal, and 3 for any other failure.
  case "$1:${2##* }:${2% *}" in
    EXPECT_SUCCESS:0:*) echo "the login succeeded; read token_policies, lease_duration and the hvs. token prefix above against the cases below"; exit 0 ;;
    EXPECT_SUCCESS:*) echo "vault write exit ${2##* }: a login expected to succeed failed, so this positive control failed; inconclusive"; exit 3 ;;
    EXPECT_REFUSAL:0:*) echo "FINDING: a login expected to be refused succeeded"; exit 1 ;;
    *:*"invalid role or secret ID"*|*:*"unauthorized by CIDR restrictions"*) echo "Vault refused the login with an authentication error, the fixed outcome while a fresh credential from an allowed source still succeeds"; exit 0 ;;
    *) echo "vault write exit ${2##* } without Vault's invalid role or secret ID or CIDR error, and a network refusal alone demonstrates neither control; inconclusive"; exit 3 ;;
  esac
)
```

Use separate credentials for independent cases so consuming a SecretID or token does not confound
another test:

- REASONED: SecretID single use: require first-login success, reuse rejection and fresh-SecretID success; successful reuse is exposed. Python parsed a dummy role_id/secret_id JSON fixture; no live credentials were used. Per the guide's cited Vault AppRole API (role parameters, SecretID generation, and login); Vault AppRole authentication (setup, token choice, and child-token constraints). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. The demonstrated label below records the historical loopback run, not this review. **SecretID use limit (demonstrated):** a fresh SecretID succeeds once from an allowed source.
  An immediate repeat with the same request file must fail with a Vault authentication error;
  another freshly delivered SecretID must succeed. Successful reuse is the exposed state. On the loopback
  run, the section 7 role refused the reuse with `400`, and a role with `secret_id_num_uses=0` accepted
  the same SecretID twice.
- **SecretID expiry (demonstrated):** leave a separate SecretID unused for more than two minutes
  beyond its ten-minute lifetime, then submit its login request. It must fail while a fresh SecretID succeeds
  from the same source. AppRole deletes expired SecretIDs in a tidy that runs once a minute, and until
  then an expired SecretID still logs in: on the loopback run, SecretIDs 10 seconds past their TTL
  logged in, while one 70 seconds past it was refused with `invalid role or secret ID`. Successful
  login more than two minutes after expiry is the exposed state; the margin allows for a tidy that is
  only nominally once a minute. With a 20-second test TTL, a SecretID tried about 130 seconds past it was
  refused with `invalid role or secret ID`, while one from a role with no `secret_id_ttl` logged in.
- **Source bounds (demonstrated with a second loopback address):** try a fresh SecretID from outside the configured CIDR but within
  a test network that can reach Vault. Require authentication rejection, paired with successful
  login using fresh credentials from the allowed CIDR. Test the resulting token's payments read
  with the guarded GET block from both sources: allowed source `200`, disallowed source `403`.
  Network refusal alone does not demonstrate either CIDR control. On the loopback run, with
  `127.0.0.1/32` as the CIDR, a login sent from 127.0.0.2 (the same JSON request through
  `curl --interface`, because the block's CLI cannot choose its source address) was refused with
  `source address "127.0.0.2" unauthorized by CIDR restrictions on the role`. The same loopback run,
  with `127.0.0.1/32` as the CIDR, showed that a login from 127.0.0.1 succeeded, and its token read
  the payments secret with `200` from 127.0.0.1 and `403` from 127.0.0.2 (that read also went through
  `curl --interface`, not the block). With no CIDR bound on the role, a login from
  127.0.0.2 succeeded with `200`, and a token from a role without `token_bound_cidrs` read the payments
  secret from 127.0.0.2 with `200`.
- **Token lifetime, use budget and renewal ceiling (demonstrated):** the login response
  must show the intended `token_policies` and a `lease_duration` of at most 300 seconds, and its token
  must begin `hvs.`, the service-token prefix (the CLI's JSON output has no token-type field). Using the guarded payments
  GET, require success before expiry and `403` after the issued lease expires, paired with `200`
  using a fresh token. Separately exhaust the 100-request budget before expiry, counting all token
  uses, and require subsequent denial while a fresh token succeeds. Continued access after expiry
  or exhaustion is the exposed state. The role read checks the fifteen-minute explicit ceiling;
  an expiry test without renewal does not independently demonstrate that renewal ceiling.
  Do not use token self-lookup as the application's validity test: this example excludes the
  default policy and does not grant that permission. On the loopback run, the login returned
  `token_policies` `payments-read` and `lease_duration` `300` with an `hvs.` token; a read returned
  `200` before the TTL and `403` ten seconds after it, while a fresh token got `200`; and 100 reads
  returned `200` before read 101 got `403`; with `token_num_uses=0`, all 101 reads returned `200`. With
  short test durations (`token_ttl=10s`, `token_explicit_max_ttl=30s`), a token renewed every 8 seconds
  got `403` on a read at about 43 seconds, after the 30-second ceiling, while the same schedule without
  an explicit ceiling kept a token working. A role with `token_type=batch` issued an `hvb.` token and a
  role with no TTL a `lease_duration` of `2764800`, the exposed halves of the type and lease checks. With `token_ttl=10s`, a read at about 15 seconds got `403`,
  while a token from a role with no token TTL (the default lifetime) got `200`.

REASONED: credential and token discriminators: fresh allowed credentials succeed while reused credentials, SecretIDs past the stated expiry margin or disallowed-source credentials fail; token access must stop at the specified use and lifetime bounds. Python parsed the dummy login JSON fixture. Per the guide's cited Vault AppRole API (role parameters, SecretID generation, and login); Vault AppRole authentication (setup, token choice, and child-token constraints); Vault token concepts (token prefixes, parent and child revocation, root tokens, TTLs, service and batch behavior). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. The discriminators come from the
[AppRole credential and role parameters](https://developer.hashicorp.com/vault/api-docs/auth/approle),
[AppRole constraints](https://developer.hashicorp.com/vault/docs/auth/approle), and
[token lifetime rules](https://developer.hashicorp.com/vault/docs/concepts/tokens).

**Mandatory wrapping (demonstrated on loopback):** select the deployment identity, not an administrator or root token. In an isolated test deployment,
the first two requests below must be rejected for their wrapping settings. Vault's error, `403`
`permission denied`, does not name the setting, so rely on the controls: the sixty-second positive
control and the exposed comparison below. The sixty-second request is the matched
positive control and must return wrapping information. Unexpectedly successful negative requests
are findings; their credential-bearing output is discarded.

```bash
# DEMONSTRATED: loopback mandatory-wrapping negative requests and matched positive control recorded below. The loopback runs used an earlier form of the block, whose guard refusals exited with status 1 and which ended with the positive control's status; the current form, whose guard refusals exit with status 2 and which exits with status 1 after a finding and 3 after a failed positive control, has not been run.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_VAULT_HTTPS_URL' \
    'REPLACE_WITH_CA_FILE'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
    *)
      case "$2" in
        *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 2; not probing"; exit 2 ;;
        *)
          case "$1" in https://*) ;; *) echo "use an HTTPS URL"; exit 2 ;; esac
          [ -r "$2" ] || { echo "CA file is not readable"; exit 2; }
          unset VAULT_SKIP_VERIFY VAULT_AGENT_ADDR VAULT_NAMESPACE VAULT_WRAP_TTL || exit 2
          export VAULT_ADDR="$1" VAULT_CACERT="$2" || exit 2
          if vault write -f auth/approle/role/payments/secret-id > /dev/null; then
            echo "FINDING: unwrapped issuance succeeded"
            set -- "$@" 1   # records the finding; the block exits once, after the positive control
          else
            echo "Refused; this counts only if the sixty-second request below succeeds"
          fi
          if vault write -wrap-ttl=61s -f auth/approle/role/payments/secret-id > /dev/null; then
            echo "FINDING: issuance above the wrapping TTL ceiling succeeded"
            set -- "$@" 1
          else
            echo "Refused; this counts only if the sixty-second request below succeeds"
          fi
          vault write -wrap-ttl=60s -f auth/approle/role/payments/secret-id || set -- "$@" 3
          # Status: 1 for any finding; otherwise 3 if the positive control failed; otherwise 0.
          case "${3-}${4-}${5-}" in *1*) exit 1 ;; *3*) exit 3 ;; esac
          ;;
      esac
      ;;
  esac
)
```

Without the policy restrictions, otherwise authorized issuance can succeed without wrapping or
with a longer wrapping TTL. That is the exposed comparison. A failure of the sixty-second positive
control leaves the result inconclusive. On the loopback run, both negative requests were refused
with `403` `permission denied`, which does not name the wrapping setting, so the positive control is
what separates a wrapping refusal from a missing permission; the sixty-second request returned
`wrapping_token_ttl` `1m` and `wrapping_token_creation_path` `auth/approle/role/payments/secret-id`. With a delivery policy that sets
neither wrapping TTL, the same kind of identity's unwrapped request returned the SecretID fields and a
sixty-one-second request succeeded: the exposed comparison. In the follow-up run, the block printed
`Refused; this counts only if the sixty-second request below succeeds` for each refusal in the fixed
state, and both `FINDING` lines in the exposed state.
See [required wrapping TTLs](https://developer.hashicorp.com/vault/docs/concepts/policies#required-response-wrapping-ttls)
and [wrapping requests](https://developer.hashicorp.com/vault/docs/concepts/response-wrapping).

REASONED: from the shell behaviour of file input on stdin, not from the loopback lookup runs,
which did not test it. What was run: on 2026-10-13 UTC a QA review ran both wrapping-lookup blocks
below under `bash -x` with their external commands stubbed and a dummy secret as the token; no
trace line carried the dummy secret, while a positive control that printed the file with a traced
builtin `printf` did. A second run the same day pasted both blocks into Bash 5.3.9
(`bash --noprofile --norc -i`) on a pseudo-terminal with history enabled, with a `vault` stub that
read stdin and slept four seconds, the dummy token placed in the shell's initial environment as
`VAULT_TOKEN`, and the observing and inspected processes under the same account. The second run's
history file held no token value and `/proc/<pid>/cmdline` did not contain it, but
`/proc/<pid>/environ` of both the stub and the block's subshell contained `VAULT_TOKEN` set to the
dummy token. In that run the observer was an ancestor of the inspected processes. A third run the
same day, on the QA review's evaluation host, repeated the observation with same-account observers
that were siblings of the block's shells rather than ancestors. The third run found that
`/proc/<pid>/cmdline` of no sampled process contained the dummy token, but `/proc/<pid>/environ` of
the `vault` recording stub, the block's subshell and the outer shell, which held `VAULT_TOKEN` in
its initial environment, all contained it. What was not run: the contents of process memory are
unknown, because every attempt by those observers to open `/proc/<pid>/mem` was refused with EACCES
(Permission denied) on the evaluation host, where `/proc/sys/kernel/yama/ptrace_scope` read `1`.
Root was not tested as the observer, because the evaluation host refused privilege elevation
(`sudo -n id` failed because the no-new-privileges flag was set), and no real `vault` client or
live Vault service ran, because `vault` was not on the evaluation host's PATH. These three runs
covered an earlier form of both wrapping-lookup blocks, whose guard refusals exited with status 1
and which ended with the lookup's own status; none was re-run on the current form, which takes
`FRESH` or `SPENT` as a fourth value and classifies the lookup, and which holds only `vault`'s error
text in a value. The reasoning from the shell behaviour of file input on stdin applies to both
wrapping-lookup blocks below, the demonstrated lookup and the recipient-validation lookup. Each
passes the protected lookup request, wrapping token included, to `vault` from a file on its stdin.
Neither block types the token or expands a variable holding it, so neither shell history nor `set -x`
tracing records it from the block, provided the file is prepared through protected delivery rather
than by a shell command that contains the token. Stdin closes the argv channel only: the account
owner and root can still read the file and the `vault` process's memory. The token, where
`VAULT_TOKEN` holds the same token, as the next paragraph asks, is also in the environment of every
program the shell starts while `VAULT_TOKEN` is exported, including `vault`, readable through
`/proc/<pid>/environ` by the same account and root while each runs. Where the shell received
`VAULT_TOKEN` in its initial environment, as in the runs above, that file also shows it for the shell
itself and the block's subshell; a shell that sets `VAULT_TOKEN` only after it starts was not tested.

**Recipient validation (the lookup demonstrated; the recipient's own check REASONED, since it
belongs to the receiving application):** prepare the
protected JSON lookup request described in section 7, and select the received
wrapping token through securely injected `VAULT_TOKEN`. Lookup must succeed before unwrapping:

```bash
# DEMONSTRATED: loopback wrapping lookup before expiry and after consumption or expiry, recorded below. The loopback runs used an earlier form of the block, whose guard refusals exited with status 1, which took three values and which ended with the lookup's status; the current form, which takes FRESH or SPENT as a fourth value and classifies the lookup, has not been demonstrated.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_VAULT_HTTPS_URL' \
    'REPLACE_WITH_CA_FILE' \
    'REPLACE_WITH_WRAPPING_LOOKUP_JSON_FILE' \
    'REPLACE_WITH_FRESH_OR_SPENT'
  # Value 4 is FRESH for a token not yet unwrapped and unexpired, or SPENT for a consumed or expired one.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "the set -- line needs exactly 4 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 2; not probing"; exit 2 ;;
  esac
  case "$3" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 3; not probing"; exit 2 ;;
  esac
  case "$1" in https://*) ;; *) echo "use an HTTPS URL"; exit 2 ;; esac
  [ -r "$2" ] || { echo "CA file is not readable"; exit 2; }
  case "$4" in
    FRESH|SPENT) ;;
    *) echo "set value 4 to FRESH for a token not yet unwrapped and unexpired, or SPENT for a consumed or expired one; not probing"; exit 2 ;;
  esac
  unset VAULT_SKIP_VERIFY VAULT_AGENT_ADDR VAULT_NAMESPACE VAULT_WRAP_TTL VAULT_ADDR VAULT_CACERT || exit 2
  export VAULT_ADDR="$1" VAULT_CACERT="$2" || exit 2
  [ -r "$3" ] || { echo "lookup request file is not readable"; exit 2; }
  # The lookup's output goes straight to you; only vault's error text is held as a value.
  { set -- "$4" "$(if { vault write -format=json sys/wrapping/lookup - < "$3" >&3; } 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"; } 3>&1
  printf '%s' "${2% *}"
  # Status: with FRESH, 0 when the lookup succeeds, its fields left for you to judge, and 3 when it fails; with
  # SPENT, 1 when the lookup succeeds, 0 for Vault's not-valid wrapping-token error, and 3 for any other failure.
  case "$1:${2##* }:${2% *}" in
    FRESH:0:*) echo "the lookup succeeded; read creation_path, creation_ttl and creation_time above against the requirements below"; exit 0 ;;
    FRESH:*) echo "vault write exit ${2##* }: the lookup of a fresh token, the positive control, failed; inconclusive"; exit 3 ;;
    SPENT:0:*) echo "FINDING: a consumed or expired wrapping token still passed lookup"; exit 1 ;;
    *:*"wrapping token is not valid or does not exist"*) echo "Vault refused the consumed or expired token, the fixed outcome while a fresh token from the same delivery path passes"; exit 0 ;;
    *) echo "vault write exit ${2##* } without Vault's not-valid wrapping-token error; inconclusive"; exit 3 ;;
  esac
)
```

```bash
# REASONED: recipient validation belongs to the receiving application. Use this lookup with the unexpected-path scenario below; the cited recipient-validation source defines the required rejection.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_VAULT_HTTPS_URL' \
    'REPLACE_WITH_CA_FILE' \
    'REPLACE_WITH_WRAPPING_LOOKUP_JSON_FILE' \
    'REPLACE_WITH_FRESH_OR_SPENT'
  # Value 4 is FRESH for a token not yet unwrapped and unexpired, or SPENT for a consumed or expired one.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "the set -- line needs exactly 4 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 2; not probing"; exit 2 ;;
  esac
  case "$3" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 3; not probing"; exit 2 ;;
  esac
  case "$1" in https://*) ;; *) echo "use an HTTPS URL"; exit 2 ;; esac
  [ -r "$2" ] || { echo "CA file is not readable"; exit 2; }
  case "$4" in
    FRESH|SPENT) ;;
    *) echo "set value 4 to FRESH for a token not yet unwrapped and unexpired, or SPENT for a consumed or expired one; not probing"; exit 2 ;;
  esac
  unset VAULT_SKIP_VERIFY VAULT_AGENT_ADDR VAULT_NAMESPACE VAULT_WRAP_TTL VAULT_ADDR VAULT_CACERT || exit 2
  export VAULT_ADDR="$1" VAULT_CACERT="$2" || exit 2
  [ -r "$3" ] || { echo "lookup request file is not readable"; exit 2; }
  # The lookup's output goes straight to you; only vault's error text is held as a value.
  { set -- "$4" "$(if { vault write -format=json sys/wrapping/lookup - < "$3" >&3; } 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"; } 3>&1
  printf '%s' "${2% *}"
  # Status: with FRESH, 0 when the lookup succeeds, its fields left for you to judge, and 3 when it fails; with
  # SPENT, 1 when the lookup succeeds, 0 for Vault's not-valid wrapping-token error, and 3 for any other failure.
  case "$1:${2##* }:${2% *}" in
    FRESH:0:*) echo "the lookup succeeded; read creation_path, creation_ttl and creation_time above against the requirements below"; exit 0 ;;
    FRESH:*) echo "vault write exit ${2##* }: the lookup of a fresh token, the positive control, failed; inconclusive"; exit 3 ;;
    SPENT:0:*) echo "FINDING: a consumed or expired wrapping token still passed lookup"; exit 1 ;;
    *:*"wrapping token is not valid or does not exist"*) echo "Vault refused the consumed or expired token, the fixed outcome while a fresh token from the same delivery path passes"; exit 0 ;;
    *) echo "vault write exit ${2##* } without Vault's not-valid wrapping-token error; inconclusive"; exit 3 ;;
  esac
)
```

Require the exact creation path, an original TTL from one through sixty seconds, and an unexpired
creation time plus TTL. An expired or consumed token must fail lookup; a fresh token from the same
delivery path is the positive control. In an isolated recipient test, a valid wrapping token from
an unexpected creation path must be rejected by the recipient before unwrapping; accepting it
is a recipient-validation finding even though Vault itself recognizes the token. On the loopback run,
the lookup returned `creation_path` `auth/approle/role/payments/secret-id`, `creation_ttl` `60` and the
creation time, and a lookup of the consumed token failed with `wrapping token is not valid or does
not exist`. A wrapping token looked up three seconds after its two-second TTL failed the same way.
See [wrapping lookup fields](https://developer.hashicorp.com/vault/api-docs/system/wrapping-lookup)
and [recipient validation](https://developer.hashicorp.com/vault/docs/concepts/response-wrapping).

REASONED: from the environment behaviour recorded above for the wrapping-lookup blocks, not from
the loopback unwrap runs, which did not observe it. The single-use unwrap block below takes the
wrapping token from `VAULT_TOKEN`, not from its arguments or a file: the block never types the
token or expands a variable holding it, so neither shell history nor `set -x` tracing records it
from the block. That closes the argv channel only. While `VAULT_TOKEN` is exported, the token is in
the environment of every program the shell starts, including `vault`, readable through
`/proc/<pid>/environ` by the same account and root while each runs; where the shell received
`VAULT_TOKEN` in its initial environment, that file also shows it for the shell itself and the
block's subshell. A wrapping token read there before the first unwrap can be unwrapped by its
reader, so a first unwrap that fails is a finding to investigate, not a pass.

**Single-use unwrap (demonstrated on loopback):** only after the preceding
validation, run this block with that same wrapping token selected. The first unwrap must succeed;
repeat with the consumed token still selected and require a Vault invalid-token or
already-unwrapped error. A separate fresh, validated token must still unwrap successfully.
Protect the successful output, which contains the SecretID.

```bash
# DEMONSTRATED: loopback first unwrap, consumed-token refusal and fresh-token control recorded below. The loopback runs used an earlier form of the block, whose guard refusals exited with status 1, which took two values and which ended with the unwrap's status; the current form, which takes FIRST or REPEAT as a third value and classifies the unwrap, has not been demonstrated.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_VAULT_HTTPS_URL' \
    'REPLACE_WITH_CA_FILE' \
    'REPLACE_WITH_FIRST_OR_REPEAT'
  # Value 3 is FIRST for a token's first unwrap, or REPEAT for the repeat with the consumed token still selected.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 3 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  case "$2" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 2; not probing"; exit 2 ;;
  esac
  case "$1" in https://*) ;; *) echo "use an HTTPS URL"; exit 2 ;; esac
  [ -r "$2" ] || { echo "CA file is not readable"; exit 2; }
  case "$3" in
    FIRST|REPEAT) ;;
    *) echo "set value 3 to FIRST for a token's first unwrap, or REPEAT with the consumed token still selected; not probing"; exit 2 ;;
  esac
  unset VAULT_SKIP_VERIFY VAULT_AGENT_ADDR VAULT_NAMESPACE VAULT_WRAP_TTL VAULT_ADDR VAULT_CACERT || exit 2
  export VAULT_ADDR="$1" VAULT_CACERT="$2" || exit 2
  # The unwrapped SecretID goes straight to you; only vault's error text is held as a value.
  { set -- "$3" "$(if { vault unwrap >&3; } 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"; } 3>&1
  printf '%s' "${2% *}"
  # Status: with FIRST, 0 when the unwrap succeeds, 1 when Vault says the token is not valid, because someone may
  # have unwrapped it first, and 3 for any other failure; with REPEAT, 1 when the unwrap succeeds, 0 for that
  # not-valid error, and 3 for any other failure.
  case "$1:${2##* }:${2% *}" in
    FIRST:0:*) echo "the first unwrap succeeded; protect the SecretID above"; exit 0 ;;
    REPEAT:0:*) echo "FINDING: the consumed wrapping token unwrapped again"; exit 1 ;;
    FIRST:*:*"wrapping token is not valid or does not exist"*) echo "FINDING: the first unwrap failed because the token is no longer valid, so it may have been unwrapped before you; investigate"; exit 1 ;;
    REPEAT:*:*"wrapping token is not valid or does not exist"*) echo "Vault refused the consumed token, the fixed outcome while a fresh, validated token still unwraps"; exit 0 ;;
    *) echo "vault unwrap exit ${2##* } without Vault's not-valid wrapping-token error; inconclusive"; exit 3 ;;
  esac
)
```

Successful reuse would violate the expected single-use behavior. Do not mistake selecting a new
token between requests for successful reuse of the original. On the loopback run, the first unwrap
returned the SecretID fields, the second failed with `wrapping token is not valid or does not exist`,
and a fresh wrapping token unwrapped.
See [unwrap](https://developer.hashicorp.com/vault/docs/commands/unwrap) and
[wrapping-token behavior](https://developer.hashicorp.com/vault/docs/concepts/response-wrapping).

**External isolation (both connection outcomes demonstrated on loopback; the real network
REASONED, since the host has no second network):** this last probe is the reverse of the on-host checks:
run it from a machine outside your trusted network, where the fixed state is that nothing answers.
Guard the address so the probe cannot run unsubstituted and time out as if the port were closed:

```bash
# DEMONSTRATED: local connection-failure discriminator recorded below; this does not demonstrate an external firewall. The loopback runs used an earlier form of the block, whose guard refusals exited with status 1 and which ended with curl's status; the current form, whose guard refusals exit with status 2 and which classifies the probe by time_connect, has not been demonstrated.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_PUBLIC_IP'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  set -- "$(if curl -q -g -s -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
    -w 'http=%{http_code} time_connect=%{time_connect} exit=%{exitcode} err=%{errormsg}\n' \
    "https://$1:8200/v1/sys/seal-status"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  set -- "${1% *}" "${1##* }"   # curl's write-out line, then its exit status
  printf '%s' "$1"
  # Status: 1 for any non-zero time_connect, because the TCP connection formed; 0 when it stayed 0.000000 after a
  # refusal, no route or connection timeout (curl exit 7 or 28); otherwise 3, as for a name or local socket error.
  case "$1" in
    "http="*" time_connect=0.000000 "*) ;;
    "http="*" time_connect="*) echo "FINDING: a TCP connection to port 8200 formed from this source"; exit 1 ;;
    *) echo "curl exit $2 printed no write-out line; inconclusive"; exit 3 ;;
  esac
  case "$2" in
    7|28) echo "no TCP connection formed (curl exit $2); this shows only that the address you tested is unreachable from here"; exit 0 ;;
    *) echo "curl exit $2 before any TCP connection, as for a name-resolution or local socket error; inconclusive"; exit 3 ;;
  esac
)
```

```bash
# REASONED: external isolation and permitted-source control; the host has no second network. Repeat this probe from the sources described below; the cited listener and firewall guidance defines the expected outcomes.
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_PUBLIC_IP' 'REPLACE_WITH_FORBIDDEN_OR_PERMITTED'
  # Value 2 is FORBIDDEN when you probe from a source the firewall must refuse, or PERMITTED from a permitted one.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"") echo "substitute value 1; not probing"; exit 2 ;;
  esac
  case "$2" in
    FORBIDDEN|PERMITTED) ;;
    *) echo "set value 2 to FORBIDDEN from a source the firewall must refuse, or PERMITTED from a permitted source; not probing"; exit 2 ;;
  esac
  set -- "$2" "$(if curl -q -g -s -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
    -w 'http=%{http_code} time_connect=%{time_connect} exit=%{exitcode} err=%{errormsg}\n' \
    "https://$1:8200/v1/sys/seal-status"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  set -- "$1" "${2% *}" "${2##* }"   # the source, curl's write-out line, then its exit status
  printf '%s' "$2"
  # Status: from a FORBIDDEN source, 1 for any non-zero time_connect, 0 when it stayed 0.000000 after curl exit 7
  # or 28, otherwise 3; from a PERMITTED source, 0 when the TCP connection formed, the positive control, else 3.
  case "$1:$2" in
    FORBIDDEN:"http="*" time_connect=0.000000 "*) ;;
    FORBIDDEN:"http="*" time_connect="*) echo "FINDING: a TCP connection to port 8200 formed from this forbidden source"; exit 1 ;;
    PERMITTED:"http="*" time_connect=0.000000 "*) echo "curl exit $3: no TCP connection formed from the permitted source, so the matched control failed; inconclusive"; exit 3 ;;
    PERMITTED:"http="*" time_connect="*) echo "a TCP connection formed from the permitted source, the positive control, even if certificate verification failed after it"; exit 0 ;;
    *) echo "curl exit $3 printed no write-out line; inconclusive"; exit 3 ;;
  esac
  case "$3" in
    7|28) echo "no TCP connection formed (curl exit $3); this shows only that the address you tested is unreachable from here"; exit 0 ;;
    *) echo "curl exit $3 before any TCP connection, as for a name-resolution or local socket error; inconclusive"; exit 3 ;;
  esac
)
```

For this probe the discriminator is whether the TCP connection forms, not the HTTP reply: the fixed
state is `time_connect` at `0.000000` with `err` naming a refusal, no route, or a filtered-port timeout,
and any non-zero `time_connect`, even when the TLS handshake then fails against an internal CA, means
the port is reachable and is the finding. Run the same check against `8201` and every externally
reachable address. A name-resolution or local-socket error is inconclusive. This proves only that the
ADDRESS you tested is unreachable, not that Vault is: a mistyped or misrouted address also yields
`time_connect=0`, so confirm `$1` is the real external address (or public NAT) of the listener the on-host
`ss` showed bound to `8200`, so a typo does not read as isolation. On loopback, the probe against the listening address printed a
non-zero `time_connect` and curl's certificate-verification error (exit `60`), the reachable shape,
and against 127.0.0.2, where nothing listens, `time_connect=0.000000` and `Could not connect to
server` (exit `7`), the refused shape.

REASONED: external isolation control: require a TCP connection from the permitted source and refusal from the forbidden source to the same destination; forbidden-source connectivity is exposed and a failed permitted control is inconclusive. No permitted/forbidden deployment pair was available. Per the guide's cited Vault production hardening (root token, swap, core dumps); Vault HA communication (advertised addresses and cluster TLS); curl options (write-out fields require 7.75.0; header files, TLS verification, direct connections, and write-out fields). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Pair the forbidden-source check with the same destination and port from a permitted host:
the positive control must establish a TCP connection, which the preceding block reports with status
0 when its second value is `PERMITTED`. For `8201`, use a permitted Vault node.
If the permitted source cannot route to that destination, the matched control is unavailable;
record the limitation instead of claiming this probe demonstrates isolation. Confirm the firewall
rules as well; a single external probe only establishes reachability from that source.
See [production firewall guidance](https://developer.hashicorp.com/vault/docs/concepts/production-hardening),
[cluster communication](https://developer.hashicorp.com/vault/docs/concepts/ha), and
[seal-status API behavior](https://developer.hashicorp.com/vault/api-docs/system/seal-status).

| Check scope | Status | Deployment comparison and prerequisites |
| --- | --- | --- |
| REASONED: deployment comparisons in this row: require the specified HA responses, delivery to both independent audit destinations, intended binds, unexpected-path rejection by the recipient, and denied external access with a working permitted-source control; missing delivery, unintended binds, accepted unexpected paths and forbidden-source connectivity are findings. No multi-node deployment, recipient implementation or external source pair was available. The guide's cited sources for the deployment comparisons in this row (part 1 of 2): Vault sys/health status codes; Vault HA redirect implementation (pinned v2.2.1); Vault local-only forwarding implementation (pinned v2.2.1); Vault audit devices (fail-closed, HMAC default, exempt endpoints); Vault TCP listener (address defaults, tls_disable, cluster_address). The guide's cited sources for the deployment comparisons in this row (part 2 of 2): Vault response wrapping (single use, delivery, validation, and historical 0.8 version note); Vault wrapping lookup API (creation path, time, and original TTL); Vault production hardening (root token, swap, core dumps); Vault HA communication (advertised addresses and cluster TLS). Related Verify blocks passed `bash -n` and ShellCheck 0.11.0 silently; written placeholders printed `substitute value 1; not probing` (exit 1), and substituted fixtures printed stub calls (exit 0). The bash -n, ShellCheck and stub runs recorded here covered an earlier form of the Verify blocks, whose guard refusals exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. This marking review used stubs: a live Vault stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Checks beyond the recorded loopback runs | REASONED from the cited Vault documentation; not demonstrated | In an authorized isolated Vault deployment, demonstrate what a single loopback node cannot (part 1 of 2): HA standby behavior (the `429`, `474` and `530` health and status codes, and the monitoring checks' redirects and local-only handlers), a second audit device in a separate failure domain with delivery to both destinations, a wildcard bind and `ss` run as root. The demonstration in that authorized isolated Vault deployment, of what a single loopback node cannot demonstrate, is to cover (part 2 of 2): recipient-side rejection of an unexpected creation path, and the external isolation probe from real permitted and forbidden sources against 8200 and 8201. Record the Vault version and edition, effective settings, requests, errors, and matched positive controls without credentials. |

## Sources (checked September 2026)

- Vault dev server (in-memory, insecure, not for production): https://developer.hashicorp.com/vault/docs/concepts/dev-server
- Vault TCP listener (address defaults, tls_disable, cluster_address): https://developer.hashicorp.com/vault/docs/configuration/listener/tcp
- Vault Integrated Storage (Raft) backend (path, node_id, cluster_addr): https://developer.hashicorp.com/vault/docs/configuration/storage/raft
- Vault seal concepts (sealed state, Shamir vs auto-unseal, recovery keys): https://developer.hashicorp.com/vault/docs/concepts/seal
- Vault operator init: https://developer.hashicorp.com/vault/docs/commands/operator/init
- Vault audit devices (fail-closed, HMAC default, exempt endpoints): https://developer.hashicorp.com/vault/docs/audit
- Vault production hardening (root token, swap, core dumps): https://developer.hashicorp.com/vault/docs/concepts/production-hardening
- Vault sys/health status codes: https://developer.hashicorp.com/vault/api-docs/system/health
- Vault policies and tokens: https://developer.hashicorp.com/vault/docs/concepts/policies
- Vault Login MFA (enforced on auth-method logins; the token auth method cannot use it): https://developer.hashicorp.com/vault/docs/auth/login-mfa
- Vault server flags (config, dev TLS, dev token-helper storage): https://developer.hashicorp.com/vault/docs/commands/server
- Vault configuration (UI default, advertised addresses, disable_mlock): https://developer.hashicorp.com/vault/docs/configuration
- Vault HA communication (advertised addresses and cluster TLS): https://developer.hashicorp.com/vault/docs/concepts/ha
- Vault KMIP secrets engine (Enterprise requirement and separate listener): https://developer.hashicorp.com/vault/docs/secrets/kmip
- Vault Agent configuration and listeners: https://developer.hashicorp.com/vault/docs/agent-and-proxy/agent
- Vault Proxy configuration and listeners: https://developer.hashicorp.com/vault/docs/agent-and-proxy/proxy
- Vault AWS KMS seal (auto-unseal and Enterprise seal wrapping): https://developer.hashicorp.com/vault/docs/configuration/seal/awskms
- Vault Transit seal (Community auto-unseal and Enterprise seal wrapping): https://developer.hashicorp.com/vault/docs/configuration/seal/transit
- Vault operator unseal (hidden prompt): https://developer.hashicorp.com/vault/docs/commands/operator/unseal
- Vault operator rekey (unseal and recovery shares): https://developer.hashicorp.com/vault/docs/commands/operator/rekey
- Vault file audit device and SIGHUP rotation: https://developer.hashicorp.com/vault/docs/audit/file
- Vault syslog audit device (local agent and remote-delivery responsibility): https://developer.hashicorp.com/vault/docs/audit/syslog
- Vault audit API (device options, log_raw, and inspection permissions): https://developer.hashicorp.com/vault/api-docs/system/audit
- Vault audit entry schema (request IDs and token-use fields): https://developer.hashicorp.com/vault/docs/audit/schema
- Vault audit list command: https://developer.hashicorp.com/vault/docs/commands/audit/list
- Vault token concepts (token prefixes, parent and child revocation, root tokens, TTLs, service and batch behavior): https://developer.hashicorp.com/vault/docs/concepts/tokens
- Vault token revoke command (self-revocation): https://developer.hashicorp.com/vault/docs/commands/token/revoke
- Vault root-token generation: https://developer.hashicorp.com/vault/docs/commands/operator/generate-root
- Vault CLI (environment variables, token helper, TLS, and wrapping options): https://developer.hashicorp.com/vault/docs/commands
- Vault login command (credential prompts): https://developer.hashicorp.com/vault/docs/commands/login
- Vault policy write command (HCL from stdin): https://developer.hashicorp.com/vault/docs/commands/policy/write
- Vault KV v2 API (data paths and read operations): https://developer.hashicorp.com/vault/api-docs/secret/kv/kv-v2
- Vault AppRole authentication (setup, token choice, and child-token constraints): https://developer.hashicorp.com/vault/docs/auth/approle
- Vault AppRole API (role parameters, SecretID generation, and login): https://developer.hashicorp.com/vault/api-docs/auth/approle
- Vault AppRole integration guidance (prefer existing workload identity): https://developer.hashicorp.com/vault/docs/auth/approle/approle-pattern
- Vault auth enable command: https://developer.hashicorp.com/vault/docs/commands/auth/enable
- Vault Kubernetes API (service-account and namespace bindings): https://developer.hashicorp.com/vault/api-docs/auth/kubernetes
- Vault JWT authentication (identity constraints and Vault 1.17 audience requirement): https://developer.hashicorp.com/vault/docs/auth/jwt
- Vault response wrapping (single use, delivery, validation, and historical 0.8 version note): https://developer.hashicorp.com/vault/docs/concepts/response-wrapping
- Vault wrapping lookup API (creation path, time, and original TTL): https://developer.hashicorp.com/vault/api-docs/system/wrapping-lookup
- Vault write command (JSON stdin, format, and force flags): https://developer.hashicorp.com/vault/docs/commands/write
- Vault unwrap command (use the selected token without a token argument): https://developer.hashicorp.com/vault/docs/commands/unwrap
- Vault metrics API (GET, JSON format, and root namespace): https://developer.hashicorp.com/vault/api-docs/system/metrics
- Vault profiling API (index path and root namespace): https://developer.hashicorp.com/vault/api-docs/system/pprof
- Vault initialization API: https://developer.hashicorp.com/vault/api-docs/system/init
- Vault leader-status API: https://developer.hashicorp.com/vault/api-docs/system/leader
- Vault seal-status API (unauthenticated status): https://developer.hashicorp.com/vault/api-docs/system/seal-status
- Vault Raft operator commands (snapshot save): https://developer.hashicorp.com/vault/docs/commands/operator/raft
- Vault status command (JSON output and exit codes): https://developer.hashicorp.com/vault/docs/commands/status
- Vault 2.1.1 AppRole expired-SecretID tidy (once a minute; a SecretID may live up to a minute past expiry): https://github.com/hashicorp/vault/blob/v2.1.1/builtin/credential/approle/backend.go
- Vault token lookup command (selected-token lookup and JSON output): https://developer.hashicorp.com/vault/docs/commands/token/lookup
- curl options (write-out fields require 7.75.0; header files, TLS verification, direct connections, and write-out fields): https://curl.se/docs/manpage.html
- Vault HA redirect implementation (pinned v2.2.1): https://raw.githubusercontent.com/hashicorp/vault/v2.2.1/http/handler.go
- Vault local-only forwarding implementation (pinned v2.2.1): https://raw.githubusercontent.com/hashicorp/vault/v2.2.1/http/logical.go
- sudo SUDO_1_9_16p2 sudoers manual, secure_path (checked October 2026): https://github.com/sudo-project/sudo/blob/SUDO_1_9_16p2/docs/sudoers.man.in#L5650-L5655


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- run: Vault loopback run (2.1.1)
- ha: Vault handler source (v2.2.1)
- forward: Vault forwarding source (v2.2.1)
- jwt-min: Vault JWT audience minimum (1.17)
- wrap-history: Vault historical wrapping qualification (0.8)
- docs: Vault documentation (unknown)
- curl: curl minimum write-out version (7.75.0)

Claims (full source mapping in the JSON block below):

- dev (REASONED; docs): Dev modes, token-helper storage and production config-file startup.
- listeners (REASONED; docs): API/UI 8200, cluster 8201, private bind, advertised addresses and cluster TLS; optional KMIP, Agent and Proxy listeners.
- mfa (REASONED; docs): Login MFA belongs on human auth methods; token auth cannot use it.
- raft-tls (DEMONSTRATED; docs, run): Raft node fields, UI disabled, TLS certificate/key/minimum, anonymous monitoring disabled; address/path substitutions only in the recorded run.
- defaults (REASONED; docs): Listener loopback, TLS enabled, UI disabled and anonymous metrics/profiling disabled are documentation defaults.
- seal (REASONED; docs): Shamir init/unseal prompts, auto-unseal/recovery, Community Transit and Enterprise seal wrapping/HA; key loss and rekey custody.
- audit (REASONED; docs): Enable file and independent syslog auditing, fail-closed availability, HMAC defaults, log_raw, exemptions and SIGHUP rotation.
- root (REASONED; docs): Bootstrap root has unlimited access and no expiry; retire after testing another auth method, remove helper copy, regenerate only by quorum.
- cli (REASONED; docs): Credential prompts, token environment/helper selection and protected stdin/files avoid credential arguments.
- policy (REASONED; docs): Deny-by-default non-root policies, additive grants, KV v2 data path, no writes/listing/sudo, bounded TTL and service-token tradeoffs.
- role (DEMONSTRATED; docs, run): Every displayed AppRole role parameter is returned by role inspection; example budgets are not defaults. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.
- delivery (REASONED; docs): Delivery policy requires wrapping TTL 1s to 60s; protect transfer and lookup JSON, check path/time/original TTL before unwrap.
- identity (REASONED; docs, jwt-min): Existing workload identity is preferred; Kubernetes names/namespaces and JWT identity/audience binding apply, including the stated 1.17 qualification.
- bootstrap (REASONED; docs): Unauthenticated health, seal-status, init and leader paths need network isolation; policies cannot close bootstrap paths.
- storage (REASONED; docs): Unprivileged process, protected snapshots/storage, no swap/core dumps; disable_mlock is Raft-specific.
- bind-test (DEMONSTRATED; docs, run): Loopback socket inventory and TLS/plaintext discrimination; extra unintended loopback listener detected. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.
- cluster-address (DEMONSTRATED; docs, run): cluster_address defaults to the address port + 1; the follow-up loopback run observed 127.0.0.2:8200 and :8201 for a second listener. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.
- bind-limits (REASONED; docs): Wildcard binds, ss as root and actual firewall isolation remain unobserved.
- health-test (DEMONSTRATED; docs, run): Single-node health 501/503/200 and status sealed/unsealed exits; stopped-server failure is inconclusive. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.
- health-ha (REASONED; docs): Standby, removed-node and Enterprise health/status codes and query overrides are documentation reasoning.
- audit-test (DEMONSTRATED; docs, run): Empty/one/two file-device inspection and request-ID correlation demonstrate local delivery. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.
- audit-remote (REASONED; docs): Independent failure-domain audit delivery remains unobserved.
- root-test (DEMONSTRATED; docs, run): Root self-revocation rejects lookups and revokes non-orphan children; independent logins continue. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.
- acl-test (DEMONSTRATED; docs, run): Own-secret, cross-application denial and collector isolation distinguish narrow from broad policies with fixture controls. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.
- monitor-test (DEMONSTRATED; docs, run): Active-node anonymous metrics/pprof reject while authorized identities succeed; enabling anonymous access exposes both. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.
- monitor-ha (REASONED; docs, ha, forward): Root namespace, active-node targeting, separate profiling policy, HA redirects/local-only forwarding and every-node checks.
- secretid (DEMONSTRATED; docs, run): SecretID one-use and TTL/tidy discrimination use fresh positive controls; expired IDs can work until tidy. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.
- cidr (DEMONSTRATED; docs, run): SecretID and token source restrictions discriminate on two loopback addresses; curl --interface replaces CLI source selection. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.
- token (DEMONSTRATED; docs, run): Service/batch prefixes, TTL, 100-use limit and shortened renewal-ceiling experiment have exposed/fixed controls. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.
- wrap-test (DEMONSTRATED; docs, run): No-wrap/61s issuance refused, 60s succeeds; unrestricted delivery policy supplies exposed control. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1 and which ended with the positive control's status; the current form has no recorded run.
- lookup-test (DEMONSTRATED; docs, run): Lookup returns path/time/original TTL; consumed and expired tokens fail. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.
- recipient (REASONED; docs): Receiving application must reject an unexpected creation path; its implementation is not demonstrated.
- unwrap-test (DEMONSTRATED; docs, run): First unwrap succeeds, reuse fails, fresh control succeeds. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.
- connection-test (DEMONSTRATED; docs, curl, run): Loopback reachable/refused shapes distinguish TCP connection from TLS/HTTP success, not real external isolation. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.
- external (REASONED; docs, curl): Test actual 8200/8201 destinations from permitted and forbidden sources; routing, local errors and unavailable controls are inconclusive.
- wrapping-history (REASONED; wrap-history): Some wrapping-token features date from 0.8; do not generalize current behavior to earlier versions.

````json
{
  "schema": 1,
  "checked": "2026-09-26",
  "documentation_checked": "2026-09",
  "body_sha256": "022349ca91831b2529cafa503eb58de4b7a08164ad52413b60e1c236738edbc9",
  "components": {
    "run": {
      "name": "Vault loopback run",
      "basis": "2.1.1",
      "sources": {
        "sd936be5e4c41": "https://github.com/hashicorp/vault/blob/v2.1.1/builtin/credential/approle/backend.go"
      }
    },
    "ha": {
      "name": "Vault handler source",
      "basis": "v2.2.1",
      "sources": {
        "s277fb66ef17f": "https://raw.githubusercontent.com/hashicorp/vault/v2.2.1/http/handler.go"
      }
    },
    "forward": {
      "name": "Vault forwarding source",
      "basis": "v2.2.1",
      "sources": {
        "s2c568094f4a5": "https://raw.githubusercontent.com/hashicorp/vault/v2.2.1/http/logical.go"
      }
    },
    "jwt-min": {
      "name": "Vault JWT audience minimum",
      "basis": "1.17",
      "sources": {
        "sf213104862ac": "https://developer.hashicorp.com/vault/docs/auth/jwt"
      }
    },
    "wrap-history": {
      "name": "Vault historical wrapping qualification",
      "basis": "0.8",
      "sources": {
        "sa79f2fd07092": "https://developer.hashicorp.com/vault/docs/concepts/response-wrapping"
      }
    },
    "docs": {
      "name": "Vault documentation",
      "basis": "unknown",
      "sources": {
        "sbffd38b4758e": "https://developer.hashicorp.com/vault/docs/concepts/dev-server",
        "se38e85360763": "https://developer.hashicorp.com/vault/docs/commands/server",
        "sbfb9c60f21c1": "https://developer.hashicorp.com/vault/docs/configuration/listener/tcp",
        "s60d6655e9803": "https://developer.hashicorp.com/vault/docs/configuration/storage/raft",
        "sf7bd8360ca01": "https://developer.hashicorp.com/vault/docs/concepts/seal",
        "s847725e335a1": "https://developer.hashicorp.com/vault/docs/commands/operator/init",
        "s6a139716500f": "https://developer.hashicorp.com/vault/docs/audit",
        "s0f36ae51e56b": "https://developer.hashicorp.com/vault/docs/concepts/production-hardening",
        "sa1a925943f6a": "https://developer.hashicorp.com/vault/api-docs/system/health",
        "sfbfbd7179dca": "https://developer.hashicorp.com/vault/docs/concepts/policies",
        "s85efb0c5061e": "https://developer.hashicorp.com/vault/docs/auth/login-mfa",
        "sf1aad6c3d00d": "https://developer.hashicorp.com/vault/docs/configuration",
        "sb271b7950e37": "https://developer.hashicorp.com/vault/docs/concepts/ha",
        "s91710ca3e5c1": "https://developer.hashicorp.com/vault/docs/secrets/kmip",
        "sd7d57255b0b5": "https://developer.hashicorp.com/vault/docs/agent-and-proxy/agent",
        "s8320687a6d11": "https://developer.hashicorp.com/vault/docs/agent-and-proxy/proxy",
        "sbf26b6d0ef76": "https://developer.hashicorp.com/vault/docs/configuration/seal/awskms",
        "s3036564c8eb4": "https://developer.hashicorp.com/vault/docs/configuration/seal/transit",
        "s6a0b17f5713a": "https://developer.hashicorp.com/vault/docs/commands/operator/unseal",
        "s89677a91be0d": "https://developer.hashicorp.com/vault/docs/commands/operator/rekey",
        "scfd7c15adedf": "https://developer.hashicorp.com/vault/docs/audit/file",
        "s32194cc039b1": "https://developer.hashicorp.com/vault/docs/audit/syslog",
        "s6a89353a6c03": "https://developer.hashicorp.com/vault/api-docs/system/audit",
        "sd66fc0bcfb15": "https://developer.hashicorp.com/vault/docs/audit/schema",
        "s4bc92d253ba6": "https://developer.hashicorp.com/vault/docs/commands/audit/list",
        "s449e83b31426": "https://developer.hashicorp.com/vault/docs/concepts/tokens",
        "s923f5369652b": "https://developer.hashicorp.com/vault/docs/commands/token/revoke",
        "s426748068836": "https://developer.hashicorp.com/vault/docs/commands/operator/generate-root",
        "sab78482b691b": "https://developer.hashicorp.com/vault/docs/commands",
        "s0f2cf5468884": "https://developer.hashicorp.com/vault/docs/commands/login",
        "s607f5b7aafbc": "https://developer.hashicorp.com/vault/docs/commands/policy/write",
        "sf7640abb07c2": "https://developer.hashicorp.com/vault/api-docs/secret/kv/kv-v2",
        "s745b51dd1719": "https://developer.hashicorp.com/vault/docs/auth/approle",
        "s553adec7c375": "https://developer.hashicorp.com/vault/api-docs/auth/approle",
        "s3cf51daf4c81": "https://developer.hashicorp.com/vault/docs/auth/approle/approle-pattern",
        "scfa855ec9d87": "https://developer.hashicorp.com/vault/api-docs/auth/kubernetes",
        "sf213104862ac": "https://developer.hashicorp.com/vault/docs/auth/jwt",
        "sa79f2fd07092": "https://developer.hashicorp.com/vault/docs/concepts/response-wrapping",
        "sca6c552728d7": "https://developer.hashicorp.com/vault/api-docs/system/wrapping-lookup",
        "s17fb33326e35": "https://developer.hashicorp.com/vault/docs/commands/write",
        "sd1209454cb98": "https://developer.hashicorp.com/vault/docs/commands/unwrap",
        "s1437757f255b": "https://developer.hashicorp.com/vault/api-docs/system/metrics",
        "s84bf68313c5d": "https://developer.hashicorp.com/vault/api-docs/system/pprof",
        "sabe0751ee280": "https://developer.hashicorp.com/vault/api-docs/system/init",
        "s51416363da81": "https://developer.hashicorp.com/vault/api-docs/system/leader",
        "s1e239e51209c": "https://developer.hashicorp.com/vault/api-docs/system/seal-status",
        "sd032f083ae99": "https://developer.hashicorp.com/vault/docs/commands/operator/raft",
        "s70ec02f4b4d7": "https://developer.hashicorp.com/vault/docs/commands/status",
        "sdb9905c2f649": "https://developer.hashicorp.com/vault/docs/commands/token/lookup"
      }
    },
    "curl": {
      "name": "curl minimum write-out version",
      "basis": "7.75.0",
      "sources": {
        "s2b2686afaf41": "https://curl.se/docs/manpage.html"
      }
    }
  },
  "claims": {
    "dev": {"text": "Dev modes, token-helper storage and production config-file startup.", "components": ["docs"], "sources": ["docs:sbffd38b4758e", "docs:se38e85360763"], "status": "REASONED"},
    "listeners": {"text": "API/UI 8200, cluster 8201, private bind, advertised addresses and cluster TLS; optional KMIP, Agent and Proxy listeners.", "components": ["docs"], "sources": ["docs:sbfb9c60f21c1", "docs:sf1aad6c3d00d", "docs:sb271b7950e37", "docs:s91710ca3e5c1", "docs:sd7d57255b0b5", "docs:s8320687a6d11"], "status": "REASONED"},
    "mfa": {"text": "Login MFA belongs on human auth methods; token auth cannot use it.", "components": ["docs"], "sources": ["docs:s85efb0c5061e"], "status": "REASONED"},
    "raft-tls": {"text": "Raft node fields, UI disabled, TLS certificate/key/minimum, anonymous monitoring disabled; address/path substitutions only in the recorded run.", "components": ["docs", "run"], "sources": ["docs:sbfb9c60f21c1", "docs:s60d6655e9803", "docs:sf1aad6c3d00d", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "a single Raft node running the section 3 configuration unchanged apart from addresses and paths"},
    "defaults": {"text": "Listener loopback, TLS enabled, UI disabled and anonymous metrics/profiling disabled are documentation defaults.", "components": ["docs"], "sources": ["docs:sbfb9c60f21c1", "docs:sf1aad6c3d00d"], "status": "REASONED"},
    "seal": {"text": "Shamir init/unseal prompts, auto-unseal/recovery, Community Transit and Enterprise seal wrapping/HA; key loss and rekey custody.", "components": ["docs"], "sources": ["docs:sf7bd8360ca01", "docs:s847725e335a1", "docs:sbf26b6d0ef76", "docs:s3036564c8eb4", "docs:s6a0b17f5713a", "docs:s89677a91be0d"], "status": "REASONED"},
    "audit": {"text": "Enable file and independent syslog auditing, fail-closed availability, HMAC defaults, log_raw, exemptions and SIGHUP rotation.", "components": ["docs"], "sources": ["docs:s6a139716500f", "docs:scfd7c15adedf", "docs:s32194cc039b1", "docs:s6a89353a6c03"], "status": "REASONED"},
    "root": {"text": "Bootstrap root has unlimited access and no expiry; retire after testing another auth method, remove helper copy, regenerate only by quorum.", "components": ["docs"], "sources": ["docs:s449e83b31426", "docs:s923f5369652b", "docs:s426748068836"], "status": "REASONED"},
    "cli": {"text": "Credential prompts, token environment/helper selection and protected stdin/files avoid credential arguments.", "components": ["docs"], "sources": ["docs:s6a0b17f5713a", "docs:sab78482b691b", "docs:s0f2cf5468884", "docs:s17fb33326e35", "docs:sd1209454cb98"], "status": "REASONED"},
    "policy": {"text": "Deny-by-default non-root policies, additive grants, KV v2 data path, no writes/listing/sudo, bounded TTL and service-token tradeoffs.", "components": ["docs"], "sources": ["docs:sfbfbd7179dca", "docs:s449e83b31426", "docs:s607f5b7aafbc", "docs:sf7640abb07c2", "docs:s745b51dd1719"], "status": "REASONED"},
    "role": {"text": "Every displayed AppRole role parameter is returned by role inspection; example budgets are not defaults. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.", "components": ["docs", "run"], "sources": ["docs:s553adec7c375", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "The role read returned every section 7 value, with durations in seconds.", "verify": [1]},
    "delivery": {"text": "Delivery policy requires wrapping TTL 1s to 60s; protect transfer and lookup JSON, check path/time/original TTL before unwrap.", "components": ["docs"], "sources": ["docs:sfbfbd7179dca", "docs:sa79f2fd07092", "docs:sca6c552728d7", "docs:s17fb33326e35", "docs:sd1209454cb98"], "status": "REASONED"},
    "identity": {"text": "Existing workload identity is preferred; Kubernetes names/namespaces and JWT identity/audience binding apply, including the stated 1.17 qualification.", "components": ["docs", "jwt-min"], "sources": ["docs:s3cf51daf4c81", "docs:scfa855ec9d87", "docs:sf213104862ac", "jwt-min:sf213104862ac"], "status": "REASONED"},
    "bootstrap": {"text": "Unauthenticated health, seal-status, init and leader paths need network isolation; policies cannot close bootstrap paths.", "components": ["docs"], "sources": ["docs:sa1a925943f6a", "docs:sabe0751ee280", "docs:s51416363da81", "docs:s1e239e51209c"], "status": "REASONED"},
    "storage": {"text": "Unprivileged process, protected snapshots/storage, no swap/core dumps; disable_mlock is Raft-specific.", "components": ["docs"], "sources": ["docs:s60d6655e9803", "docs:s0f36ae51e56b", "docs:sf1aad6c3d00d", "docs:sd032f083ae99"], "status": "REASONED"},
    "bind-test": {"text": "Loopback socket inventory and TLS/plaintext discrimination; extra unintended loopback listener detected. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.", "components": ["docs", "run"], "sources": ["docs:sbfb9c60f21c1", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "a plaintext request got `400` \"Client sent an HTTP request to an HTTPS server\"", "verify": [1]},
    "cluster-address": {"text": "cluster_address defaults to the address port + 1; the follow-up loopback run observed 127.0.0.2:8200 and :8201 for a second listener. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.", "components": ["docs", "run"], "sources": ["docs:sbfb9c60f21c1", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "verify": [1], "evidence": "socket table also showed `127.0.0.2:8200` and `127.0.0.2:8201`, an unintended listener with its own cluster port, because `cluster_address` defaults to one port above `address`."},
    "bind-limits": {"text": "Wildcard binds, ss as root and actual firewall isolation remain unobserved.", "components": ["docs"], "sources": ["docs:sbfb9c60f21c1", "docs:s0f36ae51e56b"], "status": "REASONED", "verify": [2, 11]},
    "health-test": {"text": "Single-node health 501/503/200 and status sealed/unsealed exits; stopped-server failure is inconclusive. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.", "components": ["docs", "run"], "sources": ["docs:sa1a925943f6a", "docs:s70ec02f4b4d7", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "Health returned `501` before initialization, `503` while sealed (status exit code `2`) and `200` once unsealed (exit code `0`)", "verify": [1]},
    "health-ha": {"text": "Standby, removed-node and Enterprise health/status codes and query overrides are documentation reasoning.", "components": ["docs"], "sources": ["docs:sa1a925943f6a", "docs:s70ec02f4b4d7"], "status": "REASONED", "verify": [2]},
    "audit-test": {"text": "Empty/one/two file-device inspection and request-ID correlation demonstrate local delivery. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.", "components": ["docs", "run"], "sources": ["docs:sd66fc0bcfb15", "docs:s4bc92d253ba6", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "with two file audit devices, one request's `request_id` appeared twice in each file", "verify": [1]},
    "audit-remote": {"text": "Independent failure-domain audit delivery remains unobserved.", "components": ["docs"], "sources": ["docs:s6a139716500f", "docs:s32194cc039b1"], "status": "REASONED", "verify": [2]},
    "root-test": {"text": "Root self-revocation rejects lookups and revokes non-orphan children; independent logins continue. The recorded live loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by stub runs, which do not establish live Vault behavior.", "components": ["docs", "run"], "sources": ["docs:s449e83b31426", "docs:s923f5369652b", "docs:sdb9905c2f649", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "A scoped admin created as a child of the root token lost access with it, while an orphan token and a userpass login kept working.", "verify": [1]},
    "acl-test": {"text": "Own-secret, cross-application denial and collector isolation distinguish narrow from broad policies with fixture controls. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.", "components": ["docs", "run"], "sources": ["docs:sfbfbd7179dca", "docs:sf7640abb07c2", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "the payments token `200` on its own secret and `403` on the inventory secret, where the fixture reader got `200`", "verify": [3]},
    "monitor-test": {"text": "Active-node anonymous metrics/pprof reject while authorized identities succeed; enabling anonymous access exposes both. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.", "components": ["docs", "run"], "sources": ["docs:sbfb9c60f21c1", "docs:s1437757f255b", "docs:s84bf68313c5d", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "anonymous requests got `200` on `sys/metrics` and `sys/pprof/`", "verify": [3]},
    "monitor-ha": {"text": "Root namespace, active-node targeting, separate profiling policy, HA redirects/local-only forwarding and every-node checks.", "components": ["docs", "ha", "forward"], "sources": ["docs:s1437757f255b", "docs:s84bf68313c5d", "ha:s277fb66ef17f", "forward:s2c568094f4a5"], "status": "REASONED", "verify": [4]},
    "secretid": {"text": "SecretID one-use and TTL/tidy discrimination use fresh positive controls; expired IDs can work until tidy. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.", "components": ["docs", "run"], "sources": ["docs:s553adec7c375", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "SecretIDs 10 seconds past their TTL logged in, while one 70 seconds past it was refused", "verify": [5]},
    "cidr": {"text": "SecretID and token source restrictions discriminate on two loopback addresses; curl --interface replaces CLI source selection. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.", "components": ["docs", "run"], "sources": ["docs:s553adec7c375", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "a login from 127.0.0.1 succeeded, and its token read the payments secret with `200` from 127.0.0.1 and `403` from 127.0.0.2", "verify": [5]},
    "token": {"text": "Service/batch prefixes, TTL, 100-use limit and shortened renewal-ceiling experiment have exposed/fixed controls. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.", "components": ["docs", "run"], "sources": ["docs:s449e83b31426", "docs:s553adec7c375", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "100 reads returned `200` before read 101 got `403`; with `token_num_uses=0`, all 101 reads returned `200`.", "verify": [5]},
    "wrap-test": {"text": "No-wrap/61s issuance refused, 60s succeeds; unrestricted delivery policy supplies exposed control. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1 and which ended with the positive control's status; the current form has no recorded run.", "components": ["docs", "run"], "sources": ["docs:sfbfbd7179dca", "docs:sa79f2fd07092", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "the same kind of identity's unwrapped request returned the SecretID fields and a sixty-one-second request succeeded", "verify": [6]},
    "lookup-test": {"text": "Lookup returns path/time/original TTL; consumed and expired tokens fail. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.", "components": ["docs", "run"], "sources": ["docs:sca6c552728d7", "docs:s17fb33326e35", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "A wrapping token looked up three seconds after its two-second TTL failed the same way.", "verify": [7]},
    "recipient": {"text": "Receiving application must reject an unexpected creation path; its implementation is not demonstrated.", "components": ["docs"], "sources": ["docs:sa79f2fd07092", "docs:sca6c552728d7"], "status": "REASONED", "verify": [8]},
    "unwrap-test": {"text": "First unwrap succeeds, reuse fails, fresh control succeeds. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.", "components": ["docs", "run"], "sources": ["docs:sa79f2fd07092", "docs:sd1209454cb98", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "the first unwrap returned the SecretID fields, the second failed with `wrapping token is not valid or does not exist`, and a fresh wrapping token unwrapped.", "verify": [9]},
    "connection-test": {"text": "Loopback reachable/refused shapes distinguish TCP connection from TLS/HTTP success, not real external isolation. The recorded loopback runs used an earlier form of the block, whose guard refusals exited with status 1; the current form has no recorded run.", "components": ["docs", "curl", "run"], "sources": ["docs:s1e239e51209c", "curl:s2b2686afaf41", "run:sd936be5e4c41"], "status": "DEMONSTRATED", "evidence": "against 127.0.0.2, where nothing listens, `time_connect=0.000000` and `Could not connect to server` (exit `7`)", "verify": [10]},
    "external": {"text": "Test actual 8200/8201 destinations from permitted and forbidden sources; routing, local errors and unavailable controls are inconclusive.", "components": ["docs", "curl"], "sources": ["docs:s0f36ae51e56b", "docs:sb271b7950e37", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [11]},
    "wrapping-history": {"text": "Some wrapping-token features date from 0.8; do not generalize current behavior to earlier versions.", "components": ["wrap-history"], "sources": ["wrap-history:sa79f2fd07092"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
