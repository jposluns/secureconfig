# MinIO: credentials, TLS, encryption, and object protection

MinIO (now shipped as AIStor) is object storage you run yourself: apps store files in buckets through the same API as Amazon S3. This guide helps your AI assistant configure it securely, including real root credentials, TLS, scoped application access, and encryption with a key manager.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/minio.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against AIStor documentation (no recorded version) and curl curl-8_14_1; 1 further source is pinned to a commit and 1 carries no recorded version. Metadata reviewed 2026-09-26; documentation checked September 2026. The guide records 44 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

MinIO serves S3-compatible object storage; an exposed instance with weak or well-known credentials hands over every bucket. Both the S3 API port and the web console need the same care.

Lifecycle note, as of September 2026: the MinIO community repository on GitHub was archived on 2026-04-25 and carries the notice that it is no longer maintained; MinIO now ships AIStor Free (a standalone edition under a free licence) and AIStor Enterprise. The settings below are documented for AIStor. An archived community build receives no security fixes, so treat running one as a finding and plan the migration.

## 1. Set real root credentials

Provision `/etc/minio/root-user` and `/etc/minio/root-password` through your secret manager before starting the server. Each must be a regular file owned by the server account, mode `0600`, under a directory other accounts cannot traverse, write to or replace, with no ACL granting them access. Each contains only its credential, with no whitespace or trailing newline. Keep these files and their backups out of source control.

In the server's launch configuration, set only the file paths:

```dotenv
MINIO_ROOT_USER_FILE=/etc/minio/root-user
MINIO_ROOT_PASSWORD_FILE=/etc/minio/root-password
```

AIStor reads these files at startup. Remove `MINIO_ROOT_USER` and `MINIO_ROOT_PASSWORD` from the launch environment and any environment file: a direct value takes precedence over its `_FILE` counterpart. Start a fresh server process after changing its launch configuration. This assumes the protected files already exist and the launcher supplies these path variables; it does not create credentials or start a server. The shell and launch arguments contain only paths, while the server account and root can still read the credential files and server memory. See the vendor's [file-based settings](https://docs.min.io/aistor/reference/aistor-server/settings/#file-based-environment-variables) and [root credential file requirements](https://docs.min.io/aistor/reference/aistor-server/settings/root-credentials/).

Never run with the `minioadmin`/`minioadmin` pair, which is still the built-in default when neither direct root credentials nor credential files are supplied; scanners try it constantly. Root credentials are for administration only: create per-application access keys with least-privilege policies (via the console or the `mc` client) so no app holds root ([authentication.md](authentication.md)).

## 2. Enable TLS

MinIO serves HTTPS automatically when it finds a PEM key pair named `public.crt` and `private.key` in `${HOME}/.minio/certs` (or the directory given with `--certs-dir`):

```bash
cp fullchain.pem "${HOME}/.minio/certs/public.crt"
cp privkey.pem   "${HOME}/.minio/certs/private.key"
```

Certificates per [free-certificates.md](free-certificates.md) or [self-signed.md](self-signed.md); clients then use `https://` endpoints and, for self-signed, trust the CA rather than disabling verification.

## 3. Exposure posture

MinIO's S3 API binds every interface by default: `--address` defaults to `:9000` (all IPv4 and IPv6 addresses), so a default install is reachable from any network the host is on, not loopback-only. Bind it explicitly with `--address 127.0.0.1:9000` (or a private address), and expose public access only via the TLS endpoints above or behind a proxy/tunnel ([nginx.md](nginx.md), [cloudflare.md](cloudflare.md)). The web console is a second listener, configured independently of the S3 API: MinIO serves its embedded console on the address set by `--console-address` (env `MINIO_CONSOLE_ADDRESS`), and left unset it picks a free port at startup and prints the console URL in its log. A console address with no host, whether the default or an explicit `:9001`, binds every interface even when the S3 API is bound to loopback, so the console can be reachable while the API is not. Bind it explicitly with `--console-address 127.0.0.1:9001` (or a private address), keep it off the public internet, and give human logins MFA at the fronting layer ([mfa.md](mfa.md)). Buckets are private unless a policy says otherwise; before exposing anything, inspect every bucket's full anonymous policy with `mc anonymous get-json ALIAS/BUCKET` (it shows the download and upload grants, resource prefixes, and conditions; the GET probes below cannot audit upload permissions or untested objects and prefixes) and remove any unintended anonymous access.

### 3.1. Disable the embedded Console when unnecessary

Once Console-based setup is complete, disable the embedded Console if administration uses `mc` or other API clients. Add this to the protected server environment file on every node and restart AIStor:

```dotenv
MINIO_BROWSER="off"
```

`MINIO_BROWSER_REDIRECT` controls automatic browser redirection to the Console; disabling redirection does not disable the Console. Use `MINIO_BROWSER` for that control. Source: [AIStor Console settings](https://docs.min.io/aistor/reference/aistor-server/settings/console/).

### 3.2. Set a workload-sized API concurrency budget

The automatic request budget is based on available host RAM. If it exceeds what the deployment's storage, CPU, or workload can sustain, configure an explicit value in the server environment on every node and restart AIStor:

```dotenv
MINIO_API_REQUESTS_MAX="64"
```

This is a cluster-wide budget for concurrent S3 and administrative API requests, divided among the nodes. For example, 64 across four nodes gives a request pool of 16 per node. It is neither requests per second nor a TCP-connection limit. The number is an illustrative workload-sizing choice, not a recommendation: measure representative workloads before selecting it. Source: [AIStor core settings](https://docs.min.io/aistor/reference/aistor-server/settings/core/).

## 4. Create scoped application access

A leaked application key should expose only the application's required objects and operations. Give each application a non-root parent user and its own expiring access key. The built-in `readonly`, `writeonly`, `readwrite`, and `consoleAdmin` policies are broad: the first two allow their respective object operations across the deployment, `readwrite` grants every S3 action, and `consoleAdmin` also grants administrative access. `readonly` does not grant bucket listing.

Create the parent user through the Console's IAM Users screen. The documented `mc admin user add` CLI requires a positional secret and has no stdin secret form, so do not use it to put a password in argv. Give the parent only the required policies; review group memberships too.

Save this custom policy as `/path/to/REPLACE_WITH_APP_POLICY.json`, substituting the same bucket name in both resource entries. It permits bucket listing and object reads and writes in one bucket, with no deletion or administrative grants. Remove any action the application does not need.

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:GetBucketLocation", "s3:ListBucket"],
      "Resource": ["arn:aws:s3:::REPLACE_WITH_APP_BUCKET"]
    },
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject"],
      "Resource": ["arn:aws:s3:::REPLACE_WITH_APP_BUCKET/*"]
    }
  ]
}
```

Configure the administrative alias `mys3` using the stdin import in section 8 before running these commands. Choose an unused policy name and a new output file in an owner-only directory; creating an existing policy name replaces its policy.

```bash
mc admin policy create mys3 app-bucket /path/to/REPLACE_WITH_APP_POLICY.json
mc admin policy attach mys3 app-bucket --user REPLACE_WITH_APP_USER
(
  umask 077
  mc admin accesskey create mys3/ REPLACE_WITH_APP_USER \
    --policy /path/to/REPLACE_WITH_APP_POLICY.json \
    --expiry-duration 24h > /path/to/REPLACE_WITH_NEW_ACCESSKEY_OUTPUT.txt
)
```

The explicit parent username prevents accidentally creating a child of the administrative identity. Omitting the access-key and secret-key options lets AIStor generate the pair. The output contains credentials: transfer them through your secret-management workflow, restrict the file to its owner, and keep it out of logs and version control. Populate the application's alias JSON from that pair using the format in section 8; the creation output is not itself an alias-import document.

The `--policy` document is an inline restriction on the parent's permissions, not an independent grant. It cannot expand access beyond the parent's user and group policies, and its maximum size is 4096 bytes. Check the size after substitution. Arrange rotation before the example's 24-hour expiry; retire the old key through the Console after the application switches.

Identity policies and anonymous bucket policies are separate controls. Review both: a scoped key does not remove an anonymous grant on another bucket.

### 4.1. Map OIDC identities to scoped policies

Authentication does not establish an appropriate authorization boundary. With role-policy mapping, every authentication request using the provider's `RoleArn` receives the configured policies. Assigning a broad policy therefore spreads that access across the identities using that role. Source: [AIStor OIDC access management](https://docs.min.io/aistor/administration/iam/access/oidc-access/).

For an already configured OIDC provider, choose exactly one mapping method. Remove the other method's explicit settings from both the environment and stored configuration; configuring both `role_policy` and `claim_name` is an error. Apply consistent settings across nodes and restart AIStor. The examples below set the default configuration. For a named configuration, append `_` followed by its case-sensitive name to each variable (for example `MINIO_IDENTITY_OPENID_ROLE_POLICY_PARTNERS` for a configuration named `PARTNERS`). When that configuration uses role-policy mapping, have clients supply its `RoleArn` in their STS request. Claim mapping can serve only one OIDC provider per deployment; every other provider must use role-policy mapping. Sources: [AIStor OIDC identity management](https://docs.min.io/aistor/administration/iam/identity/oidc-identity/), [OpenID settings](https://docs.min.io/aistor/reference/aistor-server/settings/iam/openid/) (multiple configurations), and [OIDC access management](https://docs.min.io/aistor/administration/iam/access/oidc-access/).

Use role-policy mapping only when every identity admitted through that role should receive the section 4 application's access:

```dotenv
MINIO_IDENTITY_OPENID_ROLE_POLICY="app-bucket"
```

The `app-bucket` policy must already exist with the intended bucket substitutions. Clients must supply the provider's corresponding `RoleArn` in their STS request. Source: [AIStor OpenID settings](https://docs.min.io/aistor/reference/aistor-server/settings/iam/openid/).

Alternatively, select claim mapping when identities need different policies:

```dotenv
MINIO_IDENTITY_OPENID_CLAIM_NAME="policy"
```

Configure the IdP to issue `"policy": "app-bucket"` only for identities entitled to that policy; other identities receive their own existing, narrowly scoped policy names. Treat this claim as an authorization decision controlled by the IdP administrator. An identity whose token maps to no policy gains no identity-based access; an anonymous bucket policy (sections 3 and 4) still grants its access to anyone. Sources: [AIStor OpenID settings](https://docs.min.io/aistor/reference/aistor-server/settings/iam/openid/), [OIDC identity management](https://docs.min.io/aistor/administration/iam/identity/oidc-identity/), and [OIDC access management](https://docs.min.io/aistor/administration/iam/access/oidc-access/).

Do not describe a short `MINIO_STS_DURATION` as a universal maximum. `AssumeRoleWithWebIdentity` accepts explicit `DurationSeconds` values from 900 through 31536000 seconds (365 days); with a usable JWT expiry, an explicit duration takes precedence over that expiry. `MINIO_STS_DURATION` is a default, not this ceiling. AIStor separately documents the native `sts:DurationSeconds` policy condition for restricting WebIdentity credential duration. Sources: [AssumeRoleWithWebIdentity](https://docs.min.io/aistor/developers/security-token-service/assumerolewithwebidentity/), [STS settings](https://docs.min.io/aistor/reference/aistor-server/settings/iam/sts/), and [access-management condition keys](https://docs.min.io/aistor/administration/iam/access/).

### 4.2. Shorten presigned URLs and cap signature age

A presigned download URL contains access credentials: possession permits its authorized download even when the bucket is private. Generate it with the scoped `app` identity and a short expiry; if the `app` alias does not exist yet, import it from the section 4 access key with the stdin form in section 8 (`mc alias import app < /path/to/REPLACE_WITH_APP_ALIAS.json`). Save the output in a new file inside an owner-only directory, and share the URL through a protected channel:

```bash
(
  umask 077
  set -C
  mc share download --expire 5m \
    app/REPLACE_WITH_APP_BUCKET/REPLACE_WITH_KNOWN_PRIVATE_OBJECT \
    > /path/to/REPLACE_WITH_NEW_SHARE_OUTPUT.txt
)
```

The example requests five minutes instead of `mc share download`'s default seven days. Keep the output out of logs and version control. Source: [AIStor `mc share download`](https://docs.min.io/aistor/reference/cli/mc-share/mc-share-download/).

Add a server-enforced policy restriction as well. AIStor documents support for `s3:signatureAge` and AWS-compatible policy evaluation. The following example uses the referenced S3 semantics: 600000 milliseconds is ten minutes, and `NumericGreaterThan` matches an older signature. Its expected AIStor behaviour remains subject to the REASONED comparison below. Sources: [AIStor access management](https://docs.min.io/aistor/administration/iam/access/) and the supplementary [S3 signature-condition reference](https://docs.aws.amazon.com/AmazonS3/latest/developerguide/bucket-policy-s3-sigv4-conditions.html).

Save this as `/path/to/REPLACE_WITH_SIGNATURE_AGE_POLICY.json`, substituting the section 4 bucket name:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Deny",
      "Action": ["s3:*"],
      "Resource": [
        "arn:aws:s3:::REPLACE_WITH_APP_BUCKET",
        "arn:aws:s3:::REPLACE_WITH_APP_BUCKET/*"
      ],
      "Condition": {
        "NumericGreaterThan": {
          "s3:signatureAge": "600000"
        }
      }
    }
  ]
}
```

Choose an unused policy name; creating an existing name overwrites its policy. Attach the restriction to the existing non-root application parent user, retaining its `app-bucket` grant:

```bash
mc admin policy create mys3 app-signature-age /path/to/REPLACE_WITH_SIGNATURE_AGE_POLICY.json
mc admin policy attach mys3 app-signature-age --user REPLACE_WITH_APP_USER
```

Sources: [AIStor `mc admin policy create`](https://docs.min.io/aistor/reference/cli/admin/mc-admin-policy/mc-admin-policy-create/) and [`mc admin policy attach`](https://docs.min.io/aistor/reference/cli/admin/mc-admin-policy/mc-admin-policy-attach/).

A matching explicit deny overrides an allow. This attachment restricts the governed application identity and its inherited access on the named resources; it is not a deployment-wide ban on older presigned URLs. It does not attach the restriction to unrelated identities or OIDC roles, or remove anonymous grants. Review those separately. Source: [AIStor access management](https://docs.min.io/aistor/administration/iam/access/).

## 5. Encrypt stored data with a key manager

Stolen storage should not yield readable object data or backend credentials. SSE-S3 uses the deployment's default external key; SSE-KMS supports a selected key for a bucket or write request. Both require a configured key manager. Server-side encryption does not replace TLS or access policy.

Use MinIO KMS for new deployments. KES is the supported legacy integration with an external third-party KMS. Configure exactly one of these alternatives in the protected server environment file on every node, normally `/etc/default/minio`. These are file contents, not command-line arguments. Provision the named keys and authorized identities first, trust the key manager's CA, and restart AIStor after applying the settings.

For MinIO KMS, use the actual endpoint, enclave, default key name, and complete API key issued for the enclave identity:

```dotenv
MINIO_KMS_SERVER="https://kms.example.com:7373"
MINIO_KMS_ENCLAVE="REPLACE_WITH_ENCLAVE"
MINIO_KMS_SSE_KEY="REPLACE_WITH_EXISTING_DEFAULT_KEY_NAME"
MINIO_KMS_API_KEY="REPLACE_WITH_KMS_API_KEY"
MINIO_KMS_AUTO_ENCRYPTION="on"
```

For an existing KES integration, the certificate-based alternative is:

```dotenv
MINIO_KMS_KES_ENDPOINT="https://kes.example.com:7373"
MINIO_KMS_KES_KEY_NAME="REPLACE_WITH_EXISTING_DEFAULT_KEY_NAME"
MINIO_KMS_KES_CERT_FILE="/etc/minio/kes/client.crt"
MINIO_KMS_KES_KEY_FILE="/etc/minio/kes/client.key"
MINIO_KMS_KES_CAPATH="/etc/minio/kes/ca.crt"
MINIO_KMS_AUTO_ENCRYPTION="on"
```

Keep the MinIO KMS and KES configurations mutually exclusive. Within KES, the certificate and private-key settings must be supplied together and are mutually exclusive with `MINIO_KMS_KES_API_KEY`. `MINIO_KMS_KES_CAPATH` identifies the CA certificate used to validate the KES server when needed. Protect the API key, client private key, and environment file.

`MINIO_KMS_AUTO_ENCRYPTION` defaults to `on` when a key manager is configured, automatically encrypting new object writes using SSE-KMS. An unconfigured installation does not acquire encryption merely because this default exists. Setting it to `off` disables that automatic object encryption; configure bucket encryption explicitly if doing so.

Choose the required bucket default. For SSE-KMS with an existing key:

```bash
mc encrypt set sse-kms REPLACE_WITH_EXISTING_BUCKET_KEY_NAME mys3/REPLACE_WITH_BUCKET
```

Alternatively, use SSE-S3 with the deployment's default key:

```bash
mc encrypt set sse-s3 mys3/REPLACE_WITH_BUCKET
```

Enabling SSE also encrypts backend data, including IAM and configuration data. Backend encryption cannot be disabled or reset, and normal startup then depends on access to the key manager and the backend key. Preserve that key and test key-manager recovery; changing the automatic-object-encryption setting does not remove this dependency.

Bucket encryption settings affect subsequent writes. They do not rewrite or establish the encryption state of historical objects; inspect existing versions and plan any required migration separately.

## 6. Protect object versions from deletion

Versioning preserves older writes, but an identity with deletion rights can still remove individual versions. Object locking adds retention to protect those versions.

For a new bucket, enable locking and set a default retention period:

```bash
mc mb --with-lock mys3/REPLACE_WITH_NEW_BUCKET
mc retention set --default GOVERNANCE 30d mys3/REPLACE_WITH_NEW_BUCKET
```

`--with-lock` also enables versioning; it does not itself set a retention period. Choose `GOVERNANCE` or `COMPLIANCE` and an `Nd` duration, such as `30d`, according to the required protection.

AIStor `RELEASE.2025-05-20T20-30-00Z` or later can enable object locking on an existing bucket. Enable versioning first if necessary, then set default retention:

```bash
mc version enable mys3/REPLACE_WITH_EXISTING_BUCKET
mc retention set --default GOVERNANCE 30d mys3/REPLACE_WITH_EXISTING_BUCKET
```

The Console does not support this retrofit. Older releases required locking at bucket creation; that is not a blanket limitation of current AIStor.

`GOVERNANCE` permits authorized bypass. Keep `s3:BypassGovernanceRetention` off application identities and their inherited policies. `COMPLIANCE` prevents deletion of the protected version even by root until retention expires; choose its period before applying it.

`--default` ignores the other flags, including `--recursive`, and supplies retention for new objects without an explicit override. It does not protect historical versions. Apply retention to each required existing version and inspect its resulting retain-until date, especially for older data:

```bash
mc retention set --version-id REPLACE_WITH_VERSION_ID GOVERNANCE 30d \
  mys3/REPLACE_WITH_BUCKET/REPLACE_WITH_OBJECT
mc legalhold set --version-id REPLACE_WITH_VERSION_ID \
  mys3/REPLACE_WITH_BUCKET/REPLACE_WITH_OBJECT
```

The second command adds an indefinite legal hold. Only an identity with `s3:PutObjectLegalHold` can set or lift it; keep that permission restricted. A version with both protections remains locked until retention has expired and the legal hold has been lifted.

An ordinary delete can still create a delete marker that hides the object from an unversioned read. Verify the retained version by its exact version ID.

## 7. Publish audit logs outside the object store

Without an independent audit trail, misuse can leave no durable record outside the affected deployment. AIStor publishes no audit logs by default. Configure a remote receiver and protect its authentication, storage, and administrative access; records can contain sensitive request details, hostnames, IP addresses, object names, and headers.

For an authenticated HTTPS webhook, add these settings to the protected server environment file on every node:

```dotenv
MINIO_AUDIT_WEBHOOK_ENABLE="on"
MINIO_AUDIT_WEBHOOK_ENDPOINT="https://audit.example.com/minio/events"
MINIO_AUDIT_WEBHOOK_AUTH_TOKEN="Bearer REPLACE_WITH_RECEIVER_TOKEN"
MINIO_AUDIT_WEBHOOK_TLS_SKIP_VERIFY="false"
MINIO_AUDIT_QUEUE_DIR="/var/lib/minio/audit-queue"
```

The authentication value is sent as supplied; include `Bearer` only when the receiver expects that scheme. Trust the receiver's CA and keep TLS certificate verification enabled.

Alternatively, configure an authenticated Kafka target with credentials limited to the audit topic:

```dotenv
MINIO_AUDIT_KAFKA_ENABLE="on"
MINIO_AUDIT_KAFKA_BROKERS="kafka.example.com:9093"
MINIO_AUDIT_KAFKA_TOPIC="minio-audit"
MINIO_AUDIT_KAFKA_TLS="on"
MINIO_AUDIT_KAFKA_TLS_SKIP_VERIFY="false"
MINIO_AUDIT_KAFKA_SASL="on"
MINIO_AUDIT_KAFKA_SASL_USERNAME="REPLACE_WITH_AUDIT_PRODUCER"
MINIO_AUDIT_KAFKA_SASL_PASSWORD="REPLACE_WITH_KAFKA_PASSWORD"
MINIO_AUDIT_KAFKA_SASL_MECHANISM="plain"
MINIO_AUDIT_QUEUE_DIR="/var/lib/minio/audit-queue"
```

Use the broker's actual TLS listener and supported SASL mechanism. Kafka TLS defaults to `off`, so enable it explicitly; the example uses SASL PLAIN only over verified TLS.

For either target, provision `MINIO_AUDIT_QUEUE_DIR` on persistent storage on each node. The AIStor service account needs read, write, and directory-listing access; restrict other access. Restart AIStor to apply the environment settings.

AIStor retries failed delivery, but events can be permanently lost when the queue fills. Monitor receiver availability, queue capacity, and delivery failures. A webhook 2xx means the receiver acknowledged the request; it does not prove durable storage, and AIStor cannot recover an acknowledged event that the receiver failed to store. Keep receiver retention and deletion rights independent of application access to the object store.

## 8. Verify (REASONED: every unit in this section rests on the local evidence and comparison-specific declarations throughout this section, citing Sources entries including AIStor access management (built-in policies, custom policy structure, actions, and resources); MinIO `mc anonymous get-json` (retrieve a bucket's anonymous policy as JSON to inspect grants, prefixes, and conditions). A live AIStor, KMS, audit receiver, and IdP stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md)

REASONED: only local parsing, shell behaviour and arithmetic were exercised in an offline scratch clone. The eight Bash blocks this section held before this change passed bash -n and ShellCheck 0.11.0 with exit 0 and no output in earlier forms (for the exposure, presigned-URL and Console-disabled blocks, forms before their last guard changes); the three JSON examples in sections 4, 4.2 and 8 parsed with Python json.loads. Those earlier shell runs used mc, curl, and ss stubs, with the two alias-file input paths mapped to a scratch JSON fixture, and the first six blocks printed stub responses and forwarded their placeholders unchanged. Every Bash block here has changed since then. Each refuses with status 2, before it runs any probe, when a value on its `set --` line is missing or unusable or, in the two blocks that list listeners, when ss is not installed. The anonymous S3 probe and console reachability blocks also refuse with status 2 if the `PASTE_WHOLE_BLOCK` marker that opens their `set --` line is missing, as when that line is left out of the paste, printing "paste the whole block, including its set -- line; not probing", or if that line does not carry exactly three values after the marker (the probe) or two (the console block). Both also refuse with status 2 if the host is example.com, example.net, example.org or one of their subdomains, in any letter case, and the console block also refuses a port above 65535. In a shell other than bash, such as dash or busybox sh, where `shopt` does not exist, both refuse with status 2, printing "this block needs bash; run it in bash; not probing", but only once the marker, value-count and host-syntax checks have passed; before that, a missing marker, a wrong value count or an unusable host, such as the shipped placeholders, gets its own message. Each records every classified result and every failed command in one exit status: 0 for a pass or for an observation it says it cannot classify, 1 for a finding and 3 for an inconclusive result, a finding outranking an inconclusive result. The current form of all ten Bash blocks is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite. Stub runs with mc, curl and ss stubs checked each block's guards and its exit status for each classified result, each failed command and inherited readonly, declare -i and set -e, on the current form of eight blocks and on the earlier form of the anonymous S3 probe and console reachability blocks, which lowercased the host with `tr` before refusing reserved names. The records of those two blocks also give stub runs of their current form. Each block's record, which follows the expected results of its comparison, says what its runs covered, and the console reachability block's record says why it cannot report a pass. The live comparisons need AIStor, KMS, a durable audit receiver, and an IdP; a live AIStor, KMS, audit receiver, and IdP stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. Credentials and authenticated STS/S3 and load clients with per-node metrics collection are also required. Sources entries include AIStor access management (built-in policies, custom policy structure, actions, and resources); MinIO `mc anonymous get-json` (retrieve a bucket's anonymous policy as JSON to inspect grants, prefixes, and conditions); each comparison's declaration identifies its specific sources. Stub responses establish argument and stdin handling only; every exposed/fixed service outcome below remains an expectation, not an observation. Substitute deployment-specific values and use harmless private fixtures. Run checks in stages, confirming every expected-success operation before interpreting a denial. A timeout, TLS failure, invalid credential, missing object, or proxy-generated error is not evidence that the intended security control worked.

REASONED in this authoring environment: the existing probes below are retained, but their live outcomes were not demonstrated here. A live AIStor, KMS, audit receiver, and IdP stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md.

REASONED: the alias JSON block below; alias JSON follows the cited mc alias import schema; a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. Python json.loads parsed the five-field alias example; importing and authenticating with these fields still requires a live endpoint. Per the guide's cited AIStor `mc alias import` (stdin and JSON fields). These existing citations were not reopened.

Prepare `/path/to/REPLACE_WITH_ADMIN_ALIAS.json` as an owner-only credential file with these fields:

```json
{
  "url": "https://s3.example.com:9000",
  "accessKey": "REPLACE_WITH_ACCESS_KEY",
  "secretKey": "REPLACE_WITH_SECRET_KEY",
  "api": "s3v4",
  "path": "auto"
}
```

Use root credentials in `mys3` only for the administrative comparisons below. Protect both the imported file and the resulting local `mc` configuration. Importing an alias is configuration, not proof of working authentication; confirm signed operations against MinIO's own endpoint.

```bash
(                                       # a subshell, so the exits below end only the subshell
  command -v ss > /dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
  if ss -tlnp; then   # read every listener; S3 API 9000 and the console (--console-address, ~9001); private unless deliberate
    echo "block exit 0; unclassified observation: this block does not judge listeners, so read every listener above against section 3"; exit 0
  else
    echo "ss -tlnp exit $?: the listener list failed; inconclusive"; exit 3
  fi
)
```

```bash
(                                       # a subshell, so your own script arguments are untouched and the exits below end only the subshell
  set +e                                # errexit off here, so a request that ends nonzero is folded into the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_S3_HOST' 'REPLACE_WITH_BUCKET' 'REPLACE_WITH_PRIVATE_OBJECT'   # the host name MinIO's own S3 API answers on (its direct origin), no scheme, user name, port, path, query, fragment, percent sign or trailing dot; then a bucket name and the key of a known private object in that bucket: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 3 values; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
  case "$1" in
    example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -u nocasematch   # every match below compares letter case exactly again
  case "$2" in
    ""|*REPLACE_WITH_*|*[!abcdefghijklmnopqrstuvwxyz0123456789.-]*) echo "substitute the bucket name (lower-case letters, digits, dots and hyphens) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$3" in
    ""|*REPLACE_WITH_*|/*|*'?'*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute the key of a known private object in that bucket (no leading slash, question mark, hash sign, whitespace or control character) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- 0 "$@"                         # the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 0; then the host, bucket and object
  # -S makes curl show an error message if it fails despite -s (cited curl show-error). This guide's assessment: a 000 status beside a "curl: (N) ..." error line means no HTTP response arrived; that is inconclusive, never a denial and never proof of isolation
  set -- "$1" "$2" "$3" "$4" "$(if curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' "https://$2:9000/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # service root: anonymous ListBuckets denied
  set -- "$1" "$2" "$3" "$4" "${5##*$'\n'}" "${5%%$'\n'*}"   # curl's exit status, then the HTTP code
  printf '%s\n' "$6"
  case "$5:$6" in
    0:403) ;;
    0:2??) echo "FINDING: the service root answered $6 to an anonymous request, so anonymous ListBuckets is allowed"; set -- 1 "${@:2}" ;;
    0:*) echo "HTTP $6 from the service root is neither the 403 denial nor a 2xx finding; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
    *) echo "curl exit $5: no HTTP response from the service root; inconclusive, never a denial"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
  esac
  set -- "$1" "$2" "$3" "$4" "$(if curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' "https://$2:9000/$3/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # per bucket: anonymous listing denied
  set -- "$1" "$2" "$3" "$4" "${5##*$'\n'}" "${5%%$'\n'*}"   # curl's exit status, then the HTTP code
  printf '%s\n' "$6"
  case "$5:$6" in
    0:403) ;;
    0:2??) echo "FINDING: the bucket answered $6 to an anonymous listing request, so anonymous listing is allowed"; set -- 1 "${@:2}" ;;
    0:*) echo "HTTP $6 from the bucket is neither the 403 denial nor a 2xx finding (a 404 means the bucket name is wrong); inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
    *) echo "curl exit $5: no HTTP response for the bucket listing; inconclusive, never a denial"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
  esac
  set -- "$1" "$2" "$3" "$4" "$(if curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' "https://$2:9000/$3/$4"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "$4" "${5##*$'\n'}" "${5%%$'\n'*}"   # curl's exit status, then the HTTP code
  printf '%s\n' "$6"                                     # a known private object: 403, never 200, and the 403 must come from MinIO (behind a proxy a 403 may be the proxy's, so probe MinIO's direct origin). Anonymous policies are set per
                                                         # bucket, so a denial at the service root does not prove any bucket is private
  case "$5:$6" in
    0:403) ;;
    0:2??) echo "FINDING: the known private object answered $6 to an anonymous read"; set -- 1 "${@:2}" ;;
    0:*) echo "HTTP $6 from the known private object is neither the 403 denial nor a 2xx finding (a 404 means the key or bucket is wrong); inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
    *) echo "curl exit $5: no HTTP response for the known private object; inconclusive, never a denial"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
  esac
  echo "block exit $1; a 403 counts as MinIO's denial here only because the host is MinIO's direct origin, so confirm that yourself, and review every full anonymous policy as section 3 describes"
  exit "$1"
)
```

```bash
(                                       # a subshell, so your own script arguments are untouched and the exits below end only the subshell
  set +e                                # errexit off here, so a failed request is classified below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_S3_HOST' 'REPLACE_WITH_CONSOLE_PORT'   # the same host name as the block above, then the ACTUAL console port from ss in the first block (or the startup-log URL), not a guessed 9001 (an unset --console-address picks a random port): replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
  case "$1" in
    example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -u nocasematch   # every match below compares letter case exactly again
  case "$2" in
    ""|*REPLACE_WITH_*|*[!0123456789]*|0*|??????*) echo "substitute the console port, digits only, inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  [ "$2" -le 65535 ] || { echo "the console port must be at most 65535; not probing"; exit 2; }
  set -- "$1" "$2" "$(if curl -q -g -sS -o /dev/null --noproxy '*' -w '%{http_code}\n' "https://$1:$2/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # console: any response from outside, not only 200, means it is reachable; a refusal, timeout, or TLS error is NOT proof of isolation
  set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"   # curl's exit status, then the HTTP code
  printf '%s\n' "$4"
  case "$4" in
    [123456789][0123456789][0123456789]) echo "FINDING: the console port answered HTTP $4 from this vantage, so the Console is reachable from here, which is a finding unless you exposed it here on purpose; block exit 1"; exit 1 ;;
    *) echo "curl exit $3: no HTTP response from the console port; a refusal, timeout, or TLS error is NOT proof of isolation, so this block cannot report a pass; block exit 3, inconclusive: judge the Console's exposure from the listener inventory and your network policy"; exit 3 ;;
  esac
)
```

For the exposure probes, an anonymous grant can produce successful listing or object reads; the private configuration must deny those operations at MinIO itself. Inspect every full anonymous policy as described in section 3, including upload grants. Listener inspection and probes from the relevant external network are both needed to assess console exposure. Sources: server address flags and anonymous-policy references below.

REASONED: the listener inventory block above; listener scope follows the cited server address documentation; a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. This listener inventory was the first line of an earlier exposure block, whose local bash -n and ShellCheck 0.11.0 runs exited 0 without output and whose stub run printed a stub listener table. The current form is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite and by stub runs: a missing ss exits 2, a failing ss exits 3, and a listing exits 0 with a line saying the listeners are not classified. Real listener scope was not observed. Per the guide's cited MinIO/AIStor server address flags (`--address` defaults to `:9000` on all interfaces; `--console-address` / `MINIO_CONSOLE_ADDRESS`: a static port for the embedded console UI, or a dynamic one logged at startup when omitted). This existing citation was not reopened.

REASONED: the anonymous S3 probe block above; anonymous-denial expectations follow the cited anonymous-policy and curl documentation; a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. In an earlier form, before its S3 host, bucket and object moved to a guarded `set --` line and before it classified its results, local bash -n and ShellCheck 0.11.0 exited 0 without output on the exposure block, and its stub run recorded calls covering all four URLs. The current form is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite. Stub runs of the earlier form, which lowercased the S3 host with `tr` before refusing reserved names, showed that a 2xx from any of the three requests exits 1, a 403 from all three exits 0, and any other HTTP status or a curl failure exits 3 unless another request found a 2xx. The current form refuses a reserved name under bash's `nocasematch` option instead of through `tr`, and it refuses with 2, saying the block needs bash, when `shopt` fails, as it does in dash. In curl-stub runs of the current form on 2026-11-01 with no network, bash refused example.com, example.net, example.org and their subdomains in lower, upper and mixed case with 2 and no request, also with `tr` absent from PATH or failing and under an inherited `nocasematch`, `readonly`, `declare -i` or `set -e`. In those runs a host name outside the reserved names reached all three requests. In stub runs of the current form on 2026-11-01 under Bash 5.3.9, dash and busybox sh, a missing `PASTE_WHOLE_BLOCK` marker, with and without caller arguments, and a `set --` line without exactly three values after the marker were refused with status 2, each with its own message and no request. Under dash and busybox sh, stub runs of the current form refused every host name that passed the host-syntax check with 2 and the bash message before any request, and the shipped placeholders with 2 and the host-syntax message. None of the 2026-11-01 runs used zsh, ksh or mksh. Anonymous grants versus MinIO denials were not observed. Per the guide's cited MinIO `mc anonymous get-json` (retrieve a bucket's anonymous policy as JSON to inspect grants, prefixes, and conditions); curl show-error. These existing citations were not reopened.

REASONED: the console reachability block above; console reachability follows the cited server address documentation; a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. This console request was part of the earlier exposure block, whose local bash -n, ShellCheck 0.11.0 and stub runs covered it with a fixed port 9001. The current form takes the console port on its guarded `set --` line and is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite. Stub runs of the earlier form, which lowercased the host with `tr` before refusing reserved names, showed that any HTTP status exits 1 and no HTTP response exits 3. The current form refuses a reserved name under bash's `nocasematch` option instead of through `tr`, and it refuses with 2, saying the block needs bash, when `shopt` fails, as it does in dash. In curl-stub runs of the current form on 2026-11-01 with no network, bash refused example.com, example.net, example.org and their subdomains in lower, upper and mixed case with 2 and no request, also with `tr` absent from PATH or failing and under an inherited `nocasematch`, `readonly`, `declare -i` or `set -e`. In those runs a host name outside the reserved names reached the console request. In stub runs of the current form on 2026-11-01 under Bash 5.3.9, dash and busybox sh, a missing `PASTE_WHOLE_BLOCK` marker, with and without caller arguments, and a `set --` line without exactly two values after the marker were refused with status 2, each with its own message and no request. Under Bash 5.3.9 those runs also refused a port above 65535 with 2, its own message and no request. Under dash and busybox sh, stub runs of the current form refused every host name that passed the host-syntax check with 2 and the bash message before the request, and the shipped placeholders with 2 and the host-syntax message. None of the 2026-11-01 runs used zsh, ksh or mksh. A refusal, timeout or TLS error is not proof of isolation, so that block cannot report a pass; run it only from a network the Console should not reach. Per the guide's cited MinIO/AIStor server address flags (`--address` defaults to `:9000` on all interfaces; `--console-address` / `MINIO_CONSOLE_ADDRESS`: a static port for the embedded console UI, or a dynamic one logged at startup when omitted). This existing citation was not reopened.

**Scoped access, REASONED:** a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. Prepare two different buckets containing known, harmless private objects. The application's policy must name only the application bucket. Build the app alias JSON with the generated scoped key and the same endpoint, `api`, and `path` fields as above.

```bash
(                                       # a subshell, so your own script arguments are untouched and the exits below end only the subshell
  set +e                                # errexit off here, so a command that ends nonzero is folded into the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK '/path/to/REPLACE_WITH_ADMIN_ALIAS.json' '/path/to/REPLACE_WITH_APP_ALIAS.json' 'REPLACE_WITH_APP_BUCKET' 'REPLACE_WITH_OTHER_BUCKET' 'REPLACE_WITH_KNOWN_PRIVATE_OBJECT' 'REPLACE_WITH_UNIQUE_PROBE_OBJECT'   # the root alias file, the app alias file, the app bucket, the other bucket, the known private object's key (present in both buckets) and a new key for the write probe: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 6 ] || { echo "the set -- line needs exactly 6 values; not probing"; exit 2; }
  case "$1|$2" in
    *REPLACE_WITH_*|*[[:cntrl:]]*) echo "substitute both alias file paths inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  [ -f "$1" ] || { echo "the root alias file named on the set -- line above is not a readable regular file; not probing"; exit 2; }
  [ -r "$1" ] || { echo "the root alias file named on the set -- line above is not a readable regular file; not probing"; exit 2; }
  [ -f "$2" ] || { echo "the app alias file named on the set -- line above is not a readable regular file; not probing"; exit 2; }
  [ -r "$2" ] || { echo "the app alias file named on the set -- line above is not a readable regular file; not probing"; exit 2; }
  case "$3" in
    ""|*REPLACE_WITH_*|*[!abcdefghijklmnopqrstuvwxyz0123456789.-]*) echo "substitute the app bucket name (lower-case letters, digits, dots and hyphens) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$4" in
    ""|*REPLACE_WITH_*|*[!abcdefghijklmnopqrstuvwxyz0123456789.-]*) echo "substitute the other bucket name (lower-case letters, digits, dots and hyphens) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  [ "$3" != "$4" ] || { echo "the app bucket and the other bucket must be two different buckets; not probing"; exit 2; }
  case "$5|$6" in
    *REPLACE_WITH_*|*[[:cntrl:]]*) echo "substitute both object keys inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$5" in
    ""|/*) echo "substitute the known private object's key, without a leading slash, on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$6" in
    ""|/*) echo "substitute a new key for the write probe, without a leading slash, on the set -- line above; not probing"; exit 2 ;;
  esac
  [ "$5" != "$6" ] || { echo "the write probe needs a new key, not the known private object's; not probing"; exit 2; }
  set -- 0 "$@"                         # the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 0; then the six values above
  mc alias import mys3 < "$2" || { echo "mc alias import mys3 exit $?: the root alias did not import, so the reads below could use an older alias; inconclusive, not reading"; exit 3; }
  mc alias import app < "$3" || { echo "mc alias import app exit $?: the app alias did not import, so the reads below could use an older alias; inconclusive, not reading"; exit 3; }
  mc anonymous get-json "mys3/$4" || { echo "mc anonymous get-json exit $?: the app bucket's anonymous policy was not read; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}"; }
  mc anonymous get-json "mys3/$5" || { echo "mc anonymous get-json exit $?: the other bucket's anonymous policy was not read; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}"; }
  mc cat "mys3/$4/$6" || { echo "mc cat exit $?: root could not read the app bucket's known object, so the denial below cannot be interpreted; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}"; }
  mc cat "mys3/$5/$6" || { echo "mc cat exit $?: root could not read the other bucket's known object, so the denial below cannot be interpreted; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}"; }
  mc cat "app/$4/$6" || { echo "mc cat exit $?: the scoped key could not read its own bucket's known object; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}"; }
  printf '%s\n' 'scoped write probe' | mc pipe "app/$4/$7" || { echo "mc pipe exit $?: the scoped key could not write its probe; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}"; }
  set -- "${@:1:7}" "$(if mc cat "app/$5/$6" 2>&1 > /dev/null; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # MinIO must deny this read
  set -- "${@:1:7}" "${8##*$'\n'}" "${8%$'\n'*}"   # mc's exit status, then its error text
  printf '%s\n' "$9"
  case "$8:$9" in
    0:*) echo "FINDING: the scoped key read the other bucket's known object, so its access reaches beyond the app bucket"; set -- 1 "${@:2}" ;;
    *'Access Denied'*) ;;
    *) echo "mc cat exit $8 without an Access Denied error: the read failed, but not visibly by MinIO's denial; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
  esac
  echo "block exit $1; the anonymous policies printed above are not classified, so confirm they exclude anonymous access to both fixtures"
  exit "$1"
)
```

Confirm the policy reviews exclude anonymous access to both fixtures. Root must read both known objects. The scoped key must read its own fixture and write its probe, but MinIO must deny its read of the other bucket's known object. A root or overly broad application key would read both. A generic denial alone is insufficient: the successful reads establish the objects, endpoint, and working credentials. Sources: access management, access-key creation, `mc cat`, and `mc pipe`.

REASONED: the scoped-access block above; scoped-access comparisons follow the cited access-management and mc documentation; a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. In an earlier form, before the root alias import moved here from the exposure block and before its values moved to a guarded `set --` line, local bash -n and ShellCheck 0.11.0 exited 0 without output on this block and on that import. A fixture alias input and mc stub then recorded alias JSON on stdin, both policy queries, all reads, and the write payload; output was stub responses, not authorization results. The current form is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite and by stub runs: a failed import exits 3 before any read, and a failed policy query, control read or write records 3. In those runs, the scoped key reading the other bucket's object exits 1, and a failure of that read without an Access Denied error records 3. The expected broad-key versus scoped-key outcomes are described above. Per the guide's cited AIStor `mc alias import` (stdin and JSON fields); AIStor access management (built-in policies, custom policy structure, actions, and resources); AIStor `mc cat`; AIStor `mc pipe`. These existing citations were not reopened.

**Encryption, REASONED:** a live AIStor and KMS stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. After configuring a working key manager and the intended bucket default, write a new object without a client encryption override:

```bash
(                                       # a subshell, so your own script arguments are untouched and the exits below end only the subshell
  set +e                                # errexit off here, so a command that ends nonzero is folded into the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_BUCKET' 'REPLACE_WITH_NEW_ENCRYPTION_PROBE'   # the bucket, then a new object key for the encryption probe: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*[!abcdefghijklmnopqrstuvwxyz0123456789.-]*) echo "substitute the bucket name (lower-case letters, digits, dots and hyphens) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$2" in
    ""|*REPLACE_WITH_*|/*|*[[:cntrl:]]*) echo "substitute a new object key, without a leading slash or control character, inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- 0 "$@"                         # the block's status so far: 3 (inconclusive) outranks 0; then the bucket and the key
  mc encrypt info "mys3/$2" || { echo "mc encrypt info exit $?: the bucket's encryption configuration was not read; inconclusive"; set -- 3 "${@:2}"; }
  if printf '%s\n' 'encryption probe' | mc pipe "mys3/$2/$3"; then
    mc stat "mys3/$2/$3" || { echo "mc stat exit $?: the new object's metadata was not read; inconclusive"; set -- 3 "${@:2}"; }
  else
    echo "mc pipe exit $?: the write failed, and a failed write proves neither state; inconclusive, not inspecting"; set -- 3 "${@:2}"
  fi
  echo "block exit $1; the bucket default and the new object's SSE metadata above are not classified, so compare them with the intended configuration and KMS key yourself"
  exit "$1"
)
```

Confirm the bucket default and the newly written object's SSE metadata, including the intended KMS key for SSE-KMS. In a disposable unencrypted comparison deployment with no key manager, a successful ordinary write lacks SSE metadata; after the control is configured, the new write must carry it. A failed write proves neither state. `mc encrypt info` reports bucket configuration, not historical-object encryption, and absence of a bucket rule does not prove plaintext when server-wide automatic encryption applies. Sources: `mc encrypt info`, `mc encrypt set`, `mc stat`, and the MinIO KMS setup guide.

REASONED: the encryption block above; encryption comparison follows the cited KMS, encrypt and stat documentation; a live AIStor and KMS stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. In an earlier form, before its values moved to a guarded `set --` line, local bash -n and ShellCheck 0.11.0 exited 0 without output, and the mc stub recorded encrypt info, the write payload, and stat, printing stub responses. The current form is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite and by stub runs: a failed command records 3, a failed write skips the inspection, and success exits 0 with the SSE metadata left for the reader. Successful unencrypted versus encrypted writes still require the live KMS comparison described above. Per the guide's cited AIStor `mc encrypt info`; AIStor `mc stat` (metadata and specific-version inspection); AIStor MinIO KMS setup (environment settings, backend dependency, and object verification). These existing citations were not reopened.

**Retention, REASONED:** a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. Use a newly created disposable bucket with locking enabled and no default retention. Stop if creation or either write fails. These fixtures compare an unlocked version with a protected version under the same root identity.

```bash
(                                       # a subshell, so your own script arguments are untouched and the exits below end only the subshell
  set +e                                # errexit off here, so a command that ends nonzero is folded into the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_NEW_RETENTION_TEST_BUCKET'   # a new bucket name for this test: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*[!abcdefghijklmnopqrstuvwxyz0123456789.-]*) echo "substitute a new bucket name (lower-case letters, digits, dots and hyphens) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- 0 "$1"                         # the block's status so far: 3 (inconclusive) outranks 0; then the bucket
  mc mb --with-lock "mys3/$2" || { echo "mc mb exit $?: the locked test bucket was not created; stop, block exit 3, inconclusive"; exit 3; }
  printf '%s\n' 'unlocked control' | mc pipe "mys3/$2/control.txt" || { echo "mc pipe exit $?: the control write failed; inconclusive"; set -- 3 "$2"; }
  printf '%s\n' 'retained probe' | mc pipe "mys3/$2/protected.txt" || { echo "mc pipe exit $?: the protected write failed; inconclusive"; set -- 3 "$2"; }
  [ "$1" = 0 ] || { echo "block exit 3; stop: a write failed, so there are no version IDs to record"; exit 3; }
  mc stat "mys3/$2/control.txt" || { echo "mc stat exit $?: the control object was not inspected; inconclusive"; set -- 3 "$2"; }
  mc stat "mys3/$2/protected.txt" || { echo "mc stat exit $?: the protected object was not inspected; inconclusive"; set -- 3 "$2"; }
  echo "block exit $1; the version IDs above are not classified: record them for the next block"
  exit "$1"
)
```

Record the exact version IDs from the successful object inspections. Substitute them below. The protected fixture receives a one-day COMPLIANCE lock and cannot be deleted early, including by root.

```bash
(                                       # a subshell, so your own script arguments are untouched and the exits below end only the subshell
  set +e                                # errexit off here, so a command that ends nonzero is folded into the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_NEW_RETENTION_TEST_BUCKET' 'REPLACE_WITH_PROTECTED_VERSION' 'REPLACE_WITH_CONTROL_VERSION'   # the test bucket, then the protected and control version IDs recorded above: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 3 values; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*[!abcdefghijklmnopqrstuvwxyz0123456789.-]*) echo "substitute the test bucket name (lower-case letters, digits, dots and hyphens) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$2|$3" in
    *REPLACE_WITH_*|*[[:space:][:cntrl:]]*) echo "substitute both version IDs, without whitespace or control characters, inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  [ -n "$2" ] || { echo "substitute both version IDs on the set -- line above; not probing"; exit 2; }
  [ -n "$3" ] || { echo "substitute both version IDs on the set -- line above; not probing"; exit 2; }
  [ "$2" != "$3" ] || { echo "the protected and control version IDs must differ; not probing"; exit 2; }
  set -- 0 "$@"                         # the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 0; then the bucket and the two version IDs
  mc retention set --version-id "$3" COMPLIANCE 1d \
    "mys3/$2/protected.txt" || { echo "mc retention set exit $?: the protected version's retention was not set; inconclusive"; set -- 3 "${@:2}"; }
  mc retention info --version-id "$3" \
    "mys3/$2/protected.txt" || { echo "mc retention info exit $?: the protected version's retention was not read; inconclusive"; set -- 3 "${@:2}"; }
  mc stat --version-id "$4" \
    "mys3/$2/control.txt" || { echo "mc stat exit $?: the control version was not found; inconclusive"; set -- 3 "${@:2}"; }
  [ "$1" = 0 ] || { echo "block exit 3; stop: the protected version's retention or the control version is not established, so nothing was deleted"; exit 3; }
  mc rm --version-id "$4" \
    "mys3/$2/control.txt" || { echo "mc rm exit $?: deleting the unlocked control failed, so the test has not isolated retention; inconclusive"; set -- 3 "${@:2}"; }
  set -- "${@:1:4}" "$(if mc stat --version-id "$4" \
    "mys3/$2/control.txt" 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "${@:1:4}" "${5##*$'\n'}" "${5%$'\n'*}"   # mc's exit status, then its output
  printf '%s\n' "$6"
  case "$5:$6" in
    0:*) echo "the control version still answers after its delete, so the test has not isolated retention; inconclusive"; set -- 3 "${@:2}" ;;
    *'does not exist'*) ;;
    *) echo "mc stat exit $5 without a does-not-exist error: the control version's absence is not shown; inconclusive"; set -- 3 "${@:2}" ;;
  esac
  # This guide's assessment, not observed on a live server: MinIO refuses this delete with an error saying the object is WORM protected, so a failure without that text is not shown to be the retention refusal
  set -- "${@:1:4}" "$(if mc rm --version-id "$3" \
    "mys3/$2/protected.txt" 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # MinIO must refuse this delete
  set -- "${@:1:4}" "${5##*$'\n'}" "${5%$'\n'*}"   # mc's exit status, then its output
  printf '%s\n' "$6"
  case "$5:$6" in
    0:*) echo "FINDING: the COMPLIANCE-protected version was deleted before its retention expired"; set -- 1 "${@:2}" ;;
    *'WORM protected'*) ;;
    *) echo "mc rm exit $5 without a WORM-protected error: the delete failed, but not visibly by the COMPLIANCE retention refusal; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
  esac
  mc stat --version-id "$3" \
    "mys3/$2/protected.txt" || { echo "mc stat exit $?: the protected version did not answer after the delete attempt; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}"; }
  mc retention info --version-id "$3" \
    "mys3/$2/protected.txt" || { echo "mc retention info exit $?: the protected version's retention was not read after the delete attempt; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}"; }
  echo "block exit $1; the retention output above is not classified, so confirm the protected version still has COMPLIANCE retention with a future retain-until date"
  exit "$1"
)
```

Before deletion, confirm the protected version has COMPLIANCE retention with a future retain-until date and the control version exists. Deleting the unlocked control must succeed, and its subsequent inspection must report that specific version absent. Deleting the protected version must fail, while its subsequent inspection and retention query must still succeed for the same version ID. If both deletes fail, the test has not isolated retention. A delete marker or an unversioned read does not establish whether the retained version survived. Sources: object locking, `mc mb`, `mc retention set`, `mc retention info`, `mc rm`, and `mc stat`.

REASONED: the retention fixture block above, the first of the two retention blocks; retention fixtures follow the cited object-locking and mc documentation; a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. In an earlier form, before its bucket name moved to a guarded `set --` line, local bash -n and ShellCheck 0.11.0 exited 0 without output, and the mc stub recorded bucket creation, both write payloads, and both inspections, printing stub responses. The current form is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite and by stub runs: a failed creation exits 3 before any write, a failed write exits 3 before the inspections, a failed inspection records 3, and success exits 0 with the version IDs left for the reader. Real version IDs and unlocked versus protected versions require the live comparison described above. Per the guide's cited AIStor object locking (existing buckets, Console limitation, retention modes, and delete markers); AIStor `mc mb` (`--with-lock` enables versioning without setting retention); AIStor `mc stat` (metadata and specific-version inspection). These existing citations were not reopened.

REASONED: the exact-version deletion block above; exact-version deletion comparison follows the cited retention, rm and stat documentation; a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. In an earlier form, before its bucket and version IDs moved to a guarded `set --` line, local bash -n and ShellCheck 0.11.0 exited 0 without output, and the mc stub recorded all eight operations with their version selectors and printed stub responses. The current form is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite and by stub runs: a failure before the deletions exits 3 before any delete, and a successful delete of the protected version exits 1. In those runs, a failed control delete, a control version that still answers or fails without a does-not-exist error, a failed delete of the protected version without a WORM-protected error, or a failed later inspection records 3, and the retention output is left for the reader. Actual deletion of the unlocked version and survival of the COMPLIANCE version remain unobserved. Per the guide's cited AIStor `mc retention set` (default retention, existing buckets, ignored flags, and version IDs); AIStor `mc retention info`; AIStor `mc rm` (specific-version deletion); AIStor `mc stat` (metadata and specific-version inspection). These existing citations were not reopened.

**Audit delivery, REASONED:** a live AIStor and durable audit receiver stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. After enabling the chosen target and restarting AIStor, use a unique object name and record the test time. Reuse the proven private object in the forbidden bucket for the denied request.

```bash
(                                       # a subshell, so your own script arguments are untouched and the exits below end only the subshell
  set +e                                # errexit off here, so a command that ends nonzero is folded into the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_APP_BUCKET' 'REPLACE_WITH_UNIQUE_AUDIT_OBJECT' 'REPLACE_WITH_OTHER_BUCKET' 'REPLACE_WITH_KNOWN_PRIVATE_OBJECT'   # the app bucket, a new object key for this test, the other bucket and its proven private object's key: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "the set -- line needs exactly 4 values; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*[!abcdefghijklmnopqrstuvwxyz0123456789.-]*) echo "substitute the app bucket name (lower-case letters, digits, dots and hyphens) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$3" in
    ""|*REPLACE_WITH_*|*[!abcdefghijklmnopqrstuvwxyz0123456789.-]*) echo "substitute the other bucket name (lower-case letters, digits, dots and hyphens) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  [ "$1" != "$3" ] || { echo "the app bucket and the other bucket must be two different buckets; not probing"; exit 2; }
  case "$2|$4" in
    *REPLACE_WITH_*|*[[:cntrl:]]*) echo "substitute both object keys inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$2" in
    ""|/*) echo "substitute a new object key, without a leading slash, on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$4" in
    ""|/*) echo "substitute the proven private object's key, without a leading slash, on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- 0 "$@"                         # the block's status so far: 3 (inconclusive) outranks 0; then the four values above
  printf '%s\n' 'audit delivery probe' | mc pipe "app/$2/$3" || { echo "mc pipe exit $?: the audit write failed; inconclusive"; set -- 3 "${@:2}"; }
  mc cat "app/$2/$3" || { echo "mc cat exit $?: the audit read failed; inconclusive"; set -- 3 "${@:2}"; }
  set -- "${@:1:5}" "$(if mc cat "app/$4/$5" 2>&1 > /dev/null; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # the denied read the receiver must record
  set -- "${@:1:5}" "${6##*$'\n'}" "${6%$'\n'*}"   # mc's exit status, then its error text
  printf '%s\n' "$7"
  case "$6:$7" in
    0:*) echo "the read of the other bucket's object succeeded, so there is no denied request for the receiver to record; inconclusive (the scoped-access block classifies that read as a finding)"; set -- 3 "${@:2}" ;;
    *'Access Denied'*) ;;
    *) echo "mc cat exit $6 without an Access Denied error: the read failed, but not visibly by MinIO's denial; inconclusive"; set -- 3 "${@:2}" ;;
  esac
  echo "block exit $1; this block cannot see the audit receiver, so query its persisted records for these requests yourself: an S3 200 proves nothing about logging"
  exit "$1"
)
```

Query the receiver's persisted records for the matching bucket, object, operation, time, identity, status, and request ID. Confirm records for both the successful operations and the denied read, and confirm they remain available from durable storage, for example after restarting the receiver. With no target configured, these S3 requests can complete without any external audit record. With delivery configured, the matching records must actually be stored at the receiver. An S3 200 proves nothing about logging; a webhook 2xx proves only acknowledgement. Sources: audit logging, webhook delivery, and Kafka delivery.

REASONED: the audit block above; durable delivery comparison follows the cited audit documentation; a live AIStor and durable audit receiver stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. In an earlier form, before its values moved to a guarded `set --` line, local bash -n and ShellCheck 0.11.0 exited 0 without output, and the mc stub recorded the write payload and both reads, printing stub responses. The current form is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite and by stub runs: a failed write or read of the new object records 3, as does a successful read of the other bucket's object or a failure of that read without an Access Denied error. Otherwise it exits 0, because the receiver's records, which are the result, are left for the reader. Missing audit records without a target versus durable matching records with one still require the receiver comparison described above. Per the guide's cited AIStor audit logging (no default destination, queue loss, persistent queue, and event fields); AIStor webhook audit delivery (environment settings and acknowledgement limits); AIStor Kafka audit delivery (environment settings and restart). These existing citations were not reopened.

REASONED: STS request fields, role/claim mapping, unmapped identities, and explicit duration are source reasoning only. Per the guide's cited AIStor OIDC access management (role and claim mapping); AIStor AssumeRoleWithWebIdentity (duration bounds and JWT-expiry precedence). These existing citations were not reopened. A live AIStor and IdP stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. The broad versus scoped reads and longer explicit session described below require an authenticated STS/S3 client and were not run. There is no executable SDK example here to exercise locally. **OIDC authorization, REASONED:** the live AIStor and IdP comparison requires the same unavailable isolation capability. Use two known private fixtures, one in the application bucket and one outside it, and establish administrative reads of both.

Through an STS-capable SDK client, call `AssumeRoleWithWebIdentity` with `Version=2011-06-15`, a valid `WebIdentityToken`, and the configured `RoleArn` for role-policy mapping; omit `RoleArn` for claim mapping. Load tokens and returned credentials from protected storage, not command-line arguments or logs. Using the returned access key, secret key, and session token, issue `GetObject` for both fixtures.

In a disposable broad-policy comparison, both reads succeed. After applying `app-bucket` mapping and obtaining fresh credentials, the application read must succeed and the other read must be denied by AIStor. For claim mapping, also test an identity without a mapped policy: it must gain no object access. A failed login alone does not demonstrate scoped authorization. Sources: [AIStor OIDC access management](https://docs.min.io/aistor/administration/iam/access/oidc-access/) and [AssumeRoleWithWebIdentity](https://docs.min.io/aistor/developers/security-token-service/assumerolewithwebidentity/).

For the duration caveat, use a valid JWT expiring in approximately 20 minutes, `MINIO_STS_DURATION=15m`, and an explicit `DurationSeconds=3600` in a disposable deployment without an additional duration-restricting policy. Inspect the returned expiration and repeat the permitted read after JWT expiry but before STS expiry. The documented expectation is credentials lasting approximately one hour, despite the shorter default and JWT lifetime. This demonstrates the limitation of the default, not a failure of bucket scoping. Source: [AIStor AssumeRoleWithWebIdentity](https://docs.min.io/aistor/developers/security-token-service/assumerolewithwebidentity/).

**Presigned URLs, REASONED:** a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. Use a known private fixture and signing credentials that remain valid throughout the comparison. Confirm ordinary signed reads before and after each trial.

Paste whole Bash blocks. Substitute inside the single quotes; values containing a literal apostrophe need proper shell quoting. Disable shell history recording and tracing before handling a real URL. The block keeps the URL out of curl's argv, but does not protect it from history, tracing, or the account owner. This block and the Console-disabled check below print the `exitcode` and `errormsg` write-out variables, which the cited curl manual dates to curl 7.75.0; use curl 7.75.0 or later.

```bash
(
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  set +e                   # errexit off here, so a failed request is classified below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_PRESIGNED_URL' 'REPLACE_WITH_allow_OR_deny'   # the URL, then allow where this GET should succeed (a new URL, the first GET, or the one-hour URL without the deny policy) or deny where it should be refused (the five-minute URL after six minutes, or the one-hour URL after eleven minutes with the deny policy)
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*example.com*|*[[:cntrl:]]*|"") echo "substitute the complete URL without control characters; not probing"; exit 2 ;;
    https://*) ;;
    *) echo "use the deployment HTTPS URL; not probing"; exit 2 ;;
  esac
  case "$2" in
    allow|deny) ;;
    *) echo "substitute allow (this GET should succeed) or deny (this GET should be refused) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- "${1//\\/\\\\}" "$2"
  set -- "${1//\"/\\\"}" "$2"
  set -- "$1" "$2" "$(if printf 'url = "%s"\n' "$1" | curl -q -g -s --noproxy '*' --connect-timeout 5 --max-time 20 \
      -o /dev/null -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' \
      --config -; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"   # curl's exit status, then its write-out line
  printf '%s\n' "$4"
  case "$2:$3:$4" in
    allow:0:http=2*) echo "block exit 0; the GET succeeded, as expected with allow; the comparisons below still need their other GETs"; exit 0 ;;
    deny:0:'http=403 '*) echo "block exit 0; the GET was refused with 403, as expected with deny: correlate that denial with AIStor's own request or audit evidence, which this block cannot see"; exit 0 ;;
    deny:0:http=2*) echo "FINDING: the GET succeeded although this URL should now be refused; block exit 1"; exit 1 ;;
    *:0:*) echo "the HTTP status above is not the result this block classifies for $2; block exit 3, inconclusive"; exit 3 ;;
    *) echo "curl exit $3: no HTTP response, and a network failure establishes neither control; block exit 3, inconclusive"; exit 3 ;;
  esac
)
```

Use URLs generated for the direct AIStor endpoint; do not alter their signed hostname or path.

1. Test a five-minute URL immediately and again after six minutes. The first GET must succeed; the later GET must fail while a newly generated URL succeeds. This isolates URL expiry before the ten-minute signature-age threshold. Source: [AIStor `mc share download`](https://docs.min.io/aistor/reference/cli/mc-share/mc-share-download/).
2. Separately generate a one-hour URL using the same section 4.2 command with `--expire 1h` and a new output filename. Without the deny policy in a disposable comparison, GETs immediately and after eleven minutes should succeed. Repeat with the deny policy attached: the immediate GET should succeed, but a new GET using that URL after eleven minutes should receive an AIStor denial while a fresh URL still succeeds. This distinguishes the signature-age restriction from the URL's own expiry. Sources: [AIStor supported condition keys](https://docs.min.io/aistor/administration/iam/access/) and [S3 signature-condition semantics](https://docs.aws.amazon.com/AmazonS3/latest/developerguide/bucket-policy-s3-sigv4-conditions.html).

Correlate denials with AIStor's own request or audit evidence. A proxy error, expired signing key, missing object, or network failure does not establish either control.

REASONED: the presigned-URL block above; URL expiry and signature-age comparisons follow the cited share-download and policy documentation; a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. Local bash -n and ShellCheck 0.11.0 exited 0 without output. With curl stubbed, the literal placeholder, empty value, embedded placeholder, example.com, control character, HTTP URL, wrong marker, and wrong argument counts printed their guard messages without invoking curl, including a short assignment under set -u. A fixture HTTPS URL reached curl via config stdin, not argv; a backslash/quote fixture was escaped in that input. Both admitted cases printed a stub response. The bash -n, ShellCheck and stub runs recorded here covered the presigned-URL block in an earlier form, whose guard refusals left the subshell with status 0 and which did not classify its request. The current form, which takes allow or deny on its `set --` line, is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite and by stub runs: guard refusals exit 2, a 2xx exits 0 with allow and 1 with deny, a 403 exits 0 with deny, and any other result exits 3. These are local guard and formatting observations, not expiry or signature-age enforcement. Per the guide's cited AIStor `mc share download` (presigned credentials and expiry); AIStor access management (built-in policies, custom policy structure, actions, and resources); AWS S3 signature-condition reference (supplementary semantics for AIStor's documented condition key). These existing citations were not reopened.

**Console disabled, REASONED:** a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. Run this on each AIStor host with permission to inspect its listeners. Supply the direct Console URL established by section 3, without credentials or query parameters, and a proven application object:

```bash
(
  set +e                                # errexit off here, so a command that ends nonzero is folded into the status below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_DIRECT_CONSOLE_HTTPS_URL' 'app/REPLACE_WITH_APP_BUCKET/REPLACE_WITH_KNOWN_PRIVATE_OBJECT' 'REPLACE_WITH_enabled_OR_off'   # the Console URL, the object, then enabled while the Console is still on or off after applying MINIO_BROWSER=off and restarting
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 3 values; not probing"; exit 2; }
  [ -n "$1" ] || { echo "supply both values; not probing"; exit 2; }
  [ -n "$2" ] || { echo "supply both values; not probing"; exit 2; }
  case "$1|$2" in
    *REPLACE_WITH_*|*example.com*|*[[:cntrl:]]*) echo "substitute deployment values without control characters; not probing"; exit 2 ;;
  esac
  case "$1" in
    https://*) ;;
    *) echo "use the deployment HTTPS Console URL; not probing"; exit 2 ;;
  esac
  case "$3" in
    enabled|off) ;;
    *) echo "substitute enabled (the Console is still on) or off (after MINIO_BROWSER=off and a restart) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  command -v ss > /dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
  mc cat "$2" > /dev/null || { echo "signed S3 read failed; stop"; exit 3; }
  set -- 0 "$@"                         # the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 0; a missing ss was refused with 2 above, before anything was recorded; then the three values above
  ss -tlnp || { echo "ss -tlnp exit $?: the listener list failed; inconclusive"; set -- 3 "${@:2}"; }
  set -- "${@:1:4}" "$(if curl -q -g -s --noproxy '*' --connect-timeout 5 --max-time 20 \
    -o /dev/null -w 'http=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$2"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "${@:1:4}" "${5##*$'\n'}" "${5%%$'\n'*}"   # curl's exit status, then its write-out line
  printf '%s\n' "$6"
  case "$6" in                          # the HTTP code from a write-out line that starts http= and three digits, or none when that line is missing or malformed
    'http='[0123456789][0123456789][0123456789]' '*) set -- "${@:1:6}" "${6:5:3}" ;;
    *) set -- "${@:1:6}" none ;;
  esac
  case "$4:$5:$7" in
    *:none) echo "curl exit $5 without a valid http= write-out line: the result of the Console request is unknown; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
    enabled:*:000) echo "no HTTP response from the Console URL while the Console should be on, so its UI is not established; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
    enabled:0:*) ;;
    enabled:*) echo "curl exit $5 after HTTP $7: the request to the Console URL did not complete, so its UI is not established; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
    off:0:000) echo "curl exit 0 with HTTP 000 is not a result this block classifies; inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
    off:*:000) echo "no HTTP response from the Console URL; a failed request to the previous URL alone is insufficient, so this is not classified as a pass" ;;
    off:*) echo "FINDING: the Console URL still answers after MINIO_BROWSER=off"; set -- 1 "${@:2}" ;;
  esac
  echo "block exit $1; the listener table and the Console response are left for you to judge: with off, confirm the running service received MINIO_BROWSER=off and no Console listener remains; with enabled, confirm the response is the Console UI"
  exit "$1"
)
```

With the Console enabled, establish that its UI is served. After applying `MINIO_BROWSER=off` and restarting, confirm that the running service received that setting, the embedded Console listener is absent, and signed S3 reads still succeed. A failed request to the previous URL alone is insufficient. Disabling only `MINIO_BROWSER_REDIRECT` leaves the direct Console available. Sources: [AIStor Console settings](https://docs.min.io/aistor/reference/aistor-server/settings/console/) and [`mc cat`](https://docs.min.io/aistor/reference/cli/mc-cat/).

REASONED: the Console-disabled block above; Console disablement follows the cited Console settings; a live AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. Local bash -n and ShellCheck 0.11.0 exited 0 without output. With mc, ss, and curl stubbed, the literal placeholders, either empty value, embedded placeholder, example.com, control character, HTTP URL, wrong marker, and wrong argument counts printed guard messages without external calls, including a short assignment under set -u. Valid fixtures called mc, ss, and curl in order and printed stub listener/curl responses; a failing mc printed signed S3 read failed; stop, exited 1, and called neither ss nor curl. The bash -n, ShellCheck and stub runs recorded here covered the Console-disabled block in an earlier form, whose guard refusals left the subshell with status 0 and whose failed signed read exited 1. The current form, which takes enabled or off on its `set --` line, is covered by the bash -n and ShellCheck 0.11.0 passes of the repository's gate suite and by stub runs: guard refusals and a missing ss exit 2 before any call, a failed signed read exits 3, and a failed ss or a missing or malformed curl write-out line records 3. In those runs, with off an HTTP status from the Console URL exits 1 and a failed request with no HTTP response is left unclassified at 0, and with enabled a failed request or no HTTP response records 3. Enabled versus disabled Console behaviour still requires the live comparison described above. Per the guide's cited AIStor Console settings (disablement and browser redirection); AIStor `mc cat`. These existing citations were not reopened.

REASONED: load admission and metrics interpretation are source reasoning only. Per the guide's cited AIStor core settings (automatic and explicit cluster-wide concurrency budgets); AIStor metrics v3 (active and queued requests). These existing citations were not reopened. Local Python arithmetic returned 16 for 64/4 and 32 for 128/4; a live four-node AIStor stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. The live comparison also requires an authenticated load client and per-node metrics collection. More than 16 admitted requests per node under automatic sizing versus pools constrained to 16 under the explicit budget remains an unobserved comparison. **API concurrency, REASONED:** the live multi-node AIStor comparison requires the same unavailable isolation capability. In a disposable four-node deployment, compare automatic sizing with the illustrative explicit budget of 64. Verify the effective setting on every node after restart.

Have the load client issue signed `GetObject` requests for `REPLACE_WITH_APP_BUCKET/REPLACE_WITH_LARGE_PRIVATE_FIXTURE`, first individually, then with 128 concurrent requests distributed evenly across the four nodes. Use sufficiently long transfers to observe simultaneous processing. Keep credentials in the client's protected credential store.

The automatic comparison must actually admit more than 16 simultaneous requests per node to discriminate this example. With the explicit budget, expect the per-node request pools to constrain admission to 16; client concurrency or throughput alone cannot establish enforcement. Source: [AIStor core settings](https://docs.min.io/aistor/reference/aistor-server/settings/core/).

Record `minio_api_requests_inflight_total` and `minio_api_requests_waiting_total` by server, alongside client outcomes and latency. Account for concurrent administrative traffic. If the client, network, or storage cannot saturate the pools, record the comparison as inconclusive. Do not infer an RPS limit or require an undocumented HTTP rejection code. Source: [AIStor metrics v3 reference](https://docs.min.io/aistor/operations/monitoring/metrics-and-alerts/metrics-v3/).

REASONED from the cited AIStor documentation: the exposure probes and all four service checks against exposed and fixed states on live AIStor with `mc`, a KMS, and an independent durable audit receiver; record versions, commands, outcomes, and receiver evidence. A live AIStor, KMS, and durable audit receiver stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md.

REASONED from the cited AIStor documentation: OIDC role-policy and claim-policy scoping, including an unmapped identity and explicit STS duration overriding a shorter default and JWT expiry; five-minute presigned-URL expiry and independent signature-age denial before a longer URL expires. Embedded Console disablement with successful S3 access and a redirect-only comparison, and cluster-wide API concurrency budgeting divided among nodes under measured load, are likewise REASONED from the cited AIStor documentation. Add an IdP, authenticated STS/S3 test client, load client, and per-node metrics collection to the existing prerequisites. Record AIStor and client RELEASE tags, redacted requests, effective settings, positive controls, denials, timing, listener evidence, and load measurements. A live AIStor and IdP stand-up opens listeners; the authoring host forbids that without an isolated network namespace, recorded as unavailable in DECISIONS.md and sqlite.md. All four additions are REASONED, not demonstrated.

## Sources (checked September 2026)

- AIStor root credential files and file-variable precedence: https://docs.min.io/aistor/reference/aistor-server/settings/root-credentials/ and https://docs.min.io/aistor/reference/aistor-server/settings/#file-based-environment-variables
- MinIO network encryption (certs directory, public.crt/private.key, --certs-dir): https://docs.min.io/aistor/installation/linux/network-encryption/
- MinIO: https://www.min.io/
- MinIO community repository (archived 2026-04-25, successor editions): https://github.com/minio/minio
- MinIO `mc anonymous set` (anonymous policies are set per bucket or prefix, cover download and upload, and permit actions without authentication): https://docs.min.io/aistor/reference/cli/mc-anonymous/mc-anonymous-set/
- MinIO `mc anonymous get-json` (retrieve a bucket's anonymous policy as JSON to inspect grants, prefixes, and conditions): https://docs.min.io/aistor/reference/cli/mc-anonymous/mc-anonymous-get-json/
- MinIO/AIStor server address flags (`--address` defaults to `:9000` on all interfaces; `--console-address` / `MINIO_CONSOLE_ADDRESS`: a static port for the embedded console UI, or a dynamic one logged at startup when omitted): https://docs.min.io/aistor/reference/aistor-server/
- MinIO console listener in the server source (`--console-address` and its `MINIO_CONSOLE_ADDRESS` env var in `cmd/server-main.go`; `cmd/common-main.go` binds all interfaces when the host is omitted): https://github.com/minio/minio/blob/f0b91e5504663c4672da451877857b57c3345295/cmd/common-main.go
- AIStor identity and access management (root defaults and child access keys): https://docs.min.io/aistor/administration/iam/
- AIStor Console security and access (user creation and key rotation): https://docs.min.io/aistor/administration/console/security-and-access/
- AIStor access management (built-in policies, custom policy structure, actions, and resources): https://docs.min.io/aistor/administration/iam/access/
- AIStor `mc admin user add` (positional secret): https://docs.min.io/aistor/reference/cli/admin/mc-admin-user/mc-admin-user-add/
- AIStor `mc admin policy create`: https://docs.min.io/aistor/reference/cli/admin/mc-admin-policy/mc-admin-policy-create/
- AIStor `mc admin policy attach`: https://docs.min.io/aistor/reference/cli/admin/mc-admin-policy/mc-admin-policy-attach/
- AIStor `mc admin accesskey create` (parent, generated credentials, expiry duration, and inline-policy limit): https://docs.min.io/aistor/reference/cli/admin/mc-admin-accesskey/mc-admin-accesskey-create/
- AIStor `mc alias import` (stdin and JSON fields): https://docs.min.io/aistor/reference/cli/mc-alias/mc-alias-import/
- AIStor server-side encryption (SSE types and key-manager choices): https://docs.min.io/aistor/installation/linux/server-side-encryption/
- AIStor encryption settings (MinIO KMS, KES credentials, and conditional automatic encryption): https://docs.min.io/aistor/reference/aistor-server/settings/server-side-encryption/
- AIStor MinIO KMS setup (environment settings, backend dependency, and object verification): https://docs.min.io/aistor/installation/linux/server-side-encryption/aistor-keymanager/
- AIStor KES setup (external KMS, backend IAM/configuration encryption, and startup dependency): https://docs.min.io/aistor/installation/linux/server-side-encryption/minio-key-encryption-service/
- AIStor `mc encrypt set` (SSE-KMS key selection, SSE-S3, and historical objects): https://docs.min.io/aistor/reference/cli/mc-encrypt/mc-encrypt-set/
- AIStor `mc encrypt info`: https://docs.min.io/aistor/reference/cli/mc-encrypt/mc-encrypt-info/
- AIStor object locking (existing buckets, Console limitation, retention modes, and delete markers): https://docs.min.io/aistor/administration/object-locking-and-immutability/
- AIStor `mc mb` (`--with-lock` enables versioning without setting retention): https://docs.min.io/aistor/reference/cli/mc-mb/
- AIStor `mc version enable`: https://docs.min.io/aistor/reference/cli/mc-version/mc-version-enable/
- AIStor `mc retention set` (default retention, existing buckets, ignored flags, and version IDs): https://docs.min.io/aistor/reference/cli/mc-retention/mc-retention-set/
- AIStor `mc retention info`: https://docs.min.io/aistor/reference/cli/mc-retention/mc-retention-info/
- AIStor `mc legalhold set`: https://docs.min.io/aistor/reference/cli/mc-legalhold/mc-legalhold-set/
- AIStor `mc rm` (specific-version deletion): https://docs.min.io/aistor/reference/cli/mc-rm/
- AIStor `mc stat` (metadata and specific-version inspection): https://docs.min.io/aistor/reference/cli/mc-stat/
- AIStor `mc cat`: https://docs.min.io/aistor/reference/cli/mc-cat/
- AIStor `mc pipe`: https://docs.min.io/aistor/reference/cli/mc-pipe/
- AIStor audit logging (no default destination, queue loss, persistent queue, and event fields): https://docs.min.io/aistor/operations/monitoring/audit-logging/
- AIStor webhook audit settings (authentication and certificate verification): https://docs.min.io/aistor/reference/aistor-server/settings/metrics-and-logging/webhook-audit-logs/
- AIStor webhook audit delivery (environment settings and acknowledgement limits): https://docs.min.io/aistor/operations/monitoring/audit-logging/webhook-audit-logging/
- AIStor Kafka audit settings (TLS defaults off and SASL authentication): https://docs.min.io/aistor/reference/aistor-server/settings/metrics-and-logging/kafka-audit-logs/
- AIStor Kafka audit delivery (environment settings and restart): https://docs.min.io/aistor/operations/monitoring/audit-logging/kafka-audit-logging/
- AIStor global audit event queue: https://docs.min.io/aistor/reference/aistor-server/settings/metrics-and-logging/audit-event-queue/
- AIStor Console settings (disablement and browser redirection): https://docs.min.io/aistor/reference/aistor-server/settings/console/
- AIStor core settings (automatic and explicit cluster-wide concurrency budgets): https://docs.min.io/aistor/reference/aistor-server/settings/core/
- AIStor OIDC access management (role and claim mapping): https://docs.min.io/aistor/administration/iam/access/oidc-access/
- AIStor OIDC identity management (mutually exclusive mappings and restart): https://docs.min.io/aistor/administration/iam/identity/oidc-identity/
- AIStor OpenID settings (role policy and claim name): https://docs.min.io/aistor/reference/aistor-server/settings/iam/openid/
- AIStor AssumeRoleWithWebIdentity (duration bounds and JWT-expiry precedence): https://docs.min.io/aistor/developers/security-token-service/assumerolewithwebidentity/
- AIStor STS settings (default duration): https://docs.min.io/aistor/reference/aistor-server/settings/iam/sts/
- AIStor `mc share download` (presigned credentials and expiry): https://docs.min.io/aistor/reference/cli/mc-share/mc-share-download/
- AWS S3 signature-condition reference (supplementary semantics for AIStor's documented condition key): https://docs.aws.amazon.com/AmazonS3/latest/developerguide/bucket-policy-s3-sigv4-conditions.html
- AIStor metrics v3 (active and queued requests): https://docs.min.io/aistor/operations/monitoring/metrics-and-alerts/metrics-v3/
- AIStor release artifacts (server and client RELEASE baselines): https://docs.min.io/aistor/operations/release-artifacts/
- curl curl-8_14_1 (checked October 2026): [-S restores error messages with -s (4-19)](https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/show-error.md#L4-L19); [errormsg and exitcode added in 7.75.0 (75-79)](https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/write-out.md#L75-L79).


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- aistor: AIStor documentation (unknown)
- console: MinIO console source (f0b91e5504663c4672da451877857b57c3345295)
- aws: AWS signature-condition semantics (unknown)
- curl: curl (curl-8_14_1)

Claims (full source mapping in the JSON block below):

- lifecycle (REASONED; aistor, console): Community repository was archived 2026-04-25 and receives no fixes; guide settings target AIStor Free/Enterprise and call for migration.
- root-files (REASONED; aistor): Root credentials come from protected regular 0600 files without whitespace/newlines; set only *_FILE paths, remove overriding direct values and start a fresh process.
- root-default (REASONED; aistor): Without direct credentials or files, root defaults minioadmin/minioadmin; root is administrative and applications need scoped keys.
- tls (REASONED; aistor): public.crt/private.key under HOME/.minio/certs or certs-dir enable HTTPS; clients trust the CA without disabling verification.
- api-bind (REASONED; aistor): API address defaults :9000 across IPv4/IPv6 interfaces; bind explicit loopback/private and expose only intended TLS endpoints.
- console-bind (REASONED; aistor, console): Console address is independent of API binding; unset chooses a logged dynamic port and a hostless address binds wildcard; set explicit private host/port.
- anonymous (REASONED; aistor): Buckets are private unless policy grants access; inspect complete anonymous JSON including uploads, prefixes and conditions, independently of identity policies.
- console-disable (REASONED; aistor): MINIO_BROWSER=off disables embedded Console after restart on every node; disabling browser redirection alone does not.
- concurrency (REASONED; aistor): Automatic API budget follows RAM; REQUESTS_MAX is cluster-wide concurrent S3/admin requests divided among nodes, not RPS or connections; 64 is only an illustrative choice.
- builtin-policies (REASONED; aistor): readonly/writeonly cover deployment-wide object operations; readwrite grants all S3 actions, consoleAdmin adds admin access, and readonly does not list buckets.
- parent (REASONED; aistor): Create a non-root app parent in Console with narrow user/group grants; documented mc admin user add requires a positional secret.
- policy (REASONED; aistor): Custom app policy grants location/list plus object read/write for one bucket, without deletion/admin; remove unused actions and avoid replacing an existing policy inadvertently.
- access-key (REASONED; aistor): Create an explicit-parent generated key with 24h expiry and protected output; inline policy only restricts inherited rights and is limited to 4096 bytes; rotate before expiry.
- alias (REASONED; aistor): Alias import reads protected JSON from stdin; protect imported and mc configuration credentials, and prove authentication with a signed operation.
- oidc-role (REASONED; aistor): RoleArn mapping assigns configured policies to every admitted identity using the role; choose a narrow existing role policy.
- oidc-claim (REASONED; aistor): Claim mapping uses IdP-controlled policy names; role_policy and claim_name are mutually exclusive, named suffixes are case-sensitive, and only one provider can use claim mapping.
- oidc-unmapped (REASONED; aistor): Unmapped identities gain no identity-based access, but anonymous bucket grants still apply.
- sts-duration (REASONED; aistor): WebIdentity explicit DurationSeconds accepts 900-31536000 and can override JWT expiry; MINIO_STS_DURATION is a default, with sts:DurationSeconds available as a policy restriction.
- presign (REASONED; aistor): Presigned URLs are credentials; mc share download defaults seven days, while the example requests five minutes and stores output privately.
- signature-age (REASONED; aistor, aws): Explicit deny for signatureAge above 600000 ms restricts the attached parent identity, not unrelated identities/OIDC/anonymous grants; AIStor behavior is reasoned from supported keys and AWS semantics.
- kms (REASONED; aistor): SSE-S3 uses the default external key and SSE-KMS selects a key; configure MinIO KMS endpoint/enclave/key/API key with trusted CA before restarting.
- kes (REASONED; aistor): Legacy KES supports third-party KMS; use certificate/key together with CAPATH, mutually exclusive with KES API key and with MinIO KMS configuration.
- auto-encryption (REASONED; aistor): AUTO_ENCRYPTION defaults on only with a configured key manager and encrypts new writes using SSE-KMS; off needs explicit bucket encryption.
- bucket-encryption (REASONED; aistor): mc encrypt set selects SSE-KMS key or SSE-S3 default; settings affect subsequent writes, not historical objects or versions.
- backend-encryption (REASONED; aistor): Enabling SSE encrypts IAM/configuration backend data irreversibly; startup depends on retained backend key and key-manager access, regardless of automatic object encryption.
- object-lock (REASONED; aistor): New bucket with-lock enables versioning but no retention duration; AIStor RELEASE.2025-05-20T20-30-00Z+ can retrofit existing versioned buckets, not through Console.
- retention-modes (REASONED; aistor): GOVERNANCE permits authorized bypass; COMPLIANCE prevents protected-version deletion even by root until expiry. Remove bypass permission from application identities.
- retention-default (REASONED; aistor): Default retention ignores other flags including recursive and governs new objects without overrides; explicitly protect historical version IDs and inspect retain-until dates.
- legal-hold (REASONED; aistor): Legal hold is indefinite and requires PutObjectLegalHold to set/lift; both hold release and retention expiry are needed when combined.
- delete-marker (REASONED; aistor): Ordinary deletes can hide retained versions behind a delete marker; verify exact version IDs.
- audit-default (REASONED; aistor): No audit destination is enabled by default; publish sensitive records to independently protected remote storage.
- audit-webhook (REASONED; aistor): Enable HTTPS webhook with authentication value supplied verbatim, certificate verification and persistent audit queue; restart every node.
- audit-kafka (REASONED; aistor): Kafka TLS defaults off; explicitly enable verified TLS and supported SASL with topic-scoped credentials; example PLAIN is only over TLS.
- audit-queue (REASONED; aistor): Persistent per-node queue needs service read/write/list access; delivery retries can lose events when full, and webhook 2xx proves acknowledgement rather than durability.
- verify-exposure (REASONED; aistor, curl): Anonymous service/bucket/object reads must be denied at MinIO with known fixtures; full policy review and actual console-port external probes are independent controls.
- verify-scope (REASONED; aistor): Root reads both known private fixtures; app reads/writes its own bucket but cannot read the other after anonymous grants are excluded.
- verify-encryption (REASONED; aistor): New ordinary write must succeed with intended SSE/key metadata versus a successful unencrypted control; bucket info alone proves no historical-object state.
- verify-retention (REASONED; aistor): Under the same root identity, unlocked exact-version deletion succeeds and COMPLIANCE-protected deletion fails while that version and future retention remain readable.
- verify-audit (REASONED; aistor): Correlate successful write/read and denied read with persisted receiver events and durability; S3 success or webhook acknowledgement alone proves no stored audit.
- verify-oidc (REASONED; aistor): Fresh mapped STS credentials must read only the app fixture versus a broad-policy control; also test an unmapped identity and explicit duration beyond shorter JWT/default.
- verify-url-expiry (REASONED; aistor, curl): Same five-minute URL succeeds immediately and fails after six minutes while a new URL works; protect URL stdin and correlate AIStor denial.
- verify-signature-age (REASONED; aistor, aws, curl): One-hour URL should work after eleven minutes without age denial, fail then with the policy, and still work fresh; exclude expiry and transport errors.
- verify-console (REASONED; aistor, curl): After BROWSER=off restart, verify effective setting, absent Console listener and successful S3 read; redirect-only disablement leaves direct UI available.
- verify-concurrency (REASONED; aistor): Four-node budget 64 should constrain admission to 16 per node under saturating signed load; compare measured inflight/waiting metrics with automatic sizing, not RPS or a guessed rejection code.

````json
{
  "schema": 1,
  "checked": "2026-09-26",
  "documentation_checked": "2026-09",
  "body_sha256": "85740b262253dedbe64449ab7f401420e3f298980c920d0f573476995316c498",
  "components": {
    "aistor": {
      "name": "AIStor documentation",
      "basis": "unknown",
      "sources": {
        "s9719f7f2368e": "https://github.com/minio/minio",
        "s010df9b91c3e": "https://docs.min.io/aistor/reference/aistor-server/settings/root-credentials/",
        "s832ebbd6b12d": "https://docs.min.io/aistor/reference/aistor-server/settings/#file-based-environment-variables",
        "s77cdb5121ee1": "https://docs.min.io/aistor/administration/iam/",
        "s3be1eade5af1": "https://docs.min.io/aistor/administration/iam/access/",
        "s72c067e99d16": "https://docs.min.io/aistor/administration/iam/access/oidc-access/",
        "s2a0ce722d930": "https://docs.min.io/aistor/administration/iam/identity/oidc-identity/",
        "sa62a16f9bfe7": "https://docs.min.io/aistor/installation/linux/network-encryption/",
        "sb9d5614881d7": "https://docs.min.io/aistor/reference/aistor-server/",
        "s410c1a1103fc": "https://docs.min.io/aistor/reference/aistor-server/settings/console/",
        "sedcc92753b24": "https://docs.min.io/aistor/reference/aistor-server/settings/core/",
        "s5e54dfb548ff": "https://docs.min.io/aistor/reference/aistor-server/settings/iam/openid/",
        "sce35ebdaa862": "https://docs.min.io/aistor/reference/aistor-server/settings/iam/sts/",
        "sfc2a9f6aaa82": "https://docs.min.io/aistor/reference/aistor-server/settings/metrics-and-logging/audit-event-queue/",
        "s077155dd0d0a": "https://docs.min.io/aistor/reference/aistor-server/settings/metrics-and-logging/kafka-audit-logs/",
        "s5ffb30993d29": "https://docs.min.io/aistor/reference/aistor-server/settings/metrics-and-logging/webhook-audit-logs/",
        "sd117ab9c22cf": "https://docs.min.io/aistor/reference/aistor-server/settings/server-side-encryption/",
        "sb91d4a3416c9": "https://docs.min.io/aistor/reference/cli/mc-anonymous/mc-anonymous-get-json/",
        "s9e52474eb6af": "https://docs.min.io/aistor/reference/cli/mc-anonymous/mc-anonymous-set/",
        "sdebcaf3c2435": "https://docs.min.io/aistor/administration/console/security-and-access/",
        "s23c3415f6dfd": "https://docs.min.io/aistor/reference/cli/admin/mc-admin-user/mc-admin-user-add/",
        "s5e275951f4af": "https://docs.min.io/aistor/reference/cli/admin/mc-admin-policy/mc-admin-policy-create/",
        "s3bd415ac0205": "https://docs.min.io/aistor/reference/cli/admin/mc-admin-policy/mc-admin-policy-attach/",
        "s6e38b824d6a7": "https://docs.min.io/aistor/reference/cli/admin/mc-admin-accesskey/mc-admin-accesskey-create/",
        "scd10702aba20": "https://docs.min.io/aistor/reference/cli/mc-alias/mc-alias-import/",
        "s53d35aac0c14": "https://docs.min.io/aistor/developers/security-token-service/assumerolewithwebidentity/",
        "s19e2a1dc1a62": "https://docs.min.io/aistor/reference/cli/mc-share/mc-share-download/",
        "s9f3d8a13f89a": "https://docs.min.io/aistor/installation/linux/server-side-encryption/",
        "s725b0aa69279": "https://docs.min.io/aistor/installation/linux/server-side-encryption/aistor-keymanager/",
        "scb4e8f6b45b9": "https://docs.min.io/aistor/installation/linux/server-side-encryption/minio-key-encryption-service/",
        "s7384f2f26863": "https://docs.min.io/aistor/reference/cli/mc-encrypt/mc-encrypt-set/",
        "s6203e074bac7": "https://docs.min.io/aistor/administration/object-locking-and-immutability/",
        "s8d71fab3c175": "https://docs.min.io/aistor/reference/cli/mc-mb/",
        "sbcb4c73423fb": "https://docs.min.io/aistor/reference/cli/mc-version/mc-version-enable/",
        "sd1b52461f1be": "https://docs.min.io/aistor/reference/cli/mc-retention/mc-retention-set/",
        "sf36b2625325e": "https://docs.min.io/aistor/reference/cli/mc-legalhold/mc-legalhold-set/",
        "sb375aff8811f": "https://docs.min.io/aistor/reference/cli/mc-rm/",
        "s7eb5037577a9": "https://docs.min.io/aistor/operations/monitoring/audit-logging/",
        "s624eb11b369c": "https://docs.min.io/aistor/operations/monitoring/audit-logging/kafka-audit-logging/",
        "s8b922d2cc573": "https://docs.min.io/aistor/operations/monitoring/audit-logging/webhook-audit-logging/",
        "s060498cf1d28": "https://docs.min.io/aistor/reference/cli/mc-cat/",
        "s8aab14fd9241": "https://docs.min.io/aistor/reference/cli/mc-pipe/",
        "sa1b121169978": "https://docs.min.io/aistor/reference/cli/mc-encrypt/mc-encrypt-info/",
        "s0c9db42c9d8d": "https://docs.min.io/aistor/reference/cli/mc-stat/",
        "s79346e27156b": "https://docs.min.io/aistor/reference/cli/mc-retention/mc-retention-info/",
        "s4e625044ee38": "https://docs.min.io/aistor/operations/monitoring/metrics-and-alerts/metrics-v3/"
      }
    },
    "console": {
      "name": "MinIO console source",
      "basis": "f0b91e5504663c4672da451877857b57c3345295",
      "sources": {
        "s676cd1d021a2": "https://github.com/minio/minio/blob/f0b91e5504663c4672da451877857b57c3345295/cmd/common-main.go"
      }
    },
    "aws": {
      "name": "AWS signature-condition semantics",
      "basis": "unknown",
      "sources": {
        "s724c81d09245": "https://docs.aws.amazon.com/AmazonS3/latest/developerguide/bucket-policy-s3-sigv4-conditions.html"
      }
    },
    "curl": {
      "name": "curl",
      "basis": "curl-8_14_1",
      "sources": {
        "s07916104bf60": "https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/show-error.md#L4-L19",
        "s5e1383feef7d": "https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/write-out.md#L75-L79"
      }
    }
  },
  "claims": {
    "lifecycle": {"text": "Community repository was archived 2026-04-25 and receives no fixes; guide settings target AIStor Free/Enterprise and call for migration.", "components": ["aistor", "console"], "sources": ["aistor:s9719f7f2368e", "console:s676cd1d021a2"], "status": "REASONED"},
    "root-files": {"text": "Root credentials come from protected regular 0600 files without whitespace/newlines; set only *_FILE paths, remove overriding direct values and start a fresh process.", "components": ["aistor"], "sources": ["aistor:s010df9b91c3e", "aistor:s832ebbd6b12d"], "status": "REASONED"},
    "root-default": {"text": "Without direct credentials or files, root defaults minioadmin/minioadmin; root is administrative and applications need scoped keys.", "components": ["aistor"], "sources": ["aistor:s77cdb5121ee1", "aistor:s3be1eade5af1", "aistor:s72c067e99d16", "aistor:s2a0ce722d930"], "status": "REASONED"},
    "tls": {"text": "public.crt/private.key under HOME/.minio/certs or certs-dir enable HTTPS; clients trust the CA without disabling verification.", "components": ["aistor"], "sources": ["aistor:sa62a16f9bfe7"], "status": "REASONED"},
    "api-bind": {"text": "API address defaults :9000 across IPv4/IPv6 interfaces; bind explicit loopback/private and expose only intended TLS endpoints.", "components": ["aistor"], "sources": ["aistor:sb9d5614881d7", "aistor:s832ebbd6b12d", "aistor:s410c1a1103fc", "aistor:sedcc92753b24", "aistor:s5e54dfb548ff", "aistor:sce35ebdaa862", "aistor:sfc2a9f6aaa82", "aistor:s077155dd0d0a", "aistor:s5ffb30993d29", "aistor:s010df9b91c3e", "aistor:sd117ab9c22cf"], "status": "REASONED"},
    "console-bind": {"text": "Console address is independent of API binding; unset chooses a logged dynamic port and a hostless address binds wildcard; set explicit private host/port.", "components": ["aistor", "console"], "sources": ["aistor:sb9d5614881d7", "aistor:s832ebbd6b12d", "aistor:s410c1a1103fc", "aistor:sedcc92753b24", "aistor:s5e54dfb548ff", "aistor:sce35ebdaa862", "aistor:sfc2a9f6aaa82", "aistor:s077155dd0d0a", "aistor:s5ffb30993d29", "aistor:s010df9b91c3e", "aistor:sd117ab9c22cf", "console:s676cd1d021a2"], "status": "REASONED"},
    "anonymous": {"text": "Buckets are private unless policy grants access; inspect complete anonymous JSON including uploads, prefixes and conditions, independently of identity policies.", "components": ["aistor"], "sources": ["aistor:sb91d4a3416c9", "aistor:s9e52474eb6af"], "status": "REASONED"},
    "console-disable": {"text": "MINIO_BROWSER=off disables embedded Console after restart on every node; disabling browser redirection alone does not.", "components": ["aistor"], "sources": ["aistor:s410c1a1103fc"], "status": "REASONED"},
    "concurrency": {"text": "Automatic API budget follows RAM; REQUESTS_MAX is cluster-wide concurrent S3/admin requests divided among nodes, not RPS or connections; 64 is only an illustrative choice.", "components": ["aistor"], "sources": ["aistor:sedcc92753b24"], "status": "REASONED"},
    "builtin-policies": {"text": "readonly/writeonly cover deployment-wide object operations; readwrite grants all S3 actions, consoleAdmin adds admin access, and readonly does not list buckets.", "components": ["aistor"], "sources": ["aistor:s3be1eade5af1", "aistor:s72c067e99d16"], "status": "REASONED"},
    "parent": {"text": "Create a non-root app parent in Console with narrow user/group grants; documented mc admin user add requires a positional secret.", "components": ["aistor"], "sources": ["aistor:sdebcaf3c2435", "aistor:s23c3415f6dfd"], "status": "REASONED"},
    "policy": {"text": "Custom app policy grants location/list plus object read/write for one bucket, without deletion/admin; remove unused actions and avoid replacing an existing policy inadvertently.", "components": ["aistor"], "sources": ["aistor:s3be1eade5af1", "aistor:s72c067e99d16", "aistor:s5e275951f4af", "aistor:s3bd415ac0205"], "status": "REASONED"},
    "access-key": {"text": "Create an explicit-parent generated key with 24h expiry and protected output; inline policy only restricts inherited rights and is limited to 4096 bytes; rotate before expiry.", "components": ["aistor"], "sources": ["aistor:s6e38b824d6a7"], "status": "REASONED"},
    "alias": {"text": "Alias import reads protected JSON from stdin; protect imported and mc configuration credentials, and prove authentication with a signed operation.", "components": ["aistor"], "sources": ["aistor:scd10702aba20"], "status": "REASONED"},
    "oidc-role": {"text": "RoleArn mapping assigns configured policies to every admitted identity using the role; choose a narrow existing role policy.", "components": ["aistor"], "sources": ["aistor:s72c067e99d16", "aistor:s5e54dfb548ff"], "status": "REASONED"},
    "oidc-claim": {"text": "Claim mapping uses IdP-controlled policy names; role_policy and claim_name are mutually exclusive, named suffixes are case-sensitive, and only one provider can use claim mapping.", "components": ["aistor"], "sources": ["aistor:s2a0ce722d930", "aistor:s5e54dfb548ff"], "status": "REASONED"},
    "oidc-unmapped": {"text": "Unmapped identities gain no identity-based access, but anonymous bucket grants still apply.", "components": ["aistor"], "sources": ["aistor:s72c067e99d16"], "status": "REASONED"},
    "sts-duration": {"text": "WebIdentity explicit DurationSeconds accepts 900-31536000 and can override JWT expiry; MINIO_STS_DURATION is a default, with sts:DurationSeconds available as a policy restriction.", "components": ["aistor"], "sources": ["aistor:s53d35aac0c14", "aistor:sce35ebdaa862", "aistor:s3be1eade5af1", "aistor:s72c067e99d16"], "status": "REASONED"},
    "presign": {"text": "Presigned URLs are credentials; mc share download defaults seven days, while the example requests five minutes and stores output privately.", "components": ["aistor"], "sources": ["aistor:s19e2a1dc1a62"], "status": "REASONED"},
    "signature-age": {"text": "Explicit deny for signatureAge above 600000 ms restricts the attached parent identity, not unrelated identities/OIDC/anonymous grants; AIStor behavior is reasoned from supported keys and AWS semantics.", "components": ["aistor", "aws"], "sources": ["aistor:s3be1eade5af1", "aistor:s72c067e99d16", "aws:s724c81d09245"], "status": "REASONED"},
    "kms": {"text": "SSE-S3 uses the default external key and SSE-KMS selects a key; configure MinIO KMS endpoint/enclave/key/API key with trusted CA before restarting.", "components": ["aistor"], "sources": ["aistor:s9f3d8a13f89a", "aistor:s725b0aa69279", "aistor:scb4e8f6b45b9"], "status": "REASONED"},
    "kes": {"text": "Legacy KES supports third-party KMS; use certificate/key together with CAPATH, mutually exclusive with KES API key and with MinIO KMS configuration.", "components": ["aistor"], "sources": ["aistor:sd117ab9c22cf", "aistor:scb4e8f6b45b9"], "status": "REASONED"},
    "auto-encryption": {"text": "AUTO_ENCRYPTION defaults on only with a configured key manager and encrypts new writes using SSE-KMS; off needs explicit bucket encryption.", "components": ["aistor"], "sources": ["aistor:sd117ab9c22cf"], "status": "REASONED"},
    "bucket-encryption": {"text": "mc encrypt set selects SSE-KMS key or SSE-S3 default; settings affect subsequent writes, not historical objects or versions.", "components": ["aistor"], "sources": ["aistor:s7384f2f26863"], "status": "REASONED"},
    "backend-encryption": {"text": "Enabling SSE encrypts IAM/configuration backend data irreversibly; startup depends on retained backend key and key-manager access, regardless of automatic object encryption.", "components": ["aistor"], "sources": ["aistor:s725b0aa69279", "aistor:scb4e8f6b45b9"], "status": "REASONED"},
    "object-lock": {"text": "New bucket with-lock enables versioning but no retention duration; AIStor RELEASE.2025-05-20T20-30-00Z+ can retrofit existing versioned buckets, not through Console.", "components": ["aistor"], "sources": ["aistor:s6203e074bac7", "aistor:s8d71fab3c175", "aistor:sbcb4c73423fb"], "status": "REASONED"},
    "retention-modes": {"text": "GOVERNANCE permits authorized bypass; COMPLIANCE prevents protected-version deletion even by root until expiry. Remove bypass permission from application identities.", "components": ["aistor"], "sources": ["aistor:s6203e074bac7"], "status": "REASONED"},
    "retention-default": {"text": "Default retention ignores other flags including recursive and governs new objects without overrides; explicitly protect historical version IDs and inspect retain-until dates.", "components": ["aistor"], "sources": ["aistor:sd1b52461f1be"], "status": "REASONED"},
    "legal-hold": {"text": "Legal hold is indefinite and requires PutObjectLegalHold to set/lift; both hold release and retention expiry are needed when combined.", "components": ["aistor"], "sources": ["aistor:sf36b2625325e"], "status": "REASONED"},
    "delete-marker": {"text": "Ordinary deletes can hide retained versions behind a delete marker; verify exact version IDs.", "components": ["aistor"], "sources": ["aistor:s6203e074bac7", "aistor:sb375aff8811f"], "status": "REASONED"},
    "audit-default": {"text": "No audit destination is enabled by default; publish sensitive records to independently protected remote storage.", "components": ["aistor"], "sources": ["aistor:s7eb5037577a9", "aistor:s624eb11b369c", "aistor:s8b922d2cc573"], "status": "REASONED"},
    "audit-webhook": {"text": "Enable HTTPS webhook with authentication value supplied verbatim, certificate verification and persistent audit queue; restart every node.", "components": ["aistor"], "sources": ["aistor:s5ffb30993d29", "aistor:s8b922d2cc573"], "status": "REASONED"},
    "audit-kafka": {"text": "Kafka TLS defaults off; explicitly enable verified TLS and supported SASL with topic-scoped credentials; example PLAIN is only over TLS.", "components": ["aistor"], "sources": ["aistor:s077155dd0d0a", "aistor:s624eb11b369c"], "status": "REASONED"},
    "audit-queue": {"text": "Persistent per-node queue needs service read/write/list access; delivery retries can lose events when full, and webhook 2xx proves acknowledgement rather than durability.", "components": ["aistor"], "sources": ["aistor:sfc2a9f6aaa82", "aistor:s8b922d2cc573"], "status": "REASONED"},
    "verify-exposure": {"text": "Anonymous service/bucket/object reads must be denied at MinIO with known fixtures; full policy review and actual console-port external probes are independent controls.", "components": ["aistor", "curl"], "sources": ["aistor:sb91d4a3416c9", "aistor:sb9d5614881d7", "aistor:s832ebbd6b12d", "aistor:s410c1a1103fc", "aistor:sedcc92753b24", "aistor:s5e54dfb548ff", "aistor:sce35ebdaa862", "aistor:sfc2a9f6aaa82", "aistor:s077155dd0d0a", "aistor:s5ffb30993d29", "aistor:s010df9b91c3e", "aistor:sd117ab9c22cf", "curl:s07916104bf60"], "status": "REASONED", "verify": [1, 2, 3]},
    "verify-scope": {"text": "Root reads both known private fixtures; app reads/writes its own bucket but cannot read the other after anonymous grants are excluded.", "components": ["aistor"], "sources": ["aistor:s3be1eade5af1", "aistor:s72c067e99d16", "aistor:s060498cf1d28", "aistor:s8aab14fd9241"], "status": "REASONED", "verify": [4]},
    "verify-encryption": {"text": "New ordinary write must succeed with intended SSE/key metadata versus a successful unencrypted control; bucket info alone proves no historical-object state.", "components": ["aistor"], "sources": ["aistor:sa1b121169978", "aistor:s0c9db42c9d8d", "aistor:s725b0aa69279"], "status": "REASONED", "verify": [5]},
    "verify-retention": {"text": "Under the same root identity, unlocked exact-version deletion succeeds and COMPLIANCE-protected deletion fails while that version and future retention remain readable.", "components": ["aistor"], "sources": ["aistor:s79346e27156b", "aistor:sb375aff8811f", "aistor:s0c9db42c9d8d"], "status": "REASONED", "verify": [6, 7]},
    "verify-audit": {"text": "Correlate successful write/read and denied read with persisted receiver events and durability; S3 success or webhook acknowledgement alone proves no stored audit.", "components": ["aistor"], "sources": ["aistor:s7eb5037577a9", "aistor:s624eb11b369c", "aistor:s8b922d2cc573"], "status": "REASONED", "verify": [8]},
    "verify-oidc": {"text": "Fresh mapped STS credentials must read only the app fixture versus a broad-policy control; also test an unmapped identity and explicit duration beyond shorter JWT/default.", "components": ["aistor"], "sources": ["aistor:s72c067e99d16", "aistor:s53d35aac0c14"], "status": "REASONED"},
    "verify-url-expiry": {"text": "Same five-minute URL succeeds immediately and fails after six minutes while a new URL works; protect URL stdin and correlate AIStor denial.", "components": ["aistor", "curl"], "sources": ["aistor:s19e2a1dc1a62", "curl:s5e1383feef7d"], "status": "REASONED", "verify": [9]},
    "verify-signature-age": {"text": "One-hour URL should work after eleven minutes without age denial, fail then with the policy, and still work fresh; exclude expiry and transport errors.", "components": ["aistor", "aws", "curl"], "sources": ["aistor:s3be1eade5af1", "aistor:s72c067e99d16", "aws:s724c81d09245", "curl:s5e1383feef7d"], "status": "REASONED", "verify": [9]},
    "verify-console": {"text": "After BROWSER=off restart, verify effective setting, absent Console listener and successful S3 read; redirect-only disablement leaves direct UI available.", "components": ["aistor", "curl"], "sources": ["aistor:s410c1a1103fc", "aistor:s060498cf1d28", "curl:s5e1383feef7d"], "status": "REASONED", "verify": [10]},
    "verify-concurrency": {"text": "Four-node budget 64 should constrain admission to 16 per node under saturating signed load; compare measured inflight/waiting metrics with automatic sizing, not RPS or a guessed rejection code.", "components": ["aistor"], "sources": ["aistor:sedcc92753b24", "aistor:s4e625044ee38"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
