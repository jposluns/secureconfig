# Full-stack JS frameworks: SvelteKit, Nuxt, Vite

SvelteKit and Nuxt are JavaScript frameworks for web apps with server code; Vite is a build tool. This guide helps your AI assistant deploy them securely, including SvelteKit's loopback bind and proxy trust, no secrets in public config, auth on every server entry point, and no Vite server in production.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/frontend-frameworks.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against SvelteKit adapter-node @sveltejs/adapter-node@5.5.7, SvelteKit routing and hooks documentation @sveltejs/kit@2.70.3, SvelteKit 3.0.0 changelog @sveltejs/kit@3.0.0, Nuxt lockfile v4.0.0, Nuxt documentation 4.x, Nuxt output source v4.0.0, and Vite bind source v8.3.1, plus 4 more recorded bases; 1 further source is pinned to a commit and 4 carry no recorded version. Metadata reviewed 2026-10-18; documentation checked September 2026. The guide records 33 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

SvelteKit, Nuxt, and Vite-based apps built by AI assistants inherit the same traps as [nextjs.md](nextjs.md): a server bind that can default wide open, a proxy that has to be explicitly trusted before secure cookies and correct origins work, and a public-env prefix that ships anything given it straight to the browser. Each framework also has more than one server entry point (endpoints, server routes, load functions), and a check placed in only one of them leaves the others open, exactly as with Next.js layouts versus Server Actions. The server-bind defaults are that SvelteKit's Node adapter binds `0.0.0.0` as of adapter-node 5.5.7, Nuxt's Nitro `node-server` sets no listen host by default so Node listens on all interfaces, and Vite's dev server defaults to `localhost` as of Vite 8.3.1.

## SvelteKit (`adapter-node`)

The built server "will accept connections on `0.0.0.0` using port 3000" by default (host and port as of adapter-node 5.5.7; the port default applies only when `SOCKET_PATH` is unset or empty, and none of this applies when systemd socket activation hands the process a socket); override with `HOST` and `PORT`:

```bash
HOST=127.0.0.1 PORT=3000 node build
```

Behind a reverse proxy, set `ORIGIN` (for example `ORIGIN=https://app.example.com`) so SvelteKit computes the correct origin for redirects and cookies. `PROTOCOL_HEADER` and `HOST_HEADER` (for example `x-forwarded-proto` and `x-forwarded-host`) let it read the real scheme and host from the proxy; the docs caution to set these only behind a trusted reverse proxy, since an untrusted client could otherwise spoof them. `ADDRESS_HEADER` and `XFF_DEPTH` do the same for the client's real IP.

CSRF: `csrf.checkOrigin` (default `true`; deprecated in the pinned `@sveltejs/kit@2.70.3` source, and removed in `@sveltejs/kit@3.0.0`, whose changelog lists the removal in favor of `trustedOrigins`) checks the `Origin` header for a POST, PUT, PATCH, or DELETE form submission whose `Content-Type` is `application/x-www-form-urlencoded`, `multipart/form-data`, or `text/plain`. It verifies that the header matches the server's origin. The pinned type documentation describes the check only for form submissions with those three content types, so do not rely on it for a JSON body or any other content type reaching a `+server.js` endpoint or form action; give those requests their own origin or session check. The pinned type documentation points to `csrf.trustedOrigins` instead: an allowlist (default empty) of specific origins permitted to submit forms cross site; only `'*'` trusts every origin, and that documentation calls it generally not recommended.

Public env: the pinned `@sveltejs/kit@2.70.3` type documentation describes `env.publicPrefix` (default `PUBLIC_`) as the prefix that signals an environment variable is safe to expose to client-side code, and points to `$env/static/public` and `$env/dynamic/public`; treat every variable with that prefix as public and never give a secret that prefix. Keep secrets in modules SvelteKit treats as server-only, either `$env/static/private` / `$env/dynamic/private`, a `.server.js` filename, or anything under `$lib/server/` ([secrets.md](secrets.md)); SvelteKit statically traces import chains and errors if client code imports one, even through a dynamic `import()`.

None of this gates a request for you by default. The pinned SvelteKit load documentation and server/client source show layout and page `load` functions run concurrently unless a child calls `await parent()`, and a layout `load` does not run on every request. A `+layout.server.js` guard therefore cannot be relied on to protect a sibling `+page.server.js` load function before it uses protected data; the routing documentation says `+layout` has no effect on `+server.js`, and the form-actions documentation says actions are exported from `+page.server.js`. SvelteKit page dispatch calls form actions before page loads, so a layout guard cannot be relied on to protect a form action. Guide advice: check the session before protected work in each page load, form action and `+server.js` endpoint, the same pattern as the Next.js Data Access Layer in [nextjs.md](nextjs.md). The pinned hooks documentation describes `handle` in `hooks.server.js` for server requests, including prerendering, and returning a `Response` before `resolve` renders the route. The runtime invokes `handle` after checks that can return first, including cross-origin remote and form requests, hash-routing rejections and rerouted prerendered resources; it therefore does not run for every request received by the SvelteKit server. In adapter-node 5.5.7, client assets and already prerendered pages are served before SSR and do not reach `handle` through that adapter. Guide advice: use `handle` to check the session and block unauthorized SvelteKit requests that reach it; a hook that only redirects unauthenticated page navigation or only attaches identity to `event.locals` leaves directly reached `+server.js` endpoints and form actions open unless they check it. For a client-initiated remote function request, the runtime takes the page path and search from request headers and resolves `event.url`, `route` and `params` in `handle` from that path; the pinned hooks documentation describes these as calling-page fields rather than the generated endpoint. The pinned remote-functions documentation says the same about these `RequestEvent` properties inside remote functions. Both warn never to use these fields to authorize data access because request values can be manipulated. Guide advice: do not rely on those fields alone to decide what is authorized; check the session and enforce authorization for the specific resource where it is served, since a session check alone does not authorize access to that resource. Wire real authentication with an identity provider or library per [oidc-integration.md](oidc-integration.md), not a client-side redirect alone.

## Nuxt (Nitro server routes)

Files under `server/api/`, `server/routes/`, and `server/middleware/` are auto-registered Nitro handlers exported with `defineEventHandler()`, and a handler in `server/middleware/` runs before every other server route. Nuxt ships no built-in authentication. A middleware handler can enforce access if it throws (for example `createError` with a 401 or 403); the Nuxt server directory page says middleware should not return anything or close or respond to the request; in this guide's reading, a response therefore belongs in a route handler. A middleware that only attaches `event.context.auth` for other handlers to read has not enforced anything, and every handler that reads it still has to check it itself:

```ts
// server/api/admin.ts: the route checks for itself; the middleware only sets event.context.auth
export default defineEventHandler((event) => {
  if (!event.context.auth?.user) {
    event.node.res.statusCode = 401
    return { message: 'Not authenticated' }
  }
})
```

Nuxt's production server is Nitro's `node-server` preset (the fallback when no preset is named). It reads the listen host from `NITRO_HOST` or `HOST` with no default (nitropack 2.12.0), so with neither set Node listens on all interfaces. Bind it to loopback behind your reverse proxy with `NITRO_HOST=127.0.0.1`, and set `NITRO_PORT`:

```bash
NITRO_HOST=127.0.0.1 NITRO_PORT=3000 node .output/server/index.mjs
```

`runtimeConfig` splits the same way as Next's env prefix: keys directly on `runtimeConfig` are "only available within server-side"; keys under `runtimeConfig.public` are "also exposed to the client-side." Environment variables override both, using an uppercase `NUXT_` prefix with underscores between key segments: private keys just need `NUXT_` (for example `NUXT_API_SECRET`), public keys need `NUXT_PUBLIC_` (for example `NUXT_PUBLIC_API_BASE`). The docs warn not to "expose runtime config keys to the client-side by either rendering them or passing them to `useState`" even when they are private on the server.

## Vite (dev and preview servers)

Both are development tooling, not a production server: the `vite preview` docs say plainly "do not use this as a production server as it's not designed for it." Deploy the built `dist/` behind a real server, CDN, or your platform's hosting per [paas.md](paas.md) instead.

`server.host` defaults to `'localhost'` (as of Vite 8.3.1); setting it to `true` or `0.0.0.0` makes the dev server listen on all addresses, including the LAN, which is fine for testing from a phone on a trusted network but should not be left on elsewhere. `server.allowedHosts` defaults to `[]`, which still auto-permits localhost, `.localhost`, and IP addresses; setting it to `true` disables the check entirely, and the docs warn this "allows any website to send requests to your dev server through DNS rebinding attacks, allowing them to download your source code and content." Prefer an explicit hostname allowlist over `true`.

## Verify

REASONED: output-path coverage per the cited SvelteKit adapter-node, Nitro and Vite pinned sources; no framework application or production build is available in the authoring environment, so the paths were checked against those sources rather than a built tree. Run from the project root after a production build. The paths below cover default SvelteKit adapter-node output (`build/client` plus the separate `build/prerendered`), Nuxt/Nitro public output (`.output/public`, including copied public assets and prerendered pages), and a plain Vite client build (`dist`, including copied public assets). They exclude adapter-node server output and Nitro `.output/server`.

REASONED: scan coverage and the dist/server classification per the design of the block itself and the cited output-path sources; no real framework production build is available in the authoring environment, so none was scanned. The scan's fixture, syntax and stub checks, none of them on a real build, are listed under Verification record at the end of this section. Before running, adjust the scan block's directory list for your actual adapter, Nitro preset or configured output directories. The block always scans all of `dist`, following symlinks, so it never misses a browser-served file. In a Vite SSR layout, where `dist/server` holds the server build, a result whose matches are all under `dist/server/` is reported as server output rather than as a client leak, and any other result is a FINDING, with its `dist/server/` matches labelled as server output. Confirm that `dist/server` is server-only in your deployment before treating a server-output result as clean. Include any separately deployed static assets and prerendered HTML, and, apart from `dist` (scanned whole, as described above), never select a parent containing server-only output. This file scan does not inspect dynamically rendered HTML or API responses.

REASONED: following block; private-route denial and Host handling, with the proxy cookie and redirect checks in the prose after the next block; the client-secret scan is the next block. No deployed framework application or run outcome is recorded here; expectations are reasoned from the guide and its cited framework documentation. The private-route and spoofed-Host requests take the application's host name once, on a guarded `set --` line that refuses example.com, example.net, example.org and their subdomains. The block exits 1 if `/api/private` answers a 2xx without a session cookie, 3 if it answers anything else but 401 or if either request fails, and otherwise 0; a curl exit 52 on the spoofed-Host request, where the server closes without a response as nginx's `return 444` does, is not a failure. That request pins HTTP/1.1 with `--http1.1`, because exit 52 is curl's HTTP/1.1 reading of that close, and curl may otherwise negotiate HTTP/2 with a listener that sets `http2 on`, as the HTTPS server block in [nginx.md](nginx.md) does. The spoofed-Host result stays for you to judge. It has not been run against a deployment; its syntax and curl-stub checks are listed under Verification record below.

```bash
(                                       # a subshell, so your own script arguments are untouched
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_APP_HOST'   # the deployed application's public host name, no scheme, user name, port, path, query, fragment, percent sign or trailing dot: replace inside the quotes, keeping them
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
  case "$1" in
    ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
  case "$1" in
    example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
  esac
  shopt -u nocasematch   # every match below compares letter case exactly again
  set +e                                # errexit off here, so a request that fails is recorded below instead of ending the block
  set -- "$1" 0                         # the 2nd value is the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 0
  set -- "$1" "$2" "$(if curl -q -g -si -w '\n%{http_code}' "https://$1/api/private"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "${3##*$'\n'}" "${3%$'\n'*}"               # curl's exit status, then the response and its HTTP code
  set -- "$1" "$2" "$3" "${4%$'\n'*}" "${4##*$'\n'}"          # curl's exit status, the response, then the HTTP code
  if [ -n "$4" ]; then printf '%s\n' "${4%%$'\n'*}"; fi      # the status line: 401 with no session cookie, on all three frameworks
  case "$3:$5" in
    0:401) ;;
    0:2??) echo "FINDING: /api/private answered $5 with no session cookie"; set -- "$1" 1 ;;
    0:*) echo "HTTP $5 from /api/private is neither the 401 pass nor a 2xx finding; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
    *) echo "curl exit $3: the /api/private request failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
  esac
  # The spoofed Host header evil.example.com is a deliberately foreign value, so it stays as written.
  set -- "$1" "$2" "$(if curl -q -g -si --http1.1 "https://$1/" -H "Host: evil.example.com"; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "${3##*$'\n'}" "${3%$'\n'*}"               # curl's exit status, then the response
  if [ -n "$4" ]; then printf '%s\n' "${4%%$'\n'*}"; fi      # the deployed application must not trust a spoofed Host
  case "$3" in
    0|52) ;;                            # a status line, or none when the server closes without a response (nginx's return 444 gives curl exit 52 over the HTTP/1.1 that --http1.1 pins above)
    *) echo "curl exit $3: the spoofed-Host request failed; inconclusive"; [ "$2" = 1 ] || set -- "$1" 3 ;;
  esac
  echo "block exit $2; the spoofed-Host status line, or its absence, is not classified, so judge it as the Host paragraph below the next block says"
  exit "$2"
)
```

```bash
# The browser-served paths are the four directory checks at the top of the block; adapt them for custom output or SSR before running.
# Search client assets and prerendered pages for the literal secret with a fixed-string match. The secret is prompted
# (input hidden) and reaches grep on stdin (-f - reads the patterns from stdin), never grep's argv; -l prints only
# file names, so a finding does not echo the secret. -R follows symlinks, so a linked asset is searched too; -D skip
# skips FIFOs, sockets and devices, so a linked pipe cannot stall the scan. Only the listed directories that exist
# are searched; adapter-node can produce two. The block refuses when none exists. grep's exit status is read
# separately, so an inherited `set -e` cannot abort on a clean result: 0 is a finding, 1 is clean, anything else is
# an error, with grep's own diagnostics left visible. A file grep lists alongside an error is classified as with 0,
# so a match outside dist/server/ is still a finding, and the error makes any other result inconclusive. Paste this
# subshell by itself: without bracketed paste, a line pasted after its closing ) becomes the search value instead,
# and its clean result then means nothing.
# The block exits 1 for a finding, 3 if the hidden prompt, ls or grep fails, 2 if a check refuses (no listed
# directory, a readonly name or IFS, or an empty secret), and 0 for a clean or server-output-only result.
(
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  set +x +a +e
  set --                                # the directories to search, kept in the positional parameters rather than a named variable
  if [ -d build/client ]; then set -- "$@" build/client; fi
  if [ -d build/prerendered ]; then set -- "$@" build/prerendered; fi
  if [ -d .output/public ]; then set -- "$@" .output/public; fi
  if [ -d dist ]; then set -- "$@" dist; fi
  [ "$#" -gt 0 ] || { echo 'no listed browser-served output directory here; build first and check the paths; not scanning'; exit 2; }
  { unset -n client_secret && unset -v client_secret; } 2>/dev/null ||
    { echo 'cannot initialize secret input; not scanning'; exit 2; }
  { unset -n IFS; } 2>/dev/null || { echo 'a readonly IFS is set in this shell; not scanning'; exit 2; }
  if IFS= read -r -s -p 'Secret value to search for (input hidden), then Enter: ' client_secret < /dev/tty; then
    printf '\n'
  else
    printf '\n'; echo 'secret input failed; not scanning'; exit 3   # every check above passed, so the failed prompt is inconclusive
  fi
  case "$client_secret" in
    ''|*[[:cntrl:]]*) echo 'the full secret value is required; not scanning'; exit 2 ;;
  esac
  set -- 0 "$@"                         # the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0), then the directories
  ls -d -- "${@:2}" || { echo "ls exit $?: the output directories could not be listed; inconclusive"; set -- 3 "${@:2}"; }   # confirm browser-served output paths
  # File names are not secret: capture them so matches under dist/server/ (a Vite SSR server build) are reported apart.
  set -- "$1" "$(if printf '%s\n' "$client_secret" | grep -RlF -D skip -f - -- "${@:2}"; then printf '\n0'; else printf '\n%s' "$?"; fi)" "${@:2}"
  set -- "$1" "${2##*$'\n'}" "${2%$'\n'*}" "${@:3}"         # status, grep's exit status, the matching file names, then the directories searched
  case "$2:$3" in
    0:*|*:?*)                           # grep's 0, or any status with files listed: grep exits 2 on a read error even after listing a match
      # FINDING is the default; only a positively classified all-dist/server/ result is reported as server output.
      printf '%s' "$3"
      if printf '%s' "$3" | grep -aq '^dist/server/' && ! printf '%s' "$3" | grep -aqv '^dist/server/'; then
        echo "server output only: every match is under dist/server/, which a Vite SSR build does not serve to browsers; confirm dist/server is server-only in your deployment before treating this as clean"
      else
        echo "FINDING: the secret is in the built client output"
        if printf '%s' "$3" | grep -aq '^dist/server/'; then echo "(of the files listed, those under dist/server/ are server output)"; fi
        set -- 1 "${@:2}"
      fi
      if [ "$2" != 0 ]; then echo "grep also exited $2, so some files were not searched; a FINDING above stands, and any other result is inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}"; fi
      ;;
    1:*) echo "clean: secret not found in ${*:4}" ;;
    *) echo "error: grep exited $2, result inconclusive"; [ "$1" = 1 ] || set -- 3 "${@:2}" ;;
  esac
  echo "block exit $1; a server-output-only or clean result is not proof, so judge it as the paragraph after this block says"
  exit "$1"
)
```

REASONED: preceding block; the output-path listing and the client-secret scan, per the cited framework documentation and GNU grep manual entries; the private-route and spoofed-Host requests are in the block before it. Its fixture, tracing, shell-history, syntax and stub checks are listed under Verification record below; none of them ran against a real build or a service. The account-owner and transformation limits stated in this paragraph are documented, not demonstrated. The secret reaches grep on stdin, never argv; the hidden prompt keeps it out of shell history and the block's `set +x` keeps it out of `set -x` tracing, but this does not hide it from the account owner or root. Paste the secret alone at the hidden prompt: a multi-line paste leaves every line after the first for your shell to run. A clean grep result here is evidence, not proof: it means the literal value did not match in the directories searched, not that the secret cannot be present in some other form. A bundler could split, encode, or otherwise transform it, so check the exit code and confirm the directory actually exists rather than reading silence alone as clean.

REASONED: Host, proxy cookie, redirect and trusted-proxy checks per the cited SvelteKit adapter-node and core source, Vite server-options documentation, Nuxt runtime config documentation, the pinned Nuxt 4.0.0 package manifest and lockfile, pinned nitropack 2.12.0 and h3 1.15.3 sources, and Node v22.22.1 HTTP documentation. No reverse proxy or deployed adapter is available in the authoring environment, so the outcomes of the Host, proxy cookie, redirect and trusted-proxy checks were not observed. The deployed application must not trust a spoofed Host. The supplied Vite allowlist reference covers its dev server. Guide assessment: for this probe, exposed means the application responds to the spoofed Host, so curl prints its first response line. Fixed means a fronting proxy or server refuses the unknown Host before the application; apply the default-server refusal pattern in [nginx.md](nginx.md) to the probed HTTPS listener. With a refusal response, curl prints its status line; with nginx return 444 closing without a response, curl prints no status line. Neither a status line nor silence alone proves which layer handled the request or whether the application builds URLs or redirects from Host. Correlate proxy and application logs with the probe and a working allowed-host control; inspect response headers and generated URLs separately to judge Host use. Adapter-node 5.5.7 uses `ORIGIN` or configured/request headers for the request origin; without `ORIGIN` or `PROTOCOL_HEADER`, it defaults the protocol to `https` and uses the request `Host` header unless `HOST_HEADER` supplies one. Behind a reverse proxy, confirm cookies still carry `Secure` and redirects use an `https://` `Location` once `ORIGIN` (SvelteKit) is set. `NUXT_PUBLIC_...` is the public runtime-config prefix, exposed straight to the client bundle; it is not a trusted-proxy or secure-cookie setting and does nothing for this check. Nuxt 4.0.0 pins nitropack 2.12.0. For a non-static production build with no preset named or matched, nitropack falls back to `node-server`, whose entry runtime passes the h3 app through h3's `toNodeListener` to a Node HTTP or HTTPS server. In the traced adapter-node 5.5.7 handler and SvelteKit Node request conversion, `ORIGIN` or configured/request headers form the request URL without a Host allowlist. In the traced nitropack 2.12.0 node-server and app construction, the h3 app reaches Node HTTP or HTTPS without a Host allowlist. Nuxt v4.0.0 resolves h3 1.15.3: its traced request utilities read `Host` or optionally `x-forwarded-host` and construct a URL without an allowlist; the release commit exports `toNodeListener`, which creates an event and calls `app.handler`, matching the adapter Nitro imports. Node v22.22.1 documents default rejection of an HTTP/1.1 request missing `Host`; that is not an allowed-host list. Guide assessment: these source paths do not establish a universal Host rejection outcome, how the hosting platform treats Host and forwarded headers, or a deployed cookie and redirect outcome. Guide assessment: Nuxt's own trusted-proxy and origin handling come from its deployment preset and hosting platform rather than one documented app-level variable. Guide advice: verify the equivalent behaviour against the deployed Nuxt preset and hosting platform, or whichever adapter you deploy with.

REASONED: following block; the production-server listener bind, with the loopback-bind controls set per the SvelteKit, Nuxt/Nitro and Vite sections above. No isolated (loopback-only) network namespace was available in the authoring environment, so no Nuxt (Nitro), SvelteKit adapter-node production server or Vite preview server was stood up without one. Their bind outcomes are reasoned from the cited defaults and were not observed, the block has not been run against a deployment, and its runs against bare Node listeners are listed under Verification record below. After starting the built server with the guide's loopback bind set (SvelteKit `HOST=127.0.0.1`, Nuxt `NITRO_HOST=127.0.0.1`, or Vite's `localhost` default), run `ss -Hltn 'sport = :3000'` on the server host. Exposed: a listener's Local Address is `0.0.0.0:3000`, `[::]:3000` or `*:3000`, an all-interface bind. The unset bind defaults differ: adapter-node defaults to `0.0.0.0`, per the cited adapter-node source; Nitro node-server has no default host, per the cited nitropack source, so Node listens on `::` when IPv6 is available, which in most operating systems may also accept IPv4, or on `0.0.0.0` otherwise, per the cited Node net documentation; Vite defaults to `localhost`, per the cited Vite source. Per the cited iproute2 source, ss prints an IPv6 wildcard listener as `[::]` when it is IPv6-only and as `*` otherwise. Fixed: every listener is `127.0.0.1:3000` or `[::1]:3000`, loopback only. The block compares the whole Local Address column, so `10.0.0.0:3000` is not read as `0.0.0.0:3000` and `[::1]:3000` is not read as `[::]:3000`. It exits 2 if ss is absent and 3 if ss fails or nothing listens. Otherwise an all-interface listener exits 1 even beside other addresses; failing that, it exits 0 when every listener is `127.0.0.1:3000` or `[::1]:3000`. Failing both, it exits 3 when any listener is on another address (a specific address, another loopback form such as `127.0.0.2:3000`, or one that ss shows with a `%` interface suffix, `addr%ifname` per the cited iproute2 `sock_addr_print` source), which it prints for you to judge.

```bash
# After starting the built server with the guide's loopback bind set
# (SvelteKit HOST=127.0.0.1, Nuxt NITRO_HOST=127.0.0.1, or Vite's localhost
# default), inventory the listener on its port. Adjust the port below if you
# did not use 3000. ss is from iproute2; on a host without it, substitute
# `netstat -ltn` and read the same Local Address column.
(
  trap - DEBUG RETURN ERR   # assumes a clean shell (CONTRIBUTING rule 7)
  set +x +a +e
  command -v ss >/dev/null 2>&1 || { echo "ss (iproute2) is not on PATH; run this on the server host or use netstat -ltn; not probing"; exit 2; }
  listeners="$(ss -Hltn 'sport = :3000')" || { echo "ss exit $?: the listeners could not be read; inconclusive"; exit 3; }
  if [ -z "$listeners" ]; then echo "nothing is listening on port 3000; start the built server first, or adjust the port; inconclusive"; exit 3; fi
  printf '%s\n' "$listeners"   # the Local Address:Port column shows where the server listens
  # awk takes the Local Address:Port column (the 4th) and grep -x compares it whole, so 10.0.0.0:3000
  # is not read as 0.0.0.0:3000. All interfaces: 0.0.0.0 (IPv4), [::] (IPv6 only) or * (IPv6 and IPv4).
  if printf '%s\n' "$listeners" | awk '{print $4}' | grep -Fxq -e '0.0.0.0:3000' -e '[::]:3000' -e '*:3000'; then
    echo "FINDING: the server listens on all interfaces on port 3000 (0.0.0.0, [::] or *); set the loopback bind variable and restart"; exit 1
  fi
  set -- "$(printf '%s\n' "$listeners" | grep -c '')" "$(printf '%s\n' "$listeners" | awk '{print $4}' | grep -Fxc -e '127.0.0.1:3000' -e '[::1]:3000')"   # all listeners, then loopback ones
  if [ -n "$1" ] && [ "$2" = "$1" ]; then
    echo "loopback only: every listener on port 3000 is on 127.0.0.1 or [::1]; a fronting proxy must reach it there"; exit 0
  fi
  echo "a listener above is on neither all interfaces nor exactly 127.0.0.1 or ::1 (a specific address, another loopback form such as 127.0.0.2, or one ss shows with a %interface suffix); judge the printed address; inconclusive"; exit 3
)
```

### Verification record

REASONED: what was run on the three blocks above, and on what. None of it was run against a framework production build, a reverse proxy or a deployment: bash -n and ShellCheck are syntax checks, and the stub, fixture, tracing and bare-listener runs test the blocks' own guards, classification and secret handling, not a framework's behaviour. No block or claim in this guide is demonstrated; the earlier-form runs below were not repeated on the current forms.

REASONED: the private-route and spoofed-Host block, the first above, is covered in its current form only by bash -n and ShellCheck 0.11.0 syntax checks and by curl-stub runs made while it was written; it has not been run against a deployment.

REASONED: the client-secret scan block, the second above, was run in an earlier form, whose FINDING and error arms ended with status 0, against local fixture trees: a secret planted under dist/assets was reported as a FINDING, a tree without it reported clean, and a plant only under dist/server was reported as server output. The same fixture run showed that, with no listed directory, the block refused as inconclusive, and that, with dist/assets a symlink to an external fixture directory holding the planted value, the scan followed the link and reported dist/assets/x.js as a FINDING. On 2026-10-13 (UTC), with Bash 5.3.9 and a dummy secret typed at a pty's hidden prompt, the scan subshell traced two lines under `bash -x` (`trap -` and `set +x +a +e`), neither holding the dummy, where the same subshell with `set +x` removed traced 32 lines, one of them holding the dummy; an interactive Bash given the subshell wrote a history file holding the block's lines and not the dummy. None of these fixture, `bash -x` and history runs was re-run on the current form, whose FINDING arm exits 1 and whose error arm exits 3. The current form, which also lists its directories itself, holds its captures in positional parameters and exits 3 when the hidden prompt fails, is covered only by bash -n and ShellCheck 0.11.0 syntax checks and by stub runs, with real grep on fixture trees, made while it was written.

REASONED: the listener-inventory block, the third above, was run in its current form on 2026-11-12 (UTC) with Node v22.22.1, iproute2 ss 6.19.0, Bash 5.3.9 and ShellCheck 0.11.0: it passed bash -n and ShellCheck and was run against bare Node `net` listeners on port 3000 of one host, one `net.createServer().listen(...)` per listener, not a framework production build or a deployment. With no host given (ss showed `*:3000`), with `::` IPv6-only (`[::]:3000`) and with `0.0.0.0` it exited 1; with `127.0.0.1`, `::1`, or both it exited 0; with `127.0.0.1` beside `[::]:3000` it exited 1; with `127.0.0.1` beside a LAN address it exited 3; with nothing listening it exited 3; and with a stub ss printing `127.0.0.2:3000` it exited 3.

## Common mistakes

- Treating a SvelteKit `handle` hook that only redirects an unauthenticated page navigation, or a Nuxt `server/middleware/` that only attaches `event.context.auth`, as if it already enforced access, while the `+server.js` endpoint, form action, or `server/api/` route trusts that it happened and skips its own check.
- Leaving `server.allowedHosts` at `true`, or `server.host` wide open, past a local demo.
- Naming a secret `PUBLIC_...` or `NUXT_PUBLIC_...` out of habit from a genuinely public value.

## Sources (checked September 2026)

- SvelteKit adapter-node origin configuration and proxy header variables (pinned tag @sveltejs/adapter-node@5.5.7; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L17-L24
- SvelteKit adapter-node request origin passed to getRequest (pinned tag @sveltejs/adapter-node@5.5.7; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L95-L105
- SvelteKit adapter-node protocol, Host and port header fallback (pinned tag @sveltejs/adapter-node@5.5.7; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L209-L239
- Nuxt 4.0.0 pins nitropack 2.12.0 (pinned tag v4.0.0; checked October 2026): https://github.com/nuxt/nuxt/blob/v4.0.0/packages/nuxt/package.json#L104
- nitropack 2.12.0 non-static production node-server fallback when no preset is named or matched (pinned release commit 65e514d873da1d1d9edd4d9576d48d90b13e0fac; checked October 2026): https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/presets/_resolve.ts#L85-L90
- nitropack 2.12.0 production preset auto-detection for a build with no preset named (pinned release commit 65e514d873da1d1d9edd4d9576d48d90b13e0fac; checked October 2026): https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/core/config/loader.ts#L134-L141
- nitropack 2.12.0 h3 dependency range (pinned release commit 65e514d873da1d1d9edd4d9576d48d90b13e0fac; checked October 2026): https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/package.json#L131
- nitropack 2.12.0 node-server preset entry (pinned release commit 65e514d873da1d1d9edd4d9576d48d90b13e0fac; checked October 2026): https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/presets/node/preset.ts#L16-L29
- nitropack 2.12.0 node-server uses h3 toNodeListener with Node HTTP or HTTPS server (pinned release commit 65e514d873da1d1d9edd4d9576d48d90b13e0fac; checked October 2026): https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/presets/node/runtime/node-server.ts#L1-L23
- nitropack 2.12.0 node-server listen host from NITRO_HOST or HOST with no default, and listen call (pinned release commit 65e514d873da1d1d9edd4d9576d48d90b13e0fac; checked November 2026): https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/presets/node/runtime/node-server.ts#L25-L32
- nitropack 2.12.0 h3 app construction and request hook (pinned release commit 65e514d873da1d1d9edd4d9576d48d90b13e0fac; checked October 2026): https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/runtime/internal/app.ts#L59-L128
- SvelteKit pinned routing: +layout has no effect on +server.js (pinned tag @sveltejs/kit@2.70.3): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/20-core-concepts/10-routing.md#L291-L332
- SvelteKit pinned load: layout/page concurrency and auth implications (pinned tag @sveltejs/kit@2.70.3): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/20-core-concepts/20-load.md#L702-L714
- SvelteKit pinned form actions in +page.server.js (pinned tag @sveltejs/kit@2.70.3): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/20-core-concepts/30-form-actions.md#L1-L5
- SvelteKit pinned handle scope and remote-function request metadata (pinned tag @sveltejs/kit@2.70.3): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/30-advanced/20-hooks.md#L15-L36
- SvelteKit pinned remote-function RequestEvent metadata (pinned tag @sveltejs/kit@2.70.3): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/20-core-concepts/60-remote-functions.md#L1300-L1303
- SvelteKit page action dispatch before load (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/page/index.js#L70-L78
- SvelteKit parallel server and universal load scheduling (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/page/index.js#L178-L250
- SvelteKit invalidated server load nodes (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/data/index.js#L39-L97
- SvelteKit client load invalidation (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/client/client.js#L1217-L1235
- SvelteKit checks before handle (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L73-L106
- SvelteKit remote request page URL from headers (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L111-L130
- SvelteKit route and params from resolved path (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L333-L343
- SvelteKit handle invocation (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L456-L498
- SvelteKit rerouted prerendered resource branch (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L274-L306
- SvelteKit Node request conversion (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/exports/node/index.js#L121-L160
- h3 request Host lookup and optional forwarded Host (pinned 1.15.3 release commit; checked October 2026): https://github.com/h3js/h3/blob/3d0f4d582d1ffa7390bf3a6d6748aaf9ce3ab9e6/src/utils/request.ts#L275-L286
- h3 request URL and optional forwarded Host (pinned 1.15.3 release commit; checked October 2026): https://github.com/h3js/h3/blob/3d0f4d582d1ffa7390bf3a6d6748aaf9ce3ab9e6/src/utils/request.ts#L333-L344
- h3 toNodeListener Node adapter (pinned 1.15.3 release commit; checked October 2026): https://github.com/h3js/h3/blob/3d0f4d582d1ffa7390bf3a6d6748aaf9ce3ab9e6/src/adapters/node.ts#L55-L89
- Node HTTP missing Host option (pinned tag v22.22.1; checked October 2026): https://github.com/nodejs/node/blob/v22.22.1/doc/api/http.md#L3653-L3657
- Node net server.listen with host omitted listens on the unspecified IPv6 address (::) when IPv6 is available, which in most operating systems may also accept IPv4, or on 0.0.0.0 otherwise (pinned tag v22.22.1; checked November 2026): https://github.com/nodejs/node/blob/v22.22.1/doc/api/net.md#L638-L644
- Nuxt h3 lockfile resolution (pinned tag v4.0.0; checked October 2026): https://github.com/nuxt/nuxt/blob/v4.0.0/pnpm-lock.yaml#L5204-L5205
- SvelteKit adapter-node output defaults and client and prerendered writes (pinned tag @sveltejs/adapter-node@5.5.7): https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/index.js#L24-L38
- SvelteKit adapter-node server chunks under build/server (pinned tag @sveltejs/adapter-node@5.5.7): https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/index.js#L118
- SvelteKit adapter-node serves the separate prerendered directory (pinned tag @sveltejs/adapter-node@5.5.7): https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L69
- SvelteKit adapter-node serves client files and prerendered pages before SSR (pinned tag @sveltejs/adapter-node@5.5.7): https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L243
- Nuxt 4.x public build assets passed to Nitro (additional source pin v4.0.0): https://github.com/nuxt/nuxt/blob/v4.0.0/packages/nuxt/src/core/nitro.ts#L163-L170
- Nuxt static dist alias targets Nitro public output (additional source pin v4.0.0): https://github.com/nuxt/nuxt/blob/v4.0.0/packages/nuxt/src/core/nitro.ts#L653-L659
- Nitro 2.12.0, the nitropack version Nuxt v4.0.0 pins, output defaults .output, .output/server and .output/public (published build, lines 67 to 69): https://cdn.jsdelivr.net/npm/nitropack@2.12.0/dist/core/index.mjs
- Nitro output defaults and prerender destination (rolling documentation, checked September 2026): https://nitro.build/config
- Nitro public assets copied to production public output (rolling documentation, checked September 2026): https://nitro.build/docs/assets
- Vite default build.outDir 'dist' (pinned tag v8.3.1): https://github.com/vitejs/vite/blob/v8.3.1/packages/vite/src/node/build.ts#L395
- Vite public assets copied to build output (pinned tag v8.3.1): https://github.com/vitejs/vite/blob/v8.3.1/packages/vite/src/node/config.ts#L388-L396
- Vite build output directory and public-copy defaults (rolling documentation, checked November 2026): https://vite.dev/config/build-options
- Vite SSR uses separate client and server builds (rolling documentation, checked November 2026): https://vite.dev/guide/ssr
- SvelteKit adapter-node (rolling documentation, checked November 2026): https://svelte.dev/docs/kit/adapter-node
- SvelteKit server-only modules (rolling documentation, now describing SvelteKit 3, checked November 2026): https://svelte.dev/docs/kit/server-only-modules
- SvelteKit pinned server-only modules (pinned tag @sveltejs/kit@2.70.3; checked November 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/30-advanced/50-server-only-modules.md#L9-L61
- SvelteKit current `$env/static/public` reference, which now says the module was deprecated in SvelteKit 3 (rolling documentation, checked October 2026): https://svelte.dev/docs/kit/$env-static-public
- SvelteKit `csrf.checkOrigin` (default `true`, deprecated) and `csrf.trustedOrigins` (default empty; `'*'` trusts every origin and is generally not recommended) configuration types (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/exports/public.d.ts#L423-L450
- SvelteKit `env.publicPrefix` (default `PUBLIC_`) configuration type (pinned tag @sveltejs/kit@2.70.3; checked October 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/exports/public.d.ts#L466-L470
- SvelteKit current `@sveltejs/kit/vite` reference, which marks `csrf.checkOrigin` deprecated and removed in 3.0 (rolling documentation, checked November 2026): https://svelte.dev/docs/kit/@sveltejs-kit-vite
- SvelteKit 3.0.0 changelog: the deprecated CSRF `checkOrigin` option removed in favor of `trustedOrigins` (pinned tag @sveltejs/kit@3.0.0; checked November 2026): https://github.com/sveltejs/kit/blob/%40sveltejs/kit%403.0.0/packages/kit/CHANGELOG.md#L57
- Nuxt runtime config (rolling documentation, checked November 2026): https://nuxt.com/docs/4.x/guide/going-further/runtime-config
- Nuxt server directory structure (rolling documentation, checked November 2026): https://nuxt.com/docs/4.x/directory-structure/server
- Vite server options (`server.host`, `server.allowedHosts`) (rolling documentation, checked November 2026): https://vite.dev/config/server-options
- Vite CLI (`vite preview`) (rolling documentation, checked November 2026): https://vite.dev/guide/cli
- Vite resolves an unset `server.host` to `'localhost'` (pinned tag v8.3.1): https://github.com/vitejs/vite/blob/v8.3.1/packages/vite/src/node/utils.ts#L1010-L1022
- SvelteKit adapter-node `host = env('HOST', '0.0.0.0')` and `port = env('PORT', !path && '3000')`, with `path = env('SOCKET_PATH', false)`, where `env()` returns a variable's value whenever it is present, even empty, and the socket-activation branch that listens on the passed descriptor instead (pinned tag @sveltejs/adapter-node@5.5.7). SvelteKit adapter-node 5.5.7 sources: https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/index.js#L10-L12, https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/env.js#L46-L50 and https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/index.js#L57-L60
- GNU grep `-f -` ("When file is '-', read patterns from standard input"), `-l` ("print the name of each input file from which output would normally have been printed") and its exit status (0 if a line is selected, 1 if none, 2 on error). GNU grep manual sources: https://www.gnu.org/software/grep/manual/html_node/Matching-Control.html , https://www.gnu.org/software/grep/manual/html_node/General-Output-Control.html and https://www.gnu.org/software/grep/manual/html_node/Exit-Status.html
- iproute2 `ss` address printing: a numeric IPv6 address in brackets, and an IPv6 wildcard listener that is not IPv6-only as `*` (pinned tag v6.19.0): https://git.kernel.org/pub/scm/network/iproute2/iproute2.git/tree/misc/ss.c?h=v6.19.0#n1722
- iproute2 `ss` `sock_addr_print`: an address given an interface name is printed with a `%` interface suffix (`addr%ifname`) (pinned tag v6.19.0): https://git.kernel.org/pub/scm/network/iproute2/iproute2.git/tree/misc/ss.c?h=v6.19.0#n1484


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- adapter: SvelteKit adapter-node (@sveltejs/adapter-node@5.5.7)
- svelte-kit-pin: SvelteKit routing and hooks documentation (@sveltejs/kit@2.70.3)
- svelte-kit-3: SvelteKit 3.0.0 changelog (@sveltejs/kit@3.0.0)
- nuxt-lock: Nuxt lockfile (v4.0.0)
- nuxt: Nuxt documentation (4.x)
- nuxt-output: Nuxt output source (v4.0.0)
- vite-pin: Vite bind source (v8.3.1)
- svelte: SvelteKit documentation (unknown)
- vite: Vite documentation (unknown)
- h3-pin: h3 request and Node adapter source at release commit (1.15.3)
- node-http: Node HTTP documentation (v22.22.1)
- nitro-output: Nitro output defaults (2.12.0)
- nitro-node: nitropack 2.12.0 source (65e514d873da1d1d9edd4d9576d48d90b13e0fac)
- nitro-output-docs: Nitro documentation (rolling) (unknown)
- grep: GNU grep (unknown)
- iproute2-ss: iproute2 ss source (v6.19.0)

Claims (full source mapping in the JSON block below):

- adapter-bind (REASONED; adapter, svelte): adapter-node defaults 0.0.0.0:3000 only with SOCKET_PATH unset/empty and no systemd socket; set HOST=127.0.0.1 PORT=3000.
- adapter-origin (REASONED; svelte): Set ORIGIN to external HTTPS origin; trust PROTOCOL_HEADER/HOST_HEADER only behind a trusted proxy.
- adapter-ip (REASONED; svelte): ADDRESS_HEADER and XFF_DEPTH configure proxy-derived client IP and require trusted proxy handling.
- csrf-check (REASONED; svelte, svelte-kit-pin, svelte-kit-3): csrf.checkOrigin defaults true, deprecated and removed in @sveltejs/kit 3.0.0; documented for cross-origin POST/PUT/PATCH/DELETE form content types only; give JSON/other content origin/session checks.
- csrf-trust (REASONED; svelte, svelte-kit-pin): csrf.trustedOrigins defaults empty; list specific form origins, with wildcard trust discouraged.
- svelte-public (REASONED; svelte-kit-pin): Pinned 2.70.3 types: env.publicPrefix (default PUBLIC_) marks env variables safe to expose to client-side code; keep secrets out.
- svelte-private (REASONED; svelte, svelte-kit-pin): Private env modules, .server.js and lib/server are server-only; SvelteKit errors on client import chains, including dynamic imports.
- svelte-routes (REASONED; svelte-kit-pin): Pinned docs and source show layout `load` does not run on every request, layout/page `load` run concurrently unless a child calls `await parent()`, `+layout` has no effect on `+server.js`, and form actions run before page loads. Guide advice: do not rely on a layout guard to protect a sibling page load, form action or directly reached endpoint; check the session before protected work in each.
- svelte-handle (REASONED; svelte-kit-pin): Pinned hooks docs describe `handle` for SvelteKit server requests, including prerendering; runtime source calls it after checks that can reject requests before the hook and lets it return before `resolve`.
- svelte-handle-adapter (REASONED; adapter): In adapter-node 5.5.7, client assets and already prerendered pages are served before SSR, so they do not reach `handle` through that adapter.
- svelte-handle-remote (REASONED; svelte-kit-pin): For client-initiated remote function requests, runtime source takes the calling-page path and search from request headers and resolves `route` and `params` from that path; pinned remote-functions docs describe the same fields on `RequestEvent` inside remote functions, and the pinned hooks and remote-functions docs both warn never to use these request-derived fields to authorize data access.
- svelte-handle-advice (REASONED; svelte-kit-pin, adapter): Guide advice: use `handle` to block unauthorized SvelteKit requests that reach it; a redirect-only or `event.locals`-only hook leaves directly reached endpoints and form actions open unless they check the session; do not rely on calling-page fields alone, and authorize each specific resource where served because a session check alone does not authorize it.
- nuxt-handlers (REASONED; nuxt): Nuxt auto-registers server/api, server/routes and middleware; middleware runs first, but context.auth alone enforces nothing. The Nuxt page says middleware should not return anything or close or respond to the request, and only inspect or extend the request context or throw an error. Guide advice: respond from route handlers, or check each handler.
- nuxt-auth (REASONED; nuxt): Nuxt ships no built-in authentication; enforce access server-side, not with client redirects.
- nuxt-private (REASONED; nuxt): Direct runtimeConfig keys are server-only with NUXT_ overrides; rendering or passing to useState can disclose them.
- nuxt-public (REASONED; nuxt): runtimeConfig.public is client-exposed with NUXT_PUBLIC_ overrides, not proxy/cookie configuration.
- nuxt-bind (REASONED; nitro-node): nitropack 2.12.0 node-server reads the listen host from NITRO_HOST or HOST with no default, so with neither set Node listens on all interfaces; set NITRO_HOST=127.0.0.1 and NITRO_PORT to bind loopback.
- vite-production (REASONED; vite): Vite dev/preview is development tooling; deploy dist through a production server, CDN or platform.
- vite-bind (REASONED; vite-pin, vite): Vite 8.3.1 server.host defaults localhost; true/0.0.0.0 exposes all addresses and should not remain beyond trusted-network tests.
- vite-hosts (REASONED; vite): server.allowedHosts defaults empty with localhost, .localhost and IPs allowed; true disables protection and permits DNS rebinding. Prefer explicit names.
- verify-bind (REASONED; adapter, nitro-node, vite-pin, iproute2-ss, node-http): After setting the loopback bind, run `ss -Hltn 'sport = :3000'` on the production host. A Local Address of `0.0.0.0:3000`, `[::]:3000` or `*:3000` (all interfaces; adapter-node and Nitro default) exits 1 even beside others; else every listener on `127.0.0.1:3000` or `[::1]:3000` exits 0; any other address exits 3. Seen on bare Node listeners; defaults reasoned from sources; no deployment run.
- verify-private (REASONED; nuxt): Guide expects anonymous /api/private 401; enforcement needs app/server handlers, not client redirects.
- verify-secret (REASONED; grep, adapter, nuxt-output, nitro-output, vite-pin, vite, nitro-output-docs): Scan browser-served output: adapter-node build/client and build/prerendered, Nuxt .output/public, Vite dist, scanned whole following symlinks; only a result with every match under dist/server/ is reported as server output, else FINDING with dist/server/ matches labelled. Adjust paths for custom layouts/SSR; reject absence.
- verify-secret-grep (REASONED; grep, adapter, nuxt-output, nitro-output, vite-pin, vite, nitro-output-docs): Prompt full literal secret; grep stdin: 0 finding, 1 no match, others errors. Clean cannot rule out transformed secrets or runtime responses; hidden input and set +x keep the secret from argv, history and tracing, not the account owner or root.
- verify-host (REASONED; vite, adapter, nitro-node, svelte-kit-pin, h3-pin, node-http, nuxt-lock): The deployed application must not trust a spoofed Host. The supplied Vite allowlist reference covers its dev server. Guide assessment: for this probe, exposed means the application responds to the spoofed Host, so curl prints its first response line.
- verify-host-fixed (REASONED; vite, adapter, nitro-node, svelte-kit-pin, h3-pin, node-http, nuxt-lock): Guide assessment: fixed means a fronting proxy or server refuses the unknown Host before the application; apply the default-server refusal pattern in [nginx.md](nginx.md) to the probed HTTPS listener. With a refusal response, curl prints its status line; with nginx return 444 closing without a response, curl prints no status line.
- verify-host-judge (REASONED; vite, adapter, nitro-node, svelte-kit-pin, h3-pin, node-http, nuxt-lock): Neither a status line nor silence alone proves which layer handled the request or whether the application builds URLs or redirects from Host. Correlate proxy and application logs with the probe and a working allowed-host control; inspect response headers and generated URLs separately to judge Host use.
- verify-host-adapter (REASONED; adapter, svelte-kit-pin): In the traced adapter-node 5.5.7 and SvelteKit Node request conversion, ORIGIN or configured/request headers form the request URL; these files do not apply a Host allowlist.
- verify-host-nitro (REASONED; nitro-node, h3-pin, nuxt-lock): In the traced nitropack 2.12.0 node-server and app construction, the h3 app is passed to Node HTTP or HTTPS without a Host allowlist. Nuxt v4.0.0 resolves h3 1.15.3; its traced request utilities read Host or optionally forwarded Host and construct a URL without an allowlist; the release commit exports toNodeListener, which creates an event and calls app.handler, matching the adapter Nitro imports.
- verify-host-scope (REASONED; vite, adapter, nitro-node, svelte-kit-pin, h3-pin, node-http, nuxt-lock): Node v22.22.1 documents a default missing-Host rejection for HTTP/1.1, not an allowed-host list. Guide assessment: these source paths do not establish a universal Host rejection outcome or how the hosting platform treats Host and forwarded headers.
- verify-proxy (REASONED; svelte, nuxt, adapter, nuxt-output, nitro-node): Check Secure cookies and HTTPS redirects with SvelteKit ORIGIN; verify Nuxt for its deployment preset and hosting platform, not NUXT_PUBLIC_. Adapter-node 5.5.7 uses ORIGIN or configured/request headers for the request origin; with ORIGIN and PROTOCOL_HEADER unset, it defaults to https and uses the request Host header unless HOST_HEADER supplies one.
- verify-proxy-nitro (REASONED; nuxt-output, nitro-node): Nuxt 4.0.0 pins nitropack 2.12.0, which falls back to its node-server preset for a non-static production build with no preset named or matched; that preset passes the h3 app through toNodeListener to a Node HTTP or HTTPS server.
- verify-proxy-scope (REASONED; svelte, nuxt, adapter, nuxt-output, nitro-node): Guide assessment: Nuxt's own trusted-proxy and origin handling come from its deployment preset and hosting platform rather than one documented app-level variable; the cited lines do not establish how h3 1.x or the hosting platform treats Host and forwarded headers or a deployed cookie and redirect outcome.

````json
{
  "schema": 1,
  "checked": "2026-10-18",
  "documentation_checked": "2026-09",
  "body_sha256": "bff1148814fb78fed5bc3a2ca17d12e1f06e61d54cdca375ced0c4d2b5bc3ba6",
  "components": {
    "adapter": {
      "name": "SvelteKit adapter-node",
      "basis": "@sveltejs/adapter-node@5.5.7",
      "sources": {
        "s011f4e44c91a": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/env.js#L46-L50",
        "s93f13e6b8d31": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/index.js#L10-L12",
        "sd23cac9a730f": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/index.js#L57-L60",
        "s200d6e800c74": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/index.js#L24-L38",
        "sf17c5646623c": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/index.js#L118",
        "s1ffeda9bbb37": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L69",
        "s8d4fa8e7426b": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L243",
        "sfd51397a510e": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L17-L24",
        "s6152d66c6b19": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L95-L105",
        "s7b3a11637166": "https://github.com/sveltejs/kit/blob/%40sveltejs/adapter-node%405.5.7/packages/adapter-node/src/handler.js#L209-L239"
      }
    },
    "svelte-kit-pin": {
      "name": "SvelteKit routing and hooks documentation",
      "basis": "@sveltejs/kit@2.70.3",
      "sources": {
        "sca07fbe19546": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/20-core-concepts/10-routing.md#L291-L332",
        "sa9bbf285a91c": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/20-core-concepts/20-load.md#L702-L714",
        "s380cc33507e0": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/20-core-concepts/30-form-actions.md#L1-L5",
        "sf5b873616d3c": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/30-advanced/20-hooks.md#L15-L36",
        "s5ad7a525e0ea": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/20-core-concepts/60-remote-functions.md#L1300-L1303",
        "s6a78ad19d884": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/page/index.js#L70-L78",
        "s0969ea98a4f1": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/page/index.js#L178-L250",
        "sffcf647d5328": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/data/index.js#L39-L97",
        "sfb110948d2ca": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/client/client.js#L1217-L1235",
        "s67fe32e7a18d": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L73-L106",
        "sc4708064d4fd": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L111-L130",
        "s95d5c7dd7a50": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L333-L343",
        "sca363a35f3fc": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L456-L498",
        "s89773d0c39e7": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/runtime/server/respond.js#L274-L306",
        "sd1c295d2cf56": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/exports/node/index.js#L121-L160",
        "s029a2e9edbca": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/exports/public.d.ts#L423-L450",
        "s8e93f5865bbc": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/packages/kit/src/exports/public.d.ts#L466-L470",
        "sb21b72450e17": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%402.70.3/documentation/docs/30-advanced/50-server-only-modules.md#L9-L61"
      }
    },
    "svelte-kit-3": {
      "name": "SvelteKit 3.0.0 changelog",
      "basis": "@sveltejs/kit@3.0.0",
      "sources": {
        "s4f76ac707c1c": "https://github.com/sveltejs/kit/blob/%40sveltejs/kit%403.0.0/packages/kit/CHANGELOG.md#L57"
      }
    },
    "nuxt-lock": {
      "name": "Nuxt lockfile",
      "basis": "v4.0.0",
      "sources": {
        "se77b46c1e3ad": "https://github.com/nuxt/nuxt/blob/v4.0.0/pnpm-lock.yaml#L5204-L5205"
      }
    },
    "nuxt": {
      "name": "Nuxt documentation",
      "basis": "4.x",
      "sources": {
        "se2d1e4a2e433": "https://nuxt.com/docs/4.x/directory-structure/server",
        "s32e447cb5ef4": "https://nuxt.com/docs/4.x/guide/going-further/runtime-config"
      }
    },
    "nuxt-output": {
      "name": "Nuxt output source",
      "basis": "v4.0.0",
      "sources": {
        "sa65d64f55ca1": "https://github.com/nuxt/nuxt/blob/v4.0.0/packages/nuxt/src/core/nitro.ts#L163-L170",
        "se1cb3e5b4959": "https://github.com/nuxt/nuxt/blob/v4.0.0/packages/nuxt/src/core/nitro.ts#L653-L659",
        "sd00a53729513": "https://github.com/nuxt/nuxt/blob/v4.0.0/packages/nuxt/package.json#L104"
      }
    },
    "vite-pin": {
      "name": "Vite bind source",
      "basis": "v8.3.1",
      "sources": {
        "s36532f775f7f": "https://github.com/vitejs/vite/blob/v8.3.1/packages/vite/src/node/utils.ts#L1010-L1022",
        "s8ba1c2b868b7": "https://github.com/vitejs/vite/blob/v8.3.1/packages/vite/src/node/config.ts#L388-L396",
        "s484948ac14b6": "https://github.com/vitejs/vite/blob/v8.3.1/packages/vite/src/node/build.ts#L395"
      }
    },
    "svelte": {
      "name": "SvelteKit documentation",
      "basis": "unknown",
      "sources": {
        "s59abf03bae6a": "https://svelte.dev/docs/kit/adapter-node",
        "s23f255e94668": "https://svelte.dev/docs/kit/@sveltejs-kit-vite",
        "se2fdc4fd5885": "https://svelte.dev/docs/kit/server-only-modules"
      }
    },
    "vite": {
      "name": "Vite documentation",
      "basis": "unknown",
      "sources": {
        "sae9dd90908fc": "https://vite.dev/config/server-options",
        "s16927b810cff": "https://vite.dev/guide/cli",
        "s7c70a12e43ed": "https://vite.dev/config/build-options",
        "sba6dbfdd7590": "https://vite.dev/guide/ssr"
      }
    },
    "h3-pin": {
      "name": "h3 request and Node adapter source at release commit",
      "basis": "1.15.3",
      "sources": {
        "scfe5cba40964": "https://github.com/h3js/h3/blob/3d0f4d582d1ffa7390bf3a6d6748aaf9ce3ab9e6/src/utils/request.ts#L275-L286",
        "sdbe7e781611f": "https://github.com/h3js/h3/blob/3d0f4d582d1ffa7390bf3a6d6748aaf9ce3ab9e6/src/utils/request.ts#L333-L344",
        "s218970f40ae0": "https://github.com/h3js/h3/blob/3d0f4d582d1ffa7390bf3a6d6748aaf9ce3ab9e6/src/adapters/node.ts#L55-L89"
      }
    },
    "node-http": {
      "name": "Node HTTP documentation",
      "basis": "v22.22.1",
      "sources": {
        "sdc846082a7e3": "https://github.com/nodejs/node/blob/v22.22.1/doc/api/http.md#L3653-L3657",
        "sac6de1c6e048": "https://github.com/nodejs/node/blob/v22.22.1/doc/api/net.md#L638-L644"
      }
    },
    "nitro-output": {
      "name": "Nitro output defaults",
      "basis": "2.12.0",
      "sources": {
        "sbe9fd1f61fe0": "https://cdn.jsdelivr.net/npm/nitropack@2.12.0/dist/core/index.mjs"
      }
    },
    "nitro-node": {
      "name": "nitropack 2.12.0 source",
      "basis": "65e514d873da1d1d9edd4d9576d48d90b13e0fac",
      "sources": {
        "sd56c769d6dae": "https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/presets/_resolve.ts#L85-L90",
        "s32975278fc3f": "https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/presets/node/preset.ts#L16-L29",
        "sdfda9cd3ce7b": "https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/presets/node/runtime/node-server.ts#L1-L23",
        "sdf38c24e1f80": "https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/runtime/internal/app.ts#L59-L128",
        "s91ab58ddc148": "https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/core/config/loader.ts#L134-L141",
        "s0c8ca22542d2": "https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/package.json#L131",
        "s68e3655562f1": "https://github.com/nitrojs/nitro/blob/65e514d873da1d1d9edd4d9576d48d90b13e0fac/src/presets/node/runtime/node-server.ts#L25-L32"
      }
    },
    "nitro-output-docs": {
      "name": "Nitro documentation (rolling)",
      "basis": "unknown",
      "sources": {
        "s47fff9b24fba": "https://nitro.build/config",
        "s51e38e411bfa": "https://nitro.build/docs/assets"
      }
    },
    "grep": {
      "name": "GNU grep",
      "basis": "unknown",
      "sources": {
        "sea43e82b0753": "https://www.gnu.org/software/grep/manual/html_node/Exit-Status.html",
        "s2c1251092e66": "https://www.gnu.org/software/grep/manual/html_node/General-Output-Control.html",
        "sd00017f70dae": "https://www.gnu.org/software/grep/manual/html_node/Matching-Control.html"
      }
    },
    "iproute2-ss": {
      "name": "iproute2 ss source",
      "basis": "v6.19.0",
      "sources": {
        "sde20173b1cdf": "https://git.kernel.org/pub/scm/network/iproute2/iproute2.git/tree/misc/ss.c?h=v6.19.0#n1722",
        "scf8e779f9031": "https://git.kernel.org/pub/scm/network/iproute2/iproute2.git/tree/misc/ss.c?h=v6.19.0#n1484"
      }
    }
  },
  "claims": {
    "adapter-bind": {"text": "adapter-node defaults 0.0.0.0:3000 only with SOCKET_PATH unset/empty and no systemd socket; set HOST=127.0.0.1 PORT=3000.", "components": ["adapter", "svelte"], "sources": ["adapter:s011f4e44c91a", "adapter:s93f13e6b8d31", "adapter:sd23cac9a730f", "svelte:s59abf03bae6a"], "status": "REASONED"},
    "adapter-origin": {"text": "Set ORIGIN to external HTTPS origin; trust PROTOCOL_HEADER/HOST_HEADER only behind a trusted proxy.", "components": ["svelte"], "sources": ["svelte:s59abf03bae6a"], "status": "REASONED"},
    "adapter-ip": {"text": "ADDRESS_HEADER and XFF_DEPTH configure proxy-derived client IP and require trusted proxy handling.", "components": ["svelte"], "sources": ["svelte:s59abf03bae6a"], "status": "REASONED"},
    "csrf-check": {"text": "csrf.checkOrigin defaults true, deprecated and removed in @sveltejs/kit 3.0.0; documented for cross-origin POST/PUT/PATCH/DELETE form content types only; give JSON/other content origin/session checks.", "components": ["svelte", "svelte-kit-pin", "svelte-kit-3"], "sources": ["svelte:s23f255e94668", "svelte-kit-pin:s029a2e9edbca", "svelte-kit-3:s4f76ac707c1c"], "status": "REASONED"},
    "csrf-trust": {"text": "csrf.trustedOrigins defaults empty; list specific form origins, with wildcard trust discouraged.", "components": ["svelte", "svelte-kit-pin"], "sources": ["svelte:s23f255e94668", "svelte-kit-pin:s029a2e9edbca"], "status": "REASONED"},
    "svelte-public": {"text": "Pinned 2.70.3 types: env.publicPrefix (default PUBLIC_) marks env variables safe to expose to client-side code; keep secrets out.", "components": ["svelte-kit-pin"], "sources": ["svelte-kit-pin:s8e93f5865bbc"], "status": "REASONED"},
    "svelte-private": {"text": "Private env modules, .server.js and lib/server are server-only; SvelteKit errors on client import chains, including dynamic imports.", "components": ["svelte", "svelte-kit-pin"], "sources": ["svelte:se2fdc4fd5885", "svelte-kit-pin:sb21b72450e17"], "status": "REASONED"},
    "svelte-routes": {"text": "Pinned docs and source show layout `load` does not run on every request, layout/page `load` run concurrently unless a child calls `await parent()`, `+layout` has no effect on `+server.js`, and form actions run before page loads. Guide advice: do not rely on a layout guard to protect a sibling page load, form action or directly reached endpoint; check the session before protected work in each.", "components": ["svelte-kit-pin"], "sources": ["svelte-kit-pin:sca07fbe19546", "svelte-kit-pin:sa9bbf285a91c", "svelte-kit-pin:s380cc33507e0", "svelte-kit-pin:sfb110948d2ca", "svelte-kit-pin:sffcf647d5328", "svelte-kit-pin:s0969ea98a4f1", "svelte-kit-pin:s6a78ad19d884"], "status": "REASONED"},
    "svelte-handle": {"text": "Pinned hooks docs describe `handle` for SvelteKit server requests, including prerendering; runtime source calls it after checks that can reject requests before the hook and lets it return before `resolve`.", "components": ["svelte-kit-pin"], "sources": ["svelte-kit-pin:sf5b873616d3c", "svelte-kit-pin:s5ad7a525e0ea", "svelte-kit-pin:s67fe32e7a18d", "svelte-kit-pin:sc4708064d4fd", "svelte-kit-pin:s95d5c7dd7a50", "svelte-kit-pin:sca363a35f3fc", "svelte-kit-pin:s89773d0c39e7"], "status": "REASONED"},
    "svelte-handle-adapter": {"text": "In adapter-node 5.5.7, client assets and already prerendered pages are served before SSR, so they do not reach `handle` through that adapter.", "components": ["adapter"], "sources": ["adapter:s1ffeda9bbb37", "adapter:s8d4fa8e7426b"], "status": "REASONED"},
    "svelte-handle-remote": {"text": "For client-initiated remote function requests, runtime source takes the calling-page path and search from request headers and resolves `route` and `params` from that path; pinned remote-functions docs describe the same fields on `RequestEvent` inside remote functions, and the pinned hooks and remote-functions docs both warn never to use these request-derived fields to authorize data access.", "components": ["svelte-kit-pin"], "sources": ["svelte-kit-pin:sf5b873616d3c", "svelte-kit-pin:s5ad7a525e0ea", "svelte-kit-pin:s67fe32e7a18d", "svelte-kit-pin:sc4708064d4fd", "svelte-kit-pin:s95d5c7dd7a50", "svelte-kit-pin:sca363a35f3fc", "svelte-kit-pin:s89773d0c39e7"], "status": "REASONED"},
    "svelte-handle-advice": {"text": "Guide advice: use `handle` to block unauthorized SvelteKit requests that reach it; a redirect-only or `event.locals`-only hook leaves directly reached endpoints and form actions open unless they check the session; do not rely on calling-page fields alone, and authorize each specific resource where served because a session check alone does not authorize it.", "components": ["svelte-kit-pin", "adapter"], "sources": ["svelte-kit-pin:sf5b873616d3c", "svelte-kit-pin:s5ad7a525e0ea", "svelte-kit-pin:s67fe32e7a18d", "svelte-kit-pin:sc4708064d4fd", "svelte-kit-pin:s95d5c7dd7a50", "svelte-kit-pin:sca363a35f3fc", "svelte-kit-pin:s89773d0c39e7", "adapter:s1ffeda9bbb37", "adapter:s8d4fa8e7426b"], "status": "REASONED"},
    "nuxt-handlers": {"text": "Nuxt auto-registers server/api, server/routes and middleware; middleware runs first, but context.auth alone enforces nothing. The Nuxt page says middleware should not return anything or close or respond to the request, and only inspect or extend the request context or throw an error. Guide advice: respond from route handlers, or check each handler.", "components": ["nuxt"], "sources": ["nuxt:se2d1e4a2e433"], "status": "REASONED"},
    "nuxt-auth": {"text": "Nuxt ships no built-in authentication; enforce access server-side, not with client redirects.", "components": ["nuxt"], "sources": ["nuxt:se2d1e4a2e433"], "status": "REASONED"},
    "nuxt-private": {"text": "Direct runtimeConfig keys are server-only with NUXT_ overrides; rendering or passing to useState can disclose them.", "components": ["nuxt"], "sources": ["nuxt:s32e447cb5ef4"], "status": "REASONED"},
    "nuxt-public": {"text": "runtimeConfig.public is client-exposed with NUXT_PUBLIC_ overrides, not proxy/cookie configuration.", "components": ["nuxt"], "sources": ["nuxt:s32e447cb5ef4"], "status": "REASONED"},
    "nuxt-bind": {"text": "nitropack 2.12.0 node-server reads the listen host from NITRO_HOST or HOST with no default, so with neither set Node listens on all interfaces; set NITRO_HOST=127.0.0.1 and NITRO_PORT to bind loopback.", "components": ["nitro-node"], "sources": ["nitro-node:s68e3655562f1"], "status": "REASONED"},
    "vite-production": {"text": "Vite dev/preview is development tooling; deploy dist through a production server, CDN or platform.", "components": ["vite"], "sources": ["vite:s16927b810cff"], "status": "REASONED"},
    "vite-bind": {"text": "Vite 8.3.1 server.host defaults localhost; true/0.0.0.0 exposes all addresses and should not remain beyond trusted-network tests.", "components": ["vite-pin", "vite"], "sources": ["vite-pin:s36532f775f7f", "vite:sae9dd90908fc"], "status": "REASONED"},
    "vite-hosts": {"text": "server.allowedHosts defaults empty with localhost, .localhost and IPs allowed; true disables protection and permits DNS rebinding. Prefer explicit names.", "components": ["vite"], "sources": ["vite:sae9dd90908fc"], "status": "REASONED"},
    "verify-bind": {"text": "After setting the loopback bind, run `ss -Hltn 'sport = :3000'` on the production host. A Local Address of `0.0.0.0:3000`, `[::]:3000` or `*:3000` (all interfaces; adapter-node and Nitro default) exits 1 even beside others; else every listener on `127.0.0.1:3000` or `[::1]:3000` exits 0; any other address exits 3. Seen on bare Node listeners; defaults reasoned from sources; no deployment run.", "components": ["adapter", "nitro-node", "vite-pin", "iproute2-ss", "node-http"], "sources": ["adapter:s93f13e6b8d31", "nitro-node:s68e3655562f1", "vite-pin:s36532f775f7f", "iproute2-ss:sde20173b1cdf", "iproute2-ss:scf8e779f9031", "node-http:sac6de1c6e048"], "status": "REASONED", "verify": [3]},
    "verify-private": {"text": "Guide expects anonymous /api/private 401; enforcement needs app/server handlers, not client redirects.", "components": ["nuxt"], "sources": ["nuxt:se2d1e4a2e433"], "status": "REASONED", "verify": [1]},
    "verify-secret": {"text": "Scan browser-served output: adapter-node build/client and build/prerendered, Nuxt .output/public, Vite dist, scanned whole following symlinks; only a result with every match under dist/server/ is reported as server output, else FINDING with dist/server/ matches labelled. Adjust paths for custom layouts/SSR; reject absence.", "components": ["grep", "adapter", "nuxt-output", "nitro-output", "vite-pin", "vite", "nitro-output-docs"], "sources": ["grep:sea43e82b0753", "grep:s2c1251092e66", "grep:sd00017f70dae", "adapter:s200d6e800c74", "adapter:sf17c5646623c", "adapter:s1ffeda9bbb37", "adapter:s8d4fa8e7426b", "nuxt-output:sa65d64f55ca1", "nuxt-output:se1cb3e5b4959", "nitro-output:sbe9fd1f61fe0", "nitro-output-docs:s47fff9b24fba", "nitro-output-docs:s51e38e411bfa", "vite-pin:s8ba1c2b868b7", "vite-pin:s484948ac14b6", "vite:s7c70a12e43ed", "vite:sba6dbfdd7590"], "status": "REASONED", "verify": [2]},
    "verify-secret-grep": {"text": "Prompt full literal secret; grep stdin: 0 finding, 1 no match, others errors. Clean cannot rule out transformed secrets or runtime responses; hidden input and set +x keep the secret from argv, history and tracing, not the account owner or root.", "components": ["grep", "adapter", "nuxt-output", "nitro-output", "vite-pin", "vite", "nitro-output-docs"], "sources": ["grep:sea43e82b0753", "grep:s2c1251092e66", "grep:sd00017f70dae", "adapter:s200d6e800c74", "adapter:sf17c5646623c", "adapter:s1ffeda9bbb37", "adapter:s8d4fa8e7426b", "nuxt-output:sa65d64f55ca1", "nuxt-output:se1cb3e5b4959", "nitro-output:sbe9fd1f61fe0", "nitro-output-docs:s47fff9b24fba", "nitro-output-docs:s51e38e411bfa", "vite-pin:s8ba1c2b868b7", "vite-pin:s484948ac14b6", "vite:s7c70a12e43ed", "vite:sba6dbfdd7590"], "status": "REASONED", "verify": [2]},
    "verify-host": {"text": "The deployed application must not trust a spoofed Host. The supplied Vite allowlist reference covers its dev server. Guide assessment: for this probe, exposed means the application responds to the spoofed Host, so curl prints its first response line.", "components": ["vite", "adapter", "nitro-node", "svelte-kit-pin", "h3-pin", "node-http", "nuxt-lock"], "sources": ["vite:sae9dd90908fc", "adapter:sfd51397a510e", "adapter:s6152d66c6b19", "adapter:s7b3a11637166", "nitro-node:sd56c769d6dae", "nitro-node:s32975278fc3f", "nitro-node:sdfda9cd3ce7b", "nitro-node:s0c8ca22542d2", "svelte-kit-pin:sd1c295d2cf56", "h3-pin:scfe5cba40964", "h3-pin:sdbe7e781611f", "h3-pin:s218970f40ae0", "node-http:sdc846082a7e3", "nuxt-lock:se77b46c1e3ad"], "status": "REASONED", "verify": [1]},
    "verify-host-fixed": {"text": "Guide assessment: fixed means a fronting proxy or server refuses the unknown Host before the application; apply the default-server refusal pattern in [nginx.md](nginx.md) to the probed HTTPS listener. With a refusal response, curl prints its status line; with nginx return 444 closing without a response, curl prints no status line.", "components": ["vite", "adapter", "nitro-node", "svelte-kit-pin", "h3-pin", "node-http", "nuxt-lock"], "sources": ["vite:sae9dd90908fc", "adapter:sfd51397a510e", "adapter:s6152d66c6b19", "adapter:s7b3a11637166", "nitro-node:sd56c769d6dae", "nitro-node:s32975278fc3f", "nitro-node:sdfda9cd3ce7b", "nitro-node:s0c8ca22542d2", "svelte-kit-pin:sd1c295d2cf56", "h3-pin:scfe5cba40964", "h3-pin:sdbe7e781611f", "h3-pin:s218970f40ae0", "node-http:sdc846082a7e3", "nuxt-lock:se77b46c1e3ad"], "status": "REASONED", "verify": [1]},
    "verify-host-judge": {"text": "Neither a status line nor silence alone proves which layer handled the request or whether the application builds URLs or redirects from Host. Correlate proxy and application logs with the probe and a working allowed-host control; inspect response headers and generated URLs separately to judge Host use.", "components": ["vite", "adapter", "nitro-node", "svelte-kit-pin", "h3-pin", "node-http", "nuxt-lock"], "sources": ["vite:sae9dd90908fc", "adapter:sfd51397a510e", "adapter:s6152d66c6b19", "adapter:s7b3a11637166", "nitro-node:sd56c769d6dae", "nitro-node:s32975278fc3f", "nitro-node:sdfda9cd3ce7b", "nitro-node:s0c8ca22542d2", "svelte-kit-pin:sd1c295d2cf56", "h3-pin:scfe5cba40964", "h3-pin:sdbe7e781611f", "h3-pin:s218970f40ae0", "node-http:sdc846082a7e3", "nuxt-lock:se77b46c1e3ad"], "status": "REASONED", "verify": [1]},
    "verify-host-adapter": {"text": "In the traced adapter-node 5.5.7 and SvelteKit Node request conversion, ORIGIN or configured/request headers form the request URL; these files do not apply a Host allowlist.", "components": ["adapter", "svelte-kit-pin"], "sources": ["adapter:sfd51397a510e", "adapter:s6152d66c6b19", "adapter:s7b3a11637166", "svelte-kit-pin:sd1c295d2cf56"], "status": "REASONED", "verify": [1]},
    "verify-host-nitro": {"text": "In the traced nitropack 2.12.0 node-server and app construction, the h3 app is passed to Node HTTP or HTTPS without a Host allowlist. Nuxt v4.0.0 resolves h3 1.15.3; its traced request utilities read Host or optionally forwarded Host and construct a URL without an allowlist; the release commit exports toNodeListener, which creates an event and calls app.handler, matching the adapter Nitro imports.", "components": ["nitro-node", "h3-pin", "nuxt-lock"], "sources": ["nitro-node:sd56c769d6dae", "nitro-node:s32975278fc3f", "nitro-node:sdfda9cd3ce7b", "nitro-node:s0c8ca22542d2", "h3-pin:scfe5cba40964", "h3-pin:sdbe7e781611f", "h3-pin:s218970f40ae0", "nuxt-lock:se77b46c1e3ad"], "status": "REASONED", "verify": [1]},
    "verify-host-scope": {"text": "Node v22.22.1 documents a default missing-Host rejection for HTTP/1.1, not an allowed-host list. Guide assessment: these source paths do not establish a universal Host rejection outcome or how the hosting platform treats Host and forwarded headers.", "components": ["vite", "adapter", "nitro-node", "svelte-kit-pin", "h3-pin", "node-http", "nuxt-lock"], "sources": ["vite:sae9dd90908fc", "adapter:sfd51397a510e", "adapter:s6152d66c6b19", "adapter:s7b3a11637166", "nitro-node:sd56c769d6dae", "nitro-node:s32975278fc3f", "nitro-node:sdfda9cd3ce7b", "nitro-node:s0c8ca22542d2", "svelte-kit-pin:sd1c295d2cf56", "h3-pin:scfe5cba40964", "h3-pin:sdbe7e781611f", "h3-pin:s218970f40ae0", "node-http:sdc846082a7e3", "nuxt-lock:se77b46c1e3ad"], "status": "REASONED", "verify": [1]},
    "verify-proxy": {"text": "Check Secure cookies and HTTPS redirects with SvelteKit ORIGIN; verify Nuxt for its deployment preset and hosting platform, not NUXT_PUBLIC_. Adapter-node 5.5.7 uses ORIGIN or configured/request headers for the request origin; with ORIGIN and PROTOCOL_HEADER unset, it defaults to https and uses the request Host header unless HOST_HEADER supplies one.", "components": ["svelte", "nuxt", "adapter", "nuxt-output", "nitro-node"], "sources": ["svelte:s59abf03bae6a", "nuxt:s32e447cb5ef4", "adapter:sfd51397a510e", "adapter:s6152d66c6b19", "adapter:s7b3a11637166", "nuxt-output:sd00a53729513", "nitro-node:sd56c769d6dae", "nitro-node:s32975278fc3f", "nitro-node:sdfda9cd3ce7b", "nitro-node:sdf38c24e1f80", "nitro-node:s91ab58ddc148", "nitro-node:s0c8ca22542d2"], "status": "REASONED", "verify": [1]},
    "verify-proxy-nitro": {"text": "Nuxt 4.0.0 pins nitropack 2.12.0, which falls back to its node-server preset for a non-static production build with no preset named or matched; that preset passes the h3 app through toNodeListener to a Node HTTP or HTTPS server.", "components": ["nuxt-output", "nitro-node"], "sources": ["nuxt-output:sd00a53729513", "nitro-node:sd56c769d6dae", "nitro-node:s32975278fc3f", "nitro-node:sdfda9cd3ce7b", "nitro-node:sdf38c24e1f80", "nitro-node:s91ab58ddc148", "nitro-node:s0c8ca22542d2"], "status": "REASONED", "verify": [1]},
    "verify-proxy-scope": {"text": "Guide assessment: Nuxt's own trusted-proxy and origin handling come from its deployment preset and hosting platform rather than one documented app-level variable; the cited lines do not establish how h3 1.x or the hosting platform treats Host and forwarded headers or a deployed cookie and redirect outcome.", "components": ["svelte", "nuxt", "adapter", "nuxt-output", "nitro-node"], "sources": ["svelte:s59abf03bae6a", "nuxt:s32e447cb5ef4", "adapter:sfd51397a510e", "adapter:s6152d66c6b19", "adapter:s7b3a11637166", "nuxt-output:sd00a53729513", "nitro-node:sd56c769d6dae", "nitro-node:s32975278fc3f", "nitro-node:sdfda9cd3ce7b", "nitro-node:sdf38c24e1f80", "nitro-node:s91ab58ddc148", "nitro-node:s0c8ca22542d2"], "status": "REASONED", "verify": [1]}
  }
}
````
<!-- version-basis:end -->
