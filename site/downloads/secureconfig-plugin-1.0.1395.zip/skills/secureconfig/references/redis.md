# Redis: TLS and authentication

Redis is an in-memory data store used as a cache, key-value database or message channel. This guide helps your AI assistant configure it securely, including a local bind unless remote access is deliberate, a required credential, locked-down runtime commands, and TLS where server and client are built with it.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/redis.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Redis configuration 6.0.20, 6.2.14, 6.2.0, 7.0.15, 8.2.1, and 8.6.0, Redis HA source 8.10.1, Redis image tag v8.10.2, and Redis compiled defaults 7.4.8 and 8.10.2; 1 further source is pinned to a commit and 3 carry no recorded version. Metadata reviewed 2026-09-26; documentation checked September 2026. The guide records 59 claims: 1 demonstrated by a check that ran; 58 reasoned from cited sources and any earlier-form run (not a live demonstration of the shipped form).

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

Redis trusts its network by design, so the network boundary and credentials are your job. An exposed unauthenticated Redis leaks its data, and historic attack tooling has also used the CONFIG command against open instances to write files and take over hosts. Applies to Redis 6.0 and later for TLS and ACLs; the server and client must be built with TLS support. Additional controls below carry their minimum versions. See the [Redis security](https://redis.io/docs/latest/operate/oss_and_stack/management/security/) and [TLS documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/).

This guide targets upstream Redis 6.0 and later. The existing configuration references through 8.2.1 pin syntax and historical behaviour, not a deployment version. Sections 9-15 add deployment-exposure controls for replication, Sentinel, and Redis Cluster, reviewed against upstream Redis 8.10.1. Version-specific examples carry their own qualifications; the Redis 8.10 peer-name control does not belong in a generic Redis 6.0+ configuration. These HA findings establish no equivalent Valkey or Redis Enterprise behaviour; the Valkey compatibility note remains separate.

## 1. Keep it local unless remote access is deliberate

In `redis.conf`:

```
# Redis 6.2+: "-" makes an address optional if it is absent from local interfaces.
# An address already in use still fails startup.
# Redis 6.0: use "bind 127.0.0.1" instead.
# Keep comments on separate lines.
bind 127.0.0.1 -::1
protected-mode yes
```

`protected-mode` confines clients to the loopback interfaces and Unix sockets, but only while the default user still has its `nopass` flag and, on Redis 6.0/6.2, no explicit `bind` is configured. Redis 7.0 keeps the `nopass` condition and drops the `bind` condition. On Redis 6.0/6.2, setting any explicit `bind` disables this protected-mode restriction; a wildcard bind such as `bind 0.0.0.0` then permits remote passwordless access while the default user remains `on nopass`, whereas a loopback-only `bind 127.0.0.1` still confines access to the local host. Treat protected mode as a backstop for the unconfigured default; the bind address and credentials are the controls. The pinned [6.2 configuration](https://raw.githubusercontent.com/redis/redis/6.2.14/redis.conf) and [7.0 configuration](https://raw.githubusercontent.com/redis/redis/7.0.15/redis.conf) document the version difference.

The official Docker images change the protected-mode default. Their build, from redis/docker-library-redis, patches Redis so `protected-mode` defaults to `no`; this holds for every image on the repository's default branch at the pinned commit (6.2 through 7.4, Debian and Alpine) and for the 8.10.2 release tag, the only 8.x build checked. Their default command runs `redis-server` with no configuration file, so the compiled-in defaults apply; in the 7.4.8 and 8.10.2 builds those are `bind * -::*` (every IPv4 address, and every IPv6 address where the container has IPv6) and a `default` user that is `on`, `nopass` and `+@all`. A container from those images, started without a configuration file or arguments of its own, therefore accepts unauthenticated connections from any address that reaches it, with the `default` user's `+@all` permissions (commands that Redis disables by default, such as `DEBUG` and `MODULE` on 7.0 and later, stay disabled; see section 5). Start it with a configuration file carrying the credential settings in section 2 (a loopback `bind` inside the container would also block published traffic), and publish only to host loopback or a private network.

## 2. Require a credential

Minimum, using a single shared password sent by clients with `AUTH`:

```
requirepass REPLACE_WITH_LONG_RANDOM_PASSWORD
```

Better, per-service ACL users with least privilege, supported since Redis 6:

```
user app on >REPLACE_WITH_LONG_RANDOM_PASSWORD ~app:* +@read +@write -flushall -flushdb -swapdb
```

That grants the `app` user the read and write command categories, and `~app:*` restricts only the key arguments those commands take, to keys named `app:*`. It does not confine commands that take no key: `+@write` still includes `FLUSHALL` (clears every database), `FLUSHDB` (clears the current database), `SWAPDB` (swaps two databases), and, on Redis 7 and later, the FUNCTION write subcommands (`FUNCTION LOAD`, `FUNCTION DELETE`, `FUNCTION FLUSH`, `FUNCTION RESTORE`) that manage global libraries. `+@read` still includes keyspace-walking commands such as `KEYS`, `SCAN`, and `RANDOMKEY` that range outside `app:*`.

The `-flushall -flushdb -swapdb` above removes those three commands only, not every keyless write. For real least privilege, allowlist only the commands the app uses, for example `~app:* +get +set`, and expand that list deliberately. Apply that replacement with `reset`, as shown in section 3, rather than adding it to an existing broad policy. See the [ACL rules](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/) and the command references in Sources.

Generate passwords per [authentication.md](authentication.md). The `default` user starts `on nopass ~* +@all` (Redis 6.2 adds `&*` for Pub/Sub channels), so with ACLs as your control you must secure it before any remote exposure: give it a strong password, or set `user default off resetpass` in `redis.conf` or the ACL file and apply it on a running server with `ACL SETUSER default off resetpass`. Do that only after every client authenticates as a named user and a separate named administrator has been tested. A connection already authenticated as `default` keeps working until it disconnects; section 3 covers revocation. See the [ACL authentication and user-state rules](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/).

MFA: Redis has no second-factor dialogue. For machine clients, `tls-auth-clients yes` (mutual TLS, below) adds a possession factor, a certificate, alongside the password; that is stronger than a password alone but it is not MFA for a person. Human paths to the host go behind MFA per [mfa.md](mfa.md).

On Redis 8.6+, the certificate-plus-password description assumes certificate-to-user automatic authentication is disabled. Redis 8.6 introduced `tls-auth-clients-user`, which defaults to `off`; enabling it can authenticate a connection without a separate password exchange. On Redis 8.6+, keep this setting `off` for the guide's certificate-plus-password and unauthenticated-certificate `NOAUTH` checks. Earlier releases do not support this directive; omit it entirely, because an unknown configuration directive prevents startup. See the [8.6 release notes](https://redis.io/docs/latest/operate/oss_and_stack/stack-with-enterprise/release-notes/redisce/redisos-8.6-release-notes/), [pinned certificate authentication configuration](https://raw.githubusercontent.com/redis/redis/8.6.0/redis.conf), and [registered default](https://raw.githubusercontent.com/redis/redis/8.6.0/src/config.c).

## 3. Make ACL restrictions durable and replace old permissions explicitly

`ACL SETUSER` modifies an existing user incrementally. A narrower-looking command does not remove earlier passwords, key patterns, or command grants. Start a replacement policy with `reset`; on Redis 7+, that also clears selectors, which otherwise provide alternative grants. Rules are processed from left to right. See [ACL SETUSER](https://redis.io/docs/latest/commands/acl-setuser/).

Use a separate administrative account, called `ops` here, with the permissions needed for the management commands below. Test its login before changing application users or disabling `default`. Connect over TLS using section 7 with `--user ops`.

The following is input at the Redis prompt, not a shell command. Replace the password placeholder there. Do not put the password or the complete `ACL SETUSER` command in the shell invocation's arguments.

```
ACL SETUSER app reset on >REPLACE_WITH_LONG_RANDOM_PASSWORD resetchannels ~app:* +get +set
```

This example requires Redis 6.2+ because of `resetchannels`. For Redis 6.0, omit that token; channel ACLs are unavailable there. Explicitly resetting channels avoids inheriting the Redis 6.2 `allchannels` default. Redis 7.0 changed that default to `resetchannels`. See the [pinned ACL configuration](https://raw.githubusercontent.com/redis/redis/8.2.1/redis.conf).

Keep CLI history disabled as shown in section 7. Passwords entered in ACL commands can still appear on the terminal or in session recordings. Protect configuration and ACL files, including their password hashes.

Choose one persistence method:

- **Users in `redis.conf`:** after checking the runtime policy, run `CONFIG REWRITE` from the administrative Redis prompt. Redis must have been started with a configuration file and must be able to write it. Require an `OK` response. This rewrites other runtime configuration too, so review the resulting file. See [CONFIG REWRITE](https://redis.io/docs/latest/commands/config-rewrite/).
- **Users in an external ACL file:** configure the following in `redis.conf`, and move all `user` definitions, including the administrator and secured `default` user, into that file. Redis refuses to start if inline `user` definitions and `aclfile` are both configured.

```
aclfile /etc/redis/users.acl
```

With `aclfile` configured, run `ACL SAVE` to persist runtime ACL changes. If instead you edit the ACL file, run `ACL LOAD` to replace the runtime rules from it. Require `OK`; an invalid file leaves the previous runtime rules in place. `CONFIG REWRITE` does not perform `ACL SAVE`. Do not combine this mode with `requirepass`: configure the default user's credential in the ACL file instead. See [ACL persistence](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/#use-an-external-acl-file), [ACL SAVE](https://redis.io/docs/latest/commands/acl-save/), and [ACL LOAD](https://redis.io/docs/latest/commands/acl-load/).

Keep the deployment's configuration source synchronized with the saved policy so a redeployment does not restore old permissions.

For a cutover from an old named user, first authenticate and test the replacement user. Then, from the separate administrator's Redis prompt, disable the old user and close its sessions:

```
ACL SETUSER app-old off resetpass
CLIENT KILL USER app-old SKIPME no
```

Replace `app-old` with the actual retired username. Disabling the user prevents new authentication; `CLIENT KILL` closes existing authenticated connections. Its integer reply is the number closed, which may be zero. Persist the disabled user with the chosen method. When retiring `default`, use `default` in both commands after migrating every client. See [user disabling](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/) and [CLIENT KILL](https://redis.io/docs/latest/commands/client-kill/).

If retaining the username while changing its password, existing connections are not forced to authenticate again. After applying the replacement policy, use `CLIENT KILL USER app SKIPME no` from the separate administrator to force reconnection, and account for the resulting application interruption.

## 4. Separate read/write key permissions and Pub/Sub channel permissions

Redis 7.0+ supports `%R~pattern` for reading key values and `%W~pattern` for writing keys. Ordinary `~pattern` grants both. Command permission is also required; a key pattern alone grants no commands. Avoid adding a broader `~app:*` grant that would defeat the intended separation. See [key permissions](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/#key-permissions).

For a worker that reads inputs, writes outputs, and publishes events, enter this replacement policy at the administrative Redis prompt:

```
ACL SETUSER app-worker reset on >REPLACE_WITH_DISTINCT_WORKER_PASSWORD resetchannels %R~app:input:* %W~app:output:* &app:events:* +get +set +publish
```

Persist it using section 3. The intended permissions are:

| Operation | Result |
| --- | --- |
| `GET app:input:probe` | Allowed |
| `SET app:output:probe value` | Allowed |
| `SET app:input:probe value` | Denied |
| `GET app:output:probe` | Denied |
| `PUBLISH app:events:probe value` | Allowed |
| `PUBLISH other:events:probe value` | Denied |

Key permissions and channel permissions are separate. `~app:*` does not restrict Pub/Sub channels; `&app:events:*` does not grant access to keys. Channel patterns require Redis 6.2+. Start with `resetchannels`, then add only the necessary channel patterns and commands. For an application without Pub/Sub, keep `resetchannels` and grant no Pub/Sub commands. See [ACL SETUSER channel rules](https://redis.io/docs/latest/commands/acl-setuser/).

The worker above cannot subscribe. If a subscriber needs `SUBSCRIBE`, grant it deliberately. If it needs `PSUBSCRIBE`, its requested pattern must literally match an allowed channel pattern; an apparently narrower glob is not sufficient. See the [Pub/Sub ACL rules](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/#acl-rules).

## 5. Lock down runtime configuration, debugging, modules, and scripting

Keep administrative capabilities out of application users. The explicit command allowlists above already exclude them. When reviewing a broader policy, subtract administrative, dangerous, and scripting categories after any grants. For the selector-free `app` policy established in section 3, this administrative Redis command makes the exclusions explicit on Redis 7+:

```
ACL SETUSER app -@admin -@dangerous -@scripting -config -debug -module -script -function
```

On Redis 6.x, omit `-function`, because Redis Functions arrived in Redis 7.0. Persist the result. For an existing policy with unknown selectors, rebuild it with `reset` first; subtracting from the root rules does not remove an alternative selector's grants. See [ACL SETUSER](https://redis.io/docs/latest/commands/acl-setuser/).

`-@admin -@dangerous` alone does not disable scripting. For example, `EVAL`, `EVALSHA`, and `FCALL` belong to `@scripting`; FUNCTION library writes also belong to `@write`. Removing `SCRIPT` and `FUNCTION` alone does not remove the separate execution commands. Use `-@scripting` when the application needs no scripting, including the read-only execution variants. See [EVAL](https://redis.io/docs/latest/commands/eval/), [EVALSHA](https://redis.io/docs/latest/commands/evalsha/), [FCALL](https://redis.io/docs/latest/commands/fcall/), and [FUNCTION LOAD](https://redis.io/docs/latest/commands/function-load/).

If scripting is required, add only the execution commands the application needs and review its key permissions. Keep script and function management with the deployment administrator.

On Redis 7.0+, keep these startup settings in `redis.conf`:

```
enable-debug-command no
enable-module-command no
```

At the time of writing, `no` is the default in the pinned configuration. The alternatives are `yes` and `local`; a local connection is still an application connection that needs appropriate ACLs. These settings supplement command permissions. Disabling runtime module management does not remove modules loaded at startup or deny their own commands. Retain explicit command allowlists and review any modules enabled by the deployment. See the [pinned startup configuration](https://raw.githubusercontent.com/redis/redis/8.2.1/redis.conf).

`rename-command` is deprecated. Use ACLs to restrict commands instead of relying on renamed commands as an access boundary. See [Redis command restrictions](https://redis.io/docs/latest/operate/oss_and_stack/management/security/#disallowing-specific-commands).

## 6. Enable TLS

Get a certificate ([free-certificates.md](free-certificates.md) or [self-signed.md](self-signed.md)), then replace the plaintext port with a TLS listener:

```
# No plaintext listener.
port 0
tls-port 6379
tls-cert-file    /etc/redis/tls/server.crt
tls-key-file     /etc/redis/tls/server.key
tls-ca-cert-file /etc/redis/tls/ca.crt
# The default is yes: require a client certificate.
# This deliberate downgrade relies on the password/ACL control in section 2.
tls-auth-clients no
```

Set `tls-auth-clients yes` for machine-to-machine deployments where clients can hold certificates; it is stronger than passwords alone. With `yes`, clients must also pass `--cert client.crt --key client.key`, or the TLS handshake is rejected before any `AUTH`. Confirm that a missing or untrusted client certificate is refused. See [Redis TLS](https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/).

For HA deployments, the deliberate `tls-auth-clients no` above also removes the client-certificate requirement for incoming replicas on the data listener. Use section 13's mutual TLS settings for those connections. Enabling the client TLS listener alone does not enable outgoing replication TLS or cluster-bus TLS. The TLS cluster bus always requires a peer certificate, regardless of the data listener's `tls-auth-clients` setting. See the [replication TLS documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/) and pinned [cluster accept implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/cluster_legacy.c).

## 7. Client side

Replace the host inside the single quotes with your Redis hostname, such as `redis.example.com`, and paste the whole block. `--askpass` reads the password from standard input with masking, keeping it out of process arguments. Use `--user ops` for administrative sessions.

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_REDIS_HOST'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not connecting"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 host; not connecting"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute your Redis host; not connecting"; exit 2 ;;
    *)
      REDISCLI_HISTFILE=/dev/null redis-cli --tls \
        --cacert /etc/redis/tls/ca.crt -h "$1" -p 6379 --user app --askpass
      ;;
  esac
)
```

With `tls-auth-clients yes`, also add `--cert /etc/redis/tls/client.crt --key /etc/redis/tls/client.key` to the TLS invocation.

The client sends the named-user `AUTH` exchange. At the Redis prompt:

```
GET app:probe
```

`GET app:probe` is allowed by both the introductory ACL and the narrowed policy in section 3; `(nil)` is a successful read of a missing key. `PING` sits in the `@connection` and `@fast` categories, which neither policy grants, so it fails for `app`. Application clients take equivalent TLS and credential options; point them at the CA rather than disabling verification. See [Redis CLI](https://redis.io/docs/latest/develop/tools/cli/), [AUTH](https://redis.io/docs/latest/commands/auth/), [GET](https://redis.io/docs/latest/commands/get/), and [PING](https://redis.io/docs/latest/commands/ping/).

## 8. Verify (REASONED: deployment and HA comparisons from cited Redis documentation and pinned sources; no Redis runtime, live topology or permitted socket inspection.)

REASONED: the deployment checks below, from the cited Redis documentation and pinned sources; they are not demonstrated. The authoring environment has no `redis-server`, `redis-cli`, Docker, or Podman, and denies socket inspection. No live deployment was supplied. Shell syntax and placeholder rejection were checked locally; Redis configuration parsing remains unconfirmed, and exposed/fixed runtime behaviour is REASONED from the cited documentation and pinned sources. Those local checks covered an earlier form of the guarded shell blocks, whose refusals exited with status 1 and whose probes set no status of their own. The current form of every shell block in this section is covered by the repository gate suite's `bash -n` and ShellCheck 0.11.0 passes and by stub runs on 31 October 2026 under bash 5.3.9, with stand-ins for `ss`, `redis-cli`, `nc`, `openssl` and `timeout`; no Redis process or network was involved. Each block now exits once with one status: 1 for a finding, which outranks 3 for a failed command or an inconclusive result; 2 for a refusal before any probe; and 0 otherwise. Once its probes run, its last line names what it leaves for you to judge. The two listener inventories refuse with status 2, printing `ss is not installed here; not listing sockets`, when `ss` is missing, and the replica-certificate, cluster-bus certificate and peer-name checks refuse with status 2 when a CA, certificate or key file they read is not readable. For a plaintext request, a closed or reset connection without a RESP reply is the expected rejection, and any other plaintext failure is inconclusive. In the replica-certificate, cluster-bus certificate and peer-name checks, a failed negative probe counts as the expected rejection only when its error names a bad-certificate, certificate-unknown or certificate-required alert, or an unknown-CA alert for the untrusted certificate. A generic handshake failure, a closed or reset connection or any other failure there cannot be told apart from an unrelated failure, so it is inconclusive even in a fixed state, and the server's log line for the rejected handshake is left for you to read. Which error text `redis-cli` and OpenSSL print, and which alert a rejecting server sends, is this guide's assessment, not observed here, so a real rejection worded otherwise reads as inconclusive.

**Listener inventory.** On the Redis host, inspect every listener:

```bash
(                                       # a subshell, so the exits below end only the subshell
  command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
  if ss -tlnp; then
    echo "unclassified observation: read every listener above; for the local-only configuration, Redis TCP listeners belong on loopback"
    exit 0
  else
    echo "ss -tlnp exit $?: a socket-inspection error is inconclusive; read the error above"
    exit 3
  fi
)
```

For the local-only configuration, Redis TCP listeners should be on loopback. An unintended wildcard or external-interface listener fails that configuration's check. Deliberate remote access needs the intended private listener and network restrictions. A socket-inspection error is inconclusive. The bind behaviour follows the [pinned configuration](https://raw.githubusercontent.com/redis/redis/8.2.1/redis.conf).

**Plaintext and unauthenticated TLS checks.** Run from a client location that should reach Redis. Substitute the actual hostname inside the quotes. For mutual TLS, add the client certificate and key options to the TLS command.

```bash
(
  set +e                                # errexit off here, so a probe that ends nonzero is classified below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_REDIS_HOST'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 host; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute your Redis host; not probing"; exit 2 ;;
  esac
  unset REDISCLI_AUTH || exit 2
  set -- 0 "$1" "$(if redis-cli -h "$1" -p 6379 ping 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "${3##*$'\n'}" "${3%$'\n'*}"   # the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0), the host, redis-cli's exit status, then its output
  printf '%s' "$4"
  case "$3:$4" in
    0:*|*PONG*|*NOAUTH*) echo "FINDING: the plaintext ping got a RESP reply, so plaintext Redis is still available at this endpoint"; set -- 1 "$2" ;;
    *'Server closed the connection'*|*'Connection reset by peer'*) echo "no RESP reply recognized to the plaintext ping (redis-cli exit $3); the TLS ping below decides whether that is the pass"; set -- 0 "$2" ;;
    *) echo "the plaintext ping got neither a RESP reply nor a closed or reset connection (redis-cli exit $3), as a timeout, resolution failure, refusal or local error does; inconclusive"; set -- 3 "$2" ;;
  esac
  set -- "$1" "$2" "$(if redis-cli --tls --cacert /etc/redis/tls/ca.crt -h "$2" -p 6379 ping 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "${3##*$'\n'}" "${3%$'\n'*}"   # status, host, redis-cli's exit status, then its output
  printf '%s' "$4"
  case "$4" in
    *NOAUTH*) echo "the TLS ping reached NOAUTH, the secured default user's reply" ;;
    *PONG*) echo "FINDING: the TLS ping got PONG without credentials, as an exposed default on nopass +@all does"; set -- 1 "$2" ;;
    *) echo "the TLS ping reached neither NOAUTH nor PONG (redis-cli exit $3), so it did not confirm the endpoint; inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" ;;
  esac
  echo "block exit $1; the authenticated GET app:probe positive control from section 7 is left for you to run and judge"
  exit "$1"
)
```

Any RESP reply to the plaintext command, including `PONG`, `NOAUTH`, or another Redis error, means plaintext Redis is still available at that endpoint. With `port 0` and `tls-port 6379`, TCP 6379 remains open for TLS: expect the plaintext connection to close or reset without a RESP reply. A timeout, name-resolution failure, or connection refusal alone proves nothing. Confirm that the TLS command reaches the same endpoint.

For the secured default user in this guide, the unauthenticated TLS request should return `NOAUTH`. An exposed `default on nopass +@all` returns `PONG` when the connection is otherwise permitted. With mutual TLS, a missing client certificate fails before this authentication check. Then authenticate as `app` using section 7 and confirm `GET app:probe` succeeds. These distinctions follow the [TLS listener documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/) and [ACL default-user rules](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/).

**ACL readback and denied-privilege review.** In the separate administrative session:

```
ACL GETUSER app
ACL GETUSER default
ACL LOG 20
```

After sections 3 and 5, `app` should be enabled, have a password hash without `nopass`, allow only `GET` and `SET`, have only `~app:*`, and have no channel grants or selectors. `default` should be disabled or separately password-protected. Redis may normalize the command-rule representation; compare effective permissions. Unexpected categories, wildcard patterns, additional passwords, or selectors need investigation. Do not publish the password hashes from the readback. See [ACL GETUSER](https://redis.io/docs/latest/commands/acl-getuser/).

In a fresh session authenticated as `app`, run this non-destructive check:

```
GET app:probe
CONFIG GET bind
```

The first command is the positive control. The second must return `NOPERM` for the policy above. An overprivileged account with CONFIG access returns the bind configuration instead. `NOAUTH`, connection errors, and unknown-command errors do not demonstrate the intended ACL denial. `CONFIG GET` reads configuration without changing it. See [CONFIG GET](https://redis.io/docs/latest/commands/config-get/).

Back in the administrative session:

```
ACL LOG 20
```

Look for the corresponding denied CONFIG command, the `app` username, and a recent event age. Review unexpected `auth`, `command`, `key`, and `channel` failures. Record relevant events before any reset; do not clear the log as part of this check. The log is bounded and held in memory, so an empty result is not proof that no failures occurred. See [ACL LOG](https://redis.io/docs/latest/commands/acl-log/) and the [pinned ACL-log configuration](https://raw.githubusercontent.com/redis/redis/8.2.1/redis.conf).

**Read/write and channel policy checks, Redis 7.0+.** If section 4's worker is configured, run these from the administrative session:

```
ACL GETUSER app-worker
ACL DRYRUN app-worker GET app:input:probe
ACL DRYRUN app-worker SET app:output:probe value
ACL DRYRUN app-worker SET app:input:probe value
ACL DRYRUN app-worker GET app:output:probe
ACL DRYRUN app-worker PUBLISH app:events:probe value
ACL DRYRUN app-worker PUBLISH other:events:probe value
```

Expect `OK` for reading inputs, writing outputs, and publishing within the allowed channel pattern. Expect permission-denial descriptions for the other three requests. An overly broad policy would also allow those forbidden requests. `ACL DRYRUN` checks permission without executing the request, so these checks neither write keys nor publish messages. It does not demonstrate successful authentication or replace the actual denied CONFIG request above. See [ACL DRYRUN](https://redis.io/docs/latest/commands/acl-dryrun/).

**REASONED: persistence and revocation.** During a planned restart of a disposable test instance, repeat `ACL GETUSER app`, `ACL GETUSER default`, and the applicable permission checks. A runtime-only change reverts; the persisted policy survives. After retiring `app-old`, its existing connection must close and a fresh authentication attempt must fail. Use section 7's masked prompt with the old username to test this, without putting its password in arguments. See [ACL persistence](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/#use-an-external-acl-file) and [CLIENT KILL](https://redis.io/docs/latest/commands/client-kill/).

The following checks cover sections 9-15. All are **REASONED, not demonstrated**: the authoring environment has no `redis-server`, `redis-cli`, Docker, or Podman, and no live HA topology was supplied. Run exposed-state comparisons only in a disposable isolated environment. Redis-prompt commands below are not shell commands. Use section 7's guarded connection block, masked password prompt, and disabled CLI history for authenticated data-server sessions, changing the username as directed. Certificate and key options name files; never put their contents or passwords in process arguments. References below to disabling certificate-to-user automatic authentication apply only to Redis 8.6+, as explained in section 2. Earlier releases lack that setting; do not add the directive to their configuration.

**Replication authentication and promotion, section 9.** No live primary/replica pair or failover topology was available. Compare an unsecured primary accepting an uncredentialed replica with a secured primary rejecting missing or wrong replication credentials. After restoring correct credentials, run this in an administrative session on the replica:

```
INFO replication
```

Require `master_link_status:up`, then write a disposable canary through an authorized primary session and read it from the replica. Separately repeat the unauthenticated data-listener check against the replica: it must reject the request even though its outbound replication login succeeds. See the [replication authentication implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/replication.c), [replica authentication documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/replication/#setting-a-replica-to-authenticate-to-a-master), and [INFO replication fields](https://redis.io/docs/latest/commands/info/).

On Redis 7+, run these at the administrative Redis prompt:

```
ACL DRYRUN replication PSYNC ? -1
ACL DRYRUN app PSYNC ? -1
```

Expect `OK` for `replication` and a permission-denial description for the guide's restricted `app` user. These are permission checks, not synchronization tests. They need one server; synchronization needs two processes; preserving authentication through promotion needs a live failover exercise with the checks repeated after roles change. See [ACL DRYRUN](https://redis.io/docs/latest/commands/acl-dryrun/) and the [replica command requirements](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/#acl-rules-for-sentinel-and-replicas).

**Sentinel listener, incoming authentication, and peers, section 10.** No live Sentinel or peer group was available. Repeat the unfiltered `ss -tlnp` inventory on the Sentinel host and account for its separate 26379 listener. Against Sentinel itself, compare this request before and after securing incoming authentication, while holding the transport configuration constant:

```
SENTINEL GET-MASTER-ADDR-BY-NAME mymaster
```

An exposed instance returns the monitored endpoint; the secured instance returns `NOAUTH` without Redis authentication, then permits discovery with valid credentials. Supply a trusted client certificate when mutual TLS is required, with certificate-to-user automatic authentication disabled for this comparison. The guarded Sentinel probe below supplies the TLS form. Authenticate as `discovery` and confirm administrative subcommands are denied with `NOPERM`; a read-only administrative check is `SENTINEL CONFIG GET '*'` on Redis 6.2+. A connection error or `NOAUTH` does not demonstrate the discovery user's ACL denial. See the [Sentinel command and authentication documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#configuring-sentinel-instances-with-authentication).

One Sentinel suffices for listener and incoming-authentication checks. From an administrative Sentinel session, use `SENTINEL SENTINELS mymaster` to inspect peer announcements, and verify actual authenticated peer communication with multiple Sentinels. Announcement readback alone does not establish reachability. See the [pinned peer and announcement settings](https://raw.githubusercontent.com/redis/redis/8.10.1/sentinel.conf).

**Sentinel monitored-server permissions and failover, section 11.** No live data server or Sentinel topology was available. In a data-server session authenticated as `sentinel-monitor`, run:

```
PING
GET app:probe
PUBLISH unrelated:probe value
```

Expect `PONG`, then `NOPERM` for both the key read and unrelated-channel publish. An unrestricted account permits the latter operations. Review `ACL LOG 20` from the separate administrator during monitoring; preserve relevant denials without clearing the log. These permission checks need one data server. See the [Sentinel-specific channel and command policy](https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#redis-access-control-list-authentication).

In a disposable Sentinel and primary/replica topology, missing or wrong `sentinel auth-pass` must prevent successful authenticated monitoring; correct credentials must restore it. Exercise promotion, then confirm Sentinel monitoring and replication continue with the former replica as primary. The [pinned authentication implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/sentinel.c) uses the monitored primary's credentials for its replicas too.

**Cluster-bus exposure and announcements, section 12.** No cluster-enabled process or multi-node topology was available. Repeat unfiltered `ss -tlnp`, then run this through an authenticated administrative data-port session:

```
CLUSTER NODES
```

Inspect the advertised address and `@bus-port`. Compare bus connectivity from an unauthorized network with connectivity from an allowed peer: an exposed bus permits the former, while the fixed network boundary denies it and retains the working peer path. Failure from outside is meaningful only alongside a working authorized path and listener/network-policy evidence. A missing Redis `PING` response is not evidence that the binary bus is blocked. One cluster-enabled process can demonstrate its listener; working membership and advertised reachability need multiple nodes. See [CLUSTER NODES](https://redis.io/docs/latest/commands/cluster-nodes/), [cluster networking](https://redis.io/docs/latest/operate/oss_and_stack/management/scaling/#redis-cluster-tcp-ports), and the [pinned listener and announcement implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/cluster_legacy.c).

The section 12 network comparison in the following block is REASONED from the cited cluster networking requirements, because no live bus endpoint or authorized and unauthorized probe locations were available. Run this concrete TCP probe from both locations, using OpenBSD `nc`. Substitute the actual host and bus port inside the quotes, and `unauthorized` or `allowed` for the location you run it from.

```bash
(
  set +e                                # errexit off here, so a probe that ends nonzero is classified below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_CLUSTER_HOST' 'REPLACE_WITH_BUS_PORT' 'REPLACE_WITH_unauthorized_OR_allowed'   # the 3rd value is where you run this from: unauthorized, or allowed for the authorized-peer control
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 1 host, 1 port, and 1 location; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the host; not probing"; exit 2 ;;
  esac
  case "$2" in
    *[!0123456789]*|"") echo "substitute a numeric port; not probing"; exit 2 ;;
  esac
  if [ "$2" -ge 1 ] && [ "$2" -le 65535 ]; then :; else echo "port must be 1-65535; not probing"; exit 2; fi
  case "$3" in
    unauthorized|allowed) ;;
    *) echo "substitute unauthorized or allowed, the location you run this from; not probing"; exit 2 ;;
  esac
  set -- 0 "$@" "$(if nc -vz -w 5 "$1" "$2" 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "$4" "${5##*$'\n'}" "${5%$'\n'*}"   # the block's status so far, host, port, location, nc's exit status, then its messages
  printf '%s' "$6"
  if [ "$5" = 0 ]; then
    echo "TCP connected; the bus port is reachable from here"
  else
    printf 'TCP probe exit=%s; compare with the allowed-peer control\n' "$5"
  fi
  case "$4:$5:$6" in
    unauthorized:0:*) echo "FINDING: the unauthorized location reached the bus port, so the network boundary permits it"; set -- 1 ;;
    allowed:0:*) echo "the allowed-peer control connected" ;;
    allowed:*) echo "the allowed-peer control did not connect; inconclusive"; set -- 3 ;;
    *'Connection refused'*|*'timed out'*) echo "the unauthorized location was refused or timed out: the pass only alongside a connected allowed-peer run" ;;
    *) echo "nc reported neither a refusal nor a timeout (a local tool error or name-resolution failure, for example); inconclusive"; set -- 3 ;;
  esac
  echo "block exit $1; nc's messages and the listener and network-policy evidence are left for you to judge"
  exit "$1"
)
```

An exposed network boundary permits a TCP connection from the unauthorized location. The fixed boundary denies that connection while retaining the allowed peer's successful connection to the intended listener. A local tool error, name-resolution failure, or failed allowed-peer control is inconclusive. This probes TCP reachability only, not TLS, certificate acceptance, or cluster membership. See the [cluster networking requirements](https://redis.io/docs/latest/operate/oss_and_stack/management/scaling/#redis-cluster-tcp-ports).

**REASONED: replication encryption and incoming certificates, section 13.** No live primary/replica pair, certificate fixtures, or connection evidence was available. Use a disposable pair connected directly, without a TLS-terminating proxy. Correlate the primary's actual listener, the replica's established connection, and successful replication. `INFO replication` reports link status, not encryption.

At the primary's authenticated administrative Redis prompt:

```
CONFIG GET port
CONFIG GET tls-port
```

For the fixed configuration, require `port` to be `0` and record the nonzero `tls-port`. At the replica's authenticated administrative Redis prompt:

```
CONFIG GET tls-replication
INFO replication
```

Require `tls-replication` to be `yes`, `master_host` and `master_port` to identify that primary's TLS endpoint, and `master_link_status:up`. On the replica host, inspect established connections:

```bash
(                                       # a subshell, so the exits below end only the subshell
  command -v ss >/dev/null || { echo "ss is not installed here; not listing sockets"; exit 2; }
  if ss -tnp; then
    echo "unclassified observation: find the replica process's established connection to the recorded primary address and TLS port above; without process information the list cannot show which process owns it"
    exit 0
  else
    echo "ss -tnp exit $?: a socket-inspection error is inconclusive; read the error above"
    exit 3
  fi
)
```

Identify the replica process's established connection to the recorded primary address and TLS port. Use an account permitted to see process information. Missing process information or a socket-inspection error is inconclusive.

From an allowed client location, probe that same primary endpoint. Substitute a DNS hostname or IPv4 address and the recorded TLS port inside the quotes. Use the installed CA and client certificate paths. The commands deliberately omit Redis credentials; on Redis 8.6+, keep certificate-to-user automatic authentication disabled for this comparison.

```bash
(
  set +e                                # errexit off here, so a probe that ends nonzero is classified below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_PRIMARY_HOST' 'REPLACE_WITH_PRIMARY_TLS_PORT'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 1 host and 1 port; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the host; not probing"; exit 2 ;;
  esac
  case "$2" in
    *[!0123456789]*|"") echo "substitute a numeric port; not probing"; exit 2 ;;
  esac
  if [ "$2" -ge 1 ] && [ "$2" -le 65535 ]; then :; else echo "port must be 1-65535; not probing"; exit 2; fi
  if [ -r /etc/redis/tls/ha-ca.crt ] && [ -r /etc/redis/tls/client.crt ] && [ -r /etc/redis/tls/client.key ]; then :; else
    echo "the CA, client certificate and key files named below must be readable here; not probing"; exit 2
  fi
  unset REDISCLI_AUTH || exit 2
  printf '\nNo client certificate\n'
  set -- 0 "$1" "$2" "$(if timeout 10s redis-cli --tls --cacert /etc/redis/tls/ha-ca.crt \
      -h "$1" -p "$2" PING 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "${4##*$'\n'}" "${4%$'\n'*}"   # the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0), host, port, the probe's exit status, then its output
  printf '%s' "$5"
  if [ "$4" = 0 ]; then
    echo "inspect the RESP reply; exit=0 alone is not a pass"
  else
    printf 'probe exit=%s; inspect the TLS or authentication error\n' "$4"
  fi
  # under TLS 1.3 a server that rejects the missing certificate after the handshake may leave redis-cli reporting only a closed connection, which reads as inconclusive here even when the listener is fixed
  case "$4:$5" in
    0:*|*NOAUTH*|*PONG*) echo "FINDING: the request without a client certificate reached Redis, so this listener does not require one"; set -- 1 "$2" "$3" ;;
    124:*) echo "the request without a client certificate timed out, which does not demonstrate rejection; inconclusive"; set -- 3 "$2" "$3" ;;
    *'alert bad certificate'*|*'alert certificate unknown'*|*'alert certificate required'*) echo "the request without a client certificate ended with a bad-certificate, certificate-unknown or certificate-required TLS alert, the rejection shape" ;;
    *'alert handshake failure'*|*'alert unknown ca'*|*'Server closed the connection'*|*'Connection reset by peer'*) echo "the request without a client certificate ended with a generic handshake failure, an unknown-CA alert or a closed or reset connection, which does not show that the missing certificate caused it; inconclusive: read the server's log line for the rejected handshake"; set -- 3 "$2" "$3" ;;
    *) echo "the request without a client certificate failed without a certificate-related TLS alert or a closed connection (a local file, name-resolution or connection error, for example); inconclusive"; set -- 3 "$2" "$3" ;;
  esac
  printf '\nTrusted client certificate, positive control\n'
  set -- "$1" "$2" "$3" "$(if timeout 10s redis-cli --tls --cacert /etc/redis/tls/ha-ca.crt \
      --cert /etc/redis/tls/client.crt --key /etc/redis/tls/client.key \
      -h "$2" -p "$3" PING 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "${4##*$'\n'}" "${4%$'\n'*}"   # status, host, port, the probe's exit status, then its output
  printf '%s' "$5"
  if [ "$4" = 0 ]; then
    echo "inspect the RESP reply; exit=0 alone is not a pass"
  else
    printf 'probe exit=%s; inspect the TLS or authentication error\n' "$4"
  fi
  case "$5" in
    *NOAUTH*) echo "the trusted-certificate positive control reached NOAUTH" ;;
    *PONG*) echo "FINDING: the trusted-certificate request got PONG without Redis credentials, as an exposed default on nopass +@all does"; set -- 1 ;;
    *) echo "the trusted-certificate positive control did not reach NOAUTH; inconclusive"; [ "$1" = 1 ] || set -- 3 ;;
  esac
  echo "block exit $1; the first request's error is left for you to judge: it must be a TLS certificate rejection, not a missing certificate file or an unreachable endpoint"
  exit "$1"
)
```

The replica-certificate check above is REASONED, because no live primary/replica pair or certificate fixtures were available to run it. With `tls-auth-clients yes`, require a TLS certificate rejection for the first request and `NOAUTH` for the trusted-certificate positive control. In the isolated comparison with `tls-auth-clients no`, both requests reach `NOAUTH`. This tests the data listener's certificate requirement, which also applies to incoming replicas; it does not authenticate a replication session. A missing or unreadable CA, certificate or key file is refused with status 2 before any request. A timeout, an unreachable endpoint, a generic handshake failure, an unknown-CA alert, a closed or reset connection or any other failure without a bad-certificate, certificate-unknown or certificate-required alert is inconclusive. In this guide's assessment, under TLS 1.3 a server that rejects the missing certificate after the handshake may leave `redis-cli` reporting only a closed connection, so a fixed listener can read 3; read the server's log line for the rejected handshake.

To confirm current synchronization, write a fresh disposable value at an authorized primary Redis prompt:

```
SET app:ha-tls-probe tls-check-1
```

Then read it at an authorized replica Redis prompt:

```
GET app:ha-tls-probe
```

Require the newly written value, changing it on each repetition. In the exposed comparison, use `tls-replication no` and the primary's plaintext endpoint: replication and the canary can still succeed, while the connection terminates on the plaintext listener. In the fixed comparison, require the active replica connection to terminate on the primary's TLS-only listener, the successful TLS positive control, and the fresh canary together. Neither link status nor a separate successful TLS probe alone proves that replication is encrypted. See the [TLS replication documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/), [pinned listener implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/server.c), [INFO replication fields](https://redis.io/docs/latest/commands/info/), and [Redis CLI options](https://redis.io/docs/latest/develop/tools/cli/).

**REASONED: cluster-bus client certificates, section 13.** No live TLS cluster-bus listener or certificate fixtures were available. From an allowed peer location, probe the actual bus port with no certificate, an otherwise valid certificate from an untrusted CA, and a trusted certificate. If Redis 8.10+ peer-name checking is enabled, both certificate fixtures must contain the expected name so this comparison isolates CA trust.

These OpenSSL probes require TLS 1.2 to be enabled on the test endpoint and GNU `timeout`. They select TLS 1.2 so a completed handshake includes the server's acceptance of the client certificate. Do not weaken a TLS 1.3-only deployment for this check; these particular probes are inconclusive there. Use protected PEM fixture files at the paths below, replace the DNS hostname or IPv4 address and actual bus port inside the quotes, and paste the whole block.

```bash
(
  set +e                                # errexit off here, so a probe that ends nonzero is classified below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_CLUSTER_HOST' 'REPLACE_WITH_BUS_PORT' 'REPLACE_WITH_EXPECTED_PEER_NAME'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 1 host, 1 port, and 1 expected peer name; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the host; not probing"; exit 2 ;;
  esac
  case "$2" in
    *[!0123456789]*|"") echo "substitute a numeric port; not probing"; exit 2 ;;
  esac
  if [ "$2" -ge 1 ] && [ "$2" -le 65535 ]; then :; else echo "port must be 1-65535; not probing"; exit 2; fi
  case "$3" in
    *REPLACE_WITH_*|"") echo "substitute the expected peer name; not probing"; exit 2 ;;
  esac
  if [ -r /etc/redis/tls/ha-ca.crt ] && [ -r /etc/redis/tls/untrusted-client.crt ] && [ -r /etc/redis/tls/untrusted-client.key ] &&
    [ -r /etc/redis/tls/ha-client.crt ] && [ -r /etc/redis/tls/ha-client.key ]; then :; else
    echo "the CA, untrusted and trusted certificate and key files named below must be readable here; not probing"; exit 2
  fi
  set -- 0 "$@"                         # the 1st value is the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 0
  printf '\nNo client certificate\n'
  set -- "$1" "$2" "$3" "$4" "$(if timeout 10s openssl s_client -connect "$2:$3" -tls1_2 -brief \
      -verify_hostname "$4" -verify_return_error -CAfile /etc/redis/tls/ha-ca.crt </dev/null 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "$4" "${5##*$'\n'}" "${5%$'\n'*}"   # status, host, port, peer name, the probe's exit status, then its output
  printf '%s' "$6"
  if [ "$5" = 0 ]; then
    echo "probe exit=0; inspect the handshake result"
  else
    printf 'probe exit=%s; inspect the TLS error\n' "$5"
  fi
  # with TLS 1.2 a server may reject a missing or untrusted certificate with only a generic handshake-failure alert, which reads as inconclusive here even when the bus is fixed
  case "$5:$6" in
    0:*) echo "FINDING: the handshake completed without a client certificate, so the bus does not require one"; set -- 1 "$2" "$3" "$4" ;;
    124:*) echo "a timeout does not demonstrate that the bus rejects a missing client certificate; inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" "$3" "$4" ;;
    *'alert bad certificate'*|*'alert certificate unknown'*|*'alert certificate required'*) echo "the TLS error names a certificate-related alert, the rejection shape" ;;
    *'alert handshake failure'*|*'alert unknown ca'*) echo "the TLS error is a generic handshake failure or an unknown-CA alert, which does not show that the missing certificate caused it; inconclusive: read the server's log line for the rejected handshake"; [ "$1" = 1 ] || set -- 3 "$2" "$3" "$4" ;;
    *) echo "the TLS error names no certificate-related alert (a local file, connection, protocol-version or server-verification error, for example); inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" "$3" "$4" ;;
  esac
  printf '\nUntrusted client certificate\n'
  set -- "$1" "$2" "$3" "$4" "$(if timeout 10s openssl s_client -connect "$2:$3" -tls1_2 -brief \
      -verify_hostname "$4" -verify_return_error -CAfile /etc/redis/tls/ha-ca.crt \
      -cert /etc/redis/tls/untrusted-client.crt -key /etc/redis/tls/untrusted-client.key </dev/null 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "$4" "${5##*$'\n'}" "${5%$'\n'*}"   # status, host, port, peer name, the probe's exit status, then its output
  printf '%s' "$6"
  if [ "$5" = 0 ]; then
    echo "probe exit=0; inspect the handshake result"
  else
    printf 'probe exit=%s; inspect the TLS error\n' "$5"
  fi
  case "$5:$6" in
    0:*) echo "FINDING: the handshake completed with the untrusted client certificate, so the bus accepts it"; set -- 1 "$2" "$3" "$4" ;;
    124:*) echo "a timeout does not demonstrate that the bus rejects the untrusted certificate; inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" "$3" "$4" ;;
    *'alert bad certificate'*|*'alert certificate unknown'*|*'alert unknown ca'*|*'alert certificate required'*) echo "the TLS error names a certificate-related alert, the rejection shape" ;;
    *'alert handshake failure'*) echo "the TLS error is a generic handshake failure, which does not show that the untrusted certificate caused it; inconclusive: read the server's log line for the rejected handshake"; [ "$1" = 1 ] || set -- 3 "$2" "$3" "$4" ;;
    *) echo "the TLS error names no certificate-related alert (a local file, connection, protocol-version or server-verification error, for example); inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" "$3" "$4" ;;
  esac
  printf '\nTrusted client certificate, positive control\n'
  if timeout 10s openssl s_client -connect "$2:$3" -tls1_2 -brief \
      -verify_hostname "$4" -verify_return_error -CAfile /etc/redis/tls/ha-ca.crt \
      -cert /etc/redis/tls/ha-client.crt -key /etc/redis/tls/ha-client.key </dev/null; then
    echo "probe exit=0; inspect the handshake result"
  else
    printf 'probe exit=%s; inspect the TLS error\n' "$?"
    echo "the trusted positive control did not complete a verified handshake; inconclusive"; [ "$1" = 1 ] || set -- 3
  fi
  echo "block exit $1; the TLS errors of the first two probes are left for you to judge: each must be a certificate-related rejection, not a local file error, protocol-version mismatch or failed server-certificate verification"
  exit "$1"
)
```

The cluster-bus certificate check above is REASONED, because no live TLS cluster-bus listener or certificate fixtures were available to run it. Require certificate-related TLS rejection for the first two probes and a completed, verified TLS handshake for the trusted positive control. Repeat with data-port `tls-auth-clients no` and `yes`; the bus must require a trusted certificate in both cases. A timeout, local file error, protocol-version mismatch, or failed server-certificate verification does not demonstrate rejection of the client certificate. The block counts a bad-certificate, certificate-unknown or certificate-required alert as the rejection, and an unknown-CA alert too for the untrusted certificate; a generic handshake failure, or an unknown-CA alert without a client certificate, is inconclusive. In this guide's assessment, with TLS 1.2 a server may reject a missing or untrusted certificate with only that generic alert, so a fixed bus can read 3; read the server's log line for the rejected handshake.

An exposed plaintext bus has no TLS certificate gate and will fail the TLS positive control; that failure must not be mistaken for a protected bus. Use the section 12 TCP reachability comparison separately. OpenSSL does not speak the binary cluster protocol, so a successful handshake establishes neither cluster membership nor working node-to-node traffic. Listener checks need one cluster-enabled process; working cluster transport needs multiple nodes. See the [pinned cluster certificate requirement](https://raw.githubusercontent.com/redis/redis/8.10.1/src/cluster_legacy.c) and [TLS cluster documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/).

**Sentinel TLS and outgoing connections, section 14.** No live Sentinel or data-node topology was available. Repeat the plaintext/TLS discriminator on 26379, not only on the Redis data port. The following block assumes the Redis 6.2+ `discovery` account, the monitored group `mymaster`, and certificate-to-user automatic authentication disabled. For the password-only Sentinel arrangement, use `--user default` instead. Replace the host inside the single quotes and use the installed certificate file paths, then paste the whole block:

```bash
(
  set +e                                # errexit off here, so a request that ends nonzero is classified below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_SENTINEL_HOST'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 host; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute your Sentinel host; not probing"; exit 2 ;;
  esac
  unset REDISCLI_AUTH || exit 2
  set -- 0 "$1" "$(if timeout 10s redis-cli -h "$1" -p 26379 SENTINEL GET-MASTER-ADDR-BY-NAME mymaster 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "${3##*$'\n'}" "${3%$'\n'*}"   # the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0), the host, redis-cli's exit status, then its output
  printf '%s' "$4"
  case "$3:$4" in
    0:*|*NOAUTH*) echo "FINDING: the plaintext request got a RESP reply, so plaintext Redis protocol is available at this endpoint"; set -- 1 "$2" ;;
    *'Server closed the connection'*|*'Connection reset by peer'*) echo "no RESP reply recognized to the plaintext request (exit $3); a timeout, resolution error or refusal alone proves nothing, so the TLS requests below decide"; set -- 0 "$2" ;;
    *) echo "the plaintext request got neither a RESP reply nor a closed or reset connection (exit $3), as a timeout, resolution failure, refusal or local error does; inconclusive"; set -- 3 "$2" ;;
  esac
  set -- "$1" "$2" "$(if timeout 10s redis-cli --tls --cacert /etc/redis/tls/ha-ca.crt \
        --cert /etc/redis/tls/client.crt --key /etc/redis/tls/client.key \
        -h "$2" -p 26379 SENTINEL GET-MASTER-ADDR-BY-NAME mymaster 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "${3##*$'\n'}" "${3%$'\n'*}"   # status, host, redis-cli's exit status, then its output
  printf '%s' "$4"
  case "$3:$4" in
    *NOAUTH*) echo "the TLS request without Redis credentials reached NOAUTH, as the secured instance must" ;;
    0:*) echo "FINDING: the TLS request without Redis credentials was answered, as an exposed instance returns the monitored endpoint"; set -- 1 "$2" ;;
    *) echo "the TLS request without Redis credentials reached neither NOAUTH nor a reply (exit $3); inconclusive"; [ "$1" = 1 ] || set -- 3 "$2" ;;
  esac
  if REDISCLI_HISTFILE=/dev/null timeout --foreground 10s redis-cli --tls \
      --cacert /etc/redis/tls/ha-ca.crt \
      --cert /etc/redis/tls/client.crt --key /etc/redis/tls/client.key \
      -h "$2" -p 26379 --user discovery --askpass \
      SENTINEL GET-MASTER-ADDR-BY-NAME mymaster; then   # --foreground: this guide's assessment is that it lets the hidden password prompt read from your terminal
    echo "unclassified observation: the authenticated request ended with exit 0; read its reply above, which must be the monitored endpoint"
  else
    echo "the authenticated request, or its hidden password prompt, failed with exit $?; inconclusive"
    [ "$1" = 1 ] || set -- 3 "$2"
  fi
  echo "block exit $1; the authenticated reply above is left for you to judge: it must be the monitored endpoint"
  exit "$1"
)
```

Any RESP reply to the first request proves plaintext Redis protocol is available at that endpoint. With the TLS-only configuration, expect no plaintext RESP reply; the trusted-certificate TLS request without Redis credentials must reach `NOAUTH`, and the authenticated request must return the monitored endpoint. A timeout, resolution error, or connection refusal alone proves nothing. Repeat the TLS requests without a client certificate and with an untrusted certificate; both must fail under `tls-auth-clients yes`. Restore the trusted certificate and valid credentials as the positive control. See [Sentinel TLS](https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/#sentinel), [Sentinel authentication](https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#configuring-sentinel-instances-with-authentication), and [Redis CLI options](https://redis.io/docs/latest/develop/tools/cli/).

One Sentinel can demonstrate its incoming listener. Outgoing TLS, peer discovery, and failover need a live Sentinel/data-node topology and independent connection evidence; success on 26379 does not prove those outgoing connections use TLS. See the [pinned outgoing connection and advertisement implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/sentinel.c).

REASONED: preceding block; the Sentinel shell block above, whose Redis behaviour was not demonstrated. The Sentinel shell block above passed local Bash syntax and ShellCheck checks. With `set -u`, it rejected the unchanged placeholder, an embedded placeholder, an empty host, a marker-only assignment, an omitted assignment with no inherited arguments, and an extra host argument before any connection command ran. These local checks did not demonstrate Redis behaviour. Those checks covered an earlier form of the block, whose refusals exited with status 1 and whose requests set no status. The current form, whose refusals exit with status 2 and whose requests feed one exit status, is covered by the gate suite's `bash -n` and ShellCheck 0.11.0 passes and by the 31 October 2026 stub runs recorded at the start of this section. Its authenticated request now runs under `timeout --foreground`; that this lets its hidden password prompt read from your terminal is this guide's assessment, with no cited source, and was not observed against a live Sentinel.

**REASONED: enforced HA peer identity, Redis 8.10+, section 15.** No Redis 8.10 runtime, certificate fixtures, or HA endpoints were available. Prepare two otherwise valid client certificates signed by the same trusted CA: one matching the configured HA identity and one that does not match it through either SAN or CN fallback. Keep certificate purpose, validity, CA trust, and Redis credentials constant.

For incoming identity enforcement, target the TLS cluster-bus port. An ordinary client handshake to the data port does not exercise this incoming peer-name restriction. At the test node's authenticated administrative data-port prompt, first establish the isolated comparison without the restriction:

```
CONFIG SET tls-expected-peer-name ""
```

Run the following block, then enable the intended identity at that same administrative prompt and run the block again:

```
CONFIG SET tls-expected-peer-name redis-ha.example.com
```

The peer-name comparison in the following block is REASONED from the cited pinned identity configuration and enforcement paths. Replace the example identity consistently with the identity issued to intended HA nodes. Require `OK` from each configuration change. The shell block uses the same TLS 1.2, GNU `timeout`, and protected PEM-file prerequisites as the preceding bus-certificate check. Substitute the DNS hostname or IPv4 address, actual bus port and expected peer name inside the quotes, and the phase: `unrestricted` for the first run and `restricted` for the run after enabling the intended identity. The block counts a bad-certificate, certificate-unknown or certificate-required alert to the wrong-name probe as the restricted phase's rejection. An unknown-CA alert there means the wrong-name fixture is not from the trusted CA, and a generic handshake failure does not show that the peer name caused it, so both are inconclusive. In this guide's assessment a node may report the mismatch with only that generic alert, so a working restriction can read 3; read the server's log line for the rejected handshake.

```bash
(
  set +e                                # errexit off here, so a probe that ends nonzero is classified below instead of ending the block
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_CLUSTER_HOST' 'REPLACE_WITH_BUS_PORT' 'REPLACE_WITH_EXPECTED_PEER_NAME' 'REPLACE_WITH_unrestricted_OR_restricted'   # the 4th value is the phase: unrestricted before tls-expected-peer-name is set, restricted after
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block; not probing"; exit 2; }
  shift
  [ "$#" -eq 4 ] || { echo "the set -- line needs exactly 1 host, 1 port, 1 expected peer name, and 1 phase; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the host; not probing"; exit 2 ;;
  esac
  case "$2" in
    *[!0123456789]*|"") echo "substitute a numeric port; not probing"; exit 2 ;;
  esac
  if [ "$2" -ge 1 ] && [ "$2" -le 65535 ]; then :; else echo "port must be 1-65535; not probing"; exit 2; fi
  case "$3" in
    *REPLACE_WITH_*|"") echo "substitute the expected peer name; not probing"; exit 2 ;;
  esac
  case "$4" in
    unrestricted|restricted) ;;
    *) echo "substitute unrestricted or restricted, this run's phase; not probing"; exit 2 ;;
  esac
  if [ -r /etc/redis/tls/ha-ca.crt ] && [ -r /etc/redis/tls/wrong-name-client.crt ] && [ -r /etc/redis/tls/wrong-name-client.key ] &&
    [ -r /etc/redis/tls/matching-name-client.crt ] && [ -r /etc/redis/tls/matching-name-client.key ]; then :; else
    echo "the CA, wrong-name and matching-name certificate and key files named below must be readable here; not probing"; exit 2
  fi
  set -- 0 "$@"                         # the 1st value is the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 0
  printf '\nSame CA, wrong peer name\n'
  set -- "$1" "$2" "$3" "$4" "$5" "$(if timeout 10s openssl s_client -connect "$2:$3" -tls1_2 -brief \
      -verify_hostname "$4" -verify_return_error -CAfile /etc/redis/tls/ha-ca.crt \
      -cert /etc/redis/tls/wrong-name-client.crt -key /etc/redis/tls/wrong-name-client.key </dev/null 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
  set -- "$1" "$2" "$3" "$4" "$5" "${6##*$'\n'}" "${6%$'\n'*}"   # status, host, port, peer name, phase, the probe's exit status, then its output
  printf '%s' "$7"
  if [ "$6" = 0 ]; then
    echo "probe exit=0; inspect the handshake result"
  else
    printf 'probe exit=%s; inspect the TLS error\n' "$6"
  fi
  # a node may report the name mismatch with only a generic handshake-failure alert, which reads as inconclusive here even when the restriction works
  case "$5:$6:$7" in
    restricted:0:*) echo "FINDING: the wrong-name certificate was accepted with the setting enabled, which fails this enforcement check"; set -- 1 "$2" "$3" "$4" "$5" ;;
    unrestricted:0:*) ;;
    unrestricted:*) echo "without the name restriction both handshakes must complete; inconclusive"; set -- 3 "$2" "$3" "$4" "$5" ;;
    restricted:124:*) echo "a timeout does not demonstrate rejection of the wrong-name certificate; inconclusive"; set -- 3 "$2" "$3" "$4" "$5" ;;
    *'alert unknown ca'*) echo "the wrong-name probe got an unknown-CA alert, so the wrong-name fixture is not from the trusted CA; inconclusive"; set -- 3 "$2" "$3" "$4" "$5" ;;
    *'alert bad certificate'*|*'alert certificate unknown'*|*'alert certificate required'*) echo "the TLS error names a certificate-related alert, the rejection shape" ;;
    *'alert handshake failure'*) echo "the TLS error is a generic handshake failure, which does not show that the peer name caused it; inconclusive: read the server's log line for the rejected handshake"; set -- 3 "$2" "$3" "$4" "$5" ;;
    *) echo "the TLS error names no certificate-related alert (a local file, connection, protocol-version or server-verification error, for example); inconclusive"; set -- 3 "$2" "$3" "$4" "$5" ;;
  esac
  printf '\nSame CA, matching peer name, positive control\n'
  if timeout 10s openssl s_client -connect "$2:$3" -tls1_2 -brief \
      -verify_hostname "$4" -verify_return_error -CAfile /etc/redis/tls/ha-ca.crt \
      -cert /etc/redis/tls/matching-name-client.crt -key /etc/redis/tls/matching-name-client.key </dev/null; then
    echo "probe exit=0; inspect the handshake result"
  else
    printf 'probe exit=%s; inspect the TLS error\n' "$?"
    echo "the matching-name positive control did not complete; inconclusive"; [ "$1" = 1 ] || set -- 3
  fi
  echo "block exit $1; the wrong-name probe's TLS error, which in the restricted phase you correlate with the accepting node's certificate-verification error, and the node's startup warnings are left for you to judge"
  exit "$1"
)
```

Without the name restriction, require both handshakes to complete. With enforcement enabled, require the wrong-name handshake to be rejected and the matching-name handshake to complete. Correlate rejection with the accepting node's certificate-verification error. An unrelated failure or a failed positive control is inconclusive. Inspect startup warnings indicating that this build does not enforce peer-name verification; accepting the wrong-name certificate with the setting enabled fails this enforcement check. See the [pinned identity configuration](https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf) and [enforcement and warning paths](https://raw.githubusercontent.com/redis/redis/8.10.1/src/tls.c).

Test outbound replication separately in a disposable Redis 8.10+ pair. Prepare matching-name and wrong-name server certificates from the same CA, with valid server-authentication purposes. At the primary's authenticated administrative prompt, install the wrong-name fixture:

```
CONFIG SET tls-cert-file /etc/redis/tls/wrong-name-server.crt tls-key-file /etc/redis/tls/wrong-name-server.key
```

Require `OK`. At the replica's authenticated administrative prompt, remove the name restriction and force a fresh connection:

```
CONFIG SET tls-expected-peer-name ""
CLIENT KILL TYPE master
INFO replication
```

Repeat `INFO replication` until the connection attempt completes; require `master_link_status:up` as the unrestricted control. Then enable the intended identity on the replica and force another connection:

```
CONFIG SET tls-expected-peer-name redis-ha.example.com
CLIENT KILL TYPE master
INFO replication
```

Require the new connection to fail with a certificate-name verification error in the replica's log. A down link without that evidence is inconclusive. At the primary's administrative prompt, restore the matching fixture:

```
CONFIG SET tls-cert-file /etc/redis/tls/matching-name-server.crt tls-key-file /etc/redis/tls/matching-name-server.key
```

Require `OK`, then repeat `INFO replication` on the replica and the fresh canary check above; both must recover. These commands intentionally reconnect replication and belong only in the isolated comparison. Keep the intended name restriction enabled afterward. File paths are arguments, but private-key contents and passwords are not. See [CONFIG SET](https://redis.io/docs/latest/commands/config-set/), the [pinned modifiable TLS settings](https://raw.githubusercontent.com/redis/redis/8.10.1/src/config.c), [CLIENT KILL](https://redis.io/docs/latest/commands/client-kill/), and [INFO replication fields](https://redis.io/docs/latest/commands/info/).

Small isolated endpoints can exercise these handshakes without a complete functioning cluster. Proving the full HA trust boundary requires testing every connection class, including outgoing cluster-bus and `MIGRATE` connections and Sentinel separately. Do not expect the directive to reject the wrong-name certificate on Sentinel's reviewed outgoing path; verify Sentinel's dedicated trust boundary independently. That exception is derived from the [pinned Sentinel source](https://raw.githubusercontent.com/redis/redis/8.10.1/src/sentinel.c), not a runtime demonstration.

| Check scope | Procedure and prerequisites | Status |
| --- | --- | --- |
| Service comparisons | In an isolated environment with Redis, TLS certificates, and socket access, record exact versions and demonstrate exposed/fixed listeners, plaintext rejection, authentication, ACL readback, actual CONFIG denial and ACL logging, directional key/channel checks, both persistence methods across restart, and old-user session revocation. Also demonstrate the seven HA checks: (1) replication credential rejection, successful synchronization and canary transfer, replica listener authentication, Redis 7+ replication ACL checks, and authentication through promotion. HA check (2) is to demonstrate Sentinel listener restrictions, incoming authentication, discovery-user denials, announcements, and authenticated peer communication. HA check (3) is to demonstrate Sentinel monitored-server command/channel restrictions, ACL logging, credential failure/recovery, and monitoring through failover. HA check (4) is to demonstrate cluster-bus listener and announcement correctness with denied unauthorized and working authorized paths. HA check (5) is to demonstrate replication encryption using correlated TLS listener, established-connection, and fresh canary evidence, incoming replica certificate requirements, and mandatory TLS cluster-bus certificates. HA check (6) is to demonstrate Sentinel plaintext rejection, incoming certificate/password checks, outgoing TLS, peer discovery, and failover. HA check (7) is to demonstrate Redis 8.10+ same-CA wrong-name rejection with matching-certificate positive controls, outbound replication and incoming bus tests, build-warning inspection, and every remaining connection class including Sentinel's separate trust boundary. Record exact Redis versions and TLS build capabilities. | REASONED from the cited Redis documentation and pinned sources; not demonstrated. |
| Native configuration parsing | Parse the applicable configuration examples with the real Redis server, including the added server, ACL, and Sentinel examples on their stated versions; record exact Redis versions and TLS build capabilities. | Unconfirmed because Redis binaries are absent; retained local work. |

## 9. Authenticate replication through role changes

Within this guide's Redis 6.0+ scope, an unsecured default user permits replication commands as well as ordinary commands once the network permits access. A dedicated replication user requires data-server ACLs, available since Redis 6.0. The required replication commands are `PING`, `REPLCONF`, and `PSYNC`. See the [ACL rules for replicas](https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/#acl-rules-for-sentinel-and-replicas).

For the password-only arrangement, configure both directions on every member eligible to become primary:

```
requirepass REPLACE_WITH_DATA_PASSWORD
masterauth REPLACE_WITH_DATA_PASSWORD
```

`requirepass` protects incoming access. `masterauth` supplies an outbound credential; it does not protect the replica's own listener. Configure both on potential primaries so authentication survives role changes. See the [pinned replication configuration](https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf) and [Sentinel authentication documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#redis-access-control-list-authentication).

Prefer a dedicated replication account, provisioned on every potential primary. Put this rule in the ACL persistence surface chosen in section 3:

```
user replication reset on >REPLACE_WITH_REPLICATION_PASSWORD +ping +replconf +psync
```

Put the outbound credentials in each data member's server configuration:

```
masteruser replication
masterauth REPLACE_WITH_REPLICATION_PASSWORD
```

Retain the secured default user and separate administrator from sections 2 and 3. The replication account receives the full replication stream: omitting key-pattern grants does not restrict it to an application prefix. The pinned [configuration](https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf) documents both credential directives; the [replication implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/replication.c) sends username/password authentication when configured and aborts the handshake on authentication failure. See also [persistent replica authentication](https://redis.io/docs/latest/operate/oss_and_stack/management/replication/#setting-a-replica-to-authenticate-to-a-master).

## 10. Secure Sentinel's separate listener and peer authentication

Sentinel has a separate listener, normally TCP 26379. Its shipped configuration disables protected mode and supplies no active authentication rule. Protecting the Redis data port does not protect Sentinel. Password-only Sentinel authentication is available throughout this guide's Redis 6.0+ scope; Sentinel ACLs require Redis 6.2+. See the [pinned Sentinel configuration](https://raw.githubusercontent.com/redis/redis/8.10.1/sentinel.conf) and [Sentinel authentication documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#configuring-sentinel-instances-with-authentication).

For a representative private Sentinel address, the password-only arrangement is:

```
bind 10.0.0.11
port 26379
requirepass REPLACE_WITH_SENTINEL_PASSWORD
sentinel announce-ip 10.0.0.11
sentinel announce-port 26379
```

Restrict network access to the required Sentinel peers, discovery clients, and administrators. Use the same Sentinel password across peers in this arrangement, with a credential distinct from the data-server password. The announcement directives publish discovery information; they neither bind sockets nor enforce access restrictions. Section 14 replaces the plaintext listener with TLS. See the [pinned listener, announcement, and password settings](https://raw.githubusercontent.com/redis/redis/8.10.1/sentinel.conf).

Alternatively, on Redis 6.2+, use ACL authentication. Retain the private bind and announcements, and use these account rules instead of the password-only `requirepass` arrangement:

```
user sentinel-peer reset on >REPLACE_WITH_SENTINEL_PEER_PASSWORD &* +@all
user discovery reset on >REPLACE_WITH_DISCOVERY_PASSWORD +ping +sentinel|get-master-addr-by-name
user default off resetpass
```

Configure Sentinel's outgoing peer credentials separately:

```
sentinel sentinel-user sentinel-peer
sentinel sentinel-pass REPLACE_WITH_SENTINEL_PEER_PASSWORD
```

Provision the peer account consistently across the Sentinel group. Establish and test administrative access before disabling `default`. The peer account above has administrative authority; the discovery account permits only `PING` and `SENTINEL GET-MASTER-ADDR-BY-NAME`. Add other commands only when the actual client library needs them. Use the chosen ACL persistence surface for `user` rules and Sentinel configuration for peer credentials. Choose ACL authentication or the password-only arrangement rather than combining their examples. See the [pinned ACL and peer settings](https://raw.githubusercontent.com/redis/redis/8.10.1/sentinel.conf).

## 11. Give Sentinel dedicated monitored-server credentials

Sentinel's own password does not authenticate it to Redis data servers. Monitored-instance credentials are initially unset. Leaving data servers unauthenticated to permit monitoring exposes them; giving Sentinel an application or unrestricted administrator credential grants unnecessary authority. The monitored-server ACL mechanism requires Redis 6.0+, while the channel-restricted policy below requires Redis 6.2+. See the [pinned credential settings](https://raw.githubusercontent.com/redis/redis/8.10.1/sentinel.conf) and [Sentinel-specific ACL documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#redis-access-control-list-authentication).

On every Sentinel monitoring the group named `mymaster`:

```
sentinel auth-user mymaster sentinel-monitor
sentinel auth-pass mymaster REPLACE_WITH_MONITOR_PASSWORD
```

On every data member of that group, provision the same dedicated account in the ACL persistence surface chosen in section 3:

```
user sentinel-monitor reset on >REPLACE_WITH_MONITOR_PASSWORD resetchannels &__sentinel__:hello +ping +info +role +multi +exec +slaveof +subscribe +publish +config|rewrite +client|setname +client|kill +script|kill
```

This policy is adapted from the current Sentinel-specific vendor example and reviewed for Redis 8.10.1. It permits the reserved discovery channel specifically, rather than every Pub/Sub channel. It remains a powerful operational account. Redis 6.0 cannot enforce this channel restriction; do not describe an account there as having equivalent channel isolation. See the [Sentinel ACL requirements](https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#redis-access-control-list-authentication).

For password-only data servers, omit `auth-user` and set `auth-pass` to their `requirepass` value. Sentinel uses the monitored primary's credentials for its replicas too, so provision them on every member eligible for either role. Its monitored-server credentials are distinct from its Sentinel-peer credentials. See `sentinelSendAuthIfNeeded` in the [pinned implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/sentinel.c).

## 12. Restrict the cluster bus and announce private endpoints

Cluster mode is opt-in. When enabled, it adds a binary node-to-node listener for discovery, failure detection, and failover coordination. Restrict this listener separately throughout this guide's Redis 6.0+ scope. Its default port is the data port plus 10000, normally 16379 beside 6379. Data-port password authentication does not provide a RESP `AUTH` gate on the binary bus. See the [cluster networking documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/scaling/#redis-cluster-tcp-ports).

For an existing TLS cluster using section 13, this explicit listener and announcement example targets Redis 8.10.1; it is not a claim that every directive is available on every Redis 6.x release:

```
bind 10.0.0.11
cluster-port 16379
cluster-announce-ip 10.0.0.11
cluster-announce-port 0
cluster-announce-tls-port 6379
cluster-announce-bus-port 16379
```

Permit the bus only between cluster nodes. Permit the data port to intended clients and nodes that need it. `cluster-port` selects the actual bus listener; `cluster-announce-*` publishes endpoint information and is not a firewall. Account for remapping rather than assuming the externally reachable bus port retains the 10000 offset. See the [pinned cluster and NAT configuration](https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf).

In TLS cluster mode, the default offset is based on `tls-port`; the bus uses the configured bind addresses. The listener and announced endpoints must both match the intended deployment. See `defaultClientPort`, `deriveAnnouncedPorts`, and `clusterInitLast` in the [pinned cluster implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/cluster_legacy.c).

## 13. Enable TLS for replication and cluster traffic

Redis 6.0+ with TLS support needs separate switches for outgoing replication and cluster traffic. Enabling the client TLS listener does not enable either one; both switches default to disabled. See the [TLS documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/) and [pinned defaults](https://raw.githubusercontent.com/redis/redis/8.10.1/src/config.c).

On all applicable data nodes, retain section 6's certificate, key, and CA configuration and use:

```
port 0
tls-port 6379
tls-replication yes
tls-auth-clients yes
```

On cluster nodes, also configure:

```
tls-cluster yes
```

Where replication is configured explicitly, point `replicaof` at the primary's TLS endpoint. `tls-auth-clients yes` is already the Redis default; restoring it from section 6's deliberate `no` requires incoming replicas, as well as ordinary clients, to present trusted certificates. Retain replication credentials from section 9, subject to the certificate-to-user authentication qualification in section 2. See the [pinned TLS and replication settings](https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf).

Redis normally reuses its certificate for outgoing connections. On Redis 6.2+, if certificates have separate server and client purposes, configure `tls-client-cert-file` and `tls-client-key-file` for the outgoing certificate and key. Readers on Redis releases before 6.2 must instead use one certificate suitable for both server and client authentication, configured through `tls-cert-file` and `tls-key-file`. Omit both `tls-client-*` directives on those releases: an unknown configuration directive prevents startup. Compare the pinned [6.0.20 certificate configuration](https://raw.githubusercontent.com/redis/redis/6.0.20/redis.conf) with the [6.2.0 certificate configuration](https://raw.githubusercontent.com/redis/redis/6.2.0/redis.conf).

The TLS cluster bus always requests and requires a peer certificate. Its accept path explicitly uses `TLS_CLIENT_AUTH_YES`; setting data-port `tls-auth-clients no` does not disable cluster-bus certificate authentication. See `clusterAcceptHandler` in the [pinned implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/cluster_legacy.c).

## 14. Configure TLS on Sentinel and its outgoing connections

Sentinel is a separate process; data-node TLS configuration does not configure it. On Redis 6.0+ with TLS support, a nonzero `tls-port` creates Sentinel's incoming TLS listener independently of `tls-replication`. The `tls-replication yes` setting selects TLS for outgoing connections to monitored servers and Sentinel peers. It also selects the configured TLS port for Sentinel's default port advertisement; an explicit `sentinel announce-port` overrides that choice. Configure both `tls-port` and `tls-replication yes` for end-to-end TLS, and set `port 0` to disable the plaintext listener. See `initListeners` in the [pinned server implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/server.c), and `sentinelReconnectInstance` and `sentinelSendHello` in the [pinned Sentinel implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/sentinel.c).

In each Sentinel's configuration:

```
port 0
tls-port 26379
tls-replication yes
tls-auth-clients yes
tls-cert-file /etc/redis/tls/sentinel.crt
tls-key-file /etc/redis/tls/sentinel.key
tls-ca-cert-file /etc/redis/tls/ha-ca.crt
sentinel announce-port 26379
```

Retain section 10's private bind and chosen authentication arrangement, and section 11's monitored-server credentials. Set `sentinel monitor` to the primary's TLS data port. Provision certificates and trust for Sentinel-to-data-server connections, Sentinel-to-Sentinel connections, and discovery clients. `tls-cluster` is not Sentinel's TLS switch. Certificate directives are documented in the [pinned Redis configuration](https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf); `sentinelReconnectInstance`, `instanceLinkNegotiateTLS`, and `sentinelSendHello` in the [pinned Sentinel implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/sentinel.c) establish the outgoing TLS selection and TLS-port advertisement.

## 15. Restrict trusted HA peer identities

Redis 8.10 introduced server-to-server certificate-name authentication. The setting is unset by default, leaving CA validation without this additional peer-name restriction. This control is newer than the guide's existing 8.2.1 configuration references and must not be added to the generic Redis 6.0+ baseline. See the [8.10 release notes](https://redis.io/docs/latest/operate/oss_and_stack/stack-with-enterprise/release-notes/redisce/redisos-8.10-release-notes/) and [pinned peer-name configuration](https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf).

On Redis 8.10+ builds that enforce the feature:

```
tls-expected-peer-name redis-ha.example.com
```

Replace the example identity with the intended HA trust-group name. Issue intended nodes certificates containing that shared identity in their SANs, including the outgoing client certificates. This adds identity checking to CA validation for outgoing replication, cluster-bus, and `MIGRATE` connections, and incoming cluster-bus connections. It identifies membership in the configured trust group, not a unique certificate-to-node-ID mapping. See the [pinned configuration](https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf) and [`tlsSetVerifyName` and its callers](https://raw.githubusercontent.com/redis/redis/8.10.1/src/tls.c).

Two limits apply:

- Builds with `TLS_NO_PEER_NAME_VERIFICATION` warn and continue without enforcing the name; CA validation still applies. Configuration readback alone does not prove enforcement. See the [pinned TLS implementation](https://raw.githubusercontent.com/redis/redis/8.10.1/src/tls.c).
- Sentinel's outgoing `instanceLinkNegotiateTLS` path creates an SSL object and invokes hiredis directly without applying this name check. This is a source-derived conclusion from Redis 8.10.1, not a demonstrated runtime result. Do not rely on this directive to protect Sentinel's outgoing peer identity. See the [separate Sentinel TLS path](https://raw.githubusercontent.com/redis/redis/8.10.1/src/sentinel.c).

Use a dedicated HA trust boundary for Sentinel and releases without this identity control. Do not trust a general-purpose CA whose other certificate holders should not be able to impersonate HA peers. The [pinned configuration](https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf) explains why shared CA trust alone is insufficient.

## Common mistakes

- Commenting out `bind`, which listens everywhere, while `requirepass` is still empty.
- One `requirepass` value shared across environments and committed to the repository.
- TLS enabled but the plaintext `port` left open alongside it; set `port 0`.
- Adding a narrower ACL without resetting old grants or reviewing selectors.
- Saving `redis.conf` while runtime ACL changes belong in an external ACL file.
- Disabling a user and assuming its existing connections have been disconnected.
- Treating key patterns as restrictions on Pub/Sub channels or keyless commands.

## Valkey

Valkey, the community fork of Redis, uses the same `requirepass`, ACL, and TLS configuration concepts described above. Apply the version-appropriate controls and check the installed release's syntax and defaults. See the Valkey [security](https://valkey.io/topics/security/), [ACL](https://valkey.io/topics/acl/), and [TLS](https://valkey.io/topics/tls/) documentation.

The upstream Redis HA controls and source-derived limitations in sections 9-15 have not been established for Valkey. Verify those controls separately against the installed Valkey release before applying them.

## Sources (checked September 2026)

The tagged configuration files below pin syntax and historical behaviour; they are not recommendations to install those patch releases.

- Redis security model, authentication, and deprecated command renaming: https://redis.io/docs/latest/operate/oss_and_stack/management/security/
- Redis configuration format: https://redis.io/docs/latest/operate/oss_and_stack/management/config/
- Redis TLS build support, listeners, and client certificates: https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/
- Redis ACL rules, categories, selectors, key/channel permissions, and persistence: https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/
- Redis 8.2.1 pinned configuration, including ACL-file compatibility and debug/module defaults: https://raw.githubusercontent.com/redis/redis/8.2.1/redis.conf
- Redis 6.0.20 pinned bind and protected-mode configuration: https://raw.githubusercontent.com/redis/redis/6.0.20/redis.conf
- Redis 6.2.14 pinned optional-bind syntax and protected-mode configuration: https://raw.githubusercontent.com/redis/redis/6.2.14/redis.conf
- Redis 7.0.15 pinned protected-mode and hardened-command configuration: https://raw.githubusercontent.com/redis/redis/7.0.15/redis.conf
- Official Redis Docker images (redis/docker-library-redis): the build patch that sets the `protected-mode` default to 0, and `CMD ["redis-server"]`, present in every Dockerfile on the default branch at commit 584feaab6cd12a77866c121beff1bb16ff239486 (6.2 through 7.4; the patch is shown for 7.4 Debian and Alpine, 7.2 and 6.2) and at release tag v8.10.2. The pinned commit's 7.4 Debian Dockerfile sources: https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/7.4/debian/Dockerfile#L85-L90 and https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/7.4/debian/Dockerfile#L146-L150. The pinned commit's 7.4 Alpine and 7.2 Debian Dockerfile sources: https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/7.4/alpine/Dockerfile#L79-L84 and https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/7.2/debian/Dockerfile#L85-L90. The pinned commit's 6.2 Debian Dockerfile source: https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/6.2/debian/Dockerfile#L85-L90. The v8.10.2 tag's Debian Dockerfile sources: https://github.com/redis/docker-library-redis/blob/v8.10.2/debian/Dockerfile#L70-L75 and https://github.com/redis/docker-library-redis/blob/v8.10.2/debian/Dockerfile#L127-L130. The v8.10.2 tag's Alpine Dockerfile sources: https://github.com/redis/docker-library-redis/blob/v8.10.2/alpine/Dockerfile#L82-L87 and https://github.com/redis/docker-library-redis/blob/v8.10.2/alpine/Dockerfile#L142-L145. The entrypoints (every one at the pinned commit, and 8.10.2 Debian and Alpine) do not supply a configuration file or set bind, protected-mode or password. The pinned commit's entrypoint sources: https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/7.4/debian/docker-entrypoint.sh and https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/7.4/alpine/docker-entrypoint.sh. The v8.10.2 tag's entrypoint sources: https://github.com/redis/docker-library-redis/blob/v8.10.2/debian/docker-entrypoint.sh and https://github.com/redis/docker-library-redis/blob/v8.10.2/alpine/docker-entrypoint.sh
- Redis compiled defaults, `bind` `* -::*`, `protected-mode` 1, and the `default` user `on nopass +@all` (pinned tags 7.4.8 and 8.10.2). The Redis 7.4.8 tag's sources: https://github.com/redis/redis/blob/7.4.8/src/server.h#L119-L120, https://github.com/redis/redis/blob/7.4.8/src/config.c#L3055 and https://github.com/redis/redis/blob/7.4.8/src/acl.c#L1407-L1415. The Redis 8.10.2 tag's sources: https://github.com/redis/redis/blob/8.10.2/src/server.h#L138-L139, https://github.com/redis/redis/blob/8.10.2/src/config.c#L3403 and https://github.com/redis/redis/blob/8.10.2/src/acl.c#L1430-L1438
- Redis CLI connection flags, masked password input, TLS options, and history control: https://redis.io/docs/latest/develop/tools/cli/
- AUTH named-user and default-user authentication: https://redis.io/docs/latest/commands/auth/
- ACL SETUSER replacement rules and version history: https://redis.io/docs/latest/commands/acl-setuser/
- CONFIG REWRITE persistence and prerequisites: https://redis.io/docs/latest/commands/config-rewrite/
- ACL SAVE persistence to the configured ACL file: https://redis.io/docs/latest/commands/acl-save/
- ACL LOAD replacement and failure behaviour: https://redis.io/docs/latest/commands/acl-load/
- CLIENT KILL user filtering and SKIPME behaviour: https://redis.io/docs/latest/commands/client-kill/
- ACL GETUSER effective-policy readback: https://redis.io/docs/latest/commands/acl-getuser/
- ACL LOG failure reasons and retrieval: https://redis.io/docs/latest/commands/acl-log/
- ACL DRYRUN checks without command execution: https://redis.io/docs/latest/commands/acl-dryrun/
- CONFIG GET read-only configuration inspection: https://redis.io/docs/latest/commands/config-get/
- GET and SET syntax and key access: https://redis.io/docs/latest/commands/get/ and https://redis.io/docs/latest/commands/set/
- PING command categories: https://redis.io/docs/latest/commands/ping/
- Global database write commands: https://redis.io/docs/latest/commands/flushall/ and https://redis.io/docs/latest/commands/flushdb/ and https://redis.io/docs/latest/commands/swapdb/
- Keyspace enumeration commands: https://redis.io/docs/latest/commands/keys/ and https://redis.io/docs/latest/commands/scan/ and https://redis.io/docs/latest/commands/randomkey/
- Global function-library write commands: https://redis.io/docs/latest/commands/function-load/ and https://redis.io/docs/latest/commands/function-delete/ and https://redis.io/docs/latest/commands/function-flush/ and https://redis.io/docs/latest/commands/function-restore/
- Script and function execution categories: https://redis.io/docs/latest/commands/eval/ and https://redis.io/docs/latest/commands/evalsha/ and https://redis.io/docs/latest/commands/fcall/
- Read-only scripting variants: https://redis.io/docs/latest/commands/eval_ro/ and https://redis.io/docs/latest/commands/evalsha_ro/ and https://redis.io/docs/latest/commands/fcall_ro/
- Pub/Sub publishing and subscriptions: https://redis.io/docs/latest/commands/publish/ and https://redis.io/docs/latest/commands/subscribe/ and https://redis.io/docs/latest/commands/psubscribe/
- Valkey security, ACLs, and TLS: https://valkey.io/topics/security/ and https://valkey.io/topics/acl/ and https://valkey.io/topics/tls/
- Redis 8.10.1 pinned server configuration: https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf
- Redis 6.2.0 separate outgoing TLS certificate and key configuration: https://raw.githubusercontent.com/redis/redis/6.2.0/redis.conf
- Redis 8.10.1 independent TCP and TLS listener initialization: https://raw.githubusercontent.com/redis/redis/8.10.1/src/server.c
- CONFIG SET runtime configuration changes and multiple-parameter syntax: https://redis.io/docs/latest/commands/config-set/
- Redis 8.10.1 pinned Sentinel configuration: https://raw.githubusercontent.com/redis/redis/8.10.1/sentinel.conf
- Redis 8.10.1 registered TLS and certificate-authentication defaults: https://raw.githubusercontent.com/redis/redis/8.10.1/src/config.c
- Redis 8.6.0 tls-auth-clients-user introduction and default: https://raw.githubusercontent.com/redis/redis/8.6.0/redis.conf
- Redis 8.6 release notes and tls-auth-clients-user introduction: https://redis.io/docs/latest/operate/oss_and_stack/stack-with-enterprise/release-notes/redisce/redisos-8.6-release-notes/
- Redis 8.10.1 replication authentication implementation: https://raw.githubusercontent.com/redis/redis/8.10.1/src/replication.c
- Redis 8.10.1 Sentinel authentication, outgoing TLS, and announcements: https://raw.githubusercontent.com/redis/redis/8.10.1/src/sentinel.c
- Redis 8.10.1 cluster listeners, announcements, and mandatory TLS peer certificates: https://raw.githubusercontent.com/redis/redis/8.10.1/src/cluster_legacy.c
- Redis 8.10.1 peer-name enforcement and build opt-out: https://raw.githubusercontent.com/redis/redis/8.10.1/src/tls.c
- Replica ACL command requirements: https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/#acl-rules-for-sentinel-and-replicas
- Persistent replica authentication: https://redis.io/docs/latest/operate/oss_and_stack/management/replication/#setting-a-replica-to-authenticate-to-a-master
- Sentinel incoming and peer authentication: https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#configuring-sentinel-instances-with-authentication
- Sentinel monitored-server ACL and channel requirements: https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#redis-access-control-list-authentication
- Cluster data and bus networking: https://redis.io/docs/latest/operate/oss_and_stack/management/scaling/#redis-cluster-tcp-ports
- Sentinel TLS configuration: https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/#sentinel
- Redis 8.10 release notes and peer-name feature boundary: https://redis.io/docs/latest/operate/oss_and_stack/stack-with-enterprise/release-notes/redisce/redisos-8.10-release-notes/
- Replication status fields: https://redis.io/docs/latest/commands/info/
- Cluster advertised addresses and bus ports: https://redis.io/docs/latest/commands/cluster-nodes/


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- r60: Redis configuration (6.0.20)
- r62: Redis configuration (6.2.14)
- r620: Redis configuration (6.2.0)
- r70: Redis configuration (7.0.15)
- r82: Redis configuration (8.2.1)
- r86: Redis configuration (8.6.0)
- ha: Redis HA source (8.10.1)
- image8: Redis image tag (v8.10.2)
- r74: Redis compiled defaults (7.4.8)
- r8102: Redis compiled defaults (8.10.2)
- docs: Redis documentation (unknown)
- image: Redis image source (584feaab6cd12a77866c121beff1bb16ff239486)
- release-notes: Redis release notes (unknown)
- valkey: Valkey documentation (unknown)

Claims (full source mapping in the JSON block below):

- baseline (REASONED; docs, r60): Redis 6.0+ supplies TLS and ACLs; TLS needs TLS-enabled server/client builds. Restrict bind and credentials before remote access.
- optional-bind (REASONED; r62, r60): Redis 6.2+ -::1 makes an absent interface optional, not an occupied address; Redis 6.0 uses plain loopback binding.
- protected-mode (REASONED; r60, r62, r70): 6.0/6.2 protected mode requires default nopass and no explicit bind; 7.0 drops the bind condition. Explicit wildcard bind can expose passwordless 6.x.
- image-protected (REASONED; image, image8): Pinned 6.2-7.4 images and the checked 8.x tag patch protected-mode to no and run redis-server without a config; publish privately with explicit credentials.
- compiled-bind (REASONED; r74, r8102): 7.4.8/8.10.2 compiled bind is * -::*; IPv6 wildcard applies where available.
- compiled-user (REASONED; r74, r8102, r82): Checked 7.4.8/8.10.2 default users are on nopass +@all; disabled DEBUG/MODULE commands remain disabled.
- password (REASONED; docs): requirepass supplies one shared AUTH password; prefer separate least-privilege ACL identities.
- keyless (REASONED; docs): ~app:* constrains key arguments, not keyless commands: write categories include global flush/swap and 7+ FUNCTION writes; reads include keyspace walking.
- allowlist (REASONED; docs): Removing flushall/flushdb/swapdb removes only those commands; replace broad grants with reset and explicit required commands such as GET/SET.
- default-user (REASONED; docs): Default starts on nopass ~* +@all, adding &amp;* from 6.2; secure or disable it only after named clients/admin work; existing sessions survive.
- mfa (REASONED; docs): Redis has no second-factor dialogue; mutual TLS adds machine possession alongside passwords, not human MFA.
- cert-user (REASONED; r86, release-notes): Redis 8.6+ tls-auth-clients-user defaults off; enabling it can authenticate without passwords. Keep off for these NOAUTH checks and omit the unknown directive on older releases.
- reset (REASONED; docs): ACL SETUSER changes users incrementally and applies rules left-to-right; reset removes old grants/passwords and, on 7+, selectors.
- channel-default (REASONED; r82, docs): resetchannels needs 6.2+; 6.0 lacks channel ACLs. Redis 6.2 default allchannels became resetchannels in 7.0.
- inline-persistence (REASONED; docs): CONFIG REWRITE persists inline users only with a writable startup configuration and OK; it also rewrites other runtime settings.
- acl-file (REASONED; r82, docs): External aclfile excludes inline users and requirepass; ACL SAVE persists, ACL LOAD replaces, invalid loads retain old policy, and CONFIG REWRITE does not save ACLs.
- revocation (REASONED; docs): Disabling a user blocks new auth but CLIENT KILL USER closes existing sessions; password replacement also needs forced reconnect and persistence.
- directional-keys (REASONED; docs): Redis 7+ %R~/%W~ separate read/write key access; commands still need grants and broader ~ patterns can defeat separation.
- channels (REASONED; docs): Channel patterns are independent of keys; reset then allow required channels/commands. PSUBSCRIBE patterns must literally match an allowed pattern.
- scripting (REASONED; docs): Subtract admin/dangerous/scripting after grants; SCRIPT/FUNCTION removal alone misses execution commands. Omit FUNCTION on 6.x and rebuild unknown selectors first.
- startup-commands (REASONED; r82): Redis 7+ enable-debug-command and enable-module-command default no in the pin; local/yes and startup-loaded modules still require ACL review.
- renaming (REASONED; docs): rename-command is deprecated; use ACL command restrictions.
- tls-listener (REASONED; docs, r82): port 0 removes plaintext while tls-port 6379 serves TLS with configured CA/certificate/key; set mutual TLS for certificate-capable clients.
- tls-cert-default (REASONED; ha): tls-auth-clients defaults yes; this guide's initial no removes client-certificate requirements, including incoming replicas, not the TLS cluster bus.
- cli (REASONED; docs): Use CA trust, --user and masked --askpass with history disabled; GET app:probe is allowed while PING is not granted to app.
- verify-listeners (REASONED; r82): Inventory all listeners; only intended loopback/private addresses pass, and socket errors establish nothing.
- verify-plaintext (REASONED; docs): Any plaintext RESP reply proves plaintext availability; TLS-only 6379 must close/reset plaintext while TLS reaches the same endpoint.
- verify-noauth (REASONED; docs): Secured default produces NOAUTH over TLS, exposed nopass produces PONG; certificate failures precede this test, and authenticated GET is the positive control.
- verify-acl (REASONED; docs): Read effective users including selectors/passwords without publishing hashes; app GET succeeds and CONFIG GET bind returns NOPERM, not NOAUTH or unknown command.
- verify-acl-log (REASONED; docs, r82): Correlate denied CONFIG with user and age in ACL LOG; preserve events before resets, and bounded in-memory emptiness proves no absence of failures.
- verify-direction (REASONED; docs): Redis 7+ DRYRUN allows input reads/output writes/allowed publication and denies reverse access/unrelated publication; it does not execute or prove authentication.
- verify-persistence (REASONED; docs): Repeat policy and permissions after restart; runtime-only changes revert. Retired users must lose old sessions and fail fresh auth.
- replication-auth (REASONED; docs, ha): Use PING/REPLCONF/PSYNC-only replication users and masteruser/masterauth on every potential primary; outbound credentials do not protect incoming access or limit the stream by key.
- sentinel-default (REASONED; ha): Sentinel normally listens on 26379 with protected mode disabled and no active auth rule; data-port protection does not protect it.
- sentinel-auth (REASONED; docs, ha): Password-only Sentinel auth applies throughout 6.0+; ACLs require 6.2+. Provision separate peer/admin and narrow discovery identities; do not combine the two arrangements.
- sentinel-announcement (REASONED; ha): Private bind and network policy restrict Sentinel; announce-ip/port only publish discovery information. Password-only peers share a distinct Sentinel password.
- monitor-auth (REASONED; ha): Sentinel monitored-server credentials start unset and differ from peer credentials; provision every potential primary/replica.
- monitor-acl (REASONED; docs, ha): Monitored-server ACLs require 6.0+, channel isolation 6.2+; the 8.10.1-reviewed operational policy permits only `__sentinel__:hello` publication/subscription.
- cluster-bus (REASONED; docs): Opt-in cluster adds a binary bus, normally data port+10000 (16379); data RESP AUTH is not a bus gate. Restrict node and client paths separately.
- cluster-announcement (REASONED; ha): 8.10.1 cluster-port selects the bus listener; announce fields are not firewalls. TLS offset uses tls-port; binds and remapped advertisements must agree.
- ha-tls (REASONED; docs, ha): Client TLS does not enable outgoing replication or cluster TLS; tls-replication and tls-cluster default disabled and must be configured separately.
- outgoing-cert (REASONED; r60, r620): Outgoing TLS normally reuses the server certificate; separate tls-client-cert/key need 6.2+. Older builds require one dual-purpose certificate and reject unknown directives.
- bus-cert (REASONED; ha): The TLS cluster bus always requires a trusted peer certificate, independently of data-port tls-auth-clients.
- sentinel-tls (REASONED; ha): Sentinel tls-port independently creates incoming TLS; tls-replication selects outgoing data/peer TLS and default TLS-port advertisement; explicit announce-port overrides it.
- peer-name (REASONED; ha, release-notes): Redis 8.10+ tls-expected-peer-name defaults unset; it adds shared trust-group identity to outgoing replication/bus/MIGRATE and incoming bus, not node-ID binding.
- peer-limits (REASONED; ha): TLS_NO_PEER_NAME_VERIFICATION builds warn and skip name enforcement; 8.10.1 Sentinel's outgoing hiredis path does not apply this check; use a dedicated trust boundary.
- verify-replication (REASONED; ha, docs): Wrong/missing replica credentials must fail; correct auth restores link and fresh canary transfer. Test replica incoming auth and repeat through promotion.
- verify-replication-acl (REASONED; docs): Redis 7+ DRYRUN PSYNC permits replication and denies app; synchronization and promotion require separate runtime tests.
- verify-sentinel (REASONED; docs, ha): Uncredentialed discovery returns endpoint exposed and NOAUTH secured; discovery credentials restore it but administrative commands get NOPERM. Peer announcements alone prove no communication.
- verify-monitor (REASONED; docs, ha): sentinel-monitor permits PING but denies GET/unrelated publication; wrong auth-pass stops monitoring, correct credentials restore it, including after promotion.
- verify-bus (REASONED; docs, ha): Compare actual bus TCP access from forbidden and allowed locations; only forbidden access must fail. CLUSTER NODES announcements and listener evidence complement reachability.
- verify-replication-tls (REASONED; ha, docs): Correlate TLS-only primary listener, replica connection to that port and a fresh replicated canary; link status or a separate TLS probe alone proves no encryption.
- verify-replica-cert (REASONED; docs, ha): Without automatic certificate-user auth, missing client cert must fail TLS and trusted cert reach NOAUTH; with tls-auth-clients no both reach NOAUTH.
- verify-bus-cert (REASONED; ha, docs): TLS 1.2 bus probes reject absent/untrusted certificates and accept trusted peers under either data-port client-auth setting; handshake success is not cluster membership.
- verify-sentinel-tls (REASONED; docs, ha): 26379 must reject plaintext RESP, require client certificates and Redis credentials, and restore discovery with both; outgoing TLS/failover need separate topology evidence.
- verify-peer-name (REASONED; ha): Same-CA bus certificates both pass without name restriction; enabled enforcement rejects wrong SAN/CN and accepts matching identity. Build warnings/readback alone are insufficient.
- verify-outbound-name (REASONED; ha, docs): Force new replication connections: wrong-name server works unrestricted, fails with explicit name-verification evidence when restricted, then recovers with matching certificate/canary.
- valkey (REASONED; valkey): Valkey shares requirepass/ACL/TLS concepts; verify its version-specific syntax. Redis HA findings and limitations have not been established for Valkey.
- local-sentinel (DEMONSTRATED; docs): Historical Sentinel shell parsing and invalid-input rejection tested local dispatch only, not Redis behavior; those runs covered an earlier form whose refusals exited with status 1, and the current form is covered by gate bash -n and ShellCheck passes and stub runs.

````json
{
  "schema": 1,
  "checked": "2026-09-26",
  "documentation_checked": "2026-09",
  "body_sha256": "fa2cae058289856b567209194eda26b4e7b97d426b3f84f8c113132b92e5d0f3",
  "components": {
    "r60": {
      "name": "Redis configuration",
      "basis": "6.0.20",
      "sources": {
        "s2e8e20a079ac": "https://raw.githubusercontent.com/redis/redis/6.0.20/redis.conf"
      }
    },
    "r62": {
      "name": "Redis configuration",
      "basis": "6.2.14",
      "sources": {
        "s0e0da970fda1": "https://raw.githubusercontent.com/redis/redis/6.2.14/redis.conf"
      }
    },
    "r620": {
      "name": "Redis configuration",
      "basis": "6.2.0",
      "sources": {
        "sbf13a91d0de5": "https://raw.githubusercontent.com/redis/redis/6.2.0/redis.conf"
      }
    },
    "r70": {
      "name": "Redis configuration",
      "basis": "7.0.15",
      "sources": {
        "s4b8359fa209a": "https://raw.githubusercontent.com/redis/redis/7.0.15/redis.conf"
      }
    },
    "r82": {
      "name": "Redis configuration",
      "basis": "8.2.1",
      "sources": {
        "s4c78c91e3995": "https://raw.githubusercontent.com/redis/redis/8.2.1/redis.conf"
      }
    },
    "r86": {
      "name": "Redis configuration",
      "basis": "8.6.0",
      "sources": {
        "s4afad097a602": "https://raw.githubusercontent.com/redis/redis/8.6.0/redis.conf"
      }
    },
    "ha": {
      "name": "Redis HA source",
      "basis": "8.10.1",
      "sources": {
        "sf86ee0b4abaa": "https://raw.githubusercontent.com/redis/redis/8.10.1/redis.conf",
        "s81bf82ed258f": "https://raw.githubusercontent.com/redis/redis/8.10.1/src/cluster_legacy.c",
        "s0c0876f8a079": "https://raw.githubusercontent.com/redis/redis/8.10.1/src/replication.c",
        "sd23ed315b5f6": "https://raw.githubusercontent.com/redis/redis/8.10.1/sentinel.conf",
        "s4de235c7343e": "https://raw.githubusercontent.com/redis/redis/8.10.1/src/sentinel.c",
        "s9f433f5e78e3": "https://raw.githubusercontent.com/redis/redis/8.10.1/src/config.c",
        "saf8be6411363": "https://raw.githubusercontent.com/redis/redis/8.10.1/src/server.c",
        "s28f3f121848c": "https://raw.githubusercontent.com/redis/redis/8.10.1/src/tls.c"
      }
    },
    "image8": {
      "name": "Redis image tag",
      "basis": "v8.10.2",
      "sources": {
        "sfc739e8ba37a": "https://github.com/redis/docker-library-redis/blob/v8.10.2/alpine/Dockerfile#L82-L87",
        "sc9481a9a0b3e": "https://github.com/redis/docker-library-redis/blob/v8.10.2/debian/docker-entrypoint.sh",
        "sf42044d0a0cf": "https://github.com/redis/docker-library-redis/blob/v8.10.2/debian/Dockerfile#L127-L130"
      }
    },
    "r74": {
      "name": "Redis compiled defaults",
      "basis": "7.4.8",
      "sources": {
        "s255d08889d8e": "https://github.com/redis/redis/blob/7.4.8/src/server.h#L119-L120",
        "s71d2454bab19": "https://github.com/redis/redis/blob/7.4.8/src/acl.c#L1407-L1415"
      }
    },
    "r8102": {
      "name": "Redis compiled defaults",
      "basis": "8.10.2",
      "sources": {
        "sd44747e97e5d": "https://github.com/redis/redis/blob/8.10.2/src/server.h#L138-L139",
        "see1833b741f4": "https://github.com/redis/redis/blob/8.10.2/src/acl.c#L1430-L1438"
      }
    },
    "docs": {
      "name": "Redis documentation",
      "basis": "unknown",
      "sources": {
        "s676f92c46896": "https://redis.io/docs/latest/operate/oss_and_stack/management/security/",
        "s5f24cdfad62f": "https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/",
        "s6cf51f8deeec": "https://redis.io/docs/latest/commands/auth/",
        "s72fa2dffefe0": "https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/",
        "s503353d67ab0": "https://redis.io/docs/latest/commands/flushall/",
        "s04727068bf6d": "https://redis.io/docs/latest/commands/flushdb/",
        "s77f119379267": "https://redis.io/docs/latest/commands/swapdb/",
        "s94f2d2ff2791": "https://redis.io/docs/latest/commands/keys/",
        "sbf9af1bcd939": "https://redis.io/docs/latest/commands/randomkey/",
        "sf208d01054d8": "https://redis.io/docs/latest/commands/scan/",
        "s845464defcbf": "https://redis.io/docs/latest/commands/function-delete/",
        "se6006d0ebe9d": "https://redis.io/docs/latest/commands/function-flush/",
        "sfe89bc1db7ec": "https://redis.io/docs/latest/commands/function-load/",
        "s2d7c63097f6b": "https://redis.io/docs/latest/commands/function-restore/",
        "s810656b5a50e": "https://redis.io/docs/latest/commands/acl-setuser/",
        "seaec1ae0ac17": "https://redis.io/docs/latest/commands/config-rewrite/",
        "s96598ec29ba4": "https://redis.io/docs/latest/commands/acl-save/",
        "s3e1c0de156e5": "https://redis.io/docs/latest/commands/acl-load/",
        "s89a679483b31": "https://redis.io/docs/latest/commands/client-kill/",
        "sb5b7454ab5ec": "https://redis.io/docs/latest/commands/psubscribe/",
        "s19cd1836b3cd": "https://redis.io/docs/latest/commands/publish/",
        "sedf741005697": "https://redis.io/docs/latest/commands/subscribe/",
        "s6e5d3141dadd": "https://redis.io/docs/latest/commands/eval/",
        "s783428f2ae71": "https://redis.io/docs/latest/commands/evalsha/",
        "s0b532abc6b3e": "https://redis.io/docs/latest/commands/fcall/",
        "se9b0821291f2": "https://redis.io/docs/latest/commands/eval_ro/",
        "sf9ad57a17ff4": "https://redis.io/docs/latest/commands/evalsha_ro/",
        "s4265e3593644": "https://redis.io/docs/latest/commands/fcall_ro/",
        "sc6b4e54687ac": "https://redis.io/docs/latest/develop/tools/cli/",
        "sd3d4315b25ce": "https://redis.io/docs/latest/commands/get/",
        "se987368157bc": "https://redis.io/docs/latest/commands/set/",
        "sc62448a319aa": "https://redis.io/docs/latest/commands/ping/",
        "s04c6a2a49051": "https://redis.io/docs/latest/commands/acl-getuser/",
        "s7ab1aac347a4": "https://redis.io/docs/latest/commands/config-get/",
        "sb5f5479eccf8": "https://redis.io/docs/latest/commands/acl-log/",
        "s8d6577576295": "https://redis.io/docs/latest/commands/acl-dryrun/",
        "s43b199002e27": "https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/#acl-rules-for-sentinel-and-replicas",
        "s34e2264081b7": "https://redis.io/docs/latest/operate/oss_and_stack/management/replication/#setting-a-replica-to-authenticate-to-a-master",
        "s426dcab02f8b": "https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#configuring-sentinel-instances-with-authentication",
        "s6c549585a510": "https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#redis-access-control-list-authentication",
        "s075c67b3e9d7": "https://redis.io/docs/latest/operate/oss_and_stack/management/scaling/#redis-cluster-tcp-ports",
        "sce02504d451b": "https://redis.io/docs/latest/commands/info/",
        "sfe348474049a": "https://redis.io/docs/latest/commands/cluster-nodes/",
        "s04d70801d688": "https://redis.io/docs/latest/operate/oss_and_stack/management/security/encryption/#sentinel",
        "sb384cc06fc43": "https://redis.io/docs/latest/commands/config-set/"
      }
    },
    "image": {
      "name": "Redis image source",
      "basis": "584feaab6cd12a77866c121beff1bb16ff239486",
      "sources": {
        "s6e56989d73a1": "https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/6.2/debian/Dockerfile#L85-L90",
        "sdb0e9a2d1d56": "https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/7.4/debian/Dockerfile#L146-L150",
        "s65ef31503c67": "https://github.com/redis/docker-library-redis/blob/584feaab6cd12a77866c121beff1bb16ff239486/7.4/debian/docker-entrypoint.sh"
      }
    },
    "release-notes": {
      "name": "Redis release notes",
      "basis": "unknown",
      "sources": {
        "sadcc4b0a2908": "https://redis.io/docs/latest/operate/oss_and_stack/stack-with-enterprise/release-notes/redisce/redisos-8.6-release-notes/",
        "sead103199248": "https://redis.io/docs/latest/operate/oss_and_stack/stack-with-enterprise/release-notes/redisce/redisos-8.10-release-notes/"
      }
    },
    "valkey": {
      "name": "Valkey documentation",
      "basis": "unknown",
      "sources": {
        "sb488496d1f4b": "https://valkey.io/topics/acl/",
        "s0eebdf8ee73e": "https://valkey.io/topics/security/",
        "sdc8d63632a85": "https://valkey.io/topics/tls/"
      }
    }
  },
  "claims": {
    "baseline": {"text": "Redis 6.0+ supplies TLS and ACLs; TLS needs TLS-enabled server/client builds. Restrict bind and credentials before remote access.", "components": ["docs", "r60"], "sources": ["docs:s676f92c46896", "docs:s5f24cdfad62f", "r60:s2e8e20a079ac"], "status": "REASONED"},
    "optional-bind": {"text": "Redis 6.2+ -::1 makes an absent interface optional, not an occupied address; Redis 6.0 uses plain loopback binding.", "components": ["r62", "r60"], "sources": ["r62:s0e0da970fda1", "r60:s2e8e20a079ac"], "status": "REASONED"},
    "protected-mode": {"text": "6.0/6.2 protected mode requires default nopass and no explicit bind; 7.0 drops the bind condition. Explicit wildcard bind can expose passwordless 6.x.", "components": ["r60", "r62", "r70"], "sources": ["r60:s2e8e20a079ac", "r62:s0e0da970fda1", "r70:s4b8359fa209a"], "status": "REASONED"},
    "image-protected": {"text": "Pinned 6.2-7.4 images and the checked 8.x tag patch protected-mode to no and run redis-server without a config; publish privately with explicit credentials.", "components": ["image", "image8"], "sources": ["image:s6e56989d73a1", "image:sdb0e9a2d1d56", "image8:sfc739e8ba37a", "image8:sc9481a9a0b3e", "image:s65ef31503c67", "image8:sf42044d0a0cf"], "status": "REASONED"},
    "compiled-bind": {"text": "7.4.8/8.10.2 compiled bind is * -::*; IPv6 wildcard applies where available.", "components": ["r74", "r8102"], "sources": ["r74:s255d08889d8e", "r8102:sd44747e97e5d"], "status": "REASONED"},
    "compiled-user": {"text": "Checked 7.4.8/8.10.2 default users are on nopass +@all; disabled DEBUG/MODULE commands remain disabled.", "components": ["r74", "r8102", "r82"], "sources": ["r74:s71d2454bab19", "r8102:see1833b741f4", "r82:s4c78c91e3995"], "status": "REASONED"},
    "password": {"text": "requirepass supplies one shared AUTH password; prefer separate least-privilege ACL identities.", "components": ["docs"], "sources": ["docs:s676f92c46896", "docs:s6cf51f8deeec", "docs:s72fa2dffefe0"], "status": "REASONED"},
    "keyless": {"text": "~app:* constrains key arguments, not keyless commands: write categories include global flush/swap and 7+ FUNCTION writes; reads include keyspace walking.", "components": ["docs"], "sources": ["docs:s72fa2dffefe0", "docs:s503353d67ab0", "docs:s04727068bf6d", "docs:s77f119379267", "docs:s94f2d2ff2791", "docs:sbf9af1bcd939", "docs:sf208d01054d8", "docs:s845464defcbf", "docs:se6006d0ebe9d", "docs:sfe89bc1db7ec", "docs:s2d7c63097f6b"], "status": "REASONED"},
    "allowlist": {"text": "Removing flushall/flushdb/swapdb removes only those commands; replace broad grants with reset and explicit required commands such as GET/SET.", "components": ["docs"], "sources": ["docs:s810656b5a50e"], "status": "REASONED"},
    "default-user": {"text": "Default starts on nopass ~* +@all, adding &* from 6.2; secure or disable it only after named clients/admin work; existing sessions survive.", "components": ["docs"], "sources": ["docs:s72fa2dffefe0"], "status": "REASONED"},
    "mfa": {"text": "Redis has no second-factor dialogue; mutual TLS adds machine possession alongside passwords, not human MFA.", "components": ["docs"], "sources": ["docs:s676f92c46896", "docs:s5f24cdfad62f"], "status": "REASONED"},
    "cert-user": {"text": "Redis 8.6+ tls-auth-clients-user defaults off; enabling it can authenticate without passwords. Keep off for these NOAUTH checks and omit the unknown directive on older releases.", "components": ["r86", "release-notes"], "sources": ["r86:s4afad097a602", "release-notes:sadcc4b0a2908"], "status": "REASONED"},
    "reset": {"text": "ACL SETUSER changes users incrementally and applies rules left-to-right; reset removes old grants/passwords and, on 7+, selectors.", "components": ["docs"], "sources": ["docs:s810656b5a50e"], "status": "REASONED"},
    "channel-default": {"text": "resetchannels needs 6.2+; 6.0 lacks channel ACLs. Redis 6.2 default allchannels became resetchannels in 7.0.", "components": ["r82", "docs"], "sources": ["r82:s4c78c91e3995", "docs:s810656b5a50e"], "status": "REASONED"},
    "inline-persistence": {"text": "CONFIG REWRITE persists inline users only with a writable startup configuration and OK; it also rewrites other runtime settings.", "components": ["docs"], "sources": ["docs:seaec1ae0ac17"], "status": "REASONED"},
    "acl-file": {"text": "External aclfile excludes inline users and requirepass; ACL SAVE persists, ACL LOAD replaces, invalid loads retain old policy, and CONFIG REWRITE does not save ACLs.", "components": ["r82", "docs"], "sources": ["r82:s4c78c91e3995", "docs:s96598ec29ba4", "docs:s3e1c0de156e5"], "status": "REASONED"},
    "revocation": {"text": "Disabling a user blocks new auth but CLIENT KILL USER closes existing sessions; password replacement also needs forced reconnect and persistence.", "components": ["docs"], "sources": ["docs:s72fa2dffefe0", "docs:s89a679483b31"], "status": "REASONED"},
    "directional-keys": {"text": "Redis 7+ %R~/%W~ separate read/write key access; commands still need grants and broader ~ patterns can defeat separation.", "components": ["docs"], "sources": ["docs:s72fa2dffefe0"], "status": "REASONED"},
    "channels": {"text": "Channel patterns are independent of keys; reset then allow required channels/commands. PSUBSCRIBE patterns must literally match an allowed pattern.", "components": ["docs"], "sources": ["docs:s810656b5a50e", "docs:s72fa2dffefe0", "docs:sb5b7454ab5ec", "docs:s19cd1836b3cd", "docs:sedf741005697"], "status": "REASONED"},
    "scripting": {"text": "Subtract admin/dangerous/scripting after grants; SCRIPT/FUNCTION removal alone misses execution commands. Omit FUNCTION on 6.x and rebuild unknown selectors first.", "components": ["docs"], "sources": ["docs:s810656b5a50e", "docs:s6e5d3141dadd", "docs:s783428f2ae71", "docs:s0b532abc6b3e", "docs:se9b0821291f2", "docs:sf9ad57a17ff4", "docs:s4265e3593644", "docs:s845464defcbf", "docs:se6006d0ebe9d", "docs:sfe89bc1db7ec", "docs:s2d7c63097f6b"], "status": "REASONED"},
    "startup-commands": {"text": "Redis 7+ enable-debug-command and enable-module-command default no in the pin; local/yes and startup-loaded modules still require ACL review.", "components": ["r82"], "sources": ["r82:s4c78c91e3995"], "status": "REASONED"},
    "renaming": {"text": "rename-command is deprecated; use ACL command restrictions.", "components": ["docs"], "sources": ["docs:s676f92c46896"], "status": "REASONED"},
    "tls-listener": {"text": "port 0 removes plaintext while tls-port 6379 serves TLS with configured CA/certificate/key; set mutual TLS for certificate-capable clients.", "components": ["docs", "r82"], "sources": ["docs:s5f24cdfad62f", "r82:s4c78c91e3995"], "status": "REASONED"},
    "tls-cert-default": {"text": "tls-auth-clients defaults yes; this guide's initial no removes client-certificate requirements, including incoming replicas, not the TLS cluster bus.", "components": ["ha"], "sources": ["ha:sf86ee0b4abaa", "ha:s81bf82ed258f"], "status": "REASONED"},
    "cli": {"text": "Use CA trust, --user and masked --askpass with history disabled; GET app:probe is allowed while PING is not granted to app.", "components": ["docs"], "sources": ["docs:sc6b4e54687ac", "docs:s6cf51f8deeec", "docs:sd3d4315b25ce", "docs:se987368157bc", "docs:sc62448a319aa"], "status": "REASONED"},
    "verify-listeners": {"text": "Inventory all listeners; only intended loopback/private addresses pass, and socket errors establish nothing.", "components": ["r82"], "sources": ["r82:s4c78c91e3995"], "status": "REASONED", "verify": [1]},
    "verify-plaintext": {"text": "Any plaintext RESP reply proves plaintext availability; TLS-only 6379 must close/reset plaintext while TLS reaches the same endpoint.", "components": ["docs"], "sources": ["docs:s5f24cdfad62f"], "status": "REASONED", "verify": [2]},
    "verify-noauth": {"text": "Secured default produces NOAUTH over TLS, exposed nopass produces PONG; certificate failures precede this test, and authenticated GET is the positive control.", "components": ["docs"], "sources": ["docs:s72fa2dffefe0", "docs:s5f24cdfad62f"], "status": "REASONED", "verify": [2]},
    "verify-acl": {"text": "Read effective users including selectors/passwords without publishing hashes; app GET succeeds and CONFIG GET bind returns NOPERM, not NOAUTH or unknown command.", "components": ["docs"], "sources": ["docs:s04c6a2a49051", "docs:s7ab1aac347a4"], "status": "REASONED"},
    "verify-acl-log": {"text": "Correlate denied CONFIG with user and age in ACL LOG; preserve events before resets, and bounded in-memory emptiness proves no absence of failures.", "components": ["docs", "r82"], "sources": ["docs:sb5f5479eccf8", "r82:s4c78c91e3995"], "status": "REASONED"},
    "verify-direction": {"text": "Redis 7+ DRYRUN allows input reads/output writes/allowed publication and denies reverse access/unrelated publication; it does not execute or prove authentication.", "components": ["docs"], "sources": ["docs:s8d6577576295"], "status": "REASONED"},
    "verify-persistence": {"text": "Repeat policy and permissions after restart; runtime-only changes revert. Retired users must lose old sessions and fail fresh auth.", "components": ["docs"], "sources": ["docs:s72fa2dffefe0", "docs:s89a679483b31"], "status": "REASONED"},
    "replication-auth": {"text": "Use PING/REPLCONF/PSYNC-only replication users and masteruser/masterauth on every potential primary; outbound credentials do not protect incoming access or limit the stream by key.", "components": ["docs", "ha"], "sources": ["docs:s43b199002e27", "ha:sf86ee0b4abaa", "ha:s0c0876f8a079", "docs:s34e2264081b7"], "status": "REASONED"},
    "sentinel-default": {"text": "Sentinel normally listens on 26379 with protected mode disabled and no active auth rule; data-port protection does not protect it.", "components": ["ha"], "sources": ["ha:sd23ed315b5f6"], "status": "REASONED"},
    "sentinel-auth": {"text": "Password-only Sentinel auth applies throughout 6.0+; ACLs require 6.2+. Provision separate peer/admin and narrow discovery identities; do not combine the two arrangements.", "components": ["docs", "ha"], "sources": ["docs:s426dcab02f8b", "ha:sd23ed315b5f6"], "status": "REASONED"},
    "sentinel-announcement": {"text": "Private bind and network policy restrict Sentinel; announce-ip/port only publish discovery information. Password-only peers share a distinct Sentinel password.", "components": ["ha"], "sources": ["ha:sd23ed315b5f6"], "status": "REASONED"},
    "monitor-auth": {"text": "Sentinel monitored-server credentials start unset and differ from peer credentials; provision every potential primary/replica.", "components": ["ha"], "sources": ["ha:sd23ed315b5f6", "ha:s4de235c7343e"], "status": "REASONED"},
    "monitor-acl": {"text": "Monitored-server ACLs require 6.0+, channel isolation 6.2+; the 8.10.1-reviewed operational policy permits only `__sentinel__:hello` publication/subscription.", "components": ["docs", "ha"], "sources": ["docs:s6c549585a510", "ha:s4de235c7343e"], "status": "REASONED"},
    "cluster-bus": {"text": "Opt-in cluster adds a binary bus, normally data port+10000 (16379); data RESP AUTH is not a bus gate. Restrict node and client paths separately.", "components": ["docs"], "sources": ["docs:s075c67b3e9d7"], "status": "REASONED"},
    "cluster-announcement": {"text": "8.10.1 cluster-port selects the bus listener; announce fields are not firewalls. TLS offset uses tls-port; binds and remapped advertisements must agree.", "components": ["ha"], "sources": ["ha:sf86ee0b4abaa", "ha:s81bf82ed258f"], "status": "REASONED"},
    "ha-tls": {"text": "Client TLS does not enable outgoing replication or cluster TLS; tls-replication and tls-cluster default disabled and must be configured separately.", "components": ["docs", "ha"], "sources": ["docs:s5f24cdfad62f", "ha:s9f433f5e78e3"], "status": "REASONED"},
    "outgoing-cert": {"text": "Outgoing TLS normally reuses the server certificate; separate tls-client-cert/key need 6.2+. Older builds require one dual-purpose certificate and reject unknown directives.", "components": ["r60", "r620"], "sources": ["r60:s2e8e20a079ac", "r620:sbf13a91d0de5"], "status": "REASONED"},
    "bus-cert": {"text": "The TLS cluster bus always requires a trusted peer certificate, independently of data-port tls-auth-clients.", "components": ["ha"], "sources": ["ha:s81bf82ed258f"], "status": "REASONED"},
    "sentinel-tls": {"text": "Sentinel tls-port independently creates incoming TLS; tls-replication selects outgoing data/peer TLS and default TLS-port advertisement; explicit announce-port overrides it.", "components": ["ha"], "sources": ["ha:saf8be6411363", "ha:s4de235c7343e"], "status": "REASONED"},
    "peer-name": {"text": "Redis 8.10+ tls-expected-peer-name defaults unset; it adds shared trust-group identity to outgoing replication/bus/MIGRATE and incoming bus, not node-ID binding.", "components": ["ha", "release-notes"], "sources": ["ha:sf86ee0b4abaa", "ha:s28f3f121848c", "release-notes:sead103199248"], "status": "REASONED"},
    "peer-limits": {"text": "TLS_NO_PEER_NAME_VERIFICATION builds warn and skip name enforcement; 8.10.1 Sentinel's outgoing hiredis path does not apply this check; use a dedicated trust boundary.", "components": ["ha"], "sources": ["ha:s28f3f121848c", "ha:s4de235c7343e"], "status": "REASONED"},
    "verify-replication": {"text": "Wrong/missing replica credentials must fail; correct auth restores link and fresh canary transfer. Test replica incoming auth and repeat through promotion.", "components": ["ha", "docs"], "sources": ["ha:s0c0876f8a079", "docs:sce02504d451b", "docs:s34e2264081b7"], "status": "REASONED"},
    "verify-replication-acl": {"text": "Redis 7+ DRYRUN PSYNC permits replication and denies app; synchronization and promotion require separate runtime tests.", "components": ["docs"], "sources": ["docs:s8d6577576295", "docs:s43b199002e27"], "status": "REASONED"},
    "verify-sentinel": {"text": "Uncredentialed discovery returns endpoint exposed and NOAUTH secured; discovery credentials restore it but administrative commands get NOPERM. Peer announcements alone prove no communication.", "components": ["docs", "ha"], "sources": ["docs:s426dcab02f8b", "ha:sd23ed315b5f6"], "status": "REASONED", "verify": [7]},
    "verify-monitor": {"text": "sentinel-monitor permits PING but denies GET/unrelated publication; wrong auth-pass stops monitoring, correct credentials restore it, including after promotion.", "components": ["docs", "ha"], "sources": ["docs:s6c549585a510", "ha:s4de235c7343e"], "status": "REASONED"},
    "verify-bus": {"text": "Compare actual bus TCP access from forbidden and allowed locations; only forbidden access must fail. CLUSTER NODES announcements and listener evidence complement reachability.", "components": ["docs", "ha"], "sources": ["docs:s075c67b3e9d7", "docs:sfe348474049a", "ha:s81bf82ed258f"], "status": "REASONED", "verify": [3]},
    "verify-replication-tls": {"text": "Correlate TLS-only primary listener, replica connection to that port and a fresh replicated canary; link status or a separate TLS probe alone proves no encryption.", "components": ["ha", "docs"], "sources": ["ha:saf8be6411363", "docs:sce02504d451b", "docs:s5f24cdfad62f"], "status": "REASONED", "verify": [4, 5]},
    "verify-replica-cert": {"text": "Without automatic certificate-user auth, missing client cert must fail TLS and trusted cert reach NOAUTH; with tls-auth-clients no both reach NOAUTH.", "components": ["docs", "ha"], "sources": ["docs:s5f24cdfad62f", "ha:sf86ee0b4abaa"], "status": "REASONED", "verify": [5]},
    "verify-bus-cert": {"text": "TLS 1.2 bus probes reject absent/untrusted certificates and accept trusted peers under either data-port client-auth setting; handshake success is not cluster membership.", "components": ["ha", "docs"], "sources": ["ha:s81bf82ed258f", "docs:s5f24cdfad62f"], "status": "REASONED", "verify": [6]},
    "verify-sentinel-tls": {"text": "26379 must reject plaintext RESP, require client certificates and Redis credentials, and restore discovery with both; outgoing TLS/failover need separate topology evidence.", "components": ["docs", "ha"], "sources": ["docs:s04d70801d688", "ha:s4de235c7343e", "docs:sc6b4e54687ac"], "status": "REASONED", "verify": [7]},
    "verify-peer-name": {"text": "Same-CA bus certificates both pass without name restriction; enabled enforcement rejects wrong SAN/CN and accepts matching identity. Build warnings/readback alone are insufficient.", "components": ["ha"], "sources": ["ha:sf86ee0b4abaa", "ha:s28f3f121848c"], "status": "REASONED", "verify": [8]},
    "verify-outbound-name": {"text": "Force new replication connections: wrong-name server works unrestricted, fails with explicit name-verification evidence when restricted, then recovers with matching certificate/canary.", "components": ["ha", "docs"], "sources": ["ha:s9f433f5e78e3", "ha:s28f3f121848c", "docs:sb384cc06fc43", "docs:s89a679483b31", "docs:sce02504d451b"], "status": "REASONED"},
    "valkey": {"text": "Valkey shares requirepass/ACL/TLS concepts; verify its version-specific syntax. Redis HA findings and limitations have not been established for Valkey.", "components": ["valkey"], "sources": ["valkey:sb488496d1f4b", "valkey:s0eebdf8ee73e", "valkey:sdc8d63632a85"], "status": "REASONED"},
    "local-sentinel": {"text": "Historical Sentinel shell parsing and invalid-input rejection tested local dispatch only, not Redis behavior; those runs covered an earlier form whose refusals exited with status 1, and the current form is covered by gate bash -n and ShellCheck passes and stub runs.", "components": ["docs"], "sources": ["docs:sc6b4e54687ac"], "status": "DEMONSTRATED", "evidence": "With `set -u`, it rejected the unchanged placeholder, an embedded placeholder, an empty host, a marker-only assignment, an omitted assignment with no inherited arguments, and an extra host argument before any connection command ran."}
  }
}
````
<!-- version-basis:end -->
