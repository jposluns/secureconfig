# BI dashboards: Metabase, Superset, Redash

Metabase, Apache Superset and Redash are business intelligence tools that turn database queries into charts and dashboards. This guide helps your AI assistant deploy them securely, including private access with MFA at the fronting layer, secured setup and signing secrets, and read-only database accounts unless a dashboard must write data.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/bi-dashboards.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Metabase v0.65.3, Redash v26.9.0, environ 1.2.0, Ring Jetty adapter 1.15.3, and Jetty 12.1.13; 1 further source is pinned to a commit and 4 carry no recorded version. Metadata reviewed 2026-09-26; documentation checked September 2026. The guide records 25 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

These tools hold live connections to your production databases and cache query results in their own
storage. An exposed instance, or one still running default or example credentials, leaks both the
dashboards themselves and the databases behind them. One rule dominates everything tool-specific
below, the same as [admin-uis.md](admin-uis.md): **never public.** Reach it over SSH port
forwarding, a tailnet ([tailscale.md](tailscale.md)), or Cloudflare Access ([cloudflare.md](cloudflare.md)),
with MFA enforced at that fronting layer ([mfa.md](mfa.md)), and connect it to the database with a
least-privilege, read-only account wherever the dashboards do not need to write back.

## Metabase

The first account created during setup becomes the admin account, so an instance reachable on the
network before you finish the setup wizard lets whoever gets there first claim admin. Complete
setup before the instance is reachable from anywhere but you.

Metabase binds a wildcard address by default (as of v0.65.3). It reads each `MB_` setting
from a `.lein-env` file in the working directory (and a `.boot-env` classpath resource), then the
environment, then JVM options such as `-Dmb.jetty.host`, each overriding the one before. The jar
leaves Jetty's host unset unless the last of those layers to set `MB_JETTY_HOST` gives it a non-blank
value (an empty value in a later layer masks an address in an earlier one), and Jetty binds the
wildcard address when no host is set; the official image's entrypoint instead exports
`MB_JETTY_HOST=0.0.0.0`, every IPv4 address, whenever the variable is unset or empty. The port is
3000 unless the last layer to set `MB_JETTY_PORT` gives it a non-blank value. For a jar behind a
local proxy set
`MB_JETTY_HOST=127.0.0.1`, and in Docker publish only to host loopback (`127.0.0.1:3000:3000`),
before the first start.

Public links and public embeds are enabled by default and let admins share a question, dashboard,
or document with anyone holding the URL; visitors get view-only results with no login. Metabase's
own docs warn that the public link URL is recoverable from a public embed, so an embed is not a
stronger boundary than a plain public link. Row and column security (per-user sandboxing of the
underlying data) is a Pro/Enterprise feature, not available on the open-source edition, so on the
free tier a public link or a shared question exposes whatever rows and columns the question already
queries. Disable public sharing in Admin Settings unless you specifically need it, and treat every
public link as a permanent, unauthenticated data release.

## Apache Superset

Superset ships a `SECRET_KEY` that signs session cookies; its own docs call it "very important to
keep the `SECRET_KEY` secret and set to a secure unique complex random value." Set it, and change
the admin password created at first run, before the instance is reachable by anyone else. Do not treat `AUTH_ROLE_PUBLIC` being absent from your config as proof that anonymous access is off;
confirm it from the effective Public-role permissions instead. What keeps anonymous visitors out of
your data is that the Public role grants no data access by default (Superset:
"Data access is still required by default"), so inspect that role and remove any anonymous dashboard
or dataset grants. `PUBLIC_ROLE_LIKE` copies another role's permissions to Public at `superset init`
(choosing a broad role such as `Gamma` grants access rather than restricting it), and it does not
scope access to particular datasets or dashboards, which stay separately controlled. Superset's own `docker-compose.yml` states
plainly that the stack is not supported for production and that a real deployment needs its own
environment file with unique passwords and `SECRET_KEY`; do not run the example or dev compose file
against a production database.

## Redash

Setup creates the admin account on first run: "it will ask you to create your admin account. Once
this is done, you can start using Redash." Redash's own setup guidance calls out both HTTPS and its signing secrets as things you must set:
"If this is a production setup, you should enforce HTTPS and make sure you set the cookie secret."
For a manual deployment set a strong, instance-specific `REDASH_COOKIE_SECRET` and
`REDASH_SECRET_KEY` (the latter encrypts stored data-source credentials), keep them out of version
control, and never reuse them across instances. Front it the same as the other tools here rather than
relying on anything Redash provides natively.

Redash's `server` command, which the official image runs by default, binds gunicorn to
`REDASH_GUNICORN_BIND`, or to `[::]:5000`, the IPv6 wildcard (which may also accept IPv4 on a dual-stack host), when that variable is unset or empty
(as of v26.9.0). Behind a local proxy set `REDASH_GUNICORN_BIND=127.0.0.1:5000`; in Docker, publish
only to host loopback.

## Verify

REASONED: the Metabase, Superset, Redash and Docker port-publishing sources below support this host-side inventory, which is prose rather than part of the block below, because it runs on each tool's host and the block runs from outside your network. On that host, run `ss -tlnp` and read every application AND proxy listener; Metabase/Superset/Redash default to 3000/8088/5000 (ports vary by install). `ss` shows host listeners, not Docker's NAT: for a container also inspect the published address/port and the forwarding rules, and probe each direct origin and backend port from another host (IPv4, IPv6, LAN/VPC); absence from `ss` is not proof of isolation. No BI deployment or external test network is available here, so no listing is recorded.

REASONED: authorized-data positive control and anonymous comparison, per the guide's cited Metabase data permissions and Superset security. No BI deployment, authorized account or external probe host is available. bash -n and ShellCheck 0.11.0 exited 0 without diagnostics; original, missing-assignment, short, empty and embedded-placeholder cases printed refusal messages without reaching curl, while substituted URLs reached two curl stubs. The bash -n, ShellCheck and stub runs recorded here covered the listener and data-route probe block in an earlier form, whose guard refusals left the subshell with status 0; none covered the later form, whose guard refusals left the subshell with status 2, or the forms after it, whose checks are recorded after the block. Live outcomes remain unobserved: exposed access returns dashboard data anonymously; fixed access denies or challenges it while the authorized request still returns actual data. First, with valid authorization, confirm your chosen protected route returns actual dashboard DATA (a
real data or API route, not the SPA HTML shell or a health endpoint): that is the positive control.
Then, from OUTSIDE your network with no cookies, tokens, or Access credentials, run the whole block
(substitute inside the quotes):

REASONED: following block; Metabase, Superset and Redash sources below support the anonymous front-page and data-route checks. No BI deployment or external test network is available here; no live run is recorded. Expected exposed, denied and inconclusive outcomes surround the block. The block records each outcome and exits once: 2 if its guard refuses or curl is not installed, 3 if a request fails or the protected route answers 404 or a server error, and otherwise 0. A 401 or 403 is the pass; any other answer is printed for you to judge, because only its body shows dashboard data or a login page, so the block reports no finding itself and its last line says so.

```bash
(                                       # a subshell, so your own script arguments are untouched and one exit status covers the whole block
  set +e                                # errexit off, so a request that fails is recorded below instead of ending the block
  set -- PASTE_WHOLE_BLOCK \
    'https://REPLACE_WITH_BI_HOST/' \
    'https://REPLACE_WITH_BI_HOST/REPLACE_WITH_KNOWN_PROTECTED_ROUTE'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  if [ -z "$1" ] || [ -z "$2" ]; then echo "substitute both URLs on the set -- line above; not probing"; exit 2; fi
  case "$1$2" in
    *REPLACE_WITH_*|*example.com*) echo "substitute your own URLs on the set -- line above; not probing"; exit 2 ;;
  esac
  command -v curl >/dev/null || { echo "curl is not installed here; not probing"; exit 2; }
  set -- "$1" "$2" 0                    # the 3rd value is the block's status so far: 3 (inconclusive) outranks 0; the block classifies no finding (see its last line)
  set -- "$1" "$2" "$3" "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 -i -w '\n%{http_code}' "$1"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # the tool's front page
  set -- "$1" "$2" "$3" "${4##*$'\n'}" "${4%$'\n'*}"        # curl's exit status, then the response with the HTTP code on its last line
  set -- "$1" "$2" "$3" "$4" "${5%$'\n'*}" "${5##*$'\n'}"   # curl's exit status, the response, then the HTTP code
  printf '%s\n' "$5"
  case "$4:$6" in
    0:401|0:403) ;;
    0:*) echo "unclassified: HTTP $6 from the front page is not a 401 or 403 denial, so read its body against the paragraph after this block" ;;
    *) echo "curl exit $4: the front-page request failed; inconclusive"; set -- "$1" "$2" 3 ;;
  esac
  set -- "$1" "$2" "$3" "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 -i -w '\n%{http_code}' "$2"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # a known protected route
  set -- "$1" "$2" "$3" "${4##*$'\n'}" "${4%$'\n'*}"        # curl's exit status, then the response with the HTTP code on its last line
  set -- "$1" "$2" "$3" "$4" "${5%$'\n'*}" "${5##*$'\n'}"   # curl's exit status, the response, then the HTTP code
  printf '%s\n' "$5"
  case "$4:$6" in
    0:401|0:403) ;;
    0:404|0:5??) echo "HTTP $6 from the protected route is a 404 or a server error; inconclusive"; set -- "$1" "$2" 3 ;;
    0:*) echo "unclassified: HTTP $6 from the protected route is not a 401 or 403 denial, so read its body against the paragraph after this block" ;;
    *) echo "curl exit $4: the protected-route request failed; inconclusive"; set -- "$1" "$2" 3 ;;
  esac
  echo "block exit $3; a front-page answer other than 401 or 403, and a protected-route answer other than 401, 403, 404 or a server error, are not classified, so judge them yourself: the protected route returning dashboard data with no authorization is a fail, a 200 login page or SPA shell proves nothing, and only a verified redirect into your login layer passes"
  exit "$3"
)
```

REASONED: preceding block; paired data-route authorization, with the listener and Docker-publication inventory and origin isolation in the section's first paragraph, per the guide's cited Docker port publishing, Metabase data permissions and Superset security. No BI deployment or external probe host is available. bash -n and ShellCheck 0.11.0 exited 0 without diagnostics; five rejected guard cases reached no curl stub and substituted URLs reached two. The bash -n, ShellCheck and stub runs recorded here covered the listener and data-route probe block in an earlier form, whose guard refusals left the subshell with status 0; none was re-run on the later form, whose guard refusals left the subshell with status 2. The current form leaves the listener inventory to the section's first paragraph and gives the whole block one exit status. Before its `curl` guard, it was checked on 2026-10-31 with bash -n and with curl stubs and no network, covering each status, a failed or inconclusive first request followed by a passing second one, and an inherited `readonly`, `declare -i` or `set -e`. The stub runs covered the refusals of a missing marker, too few or too many values, an empty first or second URL, a placeholder left in either URL and an example.com URL, each with no curl call. ShellCheck 0.11.0 passed on that form in the repository's gate suite. The current form adds a `command -v curl` guard before the first request, which refuses with status 2 and no request when curl is not installed; none of these checks was re-run on it, and that guard was not run. No live outcome is observed: exposed origins answer or anonymous requests disclose dashboard data; fixed origins are isolated and protected data requires authorization, with an authorized data response as the control. Accept an access denial from WHATEVER protects the route (the tool's or the reverse proxy's 401/403,
a Cloudflare Access challenge, or a verified redirect into that login layer), not only the tool's own
denial. Read the body, not just the status: a 200 login page or SPA shell proves nothing, and an
arbitrary redirect is inconclusive; the protected route returning dashboard data with no
authorization is a fail, and a 404, server error, or DNS/TLS/proxy error is inconclusive. For an
SSH-forward or tailnet-only deployment the public URL is unreachable by design, so confirm network
isolation separately and test the tool's own authorization over the permitted private path.

REASONED: default-credential rejection and effective database privileges, per the guide's cited Superset security, Superset docker-compose.yml and Metabase database users, roles, and privileges. No BI account, database role or disposable database is available; this prose supplies no local command or configuration to execute. Live outcomes remain unobserved: exposed credentials permit login or the data-source role writes beyond its needs; fixed credentials reject defaults and the actual role permits intended reads but denies the disposable write, with any required write-back separately scoped. Also confirm no default `admin/admin` or example credentials still work, and that the database
principal each data source uses is genuinely least-privilege. The least-privilege check is to identify the actual DB role, inspect
its EFFECTIVE grants and inherited roles at the database (a role named `readonly` can still hold
write, ownership, or admin privileges), confirm reads work while writes are denied (test with a
disposable object), and keep any needed write-back access separately scoped. Checking only the
connection string or the tool's own login is not enough.

## Sources (checked September 2026)

- Metabase documentation home: https://www.metabase.com/docs/latest/
- Metabase setting up Metabase (first account is admin): https://www.metabase.com/docs/latest/configuring-metabase/setting-up-metabase
- Metabase public links and embeds: https://www.metabase.com/docs/latest/embedding/public-links
- Metabase data permissions (row and column security is Pro/Enterprise): https://www.metabase.com/docs/latest/permissions/data
- Metabase Jetty host and port (`:mb-jetty-port` default "3000", no host default, blank values treated as unset, nil values dropped from the Jetty options), ring-jetty-adapter 1.15.3 passing the host to `setHost`, and Jetty 12.1.13 binding the wildcard address for a null host (pinned tags v0.65.3, ring 1.15.3, jetty-12.1.13, environ 1.2.0). The same Sources item also covers environ 1.2.0 merging `.lein-env`, `.boot-env`, the environment and JVM properties in that order, keeping empty values, so the last layer to set a key wins, and the image entrypoint's `MB_JETTY_HOST=0.0.0.0` default (pinned tags v0.65.3, ring 1.15.3, jetty-12.1.13, environ 1.2.0). The item's sources (1 of 4): https://github.com/metabase/metabase/blob/v0.65.3/src/metabase/config/core.clj#L54, https://github.com/metabase/metabase/blob/v0.65.3/src/metabase/config/core.clj#L76-L88, https://github.com/metabase/metabase/blob/v0.65.3/src/metabase/server/instance.clj#L36-L41, https://github.com/metabase/metabase/blob/v0.65.3/deps.edn#L82. The item's sources (2 of 4): https://github.com/weavejester/environ/blob/1.2.0/environ/src/environ/core.cljc#L32-L43, https://github.com/weavejester/environ/blob/1.2.0/environ/src/environ/core.cljc#L64-L79, https://github.com/metabase/metabase/blob/v0.65.3/deps.edn#L181, https://github.com/metabase/metabase/blob/v0.65.3/deps.edn#L213. The item's sources (3 of 4): https://github.com/ring-clojure/ring/blob/1.15.3/ring-jetty-adapter/src/ring/adapter/jetty.clj#L202-L207, https://github.com/jetty/jetty.project/blob/jetty-12.1.13/jetty-core/jetty-server/src/main/java/org/eclipse/jetty/server/ServerConnector.java#L338-L344. The item's sources (4 of 4): https://github.com/metabase/metabase/blob/v0.65.3/bin/docker/run_metabase.sh#L2-L5 and https://github.com/metabase/metabase/blob/v0.65.3/Dockerfile#L72-L75
- Superset security: https://superset.apache.org/admin-docs/security/
- Superset docker-compose.yml (production warning): https://github.com/apache/superset/blob/3d01094d231712e3470eb625be3f9925aeaeadb5/docker-compose.yml
- Redash help center: https://redash.io/help/
- Redash setting up a Redash instance: https://redash.io/help/open-source/setup/
- Redash `server` binding gunicorn to `${REDASH_GUNICORN_BIND:-[::]:5000}`, and the image's default `server` command (pinned tag v26.9.0): https://github.com/getredash/redash/blob/v26.9.0/bin/docker-entrypoint#L49-L50 and https://github.com/getredash/redash/blob/v26.9.0/Dockerfile#L133-L134
- Redash secret keys (cookie signing, data-source-credential encryption, do not reuse across instances or commit): https://redash.io/help/open-source/admin-guide/secrets/
- Metabase database users, roles, and privileges (a dedicated least-privilege read-only account): https://www.metabase.com/docs/latest/databases/users-roles-privileges
- Docker port publishing (a published container port is served through NAT/forwarding rules, so the host may show no matching listener): https://docs.docker.com/engine/network/port-publishing/


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- metabase: Metabase (v0.65.3)
- redash: Redash (v26.9.0)
- metabase-docs: Metabase docs (unknown)
- superset: Superset docs (unknown)
- superset-compose: Superset Compose (3d01094d231712e3470eb625be3f9925aeaeadb5)
- redash-docs: Redash docs (unknown)
- environ: environ (1.2.0)
- ring: Ring Jetty adapter (1.15.3)
- jetty: Jetty (12.1.13)
- docker: Docker publishing (unknown)

Claims (full source mapping in the JSON block below):

- private (REASONED; redash-docs, metabase-docs): Keep BI tools private with fronting MFA and least-privilege read-only DB accounts unless write-back is needed.
- metabase-setup (REASONED; metabase-docs): First account is admin; finish setup before anyone else can reach it.
- metabase-precedence (REASONED; metabase, environ): Settings merge .lein-env, .boot-env, environment and JVM properties in order; later empty values mask earlier settings.
- metabase-bind (REASONED; metabase, ring, jetty): Final nonblank MB_JETTY_HOST sets the jar host; otherwise Ring passes no host and Jetty binds wildcard. Use loopback behind a local proxy.
- metabase-image (REASONED; metabase, docker): Image exports MB_JETTY_HOST=0.0.0.0 when unset/empty; publish 127.0.0.1:3000:3000 before first start.
- metabase-port (REASONED; metabase): Port defaults 3000 unless the final MB_JETTY_PORT is nonblank.
- metabase-sharing (REASONED; metabase-docs): Public links/embeds default enabled and expose view-only question/dashboard/document results without login; disable unneeded sharing.
- metabase-embed (REASONED; metabase-docs): Public embed URLs are recoverable; embeds do not strengthen the public-link boundary.
- metabase-sandbox (REASONED; metabase-docs): Row/column security is Pro/Enterprise; free-tier sharing exposes the rows/columns the question queries.
- superset-secret (REASONED; superset): Set a unique complex random SECRET_KEY before exposure; it signs session cookies.
- superset-admin (REASONED; superset, superset-compose): Replace the first-run admin password before exposure.
- superset-public (REASONED; superset): Absent AUTH_ROLE_PUBLIC does not prove denial; inspect effective Public-role grants, which provide no data access by default.
- superset-copy (REASONED; superset): PUBLIC_ROLE_LIKE copies permissions at superset init; broad roles grant access without scoping datasets/dashboards.
- superset-compose (REASONED; superset-compose): Example Compose is unsupported for production; use unique passwords/SECRET_KEY, not the example against production data.
- redash-setup (REASONED; redash-docs): Create the first-run admin before others reach setup.
- redash-https (REASONED; redash-docs): Enforce HTTPS and the private-access pattern.
- redash-cookie (REASONED; redash-docs): Use an instance-specific REDASH_COOKIE_SECRET; never commit or reuse it.
- redash-encryption (REASONED; redash-docs): REDASH_SECRET_KEY encrypts data-source credentials; use a strong unique value outside version control.
- redash-bind (REASONED; redash): Default image server uses REDASH_GUNICORN_BIND or [::]:5000 when unset/empty; dual-stack may accept IPv4. Bind/publish privately.
- verify-credentials (REASONED; metabase-docs, superset-compose, redash-docs): Confirm no default admin/admin or example credentials work.
- verify-db (REASONED; metabase-docs): Inspect effective/inherited DB grants; confirm reads and denied writes on a disposable object; scope needed write-back separately.
- verify-listeners (REASONED; metabase, superset-compose, redash, docker): Inventory application/proxy sockets and Docker NAT publications; probe direct origins over IPv4/IPv6/LAN/VPC. Absent ss entries do not prove isolation.
- verify-ports (REASONED; metabase, superset-compose, redash): Verify lists Metabase/Superset/Redash defaults 3000/8088/5000, qualified as install-dependent.
- verify-data (REASONED; metabase-docs, superset, redash-docs): Authorized data is the control; anonymous data fails. Denial/verified login challenge passes; SPA shells, 404/errors and arbitrary redirects are inconclusive.
- verify-private (REASONED; redash-docs, docker): For tunnel-only access, confirm public isolation separately and test authorization on the permitted private path.

````json
{
  "schema": 1,
  "checked": "2026-09-26",
  "documentation_checked": "2026-09",
  "body_sha256": "bf579abc5c372f97e8d147027a58a00ba73b68a686c1b5fa224a1ce22cd0b62b",
  "components": {
    "metabase": {
      "name": "Metabase",
      "basis": "v0.65.3",
      "sources": {
        "sdc9a71065756": "https://github.com/metabase/metabase/blob/v0.65.3/src/metabase/config/core.clj#L54",
        "sc404f3a2e81b": "https://github.com/metabase/metabase/blob/v0.65.3/src/metabase/config/core.clj#L76-L88",
        "sfacbf36d3c3a": "https://github.com/metabase/metabase/blob/v0.65.3/src/metabase/server/instance.clj#L36-L41",
        "s6a973772ebe5": "https://github.com/metabase/metabase/blob/v0.65.3/deps.edn#L82",
        "sefe4e2a91acd": "https://github.com/metabase/metabase/blob/v0.65.3/deps.edn#L181",
        "s58ab8269b060": "https://github.com/metabase/metabase/blob/v0.65.3/deps.edn#L213",
        "s40c188997580": "https://github.com/metabase/metabase/blob/v0.65.3/bin/docker/run_metabase.sh#L2-L5",
        "s83a1fd1e4dd6": "https://github.com/metabase/metabase/blob/v0.65.3/Dockerfile#L72-L75"
      }
    },
    "redash": {
      "name": "Redash",
      "basis": "v26.9.0",
      "sources": {
        "se93d7c47b037": "https://github.com/getredash/redash/blob/v26.9.0/bin/docker-entrypoint#L49-L50",
        "s9f1ef7237804": "https://github.com/getredash/redash/blob/v26.9.0/Dockerfile#L133-L134"
      }
    },
    "metabase-docs": {
      "name": "Metabase docs",
      "basis": "unknown",
      "sources": {
        "s5e2251b3184d": "https://www.metabase.com/docs/latest/configuring-metabase/setting-up-metabase",
        "s521b3063e9f0": "https://www.metabase.com/docs/latest/embedding/public-links",
        "s02b7797b6ffe": "https://www.metabase.com/docs/latest/permissions/data",
        "s434abdb1aaef": "https://www.metabase.com/docs/latest/databases/users-roles-privileges"
      }
    },
    "superset": {
      "name": "Superset docs",
      "basis": "unknown",
      "sources": {
        "se97be7353585": "https://superset.apache.org/admin-docs/security/"
      }
    },
    "superset-compose": {
      "name": "Superset Compose",
      "basis": "3d01094d231712e3470eb625be3f9925aeaeadb5",
      "sources": {
        "s0ceca7af7f79": "https://github.com/apache/superset/blob/3d01094d231712e3470eb625be3f9925aeaeadb5/docker-compose.yml"
      }
    },
    "redash-docs": {
      "name": "Redash docs",
      "basis": "unknown",
      "sources": {
        "s4c72252b5447": "https://redash.io/help/open-source/setup/",
        "sbaf5b44079a0": "https://redash.io/help/open-source/admin-guide/secrets/"
      }
    },
    "environ": {
      "name": "environ",
      "basis": "1.2.0",
      "sources": {
        "s37ed6de2d80d": "https://github.com/weavejester/environ/blob/1.2.0/environ/src/environ/core.cljc#L32-L43",
        "s9754f7c47384": "https://github.com/weavejester/environ/blob/1.2.0/environ/src/environ/core.cljc#L64-L79"
      }
    },
    "ring": {
      "name": "Ring Jetty adapter",
      "basis": "1.15.3",
      "sources": {
        "s0455b1b1fb12": "https://github.com/ring-clojure/ring/blob/1.15.3/ring-jetty-adapter/src/ring/adapter/jetty.clj#L202-L207"
      }
    },
    "jetty": {
      "name": "Jetty",
      "basis": "12.1.13",
      "sources": {
        "s8f9e4989175e": "https://github.com/jetty/jetty.project/blob/jetty-12.1.13/jetty-core/jetty-server/src/main/java/org/eclipse/jetty/server/ServerConnector.java#L338-L344"
      }
    },
    "docker": {
      "name": "Docker publishing",
      "basis": "unknown",
      "sources": {
        "s1e53417c513d": "https://docs.docker.com/engine/network/port-publishing/"
      }
    }
  },
  "claims": {
    "private": {"text": "Keep BI tools private with fronting MFA and least-privilege read-only DB accounts unless write-back is needed.", "components": ["redash-docs", "metabase-docs"], "sources": ["redash-docs:s4c72252b5447", "metabase-docs:s434abdb1aaef"], "status": "REASONED"},
    "metabase-setup": {"text": "First account is admin; finish setup before anyone else can reach it.", "components": ["metabase-docs"], "sources": ["metabase-docs:s5e2251b3184d"], "status": "REASONED"},
    "metabase-precedence": {"text": "Settings merge .lein-env, .boot-env, environment and JVM properties in order; later empty values mask earlier settings.", "components": ["metabase", "environ"], "sources": ["metabase:sdc9a71065756", "metabase:sc404f3a2e81b", "environ:s37ed6de2d80d", "environ:s9754f7c47384"], "status": "REASONED"},
    "metabase-bind": {"text": "Final nonblank MB_JETTY_HOST sets the jar host; otherwise Ring passes no host and Jetty binds wildcard. Use loopback behind a local proxy.", "components": ["metabase", "ring", "jetty"], "sources": ["metabase:sfacbf36d3c3a", "metabase:s6a973772ebe5", "metabase:sefe4e2a91acd", "metabase:s58ab8269b060", "ring:s0455b1b1fb12", "jetty:s8f9e4989175e"], "status": "REASONED"},
    "metabase-image": {"text": "Image exports MB_JETTY_HOST=0.0.0.0 when unset/empty; publish 127.0.0.1:3000:3000 before first start.", "components": ["metabase", "docker"], "sources": ["metabase:s40c188997580", "metabase:s83a1fd1e4dd6", "docker:s1e53417c513d"], "status": "REASONED"},
    "metabase-port": {"text": "Port defaults 3000 unless the final MB_JETTY_PORT is nonblank.", "components": ["metabase"], "sources": ["metabase:sdc9a71065756", "metabase:sc404f3a2e81b", "metabase:sfacbf36d3c3a"], "status": "REASONED"},
    "metabase-sharing": {"text": "Public links/embeds default enabled and expose view-only question/dashboard/document results without login; disable unneeded sharing.", "components": ["metabase-docs"], "sources": ["metabase-docs:s521b3063e9f0"], "status": "REASONED"},
    "metabase-embed": {"text": "Public embed URLs are recoverable; embeds do not strengthen the public-link boundary.", "components": ["metabase-docs"], "sources": ["metabase-docs:s521b3063e9f0"], "status": "REASONED"},
    "metabase-sandbox": {"text": "Row/column security is Pro/Enterprise; free-tier sharing exposes the rows/columns the question queries.", "components": ["metabase-docs"], "sources": ["metabase-docs:s02b7797b6ffe"], "status": "REASONED"},
    "superset-secret": {"text": "Set a unique complex random SECRET_KEY before exposure; it signs session cookies.", "components": ["superset"], "sources": ["superset:se97be7353585"], "status": "REASONED"},
    "superset-admin": {"text": "Replace the first-run admin password before exposure.", "components": ["superset", "superset-compose"], "sources": ["superset:se97be7353585", "superset-compose:s0ceca7af7f79"], "status": "REASONED"},
    "superset-public": {"text": "Absent AUTH_ROLE_PUBLIC does not prove denial; inspect effective Public-role grants, which provide no data access by default.", "components": ["superset"], "sources": ["superset:se97be7353585"], "status": "REASONED"},
    "superset-copy": {"text": "PUBLIC_ROLE_LIKE copies permissions at superset init; broad roles grant access without scoping datasets/dashboards.", "components": ["superset"], "sources": ["superset:se97be7353585"], "status": "REASONED"},
    "superset-compose": {"text": "Example Compose is unsupported for production; use unique passwords/SECRET_KEY, not the example against production data.", "components": ["superset-compose"], "sources": ["superset-compose:s0ceca7af7f79"], "status": "REASONED"},
    "redash-setup": {"text": "Create the first-run admin before others reach setup.", "components": ["redash-docs"], "sources": ["redash-docs:s4c72252b5447"], "status": "REASONED"},
    "redash-https": {"text": "Enforce HTTPS and the private-access pattern.", "components": ["redash-docs"], "sources": ["redash-docs:s4c72252b5447"], "status": "REASONED"},
    "redash-cookie": {"text": "Use an instance-specific REDASH_COOKIE_SECRET; never commit or reuse it.", "components": ["redash-docs"], "sources": ["redash-docs:sbaf5b44079a0"], "status": "REASONED"},
    "redash-encryption": {"text": "REDASH_SECRET_KEY encrypts data-source credentials; use a strong unique value outside version control.", "components": ["redash-docs"], "sources": ["redash-docs:sbaf5b44079a0"], "status": "REASONED"},
    "redash-bind": {"text": "Default image server uses REDASH_GUNICORN_BIND or [::]:5000 when unset/empty; dual-stack may accept IPv4. Bind/publish privately.", "components": ["redash"], "sources": ["redash:se93d7c47b037", "redash:s9f1ef7237804"], "status": "REASONED"},
    "verify-credentials": {"text": "Confirm no default admin/admin or example credentials work.", "components": ["metabase-docs", "superset-compose", "redash-docs"], "sources": ["metabase-docs:s5e2251b3184d", "superset-compose:s0ceca7af7f79", "redash-docs:s4c72252b5447"], "status": "REASONED"},
    "verify-db": {"text": "Inspect effective/inherited DB grants; confirm reads and denied writes on a disposable object; scope needed write-back separately.", "components": ["metabase-docs"], "sources": ["metabase-docs:s434abdb1aaef"], "status": "REASONED"},
    "verify-listeners": {"text": "Inventory application/proxy sockets and Docker NAT publications; probe direct origins over IPv4/IPv6/LAN/VPC. Absent ss entries do not prove isolation.", "components": ["metabase", "superset-compose", "redash", "docker"], "sources": ["metabase:sdc9a71065756", "superset-compose:s0ceca7af7f79", "redash:se93d7c47b037", "docker:s1e53417c513d"], "status": "REASONED"},
    "verify-ports": {"text": "Verify lists Metabase/Superset/Redash defaults 3000/8088/5000, qualified as install-dependent.", "components": ["metabase", "superset-compose", "redash"], "sources": ["metabase:sdc9a71065756", "superset-compose:s0ceca7af7f79", "redash:se93d7c47b037"], "status": "REASONED"},
    "verify-data": {"text": "Authorized data is the control; anonymous data fails. Denial/verified login challenge passes; SPA shells, 404/errors and arbitrary redirects are inconclusive.", "components": ["metabase-docs", "superset", "redash-docs"], "sources": ["metabase-docs:s521b3063e9f0", "superset:se97be7353585", "redash-docs:s4c72252b5447"], "status": "REASONED", "verify": [1]},
    "verify-private": {"text": "For tunnel-only access, confirm public isolation separately and test authorization on the permitted private path.", "components": ["redash-docs", "docker"], "sources": ["redash-docs:s4c72252b5447", "docker:s1e53417c513d"], "status": "REASONED", "verify": [1]}
  }
}
````
<!-- version-basis:end -->
