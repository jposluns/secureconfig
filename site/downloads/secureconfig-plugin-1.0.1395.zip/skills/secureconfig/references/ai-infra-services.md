# AI infrastructure services: SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0, and Onyx

SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 and Onyx are building blocks for AI apps, from web search to agent memory. This guide helps your AI assistant configure each securely, including authenticated TLS ingress, built-in login or keys enabled where available, and unpublished backing services, apart from deliberate loopback access.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/ai-infra-services.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against SearxNG documentation (no recorded version), TEI HTTP source v1.9.0, Onyx v4.3 source v4.3.13, Onyx v4.4 source v4.4.0, Onyx v4.5 source v4.5.0, Onyx v4.9 source v4.9.2 and v4.9.4, and GNU grep 3.12; 7 further sources are pinned to a commit and 6 carry no recorded version. Metadata reviewed 2026-10-20; documentation checked September 2026. The guide records 53 claims: 1 demonstrated by a check that ran; 52 reasoned from cited sources and any earlier-form run (not a live demonstration of the shipped form).

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

These services expose search, inference, embeddings, document access, or an agent's memory. Their authentication stories differ: SearxNG and LangServe require a fronting layer or application authentication, LocalAI and Text Embeddings Inference each have a key that is unset by default, and Mem0 and Onyx ship authentication on. The deployment command decides what the network sees. Mem0's Compose file and Onyx's development Compose publish backing services beside the authenticated application, where application login cannot protect them.

Keep the application and its backing services private, publish only an authenticated TLS ingress, and keep or enable native authentication wherever it exists.

## Deployment forms and controls

Defaults below describe the vendor examples checked on 2026-09-13. A **host publication** is Docker's mapping, not the application's own listening address. The listed ports are an inventory of those examples; inspect the running deployment for additions and changed host ports.

| Tool and launch form | Default listener or host publication | Authentication by default | Also published beside it | Bind or publication control | Authentication control |
| --- | --- | --- | --- | --- | --- |
| SearxNG, direct | Application: `127.0.0.1:8888` | None | No container publication in this form | `server.bind_address` and `server.port` in `settings.yml` | [Front it](fronting-auth.md) |
| SearxNG, documented Docker run | All host interfaces, `8888:8080` | None | No other mapping in the cited run | Replace with `127.0.0.1:8888:8080`, or publish nothing | [Front it](fronting-auth.md) |
| LocalAI, documented Docker run | All host interfaces, `8080:8080` | Off: native key is unset | No additional publications established by the verified record | Replace with `127.0.0.1:8080:8080`, or publish nothing | Set `LOCALAI_API_KEY`; `LOCALAI_AUTH=true` enables multi-user OAuth with per-user keys |
| Text Embeddings Inference, documented Docker run | All host interfaces, `8080:80` | Partial: `--api-key` / `API_KEY` is unset by default, and even when set it covers the inference routes only | On the same port, outside the key: `/`, `/health`, `/ping`, `/metrics`, `/docs`, `/api-doc/openapi.json` (in the documented HTTP build `/metrics` is served on this main port; `--prometheus-port`, default `9000`, starts a separate exporter only in the gRPC build) | Replace with `127.0.0.1:8080:80`, or publish nothing | Set `--api-key` or `API_KEY`, and front the service, because the key alone leaves the routes above open |
| LangServe, quickstart | Application: `localhost:8000` | None supplied; the application author provides authentication | No container publication in this form | `host=` in `uvicorn.run` | FastAPI dependencies, or [front it](fronting-auth.md) |
| Mem0, server Compose | Application: `0.0.0.0:8000` inside the container; all host interfaces, `8888:8000` | On: bearer JWT, per-user `X-API-Key`, or legacy admin key | PostgreSQL `8432:5432`; dashboard `3000:3000`, both on all host interfaces | Remove PostgreSQL's publication; remove or loopback-scope API and dashboard mappings | Keep authentication enabled; do not set `AUTH_DISABLED=true` |
| Onyx, production Compose | nginx host publications `80:80` and `443:443` | On: email/password | Backing services have no host publications | Keep backing services unpublished; configure the intended TLS ingress | Keep the built-in login; this guide infers from the v4.3.13 and v4.4.0 tag trees that `AUTH_TYPE` no longer selects runtime authentication in v4.4.0, apart from two one-time legacy imports (the SSO provider migration's Google or OIDC row and the startup SAML import) |
| Onyx, development Compose | nginx `80:80` and `3000:80` from the base file, plus API `8080:8080` from the override; all on every host interface | On at the application | PostgreSQL `5432:5432`, OpenSearch `9200:9200`, inference `9000:9000`, Redis `6379:6379`, MinIO `9004:9000` and `9005:9001`, code interpreter `8000:8000` | Use production Compose, or remove every unnecessary publication from the effective configuration | Application authentication is on; it does not reach the backing ports |

## 1. Bind privately, including every container publication

For a process running directly on the host, bind it to loopback explicitly. SearxNG already defaults to `127.0.0.1`, but LocalAI defaults to `:8080` and Text Embeddings Inference to `0.0.0.0:3000`, so bind those yourself: LocalAI `LOCALAI_ADDRESS=127.0.0.1:8080` (or `--address`), TEI `--hostname 127.0.0.1` with the intended `--port` (its CLI port default `3000` is distinct from the container port `80`). SearxNG's settings belong under `server:` in `settings.yml`:

```yaml
server:
  bind_address: "127.0.0.1"
  port: 8888
```

LangServe's quickstart uses:

```python
uvicorn.run(app, host="localhost", port=8000)
```

For containers, remove host publications when the proxy reaches the application over a private container network. Where a proxy running on the host needs a published backend port, use the loopback mapping in the table. Replace the existing mapping; adding another mapping does not remove the original.

A container's loopback address belongs to that container. Do not change its application bind to `127.0.0.1` and expect another container to reach it. Restrict the host publication, or leave the service unpublished on the network shared with its proxy.

Docker publications without a host IP expose the port on all host interfaces. On Linux, Docker's forwarding rules can bypass the chains used by UFW; a UFW deny is not a substitute for removing the publication ([docker.md](docker.md)).

Compose overrides need particular care. An ordinary `ports:` list can merge with the base list and retain the public mapping. Edit the base mapping, or use Compose's documented `!reset` mechanism to remove the list. For example, an override for Mem0 can remove PostgreSQL's publication:

```yaml
services:
  postgres:
    ports: !reset []
```

This removes only PostgreSQL's publication. The API and dashboard still need the treatment described below. Include the override in the actual deployment invocation, and inspect the merged configuration and running publications using Verify check 2. If the installed Compose rejects `!reset`, edit the base file instead; do not replace it with an ordinary empty list and assume the publication disappeared.

## 2. Put TLS and authentication at the ingress

Use [nginx.md](nginx.md), [caddy.md](caddy.md), or [traefik.md](traefik.md) for TLS. The proxy reaches loopback when it runs on the host, or the application's service address when both run on a private container network. Only the intended ingress receives public traffic.

For human access, add the login and identity policy in [fronting-auth.md](fronting-auth.md). For machine clients, enforce a credential at the proxy, such as the bearer-token pattern in [ollama.md](ollama.md). Protect every route that reaches the service's capabilities; a login page on the UI does not establish protection of the API.

A private route through [tailscale.md](tailscale.md) or an authenticated tunnel through [cloudflare.md](cloudflare.md) is another option. A tunnel still needs an access policy.

Onyx's production Compose publishes only nginx. That establishes the intended publication boundary; it does not, by itself, demonstrate a working certificate or the deployed access policy.

## 3. Auth absent or unset

### SearxNG

The direct configuration binds loopback, but the documented Docker command publishes `8888:8080` without a host IP. Use `127.0.0.1:8888:8080` behind a host proxy, or remove the publication behind a containerized proxy.

SearxNG has no authentication in the verified configuration. Put access control in front of it. An open search service lets other people make search requests through your deployment.

Set a unique `server.secret_key` (environment `SEARXNG_SECRET`): it is a cryptographic secret, not user authentication, and SearxNG exits at startup in production rather than run with the shipped `ultrasecretkey` placeholder. SearxNG also fetches remote URLs server-side and its image proxy follows redirects, so it is an SSRF vector: keep it behind the fronting auth and restrict its outbound reach so a search or image fetch cannot be steered at your internal services or the cloud metadata address ([egress-metadata.md](egress-metadata.md)).

### LocalAI

LocalAI has native authentication; the documented deployment leaves it off unless configured. Set a strong, unique value in the service's runtime environment:

```dotenv
LOCALAI_API_KEY=REPLACE_WITH_LONG_RANDOM_KEY
```

For multi-user OAuth and per-user keys, the documented control is:

```dotenv
LOCALAI_AUTH=true
```

Use the vendor's multi-user setup instructions when choosing that mode. Keep authentication at the ingress as well, and replace the documented `8080:8080` publication with the private arrangement in section 1.

### Text Embeddings Inference

The documented Docker run publishes host port 8080 to container port 80. Replace `8080:80` with `127.0.0.1:8080:80` behind a host proxy, or publish nothing behind a containerized proxy.

There is a native inbound control, and it is off until you set it. The CLI reference documents `--api-key`, with the environment variable `API_KEY`. With no key set the server responds to every request; with one set, a request must carry the key as a bearer token in the `Authorization` header. Set it, and front the service as well, because one static key is not a user model.

The key does not cover the whole port. In the HTTP server the key middleware is applied to the inference routes alone, and the health routes `/`, `/health` and `/ping`, the Prometheus route `/metrics`, and the OpenAPI surface `/docs` and `/api-doc/openapi.json` are merged into the same application beside that layer rather than beneath it. They answer anonymously on the published port with a key set. Read `/metrics` yourself before deciding that is acceptable: it reports model identity and request volumes. Checked against v1.9.0; treat it as version-specific and re-read for your own version.

Two defaults compound it. `--hostname` defaults to `0.0.0.0`, so the process listens on every interface inside its namespace and the publication alone decides what reaches it. In the documented HTTP build `/metrics` is served on the main application port, not on a separate listener (the `--prometheus-port` default `9000` starts a standalone exporter only in the gRPC build), so publishing the main port publishes `/metrics` with it; do not rely on leaving `9000` unpublished to hide it. Confirm which build you run before deciding either is closed.

Do not assume a token used to download a model authenticates incoming embedding requests.

### LangServe

Lifecycle note, as of September 2026: LangServe was deprecated on 2024-11-18. Its README recommends LangGraph Platform for new projects. Existing deployments still need these controls while they remain in service.

Keep the quickstart's loopback bind. LangServe makes the application author responsible for authentication, with FastAPI dependencies as the documented integration point. Implement that authentication or put the complete service behind an authenticating proxy, including callable routes.

## 4. A guarded front door with the backing store published beside it

Mem0 and Onyx's development Compose share this shape. The application has a real authentication gate, but a connection to the database, index, cache, or object-store port never passes through that gate.

A PostgreSQL password prompt does not fix this deployment boundary. The database remains reachable independently of the application. Remove its host publication and retain the database's own authentication as a separate control.

### Mem0

Keep authentication on. Protected API endpoints accept a bearer JWT from the dashboard login flow or an `X-API-Key` header. Per-user keys have the `m0sk_` prefix; the legacy `ADMIN_API_KEY` is also supported. Do not leave `AUTH_DISABLED=true` in a deployed environment. The server logs a warning at startup when it is enabled, and a different one when authentication is on and a NON-EMPTY `ADMIN_API_KEY` is shorter than 16 characters; an unset key takes a third branch of its own. The two are alternatives on one `if`/`elif`, so enabling `AUTH_DISABLED` suppresses the short-key warning rather than adding to it, and neither stops the start.

`JWT_SECRET` is not optional, and the server enforces it: with authentication on and no secret set it raises at startup and refuses to run. The documented `server/.env` sets it beside `OPENAI_API_KEY`, generated with `openssl rand -base64 48`, and the JWTs that carry a dashboard session are signed with it. Note what that enforcement implies: the only way to start this server without a signing secret is to turn authentication off altogether.

Register the first admin before the deployment is reachable from anywhere but the host. `POST /auth/register` succeeds only while no user exists and returns `403` afterwards, so an instance published before that call hands admin to whoever finds it first. Bootstrap it on the host, either with `make bootstrap` from `server/`, which starts Compose, creates the admin, and issues the first API key, or through the setup wizard while the dashboard is still host-only. The `/` redirect, `/docs`, and `/openapi.json` stay open in every configuration, so reaching one of those proves nothing about the protected endpoints.

The server Compose publishes three services:

- API: host 8888 to container 8000.
- PostgreSQL: host 8432 to container 5432.
- Dashboard: host 3000 to container 3000.

Remove PostgreSQL's host publication. For a host proxy, replace the API and dashboard mappings with `127.0.0.1:8888:8000` and `127.0.0.1:3000:3000`. For a containerized proxy, leave both unpublished and connect the proxy to their private network.

The dashboard's own authentication coverage is **unverified here**. Give it its own protected ingress route; the API's authentication does not establish the dashboard's policy.

The cited Compose command runs uvicorn with `--host 0.0.0.0 --port 8000 --reload`. `--reload` is a development-server flag. Remove it from a production invocation and retain the network restrictions above.

### Onyx

Use `deployment/docker_compose/docker-compose.prod.yml` as the production deployment basis. In the verified file, only nginx publishes host ports; the backing services stay on the Docker network.

The first user to sign up becomes an admin. Complete that sign-up while the deployment is still reachable only from the host, because until it happens the login page is an admin-enrolment form for whoever reaches it first.

`docker-compose.dev.yml` is an override, not a standalone file. Its own header gives the launch form as `docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d --wait`, so the effective configuration is the base file plus the override, and the base file publishes nginx on `${HOST_PORT_80:-80}:80` and `${HOST_PORT:-3000}:80`. Enumerate the merged result, not the override alone: an inventory taken from the override misses two published ports.

If the development file is running, remove the API publication and every backing publication listed in the table, except any deliberately retained loopback access. The six backing services account for seven host ports because MinIO publishes both its API and console. The API's 8080 publication is additional, and nginx's two come from the base file.

The development mappings include expressions such as `${POSTGRES_HOST_PORT:-5432}:5432`. Setting `POSTGRES_HOST_PORT` changes the host port. Leaving it empty selects the default. Neither action removes the publication. The same trap appears in Dify's plugin-daemon mapping in [agent-builders.md](agent-builders.md).

Email/password authentication is already enabled. This guide infers from the v4.3.13 and v4.4.0 tag trees that `AUTH_TYPE` no longer selects runtime authentication in v4.4.0, apart from two one-time legacy imports that can add login providers; v4.4.0 still reads legacy values for migrations, a one-time legacy SAML import at startup, and a stale-value warning. Read as source, the SSO provider migration can insert an enabled Google or OIDC provider row, and the startup SAML import can add a SAML provider row, enabled by the model's default; at v4.4.0 `main.py` always mounts the OIDC and SAML routers that serve enabled provider rows. The version identity rests on the tag names, since neither cited web package manifest records its tag's release version.

The basic authentication page, fetched on 2026-11-04, says: "The `AUTH_TYPE` environment variable is no longer used. Onyx ignores it and logs a warning at startup." It goes on: "Remove it from your deployment. SSO is configured in the admin panel, not with `AUTH_TYPE`." The page shows no date and names no version. As fetched in October 2026, the page said instead that since `v4.4.0` the variable "is inert and it is planned for full removal in `v4.5`". Because the page names no version, this guide does not apply "Onyx ignores it" to the v4.5.0 and v4.9.2 tags, where, read as source below, the two helpers and the two legacy migrations still read `AUTH_TYPE`. At v4.5.0 and at v4.9.2, the production environment template heads its commented legacy pre-v4.4 SSO block, which lists `AUTH_TYPE`, with "Planned for removal in v4.5." The v4.4.0 release notes list `feat(auth): remove AUTH_TYPE and the AuthType enum, serve multi_tenant`. None of these records that the full removal planned for v4.5 was carried out. Nor do the release notes of the 48 stable releases from v4.5.0 to v5.0.0 that the GitHub release list fetched on 2026-10-25 names: read as documentation, none of them records `AUTH_TYPE` or a legacy SSO variable as removed, so a removal record is not found in that scope on 2026-10-25. The v4.5.0 notes list `chore(deployment): stop advertising env-based SSO setup in templates and installers`, which this guide reads as a template and installer change, not a removal record. The documentation site's index pages, the other part of that scope, were searched on 2026-11-04 for `AUTH_TYPE`, `OAUTH_CLIENT_ID`, `OAUTH_CLIENT_SECRET`, `OPENID_CONFIG_URL` and `SAML_CONF_DIR`. The pages searched were `llms.txt`, the sitemap, the changelog page titled "Release Notes" that the v5.0.0 GitHub release notes link, and the release process page that both index pages list. The `llms-full.txt` export fetched that day holds the 3 migration pages that `llms.txt` lists, on the document index, the object store and permissions, and none of them names any of those variables. Of the pages searched, only the changelog's v4.4.0 entry, dated July 21st, 2026, says "`AUTH_TYPE` has been removed", adding that `AUTH_TYPE` and the legacy SSO variables "are now inert and only emit a startup warning". No changelog entry from v4.5.0, dated August 4th, 2026, to v5.0.0, dated October 23rd, 2026, names any of those variables or records the full removal planned for v4.5. Nor do `llms.txt`, the sitemap and the release process page record a removal, so a documentation index record of the full removal planned for v4.5 is not found in that scope on 2026-11-04. In the same export, the configuration page calls the variable inert and says "Planned for full removal in `v4.5`.", and the upgrade sections of the Google OAuth, OIDC and SAML pages tell readers to remove `AUTH_TYPE` from their deployment. Those sections say that "Onyx logs a warning while `AUTH_TYPE` is still set", and this guide reads them, with the configuration page, as a plan and deployment steps, not a removal record.

At v4.5.0 and v4.9.2, `main.py` still calls `verify_auth_setting()` under a comment describing a warning on stale `AUTH_TYPE` values, and calls `seed_saml_provider_from_conf_dir(db_session)` at startup inside `if not MULTI_TENANT`; its comment describes a legacy SAML import that is a no-op unless `AUTH_TYPE=saml` with no SAML row yet. Read as source, `main.py` is byte-identical at v4.9.2, v4.9.3 and v4.9.4, so both calls, their comments and the router mounting cited below are unchanged at v4.9.4, the newest stable release tag reviewed here. This guide therefore assesses that those legacy startup calls were not removed in any of v4.5.0, v4.9.2, v4.9.3 and v4.9.4; the call sites and comments do not establish runtime authentication selection or the helpers' complete behaviour. These citations are pinned to the commits that the v4.5.0, v4.9.2 and v4.9.4 tags resolved to.

The tag list fetched on 2026-10-24 has no stable tag after v4.9.4; it has v5.0.0 pre-release tags up to v5.0.0-beta.3 and no v5.0.0. The GitHub release list fetched on 2026-10-25 names a stable v5.0.0, published at 2026-10-24T06:46:01Z, whose source this guide has not reviewed. This guide does not treat a beta as a release, so v4.9.4 stays its newest reviewed release. Read as source for comparison only, v5.0.0-beta.3 keeps the same warning call, the same startup SAML import call and comment inside `if not MULTI_TENANT`, the same two helper bodies and the same cited router mounting, at shifted lines in `main.py` and `users.py`. Inside that `if not MULTI_TENANT` block it drops only a telemetry comment and a `get_or_generate_uuid()` call. After that block, where v4.9.4 has a further `if not MULTI_TENANT` block calling `optional_telemetry`, it calls `start_telemetry("api")` instead, and just before the cited routers it adds two `/oauth-provider` routers gated on `OAUTH_PROVIDER_SETTINGS`, which this guide has not reviewed. This guide therefore assesses that the beta changes nothing stated here about the cited calls, helpers and routers.

The helper bodies at the v4.5.0 and v4.9.2 commits, read as source without an Onyx run, behave as follows. `verify_auth_setting()` logs a warning when `AUTH_TYPE` is `disabled`, another when it is `google_oauth`, `oidc` or `saml`, and then a notice naming the mode as `cloud` or `basic` from `MULTI_TENANT`; it contains no `raise` and returns no value. `seed_saml_provider_from_conf_dir` returns early in multi-tenant mode, when `AUTH_TYPE` is not `saml`, when a SAML provider row already exists, and when `SAML_CONF_DIR/settings.json` cannot be read, is not valid JSON or lacks the required IdP values or the SP entity ID. Otherwise it creates one SAML provider row from that file, adding `certs/sp.key` when it can be read, and catches only `IntegrityError` from that call. In the fetched repository, both function bodies are identical at v4.4.0, v4.5.0 and v4.9.2, and in a later fetch `users.py` and `sso_provider.py` are byte-identical at v4.9.2, v4.9.3 and v4.9.4.

Read as source at v4.9.2 to v4.9.4 without an Onyx run, the seed's row creation validates the provider name, which the seed fixes as the valid slug `saml`, and validates the config against the SAML config model, raising `ValueError` when either check fails. The seed has already required that model's four required fields as nonempty strings, and beside them it passes only the model's optional `sp_x509_cert`, when `settings.json` gives it as a nonempty string, and `sp_private_key`, when `certs/sp.key` is read and nonempty; whether any value it passes can still fail the model's string validation depends on pydantic, whose source was not read. The seed catches neither that `ValueError` nor any database error other than `IntegrityError`, and its `certs/sp.key` read, which runs before the required-value check, catches only `OSError`, so a key file that is not UTF-8 raises `UnicodeDecodeError` there. Any of these exceptions passes out of the startup database session block and ends the base `lifespan` startup hook in `main.py` before it yields. What the ASGI server then does, and whether a given legacy file stops a deployment's startup, has not been observed. With EE on, `main.py` can take `get_application` from `ee.onyx.main`, whose `main.py` the paragraph below reads as source at v4.5.0 and v4.9.2. Read as source, EE is on by default: `utils/variable_functionality.py` turns it on when `LICENSE_ENFORCEMENT_ENABLED` is unset, which it treats as `true`, or is `true` in any letter case. This guide therefore assesses that a deployment that keeps that default may run the EE path. Read as source at v4.9.2 to v4.9.4, where `backend/ee/onyx/main.py` is byte-identical in the fetched files, the EE `lifespan` enters the base `lifespan` before its own `yield`, so in this guide's inference these seed errors end the EE startup hook too.

Extending the v4.4.0 inference to these tags, as source reading and this guide's inference rather than an observed deployment: a case-sensitive search for `AUTH_TYPE` in the `backend` and `web` trees at the v4.5.0 and v4.9.2 commits finds it read only by the two helpers and the two legacy migrations, and otherwise only in comments, tests and a test README. In the fetched repository, the two migration files are byte-identical to the v4.4.0 files cited above. At both tags `main.py` mounts the password login routers "in every deployment mode", gates only the env-credential Google login routers, web and mobile, on configured OAuth credentials, and always mounts the SAML and OIDC routers that serve provider rows. Read as source, `AUTH_TYPE` can still add login providers through two one-time legacy imports. When the SSO provider migration creates the provider table in single-tenant mode, it inserts an enabled Google or OIDC provider row if `AUTH_TYPE` is `google_oauth` (or `oidc` with `OPENID_CONFIG_URL` set), OAuth credentials are configured and the new table is still empty. The always-mounted OIDC router serves that row. The startup SAML import can add a SAML provider row, enabled by the model's default, that the always-mounted SAML router serves. Read as source at both commits, `backend/ee/onyx/main.py`, which both recursive trees list, contains no `AUTH_TYPE`; its `lifespan` runs the base hook through `async with lifespan_base(app):` before its own `seed_db()` and `yield`, and its `get_application` calls `get_application_base(lifespan_override=lifespan)`. It mounts a Google OAuth login router at `/auth/oauth`, built from `OAUTH_CLIENT_ID` and `OAUTH_CLIENT_SECRET`, only when `MULTI_TENANT` is set; the other routers it mounts, including `ee_oauth_router` and the SCIM router, were not read. A case-sensitive string search of every file in `backend/ee` at both commits, 208 files at v4.5.0 and 239 at v4.9.2, finds no `AUTH_TYPE`; it is a string search, not a reading of each file. A case-insensitive search of the same files finds one match, line 90 of `backend/ee/onyx/server/scim/api.py` at v4.9.2, which is an unrelated `auth_type` keyword argument to an audit actor, not the environment variable. The case-sensitive `backend` search cited above therefore has the same result whether or not it covered `backend/ee`. Read as source, `main.py`, whose cited v4.9.4 factory uses `lifespan_override` when a caller passes it, and `backend/ee/onyx/main.py` are each byte-identical in the fetched files at v4.9.2, v4.9.3 and v4.9.4. In this guide's inference, an EE deployment at those three tags therefore runs the base startup calls and router mounting cited here, and an exception that ends the base `lifespan` before it yields ends the EE one too, which narrows runtime selection without settling it. The v4.5.0 base factory is not cited, so this inference is not extended to v4.5.0. Apart from these imports, `AUTH_TYPE` does not select runtime authentication at v4.5.0 or v4.9.2; that conclusion is this guide's inference, and deployed selection at those tags has not been observed.

This guide's advice: do not set `AUTH_TYPE` expecting to change authentication.

The Docker documentation also describes access at `localhost:3000`. That is now established from the base Compose file rather than inferred: host 3000 maps to nginx's container port 80, and `web_server` carries no host publication of its own. So `localhost:3000` reaches nginx, not the web process directly, and the web process is not separately published.

For backing-service controls, see [postgresql.md](postgresql.md), [redis.md](redis.md), [minio.md](minio.md), and the OpenSearch material in [elasticsearch.md](elasticsearch.md). Those controls complement removing unnecessary publications.

Onyx also stores the credentials for each document-source connector you add through its UI (a retained `credential_json` per connector), so those are protected stored data, not just runtime configuration: give each connector the least privilege its source allows, protect the database and its backups where the credentials live, and rotate a connector's credential if the instance was ever exposed.

## 5. MFA and secrets

Enforce MFA for human access through the identity provider or fronting layer ([mfa.md](mfa.md), [fronting-auth.md](fronting-auth.md)). Native MFA coverage for these six services is **unverified here**; this guide relies on the fronting policy.

Machine clients need separate credentials, with the narrowest permissions the application or gateway supports. Keep provider keys, service keys, and signing secrets out of source control and images; supply them at runtime per [secrets.md](secrets.md). A provider credential used by the application is not an inbound access control.

## Verify

REASONED: Verify overview and the historical run record, per the guide's cited SearxNG server settings, LocalAI getting started, Text Embeddings Inference CLI arguments, LangServe README at commit `27e57af`, Mem0 REST API, Onyx basic authentication, Docker packet filtering and firewalls, Docker Compose ps, curl manual and GNU grep 3.12 manual, exit status (checked October 2026). The GNU manual documents statuses 0 for a selected line, 1 for no selected lines and 2 for an error; the house runs observed statuses in Bash, dash and BusyBox ash and did not record which grep implementation or version ran. In local marking review (October 2026, Bash 5.3.9), bash -n and ShellCheck 0.11.0 on check 1 exited 0 without output; a placeholder fixture was recorded with `grep_exit=0`, a clean fixture printed `grep_exit=1`, and a missing fixture printed `grep_exit=2`. Bash, dash and BusyBox ash, with and without `set -u`, printed the token and `grep_exit=0` for the exposed fixture and `grep_exit=1` for the fixed fixture. Check 2 bash -n and ShellCheck 0.11.0 exited 0 without output; stub ss printed `-tlnp`, and stub docker printed `compose config` and `compose ps --format json`. Those check 2 runs covered an earlier form of that block, which ran its three commands at top level and ended with the last command's status; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, which runs them in a subshell and exits with status 3 when one fails or the running inventory lists no service, otherwise 2 when `ss` is not installed, else 0. On 2026-10-31 the current form of check 2 also passed bash -n and ShellCheck 0.11.0 and ran whole against stub `ss` and `docker` with no network, with `ss` present and passing, present and failing, and missing; no live run of it is recorded. In dash and BusyBox ash, checks 6 and 7 printed `run this block in bash; not probing` with and without exported `BASH_VERSION`, with trap diagnostics on stderr and no curl stub call. Stubbed checks 3 to 7 printed `not probing` for empty or placeholder values and `STUB curl` or `STUB nc` for substituted values. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expected exposed outcomes are an anonymous protected response or a reachable direct port; fixed outcomes are anonymous rejection or direct refusal, with application output through a configured authorized ingress when valid credentials are used. Bash check 1 wrong-marker and short-count fixtures printed `paste the whole block, including its set -- line; not checking` and `the set -- line needs exactly 1 value; not checking`; its filename-placeholder fixture printed `substitute the file name on the set -- line above; not checking` and exited 1. A direct grep of a fixture printed `<fixture path>:2:REPLACE_WITH_TOKEN`. These local runs establish guard and placeholder-scan behaviour only; none establishes live service behaviour. An external vantage, TLS exchange, configured authorized ingress and valid credentials were not tested; their availability is unknown, so the positive control remains an expectation, not an observation. **Demonstration status:** the placeholder guards and the placeholder-scan discrimination were exercised locally, in `bash`, `dash` and BusyBox `ash`, with and without `set -u`. Check 7's five-value guard, changed in #475, was exercised in `bash` on 2026-10-13 (UTC) against a stub curl: one and two headers reached curl only on stdin, and a line feed, carriage return or placeholder in either header was refused before any curl call; it was not re-run in `dash` or BusyBox `ash`. Check 6's slice guard, added in #478, was exercised on 2026-10-13 (UTC) against a stub curl: `bash` reached the stub unchanged, and `dash` and BusyBox `ash` printed "run this block in bash; not probing" before any curl call, with and without `BASH_VERSION` exported; in those shells checks 6 and 7 now stop at that guard before their placeholder guards run. Every bash -n, ShellCheck, fixture and stub run recorded in this overview for checks 1 and 3 to 7 covered an earlier form of those blocks, in which every guard refusal ended with status 0 except the placeholder refusals of checks 1 and 3, which exited with status 1. The gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, in which every guard refusal exits with status 2, and no fixture, stub or live run of it is recorded. That earlier form also ended with status 0 after check 1's scan and check 4's probe, whatever they found; the current form exits with status 1 after a check 1 placeholder match or a check 4 completed connection, and check 1 exits with status 3 after a read error. Checks 2 to 7 below are **reasoned rather than demonstrated** against deployments. Historical authoring note: the authoring environment had no container runtime, and with it no live service, no external network vantage, no TLS exchange and no browser authentication flow. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. The maintainer's verified vendor record supplies the deployment facts, and each check below states the outcome it expects in both the exposed and the fixed state.

REASONED: Complete-block copy and guard guidance, per the guide's cited curl manual and Docker packet filtering and firewalls. In local marking review (October 2026, Bash 5.3.9), the single-quoted `$(printf SHOULD_NOT_RUN)` value appeared literally in the stub curl URL; the empty, placeholder, wrong-marker and short-count cases in checks 3 to 7 printed `not probing` before any stub call, while substituted values printed `STUB curl` or `STUB nc`. The stub runs recorded here covered checks 3 to 7 in an earlier form, in which every guard refusal ended with status 0 except the check 3 placeholder refusal, which exited with status 1; none was re-run on the current form, in which every guard refusal exits with status 2. The run did not test a deployed service or a pasted fragment below the guard. An external vantage, TLS exchange, configured authorized ingress and valid credentials were not tested; their availability is unknown. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. An exposed direct port is expected to answer, while a fixed direct port is expected to refuse; the authorized ingress control requires a configured route and valid credentials and was not run. Use Bash for these blocks and curl 7.75.0 or newer for `exitcode` and `errormsg`. Copy each complete block, including the enclosing parentheses. The values go on the `set --` line, so no named variable is exposed to attributes or values the reader's shell already holds, and every probe sits behind a guard that leaves the subshell rather than running on an unsubstituted value. Substitute inside the single quotes and leave them in place. They are what keeps a URL's `&` from backgrounding the line and a `$(...)` or a backtick in a pasted value from running: the shell evaluates that value before any guard in the block can see it. Keep the quotes even for an empty value, and paste every block whole. Each block opens with a fixed marker on its `set --` line, and the guard lines below check that marker and count the values, so a fragment that keeps those lines but drops or shortens the `set --` line stops instead of running on whatever arguments your own shell already held. A fragment pasted from below the guard lines is not guarded at all, which is why the instruction is to paste whole blocks. One case is beyond a pasted block's reach: a shell that already holds the marker and the right number of plausible values is indistinguishable from the block having set them, so paste whole blocks rather than relying on the check to catch every way of not doing so.

### 1. Reject unfinished configuration and probe values

REASONED: For each configuration or environment file you edited, the expected matched, clean and error statuses follow GNU grep 3.12 manual, exit status (checked October 2026); the local marking review (October 2026, Bash 5.3.9) recorded the check 1 fixture outputs in the Verify overview. The recorded runs used an earlier form of check 1, whose marker and count refusals and completed scans ended with status 0 and whose filename-placeholder refusal exited with status 1. The current form, whose guard refusals all exit with status 2 and which exits with status 1 after a placeholder match, 0 after a clean scan and 3 after a read error, has not been run. The cited manual documents GNU grep; the house runs did not record which grep implementation or version ran. Any other status (2 in GNU grep; greater than 2 in other implementations, per the same entry) is inconclusive. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Run this for each configuration or environment file you edited:

DEMONSTRATED: following block; placeholder-scan expectations follow GNU grep 3.12 manual, exit status (checked October 2026), and the recorded local exercise. Local marking review (October 2026, Bash 5.3.9) output is recorded in the Verify overview; the grep version in those house runs remains unknown. In a renewed local marking review (October 2026), Bash 5.3.9, dash and BusyBox ash 1.37.0 ran the whole block against a stub grep and fixtures. In each shell, wrong-marker and missing-set-line cases printed `paste the whole block, including its set -- line; not checking` and exited 0; short-count and long-count cases printed `the set -- line needs exactly 1 value; not checking` and exited 0; placeholder and empty filename cases printed `substitute the file name on the set -- line above; not checking` and exited 1. The renewed runs covered check 1 in an earlier form, whose marker and count refusals and completed scans ended with status 0 and whose filename-placeholder refusal exited with status 1. None was re-run on the current form, whose guard refusals all exit with status 2 and which exits with status 1 after a placeholder match, 0 after a clean scan and 3 after a read error. In each shell, the exposed fixture printed `exposed.conf:2:REPLACE_WITH_TOKEN` then `grep_exit=0` and exited 0; the clean fixture printed only `grep_exit=1` and exited 0; the missing-file fixture printed `grep: missing.conf: No such file or directory` then `grep_exit=2` and exited 0. The stub supplied the grep outputs and statuses; these renewed runs establish shell control flow, while the earlier recorded fixture runs establish the exposed and clean scan observations in all three shells and the missing-file status in Bash.

```bash
(                              # a subshell, so your own script arguments are untouched
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_EDITED_CONFIG_FILE'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not checking"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not checking"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|"") echo "substitute the file name on the set -- line above; not checking"; exit 2 ;;
    *) if grep -nH -o 'REPLACE_WITH_[[:alnum:]_]*' -- "$1"; then set -- "$1" 0; else set -- "$1" "$?"; fi   # grep's status, held as the 2nd value rather than in a named variable
       printf 'grep_exit=%s\n' "$2"
       # Status: 1 when a placeholder matched, 0 for a clean scan, 3 for a read error.
       case "$2" in 0) exit 1 ;; 1) exit 0 ;; *) exit 3 ;; esac ;;
  esac
)
```

DEMONSTRATED: Check 1 exposed fixture and unchanged filename guard, per the recorded local marking review (October 2026, Bash 5.3.9) in the Verify overview and renewed local marking review (October 2026, Bash 5.3.9, dash and BusyBox ash 1.37.0) (stub grep; shell control flow only): Bash, dash and BusyBox ash each printed the token and `grep_exit=0` for an exposed fixture. The same local marking reviews (stub grep; shell control flow only) record that a direct grep of a fixture printed `<fixture path>:2:REPLACE_WITH_TOKEN`; the filename and line in dash and BusyBox ash came only from the stub grep. The same local marking reviews (stub grep; shell control flow only) record that Bash, dash and BusyBox ash each printed `substitute the file name on the set -- line above; not checking` for the unchanged filename. The recorded runs used an earlier form of check 1, whose marker and count refusals and completed scans ended with status 0 and whose filename-placeholder refusal exited with status 1. The current form, whose guard refusals all exit with status 2 and which exits with status 1 after a placeholder match, 0 after a clean scan and 3 after a read error, has not been run. GNU grep 3.12 manual, exit status (checked October 2026) documents the match status. The house runs did not record which grep implementation or version ran. **Broken:** unresolved values print their filename, line number, and placeholder token, followed by `grep_exit=0`, and the block exits with status 1. Stop and replace them. An unchanged filename placeholder prints `substitute the file name on the set -- line above; not checking`.

DEMONSTRATED: Check 1 fixed and unreadable fixture outcomes, per the recorded local marking review (October 2026, Bash 5.3.9) in the Verify overview and renewed local marking review (October 2026, Bash 5.3.9, dash and BusyBox ash 1.37.0) (stub grep; shell control flow only): Bash, dash and BusyBox ash each printed only `grep_exit=1` for a clean fixture. The same local marking reviews (stub grep; shell control flow only) record that Bash printed `grep_exit=2` for a missing fixture, and dash and BusyBox ash reached the same `grep_exit=2` path only with a stub grep. The recorded runs used an earlier form of check 1, whose marker and count refusals and completed scans ended with status 0 and whose filename-placeholder refusal exited with status 1. The current form, whose guard refusals all exit with status 2 and which exits with status 1 after a placeholder match, 0 after a clean scan and 3 after a read error, has not been run. GNU grep 3.12 manual, exit status (checked October 2026) documents no-match and error statuses. The house runs did not record which grep implementation or version ran. **Fixed:** no placeholder matches print, followed by `grep_exit=1`, and the block exits with status 0. A file-read error is inconclusive, not a clean scan, and the block exits with status 3. This check prints only the matched placeholder tokens, rather than complete secret-bearing lines.

REASONED: Address and request guard behaviour in checks 3 to 7, per the guide's cited curl manual and Docker packet filtering and firewalls. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics for each of checks 3 to 7. In local marking review (October 2026, Bash 5.3.9), runs of each block printed `not probing` for empty and `REPLACE_WITH_` values before any stub call; substituted values printed `STUB curl` in checks 3, 5, 6 and 7 and `STUB nc` in check 4. Wrong markers printed `paste the whole block, including its set -- line; not probing`; short counts printed `the set -- line needs exactly 2 values; not probing` in checks 3 and 4, with 3, 4 or 5 values respectively in checks 5, 6 and 7. The bash -n, ShellCheck and stub runs recorded here covered checks 3 to 7 in an earlier form, in which every guard refusal ended with status 0 except the check 3 placeholder refusal, which exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, in which every guard refusal exits with status 2, and no fixture, stub or live run of it is recorded. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expected exposure is a direct answer; a fixed direct path refuses, per the guide's cited Docker packet filtering and firewalls. An external vantage, TLS exchange, authorized ingress and valid credentials were not checked; their availability is unknown. These guards are prerequisites, not deployment evidence. The address guards below likewise print `not probing` when required values are empty or still contain `REPLACE_WITH_`. Substituted values enter the probe arm. This is a prerequisite, not evidence that the deployment is private.

### 2. Inventory listeners, the merged Compose model, and running publications (REASONED: Listener and publication inventory, per the guide's cited Docker packet filtering and firewalls, Compose networking, Compose merge rules and Docker Compose ps. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. Stub ss and docker printed their invocations; no live inventory or real Compose JSON shape was observed. Those runs covered an earlier form that ran the three commands at top level; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, which exits with status 3 when one fails or the running inventory lists no service, otherwise 2 when `ss` is not installed, else 0. On 2026-10-31 the current form also passed bash -n and ShellCheck 0.11.0 and ran whole against stub `ss` and `docker` with no network, with `ss` present and passing, present and failing, and missing; no live run of it is recorded. Historical authoring note: no container runtime was available. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expect unintended listeners or publications when exposed, and only intended ingress or loopback publications when fixed; errors and empty inventories remain inconclusive.)

**Reasoned, not demonstrated** (historical authoring note: no container runtime in the authoring environment). Run on the deployment host. For Compose, use the exact project, file selection, overrides, environment, and profiles used to start the deployment. Add those same options to these commands where needed. What makes an inventory readable rather than guesswork is documented: Compose ps reports the running publication fields, Compose merge rules govern how an override's port list combines with the base, and Compose networking establishes that services reach each other with no host publication at all; all three are in Sources:

```bash
(                              # a subshell, so the exit below ends only the subshell
  set -- 0                     # the block's status so far: 3 (a command failed or the inventory is empty), else 2 (ss is not installed), else 0
  if command -v ss >/dev/null; then   # a missing ss refuses this part with status 2
    if ss -tlnp; then :; else echo "ss -tlnp exit $?: the listener list is missing or incomplete; inconclusive"; set -- 3; fi
  else
    echo "ss is not installed here; not listing sockets"; set -- 2
  fi
  if docker compose config; then :; else echo "docker compose config exit $?: no merged model to compare; inconclusive"; set -- 3; fi
  set -- "$1" "$(if docker compose ps --format json; then printf ' 0'; else printf ' %s' "$?"; fi)"   # the status so far, then the running publications, a space and ps's exit status
  printf '%s' "${2% *}"
  # Status: 3 when a command fails or the running inventory lists no service (no JSON object); otherwise 2 when ss is not installed, else 0.
  case "${2##* }:${2% *}" in
    0:*'{'*) ;;
    0:*) echo "docker compose ps listed no running service, and an empty inventory is not a pass; inconclusive"; set -- 3 ;;
    *) echo "docker compose ps exit ${2##* }: no running inventory; inconclusive"; set -- 3 ;;
  esac
  echo "block exit $1; the listeners, the merged model and the running publications above are not classified, so judge them against Broken and Fixed below"
  exit "$1"
)
```

**Broken:** `ss` shows an application or backing listener on a wildcard or non-loopback host address; the merged Compose model retains an unwanted host publication; or the running service has a `Publishers` entry mapping it to an unintended host address and port.

**Fixed:** host application listeners are loopback-only; backing services have no host publications; any retained application publications are loopback-only; only the intended ingress is public. The running publications agree with the merged model.

Read the whole listener list, including IPv6 and listeners bound to a specific LAN address. Public SSH or other unrelated services are outside this guide's acceptance decision.

A Docker publication implemented through DNAT may not appear in host `ss` output. Read the actual host mappings in `Publishers`, including `PublishedPort`, rather than counting entries: a container port listed without a host publication is not the same thing. The real JSON output shape was not demonstrated here.

A Compose error, missing service, stopped application, or empty inventory is not a pass. `docker compose config` describes the intended configuration; it does not prove running containers were recreated with it. Its output can contain secrets, so inspect it privately.

### 3. Probe the application's direct ports from another host (REASONED: Direct HTTP reachability, per the guide's cited curl manual and Docker packet filtering and firewalls. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. Local placeholder, empty-value, wrong-marker and short-count fixtures printed not probing before any stub call; substituted values reached the stub. The bash -n, ShellCheck and fixture runs recorded here covered check 3 in an earlier form, whose marker and count refusals ended with status 0 and whose placeholder refusal exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals all exit with status 2, and no fixture, stub or live run of it is recorded. Historical authoring note: no container runtime or second host was available. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expect an HTTP response or completed connection when exposed, and refusal corroborated by inventory and working ingress when fixed; timeout or http=000 alone is inconclusive.)

**Reasoned, not demonstrated, including the cross-host vantage** (historical authoring note: no container runtime and no second host in the authoring environment). Probe every application or dashboard port found in check 2, using its actual host port. Include reachable LAN addresses and public IPv4/IPv6 addresses; bracket an IPv6 literal used in the HTTP URL. Exclude the intentionally public TLS ingress. The outcomes below rest on two sources: the curl manual for what its exit status, error text and timing actually report, and Docker's packet-filtering page for how a published port interacts with a host firewall, which is what makes a refusal meaningful rather than incidental.

```bash
# Direct HTTP reachability, per the guide's cited curl manual and Docker packet filtering and firewalls. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. Local placeholder, empty-value, wrong-marker and short-count fixtures printed not probing before any stub call; substituted values reached the stub. The bash -n, ShellCheck and fixture runs recorded here covered check 3 in an earlier form, whose marker and count refusals ended with status 0 and whose placeholder refusal exited with status 1; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals all exit with status 2, and no fixture, stub or live run of it is recorded. Historical authoring note: no container runtime or second host was available. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expect an HTTP response or completed connection when exposed, and refusal corroborated by inventory and working ingress when fixed; timeout or http=000 alone is inconclusive.
(                              # a subshell, so your own script arguments are untouched
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_HOST_ADDRESS' 'REPLACE_WITH_PORT'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1:$2" in
    *REPLACE_WITH_*|:*|*:) echo "substitute the address and port on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- "$(if curl -q -g -sS -o /dev/null --noproxy '*' --connect-timeout 5 --max-time 20 \
      -w 'http=%{http_code} exit=%{exitcode} remote=%{remote_ip} time_connect=%{time_connect} err=%{errormsg}\n' \
      "http://$1:$2/"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  set -- "${1% *}" "${1##* }"    # curl's write-out line, then its exit status, held as values rather than in named variables
  printf '%s' "$1"
  # Status: 1 for any HTTP answer or a completed TCP connection; 0 when the connection failed before TCP
  # completed (curl exit 7), which check 2 and the working ingress in check 7 must still corroborate; otherwise 3.
  case "$1" in
    "http=000 "*" time_connect=0.000000 "*) ;;
    "http=000 "*) echo "FINDING: a TCP connection completed without an HTTP answer (an empty reply, reset or timeout), so the direct path exists"; exit 1 ;;
    "http="???" "*) echo "FINDING: the direct port answered over HTTP, so the direct path exists"; exit 1 ;;
    *) echo "curl exit $2 printed no write-out line; inconclusive"; exit 3 ;;
  esac
  case "$2" in
    7) echo "the connection failed before TCP completed (curl exit 7), consistent with a refusal; corroborate it with check 2 and the working ingress in check 7"; exit 0 ;;
    *) echo "curl exit $2 before any TCP connection formed (a timeout, or a name or local error); inconclusive"; exit 3 ;;
  esac
)
```

**Broken:** any HTTP response, including `401`, proves the direct path exists. A completed TCP connection followed by an empty response, reset, or timeout also fails the private-network requirement.

**Fixed:** the connection to your actual backend address and port is refused, corroborated by check 2 and the working ingress in check 7.

A timeout alone is inconclusive. `http=000` can occur after a server accepts and stalls. Read `err`, `remote`, and `time_connect`; corroborate a connection timeout with the running publication inventory and evidence at the filtering point. DNS failures, local socket errors, or a test aimed at the wrong address never establish a block. Use check 4 as well to test TCP reachability independently of HTTP.

### 4. Probe every backing port (REASONED: Backing-port reachability and the example publication inventory, per the guide's cited Docker packet filtering and firewalls, Docker Compose ps, Mem0 server Compose, Onyx development Compose and Onyx base Compose. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. Local placeholder, empty-value, wrong-marker and short-count fixtures printed not probing before any stub call; substituted values reached the stub. The successful nc stub printed its arguments and exit=0. The bash -n, ShellCheck, fixture and stub runs recorded here covered check 4 in an earlier form, whose guard refusals and completed connections ended with status 0; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2 and which exits with status 1 after a completed connection, and no fixture, stub or live run of it is recorded. Historical authoring note: no container runtime or external vantage was available. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expect a completed connection when exposed and corroborated refusal when fixed; option errors, timeout and silence are inconclusive.)

**Reasoned, not demonstrated** (historical authoring note: no container runtime in the authoring environment). From another host, run this for every private port found in check 2, including the application's ports from check 3. The distinguishing authority here is the publication state, read together with the firewall configuration, per Docker's packet-filtering page and Compose ps in Sources: under Docker's default firewall integration a backing service with no host publication is not reachable from another host, so a refusal corroborated by check 2 means the boundary holds. That page also states the limit of the guarantee: with Docker's firewalling disabled and no replacement rules, every container port becomes accessible, published or not, so an unpublished port is evidence of the boundary only while that integration is in place. An answer from any of these ports means the boundary does not hold.

For the unchanged vendor examples, Mem0 adds 8432 and 3000 beside API port 8888. Onyx development adds 5432, 9200, 9000, 6379, 9004, 9005, and 8000 beside API port 8080, and nginx contributes 80 and 3000 from the base file. Environment variables can move these ports; the running inventory is the authority.

```bash
(                              # a subshell, so your own script arguments are untouched
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_HOST_ADDRESS' 'REPLACE_WITH_PORT'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  if [ -z "$1" ] || [ -z "$2" ]; then echo "substitute the address and port on the set -- line above; not probing"; exit 2; fi
  case "$1:$2" in
    *REPLACE_WITH_*) echo "substitute the address and port on the set -- line above; not probing"; exit 2 ;;
  esac
  set -- "$(if nc -vz -w 5 "$1" "$2" 2>&1; then printf ' 0'; else printf ' %s' "$?"; fi)"   # netcat's messages, then its exit status
  set -- "${1% *}" "${1##* }"
  printf '%s' "$1"
  printf 'exit=%s\n' "$2"
  # Status: 1 when the connection completed; 3 when netcat reports a timeout for any address; 0 when it reports
  # a refused connection, which check 2 must still corroborate; otherwise 3, as for a name or option error or silence.
  case "$2:$1" in
    0:*) echo "FINDING: the connection completed, so this port is reachable from here"; exit 1 ;;
    *:*"timed out"*) echo "netcat exit $2 after a timeout, which is not a refusal; inconclusive"; exit 3 ;;
    *:*"onnection refused"*) echo "netcat reported the connection refused; confirm the private publication state with check 2"; exit 0 ;;
    *) echo "netcat exit $2 without a reported refusal (a timeout, a name or option error, or silence); inconclusive"; exit 3 ;;
  esac
)
```

**Broken:** netcat reports a successful connection and `exit=0`, and the block exits with status 1. A database password prompt or a service that sends nothing after accepting does not change that result.

REASONED: netcat status classification, from the messages netcat prints, which the block expects to contain the words connection refused for a refusal and timed out for a timeout; that wording was not checked against a netcat manual or run here, so a refusal worded differently gets status 3, never 0, and a timeout worded differently gets 3 only when no address reports a refusal. **Fixed:** netcat reports connection refused to your actual address and port, with a nonzero exit status, and check 2 confirms the private publication state. The block exits with status 0 only when netcat's output names a refused connection and no timeout, and with status 3 for any other nonzero netcat status, including the inconclusive cases below, so a status of 0 still needs check 2's corroboration.

A timeout remains inconclusive without corroborating configuration and filtering evidence. Unsupported options, name-resolution failures, local errors, or unexplained silence are not passes. In particular, BusyBox netcat may reject `-v`; use an implementation supporting these options.

### 5. Require authentication at the ingress (REASONED: Ingress authentication and route coverage, per the guide's cited curl manual, LocalAI getting started, Text Embeddings Inference CLI arguments, Text Embeddings Inference HTTP server at v1.9.0, Mem0 REST API and Onyx basic authentication. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. Local placeholder, empty-value, wrong-marker and short-count fixtures printed not probing before any stub call; substituted values reached the stub. Wrong schemes printed use a https:// URL; not probing. Body and no-body requests reached stub curl; Python parsed the probe JSON as an inputs string. The bash -n, ShellCheck, fixture and stub runs recorded here covered check 5 in an earlier form, whose guard refusals ended with status 0; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. Historical authoring note: no container runtime or live ingress was available. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expect protected output for an exposed anonymous caller, and rejection or the configured sign-in redirect when fixed, paired with authorized application output; errors and generic pages are inconclusive.)

**Reasoned, not demonstrated** (historical authoring note: no container runtime in the authoring environment). Select a harmless request to a real protected capability. Its path, method, request body, and exact response for each installed tool are **unverified here**. Obtain them from that version's documentation and use the same request in check 7. What separates the exposed outcome from the fixed one is documented per service in Sources: Text Embeddings Inference answers every request until `--api-key` is set, LocalAI's key is unset by default, and Mem0 and Onyx both ship authentication on, so an anonymous `2xx` from any of them is the exposed state and a `401` or `403` is the fixed one. For example, Text Embeddings Inference's protected capability is `POST /embed` with the harmless body `{"inputs":"probe"}`: expect a `401` without the key and a `2xx` embedding with it (check 7).

Do not choose a health endpoint, documentation page, login page, or an invented path. A `404` or request-validation error cannot demonstrate authentication.

Test the ingress and the native layer as SEPARATE controls. Where a service's native key does not cover every route (Text Embeddings Inference leaves `/metrics`, `/docs` and the health routes outside it), also probe one of those uncovered routes anonymously THROUGH the public ingress: the fronting auth must gate it, so an anonymous `2xx` there is a finding even when the capability route is protected. Where the ingress and the application use different credentials, send the application's own credential WITHOUT the ingress credential and confirm the ingress still rejects it, so a keyed backend behind a TLS-only proxy cannot pass this check while the ingress itself is open.

Set the second value on the `set --` line to the actual method, such as `GET` or `POST`. Keep the third value's empty quotes for a request without a body; otherwise put a harmless JSON test body there.

```bash
(                              # a subshell, so your own script arguments are untouched
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_PROTECTED_URL' 'REPLACE_WITH_HTTP_METHOD' ''
  # $3 is the harmless JSON request body. Keep the empty quotes if the request needs none.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 3 ] || { echo "the set -- line needs exactly 3 values; not probing"; exit 2; }
  if [ -z "$1" ] || [ -z "$2" ]; then
    echo "fill in the URL and method on the set -- line above; not probing"; exit 2
  fi
  case "$1$2$3" in
    *REPLACE_WITH_*) echo "substitute the request values on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$1" in
    https://*) ;;
    *) echo "use a https:// URL; not probing"; exit 2 ;;
  esac
  if [ -n "$3" ]; then
    set -- -H 'Content-Type: application/json' --data-binary "$3" -X "$2" "$1"
  else
    set -- -X "$2" "$1"
  fi
  set -- "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 \
    -D - -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "$@"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  set -- "${1% *}" "${1##* }"            # the headers, body and write-out line, then curl's exit status
  printf '%s' "$1"
  set -- "$1" "$2" "${1##*http=}"        # the text after the last http=, which starts with the HTTP code
  # Status: 1 for an anonymous 2xx; 0 for a 401 or 403, and 0 for a redirect you judge from its Location
  # header; otherwise 3, as for a TLS, connection, 5xx, routing or validation error.
  case "$3" in
    2??" "*) echo "FINDING: the anonymous request got HTTP ${3%% *} through the ingress"; exit 1 ;;
    401" "*|403" "*) echo "the anonymous request was rejected with HTTP ${3%% *}; check 7 must still succeed for the authorized caller"; exit 0 ;;
    3??" "*) echo "unclassified observation: HTTP ${3%% *} is a redirect, which passes only when the Location header above names your configured identity service"; exit 0 ;;
    *) echo "curl exit $2 with HTTP ${3%% *} is not an authentication result; inconclusive"; exit 3 ;;
  esac
)
```

**Broken:** the anonymous request returns application data or performs the capability, typically with a `2xx` status.

**Fixed:** the request receives an authentication rejection, normally `401` or `403`, or an interactive sign-in redirect whose `Location` identifies the configured identity service. Check 7 must then succeed for the authorized caller.

A redirect alone is insufficient: inspect its destination. Do not follow it automatically and mistake a `200` login page for application access. TLS, connection, `5xx`, routing, and validation errors are inconclusive. Certificate verification stays enabled.

### 6. Exercise the capability without native credentials (REASONED: Native authentication, its limits and the private positive control, per the guide's cited curl manual, LocalAI getting started, Text Embeddings Inference CLI arguments, Text Embeddings Inference HTTP server at v1.9.0, Mem0 REST API and Onyx basic authentication, SearxNG server settings and LangServe README at commit `27e57af`. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. Local placeholder, empty-value, wrong-marker and short-count fixtures printed not probing before any stub call; substituted values reached the stub. Body and no-body requests reached stub curl; anonymous requests omitted credentials and wrong or fixture headers reached only stdin. LF and CR headers printed put the credential header on one line; not probing; invalid schemes were refused. The bash -n, ShellCheck, fixture and stub runs recorded here covered check 6 in an earlier form, whose guard refusals ended with status 0; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. Historical authoring note: no container runtime or live service was available. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expect protected output without credentials when exposed; when fixed, the same request rejects empty and wrong credentials and returns real output with valid credentials. Stub calls do not establish authentication.)

**Reasoned, not demonstrated** (historical authoring note: no container runtime in the authoring environment). For LocalAI or Text Embeddings Inference with a key set, Mem0, Onyx, or LangServe with application authentication, run the same harmless protected request against the private upstream from a trusted location that can reach it. Do not publish a port to perform this check. The same per-service passages in Sources supply the expected outcomes as in check 5, and one of them bounds this check rather than supporting it: the Text Embeddings Inference server source shows its key middleware covering the inference routes only, so an anonymous answer from `/metrics`, `/health` or `/docs` is not evidence that the key is unset.

For SearxNG, for LangServe relying entirely on its proxy, or for any service you have deliberately left unauthenticated on the private side, run this capability check through the authenticated HTTPS ingress. An intentionally unauthenticated private upstream cannot demonstrate native authentication.

```bash
(                              # a subshell, so your own script arguments are untouched
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  ( set -- a b c d e f g; [ "$(printf '%s,' "${@:5}")" = 'e,f,g,' ] ) 2>/dev/null || { echo "run this block in bash; not probing"; exit 2; }  # dash and ash mishandle "${@:5}"
  # When you repeat this block with a valid credential header in $4, the secret
  # on the set -- line enters shell history; clear that history line afterward.
  # Stdin closes the argv channel only: it does not hide the header from set -x
  # tracing or your own account's view of the process.
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_PROTECTED_URL' 'REPLACE_WITH_HTTP_METHOD' '' '' 'REPLACE_WITH_anonymous_wrong_OR_valid'
  # $3 is the same harmless JSON body as checks 5 and 7 (keep the empty quotes if none is needed).
  # $4 is a credential header: leave it EMPTY for the anonymous run, put a WRONG credential for the
  # wrong-key run, and the VALID one for the positive control. Run this block three times against the
  # SAME private URL; the native layer must reject the first two and serve the third.
  # $5 names the run: anonymous, wrong or valid.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 5 ] || { echo "the set -- line needs exactly 5 values; not probing"; exit 2; }
  if [ -z "$1" ] || [ -z "$2" ]; then
    echo "fill in the URL and method on the set -- line above; not probing"; exit 2
  fi
  case "$1$2$3$4" in
    *REPLACE_WITH_*) echo "substitute the request values on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$1" in
    http://*|https://*) ;;
    *) echo "use an http:// or https:// URL; not probing"; exit 2 ;;
  esac
  case "$4" in
    *[[:cntrl:]]*) echo "put the credential header on one line; not probing"; exit 2 ;;
  esac
  case "$5:$4" in
    anonymous:|wrong:?*|valid:?*) ;;
    *) echo "set the fifth value to anonymous with an empty header, or to wrong or valid with a header; not probing"; exit 2 ;;
  esac
  # Body options, if any, go after the five values. The credential header ($4) reaches curl on stdin
  # (--header @-), never in its argv, where ps and /proc/<pid>/cmdline would show it.
  if [ -n "$3" ]; then set -- "$@" -H 'Content-Type: application/json' --data-binary "$3"; fi
  if [ -n "$4" ]; then
    set -- "$5" "$(if printf '%s\n' "$4" | curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 --header @- \
      -D - -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "${@:6}" -X "$2" "$1"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  else
    set -- "$5" "$(if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 \
      -D - -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "${@:6}" -X "$2" "$1"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  fi
  set -- "$1" "${2% *}" "${2##* }"       # the run, the response with its write-out line, then curl's exit status
  printf '%s' "$2"
  set -- "$1" "$3" "${2##*http=}"        # the run, curl's exit status, then the text after the last http=, which starts with the HTTP code
  # Status: for the anonymous and wrong runs, 1 for a 2xx and 0 for a 401 or 403; for the valid run, 0 for a
  # 2xx whose body you still read; otherwise 3, because an unreachable upstream, unknown path, malformed
  # request or unavailable model tests nothing.
  case "$1:${3%% *}" in
    anonymous:2??|wrong:2??) echo "FINDING: the $1 run got HTTP ${3%% *}, so the native layer served it"; exit 1 ;;
    anonymous:401|anonymous:403|wrong:401|wrong:403) echo "the $1 run was rejected with HTTP ${3%% *}; the valid run must still get a 2xx"; exit 0 ;;
    valid:2??) echo "the valid run got HTTP ${3%% *}; read the body above to confirm it is real output, not a generic page"; exit 0 ;;
    *) echo "curl exit $2 with HTTP ${3%% *} is not a result the $1 run classifies; inconclusive"; exit 3 ;;
  esac
)
```

**Broken:** the unauthenticated caller receives protected data or successfully invokes the capability.

**Fixed:** the configured authentication layer rejects that same valid request, while check 7 succeeds with credentials.

REASONED: native-gate run sequence and statuses, per the guide's cited LocalAI getting started, Text Embeddings Inference CLI arguments, Mem0 REST API and Onyx basic authentication; not run against a deployment. An unreachable upstream means native authentication was not tested; it does not prove that authentication works. Likewise, an unknown path, malformed request, or unavailable model does not demonstrate rejection of an anonymous caller. Run the block three times against the SAME private URL, varying only `$4` and the run name in `$5`: empty with `anonymous`, a deliberately WRONG credential with `wrong`, then the VALID one with `valid`. The native layer must reject the first two and serve the third; that valid-credential run is the positive control on the private backend, so the three together (anonymous reject, wrong-key reject, valid-key accept) establish the native gate rather than a coincidental error. The block exits with status 1 when the anonymous or wrong run gets a `2xx`, with 0 when either gets `401` or `403` or when the valid run gets a `2xx` whose body you still read, and with 3 otherwise. Check 7 is the separate success test through the HTTPS ingress.

Mem0 and Onyx ship authentication on, but the verified record does not establish the exact response code for a selected endpoint. Investigate a successful anonymous Mem0 request for `AUTH_DISABLED=true`, route coverage, and the running version; the response alone does not identify its cause.

### 7. Prove the protected service still works

REASONED: Credentialed HTTPS success and header transport, per the guide's cited curl manual, LocalAI getting started, Text Embeddings Inference CLI arguments, Text Embeddings Inference HTTP server at v1.9.0, Mem0 REST API and Onyx basic authentication. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. Placeholder, empty-value, marker, count and scheme fixtures stopped before stub curl; body and no-body requests reached it. One and two fixture headers appeared only on stdin; LF, CR and placeholders in either header were refused before a stub call. The bash -n, ShellCheck, fixture and stub runs recorded here covered check 7 in an earlier form, whose guard refusals ended with status 0; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. Historical authoring note: no container runtime, TLS exchange or browser flow was available. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expect anonymous rejection paired with authorized application output when fixed; success alone, errors and login pages cannot establish protection. Stub calls do not establish authentication. **Reasoned, not demonstrated** (historical authoring note: no container runtime in the authoring environment). Repeat the capability request through the HTTPS ingress with valid credentials. Keep its method, path, and body the same as the anonymous test, allowing only the expected upstream-to-ingress URL change. The credential shapes this check needs are documented in Sources: Mem0 accepts a JWT or an `X-API-Key`, Onyx uses its email and password session, LocalAI and Text Embeddings Inference take their configured key, and a guide that cannot show this check succeeding has not established that the restriction left a working service behind.

REASONED: Credentialed HTTPS success and header transport, per the guide's cited curl manual, LocalAI getting started, Text Embeddings Inference CLI arguments, Text Embeddings Inference HTTP server at v1.9.0, Mem0 REST API and Onyx basic authentication. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. Placeholder, empty-value, marker, count and scheme fixtures stopped before stub curl; body and no-body requests reached it. One and two fixture headers appeared only on stdin; LF, CR and placeholders in either header were refused before a stub call. The bash -n, ShellCheck, fixture and stub runs recorded here covered check 7 in an earlier form, whose guard refusals ended with status 0; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. Historical authoring note: no container runtime, TLS exchange or browser flow was available. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expect anonymous rejection paired with authorized application output when fixed; success alone, errors and login pages cannot establish protection. Stub calls do not establish authentication. The header below is reader-supplied. For a configured bearer-token proxy it is `Authorization: Bearer` followed by the token. Mem0 accepts its native per-user key through `X-API-Key`, or a JWT through `Authorization: Bearer`. Other native credential transports are **unverified in the supplied record**. Where ingress and application require separate credentials, send both headers on curl's stdin: `--header @-` reads one header per line, so pipe both lines to it under the same control-character guard, and never pass a credential header with `-H`, which puts it in curl's argv.

REASONED: following block; Credentialed HTTPS success and header transport, per the guide's cited curl manual, LocalAI getting started, Text Embeddings Inference CLI arguments, Text Embeddings Inference HTTP server at v1.9.0, Mem0 REST API and Onyx basic authentication. Bash 5.3.9 bash -n and ShellCheck 0.11.0 exited 0 without diagnostics. Placeholder, empty-value, marker, count and scheme fixtures stopped before stub curl; body and no-body requests reached it. One and two fixture headers appeared only on stdin; LF, CR and placeholders in either header were refused before a stub call. The bash -n, ShellCheck, fixture and stub runs recorded here covered check 7 in an earlier form, whose guard refusals ended with status 0; the gate suite's bash -n and ShellCheck 0.11.0 passes cover the current form, whose guard refusals exit with status 2, and no fixture, stub or live run of it is recorded. Historical authoring note: no container runtime, TLS exchange or browser flow was available. A live SearxNG, LocalAI, Text Embeddings Inference, LangServe, Mem0 or Onyx stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Expect anonymous rejection paired with authorized application output when fixed; success alone, errors and login pages cannot establish protection. Stub calls do not establish authentication. **Broken:** both anonymous and credentialed requests return protected data, or the credentialed request cannot reach a working application after the restrictions were applied. Connection failures, `401`/`403`, `5xx`, or a login page in place of the expected result do not establish a working protected service. **Fixed:** the anonymous request is rejected and the following block's credentialed request returns the expected application result, normally `2xx`. A `2xx` alone is insufficient; inspect the body to distinguish application output from a generic page. Credentialed success can also occur on an exposed service. It only completes the verification when the negative checks above pass.

```bash
(                              # a subshell, so your own script arguments are untouched
  trap - DEBUG RETURN ERR  # assumes a clean shell (CONTRIBUTING rule 7): no inherited DEBUG trap, extdebug, function or alias
  ( set -- a b c d e f g; [ "$(printf '%s,' "${@:6}")" = 'f,g,' ] ) 2>/dev/null || { echo "run this block in bash; not probing"; exit 2; }  # dash and ash mishandle "${@:6}"
  # The credentials you substitute on the set -- line enter shell history.
  # Clear that history line afterward.
  # Stdin closes the argv channel only: it does not hide the credentials from
  # set -x tracing or your own account's view of the process.
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_PROTECTED_URL' 'REPLACE_WITH_HTTP_METHOD' '' 'REPLACE_WITH_HEADER_NAME: REPLACE_WITH_CREDENTIAL' ''
  # $3 is the same harmless JSON body as the anonymous check. Keep the empty quotes if none is needed.
  # $5 is an optional second credential header, for an ingress and application that need separate
  # credentials. Keep the empty quotes if one header is enough.
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 5 ] || { echo "the set -- line needs exactly 5 values; not probing"; exit 2; }
  if [ -z "$1" ] || [ -z "$2" ] || [ -z "$4" ]; then
    echo "fill in the URL, method, and header on the set -- line above; not probing"; exit 2
  fi
  case "$1$2$3$4$5" in
    *REPLACE_WITH_*) echo "substitute the request values on the set -- line above; not probing"; exit 2 ;;
  esac
  case "$1" in
    https://*) ;;
    *) echo "use a https:// URL; not probing"; exit 2 ;;
  esac
  case "$4" in
    *[[:cntrl:]]*) echo "put the credential header on one line, and a second header in the fifth value; not probing"; exit 2 ;;
  esac
  case "$5" in
    *[[:cntrl:]]*) echo "put the second credential header on one line; not probing"; exit 2 ;;
  esac
  # Body options, if any, go after the five values. The credential headers ($4, and $5 if set) reach
  # curl on stdin (--header @-, one per line), never in its argv, where ps and /proc/<pid>/cmdline
  # would show them.
  if [ -n "$3" ]; then set -- "$@" -H 'Content-Type: application/json' --data-binary "$3"; fi
  if [ -n "$5" ]; then
    set -- "$(if printf '%s\n' "$4" "$5" | curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 --header @- \
      -D - -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "${@:6}" -X "$2" "$1"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  else
    set -- "$(if printf '%s\n' "$4" | curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 --header @- \
      -D - -w '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' "${@:6}" -X "$2" "$1"; then printf ' 0'; else printf ' %s' "$?"; fi)"
  fi
  set -- "${1% *}" "${1##* }"            # the response with its write-out line, then curl's exit status
  printf '%s' "$1"
  set -- "$1" "$2" "${1##*http=}"        # the text after the last http=, which starts with the HTTP code
  # Status: 0 for a 2xx, whose body you still read; otherwise 3, because a connection failure, 401, 403,
  # 5xx or login redirect does not establish a working protected service.
  case "$3" in
    2??" "*) echo "unclassified observation: HTTP ${3%% *} with credentials; read the body above, which passes only as the expected application output, not a generic page"; exit 0 ;;
    *) echo "curl exit $2 with HTTP ${3%% *}: the credentialed request did not succeed; inconclusive"; exit 3 ;;
  esac
)
```

For browser access, follow the MFA enforcement check in [mfa.md](mfa.md) against a protected operation. **Broken:** the protected operation succeeds with only a password when policy requires a second factor. **Fixed:** the password-only attempt is refused and completing the second factor allows the operation. This browser outcome is reasoned rather than demonstrated here.

If the deployment trusts identity headers from a proxy, follow the direct-origin, header-overwrite and authenticated-through-proxy checks in [fronting-auth.md](fronting-auth.md). **Broken:** a direct forged identity header reaches the app, or a forged trusted header sent through the proxy appears as the forged identity in the app log. **Fixed:** the direct forged-header request is refused at the network boundary; a valid authenticated session reaches the app through the proxy, and the app log shows the real identity after a forged trusted header is sent through it. These identity-header outcomes are reasoned rather than demonstrated here.

## Common mistakes

- Running Onyx's development Compose on an exposed host because its login page works.
- Assuming Mem0's API authentication also protects PostgreSQL or establishes the dashboard's policy.
- Changing a `${VAR:-default}` host port and believing the publication disappeared.
- Adding a loopback mapping through a Compose override while retaining the original public mapping.
- Leaving `AUTH_DISABLED=true` in Mem0 after debugging.
- Setting Onyx's `AUTH_TYPE` and expecting an authentication change; this guide infers from the v4.3.13 and v4.4.0 tag trees that it no longer selects runtime authentication in v4.4.0, apart from two one-time legacy imports (the SSO provider migration's Google or OIDC row and the startup SAML import).
- Leaving LocalAI's native key unset, or mistaking an upstream provider token for inbound authentication.
- Inspecting only `ss`, only IPv4, or only the deployment host's own view.
- Accepting a timeout, an unknown endpoint's `404`, or a credentialed `200` as proof of protection.

## Sources (checked September 2026)

The service facts come from the maintainer's vendor-source verification record dated 2026-09-13. This authoring environment had no network; the pages were not reopened here. Docker and probe syntax also follow the cited sources already recorded in the repository's existing guides.

**Citation pinning:** the LangServe README, Mem0 server, Onyx Compose and Onyx data-model citations below use commit pins, and each commit was opened and confirmed to contain the fact it is cited for. The Onyx v4.5.0, v4.9.2 and v4.9.4 source citations are pinned to the commits those tags resolved to (`055b0c5`, `df49072` and `4cfda3c`) and the Onyx v5.0.0-beta.3 pre-release citations to `55df913`, while the Onyx v4.3.13 and v4.4.0 citations and the Onyx v4.5.0 and v5.0.0 release notes use tags, which are not commit pins, and the Onyx release list is not pinned.

- [SearxNG server settings](https://docs.searxng.org/admin/settings/settings_server.html): `server.bind_address`, `server.port`, and direct defaults.
- [SearxNG Docker installation](https://docs.searxng.org/admin/installation-docker.html): documented `8888:8080` publication.
- [LocalAI getting started](https://localai.io/docs/basics/getting_started/): port 8080, Docker publication, `LOCALAI_API_KEY`, and `LOCALAI_AUTH`.
- [Text Embeddings Inference quick tour](https://huggingface.co/docs/text-embeddings-inference/en/quick_tour): container port 80 and host publication 8080.
- [Text Embeddings Inference CLI arguments](https://huggingface.co/docs/text-embeddings-inference/en/cli_arguments): `--api-key` and `API_KEY`, the default-open behaviour without one, `--hostname` defaulting to `0.0.0.0`, and `--prometheus-port` defaulting to `9000`.
- [Text Embeddings Inference HTTP server at v1.9.0](https://github.com/huggingface/text-embeddings-inference/blob/v1.9.0/router/src/http/server.rs): the key middleware applied to the inference routes only, with the health, `/metrics` and OpenAPI routes merged beside it.
- [LangServe README at commit `27e57af`](https://github.com/langchain-ai/langserve/blob/27e57afeda13007a7f4e007c5d1f5e8489963aa4/README.md): quickstart bind, application authentication responsibility, deprecation on 2024-11-18, and successor.
- [Mem0 REST API](https://docs.mem0.ai/open-source/features/rest-api): authentication enabled by default, JWTs, `X-API-Key`, `m0sk_` keys, `ADMIN_API_KEY`, `AUTH_DISABLED` and its startup warning, `JWT_SECRET`, `make bootstrap`, the first-admin `POST /auth/register`, and the routes that stay open.
- [Mem0 server Compose](https://github.com/mem0ai/mem0/blob/c7ee362aff94a369af70f13f2b4f853f6793ff4c/server/docker-compose.yaml): uvicorn command and API, PostgreSQL, and dashboard publications.
- [Mem0 server `main.py`](https://github.com/mem0ai/mem0/blob/c7ee362aff94a369af70f13f2b4f853f6793ff4c/server/main.py): the startup `raise RuntimeError` when authentication is on and `JWT_SECRET` is unset, and the `if`/`elif` warning branches for `AUTH_DISABLED` and a short `ADMIN_API_KEY`. The REST API page describes the request-time responses; this file is the startup behaviour.
- [Onyx basic authentication](https://docs.onyx.app/deployment/authentication/basic.md): email/password authentication, the first user to sign up becoming an admin, and `AUTH_TYPE`, which the undated page, checked November 2026 (fetched 2026-11-04), says "is no longer used", adding "Onyx ignores it and logs a warning at startup". Rechecked in October 2026, the page said instead that the variable "is inert" and is planned for full removal in `v4.5`.
- [Onyx v4.3.13 authentication configuration](https://github.com/onyx-dot-app/onyx/blob/v4.3.13/backend/onyx/configs/app_configs.py#L133-L142) (checked October 2026): legacy environment selection of authentication.
- [Onyx v4.3.13 authentication routes](https://github.com/onyx-dot-app/onyx/blob/v4.3.13/backend/onyx/main.py#L581-L608) (checked October 2026): legacy environment selection of authentication.
- [Onyx v4.4.0 startup warning](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/main.py#L371-L372) (checked October 2026): startup warning handling of stale `AUTH_TYPE`.
- [Onyx v4.4.0 startup SAML import](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/main.py#L392-L397) (checked October 2026): startup call to import a legacy SAML provider when `AUTH_TYPE=saml`.
- [Onyx v4.4.0 authentication warning](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/auth/users.py#L183-L200) (checked October 2026): legacy migration or startup warning handling of `AUTH_TYPE`.
- [Onyx v4.4.0 SAML provider import](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/db/sso_provider.py#L197-L295) (checked October 2026): one-time legacy SAML import at startup reads `AUTH_TYPE=saml` and can create one SAML provider row from `SAML_CONF_DIR`.
- [Onyx v4.4.0 SSO provider migration](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/alembic/versions/1fc2904131a3_add_sso_provider_table_and_seed_from_env.py#L60-L129) (checked October 2026): legacy migration or startup warning handling of `AUTH_TYPE`, including the one-time legacy provider import, run by `upgrade()` after it creates the table, that can insert an enabled Google or OIDC provider row from `AUTH_TYPE` in single-tenant mode.
- [Onyx v4.4.0 disabled authentication migration](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/alembic/versions/f7ca3e2f45d9_migrate_no_auth_data_to_placeholder.py#L129-L193) (checked October 2026): legacy migration or startup warning handling of `AUTH_TYPE`, including the inactive placeholder-user insert. Its `upgrade()` returns first when `MULTI_TENANT` is set (lines 139 to 140), so the migration inserts only in single-tenant mode.
- [Onyx v4.4.0 authentication routers](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/main.py#L589-L681) (checked October 2026): password login routers mounted in every deployment mode, the env-credential Google login routers, web and mobile, gated on OAuth credentials, and the SAML and OIDC provider-row routers always mounted; source reading, which does not establish deployed authentication selection.
- [Onyx v4.4.0 SSO provider model](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/db/models.py#L6618-L6645) (checked October 2026): the `SSOProvider` model's `enabled` column, which defaults to `True`, so a provider row created without an explicit value is enabled.
- [Onyx v4.4.0 SAML router provider resolution](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/server/saml_multi.py#L102-L140) (checked October 2026): SAML login resolving a provider row by name or by assertion issuer with `enabled_only=True` and accepting only SAML rows; source reading, which does not establish deployed authentication selection.
- [Onyx v4.4.0 OIDC router provider resolution](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/server/oidc_multi.py#L74-L97) (checked October 2026): OAuth and OIDC login resolving a provider row by name with `enabled_only=True` and accepting only `GOOGLE_OAUTH` and `OIDC` rows; source reading, which does not establish deployed authentication selection.
- [Onyx v4.3.13 web package manifest](https://github.com/onyx-dot-app/onyx/blob/v4.3.13/web/package.json#L3) (checked October 2026): `1.0.0-dev` rather than the tag version.
- [Onyx v4.4.0 web package manifest](https://github.com/onyx-dot-app/onyx/blob/v4.4.0/web/package.json#L3) (checked October 2026): `1.0.0-dev` rather than the tag version.
- [Onyx v4.4.0 release notes](https://github.com/onyx-dot-app/onyx/releases/tag/v4.4.0) (checked October 2026): the entry `feat(auth): remove AUTH_TYPE and the AuthType enum, serve multi_tenant`, read from the GitHub API copy of the release.
- [Onyx v4.5.0 release notes](https://github.com/onyx-dot-app/onyx/releases/tag/v4.5.0) (checked October 2026): the entry `chore(deployment): stop advertising env-based SSO setup in templates and installers`, read from the GitHub API copy of the release, published 2026-08-04; no entry records `AUTH_TYPE` or a legacy SSO variable as removed.
- Onyx GitHub release list, [page 1](https://api.github.com/repos/onyx-dot-app/onyx/releases?per_page=100) and [page 2](https://api.github.com/repos/onyx-dot-app/onyx/releases?per_page=100&page=2) (checked October 2026, fetched 2026-10-25): the 48 stable releases from v4.5.0 to v5.0.0, none of whose notes records `AUTH_TYPE` or a legacy SSO variable as removed, and the publication of v5.0.0 at 2026-10-24T06:46:01Z; the list has no release object for v4.6.13, v4.7.12, v4.8.7 or v4.9.3.
- [Onyx v5.0.0 release notes](https://github.com/onyx-dot-app/onyx/releases/tag/v5.0.0) (checked November 2026): a release body, read from the GitHub API copy of the release, that opens with a "Docs" heading whose one line is the address of the Onyx changelog page cited below.
- [Onyx documentation index](https://docs.onyx.app/llms.txt) (checked November 2026, fetched 2026-11-04): lists the changelog as "Release Notes", the release process page and 3 migration pages, on the document index, the object store and permissions. It names none of `AUTH_TYPE`, `OAUTH_CLIENT_ID`, `OAUTH_CLIENT_SECRET`, `OPENID_CONFIG_URL` and `SAML_CONF_DIR`; its one case-insensitive `auth_type` match is the "Get Auth Type" API reference entry.
- [Onyx documentation sitemap](https://docs.onyx.app/sitemap.xml) (checked November 2026, fetched 2026-11-04): lists the changelog, the release process page and the same 3 migration pages. It names none of those 5 variables, and its one case-insensitive `auth_type` match is the Get Auth Type API reference address.
- [Onyx changelog](https://docs.onyx.app/changelog) (checked November 2026, fetched 2026-11-04): the "Release Notes" page, read as served and as its Markdown export. Its v4.4.0 entry, dated July 21st, 2026, says "`AUTH_TYPE` has been removed" and that `AUTH_TYPE` and the legacy SSO variables "are now inert and only emit a startup warning"; no entry from v4.5.0 (August 4th, 2026) to v5.0.0 (October 23rd, 2026) names any of those 5 variables.
- [Onyx release process](https://docs.onyx.app/deployment/miscellaneous/release_process.md) (checked November 2026, fetched 2026-11-04): the release, versioning and update page that `llms.txt` and the sitemap list; it names none of those 5 variables.
- [Onyx full documentation export](https://docs.onyx.app/llms-full.txt) (checked November 2026, fetched 2026-11-04): its copies of the 3 migration pages name none of those 5 variables. Its configuration page says `AUTH_TYPE` is inert and "Planned for full removal in `v4.5`.", and the upgrade sections of its Google OAuth, OIDC and SAML pages say to remove `AUTH_TYPE` from a deployment and that "Onyx logs a warning while `AUTH_TYPE` is still set".
- [Onyx v4.5.0 startup warning](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/main.py#L378-L379) (checked October 2026): `verify_auth_setting()` call with a comment describing stale `AUTH_TYPE` warnings; this call site does not establish runtime authentication selection.
- [Onyx v4.5.0 startup SAML import](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/main.py#L398-L414) (checked October 2026): non-multitenant startup calls the legacy SAML import; its comment says it is a no-op unless `AUTH_TYPE=saml` with no SAML row yet, without establishing the helper's complete behaviour.
- [Onyx v4.9.2 startup warning](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/main.py#L394-L395) (checked October 2026): `verify_auth_setting()` call with a comment describing stale `AUTH_TYPE` warnings; this call site does not establish runtime authentication selection.
- [Onyx v4.9.2 startup SAML import](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/main.py#L414-L432) (checked October 2026): non-multitenant startup calls the legacy SAML import; its comment says it is a no-op unless `AUTH_TYPE=saml` with no SAML row yet, without establishing the helper's complete behaviour.
- [Onyx v4.5.0 production environment template](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/deployment/docker_compose/env.prod.template#L24-L26) (checked October 2026): the commented legacy pre-v4.4 SSO block, starting with `#AUTH_TYPE=`, headed "Planned for removal in v4.5."; the template carries no date beyond its tag commit.
- [Onyx v4.9.2 production environment template](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/deployment/docker_compose/env.prod.template#L24-L26) (checked October 2026): the same commented legacy SSO block and "Planned for removal in v4.5." heading, unchanged at the v4.9.2 commit.
- [Onyx v4.5.0 authentication routers](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/main.py#L611-L703) (checked October 2026): password login routers mounted in every deployment mode, the env-credential Google login routers, web and mobile, gated on OAuth credentials, and the SAML and OIDC provider-row routers always mounted; source reading, which does not establish deployed authentication selection.
- [Onyx v4.9.2 authentication routers](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/main.py#L651-L750) (checked October 2026): the same router mounting as v4.5.0, including the env-credential Google login routers, web and mobile, gated on OAuth credentials, plus an unconditionally mounted SSO discovery router; source reading, which does not establish deployed authentication selection.
- [Onyx v4.5.0 startup warning helper](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/auth/users.py#L184-L203) (checked October 2026): `verify_auth_setting()` logging stale `AUTH_TYPE` warnings and a mode notice from `MULTI_TENANT`, with no `raise` and no return value.
- [Onyx v4.9.2 startup warning helper](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/auth/users.py#L200-L219) (checked October 2026): the same `verify_auth_setting()` body as v4.5.0.
- [Onyx v4.5.0 legacy SAML import helper](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/db/sso_provider.py#L247-L345) (checked October 2026): `seed_saml_provider_from_conf_dir` early returns, the one SAML provider row it creates from `SAML_CONF_DIR`, and its handling of `IntegrityError` only.
- [Onyx v4.9.2 legacy SAML import helper](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/db/sso_provider.py#L300-L398) (checked October 2026): the same `seed_saml_provider_from_conf_dir` body as v4.5.0.
- [Onyx v4.5.0 SSO provider migration](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/alembic/versions/1fc2904131a3_add_sso_provider_table_and_seed_from_env.py#L60-L129) (checked October 2026): the one-time legacy provider import reading `AUTH_TYPE` from `os.environ` at line 79 and, after `upgrade()` creates the table, inserting in single-tenant mode an enabled Google or OIDC provider row when `AUTH_TYPE` is `google_oauth` (or `oidc` with `OPENID_CONFIG_URL` set), OAuth credentials are configured and the table is empty. The migration file, in the fetched repository, is byte-identical at v4.4.0, v4.5.0 and v4.9.2 (checked October 2026).
- [Onyx v4.5.0 disabled authentication migration](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/alembic/versions/f7ca3e2f45d9_migrate_no_auth_data_to_placeholder.py#L129-L193) (checked October 2026): the placeholder-user migration reading `AUTH_TYPE` from `os.environ` at line 144, skipping unless it is `disabled`, `none` or empty, and otherwise, when records without an owning user exist, inserting an inactive placeholder user with an empty password, which its comments say cannot log in. The migration file, in the fetched repository, is byte-identical at v4.4.0, v4.5.0 and v4.9.2 (checked October 2026). Its `upgrade()` returns first when `MULTI_TENANT` is set (lines 139 to 140), before that `AUTH_TYPE` read, so the migration inserts only in single-tenant mode.
- [Onyx v4.9.2 SSO provider migration](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/alembic/versions/1fc2904131a3_add_sso_provider_table_and_seed_from_env.py#L60-L129) (checked October 2026): the same migration file as v4.5.0, with the same `AUTH_TYPE` read at line 79 and the same enabled provider-row insert.
- [Onyx v4.9.2 disabled authentication migration](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/alembic/versions/f7ca3e2f45d9_migrate_no_auth_data_to_placeholder.py#L129-L193) (checked October 2026): the same migration file as v4.5.0, with the same `AUTH_TYPE` read at line 144 and the same inactive placeholder-user insert. Its `upgrade()` also returns first when `MULTI_TENANT` is set (lines 139 to 140), so at v4.9.2 too the migration inserts only in single-tenant mode.
- [Onyx v4.5.0 SSO provider model](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/db/models.py#L6873-L6900) (checked October 2026): the `SSOProvider` model's `enabled` column, which defaults to `True`, so a provider row created without an explicit value is enabled.
- [Onyx v4.9.2 SSO provider model](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/db/models.py#L7490-L7517) (checked October 2026): the same `enabled` default of `True` as v4.5.0.
- [Onyx v4.5.0 SAML router provider resolution](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/server/saml_multi.py#L103-L141) (checked October 2026): SAML login resolving a provider row by name or by assertion issuer with `enabled_only=True` and accepting only SAML rows; source reading, which does not establish deployed authentication selection.
- [Onyx v4.9.2 SAML router provider resolution](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/server/saml_multi.py#L40-L156) (checked October 2026): the same enabled-only SAML provider resolution as v4.5.0, behind a router-wide dependency whose comment says the router is closed on deployments with more than one workspace; source reading, which does not establish deployed authentication selection.
- [Onyx v4.5.0 OIDC router provider resolution](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/server/oidc_multi.py#L74-L97) (checked October 2026): OAuth and OIDC login resolving a provider row by name with `enabled_only=True` and accepting only `GOOGLE_OAUTH` and `OIDC` rows; source reading, which does not establish deployed authentication selection.
- [Onyx v4.9.2 OIDC router provider resolution](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/server/oidc_multi.py#L161-L184) (checked October 2026): the same enabled-only resolution of `GOOGLE_OAUTH` and `OIDC` rows as v4.5.0; source reading, which does not establish deployed authentication selection.
- [Onyx v4.5.0 EE application](https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/ee/onyx/main.py#L42-L129) (checked October 2026): a file with no `AUTH_TYPE`, whose `lifespan` enters the base one with `async with lifespan_base(app):` before `seed_db()` and `yield`, and whose `get_application` passes `lifespan_override=lifespan` to the base factory. It mounts a Google OAuth router at `/auth/oauth` only when `MULTI_TENANT` is set; source reading without an Onyx run.
- [Onyx v4.9.2 EE application](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/ee/onyx/main.py#L43-L130) (checked October 2026): the same `lifespan`, factory call and `MULTI_TENANT`-only Google OAuth router as v4.5.0, in a file that also has no `AUTH_TYPE` and also mounts an LLM gateway router; source reading without an Onyx run.
- [Onyx v4.9.2 SCIM audit actor](https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/ee/onyx/server/scim/api.py#L90) (checked November 2026): `return AuditActor(api_key_id=f"scim_token:{token.id}", auth_type="scim")`, the one case-insensitive `auth_type` match in the v4.9.2 `backend/ee` tree, a keyword argument and not the `AUTH_TYPE` environment variable; source reading without an Onyx run.
- [Onyx v4.9.4 startup warning](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L394-L395) (checked October 2026): the same `verify_auth_setting()` call and comment as v4.9.2; in the fetched repository `main.py` is byte-identical at v4.9.2, v4.9.3 and v4.9.4.
- [Onyx v4.9.4 startup SAML import](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L414-L432) (checked October 2026): the same non-multitenant legacy SAML import call and comment as v4.9.2.
- [Onyx v4.9.4 startup hook yield](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L452-L455) (checked October 2026): the `lifespan` startup hook's `try: yield`, which follows the startup SAML import, so an exception the import does not catch ends the hook before it yields; source reading without an Onyx run.
- [Onyx v4.9.4 authentication routers](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L651-L750) (checked October 2026): the same router mounting as v4.9.2; source reading, which does not establish deployed authentication selection.
- [Onyx v4.9.4 startup warning helper](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/auth/users.py#L200-L219) (checked October 2026): the same `verify_auth_setting()` body as v4.9.2; in the fetched repository `users.py` is byte-identical at v4.9.2, v4.9.3 and v4.9.4.
- [Onyx v4.9.4 legacy SAML import helper](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/db/sso_provider.py#L300-L398) (checked October 2026): the same `seed_saml_provider_from_conf_dir` body as v4.9.2, whose `certs/sp.key` read catches only `OSError` and whose row creation catches only `IntegrityError`; in the fetched repository `sso_provider.py` is byte-identical at v4.9.2, v4.9.3, v4.9.4 and v5.0.0-beta.3.
- [Onyx v4.9.4 SSO provider config models](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/db/sso_provider.py#L28-L82) (checked October 2026): config models that reject unknown keys, and the SAML model's four required string fields (`idp_entity_id`, `idp_sso_url`, `idp_x509_cert` and `sp_entity_id`) beside optional SP and email-attribute fields.
- [Onyx v4.9.4 SSO provider row creation](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/db/sso_provider.py#L132-L256) (checked October 2026): `validate_sso_config` re-raising a pydantic `ValidationError` as `ValueError`, `validate_sso_provider_name` raising `ValueError` for a name that is not a lowercase slug, and `create_sso_provider` running both before it adds and commits the row; source reading without an Onyx run.
- [Onyx v4.9.4 database session helpers](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/db/engine/sql_engine.py#L441-L549) (checked October 2026): `get_session_with_current_tenant` and `get_session_with_tenant` closing the session in `finally` with no `except`, so an exception raised in the startup session block propagates; source reading without an Onyx run.
- [Onyx v4.9.4 startup telemetry](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L434-L438) (checked October 2026): an `if not MULTI_TENANT` block calling `optional_telemetry` with a version record; source reading without an Onyx run.
- [Onyx v4.9.4 application factory](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L534-L549) (checked October 2026): `get_application` creating the FastAPI application with `lifespan=lifespan_override or lifespan`, so its startup hook is `lifespan` unless the caller passes an override; source reading without an Onyx run.
- [Onyx v4.9.4 application export](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L812-L815) (checked October 2026): a module-level `set_is_ee_based_on_env_variable()` call, then `app` taken from `fetch_versioned_implementation(module="onyx.main", attribute="get_application")`; source reading without an Onyx run.
- [Onyx v4.9.4 Enterprise Edition switch](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/utils/variable_functionality.py#L42-L72) (checked October 2026): `LICENSE_ENFORCEMENT_ENABLED` read from the environment with a default of `true`, compared ignoring case. `set_is_ee_based_on_env_variable` then turns Enterprise Edition on when `ENTERPRISE_EDITION_ENABLED` is true or, failing that, when that license value is true; source reading without an Onyx run.
- [Onyx v4.9.4 versioned implementation lookup](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/utils/variable_functionality.py#L100-L127) (checked October 2026): `fetch_versioned_implementation` importing from the `ee.`-prefixed module when Enterprise Edition is on. When that import raises a `ModuleNotFoundError` whose message contains `ee.onyx`, it falls back to the unprefixed module; source reading without an Onyx run.
- [Onyx v4.9.4 EE application lifespan](https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/ee/onyx/main.py#L58-L78) (checked October 2026): `from onyx.main import lifespan as lifespan_base` at line 58, and an EE `lifespan` whose `async with lifespan_base(app):` at line 73 encloses `seed_db()` and its own `yield` at line 78; in the fetched files `backend/ee/onyx/main.py` is byte-identical at v4.9.2, v4.9.3 and v4.9.4. Source reading without an Onyx run.
- [Onyx v5.0.0-beta.3 startup calls](https://github.com/onyx-dot-app/onyx/blob/55df913b37cb9c001a77dd010ff8c6331e70447b/backend/onyx/main.py#L395-L431) (checked October 2026): a pre-release read for comparison only, with the same `verify_auth_setting()` call and the same non-multitenant legacy SAML import call and comment as v4.9.2, at shifted lines, and without the telemetry comment and `get_or_generate_uuid()` call that precede the import at v4.9.2.
- [Onyx v5.0.0-beta.3 authentication routers](https://github.com/onyx-dot-app/onyx/blob/55df913b37cb9c001a77dd010ff8c6331e70447b/backend/onyx/main.py#L659-L758) (checked October 2026): a pre-release read for comparison only, with the v4.9.2 router mounting verbatim.
- [Onyx v5.0.0-beta.3 startup warning helper](https://github.com/onyx-dot-app/onyx/blob/55df913b37cb9c001a77dd010ff8c6331e70447b/backend/onyx/auth/users.py#L204-L223) (checked October 2026): a pre-release read for comparison only, with the v4.9.2 `verify_auth_setting()` body verbatim.
- [Onyx v5.0.0-beta.3 legacy SAML import helper](https://github.com/onyx-dot-app/onyx/blob/55df913b37cb9c001a77dd010ff8c6331e70447b/backend/onyx/db/sso_provider.py#L300-L398) (checked October 2026): a pre-release read for comparison only, with the v4.9.2 `seed_saml_provider_from_conf_dir` body in a byte-identical file.
- [Onyx v5.0.0-beta.3 startup telemetry](https://github.com/onyx-dot-app/onyx/blob/55df913b37cb9c001a77dd010ff8c6331e70447b/backend/onyx/main.py#L433) (checked October 2026): a pre-release read for comparison only, with a `start_telemetry("api")` call.
- [Onyx v5.0.0-beta.3 OAuth provider routers](https://github.com/onyx-dot-app/onyx/blob/55df913b37cb9c001a77dd010ff8c6331e70447b/backend/onyx/main.py#L646-L657) (checked October 2026): a pre-release read for comparison only, mounting the `onyx.server.oauth_provider` protocol and user routers only when `OAUTH_PROVIDER_SETTINGS` is not `None`; the routers themselves were not reviewed.
- [Onyx local Docker deployment](https://docs.onyx.app/deployment/local/docker.md): documented access at `localhost:3000`.
- [Onyx production Compose](https://github.com/onyx-dot-app/onyx/blob/a0370f232ba4e4625131fae518b86e5530e98ec5/deployment/docker_compose/docker-compose.prod.yml): nginx-only host publications.
- [Onyx development Compose](https://github.com/onyx-dot-app/onyx/blob/a0370f232ba4e4625131fae518b86e5530e98ec5/deployment/docker_compose/docker-compose.dev.yml): API and backing-service publications, and its own header naming the two-file launch form.
- [Onyx base Compose](https://github.com/onyx-dot-app/onyx/blob/a0370f232ba4e4625131fae518b86e5530e98ec5/deployment/docker_compose/docker-compose.yml): nginx publishing `${HOST_PORT_80:-80}:80` and `${HOST_PORT:-3000}:80`, and `web_server` carrying no host publication.
- [Docker packet filtering and firewalls](https://docs.docker.com/engine/network/packet-filtering-firewalls/): published ports and firewall interaction.
- [Compose networking](https://docs.docker.com/compose/how-tos/networking/): communication between services without host publication.
- [Compose merge rules](https://docs.docker.com/reference/compose-file/merge/): merged port lists and `!reset`.
- [Docker Compose ps](https://docs.docker.com/reference/cli/docker/compose/ps/): running service information and publication fields.
- [curl manual](https://curl.se/docs/manpage.html): request options, TLS verification, proxy bypass, timing, and error reporting.
- GNU grep 3.12 manual, exit status (checked October 2026): https://www.gnu.org/software/grep/manual/grep.html#Exit-Status
- [LocalAI CLI reference](https://localai.io/docs/reference/cli-reference/): the `--address` flag and `LOCALAI_ADDRESS` bind, default `:8080`.
- [SearxNG webapp implementation](https://raw.githubusercontent.com/searxng/searxng/d4ce87c23431f607162fc5c39ce52c538d64588f/searx/webapp.py): the production startup rejection of the `ultrasecretkey` placeholder and the image proxy following redirects.
- [Onyx data model](https://raw.githubusercontent.com/onyx-dot-app/onyx/15ead4ca364e654d40dac842ee9d0bb9e0fe5471/backend/onyx/db/models.py): the retained per-connector `Credential.credential_json` storage.
- [Text Embeddings Inference gRPC server](https://raw.githubusercontent.com/huggingface/text-embeddings-inference/1bb59202500e5f69dd8be63dd1604f7625124fbe/router/src/grpc/server.rs): the standalone Prometheus exporter (`prom_builder.install()`) of the gRPC build, distinct from the HTTP build's main-port `/metrics`.



<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- searx: SearxNG documentation (unknown)
- tei: TEI HTTP source (v1.9.0)
- onyx-v43: Onyx v4.3 source (v4.3.13)
- onyx-v44: Onyx v4.4 source (v4.4.0)
- onyx-v45: Onyx v4.5 source (v4.5.0)
- onyx-v49: Onyx v4.9 source (v4.9.2)
- onyx-v494: Onyx v4.9 source (v4.9.4)
- onyx-v50-beta: Onyx v5.0 pre-release source (55df913b37cb9c001a77dd010ff8c6331e70447b)
- searx-source: SearxNG source (d4ce87c23431f607162fc5c39ce52c538d64588f)
- localai: LocalAI documentation (unknown)
- tei-docs: TEI documentation (unknown)
- tei-grpc: TEI gRPC source (1bb59202500e5f69dd8be63dd1604f7625124fbe)
- langserve: LangServe source (27e57afeda13007a7f4e007c5d1f5e8489963aa4)
- mem0: Mem0 documentation (unknown)
- mem0-source: Mem0 server source (c7ee362aff94a369af70f13f2b4f853f6793ff4c)
- onyx: Onyx documentation (unknown)
- onyx-compose: Onyx Compose (a0370f232ba4e4625131fae518b86e5530e98ec5)
- onyx-data: Onyx data model (15ead4ca364e654d40dac842ee9d0bb9e0fe5471)
- docker: Docker (unknown)
- grep: GNU grep (3.12)
- curl: curl documentation (unknown)

Claims (full source mapping in the JSON block below):

- searx-bind (REASONED; searx): Direct SearxNG defaults 127.0.0.1:8888 via server.bind_address/port; documented Docker wildcard 8888:8080 needs loopback replacement or removal.
- searx-auth (REASONED; searx): Verified SearxNG configuration has no authentication; protect search with authenticated ingress.
- searx-secret (REASONED; searx, searx-source): Set unique server.secret_key/SEARXNG_SECRET; production startup refuses shipped ultrasecretkey, which is not user authentication.
- searx-egress (REASONED; searx-source): Server-side search/image fetches, including image redirects, need outbound restrictions against internal/metadata destinations.
- localai-bind (REASONED; localai): LocalAI defaults :8080; set LOCALAI_ADDRESS or --address for host loopback; documented 8080:8080 publication needs restriction.
- localai-key (REASONED; localai): LOCALAI_API_KEY is unset by default; set unique native key and retain ingress authentication.
- localai-oauth (REASONED; localai): LOCALAI_AUTH=true enables multi-user OAuth with per-user keys.
- tei-bind (REASONED; tei-docs): TEI CLI defaults 0.0.0.0:3000, distinct from documented container 80 mapped to host 8080; use hostname/port or private publication.
- tei-key (REASONED; tei-docs, tei): API_KEY/--api-key is unset by default; configured key requires Authorization Bearer on inference routes.
- tei-exempt (REASONED; tei): HTTP /, /health, /ping, /metrics, /docs and /api-doc/openapi.json remain outside inference auth on the main port.
- tei-metrics (REASONED; tei-docs, tei, tei-grpc): HTTP metrics share main port and expose model/request information; prometheus-port default 9000 starts standalone exporter only in gRPC build.
- langserve (REASONED; langserve): Deprecated 2024-11-18; README recommends LangGraph Platform. Existing quickstart localhost:8000 needs FastAPI application auth or full authenticated proxy.
- private-publication (REASONED; docker): Container loopback is not host/proxy reachability; retain container-network access and remove or host-loopback-scope publications.
- firewall (REASONED; docker): No-host-IP Docker publications bind all host interfaces; Linux forwarding can bypass UFW.
- compose-reset (REASONED; docker, mem0-source): Ordinary override ports merge; use !reset [] to remove Mem0 Postgres publication, inspect effective invocation/model, or edit base if unsupported.
- ingress (REASONED; onyx-compose, docker): Publish only authenticated TLS ingress and gate every capability route; production Onyx publication boundary alone proves no certificate or access policy.
- mem0-auth (REASONED; mem0): Mem0 auth defaults on: dashboard JWT, per-user X-API-Key m0sk_ or legacy ADMIN_API_KEY; do not deploy AUTH_DISABLED=true.
- mem0-warnings (REASONED; mem0-source): AUTH_DISABLED warning suppresses short nonempty ADMIN_API_KEY (&lt;16) warning via if/elif; unset key has separate branch; warnings do not stop startup.
- mem0-jwt (REASONED; mem0, mem0-source): With auth on, missing JWT_SECRET raises at startup; generate with openssl rand -base64 48 and keep signing secret private.
- mem0-bootstrap (REASONED; mem0): POST /auth/register grants first admin only while no user exists, then returns 403; bootstrap privately with make bootstrap or host-only wizard.
- mem0-open (REASONED; mem0): Root redirect, /docs and /openapi.json stay open and cannot prove protected-route authentication.
- mem0-api-port (REASONED; mem0-source): Compose runs API 0.0.0.0:8000 and wildcard host 8888:8000; remove publication or replace with host loopback.
- mem0-db-port (REASONED; mem0-source): Compose publishes Postgres 8432:5432 independently of application auth; remove host mapping and retain database auth.
- mem0-dashboard (REASONED; mem0-source): Compose dashboard 3000:3000 needs private publication and protected ingress; dashboard authentication coverage is unverified.
- mem0-reload (REASONED; mem0-source): Compose uvicorn --reload is a development setting; remove for production.
- onyx-prod (REASONED; onyx-compose): Production Compose publishes only nginx 80:80 and 443:443; backing services remain unpublished.
- onyx-bootstrap (REASONED; onyx): Email/password auth is on and first signup becomes admin; claim privately before exposure.
- onyx-auth-type (REASONED; onyx, onyx-v43, onyx-v44): Guide inference from v4.3.13/v4.4.0 tags: beyond two one-time imports (migration Google/OIDC row, startup SAML row), AUTH_TYPE no longer selects v4.4.0 runtime auth; legacy values remain for migrations, a one-time legacy SAML startup import and a stale-value warning. Version identity rests on tags; cited web manifests lack release versions. Guide advice: do not set AUTH_TYPE to change auth.
- onyx-auth-type-legacy-startup (REASONED; onyx-v45, onyx-v49, onyx-v494, onyx-v50-beta, onyx): Guide assessment: v4.5.0, v4.9.2 to v4.9.4 (newest stable reviewed) and pre-release v5.0.0-beta.3 retain the AUTH_TYPE stale-value warning call and, under if not MULTI_TENANT, the legacy SAML startup call (commented no-op unless AUTH_TYPE=saml with no SAML row). Runtime auth selection, full helper behaviour and any docs-site v4.5 removal record remain unverified (docs index: not found 2026-11-04).
- onyx-auth-type-plan-record (REASONED; onyx, onyx-v44, onyx-v45, onyx-v49): Documented: undated Onyx basic auth page said (Oct 2026) AUTH_TYPE "is inert" since v4.4.0, full removal planned in v4.5, and (2026-11-04) that it "is no longer used"; v4.4.0 release notes list removing AUTH_TYPE and AuthType enum. Source reading: v4.5.0/v4.9.2 env.prod.template heads its legacy SSO block (with AUTH_TYPE) "Planned for removal in v4.5." None records the full v4.5 removal as done.
- onyx-auth-type-later-selection (REASONED; onyx-v45, onyx-v49): Source reading and guide inference: a case-sensitive AUTH_TYPE search of Onyx v4.5.0/v4.9.2 backend/web finds reads only in two migrations and two helpers; main.py always mounts password login, gating only env-credential Google login on OAuth credentials. Beyond two one-time imports (migration Google/OIDC row, startup SAML row), AUTH_TYPE selects no runtime auth; deployed selection is unobserved.
- onyx-auth-type-helpers (REASONED; onyx-v45, onyx-v49, onyx-v494): Source reading, v4.5.0, v4.9.2-v4.9.4: verify_auth_setting only logs AUTH_TYPE disabled/google_oauth/oidc/saml warnings, then MULTI_TENANT mode notice. SAML seed acts only if single-tenant, AUTH_TYPE=saml, no SAML row, valid SAML_CONF_DIR settings.json, adding one row, catching only IntegrityError; at v4.9.2-v4.9.4 other errors end base and (guide inference) outer EE lifespans pre-yield (not run).
- onyx-auth-type-removal-search (REASONED; onyx, onyx-v45): Documentation reading: notes of the 48 stable Onyx releases v4.5.0 to v5.0.0 in the GitHub release list fetched 2026-10-25 record no removal of AUTH_TYPE or legacy SSO variables. On 2026-11-04 docs llms.txt, sitemap, changelog, release process and migration pages record no full v4.5 removal (the v4.4.0 changelog entry says AUTH_TYPE "has been removed", calling it inert). Not found in either scope.
- onyx-auth-type-ee-main (REASONED; onyx-v45, onyx-v49, onyx-v494): Source reading: backend/ee/onyx/main.py at v4.5.0/v4.9.2 nests base lifespan in its own, passed to base get_application, adds a Google OAuth router only under MULTI_TENANT; no backend/ee file at either has AUTH_TYPE (string search; others unread). Guide inference, v4.9.2-v4.9.4 only (v4.5.0 base factory uncited): EE runs the base startup, narrowing, not settling, runtime selection; nothing run.
- onyx-base (REASONED; onyx-compose, onyx): Development merges base plus override; base nginx publishes 80:80 and 3000:80, while web_server has no independent host publication.
- onyx-api (REASONED; onyx-compose): Development override adds API 8080:8080; remove unless deliberately restricted for access.
- onyx-backing (REASONED; onyx-compose): Development adds Postgres 5432, OpenSearch 9200, inference 9000, Redis 6379, MinIO 9004/9005 and interpreter 8000; application auth does not protect these.
- onyx-port-env (REASONED; onyx-compose): ${VAR:-default} changes or restores host port; an empty variable does not remove publication.
- onyx-secrets (REASONED; onyx-data): Connector credential_json persists in database; use least privilege, protect storage/backups and rotate after exposure.
- mfa (REASONED; mem0, onyx): Native MFA coverage remains unverified; guide relies on identity/fronting MFA and separate machine credentials.
- secrets (REASONED; localai, tei-docs, mem0, onyx-data): Runtime provider/signing/service keys stay out of source/images; outbound provider credentials are not inbound authentication.
- verify-placeholder (DEMONSTRATED; curl, grep): Placeholder scan should print matched tokens with grep_exit=0, clean with 1; read errors are inconclusive. Local guard outcomes and a direct grep match are recorded in the Verify overview; the deployed-state outcomes remain unobserved. The guard and scan runs covered an earlier form whose placeholder refusal exited with status 1 and whose scans exited 0; the current form was not re-run.
- verify-guards (REASONED; curl): Whole-block marker/count and empty/placeholder guards are prerequisites, not exposure proof; omitted guards and matching inherited positional values remain limits.
- verify-inventory (REASONED; docker): Compare full IPv4/IPv6 socket, merged model and running Publishers inventory; DNAT may escape ss, exposed-only entries are not publications, and empty/error inventories do not pass.
- verify-direct (REASONED; curl, docker): Any direct HTTP response or completed TCP connection proves reachability; refused actual backend plus inventory/working ingress supports isolation, timeout or http=000 alone does not.
- verify-backing (REASONED; docker): Probe every actual private application/backing TCP port; connection success is exposure, refusal needs configuration evidence, timeout/local/netcat-option errors are inconclusive.
- verify-ingress (REASONED; localai, tei-docs, tei, mem0, onyx, curl): Harmless protected request should reject anonymous caller and admit authorized control; inspect redirect destination/body, and test routes outside native auth through ingress too.
- verify-tei (REASONED; tei): POST /embed with harmless inputs should reject missing key 401 and return embeddings with valid key; anonymous health/docs/metrics cannot test native auth.
- verify-native (REASONED; localai, tei-docs, mem0, onyx, langserve): From trusted private position vary only empty/wrong/valid credential for same request; first two reject, third returns real output, without publishing a test port.
- verify-native-limits (REASONED; searx, langserve, mem0, onyx): Intentionally anonymous private SearxNG/LangServe instead use authenticated ingress; exact selected Mem0/Onyx response codes and dashboard policy remain unverified.
- verify-positive (REASONED; curl, localai, tei-docs, mem0, onyx): Authorized ingress request must return expected application body, paired with negative checks; 2xx alone, login page, errors or unreachable service cannot establish success.
- verify-headers (REASONED; curl): Credential headers go on curl stdin under control-character guard; separate ingress/native credentials require both, not argv.
- verify-browser (REASONED; mem0, onyx): An MFA-protected operation must be refused on a password-only attempt and succeed after the second factor; a direct forged identity header must be refused at the network boundary, a valid authenticated session must reach the app through the proxy, and a forged trusted header sent through it must not change the identity in the app log. Neither the MFA nor the header outcomes were demonstrated.

````json
{
  "schema": 1,
  "checked": "2026-10-20",
  "documentation_checked": "2026-09",
  "body_sha256": "b84a2f89263762162f1107da1188e16398936985d705a41591d16d079c2b00ff",
  "components": {
    "searx": {
      "name": "SearxNG documentation",
      "basis": "unknown",
      "sources": {
        "s99812c56f9f8": "https://docs.searxng.org/admin/settings/settings_server.html",
        "sb89a5ded36cc": "https://docs.searxng.org/admin/installation-docker.html"
      }
    },
    "tei": {
      "name": "TEI HTTP source",
      "basis": "v1.9.0",
      "sources": {
        "s2b649738d265": "https://github.com/huggingface/text-embeddings-inference/blob/v1.9.0/router/src/http/server.rs"
      }
    },
    "onyx-v43": {
      "name": "Onyx v4.3 source",
      "basis": "v4.3.13",
      "sources": {
        "s279734512e1b": "https://github.com/onyx-dot-app/onyx/blob/v4.3.13/backend/onyx/configs/app_configs.py#L133-L142",
        "sb03484e56906": "https://github.com/onyx-dot-app/onyx/blob/v4.3.13/backend/onyx/main.py#L581-L608",
        "seb430888edc4": "https://github.com/onyx-dot-app/onyx/blob/v4.3.13/web/package.json#L3"
      }
    },
    "onyx-v44": {
      "name": "Onyx v4.4 source",
      "basis": "v4.4.0",
      "sources": {
        "s799b0a246cf5": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/main.py#L371-L372",
        "sac84754b3dd2": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/main.py#L392-L397",
        "s9275371ceeec": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/auth/users.py#L183-L200",
        "sc9b10b6185fd": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/db/sso_provider.py#L197-L295",
        "s5c46d1afde57": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/alembic/versions/1fc2904131a3_add_sso_provider_table_and_seed_from_env.py#L60-L129",
        "s75cc112525f7": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/alembic/versions/f7ca3e2f45d9_migrate_no_auth_data_to_placeholder.py#L129-L193",
        "s54e8bbf4f896": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/main.py#L589-L681",
        "s6602dda5fa9c": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/db/models.py#L6618-L6645",
        "s170322fcd248": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/server/saml_multi.py#L102-L140",
        "s74923f110244": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/backend/onyx/server/oidc_multi.py#L74-L97",
        "sbc5f578e1c7e": "https://github.com/onyx-dot-app/onyx/blob/v4.4.0/web/package.json#L3",
        "sa49753aa8478": "https://github.com/onyx-dot-app/onyx/releases/tag/v4.4.0"
      }
    },
    "onyx-v45": {
      "name": "Onyx v4.5 source",
      "basis": "v4.5.0",
      "sources": {
        "s50116ebcab47": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/main.py#L378-L379",
        "sab806f01b340": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/main.py#L398-L414",
        "s7ebeb588576d": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/deployment/docker_compose/env.prod.template#L24-L26",
        "sbc16f4507870": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/main.py#L611-L703",
        "sc23bf087d9f8": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/auth/users.py#L184-L203",
        "sd046764eadb4": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/db/sso_provider.py#L247-L345",
        "sb5ac094a2533": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/alembic/versions/1fc2904131a3_add_sso_provider_table_and_seed_from_env.py#L60-L129",
        "s1f8204533a74": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/alembic/versions/f7ca3e2f45d9_migrate_no_auth_data_to_placeholder.py#L129-L193",
        "sb0b19e5482b8": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/db/models.py#L6873-L6900",
        "s20888688ad03": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/server/saml_multi.py#L103-L141",
        "s0945580d24f5": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/onyx/server/oidc_multi.py#L74-L97",
        "scfaeea113df6": "https://github.com/onyx-dot-app/onyx/releases/tag/v4.5.0",
        "s7f4227427c7d": "https://github.com/onyx-dot-app/onyx/blob/055b0c5d0e0a1187ef64d109d700ef4e1bcc5796/backend/ee/onyx/main.py#L42-L129"
      }
    },
    "onyx-v49": {
      "name": "Onyx v4.9 source",
      "basis": "v4.9.2",
      "sources": {
        "sba8318be94ea": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/main.py#L394-L395",
        "sab9b9d5d76ac": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/main.py#L414-L432",
        "sb19e8617a53f": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/deployment/docker_compose/env.prod.template#L24-L26",
        "sc82872ea4ee8": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/main.py#L651-L750",
        "s85054eff3304": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/auth/users.py#L200-L219",
        "sad04863d1458": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/db/sso_provider.py#L300-L398",
        "s589436426362": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/alembic/versions/1fc2904131a3_add_sso_provider_table_and_seed_from_env.py#L60-L129",
        "sed2172013ac6": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/alembic/versions/f7ca3e2f45d9_migrate_no_auth_data_to_placeholder.py#L129-L193",
        "secbe5662c7eb": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/db/models.py#L7490-L7517",
        "se9a7d604174b": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/server/saml_multi.py#L40-L156",
        "sf74066095373": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/onyx/server/oidc_multi.py#L161-L184",
        "sd4abc0fb7b2c": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/ee/onyx/main.py#L43-L130",
        "sb57e6f0a50cc": "https://github.com/onyx-dot-app/onyx/blob/df49072cabd57a37c75143f78910023bf1cc4dcb/backend/ee/onyx/server/scim/api.py#L90"
      }
    },
    "onyx-v494": {
      "name": "Onyx v4.9 source",
      "basis": "v4.9.4",
      "sources": {
        "s93073617917f": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L394-L395",
        "saa2935bc2cc9": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L414-L432",
        "sa1ae7eae7541": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L452-L455",
        "sa460f7210ca4": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/auth/users.py#L200-L219",
        "sdf15a9263d34": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/db/sso_provider.py#L300-L398",
        "s56d064c896d9": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/db/sso_provider.py#L28-L82",
        "s55b9746616f4": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/db/sso_provider.py#L132-L256",
        "s8a5f96230d05": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/db/engine/sql_engine.py#L441-L549",
        "s19ba2d899d29": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L534-L549",
        "s8e0f5703a244": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/main.py#L812-L815",
        "s1230ebe5af1d": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/onyx/utils/variable_functionality.py#L100-L127",
        "s0bd0b2d82697": "https://github.com/onyx-dot-app/onyx/blob/4cfda3c38c7f25e190d735b52d6c8e75522d99f5/backend/ee/onyx/main.py#L58-L78"
      }
    },
    "onyx-v50-beta": {
      "name": "Onyx v5.0 pre-release source",
      "basis": "55df913b37cb9c001a77dd010ff8c6331e70447b",
      "sources": {
        "sb6a38c2222ba": "https://github.com/onyx-dot-app/onyx/blob/55df913b37cb9c001a77dd010ff8c6331e70447b/backend/onyx/main.py#L395-L431",
        "s8bbce4b47acc": "https://github.com/onyx-dot-app/onyx/blob/55df913b37cb9c001a77dd010ff8c6331e70447b/backend/onyx/auth/users.py#L204-L223",
        "s8843778589c8": "https://github.com/onyx-dot-app/onyx/blob/55df913b37cb9c001a77dd010ff8c6331e70447b/backend/onyx/db/sso_provider.py#L300-L398"
      }
    },
    "searx-source": {
      "name": "SearxNG source",
      "basis": "d4ce87c23431f607162fc5c39ce52c538d64588f",
      "sources": {
        "s1669cd3902ff": "https://raw.githubusercontent.com/searxng/searxng/d4ce87c23431f607162fc5c39ce52c538d64588f/searx/webapp.py"
      }
    },
    "localai": {
      "name": "LocalAI documentation",
      "basis": "unknown",
      "sources": {
        "sac7ce142c7f6": "https://localai.io/docs/basics/getting_started/",
        "sc3fe058c79a4": "https://localai.io/docs/reference/cli-reference/"
      }
    },
    "tei-docs": {
      "name": "TEI documentation",
      "basis": "unknown",
      "sources": {
        "s7d188dacbcfc": "https://huggingface.co/docs/text-embeddings-inference/en/quick_tour",
        "s013618141267": "https://huggingface.co/docs/text-embeddings-inference/en/cli_arguments"
      }
    },
    "tei-grpc": {
      "name": "TEI gRPC source",
      "basis": "1bb59202500e5f69dd8be63dd1604f7625124fbe",
      "sources": {
        "s509a423cecd0": "https://raw.githubusercontent.com/huggingface/text-embeddings-inference/1bb59202500e5f69dd8be63dd1604f7625124fbe/router/src/grpc/server.rs"
      }
    },
    "langserve": {
      "name": "LangServe source",
      "basis": "27e57afeda13007a7f4e007c5d1f5e8489963aa4",
      "sources": {
        "sa9fa1381b09a": "https://github.com/langchain-ai/langserve/blob/27e57afeda13007a7f4e007c5d1f5e8489963aa4/README.md"
      }
    },
    "mem0": {
      "name": "Mem0 documentation",
      "basis": "unknown",
      "sources": {
        "s37e3935419ed": "https://docs.mem0.ai/open-source/features/rest-api"
      }
    },
    "mem0-source": {
      "name": "Mem0 server source",
      "basis": "c7ee362aff94a369af70f13f2b4f853f6793ff4c",
      "sources": {
        "sa73e09554796": "https://github.com/mem0ai/mem0/blob/c7ee362aff94a369af70f13f2b4f853f6793ff4c/server/docker-compose.yaml",
        "s491ae4b02d2d": "https://github.com/mem0ai/mem0/blob/c7ee362aff94a369af70f13f2b4f853f6793ff4c/server/main.py"
      }
    },
    "onyx": {
      "name": "Onyx documentation",
      "basis": "unknown",
      "sources": {
        "sc7649811ee67": "https://docs.onyx.app/deployment/authentication/basic.md",
        "scb3a0b1624de": "https://docs.onyx.app/deployment/local/docker.md",
        "s340e025f4f48": "https://api.github.com/repos/onyx-dot-app/onyx/releases?per_page=100",
        "s685daf37d278": "https://api.github.com/repos/onyx-dot-app/onyx/releases?per_page=100&page=2",
        "s651883102d82": "https://docs.onyx.app/llms.txt",
        "s6681a93c4f99": "https://docs.onyx.app/sitemap.xml",
        "sa7d9d07745ec": "https://docs.onyx.app/changelog",
        "sa9d706f7a521": "https://docs.onyx.app/deployment/miscellaneous/release_process.md",
        "sd804b75439bd": "https://docs.onyx.app/llms-full.txt"
      }
    },
    "onyx-compose": {
      "name": "Onyx Compose",
      "basis": "a0370f232ba4e4625131fae518b86e5530e98ec5",
      "sources": {
        "sc35a382f123e": "https://github.com/onyx-dot-app/onyx/blob/a0370f232ba4e4625131fae518b86e5530e98ec5/deployment/docker_compose/docker-compose.prod.yml",
        "sb82664aa67ff": "https://github.com/onyx-dot-app/onyx/blob/a0370f232ba4e4625131fae518b86e5530e98ec5/deployment/docker_compose/docker-compose.dev.yml",
        "s1b87311a0e14": "https://github.com/onyx-dot-app/onyx/blob/a0370f232ba4e4625131fae518b86e5530e98ec5/deployment/docker_compose/docker-compose.yml"
      }
    },
    "onyx-data": {
      "name": "Onyx data model",
      "basis": "15ead4ca364e654d40dac842ee9d0bb9e0fe5471",
      "sources": {
        "s991ce173678a": "https://raw.githubusercontent.com/onyx-dot-app/onyx/15ead4ca364e654d40dac842ee9d0bb9e0fe5471/backend/onyx/db/models.py"
      }
    },
    "docker": {
      "name": "Docker",
      "basis": "unknown",
      "sources": {
        "s351180c6678f": "https://docs.docker.com/engine/network/packet-filtering-firewalls/",
        "sae565a19136c": "https://docs.docker.com/compose/how-tos/networking/",
        "se716ad33db1f": "https://docs.docker.com/reference/compose-file/merge/",
        "s3e97c2c250b6": "https://docs.docker.com/reference/cli/docker/compose/ps/"
      }
    },
    "grep": {
      "name": "GNU grep",
      "basis": "3.12",
      "sources": {
        "sa8d467168870": "https://www.gnu.org/software/grep/manual/grep.html#Exit-Status"
      }
    },
    "curl": {
      "name": "curl documentation",
      "basis": "unknown",
      "sources": {
        "s2b2686afaf41": "https://curl.se/docs/manpage.html"
      }
    }
  },
  "claims": {
    "searx-bind": {"text": "Direct SearxNG defaults 127.0.0.1:8888 via server.bind_address/port; documented Docker wildcard 8888:8080 needs loopback replacement or removal.", "components": ["searx"], "sources": ["searx:s99812c56f9f8", "searx:sb89a5ded36cc"], "status": "REASONED"},
    "searx-auth": {"text": "Verified SearxNG configuration has no authentication; protect search with authenticated ingress.", "components": ["searx"], "sources": ["searx:s99812c56f9f8"], "status": "REASONED"},
    "searx-secret": {"text": "Set unique server.secret_key/SEARXNG_SECRET; production startup refuses shipped ultrasecretkey, which is not user authentication.", "components": ["searx", "searx-source"], "sources": ["searx:s99812c56f9f8", "searx-source:s1669cd3902ff"], "status": "REASONED"},
    "searx-egress": {"text": "Server-side search/image fetches, including image redirects, need outbound restrictions against internal/metadata destinations.", "components": ["searx-source"], "sources": ["searx-source:s1669cd3902ff"], "status": "REASONED"},
    "localai-bind": {"text": "LocalAI defaults :8080; set LOCALAI_ADDRESS or --address for host loopback; documented 8080:8080 publication needs restriction.", "components": ["localai"], "sources": ["localai:sc3fe058c79a4", "localai:sac7ce142c7f6"], "status": "REASONED"},
    "localai-key": {"text": "LOCALAI_API_KEY is unset by default; set unique native key and retain ingress authentication.", "components": ["localai"], "sources": ["localai:sac7ce142c7f6"], "status": "REASONED"},
    "localai-oauth": {"text": "LOCALAI_AUTH=true enables multi-user OAuth with per-user keys.", "components": ["localai"], "sources": ["localai:sac7ce142c7f6"], "status": "REASONED"},
    "tei-bind": {"text": "TEI CLI defaults 0.0.0.0:3000, distinct from documented container 80 mapped to host 8080; use hostname/port or private publication.", "components": ["tei-docs"], "sources": ["tei-docs:s013618141267", "tei-docs:s7d188dacbcfc"], "status": "REASONED"},
    "tei-key": {"text": "API_KEY/--api-key is unset by default; configured key requires Authorization Bearer on inference routes.", "components": ["tei-docs", "tei"], "sources": ["tei-docs:s013618141267", "tei:s2b649738d265"], "status": "REASONED"},
    "tei-exempt": {"text": "HTTP /, /health, /ping, /metrics, /docs and /api-doc/openapi.json remain outside inference auth on the main port.", "components": ["tei"], "sources": ["tei:s2b649738d265"], "status": "REASONED"},
    "tei-metrics": {"text": "HTTP metrics share main port and expose model/request information; prometheus-port default 9000 starts standalone exporter only in gRPC build.", "components": ["tei-docs", "tei", "tei-grpc"], "sources": ["tei-docs:s013618141267", "tei:s2b649738d265", "tei-grpc:s509a423cecd0"], "status": "REASONED"},
    "langserve": {"text": "Deprecated 2024-11-18; README recommends LangGraph Platform. Existing quickstart localhost:8000 needs FastAPI application auth or full authenticated proxy.", "components": ["langserve"], "sources": ["langserve:sa9fa1381b09a"], "status": "REASONED"},
    "private-publication": {"text": "Container loopback is not host/proxy reachability; retain container-network access and remove or host-loopback-scope publications.", "components": ["docker"], "sources": ["docker:sae565a19136c", "docker:s351180c6678f"], "status": "REASONED"},
    "firewall": {"text": "No-host-IP Docker publications bind all host interfaces; Linux forwarding can bypass UFW.", "components": ["docker"], "sources": ["docker:s351180c6678f"], "status": "REASONED"},
    "compose-reset": {"text": "Ordinary override ports merge; use !reset [] to remove Mem0 Postgres publication, inspect effective invocation/model, or edit base if unsupported.", "components": ["docker", "mem0-source"], "sources": ["docker:se716ad33db1f", "mem0-source:sa73e09554796"], "status": "REASONED"},
    "ingress": {"text": "Publish only authenticated TLS ingress and gate every capability route; production Onyx publication boundary alone proves no certificate or access policy.", "components": ["onyx-compose", "docker"], "sources": ["onyx-compose:sc35a382f123e", "docker:s351180c6678f"], "status": "REASONED"},
    "mem0-auth": {"text": "Mem0 auth defaults on: dashboard JWT, per-user X-API-Key m0sk_ or legacy ADMIN_API_KEY; do not deploy AUTH_DISABLED=true.", "components": ["mem0"], "sources": ["mem0:s37e3935419ed"], "status": "REASONED"},
    "mem0-warnings": {"text": "AUTH_DISABLED warning suppresses short nonempty ADMIN_API_KEY (<16) warning via if/elif; unset key has separate branch; warnings do not stop startup.", "components": ["mem0-source"], "sources": ["mem0-source:s491ae4b02d2d"], "status": "REASONED"},
    "mem0-jwt": {"text": "With auth on, missing JWT_SECRET raises at startup; generate with openssl rand -base64 48 and keep signing secret private.", "components": ["mem0", "mem0-source"], "sources": ["mem0:s37e3935419ed", "mem0-source:s491ae4b02d2d"], "status": "REASONED"},
    "mem0-bootstrap": {"text": "POST /auth/register grants first admin only while no user exists, then returns 403; bootstrap privately with make bootstrap or host-only wizard.", "components": ["mem0"], "sources": ["mem0:s37e3935419ed"], "status": "REASONED"},
    "mem0-open": {"text": "Root redirect, /docs and /openapi.json stay open and cannot prove protected-route authentication.", "components": ["mem0"], "sources": ["mem0:s37e3935419ed"], "status": "REASONED"},
    "mem0-api-port": {"text": "Compose runs API 0.0.0.0:8000 and wildcard host 8888:8000; remove publication or replace with host loopback.", "components": ["mem0-source"], "sources": ["mem0-source:sa73e09554796"], "status": "REASONED"},
    "mem0-db-port": {"text": "Compose publishes Postgres 8432:5432 independently of application auth; remove host mapping and retain database auth.", "components": ["mem0-source"], "sources": ["mem0-source:sa73e09554796"], "status": "REASONED"},
    "mem0-dashboard": {"text": "Compose dashboard 3000:3000 needs private publication and protected ingress; dashboard authentication coverage is unverified.", "components": ["mem0-source"], "sources": ["mem0-source:sa73e09554796"], "status": "REASONED"},
    "mem0-reload": {"text": "Compose uvicorn --reload is a development setting; remove for production.", "components": ["mem0-source"], "sources": ["mem0-source:sa73e09554796"], "status": "REASONED"},
    "onyx-prod": {"text": "Production Compose publishes only nginx 80:80 and 443:443; backing services remain unpublished.", "components": ["onyx-compose"], "sources": ["onyx-compose:sc35a382f123e"], "status": "REASONED"},
    "onyx-bootstrap": {"text": "Email/password auth is on and first signup becomes admin; claim privately before exposure.", "components": ["onyx"], "sources": ["onyx:sc7649811ee67"], "status": "REASONED"},
    "onyx-auth-type": {"text": "Guide inference from v4.3.13/v4.4.0 tags: beyond two one-time imports (migration Google/OIDC row, startup SAML row), AUTH_TYPE no longer selects v4.4.0 runtime auth; legacy values remain for migrations, a one-time legacy SAML startup import and a stale-value warning. Version identity rests on tags; cited web manifests lack release versions. Guide advice: do not set AUTH_TYPE to change auth.", "components": ["onyx", "onyx-v43", "onyx-v44"], "sources": ["onyx:sc7649811ee67", "onyx-v43:s279734512e1b", "onyx-v43:sb03484e56906", "onyx-v44:s799b0a246cf5", "onyx-v44:sac84754b3dd2", "onyx-v44:s9275371ceeec", "onyx-v44:sc9b10b6185fd", "onyx-v44:s5c46d1afde57", "onyx-v44:s75cc112525f7", "onyx-v44:s54e8bbf4f896", "onyx-v44:s6602dda5fa9c", "onyx-v44:s170322fcd248", "onyx-v44:s74923f110244", "onyx-v43:seb430888edc4", "onyx-v44:sbc5f578e1c7e"], "status": "REASONED"},
    "onyx-auth-type-legacy-startup": {"text": "Guide assessment: v4.5.0, v4.9.2 to v4.9.4 (newest stable reviewed) and pre-release v5.0.0-beta.3 retain the AUTH_TYPE stale-value warning call and, under if not MULTI_TENANT, the legacy SAML startup call (commented no-op unless AUTH_TYPE=saml with no SAML row). Runtime auth selection, full helper behaviour and any docs-site v4.5 removal record remain unverified (docs index: not found 2026-11-04).", "components": ["onyx-v45", "onyx-v49", "onyx-v494", "onyx-v50-beta", "onyx"], "sources": ["onyx-v45:s50116ebcab47", "onyx-v45:sab806f01b340", "onyx-v49:sba8318be94ea", "onyx-v49:sab9b9d5d76ac", "onyx-v494:s93073617917f", "onyx-v494:saa2935bc2cc9", "onyx-v50-beta:sb6a38c2222ba", "onyx-v50-beta:s8bbce4b47acc", "onyx-v50-beta:s8843778589c8", "onyx:s651883102d82", "onyx:s6681a93c4f99", "onyx:sa7d9d07745ec", "onyx:sa9d706f7a521", "onyx:sd804b75439bd"], "status": "REASONED"},
    "onyx-auth-type-plan-record": {"text": "Documented: undated Onyx basic auth page said (Oct 2026) AUTH_TYPE \"is inert\" since v4.4.0, full removal planned in v4.5, and (2026-11-04) that it \"is no longer used\"; v4.4.0 release notes list removing AUTH_TYPE and AuthType enum. Source reading: v4.5.0/v4.9.2 env.prod.template heads its legacy SSO block (with AUTH_TYPE) \"Planned for removal in v4.5.\" None records the full v4.5 removal as done.", "components": ["onyx", "onyx-v44", "onyx-v45", "onyx-v49"], "sources": ["onyx:sc7649811ee67", "onyx-v44:sa49753aa8478", "onyx-v45:s7ebeb588576d", "onyx-v49:sb19e8617a53f"], "status": "REASONED"},
    "onyx-auth-type-later-selection": {"text": "Source reading and guide inference: a case-sensitive AUTH_TYPE search of Onyx v4.5.0/v4.9.2 backend/web finds reads only in two migrations and two helpers; main.py always mounts password login, gating only env-credential Google login on OAuth credentials. Beyond two one-time imports (migration Google/OIDC row, startup SAML row), AUTH_TYPE selects no runtime auth; deployed selection is unobserved.", "components": ["onyx-v45", "onyx-v49"], "sources": ["onyx-v45:sbc16f4507870", "onyx-v45:sc23bf087d9f8", "onyx-v45:sd046764eadb4", "onyx-v45:sb5ac094a2533", "onyx-v45:s1f8204533a74", "onyx-v45:sb0b19e5482b8", "onyx-v45:s20888688ad03", "onyx-v45:s0945580d24f5", "onyx-v49:sc82872ea4ee8", "onyx-v49:s85054eff3304", "onyx-v49:sad04863d1458", "onyx-v49:s589436426362", "onyx-v49:sed2172013ac6", "onyx-v49:secbe5662c7eb", "onyx-v49:se9a7d604174b", "onyx-v49:sf74066095373"], "status": "REASONED"},
    "onyx-auth-type-helpers": {"text": "Source reading, v4.5.0, v4.9.2-v4.9.4: verify_auth_setting only logs AUTH_TYPE disabled/google_oauth/oidc/saml warnings, then MULTI_TENANT mode notice. SAML seed acts only if single-tenant, AUTH_TYPE=saml, no SAML row, valid SAML_CONF_DIR settings.json, adding one row, catching only IntegrityError; at v4.9.2-v4.9.4 other errors end base and (guide inference) outer EE lifespans pre-yield (not run).", "components": ["onyx-v45", "onyx-v49", "onyx-v494"], "sources": ["onyx-v45:sc23bf087d9f8", "onyx-v45:sd046764eadb4", "onyx-v49:s85054eff3304", "onyx-v49:sad04863d1458", "onyx-v49:sab9b9d5d76ac", "onyx-v49:sd4abc0fb7b2c", "onyx-v494:sa460f7210ca4", "onyx-v494:sdf15a9263d34", "onyx-v494:s56d064c896d9", "onyx-v494:s55b9746616f4", "onyx-v494:s93073617917f", "onyx-v494:saa2935bc2cc9", "onyx-v494:sa1ae7eae7541", "onyx-v494:s8a5f96230d05", "onyx-v494:s19ba2d899d29", "onyx-v494:s8e0f5703a244", "onyx-v494:s1230ebe5af1d", "onyx-v494:s0bd0b2d82697"], "status": "REASONED"},
    "onyx-auth-type-removal-search": {"text": "Documentation reading: notes of the 48 stable Onyx releases v4.5.0 to v5.0.0 in the GitHub release list fetched 2026-10-25 record no removal of AUTH_TYPE or legacy SSO variables. On 2026-11-04 docs llms.txt, sitemap, changelog, release process and migration pages record no full v4.5 removal (the v4.4.0 changelog entry says AUTH_TYPE \"has been removed\", calling it inert). Not found in either scope.", "components": ["onyx", "onyx-v45"], "sources": ["onyx:s340e025f4f48", "onyx:s685daf37d278", "onyx-v45:scfaeea113df6", "onyx:s651883102d82", "onyx:s6681a93c4f99", "onyx:sa7d9d07745ec", "onyx:sa9d706f7a521", "onyx:sd804b75439bd"], "status": "REASONED"},
    "onyx-auth-type-ee-main": {"text": "Source reading: backend/ee/onyx/main.py at v4.5.0/v4.9.2 nests base lifespan in its own, passed to base get_application, adds a Google OAuth router only under MULTI_TENANT; no backend/ee file at either has AUTH_TYPE (string search; others unread). Guide inference, v4.9.2-v4.9.4 only (v4.5.0 base factory uncited): EE runs the base startup, narrowing, not settling, runtime selection; nothing run.", "components": ["onyx-v45", "onyx-v49", "onyx-v494"], "sources": ["onyx-v45:s7f4227427c7d", "onyx-v49:sd4abc0fb7b2c", "onyx-v494:s19ba2d899d29", "onyx-v494:s93073617917f", "onyx-v494:s0bd0b2d82697", "onyx-v49:sb57e6f0a50cc"], "status": "REASONED"},
    "onyx-base": {"text": "Development merges base plus override; base nginx publishes 80:80 and 3000:80, while web_server has no independent host publication.", "components": ["onyx-compose", "onyx"], "sources": ["onyx-compose:sb82664aa67ff", "onyx-compose:s1b87311a0e14", "onyx:scb3a0b1624de"], "status": "REASONED"},
    "onyx-api": {"text": "Development override adds API 8080:8080; remove unless deliberately restricted for access.", "components": ["onyx-compose"], "sources": ["onyx-compose:sb82664aa67ff"], "status": "REASONED"},
    "onyx-backing": {"text": "Development adds Postgres 5432, OpenSearch 9200, inference 9000, Redis 6379, MinIO 9004/9005 and interpreter 8000; application auth does not protect these.", "components": ["onyx-compose"], "sources": ["onyx-compose:sb82664aa67ff"], "status": "REASONED"},
    "onyx-port-env": {"text": "${VAR:-default} changes or restores host port; an empty variable does not remove publication.", "components": ["onyx-compose"], "sources": ["onyx-compose:sb82664aa67ff", "onyx-compose:s1b87311a0e14"], "status": "REASONED"},
    "onyx-secrets": {"text": "Connector credential_json persists in database; use least privilege, protect storage/backups and rotate after exposure.", "components": ["onyx-data"], "sources": ["onyx-data:s991ce173678a"], "status": "REASONED"},
    "mfa": {"text": "Native MFA coverage remains unverified; guide relies on identity/fronting MFA and separate machine credentials.", "components": ["mem0", "onyx"], "sources": ["mem0:s37e3935419ed", "onyx:sc7649811ee67"], "status": "REASONED"},
    "secrets": {"text": "Runtime provider/signing/service keys stay out of source/images; outbound provider credentials are not inbound authentication.", "components": ["localai", "tei-docs", "mem0", "onyx-data"], "sources": ["localai:sac7ce142c7f6", "tei-docs:s013618141267", "mem0:s37e3935419ed", "onyx-data:s991ce173678a"], "status": "REASONED"},
    "verify-placeholder": {"text": "Placeholder scan should print matched tokens with grep_exit=0, clean with 1; read errors are inconclusive. Local guard outcomes and a direct grep match are recorded in the Verify overview; the deployed-state outcomes remain unobserved. The guard and scan runs covered an earlier form whose placeholder refusal exited with status 1 and whose scans exited 0; the current form was not re-run.", "components": ["curl", "grep"], "sources": ["curl:s2b2686afaf41", "grep:sa8d467168870"], "status": "DEMONSTRATED", "evidence": "printed the token and `grep_exit=0` for the exposed fixture and `grep_exit=1` for the fixed fixture", "verify": [1]},
    "verify-guards": {"text": "Whole-block marker/count and empty/placeholder guards are prerequisites, not exposure proof; omitted guards and matching inherited positional values remain limits.", "components": ["curl"], "sources": ["curl:s2b2686afaf41"], "status": "REASONED"},
    "verify-inventory": {"text": "Compare full IPv4/IPv6 socket, merged model and running Publishers inventory; DNAT may escape ss, exposed-only entries are not publications, and empty/error inventories do not pass.", "components": ["docker"], "sources": ["docker:s351180c6678f", "docker:se716ad33db1f", "docker:s3e97c2c250b6"], "status": "REASONED", "verify": [2]},
    "verify-direct": {"text": "Any direct HTTP response or completed TCP connection proves reachability; refused actual backend plus inventory/working ingress supports isolation, timeout or http=000 alone does not.", "components": ["curl", "docker"], "sources": ["curl:s2b2686afaf41", "docker:s351180c6678f"], "status": "REASONED", "verify": [3]},
    "verify-backing": {"text": "Probe every actual private application/backing TCP port; connection success is exposure, refusal needs configuration evidence, timeout/local/netcat-option errors are inconclusive.", "components": ["docker"], "sources": ["docker:s351180c6678f", "docker:s3e97c2c250b6"], "status": "REASONED", "verify": [4]},
    "verify-ingress": {"text": "Harmless protected request should reject anonymous caller and admit authorized control; inspect redirect destination/body, and test routes outside native auth through ingress too.", "components": ["localai", "tei-docs", "tei", "mem0", "onyx", "curl"], "sources": ["localai:sac7ce142c7f6", "tei-docs:s013618141267", "tei:s2b649738d265", "mem0:s37e3935419ed", "onyx:sc7649811ee67", "curl:s2b2686afaf41"], "status": "REASONED", "verify": [5]},
    "verify-tei": {"text": "POST /embed with harmless inputs should reject missing key 401 and return embeddings with valid key; anonymous health/docs/metrics cannot test native auth.", "components": ["tei"], "sources": ["tei:s2b649738d265"], "status": "REASONED", "verify": [5, 6, 7]},
    "verify-native": {"text": "From trusted private position vary only empty/wrong/valid credential for same request; first two reject, third returns real output, without publishing a test port.", "components": ["localai", "tei-docs", "mem0", "onyx", "langserve"], "sources": ["localai:sac7ce142c7f6", "tei-docs:s013618141267", "mem0:s37e3935419ed", "onyx:sc7649811ee67", "langserve:sa9fa1381b09a"], "status": "REASONED", "verify": [6]},
    "verify-native-limits": {"text": "Intentionally anonymous private SearxNG/LangServe instead use authenticated ingress; exact selected Mem0/Onyx response codes and dashboard policy remain unverified.", "components": ["searx", "langserve", "mem0", "onyx"], "sources": ["searx:s99812c56f9f8", "langserve:sa9fa1381b09a", "mem0:s37e3935419ed", "onyx:sc7649811ee67"], "status": "REASONED", "verify": [6]},
    "verify-positive": {"text": "Authorized ingress request must return expected application body, paired with negative checks; 2xx alone, login page, errors or unreachable service cannot establish success.", "components": ["curl", "localai", "tei-docs", "mem0", "onyx"], "sources": ["curl:s2b2686afaf41", "localai:sac7ce142c7f6", "tei-docs:s013618141267", "mem0:s37e3935419ed", "onyx:sc7649811ee67"], "status": "REASONED", "verify": [7]},
    "verify-headers": {"text": "Credential headers go on curl stdin under control-character guard; separate ingress/native credentials require both, not argv.", "components": ["curl"], "sources": ["curl:s2b2686afaf41"], "status": "REASONED", "verify": [6, 7]},
    "verify-browser": {"text": "An MFA-protected operation must be refused on a password-only attempt and succeed after the second factor; a direct forged identity header must be refused at the network boundary, a valid authenticated session must reach the app through the proxy, and a forged trusted header sent through it must not change the identity in the app log. Neither the MFA nor the header outcomes were demonstrated.", "components": ["mem0", "onyx"], "sources": ["mem0:s37e3935419ed", "onyx:sc7649811ee67"], "status": "REASONED"}
  }
}
````
<!-- version-basis:end -->
