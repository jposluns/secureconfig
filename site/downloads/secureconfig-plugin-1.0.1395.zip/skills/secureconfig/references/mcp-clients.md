# MCP clients: authorizing to Model Context Protocol servers safely

An MCP client is the program, such as a desktop app or CLI, that talks to Model Context Protocol servers. This guide helps your AI assistant secure OAuth sign-in to remote servers, including the response issuer checked when present and required when advertised, confidential refresh tokens, and SSRF-safe discovery requests.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/mcp-clients.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against MCP 2026-07-28, OAuth 2.1 draft draft-ietf-oauth-v2-1-14, CIMD draft draft-ietf-oauth-client-id-metadata-document-00, and OpenID Connect 1.0 errata 2; 2 further sources are pinned to a commit and 2 carry no recorded version. Metadata reviewed 2026-10-17; documentation checked September 2026. The guide records 29 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

An MCP client authorizes to a remote server on a user's behalf, and a malicious or confused server can steer that authorization: it can name an attacker's authorization server, hand back a discovery document that points credentials the wrong way, or supply OAuth URLs that make the client reach inside its own network. The [mcp-servers.md](mcp-servers.md) guide covers the server operator's side and its fronting proxy; this guide covers the **client's** obligations under the MCP **2026-07-28** authorization flow, where a skipped check is not a style lapse but the difference between an authorization code reaching the honest token endpoint and reaching an attacker's. Everything here is a client-side control: it runs in the MCP client (a desktop app, a CLI, or a client deployed on a server), not in the server it talks to.

**Spec revision.** This guide is written against MCP **2026-07-28**, the **Current** revision, and every "MCP requires" below is quoted from that revision's authorization and security pages. Requirement levels (MUST, SHOULD, MAY) are reproduced as the source states them; where a control is a SHOULD in one document and a MUST in another for a narrower case, both are given rather than the stronger one alone. See MCP Authorization.

## 1. Validate the authorization-response `iss` before redeeming the code

When the authorization server redirects back with a code, an `iss` parameter may accompany it. RFC 9207 section 2.4 requires a client that receives `iss` to decode it and compare it with the issuer it expected: "This comparison MUST use simple string comparison", and on a mismatch "clients MUST reject the authorization response and MUST NOT proceed with the authorization grant." MCP makes this validation apply **before the code is redeemed**: the client "MUST apply the validation" "before transmitting the authorization code to any token endpoint". A check performed on an ID token *after* the code is exchanged is too late, because the code has already left for a possibly attacker-controlled token endpoint, and for a public client the PKCE verifier can leave with it.

The handling is not "reject every response that has no `iss`". It depends on whether the authorization server advertised `authorization_response_iss_parameter_supported` and whether `iss` is present:

| AS advertises `authorization_response_iss_parameter_supported: true` | Response `iss` | Required handling |
|---|---|---|
| Yes | Present | Compare with the recorded issuer; reject on mismatch |
| Yes | Absent | Reject the response |
| No or omitted | Present | Compare with the recorded issuer; reject on mismatch |
| No or omitted | Absent | Proceed under this table (a multi-AS client still needs an `iss`-independent mix-up defence) |

Record the issuer you selected from validated metadata (step 2) in the authorization transaction, bound to the same `state`/PKCE record, and compare `iss` against it with exact string comparison: do not normalize hostname case, port, a trailing slash, or percent-encoding, because RFC 9207's "simple string comparison" is defeated by any normalization an attacker can exploit. This defends the mix-up attack of RFC 9700 section 4.4.2, where a client that trusts more than one authorization server is tricked into sending an honest server's code to an attacker's token endpoint; RFC 9700 requires that "clients MUST prevent mix-up attacks". Where `iss` is genuinely unavailable (the last table row), a client that talks to more than one authorization server still needs an applicable mix-up defence and cannot treat the absence as safe.

## 2. Validate discovery metadata identity: `issuer` (not `resource`)

Two different identifiers are validated in the discovery flow, and confusing them leaves a hole:

- **Authorization-server metadata** carries an `issuer`, and RFC 8414 section 3.3 requires that "The \"issuer\" value returned MUST be identical" to the issuer identifier used to build the well-known URL (which includes any issuer path component, not merely the hostname, and is not the full metadata URL). "If these values are not identical, the data contained in the response MUST NOT be used." MCP restates it: "the `issuer` value in the document MUST be identical to the issuer identifier used to construct the well-known URL." Preserve the issuer you used to derive the discovery URL and compare the returned `issuer` to it exactly, before you use any endpoint from the document. When you discover through OpenID Connect instead, apply the OpenID Connect Discovery section 4.3 provider-configuration validation of `issuer` (this guide's instruction). OpenID Connect Discovery section 4.3 states: "The `issuer` value returned MUST be identical to the Issuer URL that was used as the prefix to `/.well-known/openid-configuration` to retrieve the configuration information. This MUST also be identical to the `iss` Claim value in ID Tokens issued from this Issuer." If validation fails, "any operations requiring the information that failed to correctly validate MUST be aborted and the information that failed to validate MUST NOT be used."
- **Protected-resource metadata** carries a `resource`, and RFC 9728 section 3.3 validates *that* against the resource identifier you intended to reach. This is a separate check from the `issuer` check above; RFC 9728 section 3.3 is about `resource`, not `issuer`, so do both.

Skipping the `issuer` check lets an attacker serve metadata from a location it controls while naming an honest issuer, associating that honest issuer with attacker-chosen endpoints and undermining the expected-issuer record that step 1's mix-up defence relies on.

## 3. Present the client identity safely: Client ID Metadata Documents, then DCR with an explicit `application_type`

MCP 2026-07-28 prefers **Client ID Metadata Documents** (CIMD, `draft-ietf-oauth-client-id-metadata-document-00`, dated 8 October 2025): the client uses an HTTPS URL as its `client_id`, and the authorization server fetches JSON client metadata from that URL instead of requiring prior registration. The draft requires that "Client identifier URLs MUST have an \"https\" scheme, MUST contain a path component", and that the document's own `client_id` "value MUST match the URL of the document" by simple string comparison. MCP states clients "SHOULD support OAuth Client ID Metadata Documents", and a client that supports several mechanisms SHOULD prefer an available pre-registration, then supported CIMD, then Dynamic Client Registration.

Dynamic Client Registration (DCR) remains a **MAY**, deprecated but kept for compatibility. When you fall back to it, MCP requires an explicit application type: "MCP clients MUST specify an appropriate `application_type` during Dynamic Client Registration." MCP's guidance is to use `native` (a SHOULD) for desktop, mobile, CLI, and localhost-hosted applications, and `web` (a SHOULD) for remotely hosted browser applications. This matters because the default is not neutral: OpenID Connect registration says "The default, if omitted, is `web`", and `web` implies redirect-URI constraints that can conflict with a native client's loopback or custom-scheme redirect, so under a provider policy that enforces them an omitted `application_type` can be rejected. Supply the type explicitly and handle a rejection by fixing the registration, never by loosening redirect validation to make it pass.

(Version boundary: MCP 2025-06-18 said authorization servers and MCP clients "**SHOULD** support the OAuth 2.0 Dynamic Client Registration Protocol" (https://github.com/modelcontextprotocol/modelcontextprotocol/blob/86f6e0c675afea9a8f233e09b6faf566b126086c/docs/specification/2025-06-18/basic/authorization.mdx#L58-L59). MCP 2025-11-25 already set a **SHOULD** priority order for clients supporting all options. The 2025-11-25 priority order is: available pre-registration, then CIMD when advertised, then DCR as a fallback when supported, then asking the user to enter client information if no other option is available (https://github.com/modelcontextprotocol/modelcontextprotocol/blob/86f6e0c675afea9a8f233e09b6faf566b126086c/docs/specification/2025-11-25/basic/authorization.mdx#L198-L209). That order is therefore not new in 2026-07-28. This guide advises carrying the revision label when citing that history.)

## 4. Keep refresh tokens confidential, and request `offline_access` correctly

A refresh token outlives the short-lived access token, so a stolen one buys continued access. OAuth 2.1 (draft-ietf-oauth-v2-1-14 section 4.3) requires that "Refresh tokens MUST be kept confidential in transit and storage" and restricts sharing to the issuing authorization server and the client that received the token; this binds **public** clients as much as confidential ones. In practice:

- When refreshing access, send a refresh token only to the issuing authorization server's token endpoint over authenticated TLS; to revoke one, send it only to that same server's revocation endpoint (RFC 7009 section 2) over authenticated TLS. Never send a refresh token to the MCP resource server.
- Keep it out of logs, URLs, source repositories, and any published client metadata.
- Store it in protected server-side storage or a native platform credential store; those are ways to satisfy the confidentiality requirement, not a specific product the spec mandates.

To obtain one, MCP says a client that wants refresh tokens "SHOULD include" `refresh_token` in `grant_types`, "MAY add" `offline_access` to its requested scopes when the authorization server advertises it in `scopes_supported`, and "MUST NOT assume" a refresh token will be issued. For an OpenID Connect authorization server, requesting `offline_access` has conditions: OIDC Core section 11 says "a `prompt` parameter value of `consent` MUST be used" (unless another condition already permits offline access), and the server "MUST ignore the `offline_access` request unless the Client is using a `response_type`" that returns an authorization code. So request `offline_access` with the code flow and normally `prompt=consent`, and handle the case where no refresh token comes back, since `offline_access` neither guarantees issuance nor is the only way a refresh token can be issued.

## 5. Defend OAuth discovery fetches against SSRF

A client that fetches OAuth-related URLs a server named (protected-resource metadata, authorization-server metadata, and every endpoint reached afterward) is fetching attacker-influenced URLs. RFC 9728 section 7.7 identifies exactly this surface and says "Clients SHOULD take appropriate precautions against SSRF attacks, such as blocking requests to internal IP address ranges." For a client that runs **on a server**, MCP raises it to a MUST: "MCP clients deployed to a server MUST consider SSRF risks and implement appropriate mitigations when fetching OAuth-related URLs."

The attack is a malicious server handing back discovery URLs aimed at a cloud metadata service, a loopback daemon, or a private administration endpoint; a redirect or DNS rebinding can turn an allowed destination into an internal one after the check, and later token-endpoint POSTs can reach internal services too. Apply destination controls to every fetched URL, not just the first:

- Restrict destinations to production HTTPS and block private/reserved address ranges (loopback, link-local including the `169.254.169.254` metadata address, and RFC 1918).
- Re-validate the target of every redirect to the same standard, and address the gap between validating a hostname and connecting to it (DNS can change in between): resolve-then-pin, or route through an egress proxy.
- Configure any genuinely required private-network exception explicitly rather than disabling the control.

For a deployment with a known set of providers, an issuer allowlist and an approved-destination list narrow the surface further. OWASP's SSRF guidance for this shape is to "Do not accept complete URLs from the user" and instead "Match the host against an allowlist, and build the request yourself." Treat those as sound deployment practice rather than a spec requirement: RFC 9728 deliberately accommodates previously unknown authorization and resource servers, so a dynamic client still needs the runtime SSRF controls above, and issuer-equality validation (step 2) alone does not establish that a destination is safe to fetch.

## 6. Carry the baseline OAuth 2.1 client hygiene through

The controls above are the MCP-specific additions; the client still owes the baseline that [oidc-integration.md](oidc-integration.md) covers, which MCP also mandates:

- **PKCE.** Clients "MUST implement PKCE", MUST use `S256` "when technically capable", and "MUST refuse to proceed" if the authorization server's metadata lacks `code_challenge_methods_supported`. See MCP Authorization Security Considerations.
- **Resource parameter.** Clients MUST send the RFC 8707 `resource` parameter in both the authorization and token requests, naming the MCP server's canonical URI, which requests an access token scoped to that resource. Preventing cross-resource replay then depends on the authorization server supporting audience binding and issuing an audience-restricted token, and on each resource server validating that it is the intended audience; sending the parameter alone does not guarantee it. See MCP Authorization.
- **HTTPS everywhere.** Every authorization-server endpoint is contacted over HTTPS, and every redirect URI is `localhost` or HTTPS (MCP Authorization Security Considerations). Bearer and access tokens never travel in a URL query string; they go in the `Authorization` header (MCP Authorization). The authorization code, by contrast, is returned in the registered redirect URI's query by the flow itself (OAuth 2.1 section 4.1.2), so it is protected instead by PKCE and the step 1 `iss` check. The client, for the same reason, keeps callback URLs out of referrer headers (RFC 9700 section 4.2, with referrer suppression at section 4.2.4) and out of stored or logged URLs (RFC 9700 section 3 lists URLs stored or logged by browsers, proxy servers, and operating systems among an attacker's sources).

## Verify (REASONED: issuer/callback, metadata, SSRF, token-storage and registration comparisons follow the cited MCP and RFC passages; no controllable authorization/discovery server, target client or live DCR capture. Local fixture observations below do not demonstrate client integration or protected credential storage)

These checks are client-behaviour checks. Standing up a full malicious-authorization-server harness to drive a specific MCP client is infrastructure this repository's authoring environment does not have. That missing infrastructure is why the behavioural steps below are marked **reasoned**: each names the prerequisite that is unavailable, gives the concrete request or command, and states the exposed and fixed outcomes and the source passage that distinguishes them, per the contributing rule on Verify steps. The locally feasible checks (the SSRF address test and the config grep) are run as written.

1. **`iss` mismatch is rejected before redemption (reasoned).** Prerequisite unavailable: a controllable authorization server and a target MCP client. Run two authorization-callback requests to the client's redirect URI that are identical except for `iss`, and run each from the SAME freshly restored pre-callback snapshot of the client and the authorization transaction (an unconsumed `state`, a valid unredeemed `code`, and the matching PKCE context), so that neither a consumed `state` nor a spent code, but only `iss`, can cause a rejection. This isolation matters because RFC 9700 section 4.2.4 says the `state` value "SHOULD be invalidated by the client after its first use at the redirection endpoint", so replaying the second callback against the same live transaction would let a client with no issuer validation reject it as a replay and mimic the fixed outcome. Restore the snapshot before each request. Control (must be accepted), carrying the recorded issuer: `GET /callback?code=SPLICED_AUTH_CODE&state=THE_RECORDED_STATE&iss=https%3A%2F%2Fas.example.com`. Test (must be rejected), differing only in `iss`: the same request with `iss=https%3A%2F%2Fevil.example.net`. Exposed (vulnerable) client: it proceeds to `POST` the code to a token endpoint in the test case. Fixed client: it accepts the control and rejects the test, sending no token request for the test. The distinguishing source is RFC 9207 section 2.4 ("clients MUST reject ... and MUST NOT proceed") applied before redemption per MCP Authorization ("before transmitting the authorization code to any token endpoint"). Observe the difference on the wire (a token request appears for the control but not for the test).

2. **Metadata `issuer` mismatch is rejected (reasoned).** Prerequisite unavailable: a controllable metadata endpoint. Serve two authorization-server metadata documents at the well-known URL built from the issuer `https://as.example.com` (that is, `https://as.example.com/.well-known/oauth-authorization-server`), identical except for `issuer`. Control (accepted): `{"issuer":"https://as.example.com","authorization_endpoint":"https://as.example.com/authorize","token_endpoint":"https://as.example.com/token","response_types_supported":["code"],"code_challenge_methods_supported":["S256"]}`. That is a metadata baseline complete enough for the client to proceed (RFC 8414 section 2 marks `response_types_supported` REQUIRED, and MCP refuses when `code_challenge_methods_supported` is absent), so a rejection is attributable to `issuer` rather than a missing required field. Test (rejected): the same body with only `"issuer":"https://evil.example.net"` changed. Run each from a fresh, cache-cleared pre-discovery state so a cached control document cannot satisfy the test run (RFC 9111 section 4.2). A further instruction is to make the client's other well-known discovery locations, including the OpenID configuration, return a fixed failure in both runs, so any endpoint the client contacts can only have come from the document under test rather than from independently validated metadata. Exposed: the client uses the endpoints from the test document. Fixed: the client accepts the control and rejects the test, attributing the rejection to the `issuer` mismatch and contacting no endpoint obtained from the rejected document. Require evidence that the test document was actually fetched, so a mere absence of endpoint traffic, which a cache hit or a blocked alternative would also produce, is not read as success. Distinguishing source: RFC 8414 section 3.3 ("the data contained in the response MUST NOT be used").

3. **SSRF destinations are blocked (partially runnable).** The address-classification half is runnable now; the client-integration half is reasoned. Runnable: confirm the deny-list rejects the reserved and internal ranges a discovery URL might target, namely the cloud metadata address, loopback, and RFC 1918 space:

   Address classification follows the cited RFC 9728 and MCP SSRF guidance, while no target client or discovery fixture is available. Python 3.14.4 ran the printed expression: 169.254.169.254, 127.0.0.1, 10.0.0.1, 192.168.0.1 and 172.16.0.1 each printed BLOCK; the same expression with 8.8.8.8 printed ALLOW. Every invocation exited 0. That run invoked the expression without `-I`, in an earlier form of the block; no stub or live run has covered the `-I` form. This classifies six literal addresses only; it does not test DNS, fetching or SSRF enforcement.

   ```bash
   (                                       # a subshell, so the exit below ends only the subshell
     set -- 0 169.254.169.254 127.0.0.1 10.0.0.1 192.168.0.1 172.16.0.1   # the block's status so far (1, a finding, outranks 3, inconclusive, which outranks 0), then the addresses still to classify
     while [ "$#" -gt 1 ]; do
       set -- "$(if python3 -I -c 'import ipaddress,sys; a=ipaddress.ip_address(sys.argv[1]); print(sys.argv[1], "BLOCK" if (a.is_private or a.is_loopback or a.is_link_local or a.is_reserved) else "ALLOW")' "$2"; then printf '\n0'; else printf '\n%s' "$?"; fi)" "$@"
       set -- "${1##*$'\n'}" "${1%$'\n'*}" "${@:2}"   # python's exit status, its line, the status so far, then the addresses
       printf '%s' "$2"
       case "$1:$2" in
         0:"$4 BLOCK"$'\n') set -- "$3" "${@:5}" ;;
         0:"$4 ALLOW"$'\n') echo "FINDING: $4 printed ALLOW, an SSRF hole"; set -- 1 "${@:5}" ;;
         *) echo "python3 exit $1: $4 was not classified; inconclusive"; if [ "$3" = 1 ]; then set -- 1 "${@:5}"; else set -- 3 "${@:5}"; fi ;;
       esac
     done
     echo "block exit $1; the five addresses are the whole check, so beyond any error above it leaves nothing for you to judge"
     exit "$1"
   )
   ```

   Every line must print `BLOCK`; a printed `ALLOW` for any of these is an SSRF hole. Reasoned (prerequisite unavailable: a malicious server, the target client, and a controllable HTTPS discovery host that carries a valid, trusted TLS certificate and whose name resolves to an address you choose): keep the scheme HTTPS with valid TLS throughout and vary only the resolved address, so a refusal is attributable to the address policy rather than to HTTPS or TLS enforcement. Run the public-address control and the private-address test from the same fresh pre-discovery state, clearing any cached discovery metadata, DNS answers, and open connections between them. The reason for that fresh state and clearing is that otherwise a cached response would satisfy discovery with no fetch at all (RFC 9728 section 7.10 notes "Normal HTTP caching behaviors apply", and RFC 9111 section 4.2 has a fresh cached response served without contacting the origin). Establish the public-address control first: have the malicious server advertise a discovery URL on a host you control, for example `https://discovery.example.com/.well-known/oauth-protected-resource`. A further instruction for the public-address control is to resolve `discovery.example.com` to a routable public address and confirm the client fetches the discovery URL, which the client requests with `GET /.well-known/oauth-protected-resource HTTP/1.1` and `Host: discovery.example.com` (RFC 9728 section 3.1 requires the metadata "MUST be queried using an HTTP GET request"). Then, from that cleared state and changing only the resolved address, point `discovery.example.com` at the cloud metadata address (`169.254.169.254`) or another blocked range. Exposed (vulnerable) client: it fetches the URL and reaches the internal service. Fixed client: it resolves the test to the blocked address and refuses that destination before connecting. Require positive evidence of that resolve-and-reject, not the mere absence of a request, since a cache hit also produces no request. Distinguishing source: RFC 9728 section 7.7 and, for server-deployed clients, the MCP MUST in Security Best Practices.

4. **No refresh token or long-lived bearer token stored in cleartext (runnable, bounded heuristic).** This is a heuristic scan, not a proof: it searches the client's config and log paths for a refresh-token or bearer-token value in the clear, lists only the filenames (never the secret itself), and separates a clean scan from a scan error. Substitute the client's own path for the placeholder, inside the single quotes on the `set --` line:

   The bounded scan follows the cited OAuth confidentiality requirements; no actual client configuration or protected credential store is available. Bash 5.3.9 and GNU grep 3.12 ran the complete block with a disposable directory containing only config.json. With {"refresh_token":"DUMMY_NOT_A_SECRET"}, it printed that filename and FOUND; replacing the content with {"grant_types":["refresh_token"]} printed clean. Both exited 0. Empty and unchanged-placeholder paths printed the substitution diagnostic; an absent path and a regular JSON file printed not a directory; all four also exited 0. These skips are not clean scans, and the synthetic clean result proves neither secret absence nor storage protection. All three Verify shell fences passed bash -n. The bash -n and fixture runs recorded here covered the token-scan block in an earlier form, whose guard refusals left the subshell with status 0 and whose result arms ended with status 0, and the fixture runs were not repeated. On the current form, whose guard refusals leave the subshell with status 2, whose FOUND arm exits 1 and whose scan-error arm exits 3, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run. That bash -n run also covered earlier forms of the address-classification and application_type blocks, which ended with the status of their last command; on their current forms, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run.

   ```bash
   (
     set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_CLIENT_CONFIG_DIR'
     [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
     shift
     [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
     case "$1" in
       *REPLACE_WITH_*|"") echo "substitute the client's config/log directory inside the quotes above; not probing"; exit 2 ;;
     esac
     [ -d "$1" ] || { echo "not a directory: $1; not probing"; exit 2; }
     if env LC_ALL=C grep -D skip -RlaiE '"refresh_token"[[:space:]]*:[[:space:]]*"[^"]|refresh_token=[[:print:]]+|Bearer[[:space:]]+[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._~+/-]{20,}' -- "$1/"; then
       echo "FOUND: the file(s) listed above hold a token value in cleartext; move it to a protected credential store"; exit 1
     else
       case $? in
         1) echo "clean: no cleartext token value found under $1" ;;
         *) echo "scan error: grep could not read part of $1; re-run with access before trusting a clean result"; exit 3 ;;
       esac
     fi
   )
   ```

   A listed file flags a possible cleartext refresh or bearer token value where OAuth 2.1 requires confidentiality (section 4.3 for the refresh token, section 1.4 for the bearer access token); the fixed state keeps it in a protected credential store and the scan reports `clean`. The pattern matches a token value (a JSON `"refresh_token": "..."` pair, a `refresh_token=` assignment with any nonempty printable value, or a `Bearer <token>` header), so the bare word `refresh_token` inside a `grant_types` list does not trip it. The assignment match is deliberately broad, so it can also flag a benign empty quoted assignment, which is the safe direction for a secret scan, and the scan lists filenames rather than printing the secret. It cannot see a token that is encrypted, wrapped, or split across fields, so read a `clean` result as "nothing obvious", not "nothing present".

5. **`application_type` is present on DCR (reasoned).** Prerequisite unavailable: the client's live DCR request. Capture the registration request body the client `POST`s to the DCR endpoint and confirm it includes `application_type` (`native` or `web` per step 3). A fixed native client's captured body looks like this (an illustrative shape, not a live capture):

   Illustrative native registration follows MCP Client Registration and OIDC Registration; no live DCR request is available.

   ```json
   {"redirect_uris":["http://localhost:3000/callback"],"grant_types":["authorization_code"],"response_types":["code"],"token_endpoint_auth_method":"none","application_type":"native"}
   ```

   Save the actual captured body as `dcr-request.json` and inspect it (this native client checks for `native`; a remotely-hosted browser client checks for `web` instead):

   The application_type inspection follows the cited MCP and OIDC registration requirements; no live DCR request is available. Python 3.14.4 ran the exact printed json.load/get expression with {}, {"application_type":"web"} and {"application_type":"native"} on stdin: exits 1, 1 and 0 respectively, with no output. That run invoked the expression without `-I`, in an earlier form of the block; no stub or live run has covered the `-I` form. json.loads also accepted the illustrative registration and metadata documents. These are local JSON controls, not a captured registration or server acceptance.

   ```bash
   (                                       # a subshell, so the exits below end only the subshell
     [ -f dcr-request.json ] || { echo "no dcr-request.json in this directory: save the captured registration body there first; not checking"; exit 2; }
     [ -r dcr-request.json ] || { echo "dcr-request.json is unreadable; not checking"; exit 2; }
     set -- "$(if python3 -I -c 'import json,sys; sys.exit(0 if json.load(sys.stdin).get("application_type") == "native" else 1)' < dcr-request.json 2>&1; then printf '\n0'; else printf '\n%s' "$?"; fi)"
     set -- "${1##*$'\n'}" "${1%$'\n'*}"   # python's exit status, then anything it printed
     printf '%s' "$2"
     case "$1:$2" in
       0:) echo "pass: application_type has the value the expression checks; block exit 0"; exit 0 ;;
       1:) echo "FINDING: application_type is absent, which the server defaults to web, or is not the value the expression checks; block exit 1"; exit 1 ;;
       *) echo "python3 exit $1: python3 failed or the body was not read as a JSON object (read any error above); block exit 3, inconclusive"; exit 3 ;;
     esac
   )
   ```

   Exposed: the field is absent and the server defaults it to `web` (OIDC Registration section 2), which under a provider policy that enforces the web redirect-URI constraints gets a native client's loopback or custom-scheme redirect rejected, so the command exits non-zero. Fixed: the field is present and matches the client's deployment, so the command exits zero. Distinguishing source: MCP's "MUST specify an appropriate `application_type`".

## Sources (checked September 2026)

- MCP Authorization, 2026-07-28 (`iss` validation timing, access-token query-string prohibition, `resource` parameter, refresh-token scope guidance): https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization
- MCP Authorization Security Considerations, 2026-07-28 (PKCE MUSTs, HTTPS endpoints and redirect URIs): https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization/security-considerations
- MCP Authorization Server Discovery, 2026-07-28 (`issuer` identity requirement): https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization/authorization-server-discovery
- MCP Client Registration, 2026-07-28 (CIMD SHOULD, mechanism preference, DCR `application_type` MUST): https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization/client-registration
- MCP Authorization, 2025-06-18 (authorization servers and MCP clients SHOULD support DCR; checked October 2026): https://github.com/modelcontextprotocol/modelcontextprotocol/blob/86f6e0c675afea9a8f233e09b6faf566b126086c/docs/specification/2025-06-18/basic/authorization.mdx#L58-L59
- MCP Authorization, 2025-11-25 (registration mechanisms and their SHOULD priority order; checked October 2026): https://github.com/modelcontextprotocol/modelcontextprotocol/blob/86f6e0c675afea9a8f233e09b6faf566b126086c/docs/specification/2025-11-25/basic/authorization.mdx#L198-L209
- MCP Security Best Practices, 2026-07-28 (SSRF MUST for server-deployed clients): https://modelcontextprotocol.io/docs/2026-07-28/tutorials/security/security_best_practices
- RFC 9207 section 2.4, OAuth 2.0 Authorization Server Issuer Identification (`iss` simple string comparison, reject on mismatch): https://www.rfc-editor.org/rfc/rfc9207.html#section-2.4
- RFC 9700 section 3, section 4.2, section 4.2.4, and section 4.4.2, OAuth 2.0 Security Best Current Practice (attacker-accessible stored or logged URLs; Referer leakage and its suppression; single-use `state`; mix-up attacks): https://www.rfc-editor.org/rfc/rfc9700.html#section-4.2.4
- RFC 8414 section 3.3, OAuth 2.0 Authorization Server Metadata (`issuer` identity): https://www.rfc-editor.org/rfc/rfc8414.html#section-3.3
- RFC 9728 section 3.1, section 3.3, section 7.7, and section 7.10, OAuth 2.0 Protected Resource Metadata (metadata GET request; `resource` validation; SSRF precautions; metadata caching): https://www.rfc-editor.org/rfc/rfc9728.html#section-7.7
- RFC 9111 section 4.2, HTTP Caching (a fresh cached response is served without contacting the origin): https://www.rfc-editor.org/rfc/rfc9111.html#section-4.2
- RFC 8707, Resource Indicators for OAuth 2.0 (`resource` parameter): https://www.rfc-editor.org/rfc/rfc8707.html
- RFC 7009 section 2, OAuth 2.0 Token Revocation (refresh-token revocation endpoint): https://www.rfc-editor.org/rfc/rfc7009.html#section-2
- OAuth 2.1 draft-ietf-oauth-v2-1-14 section 1.4, section 4.1.2, and section 4.3 (access-token confidentiality; authorization code in the redirect query; refresh-token confidentiality): https://datatracker.ietf.org/doc/html/draft-ietf-oauth-v2-1-14#section-4.3
- OAuth Client ID Metadata Document draft-ietf-oauth-client-id-metadata-document-00 (HTTPS client-id URL, matching `client_id`): https://datatracker.ietf.org/doc/html/draft-ietf-oauth-client-id-metadata-document-00
- OpenID Connect Core 1.0 errata 2 section 11, Offline Access (`prompt=consent`, `response_type` condition): https://openid.net/specs/openid-connect-core-1_0-errata2.html#OfflineAccess
- OpenID Connect Dynamic Client Registration 1.0 errata 2 section 2 (`application_type` default is `web`): https://openid.net/specs/openid-connect-registration-1_0-errata2.html#ClientMetadata
- OpenID Connect Discovery 1.0 errata 2 section 4.3 (`issuer` identity, ID Token `iss`, abort and non-use on failure; checked October 2026): https://openid.net/specs/openid-connect-discovery-1_0-errata2.html#ProviderConfigurationValidation
- OWASP Server Side Request Forgery Prevention Cheat Sheet (host allowlist, build the request yourself): https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- mcp: MCP (2026-07-28)
- mcp-2025-06-18: MCP 2025-06-18 authorization (86f6e0c675afea9a8f233e09b6faf566b126086c)
- mcp-2025-11-25: MCP 2025-11-25 authorization (86f6e0c675afea9a8f233e09b6faf566b126086c)
- rfc: OAuth and HTTP RFCs (unknown)
- oauth: OAuth 2.1 draft (draft-ietf-oauth-v2-1-14)
- cimd: CIMD draft (draft-ietf-oauth-client-id-metadata-document-00)
- oidc: OpenID Connect (1.0 errata 2)
- owasp: OWASP SSRF guidance (unknown)

Claims (full source mapping in the JSON block below):

- iss (REASONED; mcp, rfc): Compare received iss exactly with the transaction issuer before sending a code to any token endpoint; reject mismatches without normalization.
- iss-required (REASONED; rfc): If issuer-response support is advertised, missing iss is rejected; otherwise present iss is validated and absent iss still needs multi-AS mix-up protection.
- transaction (REASONED; rfc, mcp): Bind the validated expected issuer to the state/PKCE transaction; multi-AS clients MUST prevent mix-up attacks.
- issuer (REASONED; mcp, rfc): Authorization metadata issuer must exactly equal the issuer used to construct discovery, including its path; reject the document before using endpoints.
- resource-metadata (REASONED; rfc): Validate protected-resource resource separately from authorization-server issuer; issuer equality is not SSRF protection.
- oidc-discovery (REASONED; oidc, mcp): Apply OpenID Connect Discovery section 4.3 issuer validation to OIDC discovery (this guide's instruction): returned issuer MUST be identical to the Issuer URL used as the well-known prefix and to the iss Claim in ID Tokens issued from this Issuer; on failure, operations requiring that information MUST be aborted and the information MUST NOT be used.
- cimd (REASONED; cimd): CIMD client_id uses HTTPS with a path; document client_id must exactly match its URL.
- registration-order (REASONED; mcp): Clients SHOULD support CIMD and prefer available preregistration, then CIMD, then optional deprecated DCR.
- application-type (REASONED; mcp): DCR MUST specify appropriate application_type: native SHOULD cover desktop/mobile/CLI/localhost apps; web SHOULD cover remote browser apps.
- web-default (REASONED; oidc): Omitted application_type defaults to web; incompatible native redirects can be rejected under provider policy, without justification for weakening validation.
- registration-history (REASONED; mcp, mcp-2025-06-18, mcp-2025-11-25): MCP 2025-06-18 said authorization servers and MCP clients SHOULD support DCR; MCP 2025-11-25 said clients supporting all options SHOULD use available pre-registration, then advertised CIMD, then supported DCR, then ask the user if no other option is available. Carrying the revision label when citing that MCP registration history is this guide's advice.
- refresh-confidential (REASONED; oauth, rfc): Keep refresh tokens confidential in transit/storage, including public clients; send only to issuing-server token/revocation endpoints over authenticated TLS.
- refresh-storage (REASONED; oauth): Keep refresh tokens out of logs, URLs, repositories and public metadata; use protected storage or native credential storage.
- refresh-request (REASONED; mcp): SHOULD include refresh_token grant type; MAY request advertised offline_access; MUST NOT assume refresh-token issuance.
- offline-access (REASONED; oidc): OIDC offline_access requires code-returning response_type and normally prompt=consent; another permitting condition can waive consent prompting.
- ssrf (REASONED; rfc, mcp): RFC 9728 recommends SSRF precautions; server-deployed MCP clients MUST mitigate every OAuth-related fetch.
- ssrf-destinations (REASONED; mcp, rfc, owasp): Use HTTPS destination controls blocking private/reserved, loopback, link-local and metadata addresses; configure necessary private exceptions explicitly.
- ssrf-redirects (REASONED; mcp, rfc, owasp): Revalidate redirects and prevent DNS check/connect races with pinned resolution or controlled egress.
- ssrf-allowlist (REASONED; owasp, rfc): Known-provider issuer/destination allowlists narrow exposure; dynamic clients still need runtime controls, beyond issuer equality.
- pkce (REASONED; mcp): Require PKCE, S256 when capable, and refuse absent code_challenge_methods_supported.
- resource (REASONED; mcp, rfc): Send canonical resource URI in both authorization/token requests; replay protection also needs audience-bound issuance and server audience validation.
- https (REASONED; mcp): Use HTTPS authorization endpoints and localhost or HTTPS redirect URIs.
- token-url (REASONED; mcp, oauth, rfc): Access tokens go in Authorization, never URL queries; authorization codes use callback queries with PKCE/iss and referrer/log suppression.
- verify-iss (REASONED; rfc, mcp): Restore the same fresh transaction before matched callbacks; control redeems code, mismatched iss must cause no token request, independently of state replay.
- verify-metadata (REASONED; rfc, mcp): Fresh uncached complete metadata pair differs only in issuer; prove test fetch, disable alternative discovery, and reject endpoints from mismatched metadata.
- verify-address (REASONED; rfc, mcp): Local classifier should print BLOCK for all five internal addresses; guide says it ran but records no observed output, so no demonstration is established.
- verify-ssrf (REASONED; rfc, mcp): Trusted HTTPS public-address control must fetch; cleared-state private-address test must resolve and reject before connecting, with positive evidence beyond absent traffic.
- verify-secrets (REASONED; oauth): Filename-only token scan distinguishes findings, clean and errors; grant_types alone does not match, empty quoted assignments may, and clean is a bounded heuristic.
- verify-dcr (REASONED; mcp, oidc): Captured native DCR body must contain application_type native; omission/mismatch exits nonzero, correct value zero; illustrative JSON is not a live capture.

````json
{
  "schema": 1,
  "checked": "2026-10-17",
  "documentation_checked": "2026-09",
  "body_sha256": "fd628f4d9d0620375027743388242ab66b7d71d75e121bbccfd53055af5704d3",
  "components": {
    "mcp": {
      "name": "MCP",
      "basis": "2026-07-28",
      "sources": {
        "s34fabf499cb7": "https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization",
        "s4b9b953ca683": "https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization/security-considerations",
        "s117c3edbfcd7": "https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization/authorization-server-discovery",
        "s5655f61af2a0": "https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization/client-registration",
        "s4903497743e8": "https://modelcontextprotocol.io/docs/2026-07-28/tutorials/security/security_best_practices"
      }
    },
    "mcp-2025-06-18": {
      "name": "MCP 2025-06-18 authorization",
      "basis": "86f6e0c675afea9a8f233e09b6faf566b126086c",
      "sources": {
        "sf1432398aebf": "https://github.com/modelcontextprotocol/modelcontextprotocol/blob/86f6e0c675afea9a8f233e09b6faf566b126086c/docs/specification/2025-06-18/basic/authorization.mdx#L58-L59"
      }
    },
    "mcp-2025-11-25": {
      "name": "MCP 2025-11-25 authorization",
      "basis": "86f6e0c675afea9a8f233e09b6faf566b126086c",
      "sources": {
        "s9d3e60a1183b": "https://github.com/modelcontextprotocol/modelcontextprotocol/blob/86f6e0c675afea9a8f233e09b6faf566b126086c/docs/specification/2025-11-25/basic/authorization.mdx#L198-L209"
      }
    },
    "rfc": {
      "name": "OAuth and HTTP RFCs",
      "basis": "unknown",
      "sources": {
        "s93d8089abc7b": "https://www.rfc-editor.org/rfc/rfc9207.html#section-2.4",
        "s232609abe426": "https://www.rfc-editor.org/rfc/rfc9700.html#section-4.2.4",
        "sc1f199fd57ff": "https://www.rfc-editor.org/rfc/rfc8414.html#section-3.3",
        "s612208d893d8": "https://www.rfc-editor.org/rfc/rfc9728.html#section-7.7",
        "sb90ea9a3bb09": "https://www.rfc-editor.org/rfc/rfc9111.html#section-4.2",
        "s5cb9d8ac9518": "https://www.rfc-editor.org/rfc/rfc8707.html",
        "s45a67943085b": "https://www.rfc-editor.org/rfc/rfc7009.html#section-2"
      }
    },
    "oauth": {
      "name": "OAuth 2.1 draft",
      "basis": "draft-ietf-oauth-v2-1-14",
      "sources": {
        "sd99e74137366": "https://datatracker.ietf.org/doc/html/draft-ietf-oauth-v2-1-14#section-4.3"
      }
    },
    "cimd": {
      "name": "CIMD draft",
      "basis": "draft-ietf-oauth-client-id-metadata-document-00",
      "sources": {
        "sc6ba78bdbb90": "https://datatracker.ietf.org/doc/html/draft-ietf-oauth-client-id-metadata-document-00"
      }
    },
    "oidc": {
      "name": "OpenID Connect",
      "basis": "1.0 errata 2",
      "sources": {
        "s707464abc09b": "https://openid.net/specs/openid-connect-core-1_0-errata2.html#OfflineAccess",
        "s06760d0c8dc0": "https://openid.net/specs/openid-connect-registration-1_0-errata2.html#ClientMetadata",
        "sd8cd68f5f528": "https://openid.net/specs/openid-connect-discovery-1_0-errata2.html#ProviderConfigurationValidation"
      }
    },
    "owasp": {
      "name": "OWASP SSRF guidance",
      "basis": "unknown",
      "sources": {
        "s7eb820e1e53b": "https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html"
      }
    }
  },
  "claims": {
    "iss": {"text": "Compare received iss exactly with the transaction issuer before sending a code to any token endpoint; reject mismatches without normalization.", "components": ["mcp", "rfc"], "sources": ["mcp:s34fabf499cb7", "rfc:s93d8089abc7b"], "status": "REASONED"},
    "iss-required": {"text": "If issuer-response support is advertised, missing iss is rejected; otherwise present iss is validated and absent iss still needs multi-AS mix-up protection.", "components": ["rfc"], "sources": ["rfc:s93d8089abc7b", "rfc:s232609abe426"], "status": "REASONED"},
    "transaction": {"text": "Bind the validated expected issuer to the state/PKCE transaction; multi-AS clients MUST prevent mix-up attacks.", "components": ["rfc", "mcp"], "sources": ["rfc:s232609abe426", "mcp:s34fabf499cb7"], "status": "REASONED"},
    "issuer": {"text": "Authorization metadata issuer must exactly equal the issuer used to construct discovery, including its path; reject the document before using endpoints.", "components": ["mcp", "rfc"], "sources": ["mcp:s117c3edbfcd7", "rfc:sc1f199fd57ff"], "status": "REASONED"},
    "resource-metadata": {"text": "Validate protected-resource resource separately from authorization-server issuer; issuer equality is not SSRF protection.", "components": ["rfc"], "sources": ["rfc:s612208d893d8", "rfc:sc1f199fd57ff"], "status": "REASONED"},
    "oidc-discovery": {"text": "Apply OpenID Connect Discovery section 4.3 issuer validation to OIDC discovery (this guide's instruction): returned issuer MUST be identical to the Issuer URL used as the well-known prefix and to the iss Claim in ID Tokens issued from this Issuer; on failure, operations requiring that information MUST be aborted and the information MUST NOT be used.", "components": ["oidc", "mcp"], "sources": ["oidc:s707464abc09b", "mcp:s117c3edbfcd7", "oidc:sd8cd68f5f528"], "status": "REASONED"},
    "cimd": {"text": "CIMD client_id uses HTTPS with a path; document client_id must exactly match its URL.", "components": ["cimd"], "sources": ["cimd:sc6ba78bdbb90"], "status": "REASONED"},
    "registration-order": {"text": "Clients SHOULD support CIMD and prefer available preregistration, then CIMD, then optional deprecated DCR.", "components": ["mcp"], "sources": ["mcp:s5655f61af2a0"], "status": "REASONED"},
    "application-type": {"text": "DCR MUST specify appropriate application_type: native SHOULD cover desktop/mobile/CLI/localhost apps; web SHOULD cover remote browser apps.", "components": ["mcp"], "sources": ["mcp:s5655f61af2a0"], "status": "REASONED"},
    "web-default": {"text": "Omitted application_type defaults to web; incompatible native redirects can be rejected under provider policy, without justification for weakening validation.", "components": ["oidc"], "sources": ["oidc:s06760d0c8dc0"], "status": "REASONED"},
    "registration-history": {"text": "MCP 2025-06-18 said authorization servers and MCP clients SHOULD support DCR; MCP 2025-11-25 said clients supporting all options SHOULD use available pre-registration, then advertised CIMD, then supported DCR, then ask the user if no other option is available. Carrying the revision label when citing that MCP registration history is this guide's advice.", "components": ["mcp", "mcp-2025-06-18", "mcp-2025-11-25"], "sources": ["mcp:s5655f61af2a0", "mcp-2025-06-18:sf1432398aebf", "mcp-2025-11-25:s9d3e60a1183b"], "status": "REASONED"},
    "refresh-confidential": {"text": "Keep refresh tokens confidential in transit/storage, including public clients; send only to issuing-server token/revocation endpoints over authenticated TLS.", "components": ["oauth", "rfc"], "sources": ["oauth:sd99e74137366", "rfc:s45a67943085b"], "status": "REASONED"},
    "refresh-storage": {"text": "Keep refresh tokens out of logs, URLs, repositories and public metadata; use protected storage or native credential storage.", "components": ["oauth"], "sources": ["oauth:sd99e74137366"], "status": "REASONED"},
    "refresh-request": {"text": "SHOULD include refresh_token grant type; MAY request advertised offline_access; MUST NOT assume refresh-token issuance.", "components": ["mcp"], "sources": ["mcp:s34fabf499cb7"], "status": "REASONED"},
    "offline-access": {"text": "OIDC offline_access requires code-returning response_type and normally prompt=consent; another permitting condition can waive consent prompting.", "components": ["oidc"], "sources": ["oidc:s707464abc09b"], "status": "REASONED"},
    "ssrf": {"text": "RFC 9728 recommends SSRF precautions; server-deployed MCP clients MUST mitigate every OAuth-related fetch.", "components": ["rfc", "mcp"], "sources": ["rfc:s612208d893d8", "mcp:s4903497743e8"], "status": "REASONED"},
    "ssrf-destinations": {"text": "Use HTTPS destination controls blocking private/reserved, loopback, link-local and metadata addresses; configure necessary private exceptions explicitly.", "components": ["mcp", "rfc", "owasp"], "sources": ["mcp:s4903497743e8", "rfc:s612208d893d8", "owasp:s7eb820e1e53b"], "status": "REASONED"},
    "ssrf-redirects": {"text": "Revalidate redirects and prevent DNS check/connect races with pinned resolution or controlled egress.", "components": ["mcp", "rfc", "owasp"], "sources": ["mcp:s4903497743e8", "rfc:s612208d893d8", "owasp:s7eb820e1e53b"], "status": "REASONED"},
    "ssrf-allowlist": {"text": "Known-provider issuer/destination allowlists narrow exposure; dynamic clients still need runtime controls, beyond issuer equality.", "components": ["owasp", "rfc"], "sources": ["owasp:s7eb820e1e53b", "rfc:s612208d893d8"], "status": "REASONED"},
    "pkce": {"text": "Require PKCE, S256 when capable, and refuse absent code_challenge_methods_supported.", "components": ["mcp"], "sources": ["mcp:s4b9b953ca683"], "status": "REASONED"},
    "resource": {"text": "Send canonical resource URI in both authorization/token requests; replay protection also needs audience-bound issuance and server audience validation.", "components": ["mcp", "rfc"], "sources": ["mcp:s34fabf499cb7", "rfc:s5cb9d8ac9518"], "status": "REASONED"},
    "https": {"text": "Use HTTPS authorization endpoints and localhost or HTTPS redirect URIs.", "components": ["mcp"], "sources": ["mcp:s4b9b953ca683"], "status": "REASONED"},
    "token-url": {"text": "Access tokens go in Authorization, never URL queries; authorization codes use callback queries with PKCE/iss and referrer/log suppression.", "components": ["mcp", "oauth", "rfc"], "sources": ["mcp:s34fabf499cb7", "oauth:sd99e74137366", "rfc:s232609abe426"], "status": "REASONED"},
    "verify-iss": {"text": "Restore the same fresh transaction before matched callbacks; control redeems code, mismatched iss must cause no token request, independently of state replay.", "components": ["rfc", "mcp"], "sources": ["rfc:s93d8089abc7b", "mcp:s34fabf499cb7", "rfc:s232609abe426"], "status": "REASONED"},
    "verify-metadata": {"text": "Fresh uncached complete metadata pair differs only in issuer; prove test fetch, disable alternative discovery, and reject endpoints from mismatched metadata.", "components": ["rfc", "mcp"], "sources": ["rfc:sc1f199fd57ff", "rfc:sb90ea9a3bb09", "mcp:s4b9b953ca683"], "status": "REASONED"},
    "verify-address": {"text": "Local classifier should print BLOCK for all five internal addresses; guide says it ran but records no observed output, so no demonstration is established.", "components": ["rfc", "mcp"], "sources": ["rfc:s612208d893d8", "mcp:s4903497743e8"], "status": "REASONED", "verify": [1]},
    "verify-ssrf": {"text": "Trusted HTTPS public-address control must fetch; cleared-state private-address test must resolve and reject before connecting, with positive evidence beyond absent traffic.", "components": ["rfc", "mcp"], "sources": ["rfc:s612208d893d8", "rfc:sb90ea9a3bb09", "mcp:s4903497743e8"], "status": "REASONED"},
    "verify-secrets": {"text": "Filename-only token scan distinguishes findings, clean and errors; grant_types alone does not match, empty quoted assignments may, and clean is a bounded heuristic.", "components": ["oauth"], "sources": ["oauth:sd99e74137366"], "status": "REASONED", "verify": [2]},
    "verify-dcr": {"text": "Captured native DCR body must contain application_type native; omission/mismatch exits nonzero, correct value zero; illustrative JSON is not a live capture.", "components": ["mcp", "oidc"], "sources": ["mcp:s5655f61af2a0", "oidc:s06760d0c8dc0"], "status": "REASONED", "verify": [3]}
  }
}
````
<!-- version-basis:end -->
