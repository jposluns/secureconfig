# PaaS platforms: what the platform does, what stays yours

Render, Fly.io, Railway, Vercel, Heroku and Hugging Face Spaces host your app and handle parts of running it, such as HTTPS. This guide helps your AI assistant deploy securely, including what each platform's TLS covers, authentication that stays yours, and backend secrets kept server-side, never in a Static Space.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/paas.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Render documentation (no recorded version), Next.js pinned documentation v16.4.2, Next.js environment variables 15, Express request protocol 5.x, Django proxy security setting 6.1, MySQL client connection options 8.4, and curl curl-8_14_1; 3 further sources are pinned to a commit and 4 carry no recorded version. Metadata reviewed 2026-10-22; documentation checked September 2026. The guide records 24 claims, all reasoned from cited sources and any earlier-form run, not a live demonstration of the shipped form.

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

TLS responsibilities depend on the platform and deployment mode:

- Render: the load balancer terminates HTTPS for web services and forwards HTTP to the app. Render automatically issues and renews certificates for added custom domains, including wildcards. Add the domain, configure DNS, and verify it in the dashboard. Wildcards require the root domain to point to Render and the prescribed wildcard, `_acme-challenge`, and `_cf-custom-hostname` CNAME records; existing CAA records must allow Let's Encrypt and Google Trust Services, with `issuewild` records for wildcards. At the time of writing, included custom-domain quotas depend on the workspace plan and additional domains cost extra.
- Fly.io: Fly Proxy's `tls` handler terminates TLS and forwards plaintext; without handlers, TCP passes through and the app can terminate TLS itself. Add the custom domain and configure DNS for automatic certificate issuance. Issuance and renewal require domain verification through an AAAA record pointing to the app, an `_acme-challenge` CNAME, or a `_fly-ownership` TXT record; wildcard certificates require DNS-01 with the `_acme-challenge` CNAME. This guide's assessment: these passages describe managed certificates and renewal prerequisites but do not explicitly establish automatic renewal. Fly's current custom-domain page says Fly.io needs that verification "To issue or renew a certificate", automatically validates ownership and issues certificates once DNS is configured, and notes that renewals do not count against Let's Encrypt's Certificates per Registered Domain limit. This guide's assessment: that page also does not explicitly state automatic renewal, renewal timing or renewal-failure handling. Fly's pinned Cloudflare page, under custom certificate issues, says: "Unlike Let's Encrypt certificates, which renew automatically, custom certificates must be manually renewed and re-imported before they expire." This guide's reading: the pinned custom-domain page calls Fly-managed certificates Let's Encrypt certificates, so this documents their automatic renewal; it states no renewal timing or renewal-failure handling. Fly's pinned Certificates resource page says Fly.io "can automatically issue Let's Encrypt certificates (ACME)" and, when a custom certificate also exists for a hostname, that "the ACME certificate acts as an automatic fallback". This guide's assessment: that file, read whole, states no renewal timing or renewal-failure handling either. Imported certificates require ownership verification and take priority over a coexisting Fly-managed fallback.
- Railway: correctly configured custom domains receive automatically issued Let's Encrypt certificates, renewed with 30 days of their 90-day validity remaining; external certificates are unsupported. Both the supplied CNAME and ownership TXT records are required; wildcards also require the `_acme-challenge` CNAME, unproxied on Cloudflare. Root domains require CNAME flattening or dynamic ALIAS records. At the time of writing, custom-domain limits are one on Trial, two per service on Hobby and twenty per service by default on Pro, with increases available on request; Freenom domains are unsupported. For Cloudflare-proxied domains, issuance can fail and Railway can instead serve its default `*.up.railway.app` certificate; the docs require Full mode and warn that Full (Strict) will not work as intended. Cloudflare proxying below first-level subdomains requires Advanced Certificate Manager or switching those records to DNS Only. Railway's edge proxy (tcp-proxy) terminates TLS; traffic is then forwarded over Railway's internal network to the deployment ([request flow](https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/edge-networking.md#L40-L43)).
- Vercel: its CDN terminates TLS. Certificates for deployment URLs are generated and kept updated automatically. Custom-domain issuance requires successful validation after DNS propagation; non-wildcards use HTTP-01 reachable at Vercel, and wildcards require Vercel nameservers for DNS-01. Vercel automatically attempts renewal 14 to 30 days before expiry; correct DNS, proxy, and CAA configuration must still permit validation. At the time of writing, only Enterprise teams can configure custom SSL; uploaded certificates cannot be renewed automatically by Vercel. The `/.well-known` path is reserved and cannot be redirected or rewritten.
- Heroku: the HTTP routing page describes load-balancer SSL termination, with separate Private Spaces routers. At the time of writing, ACM is included free for all applications; enable it for automatic issuance and renewal one month before expiry, using the correct Heroku DNS target. Adding custom domains requires a verified Heroku account. Cedar Private Spaces require a running web dyno for validation and renewal, cannot use ACM with Trusted IPs blocking access, and cannot use ACM for wildcard domains. On wildcards, the page says "You must also upload your own wildcard certificate for Private Space apps." and points to add-ons "If you want to automatically renew a wildcard certificate on a Private Space app"; neither statement names a generation. Its limitations say "Cedar generation Private Space apps using ACM can’t have wildcard domains. For Generation Private Space apps can use ACM with wildcard domains." This guide's assessment: the three statements agree for Cedar Private Spaces; for the other generation, which the page calls "For Generation" and which probably means Fir, the last sentence conflicts with the two unqualified statements, so Fir wildcard eligibility remains unresolved. When checked in October 2026, the Generations page's Feature Parity table, with columns Fir and Cedar, marked "Heroku ACM wildcard domains" with an X in both. This guide's assessment: since that page says "Fir is now generally available with Fir Private Spaces", the Fir mark supports the ACM page's other-generation sentence, but it withdraws neither unqualified statement, so the conflict remains. The same page says "Both the Common Runtime and Private Spaces run on the Cedar generation of the platform." Its Feature Parity table's Cedar column also marks the "Common Runtime" row, and the Internal routing, VPC peering, VPN support and Private Spaces DNS Service Discovery rows, where Fir has To Be Added; the Private Spaces page lists those four features under "Additional Features for Cedar Private Spaces". No cited page says whether the Cedar wildcard mark covers Cedar Private Spaces. This guide's assessment: the Common Runtime row's mark cannot describe a Private Space, so a Cedar mark records a feature of the Cedar Common Runtime, of Cedar Private Spaces or of both, and the wildcard mark establishes no conflict with the ACM page's Cedar Private Spaces limitation, which this guide keeps as the governing statement. When checked on 2026-11-04, the ACM page, last updated July 07, 2026, still carried that limitations sentence, and the Generations page, last updated September 11, 2026, still marked Fir for "Heroku ACM wildcard domains". Heroku's Understanding TLS on Heroku page, last updated September 30, 2024, lists "Private Space apps using wildcard domains" under what ACM does not support and says "Note that ACM doesn’t support wildcard domains for Private Spaces", naming no generation. Heroku's Acquiring an SSL Certificate page, also last updated September 30, 2024, says "If you want to use a different certificate authority for your application or a wildcard certificate on a Private Space app, follow these steps to acquire a certificate manually." and names no generation. This guide's assessment: the Understanding TLS page's note conflicts with the ACM page's other-generation sentence and the Generations page's Fir mark, and so does the Acquiring page's conditional advice, read without a generation exception, so Fir Private Space wildcard eligibility for ACM remains conflicting across the pages named. Uploading a certificate disables ACM. The ACM page's "Known limitations" list also says "ACM does not support IPv6 AAAA DNS records." and "ACM is not compatible with internal routing." CAA must permit Let's Encrypt, and DNS/CDN configuration must allow validation; ACM must be disabled if the app requires the platform-handled ACME challenge paths.

This guide's advice: where the platform terminates TLS and manages the required certificate, do not bolt certbot or an extra TLS reverse proxy onto the app, and do not apply this repository's server-TLS guides to that managed ingress. What stays yours:

## 1. Authentication: entirely yours

The platform does not authenticate your application's users. Some platforms protect the deployment itself: Vercel Deployment Protection, for example, can require a Vercel login to open preview and deployment URLs on every plan, and production domains too once the All Deployments scope is selected, which Vercel's changelog of 9 September 2026 made free on every plan including Hobby. Vercel's Password Protection is not available on Hobby, is a paid add-on per protected project on Pro, and is included on Enterprise (at the time of writing). Vercel Deployment Protection keeps the public out of a preview; it is not your app's login. Every non-public endpoint still needs login or keys per [authentication.md](authentication.md), MFA where viable per [mfa.md](mfa.md), and a hosted provider makes both easy ([identity-providers.md](identity-providers.md)). "It is on Vercel" changes nothing about an open `/api/admin`.

## 2. Secrets: use the platform's store

Each platform provides environment/secret configuration. Set secrets there; never commit `.env` files ([secrets.md](secrets.md)). Rotate anything that ever appeared in the repository, build logs, or client bundles. Public frontend frameworks compile some env vars into the client (for example `NEXT_PUBLIC_`-prefixed values); only put genuinely public values in those.

## 3. Enforce HTTPS and correct proxy awareness

- Redirect HTTP to HTTPS. This guide's advice: use the documented automatic redirect, enable the documented platform setting, or implement the redirect in the app with verified proxy trust:
  - Render's TLS page says all HTTP requests are automatically redirected to HTTPS, and its custom-domains page says the same for custom-domain traffic; neither states the HTTP-to-HTTPS status code. Its static-site redirect rules document 301 for moving a request to a rule's destination. This guide's assessment: that is a separate feature and does not establish the HTTP-to-HTTPS status.
  - Fly.io's pinned configuration reference documents `force_https = true` under `[http_service]` in `fly.toml` for apps managed by Fly Launch. The pinned services page says enabling `force_https` returns 301 for all HTTP requests; the option is only valid on HTTP handlers, and deployment fails if it is set on other handlers.
  - Railway's pinned public-networking specifications describe automatic HTTPS redirects for plain HTTP GET requests with 301, and HTTP POST redirects that convert the request to GET ([GET status and POST conversion](https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/public-networking/specs-and-limits.md#L37-L38)). This guide's assessment: these GET/POST statements establish no configurable redirect toggle, POST status code or HEAD response used below. Railway's pinned 405 troubleshooting page explains that a POST request can reach the application as a GET because, when the request is made using HTTP, "Railway will attempt to redirect your insecure request with a 301 Moved Permanently status code", and clients typically change POST to GET when they follow it ([POST redirect status](https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/troubleshooting/405-method-not-allowed.md#L8-L18)). This guide's reading: that page documents 301 for an HTTP POST and attributes the change to GET to the client; the cited passage establishes no HEAD response or redirect toggle. The pinned specifications page instead says HTTP POST requests to port 80 "are redirected to HTTPS as GET requests" ([request handling](https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/public-networking/specs-and-limits.md#L16-L17)) and that plain HTTP POST requests "will be converted to GET requests" ([POST conversion](https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/public-networking/specs-and-limits.md#L37-L38)). This guide's assessment: unlike the 405 page, that page does not attribute the change to GET to the client, and this guide does not establish which description is right.
  - Vercel's encryption page says its CDN automatically redirects HTTP requests to HTTPS with 308 and that this redirection cannot be disabled.
  - Heroku's ACM page says that, when ACM is enabled, the platform handles `/.well-known/acme-challenge/*` URLs, redirected away from the app, and requires disabling ACM if the app needs those paths. This guide's assessment: that path handling and the cited HTTP routing page establish none of the following: a general HTTP-to-HTTPS redirect policy, a redirect toggle, an application-only redirect contract, or a status code. Heroku's help article "Can Heroku force an application to use SSL/TLS?" says: "Redirects need to be performed at the application level as the Heroku router does not provide this functionality." The article names no Heroku generation or runtime; this guide's assessment: applying it to every Heroku generation and runtime is an inference. Heroku's ASP.NET Core configuration page says "Heroku doesn’t automatically redirect HTTP requests to HTTPS.", and its example configuration sets `options.RedirectStatusCode = StatusCodes.Status308PermanentRedirect;`. This guide's assessment: 308 is that example's choice, not a status the Heroku platform sends. This guide's advice: implement application-side redirection unless the deployed ingress is known to enforce HTTPS, and verify the result.

  For application-side handling, this guide's advice is to check the platform's forwarded-protocol header only after verifying the framework's proxy trust requirements. Fly's HTTP handler documents `X-Forwarded-Proto` as the original client protocol, `http` or `https`; Railway's public-networking specifications say it always indicates `https`. Heroku's routing page describes it as the originating protocol but explicitly warns that forwarded headers, including `X-Forwarded-Proto`, are not trusted because the order of pre-existing fields is unknown. Fly's pinned request-headers page says request headers "are added by the HTTP handler service" and describes `X-Forwarded-Proto` as "The protocol which the client used to make the request."; this guide's assessment: it does not say whether Fly overwrites, removes or passes through a value the client sent. These descriptions do not establish header sanitization; the cited Render and Vercel TLS pages do not establish a forwarded-protocol header contract. Vercel's request-headers page describes `x-forwarded-proto` as the protocol of the forwarded server, typically `https` in production and `http` in development. It also says that, when Vercel is used behind a proxy, Vercel currently overwrites `X-Forwarded-For` and does not forward external IPs, to prevent IP spoofing; this guide's assessment: it states no such overwrite for `x-forwarded-proto`, so it does not establish that header's sanitization. The page adds that Enterprise customers can purchase and enable a trusted proxy to allow a custom `X-Forwarded-For` IP. Heroku's help article, which names no generation or runtime, says: "Under the hood, Heroku router (over)writes the `X-Forwarded-Proto` and the `X-Forwarded-Port` request headers." Heroku's HTTP routing page still says the `X-Forwarded-For`, `X-Forwarded-By`, `X-Forwarded-Proto` and `X-Forwarded-Host` headers "are not trusted for security reasons". This guide's assessment: the two Heroku pages are not reconciled, so this guide's advice stands: trust `X-Forwarded-Proto` only after verifying the framework's proxy trust requirements. Render's TLS, Web Services and Custom Domains pages, web-services tutorial and authentication and FastAPI production articles, and Vercel's request-headers, encryption and reverse-proxy pages, searched on 2026-11-04 and listed in Sources, do not say whether either platform overwrites, removes or passes through an `X-Forwarded-Proto` value the client sent. This guide's assessment: not finding it in those pages does not establish that either platform documents no such handling. Keep the Express 5.x `trust proxy` and Django 6.1 `SECURE_PROXY_SSL_HEADER` trust requirements in view when implementing this guide's advice.
- Behind the platform proxy, configure the framework accordingly (`trust proxy` in Express per [nodejs.md](nodejs.md), `SECURE_PROXY_SSL_HEADER` in Django per [python.md](python.md)) so secure cookies and redirects behave.
- Bind the listener required by the deployment model. Render web services must bind `0.0.0.0`; Render recommends `PORT` (default port 10000, configurable), can usually detect another bound port, and requires the public HTTP server to use `PORT` when multiple ports are bound. Fly Proxy HTTP services must be reachable over IPv4: use `0.0.0.0` and match the service's configured `internal_port` to the app listener; IPv4-mapped IPv6 wildcard behaviour depends on the VM and runtime. Railway domains route to a detected or selected internal target port; its troubleshooting page says web servers should bind `0.0.0.0` and listen on the automatically injected `PORT` ([listener and port](https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/troubleshooting/application-failed-to-respond.md#L46-L51)). Heroku assigns web processes a `PORT` environment variable: its runtime-principles page says each web process binds to that port and listens for requests on it, and its Node.js deployment page says the web process command must bind to that port or the dyno does not start. For Fir, the Generations page says Private Spaces networking uses IPv6 by default, that IPv4-only assumptions do not bind properly, and recommends an IPv6 or dual-stack listener (typically `::`); the cited pages do not establish Cedar's listener address. Vercel runtimes transform code into Functions served by its CDN, including Node.js function entrypoints and Python ASGI/WSGI apps; that page establishes neither a universal injected port nor a required listener address. Vercel's Functions overview shows functions as exported `fetch` or HTTP-method handlers and says each incoming request is a new invocation with no servers to manage. This guide's assessment: that overview states no listener address or port either. When checked in October 2026, Vercel's Express page said the Express entry file "must also export the application as a default export of the module or use a port listener", showing the `app.listen` pattern with an example port of 3000, and its Python runtime page described the entrypoint as "the file and top-level variable that Vercel loads as the Vercel Function handler". This guide's assessment: neither page states a required listener address or a port Vercel uses, and the example port is not a requirement. When checked on 2026-11-04, the Express page, last updated August 10, 2026, said "You may also run your application using the `app.listen` pattern that exposes the server on a port." That page does not say which address or port the deployed function listens on, or whether Vercel connects to that socket. Vercel's Express, Python runtime, Functions runtimes, Functions and Backends pages, searched on 2026-11-04 and listed in Sources, state neither. This guide's assessment: not finding it in those pages does not establish that Vercel documents neither. This guide's advice: bind nothing else and do not open extra listeners.

## 4. Databases attached to PaaS apps

Managed databases from these platforms come with TLS endpoints, but check what the specific endpoint supports: require certificate and hostname verification with the client's own setting (`sslmode=verify-full` for PostgreSQL, `--ssl-mode=VERIFY_IDENTITY` for MySQL) per the database guides ([postgresql.md](postgresql.md), [mysql.md](mysql.md)) where the endpoint allows it. The endpoint check is also to note that some managed internal endpoints support encryption but not `verify-full` (Render's internal PostgreSQL connections, where TLS is optional, do not support `verify-ca`/`verify-full`). The step for those endpoints that support encryption but not `verify-full` is to set `sslmode=require` to force encryption and prevent a plaintext fallback, and not to treat that encryption-only connection as identity-verified. Keep the credentials in the platform's secret store, and restrict the network too: many managed databases are reachable from any IP by default (Render's Postgres is), so prefer private connectivity and disable or source-restrict external access with the provider's database network controls, not TLS alone. Databases you run yourself elsewhere follow their own guides plus [cloud-firewalls.md](cloud-firewalls.md).

## 5. Hugging Face Spaces

This guide's advice: explicitly select and verify visibility when you create a Space. The pinned docs describe public, protected, and private visibility; public visibility exposes both the source and the running app, and duplicating a Space defaults to private. At the time of writing, the pinned Advanced Security docs attach repository visibility controls to Team & Enterprise organizations: Public by default creates new repositories with public visibility; Private by default creates new repositories with private visibility; Private only enforces private visibility for all new repositories. The same pinned Advanced Security docs, at the time of writing, also say that changing the Private by default setting does not affect existing repositories and that, under Private only, organization admins are the only ones able to change visibility settings. Those lines do not establish a general creation default or a retroactive conversion of existing repositories by Private only. Visibility can be changed to "protected" (the source stays private to the owner and collaborators, but the running app is still public through its embed URL or custom domain) or "private" (both the source and the running app are restricted to the owner and collaborators). Protected visibility requires a paid plan, PRO for personal accounts or Team/Enterprise for organizations, at the time of writing. Space secrets belong in the Settings tab's secrets store, never in the repository or its README metadata; anything set as a "variable" instead of a "secret" is still publicly readable. That secrets store is not a safe place for backend or provider credentials on a Static Space: Hugging Face exposes both variables and secrets to client-side JavaScript there, through `window.huggingface.variables`, so anything placed in a Static Space's secrets still reaches the browser. Keep server-side credentials in a server-side service, such as a Docker or Gradio Space or a separate backend, instead.

At the time of writing, the pinned Dev Mode docs require PRO or Team & Enterprise. The Dev Mode Docker image starts the application as a subprocess and starts an SSH server for local editors and terminals and a VS Code server for in-product VS Code Web. Dev Mode exposes the running Space as a standard SSH host; clients use the Space subdomain shown in the Dev Mode controls as the username at ssh.hf.space, and local VS Code uses Remote - SSH to connect to the same host. SSH requires adding the machine's SSH public key to the user's Hugging Face account; these docs do not establish which users or roles may connect, or the access control for in-product VS Code Web. This guide's assessment: access into the running container is materially more access than the app itself, so treat an unattended Dev Mode session the same as any other exposed admin path. For serverless GPU platforms, see [gpu-clouds.md](gpu-clouds.md).

## 6. Verify

REASONED: HTTPS redirect, application-authentication and deployed-secret checks; no PaaS application, tenant credentials or deployed client bundle was supplied for this metadata review, and no live run is recorded. The redirect and unauthenticated-request checks take the app's host name on guarded `set --` lines that refuse example.com, example.net, example.org and their subdomains, and the unauthenticated-request check takes its protected path on the same line. No run of the guards on the form before this change, which lowercased the host and the redirect's headers with `tr` and deleted the headers' spaces and tabs with a second `tr`, was recorded before 2026-11-01; curl-stub runs of it that day refused the reserved spellings with `tr` present, and with `tr` absent or failing refused none, probed the reserved name and reported a finding. The current form refuses a reserved name, and matches the Location header, under bash's `nocasematch` option, and deletes the spaces and tabs with bash expansions, instead of through `tr`; each part refuses with 2, saying the block needs bash, when `shopt` fails, as it does in dash. It is covered by the gate suite's bash -n and ShellCheck 0.11.0 passes and by curl-stub runs on 2026-11-01 with no network. In bash, each part refused `example.com`, `EXAMPLE.NET`, `App.Example.COM`, `api.EXAMPLE.org` and seven other reserved spellings with 2 and no curl call, also with `tr` absent from PATH or failing and under an inherited `nocasematch`, `readonly`, `declare -i` or `set -e`, and a host name outside the reserved names reached both probes. In those runs a 301 whose Location header read `LOCATION:` and a tab before `HTTPS://`, or `location :` and spaces and a tab before `https://`, passed, also with `tr` absent or failing, while a 301 with an http:// Location or with no Location line was a finding. The redirect part unsets LC_ALL and sets LC_ALL=C inside its subshell just before the Location match, because `nocasematch` folds case through the locale and a Turkish or Azerbaijani locale does not fold `I` to `i`; the C locale folds A to Z only, so `location:` matches in any letter case in every locale, and a non-ASCII letter must match exactly. If LC_ALL is read-only, that part says so and exits 2 instead of classifying the redirect; both arms of the match end the part, so no later command runs in that locale. In stub runs on 2026-11-01 without the LC_ALL lines, LC_ALL=tr_TR.UTF-8 or LANG=tr_TR.UTF-8 turned a 301 whose header read `LOCATION: https://` into a finding. With them, that 301 passed under C, C.UTF-8 and both Turkish settings, also under an inherited `nocasematch` or `set -e`, while an http:// Location stayed a finding and a read-only LC_ALL gave 2 and its message. Under dash, each part refused every host name with 2 and the bash message before its probe, and the block exited 2. The expected readings below follow the cited platform documentation and the guide's application-security reasoning; exact application behaviour remains deployment-specific.

```bash
# 1. This guide checks HTTP->HTTPS redirection. Spot-check on / only: it does not prove HTTPS on every route/method, nor that
#    the app's proxy-awareness (section 3) is set for secure cookies. --noproxy so a client proxy cannot answer.
#    Documented: Vercel 308; Fly HTTP handlers with force_https enabled 301. Render's HTTPS code is unstated; its static-rule 301 differs.
#    Railway's specifications page documents GET 301 and its 405 troubleshooting page a 301 for HTTP POST that
#    clients typically follow as GET; neither page's cited passages document this HEAD response. This guide's assessment:
#    Heroku's ACM challenge-path handling establishes no general HTTPS redirect policy, setting, application-only responsibility or status.
#    Heroku's SSL/TLS help article, which names no generation or runtime, says redirects need to be performed at the
#    application level, as its router does not provide them; its ASP.NET Core page says Heroku does not redirect HTTP to
#    HTTPS automatically, and that page's 308 is its example's choice.
#    This guide's check: require 301/302/307/308 with an https:// Location; HTTP content without that redirect fails.
(                                       # the whole block in one subshell, so one exit status covers every part of it
  set +e                                # errexit off here, so a part that ends nonzero is folded into the status below instead of ending the block
  set -- 0                              # the block's status so far: 1 (a finding) outranks 3 (inconclusive), which outranks 2 (a part refused its input), which outranks 0
  (                                     # a subshell, so your own script arguments are untouched
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_APP_HOST'   # the public host name your platform serves the app on, no scheme, user name, port, path, query, fragment, percent sign or trailing dot: replace inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not probing"; exit 2; }
    case "$1" in
      ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
    case "$1" in
      example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -u nocasematch   # every match below compares letter case exactly again
    set -- "$1" "$(if curl -q -g -sSI --noproxy '*' -w 'http=%{http_code}\n' "http://$1/"; then printf '\n0'; else printf '\n%s' "$?"; fi)"   # this guide's redirect check above; -S makes curl show an error message if it fails despite -s (cited curl show-error). This guide's assessment: http=000 beside a "curl: (N) ..." error line means no HTTP response arrived: inconclusive, not a pass or a fail
    set -- "$1" "${2##*$'\n'}" "${2%$'\n\n'*}"   # curl's exit status, then the headers and the http= line
    set -- "$1" "$2" "$3" "${3##*$'\n'}"         # the same values, then the http= line alone
    printf '%s\n' "$3"
    case "$2:$4" in
      0:http=301|0:http=302|0:http=307|0:http=308)
        set -- "$1" "$2" "${3// /}" "$4"   # the headers with their spaces deleted by a bash expansion, not an outside command
        { unset -v LC_ALL; } 2>/dev/null || { echo "LC_ALL is read-only in this shell, so the Location header cannot be matched; not classifying the redirect"; exit 2; }
        LC_ALL=C   # nocasematch folds case by locale, and the C locale folds A to Z only, as header names need
        shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # header names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail; both of its arms end this part's subshell, and the option with it
        case "${3//$'\t'/}" in   # the headers with their tabs deleted too, so any spaces and tabs may follow location:
          *$'\n''location:https://'*) exit 0 ;;
          *) echo "FINDING: a ${4#http=} redirect without an https:// Location, which this guide's check requires"; exit 1 ;;
        esac ;;
      0:http=000) echo "http=000: no HTTP response arrived; inconclusive"; exit 3 ;;
      0:*) echo "FINDING: HTTP ${4#http=} instead of a 301, 302, 307 or 308 with an https:// Location, so HTTP content is served without that redirect"; exit 1 ;;
      *) echo "curl exit $2: the redirect request failed; inconclusive"; exit 3 ;;
    esac
  )
  case "$?:$1" in 0:*) ;; 1:*) set -- 1 ;; 2:0) set -- 2 ;; 2:*|*:1) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  # 2. Your APP's own auth must reject an unauthenticated request, NOT the platform deployment-protection gate.
  #    Vercel documents that Deployment Protection requires authentication for all requests, and that a valid
  #    Protection Bypass for Automation token lets the request access the deployment without authentication,
  #    sent as the x-vercel-protection-bypass HTTP header or query parameter carrying the project's generated
  #    secret. Disable deployment protection (or use that bypass) so only application auth is in play. That
  #    bypass is Vercel's; no Render or Fly equivalent is cited here, so do not assume one exists. If you use
  #    the bypass secret, send it as the header, supplied from a file with -H @file per this guide's
  #    conventions so it stays out of shell history; the query-parameter form writes it into history and logs.
  #    The status codes below are this guide's expected reading; the cited pages state none, including for the
  #    platform gate's own challenge (its SSO 401 below):
  (                                     # a subshell, so your own script arguments are untouched
    set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_YOUR_APP_HOST' 'REPLACE_WITH_PROTECTED_PATH'   # the same app host name as the redirect check above (no scheme, user name, port, path, query, fragment, percent sign or trailing dot), then a protected route without its leading slash: replace inside the quotes, keeping them
    [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
    shift
    [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
    case "$1" in
      ""|*REPLACE_WITH_*|*/*|*:*|*.|*[@?%]*|*'#'*|*[[:space:][:cntrl:]]*) echo "substitute your public host name (no scheme, user name, port, path, query, fragment, percent sign or trailing dot) inside the quotes on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -s nocasematch || { echo "this block needs bash; run it in bash; not probing"; exit 2; }   # host names ignore letter case, so this case matches them in any case through a bash option, not an outside command that could fail
    case "$1" in
      example.com|example.net|example.org|*.example.com|*.example.net|*.example.org) echo "example.com, example.net, example.org and their subdomains are not your deployment: substitute your own host name on the set -- line above; not probing"; exit 2 ;;
    esac
    shopt -u nocasematch   # every match below compares letter case exactly again
    case "$2" in
      ""|*REPLACE_WITH_*|/*|*[[:space:][:cntrl:]]*) echo "substitute a protected path, without its leading slash, inside the quotes on the set -- line above; not probing"; exit 2 ;;
    esac
    set -- "$1" "$2" "$(if curl -q -g -sS --noproxy '*' -o /dev/null -w 'http=%{http_code}\n' "https://$1/$2"; then printf '\n0'; else printf '\n%s' "$?"; fi)"  # no creds: want the APP's own 401/403, not a platform SSO 401; -S makes curl show an error message if it fails despite -s (cited curl show-error). This guide's assessment: http=000 beside a "curl: (N) ..." error line means no HTTP response arrived: inconclusive, not a rejection
    set -- "$1" "$2" "${3##*$'\n'}" "${3%%$'\n'*}"   # curl's exit status, then the http= line
    printf '%s\n' "$4"
    case "$3:$4" in
      0:http=2??) echo "FINDING: $2 answered ${4#http=} with no credentials, so nothing rejected the unauthenticated request"; exit 1 ;;
      0:http=000) echo "http=000: no HTTP response arrived; inconclusive, not a rejection"; exit 3 ;;
      0:*) echo "unclassified observation: ${4#http=} with no credentials; a 401 or 403 is the pass only if your app sent it, not a platform SSO gate, so judge which did"; exit 0 ;;
      *) echo "curl exit $3: the unauthenticated request failed; inconclusive"; exit 3 ;;
    esac
  )
  case "$?:$1" in 0:*) ;; 1:*) set -- 1 ;; 2:0) set -- 2 ;; 2:*|*:1) ;; *) set -- 3 ;; esac   # fold that part's status into the block's, ranked as above
  #    Then repeat with a valid application credential (your app's session cookie or API token, supplied from a file with
  #    -b or -H @file so it stays out of shell history) and require a 2xx: that positive control proves the endpoint is
  #    reachable and that the app's own auth, not the platform gate, is what gates it.
  # 3. Secrets: run secrets.md's history and working-tree scans AND grep the DEPLOYED client bundle (JS, source maps,
  #    generated config, runtime-injected values) for every credential type, not just private keys. No matches is evidence, not proof.
  #    Why the deployed bundle: as the Next.js case, the pinned v16.4.2 docs say NEXT_PUBLIC_ values are inlined into
  #    the JavaScript bundle delivered to the client at build time, and production browser source maps are disabled
  #    unless productionBrowserSourceMaps opts in. What to grep and which credential types are this guide's procedure,
  #    delegated to secrets.md, not taken from the cited pages.
  echo "block exit $1; a protected-path answer other than a 2xx, the credentialed positive control and the step 3 secret scans are not classified, so judge them yourself"
  exit "$1"
)
```

## Sources (checked September 2026)

- Render: https://render.com/docs ; Fly.io: https://docs.fly.io/ ; Vercel: https://vercel.com/docs (each documents managed TLS and environment configuration; consult your platform's pages for the exact toggles)
- Vercel Deployment Protection: https://vercel.com/docs/deployment-protection
- Vercel changelog, protect production deployments for free on every plan (9 September 2026): https://vercel.com/changelog/protect-production-deployments-for-free-on-every-plan
- Vercel deployment protection bypass methods (checked October 2026): https://vercel.com/docs/deployment-protection/methods-to-bypass-deployment-protection
- Vercel Protection Bypass for Automation header and query parameter (checked October 2026): https://vercel.com/docs/deployment-protection/methods-to-bypass-deployment-protection/protection-bypass-automation
- Hugging Face Spaces: https://huggingface.co/docs/hub/spaces-overview and https://huggingface.co/docs/hub/spaces-config-reference
- Hugging Face Hub Space visibility choices and source/app access (checked October 2026; commit 6fb324369143cb76a723c88a592010514ac1095a): https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/spaces-overview.md#L29-L45
- Hugging Face Hub Space duplication visibility default (checked October 2026; commit 6fb324369143cb76a723c88a592010514ac1095a): https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/spaces-overview.md#L114-L118
- Hugging Face Hub organization visibility controls and plan scope (checked October 2026; commit 6fb324369143cb76a723c88a592010514ac1095a): https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/enterprise-advanced-security.md#L3-L27
- Hugging Face Hub Dev Mode plan requirement and servers (checked October 2026; commit 6fb324369143cb76a723c88a592010514ac1095a): https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/spaces-dev-mode.md#L3-L14
- Hugging Face Hub Dev Mode SSH, editor connection and SSH key requirement (checked October 2026; commit 6fb324369143cb76a723c88a592010514ac1095a): https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/spaces-dev-mode.md#L41-L78
- Render managed PostgreSQL (external access is open by default and can be restricted; internal connections do not support `sslmode=verify-ca`/`verify-full`): https://render.com/docs/postgresql-creating-connecting
- Next.js 15 environment variables (checked October 2026; `NEXT_PUBLIC_` values in browser JavaScript): https://nextjs.org/docs/15/app/guides/environment-variables
- Next.js v16.4.2 `NEXT_PUBLIC_` build-time inlining into client JavaScript (checked October 2026): https://github.com/vercel/next.js/blob/v16.4.2/docs/01-app/02-guides/environment-variables.mdx#L158-L164
- Next.js v16.4.2 production browser source maps default and opt-in serving (checked October 2026): https://github.com/vercel/next.js/blob/v16.4.2/docs/01-app/03-api-reference/05-config/01-next-config-js/productionBrowserSourceMaps.mdx#L8-L18
- Express 5.x request protocol (checked October 2026; `trust proxy` and `X-Forwarded-Proto`): https://expressjs.com/en/5x/api/request/#req.protocol
- Django 6.1 settings (checked October 2026; `SECURE_PROXY_SSL_HEADER` and trusted proxy requirements): https://docs.djangoproject.com/en/6.1/ref/settings/#secure-proxy-ssl-header
- MySQL 8.4 client connection options (checked October 2026; `--ssl-mode=VERIFY_IDENTITY` certificate and hostname verification): https://dev.mysql.com/doc/refman/8.4/en/connection-options.html#option_general_ssl-mode
- Render web-service listener and TLS termination (checked October 2026): https://render.com/docs/web-services
- Render managed TLS (checked October 2026): https://render.com/docs/tls. The page states: "Finally, Render automatically redirects all HTTP requests to HTTPS so your users' security is never compromised." This guide's assessment: no HTTP-to-HTTPS status code is stated.
- Render custom-domain prerequisites (checked October 2026): https://render.com/docs/custom-domains. The page states: "All HTTP traffic to a custom domain is automatically redirected to HTTPS." This guide's assessment: no HTTP-to-HTTPS status code is stated.
- Render static-site redirect rules (checked October 2026): https://render.com/docs/redirects-rewrites. The Redirect action "Instructs the browser (or any other client) to switch URLs to the rule's destination via a 301 Moved Permanently response code." This guide's assessment: this status belongs to static-site redirect rules and does not establish the HTTP-to-HTTPS status.
- Render web-services tutorial (checked November 2026): https://render.com/tutorials/web-service-vs-static-site/web-services. The page was searched on 2026-11-04 for Render's handling of a client-sent `X-Forwarded-Proto` value and states none.
- Render authentication and authorization article (checked November 2026): https://render.com/articles/how-to-implement-authentication-and-authorization. The article was searched on 2026-11-04 for Render's handling of a client-sent `X-Forwarded-Proto` value and states none.
- Render FastAPI production practices article (checked November 2026): https://render.com/articles/fastapi-production-best-practices. The article was searched on 2026-11-04 for Render's handling of a client-sent `X-Forwarded-Proto` value and states none.
- Vercel TLS termination (checked November 2026): https://vercel.com/docs/cdn-security/encryption
- Vercel request headers, `x-forwarded-proto` description, `X-Forwarded-For` overwrite and Enterprise trusted proxy (checked November 2026): https://vercel.com/docs/headers/request-headers. The page describes `x-forwarded-proto` as the protocol of the forwarded server, typically `https` in production and `http` in development. Under `x-forwarded-for`, it states: "If you are trying to use Vercel behind a proxy, we currently overwrite the X-Forwarded-For header and do not forward external IPs. This restriction is in place to prevent IP spoofing." Under "Custom X-Forwarded-For IP", it states: "Enterprise customers can purchase and enable a trusted proxy to allow your custom X-Forwarded-For IP." This guide's assessment: the page states no overwrite of a client-sent `x-forwarded-proto`, so it does not establish that header's sanitization.
- Vercel reverse proxy servers (checked November 2026): https://vercel.com/docs/security/reverse-proxy. The page was searched on 2026-11-04 for Vercel's handling of a client-sent `X-Forwarded-Proto` value and states none.
- Vercel certificate validation and renewal (checked October 2026): https://vercel.com/docs/domains/working-with-ssl
- Vercel Functions runtimes (checked October 2026): https://vercel.com/docs/functions/runtimes. The page, last updated August 12, 2026, was searched on 2026-11-04 for the address or port a deployed Express function listens on and for whether Vercel connects to an `app.listen` socket, and states neither.
- Vercel Functions request handlers and invocations (checked October 2026): https://vercel.com/docs/functions. No last-updated marker was found on the page, which was searched on 2026-11-04 for the address or port a deployed Express function listens on and for whether Vercel connects to an `app.listen` socket, and states neither.
- Vercel Express entry-file export or port listener (checked October 2026): https://vercel.com/docs/frameworks/backend/express. The page states: "The file must also export the application as a default export of the module or use a port listener." This guide's assessment: its port 3000 is an example; the page states no required listener address or port. On 2026-11-04 the page, last updated August 10, 2026, states: "You may also run your application using the `app.listen` pattern that exposes the server on a port." It was searched that day for the address or port the deployed function listens on and for whether Vercel connects to that socket, and states neither.
- Vercel Python runtime entrypoint (checked October 2026): https://vercel.com/docs/functions/runtimes/python. The page states that a Python entrypoint is "the file and top-level variable that Vercel loads as the Vercel Function handler". This guide's assessment: it states no listener address or port. The page, last updated August 12, 2026, was searched on 2026-11-04 for the address or port a deployed Express function listens on and for whether Vercel connects to an `app.listen` socket, and states neither.
- Vercel Backends (checked November 2026): https://vercel.com/docs/frameworks/backend. The page, last updated August 20, 2026, was searched on 2026-11-04 for the address or port a deployed Express function listens on and for whether Vercel connects to an `app.listen` socket, and states neither.
- Heroku certificate automation and limitations (checked October 2026): https://devcenter.heroku.com/articles/automated-certificate-management. The page states: "When ACM is enabled the Let’s Encrypt HTTP challenge URLs (/.well-known/acme-challenge/*) are handled by the Heroku Platform, redirected away from your app. If you require use of these paths on your app you must disable ACM." This guide's assessment: this path handling establishes none of the following for general HTTP-to-HTTPS redirection: a policy, a toggle, application-only responsibility or a status code. The page's "Known limitations" list also states: "ACM does not support IPv6 AAAA DNS records." and "ACM is not compatible with internal routing." On 2026-11-04 the page, last updated July 07, 2026, still states: "Cedar generation Private Space apps using ACM can’t have wildcard domains. For Generation Private Space apps can use ACM with wildcard domains." This guide's assessment: Heroku's Understanding TLS on Heroku page, and its Acquiring an SSL Certificate page read without a generation exception, both last updated September 30, 2024, conflict with its other-generation sentence.
- Heroku HTTP routing (checked November 2026): https://devcenter.heroku.com/articles/http-routing
- Heroku SSL/TLS redirect responsibility and `X-Forwarded-Proto` overwrite (checked November 2026): https://help.heroku.com/J2R1S4T8/can-heroku-force-an-application-to-use-ssl-tls. The article states: "Redirects need to be performed at the application level as the Heroku router does not provide this functionality." It also states: "Under the hood, Heroku router (over)writes the `X-Forwarded-Proto` and the `X-Forwarded-Port` request headers." The article names no Heroku generation or runtime. This guide's assessment: the HTTP routing page still lists `X-Forwarded-Proto` among headers that "are not trusted for security reasons", and neither page reconciles the two statements.
- Heroku ASP.NET Core HTTPS redirection (checked November 2026): https://devcenter.heroku.com/articles/aspnetcore-app-configuration. The page states: "Heroku doesn’t automatically redirect HTTP requests to HTTPS." Its example configuration sets `options.RedirectStatusCode = StatusCodes.Status308PermanentRedirect;`. This guide's assessment: 308 is that example's choice, not a status the Heroku platform sends.
- Heroku custom-domain prerequisites (checked October 2026): https://devcenter.heroku.com/articles/custom-domains. The article states: "For security purposes, you must verify your Heroku account to add domains to apps." This guide's assessment: this sentence establishes the account prerequisite, not the verification procedure or certificate eligibility.
- Heroku web-process port assignment (checked October 2026): https://devcenter.heroku.com/articles/runtime-principles
- Heroku Node.js web-process `PORT` binding requirement (checked October 2026): https://devcenter.heroku.com/articles/deploying-nodejs
- Heroku Fir Private Spaces networking, listener recommendation and ACM wildcard feature parity (checked October 2026): https://devcenter.heroku.com/articles/generations. The article states: "Fir utilizes IPv6 as the default and recommended connection protocol for networking within Heroku Private Spaces." It warns: "If you designed your application, its dependencies, or connected services within a space assuming only IPv4 connectivity, they don’t bind properly on Fir." It recommends: "Ensure IPv6 compatibility by correctly binding to an IPv6 listener or the dual-stack address listener in your app’s language (typically ::) to leverage Fir’s networking configuration." This guide's assessment: these sentences concern networking within Heroku Private Spaces; they do not establish Cedar's listener address or a deployed application's listener configuration. Its Feature Parity table, with columns Fir and Cedar, marks "Heroku ACM wildcard domains" with an X in both. This guide's assessment: the Fir mark supports Fir Private Space ACM wildcard eligibility without withdrawing the ACM page's two unqualified statements. The article also states: "Both the Common Runtime and Private Spaces run on the Cedar generation of the platform." The table's Cedar column also marks the "Common Runtime" row and the Internal routing, VPC peering, VPN support and Private Spaces DNS Service Discovery rows, whose linked features the Private Spaces page lists for Cedar Private Spaces, and the article does not say whether the Cedar wildcard mark covers Cedar Private Spaces. This guide's assessment: a Cedar mark therefore need not hold in both Cedar runtimes, so the wildcard mark establishes no conflict with the ACM page's Cedar Private Spaces limitation. On 2026-11-04 the page, last updated September 11, 2026, still marks "Heroku ACM wildcard domains" with an X in the Fir column.
- Heroku Cedar Private Spaces features (checked October 2026): https://devcenter.heroku.com/articles/private-spaces. Under the heading "Additional Features for Cedar Private Spaces", the article says: "In addition to the features listed for the spaces in the Fir generation of the Heroku platform, the spaces in the Cedar generation have the following features." It then lists Internal Routing, DNS Service Discovery, VPN Connection and VPC Peering, linking the articles that the Generations page's Internal routing, Private Spaces DNS Service Discovery, VPN support and VPC peering rows link. This guide's assessment: those rows' Cedar marks record features this page describes for Cedar Private Spaces, while the "Common Runtime" row's Cedar mark records the other Cedar runtime.
- Heroku Understanding TLS on Heroku, ACM and Private Spaces wildcard domains (checked November 2026): https://devcenter.heroku.com/articles/understanding-tls-on-heroku. The page, last updated September 30, 2024, lists "Private Space apps using wildcard domains" under "ACM doesn’t support" and states: "Note that ACM doesn’t support wildcard domains for Private Spaces". It names no generation. This guide's assessment: it conflicts with the ACM page's other-generation sentence and the Generations page's Fir mark.
- Heroku Acquiring an SSL Certificate, Private Space wildcard certificates (checked November 2026): https://devcenter.heroku.com/articles/acquiring-an-ssl-certificate. The page, last updated September 30, 2024, states: "If you want to use a different certificate authority for your application or a wildcard certificate on a Private Space app, follow these steps to acquire a certificate manually." It names no generation exception. This guide's assessment: read without a generation exception, it conflicts with the ACM page's other-generation sentence and the Generations page's Fir mark.
- Fly TCP passthrough (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/services.mdx#L93-L97
- Fly TLS termination (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/services.mdx#L174-L176
- Fly domain verification for issuance and renewal (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/custom-domain.mdx#L39-L44
- Fly wildcard validation and automatic issuance (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/custom-domain.mdx#L64-L87
- Fly imported certificates and fallback (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/custom-domain.mdx#L91-L102
- Fly Let's Encrypt automatic renewal and manual custom-certificate renewal (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/understanding-cloudflare.mdx#L105-L105. The line states: "Unlike Let's Encrypt certificates, which renew automatically, custom certificates must be manually renewed and re-imported before they expire." This guide's assessment: it states no renewal timing or renewal-failure handling.
- Fly Certificates resource, automatic ACME issuance and fallback (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/machines/api/certificates-resource.mdx#L6-L6. The line states: "Fly.io can automatically issue Let's Encrypt certificates (ACME), or you can import your own custom certificates. When both exist for a hostname, the custom certificate is served as primary and the ACME certificate acts as an automatic fallback." This guide's assessment: the file, read whole on 2026-10-25, states no renewal timing or renewal-failure handling.
- Fly custom-domain issuance and renewal verification, automatic validation and renewal rate-limit note (checked October 2026): https://docs.fly.io/networking/custom-domain
- Fly public service binding (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/app-services.mdx#L33-L42
- Fly IPv4 and IPv6 wildcard qualification (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/app-services.mdx#L92-L92
- Railway custom-domain DNS and plan conditions (checked October 2026; commit 72354493198302677fb6be6c692dd75c64cae2c6): https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/domains/working-with-domains.md#L39-L122
- Railway certificate renewal and Cloudflare limitations (checked October 2026; commit 72354493198302677fb6be6c692dd75c64cae2c6): https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/domains/working-with-domains.md#L220-L247
- Railway root-domain DNS (checked October 2026; commit 72354493198302677fb6be6c692dd75c64cae2c6): https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/domains/working-with-domains.md#L150-L150
- Railway target ports (checked October 2026; commit 72354493198302677fb6be6c692dd75c64cae2c6): https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/domains/working-with-domains.md#L126-L146
- Railway web-server listener and injected port (checked October 2026; commit 72354493198302677fb6be6c692dd75c64cae2c6): https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/troubleshooting/application-failed-to-respond.md#L46-L51
- Railway edge-proxy TLS termination and internal forwarding (checked October 2026; commit 72354493198302677fb6be6c692dd75c64cae2c6): https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/edge-networking.md#L40-L43
- Fly app configuration file (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/reference/configuration.mdx#L7-L7
- Fly HTTP service redirect setting (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/reference/configuration.mdx#L329-L350
- Fly redirect status and HTTP-handler restriction (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/services.mdx#L229-L229
- Fly HTTP handler forwarded-protocol header (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/services.mdx#L117-L123
- Fly request headers, `X-Forwarded-Proto` description (checked October 2026; commit 2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9): https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/request-headers.mdx#L9-L35. Line 9 states: "Request headers are added by the HTTP handler service." Under `X-Forwarded-Proto`, line 35 states: "The protocol which the client used to make the request. Either `http` or `https`." This guide's assessment: the page does not say whether a client-sent `X-Forwarded-Proto` is overwritten, removed or passed through.
- Railway public-networking headers and request handling (checked October 2026; commit 72354493198302677fb6be6c692dd75c64cae2c6): https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/public-networking/specs-and-limits.md#L16-L17
- Railway GET redirect status and POST conversion (checked October 2026; commit 72354493198302677fb6be6c692dd75c64cae2c6): https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/public-networking/specs-and-limits.md#L37-L38. The two complete entries state: "Plain HTTP GET requests will be redirected to HTTPS with a `301` response." and "Plain HTTP POST requests will be converted to GET requests." This guide's assessment: these entries state none of the following: HEAD behaviour, a POST status code or a configurable redirect toggle.
- Railway HTTP POST redirect status and client method change (checked October 2026; commit 72354493198302677fb6be6c692dd75c64cae2c6): https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/troubleshooting/405-method-not-allowed.md#L8-L18. The page states: "This occurs because your request was made using HTTP. Railway will attempt to redirect your insecure request with a 301 Moved Permanently status code." It continues: "When an HTTP client encounters a 301 Moved Permanently redirect, the client will follow the redirect." It then says that, according to the HTTP/1.1 specifications, "the client will typically change the request method from POST to GET when it follows the redirect to the new URL". The page's line 8 places this in "a POST request to your application" that "is redirected to a GET request". This guide's assessment: these lines state no HEAD behaviour or configurable redirect toggle.
- curl curl-8_14_1 (checked October 2026): [-S restores error messages with -s (4-19)](https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/show-error.md#L4-L19).


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- render: Render documentation (unknown)
- fly: Fly.io documentation (unknown)
- fly-pinned: Fly.io pinned documentation (2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9)
- vercel: Vercel documentation (unknown)
- spaces: Hugging Face Spaces documentation (unknown)
- spaces-pinned: Hugging Face Hub documentation (6fb324369143cb76a723c88a592010514ac1095a)
- heroku: Heroku documentation (unknown)
- railway: Railway documentation (72354493198302677fb6be6c692dd75c64cae2c6)
- nextjs-pinned: Next.js pinned documentation (v16.4.2)
- nextjs: Next.js environment variables (15)
- express: Express request protocol (5.x)
- django: Django proxy security setting (6.1)
- mysql-client: MySQL client connection options (8.4)
- curl: curl (curl-8_14_1)

Claims (full source mapping in the JSON block below):

- managed-tls (REASONED; render, fly, vercel, heroku, fly-pinned, railway): TLS and certificates vary by platform and deployment; Railway's edge proxy terminates TLS before its internal network; Fly passes TCP through without handlers; Heroku ACM supports no AAAA records or internal routing; Heroku pages conflict on Fir Private Space wildcard ACM. Guide advice: no certbot or extra TLS proxy where the platform terminates TLS and manages the required certificate.
- fly-renewal (REASONED; fly-pinned): Fly's pinned Cloudflare page says Let's Encrypt certificates renew automatically, unlike custom certificates, which must be manually renewed and re-imported; this guide's reading: the pinned custom-domain page calls Fly-managed certificates Let's Encrypt certificates, so they renew automatically. Unestablished: Fly renewal timing and renewal-failure handling.
- application-auth (REASONED; vercel): Deployment protection does not replace app login, endpoint keys or application MFA; non-public endpoints still need their own access controls.
- vercel-login (REASONED; vercel): Vercel login can gate preview/deployment URLs on every plan and production domains with All Deployments; the 9 September 2026 change made that scope free including Hobby.
- vercel-password (REASONED; vercel): At the recorded documentation date, Password Protection is unavailable on Hobby, a paid per-project add-on on Pro and included on Enterprise.
- secret-store (REASONED; render, fly, vercel): Use platform environment/secret configuration, not committed .env files; rotate credentials exposed in repositories, build logs or client bundles.
- public-env (REASONED; vercel, nextjs): Only public values belong in browser-compiled environment variables such as NEXT_PUBLIC_.
- https-redirect (REASONED; render, fly, vercel, heroku, fly-pinned, railway): Enforce HTTPS: Render automatic (status unstated), Vercel mandatory 308, Fly HTTP handlers 301 with force_https, Railway GET 301 and, per its 405 troubleshooting page, POST 301 that clients typically follow as GET (HEAD unknown). Heroku's help article (no generation or runtime named) puts redirects in the app, not its router; its ASP.NET Core example's 308 is not a platform status.
- https-redirect-advice (REASONED; render, fly, vercel, heroku, express, django, fly-pinned): Guide advice: implement HTTP-to-HTTPS redirects in the app unless deployed ingress is known to enforce HTTPS, with verified proxy trust and no assumed forwarded-header sanitization. Heroku's help article says its router (over)writes X-Forwarded-Proto; its routing page calls it untrusted. Render and Vercel pages searched 2026-11-04 do not say how a client-sent value is handled.
- proxy-awareness (REASONED; render, fly, vercel, express, django): Configure Express trust proxy or Django SECURE_PROXY_SSL_HEADER so secure cookies and redirects work behind the platform.
- listener-port (REASONED; render, fly, vercel, heroku, fly-pinned, railway): Railway advises 0.0.0.0 on injected PORT and Heroku web processes bind PORT; listener rules vary by deployment, with IPv6/dual-stack recommended for Heroku Fir Private Spaces. Vercel's Express page allows a port listener; cited pages establish no Heroku Cedar listener address, or Vercel's deployed address, port or connection; this guide's advice: bind nothing else and do not open extra listeners.
- database-identity (REASONED; render, mysql-client): Where supported, require TLS certificate/hostname verification with PostgreSQL sslmode=verify-full or MySQL --ssl-mode=VERIFY_IDENTITY.
- render-internal-tls (REASONED; render): Render internal PostgreSQL TLS is optional and supports neither verify-ca nor verify-full; sslmode=require prevents plaintext fallback but is not identity verification.
- database-network (REASONED; render): Render Postgres external access is open to any IP by default; prefer private connectivity and disable or source-restrict external access. Keep database credentials in the secret store.
- spaces-creation (REASONED; spaces, spaces-pinned): This guide's advice: explicitly select and verify visibility when you create a Space. The pinned docs describe public, protected, and private visibility, public exposing source and running app and duplicates defaulting to private; the pinned Advanced Security lines (Team &amp; Enterprise controls at the time of writing) establish no general creation default or retroactive Private only conversion.
- spaces-public (REASONED; spaces): Public Spaces expose both source and running app.
- spaces-protected (REASONED; spaces): Protected Spaces keep source private to owner/collaborators but expose the app via embed URL or custom domain; the recorded requirement is PRO for personal accounts or Team/Enterprise for organizations.
- spaces-private (REASONED; spaces): Private Spaces restrict both source and running app to the owner and collaborators.
- spaces-secrets (REASONED; spaces): Use Settings secrets for sensitive values, never repository/README metadata; variables remain publicly readable.
- spaces-static (REASONED; spaces): Static Spaces expose both variables and secrets to client JavaScript through window.huggingface.variables; keep backend/provider credentials in Docker/Gradio Spaces or another server-side service.
- spaces-dev (REASONED; spaces, spaces-pinned): At the time of writing, the pinned Dev Mode docs require PRO or Team &amp; Enterprise. The Dev Mode Docker image starts the application as a subprocess and starts an SSH server for local editors and terminals and a VS Code server for in-product VS Code Web. Dev Mode exposes the running Space as a standard SSH host; clients use the Space subdomain shown in the Dev Mode controls as the username at ssh.hf.space, and local VS Code uses Remote - SSH to connect to the same host. SSH requires adding the machine's SSH public key to the user's Hugging Face account; these docs do not establish which users or roles may connect, or the access control for in-product VS Code Web. This guide's assessment: access into the running container is materially more access than the app itself, so treat an unattended Dev Mode session the same as any other exposed admin path.
- verify-redirect (REASONED; vercel, render, fly-pinned, railway, heroku, curl): This guide's HTTP HEAD / check requires 301/302/307/308 with an https:// Location; Vercel documents 308 and Fly HTTP handlers 301 with force_https. Spot-check proves neither every route/method nor secure-cookie proxy awareness; Render's HTTPS status (not its static-rule 301) and Railway HEAD status remain unestablished. Heroku's ASP.NET Core 308 is the example's choice, not a platform status.
- verify-app-auth (REASONED; vercel, curl): Disable Vercel deployment protection or use its documented Protection Bypass for Automation, the x-vercel-protection-bypass header or query parameter carrying the project's generated secret, to isolate app auth; no Render or Fly equivalent is cited. This guide's expected reading: anonymous protected requests get the app's 401/403, valid app credentials a 2xx, and a platform SSO 401 is not app enforcement.
- verify-secrets (REASONED; render, fly, vercel, nextjs-pinned): Scan history, working tree and deployed client JS, source maps, generated config and runtime values for every credential type; no matches is evidence, not proof. The scan procedure is this guide's, delegated to secrets.md; the pinned Next.js v16.4.2 lines document only the NEXT_PUBLIC_ build-time inlining and off-by-default production browser source maps that motivate the bundle scan.

````json
{
  "schema": 1,
  "checked": "2026-10-22",
  "documentation_checked": "2026-09",
  "body_sha256": "59a1f9107da1ac7bb86982f00ceb93add040c3349f356cb1707e55b0e5f3d0b0",
  "components": {
    "render": {
      "name": "Render documentation",
      "basis": "unknown",
      "sources": {
        "s213783ba6209": "https://render.com/docs",
        "se240afec8d2d": "https://render.com/docs/postgresql-creating-connecting",
        "s1820ac471b6c": "https://render.com/docs/web-services",
        "s5b8400c2a2ba": "https://render.com/docs/tls",
        "s22963948fc90": "https://render.com/docs/custom-domains",
        "s4935cea7a2ea": "https://render.com/docs/redirects-rewrites",
        "s86db60c0804c": "https://render.com/tutorials/web-service-vs-static-site/web-services",
        "s392f75ca4bcf": "https://render.com/articles/how-to-implement-authentication-and-authorization",
        "sec77c58ba095": "https://render.com/articles/fastapi-production-best-practices"
      }
    },
    "fly": {
      "name": "Fly.io documentation",
      "basis": "unknown",
      "sources": {
        "s29502d5e8321": "https://docs.fly.io/",
        "s74ed2822178a": "https://docs.fly.io/networking/custom-domain"
      }
    },
    "fly-pinned": {
      "name": "Fly.io pinned documentation",
      "basis": "2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9",
      "sources": {
        "s254c8c8a5edd": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/services.mdx#L93-L97",
        "s32999aa4c58c": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/services.mdx#L174-L176",
        "sf4105f79b22b": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/custom-domain.mdx#L39-L44",
        "sea5560c14d13": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/custom-domain.mdx#L64-L87",
        "sb935e8478a30": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/custom-domain.mdx#L91-L102",
        "s62fec91543a1": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/app-services.mdx#L33-L42",
        "s61c1e50d2c11": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/app-services.mdx#L92-L92",
        "s6e9a7292860d": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/reference/configuration.mdx#L7-L7",
        "sa63b828c93df": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/reference/configuration.mdx#L329-L350",
        "s4324a02dbc42": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/services.mdx#L229-L229",
        "scf2e6f3bce02": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/services.mdx#L117-L123",
        "sdf84e7f7ba34": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/understanding-cloudflare.mdx#L105-L105",
        "sdcd6b9620532": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/machines/api/certificates-resource.mdx#L6-L6",
        "sdb820fc62ed4": "https://github.com/superfly/docs/blob/2f68a40e09bb6ef4c4ac6f90c15c1cf5a176d7e9/networking/request-headers.mdx#L9-L35"
      }
    },
    "vercel": {
      "name": "Vercel documentation",
      "basis": "unknown",
      "sources": {
        "s2b470a6bc853": "https://vercel.com/docs",
        "se6089d5c4e96": "https://vercel.com/docs/deployment-protection",
        "s7836e043434a": "https://vercel.com/changelog/protect-production-deployments-for-free-on-every-plan",
        "s3e7832fd3031": "https://vercel.com/docs/cdn-security/encryption",
        "se314aa4b7f1e": "https://vercel.com/docs/domains/working-with-ssl",
        "s22498401f5d0": "https://vercel.com/docs/functions/runtimes",
        "s845513031876": "https://vercel.com/docs/deployment-protection/methods-to-bypass-deployment-protection",
        "sc1588029e14e": "https://vercel.com/docs/deployment-protection/methods-to-bypass-deployment-protection/protection-bypass-automation",
        "s2f00e51f9e6b": "https://vercel.com/docs/functions",
        "s0ede3eac8f7e": "https://vercel.com/docs/frameworks/backend/express",
        "sacb72fc28bb6": "https://vercel.com/docs/functions/runtimes/python",
        "sc2d0fb3d1d6d": "https://vercel.com/docs/headers/request-headers",
        "s43a030ff5da7": "https://vercel.com/docs/security/reverse-proxy",
        "s1b69b9469345": "https://vercel.com/docs/frameworks/backend"
      }
    },
    "spaces": {
      "name": "Hugging Face Spaces documentation",
      "basis": "unknown",
      "sources": {
        "sda0c810c053d": "https://huggingface.co/docs/hub/spaces-overview",
        "sd5ec2b2772e0": "https://huggingface.co/docs/hub/spaces-config-reference"
      }
    },
    "spaces-pinned": {
      "name": "Hugging Face Hub documentation",
      "basis": "6fb324369143cb76a723c88a592010514ac1095a",
      "sources": {
        "se2fb4e2a5c02": "https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/spaces-overview.md#L29-L45",
        "s9d332f0940e2": "https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/spaces-overview.md#L114-L118",
        "s969a28a4c44e": "https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/enterprise-advanced-security.md#L3-L27",
        "s5d393b019bad": "https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/spaces-dev-mode.md#L3-L14",
        "sd1ae2b703a70": "https://github.com/huggingface/hub-docs/blob/6fb324369143cb76a723c88a592010514ac1095a/docs/hub/spaces-dev-mode.md#L41-L78"
      }
    },
    "heroku": {
      "name": "Heroku documentation",
      "basis": "unknown",
      "sources": {
        "sa86eb06bbd4a": "https://devcenter.heroku.com/articles/automated-certificate-management",
        "s0c5bf300cef4": "https://devcenter.heroku.com/articles/http-routing",
        "sfbcf716168be": "https://devcenter.heroku.com/articles/custom-domains",
        "s370d4beec29a": "https://devcenter.heroku.com/articles/runtime-principles",
        "s211f5fe76042": "https://devcenter.heroku.com/articles/generations",
        "s110a083f7129": "https://devcenter.heroku.com/articles/deploying-nodejs",
        "sa8e24c10ccd5": "https://devcenter.heroku.com/articles/private-spaces",
        "s401f4756733b": "https://help.heroku.com/J2R1S4T8/can-heroku-force-an-application-to-use-ssl-tls",
        "s478a51b74185": "https://devcenter.heroku.com/articles/aspnetcore-app-configuration",
        "scb3d72451e99": "https://devcenter.heroku.com/articles/understanding-tls-on-heroku",
        "sccd98f23baca": "https://devcenter.heroku.com/articles/acquiring-an-ssl-certificate"
      }
    },
    "railway": {
      "name": "Railway documentation",
      "basis": "72354493198302677fb6be6c692dd75c64cae2c6",
      "sources": {
        "s93da6ccbfe58": "https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/domains/working-with-domains.md#L39-L122",
        "s6d4dc8fb7784": "https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/domains/working-with-domains.md#L220-L247",
        "s2bc94f13536b": "https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/domains/working-with-domains.md#L150-L150",
        "sac1383056b65": "https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/domains/working-with-domains.md#L126-L146",
        "sbf08758c106a": "https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/public-networking/specs-and-limits.md#L16-L17",
        "s844d338bd121": "https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/public-networking/specs-and-limits.md#L37-L38",
        "s0462eef65b1b": "https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/troubleshooting/application-failed-to-respond.md#L46-L51",
        "sa9d326046a7f": "https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/edge-networking.md#L40-L43",
        "sdd5e5ed1be54": "https://github.com/railwayapp/docs/blob/72354493198302677fb6be6c692dd75c64cae2c6/content/docs/networking/troubleshooting/405-method-not-allowed.md#L8-L18"
      }
    },
    "nextjs-pinned": {
      "name": "Next.js pinned documentation",
      "basis": "v16.4.2",
      "sources": {
        "s0e3d2cd2248e": "https://github.com/vercel/next.js/blob/v16.4.2/docs/01-app/02-guides/environment-variables.mdx#L158-L164",
        "sf7cfdc553311": "https://github.com/vercel/next.js/blob/v16.4.2/docs/01-app/03-api-reference/05-config/01-next-config-js/productionBrowserSourceMaps.mdx#L8-L18"
      }
    },
    "nextjs": {
      "name": "Next.js environment variables",
      "basis": "15",
      "sources": {
        "s22e4b70dab8b": "https://nextjs.org/docs/15/app/guides/environment-variables"
      }
    },
    "express": {
      "name": "Express request protocol",
      "basis": "5.x",
      "sources": {
        "s5bc62e66824b": "https://expressjs.com/en/5x/api/request/#req.protocol"
      }
    },
    "django": {
      "name": "Django proxy security setting",
      "basis": "6.1",
      "sources": {
        "sb5e26f65fd91": "https://docs.djangoproject.com/en/6.1/ref/settings/#secure-proxy-ssl-header"
      }
    },
    "mysql-client": {
      "name": "MySQL client connection options",
      "basis": "8.4",
      "sources": {
        "s823c0bfaaafa": "https://dev.mysql.com/doc/refman/8.4/en/connection-options.html#option_general_ssl-mode"
      }
    },
    "curl": {
      "name": "curl",
      "basis": "curl-8_14_1",
      "sources": {
        "s07916104bf60": "https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/show-error.md#L4-L19"
      }
    }
  },
  "claims": {
    "managed-tls": {"text": "TLS and certificates vary by platform and deployment; Railway's edge proxy terminates TLS before its internal network; Fly passes TCP through without handlers; Heroku ACM supports no AAAA records or internal routing; Heroku pages conflict on Fir Private Space wildcard ACM. Guide advice: no certbot or extra TLS proxy where the platform terminates TLS and manages the required certificate.", "components": ["render", "fly", "vercel", "heroku", "fly-pinned", "railway"], "sources": ["render:s213783ba6209", "fly:s29502d5e8321", "vercel:s2b470a6bc853", "render:s1820ac471b6c", "render:s5b8400c2a2ba", "render:s22963948fc90", "vercel:s3e7832fd3031", "vercel:se314aa4b7f1e", "heroku:sa86eb06bbd4a", "heroku:s0c5bf300cef4", "heroku:sfbcf716168be", "fly-pinned:s254c8c8a5edd", "fly-pinned:s32999aa4c58c", "fly-pinned:sf4105f79b22b", "fly-pinned:sea5560c14d13", "fly-pinned:sb935e8478a30", "railway:s93da6ccbfe58", "railway:s6d4dc8fb7784", "railway:s2bc94f13536b", "railway:sa9d326046a7f", "fly:s74ed2822178a", "fly-pinned:sdf84e7f7ba34", "heroku:s211f5fe76042", "heroku:sa8e24c10ccd5", "heroku:scb3d72451e99", "heroku:sccd98f23baca"], "status": "REASONED"},
    "fly-renewal": {"text": "Fly's pinned Cloudflare page says Let's Encrypt certificates renew automatically, unlike custom certificates, which must be manually renewed and re-imported; this guide's reading: the pinned custom-domain page calls Fly-managed certificates Let's Encrypt certificates, so they renew automatically. Unestablished: Fly renewal timing and renewal-failure handling.", "components": ["fly-pinned"], "sources": ["fly-pinned:sdf84e7f7ba34", "fly-pinned:sb935e8478a30", "fly-pinned:sf4105f79b22b", "fly-pinned:sdcd6b9620532"], "status": "REASONED"},
    "application-auth": {"text": "Deployment protection does not replace app login, endpoint keys or application MFA; non-public endpoints still need their own access controls.", "components": ["vercel"], "sources": ["vercel:se6089d5c4e96"], "status": "REASONED"},
    "vercel-login": {"text": "Vercel login can gate preview/deployment URLs on every plan and production domains with All Deployments; the 9 September 2026 change made that scope free including Hobby.", "components": ["vercel"], "sources": ["vercel:se6089d5c4e96", "vercel:s7836e043434a"], "status": "REASONED"},
    "vercel-password": {"text": "At the recorded documentation date, Password Protection is unavailable on Hobby, a paid per-project add-on on Pro and included on Enterprise.", "components": ["vercel"], "sources": ["vercel:se6089d5c4e96"], "status": "REASONED"},
    "secret-store": {"text": "Use platform environment/secret configuration, not committed .env files; rotate credentials exposed in repositories, build logs or client bundles.", "components": ["render", "fly", "vercel"], "sources": ["render:s213783ba6209", "fly:s29502d5e8321", "vercel:s2b470a6bc853"], "status": "REASONED"},
    "public-env": {"text": "Only public values belong in browser-compiled environment variables such as NEXT_PUBLIC_.", "components": ["vercel", "nextjs"], "sources": ["vercel:s2b470a6bc853", "nextjs:s22e4b70dab8b"], "status": "REASONED"},
    "https-redirect": {"text": "Enforce HTTPS: Render automatic (status unstated), Vercel mandatory 308, Fly HTTP handlers 301 with force_https, Railway GET 301 and, per its 405 troubleshooting page, POST 301 that clients typically follow as GET (HEAD unknown). Heroku's help article (no generation or runtime named) puts redirects in the app, not its router; its ASP.NET Core example's 308 is not a platform status.", "components": ["render", "fly", "vercel", "heroku", "fly-pinned", "railway"], "sources": ["render:s213783ba6209", "fly:s29502d5e8321", "vercel:s2b470a6bc853", "render:s5b8400c2a2ba", "vercel:s3e7832fd3031", "heroku:s0c5bf300cef4", "fly-pinned:s6e9a7292860d", "fly-pinned:sa63b828c93df", "fly-pinned:s4324a02dbc42", "fly-pinned:scf2e6f3bce02", "railway:sbf08758c106a", "railway:s844d338bd121", "render:s22963948fc90", "render:s4935cea7a2ea", "heroku:sa86eb06bbd4a", "railway:sdd5e5ed1be54", "heroku:s401f4756733b", "heroku:s478a51b74185"], "status": "REASONED"},
    "https-redirect-advice": {"text": "Guide advice: implement HTTP-to-HTTPS redirects in the app unless deployed ingress is known to enforce HTTPS, with verified proxy trust and no assumed forwarded-header sanitization. Heroku's help article says its router (over)writes X-Forwarded-Proto; its routing page calls it untrusted. Render and Vercel pages searched 2026-11-04 do not say how a client-sent value is handled.", "components": ["render", "fly", "vercel", "heroku", "express", "django", "fly-pinned"], "sources": ["render:s213783ba6209", "fly:s29502d5e8321", "vercel:s2b470a6bc853", "heroku:s0c5bf300cef4", "express:s5bc62e66824b", "django:sb5e26f65fd91", "vercel:sc2d0fb3d1d6d", "fly-pinned:sdb820fc62ed4", "heroku:s401f4756733b", "render:s5b8400c2a2ba", "render:s22963948fc90", "render:s1820ac471b6c", "vercel:s3e7832fd3031", "render:s86db60c0804c", "render:s392f75ca4bcf", "render:sec77c58ba095", "vercel:s43a030ff5da7"], "status": "REASONED"},
    "proxy-awareness": {"text": "Configure Express trust proxy or Django SECURE_PROXY_SSL_HEADER so secure cookies and redirects work behind the platform.", "components": ["render", "fly", "vercel", "express", "django"], "sources": ["render:s213783ba6209", "fly:s29502d5e8321", "vercel:s2b470a6bc853", "express:s5bc62e66824b", "django:sb5e26f65fd91"], "status": "REASONED"},
    "listener-port": {"text": "Railway advises 0.0.0.0 on injected PORT and Heroku web processes bind PORT; listener rules vary by deployment, with IPv6/dual-stack recommended for Heroku Fir Private Spaces. Vercel's Express page allows a port listener; cited pages establish no Heroku Cedar listener address, or Vercel's deployed address, port or connection; this guide's advice: bind nothing else and do not open extra listeners.", "components": ["render", "fly", "vercel", "heroku", "fly-pinned", "railway"], "sources": ["render:s213783ba6209", "fly:s29502d5e8321", "vercel:s2b470a6bc853", "render:s1820ac471b6c", "vercel:s22498401f5d0", "heroku:s370d4beec29a", "heroku:s211f5fe76042", "fly-pinned:s62fec91543a1", "fly-pinned:s61c1e50d2c11", "railway:sac1383056b65", "railway:s0462eef65b1b", "heroku:s110a083f7129", "vercel:s2f00e51f9e6b", "vercel:s0ede3eac8f7e", "vercel:sacb72fc28bb6", "vercel:s1b69b9469345"], "status": "REASONED"},
    "database-identity": {"text": "Where supported, require TLS certificate/hostname verification with PostgreSQL sslmode=verify-full or MySQL --ssl-mode=VERIFY_IDENTITY.", "components": ["render", "mysql-client"], "sources": ["render:se240afec8d2d", "mysql-client:s823c0bfaaafa"], "status": "REASONED"},
    "render-internal-tls": {"text": "Render internal PostgreSQL TLS is optional and supports neither verify-ca nor verify-full; sslmode=require prevents plaintext fallback but is not identity verification.", "components": ["render"], "sources": ["render:se240afec8d2d"], "status": "REASONED"},
    "database-network": {"text": "Render Postgres external access is open to any IP by default; prefer private connectivity and disable or source-restrict external access. Keep database credentials in the secret store.", "components": ["render"], "sources": ["render:se240afec8d2d"], "status": "REASONED"},
    "spaces-creation": {"text": "This guide's advice: explicitly select and verify visibility when you create a Space. The pinned docs describe public, protected, and private visibility, public exposing source and running app and duplicates defaulting to private; the pinned Advanced Security lines (Team & Enterprise controls at the time of writing) establish no general creation default or retroactive Private only conversion.", "components": ["spaces", "spaces-pinned"], "sources": ["spaces:sda0c810c053d", "spaces-pinned:se2fb4e2a5c02", "spaces-pinned:s9d332f0940e2", "spaces-pinned:s969a28a4c44e"], "status": "REASONED"},
    "spaces-public": {"text": "Public Spaces expose both source and running app.", "components": ["spaces"], "sources": ["spaces:sda0c810c053d"], "status": "REASONED"},
    "spaces-protected": {"text": "Protected Spaces keep source private to owner/collaborators but expose the app via embed URL or custom domain; the recorded requirement is PRO for personal accounts or Team/Enterprise for organizations.", "components": ["spaces"], "sources": ["spaces:sda0c810c053d"], "status": "REASONED"},
    "spaces-private": {"text": "Private Spaces restrict both source and running app to the owner and collaborators.", "components": ["spaces"], "sources": ["spaces:sda0c810c053d"], "status": "REASONED"},
    "spaces-secrets": {"text": "Use Settings secrets for sensitive values, never repository/README metadata; variables remain publicly readable.", "components": ["spaces"], "sources": ["spaces:sda0c810c053d", "spaces:sd5ec2b2772e0"], "status": "REASONED"},
    "spaces-static": {"text": "Static Spaces expose both variables and secrets to client JavaScript through window.huggingface.variables; keep backend/provider credentials in Docker/Gradio Spaces or another server-side service.", "components": ["spaces"], "sources": ["spaces:sda0c810c053d"], "status": "REASONED"},
    "spaces-dev": {"text": "At the time of writing, the pinned Dev Mode docs require PRO or Team & Enterprise. The Dev Mode Docker image starts the application as a subprocess and starts an SSH server for local editors and terminals and a VS Code server for in-product VS Code Web. Dev Mode exposes the running Space as a standard SSH host; clients use the Space subdomain shown in the Dev Mode controls as the username at ssh.hf.space, and local VS Code uses Remote - SSH to connect to the same host. SSH requires adding the machine's SSH public key to the user's Hugging Face account; these docs do not establish which users or roles may connect, or the access control for in-product VS Code Web. This guide's assessment: access into the running container is materially more access than the app itself, so treat an unattended Dev Mode session the same as any other exposed admin path.", "components": ["spaces", "spaces-pinned"], "sources": ["spaces:sda0c810c053d", "spaces-pinned:s5d393b019bad", "spaces-pinned:sd1ae2b703a70"], "status": "REASONED"},
    "verify-redirect": {"text": "This guide's HTTP HEAD / check requires 301/302/307/308 with an https:// Location; Vercel documents 308 and Fly HTTP handlers 301 with force_https. Spot-check proves neither every route/method nor secure-cookie proxy awareness; Render's HTTPS status (not its static-rule 301) and Railway HEAD status remain unestablished. Heroku's ASP.NET Core 308 is the example's choice, not a platform status.", "components": ["vercel", "render", "fly-pinned", "railway", "heroku", "curl"], "sources": ["vercel:s2b470a6bc853", "vercel:s3e7832fd3031", "render:s5b8400c2a2ba", "fly-pinned:s4324a02dbc42", "railway:sbf08758c106a", "railway:s844d338bd121", "heroku:s0c5bf300cef4", "render:s22963948fc90", "render:s4935cea7a2ea", "heroku:sa86eb06bbd4a", "railway:sdd5e5ed1be54", "curl:s07916104bf60", "heroku:s401f4756733b", "heroku:s478a51b74185"], "status": "REASONED", "verify": [1]},
    "verify-app-auth": {"text": "Disable Vercel deployment protection or use its documented Protection Bypass for Automation, the x-vercel-protection-bypass header or query parameter carrying the project's generated secret, to isolate app auth; no Render or Fly equivalent is cited. This guide's expected reading: anonymous protected requests get the app's 401/403, valid app credentials a 2xx, and a platform SSO 401 is not app enforcement.", "components": ["vercel", "curl"], "sources": ["vercel:se6089d5c4e96", "vercel:s845513031876", "vercel:sc1588029e14e", "curl:s07916104bf60"], "status": "REASONED", "verify": [1]},
    "verify-secrets": {"text": "Scan history, working tree and deployed client JS, source maps, generated config and runtime values for every credential type; no matches is evidence, not proof. The scan procedure is this guide's, delegated to secrets.md; the pinned Next.js v16.4.2 lines document only the NEXT_PUBLIC_ build-time inlining and off-by-default production browser source maps that motivate the bundle scan.", "components": ["render", "fly", "vercel", "nextjs-pinned"], "sources": ["render:s213783ba6209", "fly:s29502d5e8321", "vercel:s2b470a6bc853", "nextjs-pinned:s0e3d2cd2248e", "nextjs-pinned:sf7cfdc553311"], "status": "REASONED", "verify": [1]}
  }
}
````
<!-- version-basis:end -->
