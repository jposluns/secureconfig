# Firebase and Supabase: the rules are the security

Firebase and Supabase are hosted app backends whose database, storage, sign-in and functions are called directly from client code. This guide helps your AI assistant configure each securely, including Firebase Security Rules or Supabase row-level security with grants, separately authorized functions and storage, and server keys kept off clients.

<a id="ai-assistant-prompt"></a>

If an AI assistant is helping you secure a deployment, give it the prompt below:

```text
Read the secureconfig guide at
https://raw.githubusercontent.com/jposluns/secureconfig/main/firebase-supabase.md
in full, including the section for AI assistants at the end. Then, for my
deployment: state which of its recommendations apply and the exact changes
to make; compare the versions the guide was written against with the
releases I am running and with the vendor's current releases, and flag any
guidance a newer release may have changed; and run or adapt the guide's
Verify steps where you can. List separately every item you could not
verify instead of reporting it as passed.
```

Written against Firebase documentation (no recorded version), PostgreSQL invoker-view minimum 15, curl curl-8_14_1, and ShellCheck v0.11.0; 2 further sources carry no recorded version. Metadata reviewed 2026-10-19; documentation checked September 2026. The guide records 70 claims: 2 demonstrated by a check that ran; 68 reasoned from cited sources and any earlier-form run (not a live demonstration of the shipped form).

A newer release of any of this software can make version-specific details here outdated. To prioritize an update, open a GitHub issue, send a pull request, add a request under [requests/](requests/README.md), or reach the maintainer as [CONTRIBUTING.md](CONTRIBUTING.md) describes. The machine-readable version basis and claim list are in [the section for AI assistants](#about-the-ai-assistant-section-below) at the end of this guide.

These platforms handle TLS for you on their hosted endpoints; the exposure works differently.
Client SDKs talk to the backend using keys that ship in your frontend code and are **public by
design**: the Firebase API key and Supabase publishable or legacy `anon` key. Client data access
needs Firebase Security Rules or Postgres row-level security (RLS) alongside grants, IAM,
endpoint authorization, and App Check where applicable. AI-generated apps repeatedly ship with
that layer open because "it worked in testing". On Supabase the gate also depends on how exposed
views and functions execute, not only on the table policies.

Documentation was checked in September 2026. Defaults below describe the documentation at the
time of writing; inspect the effective settings of each project. Live behavior has not been
demonstrated in this authoring environment. The Verify section records the missing prerequisites
and the vendor documentation supporting the REASONED checks.

## Firebase

### 1. Set ownership rules in all three products

Every Firestore, Realtime Database, and Storage instance needs explicit security rules. Never
deploy the all-open rule (`allow read, write: if true;` or `".read": true, ".write": true`);
it exposes the entire datastore to anyone with your public config. Require authentication and
scope by user: `request.auth != null` establishes authentication, not authorization to another
user's data. See [Firebase Security Rules](https://firebase.google.com/docs/rules) and
[ownership examples](https://firebase.google.com/docs/rules/basics).

Do not assume a new instance denies access. Creating a Firestore database offers a **test mode**
that lets anyone read and overwrite your data alongside locked production mode. Firestore
production mode and RTDB locked mode deny client reads and writes. Test-mode templates grant
public access for about a month; their expiry ends that access, but does not protect data during
the trial. Inspect the actual expiry and replace the template before using sensitive data. See
[Firestore starting modes](https://firebase.google.com/docs/firestore/quickstart),
[RTDB starting modes](https://firebase.google.com/docs/database/web/start), and
[Firebase's test-rule expiry announcement](https://firebase.google.com/support/releases).

For Firestore, this is a complete ownership ruleset:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

Version 2 matters: the recursive wildcard matches zero or more path items, so this includes
`/users/{userId}` itself and its descendant documents. Under version 1, the same recursive match
excludes the user document itself. Unmatched paths remain denied. Remove overlapping permissive
rules; a matching denial does not override another matching grant. See
[Firestore rule structure](https://firebase.google.com/docs/firestore/security/rules-structure).

RTDB uses a separate JSON rules engine. Put ownership checks under `users.$uid`:

```json
{
  "rules": {
    ".read": false,
    ".write": false,
    "users": {
      "$uid": {
        ".read": "auth !== null && auth.uid === $uid",
        ".write": "auth !== null && auth.uid === $uid"
      }
    }
  }
}
```

Remove any root or ancestor `.read` or `.write` grant that would authorize everyone.
RTDB child rules cannot revoke a parent grant. Read individual authorized user paths; RTDB rules
do not filter a parent read into its permitted children. See
[RTDB rule syntax and cascading](https://firebase.google.com/docs/database/security/core-syntax).

Storage has its own rules; Firestore rules do **not** secure uploaded objects. Firebase's basic
rules documentation describes authenticated Storage access in its default-rules prose while
showing a deny-all Storage ruleset. Establish deny-all explicitly instead of relying on a
starting-mode label:

```text
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if false;
    }
  }
}
```

Then replace that ruleset with deliberate ownership access, for example:

```text
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/{allPaths=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

This authorizes objects beneath the caller's UID path. Other paths remain denied unless another
rule grants access. See [basic rules](https://firebase.google.com/docs/rules/basics) and
[Storage rule structure](https://firebase.google.com/docs/storage/security/core-syntax).

A distributed Storage download URL is a bearer credential: it does not expire, and anyone
holding it can access the object. Tightening ownership Rules does not revoke that URL. For
sensitive objects, revoke previously distributed download tokens in the Firebase console and
use authenticated SDK direct downloads such as `getBlob()` or `getBytes()` so Rules govern
access. See [Admin shareable URLs](https://firebase.google.com/docs/storage/admin/start),
[download-token revocation](https://firebase.google.com/docs/reference/kotlin/com/google/firebase/storage/StorageReference),
and [SDK direct downloads](https://firebase.google.com/docs/storage/web/download-files).

Inspect the deployed rules for every Firestore database, bucket, and RTDB instance; keep
production locked-by-default, open specific paths deliberately, and test with the Rules
Playground and emulator before deploying. Keep local and deployed rule definitions in sync.
See [getting started with rules](https://firebase.google.com/docs/firestore/security/get-started)
and [Storage rule management](https://firebase.google.com/docs/storage/security/get-started).

### 2. Authorize Functions before privileged work

Server-side credentials, including service accounts for the Admin SDK, bypass client Security
Rules; they stay on servers only, handled per [secrets.md](secrets.md). IAM and the server's own
authorization checks therefore matter. A function using the Admin SDK must not treat successful
SDK access as evidence that its caller was entitled to the data. See
[Firestore server access](https://firebase.google.com/docs/firestore/security/rules-structure).

Callable authentication is optional: the callable protocol validates a supplied ID token, but
does not require the caller to supply one. In second-generation `onCall` handlers, reject missing
`request.auth` before privileged work and derive identity from `request.auth.uid`. Treat
`request.data` as untrusted input, including any UID, role, document path, or ownership claim.
First-generation handlers use `context.auth` instead. See the
[callable protocol](https://firebase.google.com/docs/functions/callable-reference),
[second-generation handlers](https://firebase.google.com/docs/functions/callable), and
[first-generation handlers](https://firebase.google.com/docs/functions/1st-gen/callable-1st).

This second-generation example identifies the authenticated caller and also enforces App Check:

```javascript
const { onCall, HttpsError } = require("firebase-functions/v2/https");

exports.whoAmI = onCall({ enforceAppCheck: true }, (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Sign in first.");
  }
  return { uid: request.auth.uid };
});
```

Before extending it to read or change protected resources, authorize that UID for the requested
operation and validate the submitted data. App Check does not replace those checks.
The enforcement option requires `firebase-functions` 4.0.0 or newer. See
[callable App Check enforcement](https://firebase.google.com/docs/app-check/cloud-functions).

An `onRequest` HTTP handler does not inherit callable authentication. For end-user endpoints,
extract the bearer ID token, validate it with the Admin SDK's `verifyIdToken()`, reject missing or
invalid tokens, and authorize the verified UID. For IAM-controlled endpoints, restrict invocation
with `invoker: "private"` or an explicit invoker list and configure the intended principals.
Firebase user ID tokens and IAM invocation credentials serve different checks. See
[ID-token verification](https://firebase.google.com/docs/auth/admin/verify-id-tokens),
[HTTP handlers](https://firebase.google.com/docs/functions/http-events), and
[`HttpsOptions.invoker`](https://firebase.google.com/docs/reference/functions/2nd-gen/node/firebase-functions.https.httpsoptions).

### 3. Enforce App Check and restrict public API keys

Register each app with its appropriate App Check provider, deploy compatible clients, and inspect
request metrics before enabling enforcement. Registration alone does not enforce anything.
In the App Check console, enable enforcement separately for Firestore, Realtime Database, and
Storage; configure `enforceAppCheck: true` separately on each protected callable. See
[provider registration and client rollout](https://firebase.google.com/docs/app-check/web/recaptcha-enterprise-provider)
and [per-product enforcement](https://firebase.google.com/docs/app-check/enable-enforcement).

In Google Cloud Console > APIs & Services > Credentials, restrict the public Web API key to the
intended HTTP referrers. Use Android application restrictions for Android keys and iOS application
restrictions for iOS keys. A key supports one application-restriction type, so use separate keys
for different types. Apply API restrictions as well. See
[application and API restrictions](https://docs.cloud.google.com/api-keys/docs/add-restrictions-api-keys).

Build the API allowlist from Firebase's full product table. For example, Authentication uses
`identitytoolkit.googleapis.com` and `securetoken.googleapis.com`, while App Check uses
`firebaseappcheck.googleapis.com`; those three are not a complete list for every Firebase app.
Retest each product after changing restrictions. Keep unrelated, especially billable, APIs on
separate restricted keys. See
[Firebase API-key restrictions and the product table](https://firebase.google.com/docs/projects/api-keys).

The public Firebase config, including `databaseURL`, identifies resources; it grants no
authorization. Hiding or changing it does not repair open rules. See
[Firebase configuration objects](https://firebase.google.com/docs/web/learn-more).

### 4. Limit sign-in methods and keep emulators private

Disable unused sign-in providers in Firebase Authentication, including Anonymous when the app
does not need it. Anonymous authentication is opt-in, but an anonymous account still has an
authenticated UID and satisfies an authentication-only Rules check. See
[anonymous authentication](https://firebase.google.com/docs/auth/web/anonymous-auth).

Enable **Email enumeration protection** under Authentication Settings > User account management >
User actions. At the time of writing, it is enabled by default only for projects created on or
after September 15, 2023. It changes sign-in errors and account-discovery behavior; update clients
that rely on the old responses. Signup can still return `EMAIL_EXISTS`, so this is not complete
protection against discovering registered addresses. See
[email enumeration protection](https://docs.cloud.google.com/identity-platform/docs/admin/email-enumeration-protection).

Emulators listen on localhost by default. Keep their listeners, UI, and hub private: no public
ports, reverse-proxy routes, or public tunnels. A private listener is especially important because
Firestore, RTDB, and Storage emulators run with **open data security** when Rules configuration is
missing. Merge these entries into `firebase.json`, with the referenced files containing the
intended rules:

```json
{
  "firestore": {
    "rules": "firestore.rules"
  },
  "database": {
    "rules": "database.rules.json"
  },
  "storage": {
    "rules": "storage.rules"
  }
}
```

Inspect existing emulator host overrides and restore localhost-only binding where necessary.
See [emulator configuration](https://firebase.google.com/docs/emulator-suite/install_and_configure)
and [the documented localhost default](https://firebase.google.com/docs/emulator-suite/use_hosting).

## Supabase

For the hosted direct-Postgres endpoint and database pooler, restrict allowed client IP ranges
with Dashboard **Network Restrictions**, enable **Enforce SSL on incoming connections**, and
keep the `postgres` and other database-role passwords secret; see
[Network Restrictions](https://supabase.com/docs/guides/platform/network-restrictions),
[SSL enforcement](https://supabase.com/docs/guides/platform/ssl-enforcement), and
[database roles and passwords](https://supabase.com/docs/guides/database/postgres/roles).

### 1. Restrict the Data API, grants, and rows

Enable RLS on **every** table exposed through the API, then write policies for intended access.
An API-exposed table without RLS is readable or writable by a role only when that role also has
the corresponding grants. Projects retaining Supabase's automatic grants can therefore expose
new tables to the public `anon` key. At the time of writing, Supabase documents a transition
towards opt-in grants; do not assume identical defaults across projects. Review grants and RLS
separately. Dashboard Table Editor creation enables RLS; SQL-created tables require explicit
enablement. See [Data API security](https://supabase.com/docs/guides/api/securing-your-api).

For an existing `public.profiles` table whose `user_id` column contains the owner's Auth UUID,
this baseline permits authenticated owners to select their rows:

```sql
alter table public.profiles enable row level security;
revoke all privileges on table public.profiles from public, anon, authenticated;
grant select on table public.profiles to authenticated;

create policy "own rows"
on public.profiles for select
to authenticated
using ((select auth.uid()) = user_id);
```

Review existing policies and inherited or column-level grants as well; adding a narrow policy
does not cancel an existing broad permissive policy. See
[Supabase RLS](https://supabase.com/docs/guides/database/postgres/row-level-security) and
[PostgreSQL policy combination](https://www.postgresql.org/docs/current/sql-createpolicy.html).

Write separate policies per operation (`select`, `insert`, `update`, `delete`). No policy means
no row access once RLS is on for ordinary roles subject to RLS, which is the correct starting
point. Policies grant intended access; they are not required to make an RLS-enabled table closed.
Table owners normally bypass RLS, and superusers and `BYPASSRLS` roles bypass it. `TRUNCATE` is
outside RLS, so do not grant it to client roles. See
[PostgreSQL row security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html).

Install only the write policies and matching grants the app intentionally needs. For an app
that permits owners to create, update, and delete their profiles:

```sql
grant insert, update, delete on table public.profiles to authenticated;

create policy "insert own rows"
on public.profiles for insert
to authenticated
with check ((select auth.uid()) = user_id);

create policy "update own rows"
on public.profiles for update
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create policy "delete own rows"
on public.profiles for delete
to authenticated
using ((select auth.uid()) = user_id);
```

The UPDATE policy checks both the existing row and its proposed replacement, preventing a caller
from taking another user's row or changing ownership away from themselves. For roles subject
to RLS, UPDATE also needs applicable SELECT (or ALL) policies when it reads table columns,
for example in WHERE, RETURNING, or a SET expression. Data API updates that filter on existing
rows therefore need the SELECT policy too. See
[PostgreSQL CREATE POLICY](https://www.postgresql.org/docs/current/sql-createpolicy.html) and
[operation-specific RLS policies](https://supabase.com/docs/guides/database/postgres/row-level-security).

`public` is exposed by default. Restrict **Exposed schemas** to the schemas intended for client
access, or use a dedicated `api` schema and keep internal tables and helpers outside it. Grant
schema usage and object privileges deliberately; changing schemas is not a substitute for RLS.
See [custom API schemas](https://supabase.com/docs/guides/api/using-custom-schemas).

If the application does not use the Data API, turn **Enable Data API** off in the Dashboard's
Data API integration settings. This closes its generated REST endpoints regardless of table
policies. It does not disable every other Supabase service. See
[disabling the Data API](https://supabase.com/docs/guides/api/securing-your-api).

### 2. Separate client keys, server keys, and JWT signing keys

Use `sb_publishable_...` keys in clients. With no signed-in session, a publishable key uses the
`anon` role; with a signed-in user's session, requests use `authenticated`.
Keep `sb_secret_...` keys only in trusted backends: they resolve to `service_role`, which has
`BYPASSRLS`. The legacy `service_role` key likewise bypasses RLS; it is a server-only secret that
must never reach the client bundle or the repository. Browser rejection of a secret key does
not make a leaked key safe: another client can use it. See
[API keys](https://supabase.com/docs/guides/getting-started/api-keys).

Creating replacement publishable and secret keys does **not** disable legacy keys. Migrate every
consumer, confirm it uses the replacement, then explicitly deactivate the legacy keys in
Settings > API Keys. For a compromised secret key, replace it in the trusted consumers and
delete the compromised key. Fix the exposure as well as retiring the credential. See
[key migration](https://supabase.com/docs/guides/getting-started/migrating-to-new-api-keys).

JWT signing keys have a separate lifecycle. **Rotate keys** changes the key used to sign new
JWTs; the previous key remains trusted until it is revoked. Plan revocation and verifier-cache
propagation explicitly. API-key replacement is not evidence that an old JWT signing key has
lost trust. See [JWT signing keys](https://supabase.com/docs/guides/auth/signing-keys).

### 3. Check views and privileged functions

A view checks underlying relations with **its owner's** privileges by default and applies the
owner's row-level security policies rather than the caller's. On Supabase a view is typically
created by the `postgres` user, so it can disclose rows hidden by the caller's table policies.
That requires a reachable schema, suitable grants, and a view query and owner privileges that
permit the disclosure; possession of an `anon` key alone does not guarantee it. See
[PostgreSQL view security](https://www.postgresql.org/docs/current/sql-createview.html) and
[Supabase RLS and views](https://supabase.com/docs/guides/database/postgres/row-level-security).

On PostgreSQL 15 and later, make every API-exposed view apply the caller's policies instead:

```sql
alter view public.REPLACE_WITH_VIEW_NAME set (security_invoker = true);
```

The caller also needs appropriate privileges on the underlying relations. See
[`ALTER VIEW`](https://www.postgresql.org/docs/current/sql-alterview.html) and the
[PostgreSQL 15 release notes](https://www.postgresql.org/docs/release/15.0/).

On PostgreSQL 14 and earlier there is no `security_invoker`: revoke ALL privileges on the view
from `public` as well as from `anon` and `authenticated`, or keep it in a schema the API does not
expose. A simple view is automatically updatable, so revoking only `select` can leave
`insert`/`update`/`delete` that write through the owner and bypass the table's RLS.
Revoking the two API roles alone leaves access they inherit from `PUBLIC`, so confirm with
`select has_table_privilege('anon', 'public.REPLACE_WITH_VIEW_NAME', 'select, insert, update, delete');`,
which must return `f`.

```sql
-- PostgreSQL 14 or earlier: revoke ALL privileges on an API-exposed view from all three, then confirm both API roles lost every one.
-- Run the REVOKE as the view's owner; a check still returning t means another grant or role provides access.
-- A simple view is automatically updatable, so revoking only SELECT can leave INSERT/UPDATE/DELETE that write through the owner.
revoke all privileges on table public.REPLACE_WITH_VIEW_NAME from public, anon, authenticated;
select has_table_privilege('anon', 'public.REPLACE_WITH_VIEW_NAME', 'select, insert, update, delete'),
       has_table_privilege('authenticated', 'public.REPLACE_WITH_VIEW_NAME', 'select, insert, update, delete');   -- both must be f
```

See [`REVOKE`](https://www.postgresql.org/docs/current/sql-revoke.html) and
[privilege inquiry functions](https://www.postgresql.org/docs/current/functions-info.html).
The comma-separated privilege check returns true if **any** listed privilege remains.

Prefer `SECURITY INVOKER` for functions. A `SECURITY DEFINER` function likewise runs as its owner
and can return rows RLS would hide. Keep such functions out of API-exposed schemas unless they
enforce their own authorization, and revoke execution by default:

```sql
revoke execute on function public.REPLACE_WITH_FUNCTION_NAME from public, anon, authenticated;
```

Include the argument types where the function name is overloaded. Where DEFINER is necessary,
set `SET search_path = ''`, schema-qualify every referenced relation and helper, and enforce caller
authorization inside the function, including MFA where required. An empty search path does not
supply authorization. See [database functions](https://supabase.com/docs/guides/database/functions).

For an existing function with one UUID argument, the settings and selective grant take this
shape. Substitute its actual signature; grant execution only after reviewing its body:

```sql
alter function public.REPLACE_WITH_FUNCTION_NAME(uuid) set search_path = '';
revoke execute on function public.REPLACE_WITH_FUNCTION_NAME(uuid)
  from public, anon, authenticated;
grant execute on function public.REPLACE_WITH_FUNCTION_NAME(uuid)
  to authenticated;
```

New PostgreSQL functions normally grant execution to `PUBLIC`. Create privileged functions and
set their privileges in the same transaction. To change future defaults for functions created
by `postgres`, remove the global PUBLIC grant and any schema-specific API-role defaults:

```sql
alter default privileges for role postgres
  revoke execute on functions from public;

alter default privileges for role postgres in schema public
  revoke execute on functions from anon, authenticated;
```

Repeat for the actual function-creating roles and relevant schemas. Defaults do not change
existing functions; a schema-scoped revocation cannot cancel a global default grant.
See [`CREATE FUNCTION`](https://www.postgresql.org/docs/current/sql-createfunction.html),
[`ALTER FUNCTION`](https://www.postgresql.org/docs/current/sql-alterfunction.html), and
[`ALTER DEFAULT PRIVILEGES`](https://www.postgresql.org/docs/current/sql-alterdefaultprivileges.html).

Audit API-callable wrappers around `http`, `net.http_get`, and `net.http_post`. Revoke execution
from `PUBLIC`, `anon`, and `authenticated` on unneeded entry points, using each installed
signature. Where needed, constrain callers, destinations, and transmitted data. The documented
ability to issue outbound requests implies a possible SSRF or data-exfiltration path if an
exposed wrapper accepts attacker-controlled destinations or forwards privileged data; enabling
an extension alone is not proof of an exploitable endpoint. See
[`http`](https://supabase.com/docs/guides/database/extensions/http) and
[`pg_net`](https://supabase.com/docs/guides/database/extensions/pg_net).

Restrict `vault.decrypted_secrets` and every DEFINER function that reads it:

```sql
revoke all privileges on table vault.decrypted_secrets from public, anon, authenticated;
```

Keep Vault outside exposed schemas and review indirect access through views and functions.
Vault decrypts values through this view; encryption at rest does not prevent an authorized
query or privileged wrapper from disclosing plaintext through an API. See
[Vault](https://supabase.com/docs/guides/database/vault).

### 4. Authorize Storage separately

Keep sensitive buckets **Private**. Private downloads require authorized access or a deliberately
issued, time-limited signed URL. A **Public** bucket bypasses retrieval checks for anyone with the
asset URL; upload, delete, move, and copy operations still undergo access checks. See
[bucket access models](https://supabase.com/docs/guides/storage/buckets/fundamentals).

Application-table policies do not secure Storage objects. Define policies on `storage.objects`,
constrained by both `bucket_id` and the caller's path or ownership. For a private bucket whose
object names begin with the owner's UUID:

```sql
create policy "read own files"
on storage.objects for select
to authenticated
using (
  bucket_id = 'REPLACE_WITH_PRIVATE_BUCKET'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

create policy "upload own files"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'REPLACE_WITH_PRIVATE_BUCKET'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);
```

See [Storage helpers](https://supabase.com/docs/guides/storage/schema/helper-functions) and
[Storage access control](https://supabase.com/docs/guides/storage/security/access-control).

Upload needs INSERT. Upsert additionally needs SELECT and UPDATE policies. If overwrites are
intended, give UPDATE both `USING` and `WITH CHECK` with the same bucket and owner-path condition;
add DELETE only if intended. Remove broader existing policies that would admit other users.
The example above deliberately does not permit overwrites or deletion.

### 5. Require private Realtime channels

At the time of writing, **Allow public access to channels** is enabled by default. Disable it
in Realtime Settings to require private channels. Set `config.private` on clients as well; a
client's private flag alone does not disable public channels for the project. See
[Realtime settings](https://supabase.com/docs/guides/realtime/settings).

For channels named `user:` followed by the authenticated user's UUID:

```javascript
const channel = supabase.channel('user:REPLACE_WITH_AUTHENTICATED_USER_ID', {
  config: { private: true }
});
```

Authorize receiving and sending separately on `realtime.messages`, checking both the topic and
the message extension:

```sql
create policy "receive own channel"
on realtime.messages for select
to authenticated
using (
  (select realtime.topic()) = 'user:' || (select auth.uid())::text
  and extension in ('broadcast', 'presence')
);

create policy "send own channel"
on realtime.messages for insert
to authenticated
with check (
  (select realtime.topic()) = 'user:' || (select auth.uid())::text
  and extension in ('broadcast', 'presence')
);
```

These policies govern Broadcast and Presence; replace the ownership expression with an explicit
membership check for shared rooms. See
[Realtime authorization](https://supabase.com/docs/guides/realtime/authorization).

Postgres Changes uses source-table authorization. Private-channel policies are not a universal
Realtime filter. Test that subscription path separately; in particular, the documented DELETE
event limitations differ from normal row reads. See
[Postgres Changes security and limitations](https://supabase.com/docs/guides/realtime/postgres-changes).

### 6. Limit registration and enforce MFA

For invite-only projects, disable **Allow new users to sign up**. Disable **Allow anonymous
sign-ins** and unused providers unless the application deliberately needs them. Inspect the
hosted project's settings rather than assuming a universal hosted default. See
[Auth configuration](https://supabase.com/docs/guides/auth/general-configuration).

For CLI-managed local configuration in `supabase/config.toml`:

```toml
[auth]
enable_signup = false
enable_anonymous_sign_ins = false
```

At the time of writing, the CLI defaults are `true` and `false`, respectively. Editing this local
file is not evidence that hosted settings changed. See
[the CLI configuration reference](https://supabase.com/docs/guides/local-development/cli/config).

Supabase Auth supports MFA, with TOTP on every plan at the time of writing. Enrolment alone
changes nothing about table authorization: enforce it in your policies by requiring the `aal2`
assurance level, so a session that has not completed the second factor cannot read protected
rows. See [mfa.md](mfa.md),
[TOTP availability](https://supabase.com/docs/guides/auth/auth-mfa/totp), and
[MFA enforcement](https://supabase.com/docs/guides/auth/auth-mfa).

```sql
create policy "mfa required"
on public.profiles as restrictive
to authenticated
using ((select auth.jwt()->>'aal') = 'aal2')
with check ((select auth.jwt()->>'aal') = 'aal2');
```

Keep the applicable permissive ownership policies alongside this restrictive policy. It narrows
their permissions; it does not grant access itself. Repeat the assurance requirement on other
protected surfaces where needed. See
[restrictive policies](https://www.postgresql.org/docs/current/sql-createpolicy.html).

### 7. Authorize Edge Functions before privileged work

[Edge Functions](https://supabase.com/docs/guides/functions) expose server-side handlers.
At the time of writing, platform JWT verification is configured per function and enabled by
default (`verify_jwt = true`). Deploying with `supabase functions deploy --no-verify-jwt`
disables that check, as commonly needed for external webhooks. The handler MUST then
authenticate and authorize callers itself before protected work, for example by verifying
the provider's webhook signature. See the
[deployment CLI reference](https://supabase.com/docs/reference/cli/supabase-functions-deploy)
and [function authentication](https://supabase.com/docs/guides/functions/auth).

Even with JWT verification enabled, authorize the verified caller for the requested resource
and operation. Passing the platform check alone does not establish user authorization:
Supabase also documents API-key compatibility paths through that check. See
[authorization headers and JWT verification](https://supabase.com/docs/guides/functions/auth-headers).

The function environment carries privileged secrets, including the legacy
`SUPABASE_SERVICE_ROLE_KEY`, which bypasses RLS. Treat an unauthenticated function with access
to those credentials as a privileged surface. Keep secrets in managed environment variables,
exclude local secret files from source control, and never expose secret values in responses,
logs, or client bundles. Secret hygiene and in-function authorization are both required. See
[Edge Function secrets](https://supabase.com/docs/guides/functions/secrets).

## Verify

REASONED: disposable-fixture comparisons require controlled projects and accounts; a local Supabase CLI stack opens listeners; the authoring host forbids that without an isolated network namespace, and none was available. Local bash -n and ShellCheck 0.11.0 runs exited 0 without output; stub runs refused placeholders and malformed set lines, and the valid request printed synthetic http=200 exit=0 err=. The bash -n, ShellCheck and stub runs recorded here covered the Verify shell blocks in an earlier form, whose guard refusals left the subshell with status 0 and whose bundle scan result arms ended with status 0, and the stub runs were not repeated. On the current form, whose guard refusals leave the subshell with status 2, whose bundle scan candidate and scan-failure arms exit 1 and 3 and whose failed Supabase GET request exits 3, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run. For identity-based requests, exposed access admits unauthorized fixture data; fixed access denies it while the owner control succeeds, per the guide's cited Firebase security rules and Supabase row level security. Use disposable projects and harmless fixtures for exposed/fixed comparisons. Do not temporarily
open production data. No disposable cloud project, controlled user accounts, deployed client
bundle, or authorized writable service-fixture environment was supplied during authoring. No disposable Firebase or Supabase project or controlled A/B sessions were available for these comparisons; a live Firebase Emulator Suite stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available.
The live authorization comparisons below are REASONED, not demonstrated, from the cited Firebase and Supabase documentation; local shell and scan observations are scoped at their steps.

### 1. Compare unauthenticated, owner, and unrelated-user access

**REASONED:** No Firebase/Supabase test project or controlled A/B sessions was supplied.
Seed a known row owned by user A and one owned by user B first, so an empty result is not mistaken
for enforcement. Seed equivalent Firebase documents, RTDB nodes, and Storage objects.

REASONED: identity and ownership comparisons need disposable projects and A/B sessions, which were unavailable; a local Supabase CLI stack opens listeners; the authoring host forbids that without an isolated network namespace, and none was available. Local bash -n and ShellCheck 0.11.0 runs exited 0 without output; stub runs refused placeholders and malformed set lines, and the valid request printed synthetic http=200 exit=0 err=. The bash -n, ShellCheck and stub runs recorded here covered the Supabase GET block in an earlier form, whose guard refusals left the subshell with status 0; on the current form, whose guard refusals leave the subshell with status 2 and whose failed request exits 3, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run, and the stub runs were not repeated. Open rules or disabled RLS can admit unsigned and unrelated users; fixed rules and policies reject them and retain the intended owner control, per the guide's cited Firebase security rules, Supabase row level security and Supabase multi-factor authentication (aal1, aal2, enforcement policy). With only the public key/config and no signed-in user, reads and writes against protected
tables/paths must be refused or return no rows and change nothing. Signed in as user A, reading
and writing user B's rows must be refused. An authorized owner read on the same path MUST
succeed, so denial is attributable to access controls rather than a broken request or wrong
endpoint. Require owner-write success only for operations the app intentionally permits after
installing their grants and policies. The baseline Supabase policy above permits SELECT only.
With the MFA restriction installed, the positive authenticated test also needs `aal2`.

REASONED: the request matrix needs disposable projects, objects and A/B sessions, which were unavailable; a local Supabase CLI stack opens listeners; the authoring host forbids that without an isolated network namespace, and none was available. Local bash -n and ShellCheck 0.11.0 runs exited 0 without output; stub runs refused placeholders and malformed set lines, and the valid request printed synthetic http=200 exit=0 err=. The bash -n, ShellCheck and stub runs recorded here covered the Supabase GET block in an earlier form, whose guard refusals left the subshell with status 0; on the current form, whose guard refusals leave the subshell with status 2 and whose failed request exits 3, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run, and the stub runs were not repeated. For identity-based requests, exposed rules admit unauthorized requests; ownership rules deny them and permit the owner, per the guide's cited Firebase security rules and Supabase row level security. Rules tightening leaves access through an existing download token intact; token revocation denies that access while the authorized SDK direct-download control still succeeds, per Firebase Storage Admin shareable download URLs, Firebase StorageReference download-token revocation and Firebase Storage SDK direct downloads and browser CORS. Compare the following requests against a disposable exposed fixture and its fixed counterpart:

| Surface | Concrete request and expected distinction |
| --- | --- |
| Firestore | **REASONED:** In the Rules Playground or client test harness, get and write `/users/REPLACE_WITH_USER_B_ID` and `/users/REPLACE_WITH_USER_B_ID/items/probe` without authentication, as A, and as B. Open rules admit the first two identities; the ownership rules deny them and admit B for these operations. Test the user document itself to catch a version-1 recursive-match mistake. See [Firestore rules](https://firebase.google.com/docs/firestore/security/rules-structure). |
| RTDB | **REASONED:** Read and write `/users/REPLACE_WITH_USER_B_ID/probe` with the same identities. An ancestor grant admits unauthorized requests; the fixed rules deny them and admit B. See [RTDB cascading](https://firebase.google.com/docs/database/security/core-syntax). |
| Firebase Storage | **REASONED:** Read and upload `users/REPLACE_WITH_USER_B_ID/probe.txt` through the Storage client. Open or authentication-only rules admit unauthorized access; ownership rules admit B and reject A and unsigned requests. See [Storage rules](https://firebase.google.com/docs/storage/security/core-syntax). |
| Firebase Storage download tokens | **REASONED:** No disposable object, existing download URL, token-revocation access, or owner session was supplied. Save an existing download URL for `users/REPLACE_WITH_USER_B_ID/probe.txt`. With caching disabled and no session, cookies, or Authorization header, send HTTP GET to that exact URL before and after tightening ownership Rules: both should return the object's bytes. Revoke its download token in the Firebase console, keep the object and Rules unchanged, and repeat GET to the same saved URL: require an HTTP denial with no object bytes. A network or CORS failure is inconclusive. Before and after revocation, B's authenticated `getBytes(ref(storage, 'users/REPLACE_WITH_USER_B_ID/probe.txt'))` must still return the bytes; configure browser CORS for the test origin. See [shareable URLs](https://firebase.google.com/docs/storage/admin/start), [token revocation](https://firebase.google.com/docs/reference/kotlin/com/google/firebase/storage/StorageReference), and [direct downloads](https://firebase.google.com/docs/storage/web/download-files). |
| Supabase tables | **REASONED:** Request `GET /rest/v1/profiles?select=user_id&user_id=eq.REPLACE_WITH_USER_B_ID`. With matching grants and RLS disabled, B's seeded row is exposed. With the fixed grants/policies, unsigned requests and A receive no B row; B at the required assurance level receives it. For intentionally enabled writes, use POST to create a disposable profile, PATCH to change it, and DELETE to remove it; inspect persisted state as well as response status. See [select requests](https://supabase.com/docs/reference/javascript/select) and [row-security semantics](https://www.postgresql.org/docs/current/ddl-rowsecurity.html). |

REASONED: header-file preparation was exercised with a nonsecret fixture: the curl stub printed stub curl: headers=apikey: harmless-fixture. The stub run recorded here predates the current form of the Supabase GET block; the current form, whose guard refusals leave the subshell with status 2, has not been run. No disposable Supabase project or controlled user tokens were available; a local Supabase CLI stack opens listeners; the authoring host forbids that without an isolated network namespace, and none was available. Public keys alone must not authorize protected rows, while the intended owner session must succeed, per the guide's cited Supabase API keys (legacy `service_role` is a JWT starting `eyJ`; new `sb_publishable_` and `sb_secret_` keys are short strings) and Supabase row level security. For the Supabase GET comparison, prepare protected header files privately, outside source control.
The unsigned file contains an `apikey` header with the publishable or legacy `anon` key; the
signed-in file also contains `Authorization: Bearer` with the test user's access token.
Do not use a secret or service-role key for an ordinary-user test.

REASONED: live response interpretation requires an actual disposable HTTPS endpoint and controlled sessions; quoting and stdin delivery were exercised only with a stub. No disposable HTTPS endpoint or controlled sessions were available; a local Supabase CLI stack opens listeners; the authoring host forbids that without an isolated network namespace, and none was available. Local bash -n and ShellCheck 0.11.0 runs exited 0 without output; stub runs refused placeholders and malformed set lines, and the valid request printed synthetic http=200 exit=0 err=. A harmless header fixture reached stub stdin and printed stub curl: headers=apikey: harmless-fixture. The bash -n, ShellCheck and stub runs recorded here covered the Supabase GET block in an earlier form, whose guard refusals left the subshell with status 0; on the current form, whose guard refusals leave the subshell with status 2 and whose failed request exits 3, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run, and the stub runs were not repeated. Exposed requests may return another user's rows; fixed requests must withhold them while the owner control succeeds, per the guide's cited Supabase JavaScript select requests, Supabase row level security, curl curl-8_14_1 write-out fields and version requirements (checked October 2026) and curl curl-8_14_1 headers from stdin (checked October 2026). Paste the whole block and substitute inside the single quotes. Use an unsigned HTTPS endpoint
URL, never a credential-bearing or signed URL. The response must contain only your harmless
fixture data. Credentials enter curl through stdin, not process arguments; that does not protect
a carelessly created header file, shell history, or tracing, and it does not hide the
credentials from your own account's view of the process. The write-out fields require curl
7.75.0 or newer.

REASONED: following block; ordinary-user profiles and MFA comparisons; a local Supabase CLI stack opens listeners; the authoring host forbids that without an isolated network namespace, and none was available. Local bash -n and ShellCheck 0.11.0 runs exited 0 without output; stub runs refused placeholders and malformed set lines, and the valid request printed synthetic http=200 exit=0 err=. The bash -n, ShellCheck and stub runs recorded here covered the Supabase GET block in an earlier form, whose guard refusals left the subshell with status 0; on the current form, whose guard refusals leave the subshell with status 2 and whose failed request exits 3, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run, and the stub runs were not repeated. No disposable Supabase project or controlled user sessions were available. Exposed profiles may return another user's rows; fixed policies must deny them while the owner at the required assurance level succeeds, per the guide's cited Supabase JavaScript select requests, Supabase row level security, Supabase multi-factor authentication (aal1, aal2, enforcement policy) and PostgreSQL row-security bypasses and operations outside RLS.

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_HTTPS_REQUEST_URL' 'REPLACE_WITH_PROTECTED_HEADERS_FILE'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not probing"; exit 2; }
  shift
  [ "$#" -eq 2 ] || { echo "the set -- line needs exactly 2 values; not probing"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the request URL; not probing"; exit 2 ;;
    https://*)
      case "$2" in
        *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
          echo "substitute the protected headers file; not probing"; exit 2 ;;
        *)
          if [ -r "$2" ]; then
            if curl -q -g -sS --noproxy '*' --connect-timeout 5 --max-time 20 \
              --header @- --write-out '\nhttp=%{http_code} exit=%{exitcode} err=%{errormsg}\n' \
              --url "$1" < "$2"; then
              echo "block exit 0; unclassified observation: read the body and http= line above, since only you know whether its rows belong to this request's user"
            else
              echo "curl exit $?: the request failed, which proves nothing about authorization; block exit 3, inconclusive"; exit 3
            fi
          else
            echo "headers file is unreadable; no conclusion"; exit 2
          fi ;;
      esac ;;
    *) echo "use the project's HTTPS endpoint; not probing"; exit 2 ;;
  esac
)
```

REASONED: preceding block; this Supabase GET request block and interpretation need a disposable Supabase project and owner sessions, which were unavailable; a local Supabase CLI stack opens listeners; the authoring host forbids that without an isolated network namespace, and none was available. The Firebase ownership note in this paragraph also needs valid App Check tokens, which were unavailable. Local bash -n and ShellCheck 0.11.0 runs exited 0 without output; stub runs refused placeholders and malformed set lines, and the valid request printed synthetic http=200 exit=0 err=. Non-HTTPS input printed use the project's HTTPS endpoint; not probing, and an absent header file printed headers file is unreadable; no conclusion. The bash -n, ShellCheck and stub runs recorded here covered the Supabase GET block in an earlier form, whose guard refusals left the subshell with status 0; on the current form, whose guard refusals leave the subshell with status 2 and whose failed request exits 3, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run, and the stub runs were not repeated. Neither synthetic success nor transport failure demonstrates authorization: exposed reads return unauthorized fixture data; fixed reads deny it while owner reads succeed. That authorization reading is per the guide's cited Supabase JavaScript select requests, Supabase row level security, Per-product App Check enforcement, curl curl-8_14_1 write-out fields and version requirements (checked October 2026) and curl curl-8_14_1 headers from stdin (checked October 2026). A timeout, DNS failure, malformed request, or missing fixture proves nothing about authorization.
Retain the positive owner control. Supply valid App Check tokens when testing Firebase ownership
so an unrelated App Check rejection does not hide an open rule.

### 2. Test views, functions, and indirect access

- **REASONED:** No deployed view inventory or A/B sessions was supplied. Reads through every
  API-exposed view must respect the intended table boundary: request
  `/rest/v1/REPLACE_WITH_VIEW_NAME` with only the public key, then, signed in as user A, request
  user B's rows using the view's actual ownership column. An exposed owner-privileged view can
  return those rows while the table denies them; an invoker view or revoked endpoint must not.
  If it returns them, check owner privileges and overly broad policies. Confirm intended owner
  reads still succeed, or confirm deliberate endpoint removal. See
  [view security](https://www.postgresql.org/docs/current/sql-createview.html).

- **REASONED:** No deployed function inventory or disposable RPC fixtures was supplied. Every
  API-exposed function is checked the same way, because the view check cannot see it: call
  `POST /rest/v1/rpc/REPLACE_WITH_FUNCTION_NAME` with its documented JSON arguments, first with
  only the public key, then as A requesting B's data. A `SECURITY DEFINER` function **can return
  rows** while the table and view checks both look clean; this separate check catches that path.
  Repeat for every overload and use valid, harmless arguments so argument errors do not masquerade
  as authorization. Fixed functions must deny unauthorized data or operations while permitting
  their intended caller. See [RPC calls](https://supabase.com/docs/reference/javascript/rpc)
  and [function privileges](https://supabase.com/docs/guides/database/functions).

- **REASONED:** No outbound-request collector or disposable Vault secret was supplied. For each
  HTTP wrapper, call its RPC with a controlled destination and harmless marker. An exposed
  wrapper may cause an outbound request; after revocation or caller checks, an unauthorized
  request must cause none. Commit an authorized `pg_net` fixture transaction before expecting
  its request. For each Vault-reading wrapper, use a disposable nonsecret canary: an exposed
  function may return it, while the fixed endpoint must withhold it from unauthorized callers.
  Check `has_function_privilege` for each signature and `has_table_privilege` on
  `vault.decrypted_secrets` for both API roles as supporting evidence. See
  [`pg_net`](https://supabase.com/docs/guides/database/extensions/pg_net),
  [Vault](https://supabase.com/docs/guides/database/vault), and
  [privilege checks](https://www.postgresql.org/docs/current/functions-info.html).

### 3. Test Storage and Realtime independently

| Surface | Required exposed/fixed comparison |
| --- | --- |
| Supabase Storage | **REASONED:** No bucket, file fixture, or A/B sessions was supplied. Download B's known file with `supabase.storage.from('REPLACE_WITH_PRIVATE_BUCKET').download('REPLACE_WITH_USER_B_ID/probe.txt')` as A and B; also request its public asset URL without a session. A public bucket serves the public URL; the private, restricted bucket must withhold unauthorized bytes while B's authorized download succeeds. Test fresh uploads and, only if intended, upserts using `{ upsert: true }`; A must not write B's path. See [downloads](https://supabase.com/docs/guides/storage/serving/downloads), [uploads](https://supabase.com/docs/guides/storage/uploads/standard-uploads), and [bucket access](https://supabase.com/docs/guides/storage/buckets/fundamentals). |
| Broadcast and Presence | **REASONED:** No Realtime project or connected A/B clients was supplied. Join `user:REPLACE_WITH_USER_B_ID` as A and B, attempt a Broadcast send and Presence tracking, and observe from B's client. Public channels admit unintended participation when allowed. After disabling public channels, a client without `private: true` must be rejected; the private policies must withhold B's channel operations from A while allowing B. A socket connection alone is not proof of authorized message delivery. See [settings](https://supabase.com/docs/guides/realtime/settings) and [authorization](https://supabase.com/docs/guides/realtime/authorization). |
| Postgres Changes | **REASONED:** No publication or live subscription fixture was supplied. Subscribe as A to INSERT/UPDATE changes on `public.profiles`, then change seeded A and B rows through the controlled fixture. An exposed source table can disclose B's changes; fixed source-table authorization must withhold them while A's intended events arrive. Evaluate DELETE separately against its documented limitations. See [Postgres Changes](https://supabase.com/docs/guides/realtime/postgres-changes). |

### 4. Test Functions, App Check, and emulator exposure

- **REASONED:** No deployed Supabase Edge Function, disposable operation fixture, or caller
  credentials was supplied. Send `POST /functions/v1/REPLACE_WITH_FUNCTION_NAME` to the
  disposable project's function with a valid fixture payload, first without `Authorization`
  or `apikey`, then with `Authorization: Bearer invalid-test-token` and no `apikey`.
  With JWT verification disabled and handler authorization absent, these requests can reach
  privileged work; the corrected handler must reject unauthorized requests before that work.
  With JWT verification enabled, both requests must receive HTTP 401 before the handler runs.
  Omit API keys in these two probes because API-key compatibility can pass the platform check.
  For a webhook, also compare missing/invalid provider signatures with a valid signed request.
  For a user endpoint, compare A attempting B's operation with the authorized owner's request.
  The authorized positive control must succeed; inspect persisted effects as well as response
  status, and check that responses and logs disclose no secrets. See
  [JWT verification](https://supabase.com/docs/guides/functions/auth-headers),
  [handler authentication](https://supabase.com/docs/guides/functions/auth), and
  [secret handling](https://supabase.com/docs/guides/functions/secrets).

- **REASONED:** No deployed callable, HTTP endpoint, or test credentials was supplied. Send
  `POST` with `{"data":{}}` to each callable, first with valid App Check but no user ID token.
  A handler lacking its own authentication check can enter privileged work; the fixed handler
  must reject it. Repeat with A attempting B's operation and with the intended owner. For each
  `onRequest` endpoint, send its valid application request without credentials, with invalid
  credentials, and with the intended verified user or IAM principal. Only the authorized
  request may perform the operation. See [callable protocol](https://firebase.google.com/docs/functions/callable-reference)
  and [ID-token verification](https://firebase.google.com/docs/auth/admin/verify-id-tokens).

- **REASONED:** No registered Firebase app, provider attestation, or deployed clients was supplied.
  Repeat the permitted owner read separately for Firestore, RTDB, and Storage, and the permitted
  callable invocation, with valid user authentication but no App Check token. Registration
  without enforcement allows otherwise permitted requests; enforcement must reject them.
  The compatible client with valid App Check must still succeed. Allow for documented
  enforcement propagation. Test each used Firebase product from the intended restricted app
  and an excluded app/referrer; intended traffic must work and applicable key restrictions
  must reject excluded traffic. See [App Check enforcement](https://firebase.google.com/docs/app-check/enable-enforcement)
  and [API-key restrictions](https://firebase.google.com/docs/projects/api-keys).

- **REASONED:** No writable emulator fixture or second-host network fixture was supplied during authoring; a live Firebase Emulator Suite stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available. Local JSON parsing of the firebase.json fragment passed; live open-rule access should succeed and fixed ownership rules should deny unauthorized access while retaining owner access, per the guide's cited Firebase Emulator Suite configuration, open-rule behavior, and Hub API and Emulator localhost default.
  On the emulator host, inspect `ss -ltn` and request `GET /emulators` on the local Emulator Hub
  to enumerate actual listeners. In an isolated fixture with Rules configuration omitted,
  attempt an unsigned read/write of a seeded path; repeat after loading the ownership rules.
  Open emulators admit the operation; configured rules must deny the unauthorized operation
  and permit the owner. From another host, attempt connections to every enumerated port:
  listeners exposed on that interface can answer, while the fixed localhost-only deployment
  must not. Inspect proxy and tunnel routes as well. A failed connection without a working
  local positive control is inconclusive. See
  [emulator configuration and Hub API](https://firebase.google.com/docs/emulator-suite/install_and_configure)
  and [localhost binding](https://firebase.google.com/docs/emulator-suite/use_hosting).

### 5. Test account controls, MFA, and key retirement

- **REASONED:** No controlled signup accounts or mailboxes was supplied. Use a signed-out
  Firebase Auth context for EACH Anonymous-provider comparison: explicitly `await signOut(auth)`
  and confirm `auth.currentUser === null` before each `await signInAnonymously(auth)` call,
  including the retry after disabling Anonymous. With Anonymous enabled, require a successful
  result and `getAdditionalUserInfo(result)?.isNewUser === true` to confirm account creation.
  With Anonymous disabled, require rejection of new-account creation due to the disabled
  provider; a network failure is inconclusive. An already signed-in anonymous user can be
  returned without creating an account. This tests signup restrictions, not revocation of
  existing sessions. See the [Auth JS reference](https://firebase.google.com/docs/reference/js/auth),
  [new-user indicator](https://firebase.google.com/docs/reference/js/auth.additionaluserinfo), and
  [session revocation](https://firebase.google.com/docs/auth/admin/manage-sessions).
  Test each other disabled provider.
  For email enumeration protection, compare password-sign-in requests for a nonexistent
  address and a known account with a wrong password; protected sign-in responses must not
  reveal that distinction. Do not expect signup to stop returning `EMAIL_EXISTS`. See
  [anonymous authentication](https://firebase.google.com/docs/auth/web/anonymous-auth) and
  [email enumeration behavior](https://docs.cloud.google.com/identity-platform/docs/admin/email-enumeration-protection).

- **REASONED:** No Supabase signup fixture or invited account was supplied. Attempt
  `supabase.auth.signUp()` with a fresh controlled address and
  `supabase.auth.signInAnonymously()`. Enabled methods can create users; the invite-only and
  anonymous-disabled configuration must refuse those creations while an existing invited
  account can still sign in. See [Auth settings](https://supabase.com/docs/guides/auth/general-configuration),
  [password signup](https://supabase.com/docs/guides/auth/passwords), and
  [anonymous sign-ins](https://supabase.com/docs/guides/auth/auth-anonymous).

- **REASONED:** No MFA-enrolled account was supplied. Repeat the owner's
  `GET /rest/v1/profiles` request with fresh `aal1` and `aal2` sessions. Without the restrictive
  policy, ownership alone permits the read; with it, `aal1` must receive no protected rows and
  `aal2` must receive the owner's seeded row. See
  [MFA enforcement](https://supabase.com/docs/guides/auth/auth-mfa).

- **REASONED:** No API-key inventory, signing-key controls, or disposable backend was supplied.
  Repeat a known successful fixture request using the replaced and replacement API keys.
  Merely creating replacements leaves legacy keys valid; explicit deactivation must invalidate
  legacy-key use while replacement credentials still work. Separately test JWTs signed before
  and after signing-key rotation: rotation alone retains both trust relationships; revocation
  must remove trust in the old signing key after the documented propagation and verifier-cache
  behavior. Keep keys and JWTs in protected files or SDK memory. See
  [API-key migration](https://supabase.com/docs/guides/getting-started/migrating-to-new-api-keys)
  and [JWT signing-key lifecycle](https://supabase.com/docs/guides/auth/signing-keys).

- **REASONED:** No hosted Data API settings or schema fixture was supplied. Repeat a previously
  successful `GET /rest/v1/profiles` request after removing its schema from Exposed schemas,
  or after disabling the unused Data API. It must no longer return the fixture through that
  endpoint. Test retained API schemas separately with authorized positive requests. See
  [Data API controls](https://supabase.com/docs/guides/api/securing-your-api).

### 6. Review the client bundle for privileged credentials

**REASONED:** No deployed client bundle or credential inventory was supplied.
Search the client bundle for possible leaked secrets:
`grep -rlIE 'service_role|eyJ|sb_secret_' dist/` lists only files to inspect, so a full key never
lands in a shared terminal or CI log. Use the guarded form below for the actual bundle path.

REASONED: candidate interpretation needs the deployed bundle and credential inventory, which were unavailable. Local synthetic JWT payload decoding printed role=anon and role=service_role; actual grep reported a harmless marker's filename and then exited 1 without output after removal. A public anon key may remain; a confirmed privileged credential must be removed and revoked, per the guide's cited Supabase API keys (legacy `service_role` is a JWT starting `eyJ`; new `sb_publishable_` and `sb_secret_` keys are short strings). Open each flagged file privately and interpret the match rather than expecting none.
A literal `service_role` reference, an `eyJ` substring, or an `sb_secret_` prefix is a **review
candidate**, not proof of a live credential. The public legacy `anon` key is itself a JWT that
legitimately ships in the frontend; new `sb_publishable_...` keys are also intended for clients.
For a complete JWT candidate, decode its payload locally and inspect `role`: `anon` is the
expected legacy public-key role, while a confirmed project `service_role` credential is a leak.
A prefix match alone does not establish that a string is a JWT or a valid key.

REASONED: credential removal and retirement require an actual bundle, confirmed credential and key-lifecycle controls, which were unavailable. Local grep reported a harmless marker's filename and then exited 1 without output after removal; this does not demonstrate revocation. Exposed privileged credentials authorize privileged access; revoked credentials must fail while replacement credentials work, per the guide's cited Supabase API keys (legacy `service_role` is a JWT starting `eyJ`; new `sb_publishable_` and `sb_secret_` keys are short strings) and Supabase API-key migration and legacy-key deactivation. A confirmed `sb_secret_...` key, legacy service-role credential, or private key must not be there:
remove the exposure and rotate or revoke the confirmed credential, not just delete it from the
tree. Do not rotate credentials merely because a source-code word matched. See
[API-key handling](https://supabase.com/docs/guides/getting-started/api-keys) and [secrets.md](secrets.md).

REASONED: following block; credential-candidate review. No deployed client bundle or credential inventory was available. Local bash -n and ShellCheck 0.11.0 exited 0 without output; stub grep statuses 0, 1 and 2 exercised candidate, clean and failure messages. The bash -n, ShellCheck and stub runs recorded here covered the bundle scan block in an earlier form, whose guard refusals left the subshell with status 0 and whose result arms ended with status 0; none was re-run on the current form, whose guard refusals leave the subshell with status 2, whose candidate arm exits 1 and whose scan-failure arm exits 3. Actual grep reported a harmless marker filename and then exited 1 without output after removal; exposed markers should be found and removed markers absent, per the guide's cited Supabase API keys (legacy `service_role` is a JWT starting `eyJ`; new `sb_publishable_` and `sb_secret_` keys are short strings).

```bash
(
  set -- PASTE_WHOLE_BLOCK 'REPLACE_WITH_CLIENT_BUNDLE_DIRECTORY'
  [ "${1-}" = PASTE_WHOLE_BLOCK ] || { echo "paste the whole block, including its set -- line; not scanning"; exit 2; }
  shift
  [ "$#" -eq 1 ] || { echo "the set -- line needs exactly 1 value; not scanning"; exit 2; }
  case "$1" in
    *REPLACE_WITH_*|*'<'*|*'>'*|*example.com*|"")
      echo "substitute the client bundle directory; not scanning"; exit 2 ;;
    *)
      if grep -rlIE 'service_role|eyJ|sb_secret_' -- "$1"; then
        echo "Review candidates in the files listed above; a match is not proof of a leak."; exit 1
      else
        case "$?" in
          1) echo "No candidate strings found; encoded or split secrets can evade this scan." ;;
          *) echo "Scan failed; no conclusion."; exit 3 ;;
        esac
      fi ;;
  esac
)
```

REASONED: preceding block; the guarded scan and review instructions need the actual bundle, build inputs, source maps and credential inventory, which were unavailable. Local bash -n and ShellCheck 0.11.0 exited 0 without output; guard fixtures printed not scanning refusals, and stub grep statuses 0, 1 and 2 printed the candidate-review, no-candidate and Scan failed; no conclusion messages. The bash -n, ShellCheck and stub runs recorded here covered the bundle scan block in an earlier form, whose guard refusals left the subshell with status 0 and whose result arms ended with status 0; none was re-run on the current form, whose guard refusals leave the subshell with status 2, whose candidate arm exits 1 and whose scan-failure arm exits 3. Actual grep reported the harmless marker file and then exited 1 without output after removal. A marker should be found before removal and absent afterwards; a clean scan cannot establish absence of secrets, per the guide's cited Supabase API keys (legacy `service_role` is a JWT starting `eyJ`; new `sb_publishable_` and `sb_secret_` keys are short strings). For the demonstration, place a harmless marker containing a searched prefix in a disposable
bundle and confirm that its filename is reported; remove it and repeat. A clean result does not
prove the absence of encoded, split, binary, or differently shaped credentials. Inspect build
inputs, source maps, and private-key material separately.

### Local validation and REASONED service checks

Both bash blocks passed ShellCheck 0.11.0 and `bash -n` during authoring. Local guard tests refused
embedded `REPLACE_WITH_` placeholders, `example.com`, angle brackets, empty values, and omitted
or shortened `set --` lines. Both URL and header-file placeholder positions were checked.
A ShellCheck canary produced the expected SC2086 finding.

The RTDB JSON, `firebase.json` fragment, Auth TOML, and callable JavaScript passed local parsing
checks. These checks establish syntax and the stated shell behavior only; they do not compile
Firebase Rules, execute SQL policies, or demonstrate service authorization. The replacement
was not installed in the repository, and no whole-corpus gate result is claimed.

REASONED: tool-version provenance for the historical local runs above; the [ShellCheck v0.11.0 changelog](https://github.com/koalaman/shellcheck/blob/v0.11.0/CHANGELOG.md#L1) identifies the release named as ShellCheck 0.11.0 in this guide's run record, but does not establish which binary the authoring host ran. The bash -n, ShellCheck and guard-test runs recorded above covered both bash blocks in an earlier form, whose guard refusals left the subshell with status 0 and whose bundle scan result arms ended with status 0, and the guard tests were not repeated. On the current form, whose guard refusals leave the subshell with status 2, whose bundle scan candidate and scan-failure arms exit 1 and 3 and whose failed Supabase GET request exits 3, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run. Bash and other tool/parser versions were not recorded and remain unrecorded. This guide's assessment of the recorded checks is limited to syntax and the stated shell behaviour, not Firebase Rules compilation, SQL execution or service authorization.

| Scope | Exposed/fixed checks and prerequisites | Status |
| --- | --- | --- |
| Firebase and Supabase | Check every REASONED comparison above using disposable Firebase and Supabase projects, controlled A/B accounts and mailboxes, MFA sessions, registered App Check clients, a writable emulator/service fixture, a second host, Storage objects, Realtime clients, view/RPC inventories, an outbound-request collector, a Vault canary, key-lifecycle controls, and the actual client build. Record versions, effective rules/grants/settings, requests, responses, persisted write results, positive controls, propagation intervals, and cleanup. Include (1 of 3): all three Firebase Rules engines, Firebase Functions, Supabase Edge Functions (using deployed operation fixtures and caller/webhook credentials to compare JWT verification enabled/disabled, handler authorization, positive controls, persisted effects, and secret hygiene), emulators, API restrictions. The items to include (2 of 3): signup (including signed-out Anonymous-provider comparisons that confirm new-account creation when enabled and rejection when disabled), Data API removal, views, every function overload, HTTP wrappers, Vault. The items to include (3 of 3): Storage (including sessionless GET of the same saved download URL before and after Rules tightening and token revocation, with an authorized SDK direct-download positive control), both Realtime authorization paths, MFA, API-key retirement, JWT-signing-key revocation, and bundle-scan controls. | REASONED: this comparison record requires every project, account, service, second-host, collector and lifecycle capability enumerated in this row; those live fixtures were unavailable. No disposable Firebase or Supabase project or controlled A/B sessions were available for these comparisons; a live Firebase Emulator Suite stand-up opens a listener; the authoring host forbids that without an isolated network namespace, and none was available; a local Supabase CLI stack opens listeners; the authoring host forbids that without an isolated network namespace, and none was available. Local bash -n and ShellCheck 0.11.0 runs exited 0 without output; stub runs refused placeholders and malformed set lines, and the valid request printed synthetic http=200 exit=0 err=. The bash -n, ShellCheck and stub runs recorded here covered the Verify shell blocks in an earlier form, whose guard refusals left the subshell with status 0 and whose bundle scan result arms ended with status 0, and the stub runs were not repeated. On the current form, whose guard refusals leave the subshell with status 2, whose bundle scan candidate and scan-failure arms exit 1 and 3 and whose failed Supabase GET request exits 3, only the repository gate suite's bash -n and ShellCheck 0.11.0 checks run. Local grep reported a harmless marker file and exited 1 without output after its removal; synthetic JWT decoding printed role=anon and role=service_role. The identity-based authorization comparisons require unauthorized access in the exposed state and rejection in the fixed state with intended positive controls; key retirement additionally requires old credentials to fail while replacements work. The requirements for the identity-based authorization comparisons and for key retirement are per the guide's cited Firebase security rules, Supabase row level security, Supabase API keys (legacy `service_role` is a JWT starting `eyJ`; new `sb_publishable_` and `sb_secret_` keys are short strings) and Supabase JWT signing-key rotation and revocation. Rules tightening leaves access through an existing download token intact; token revocation denies that access while the authorized SDK direct-download control still succeeds, per Firebase Storage Admin shareable download URLs, Firebase StorageReference download-token revocation and Firebase Storage SDK direct downloads and browser CORS. Each other surface named in this row rests on the Sources entry cited at its step above. Live behavior is not demonstrated. |

## Sources (checked September 2026)

- Firebase security rules: https://firebase.google.com/docs/rules
- Supabase API keys (legacy `service_role` is a JWT starting `eyJ`; new `sb_publishable_` and `sb_secret_` keys are short strings): https://supabase.com/docs/guides/getting-started/api-keys
- Supabase row level security: https://supabase.com/docs/guides/database/postgres/row-level-security
- Supabase multi-factor authentication (aal1, aal2, enforcement policy): https://supabase.com/docs/guides/auth/auth-mfa
- PostgreSQL `CREATE VIEW` (base relations checked against the view owner's permissions by default; the view owner's RLS policies applied by default; `security_invoker`): https://www.postgresql.org/docs/current/sql-createview.html
- PostgreSQL `ALTER VIEW` (`SET ( security_invoker = ... )` on an existing view): https://www.postgresql.org/docs/current/sql-alterview.html
- PostgreSQL `REVOKE`: https://www.postgresql.org/docs/current/sql-revoke.html
- Supabase RLS and views (`security_invoker = true` on PostgreSQL 15 and above; revoke or unexpose on older versions; views are typically created by the `postgres` user): https://supabase.com/docs/guides/database/postgres/row-level-security
- PostgreSQL 15 release notes (view accesses "were always treated as being done by the view's owner. That's still the default."): https://www.postgresql.org/docs/release/15.0/
- [Firebase basic rules, ownership examples, and conflicting Storage default prose/example](https://firebase.google.com/docs/rules/basics).
- [Firestore starting modes](https://firebase.google.com/docs/firestore/quickstart).
- [RTDB starting modes and test-rule expiry](https://firebase.google.com/docs/database/web/start).
- [Firebase release notes: month-long test-rule access](https://firebase.google.com/support/releases).
- [Firestore rule structure, recursive wildcards, overlapping grants, and server access](https://firebase.google.com/docs/firestore/security/rules-structure).
- [RTDB rule syntax and cascading](https://firebase.google.com/docs/database/security/core-syntax).
- [Storage rule syntax](https://firebase.google.com/docs/storage/security/core-syntax).
- [Firestore rule testing and deployment](https://firebase.google.com/docs/firestore/security/get-started).
- [Storage rule management](https://firebase.google.com/docs/storage/security/get-started).
- [Second-generation callable handlers](https://firebase.google.com/docs/functions/callable).
- [Callable protocol and optional authentication](https://firebase.google.com/docs/functions/callable-reference).
- [First-generation callable handlers](https://firebase.google.com/docs/functions/1st-gen/callable-1st).
- [Firebase ID-token verification](https://firebase.google.com/docs/auth/admin/verify-id-tokens).
- [Firebase HTTP handlers](https://firebase.google.com/docs/functions/http-events).
- [Second-generation HTTPS invoker options](https://firebase.google.com/docs/reference/functions/2nd-gen/node/firebase-functions.https.httpsoptions).
- [Callable App Check enforcement and SDK requirement](https://firebase.google.com/docs/app-check/cloud-functions).
- [App Check provider registration and client rollout](https://firebase.google.com/docs/app-check/web/recaptcha-enterprise-provider).
- [Per-product App Check enforcement](https://firebase.google.com/docs/app-check/enable-enforcement).
- [Firebase API-key restrictions and required API table](https://firebase.google.com/docs/projects/api-keys).
- [Google Cloud API-key application restrictions](https://docs.cloud.google.com/api-keys/docs/add-restrictions-api-keys).
- [Public Firebase configuration identifiers](https://firebase.google.com/docs/web/learn-more).
- [Firebase anonymous authentication](https://firebase.google.com/docs/auth/web/anonymous-auth).
- [Email enumeration protection, defaults, and remaining signup errors](https://docs.cloud.google.com/identity-platform/docs/admin/email-enumeration-protection).
- [Firebase Emulator Suite configuration, open-rule behavior, and Hub API](https://firebase.google.com/docs/emulator-suite/install_and_configure).
- [Emulator localhost default](https://firebase.google.com/docs/emulator-suite/use_hosting).
- [Supabase Data API security, grants transition, explicit RLS, and API disablement](https://supabase.com/docs/guides/api/securing-your-api).
- [Supabase exposed and custom schemas](https://supabase.com/docs/guides/api/using-custom-schemas).
- [PostgreSQL row-security bypasses and operations outside RLS](https://www.postgresql.org/docs/current/ddl-rowsecurity.html).
- [PostgreSQL policy syntax and permissive/restrictive policy combination](https://www.postgresql.org/docs/current/sql-createpolicy.html).
- [Supabase API-key migration and legacy-key deactivation](https://supabase.com/docs/guides/getting-started/migrating-to-new-api-keys).
- [Supabase JWT signing-key rotation and revocation](https://supabase.com/docs/guides/auth/signing-keys).
- [Supabase function security and privileges](https://supabase.com/docs/guides/database/functions).
- [PostgreSQL function security and default PUBLIC execution](https://www.postgresql.org/docs/current/sql-createfunction.html).
- [PostgreSQL function settings](https://www.postgresql.org/docs/current/sql-alterfunction.html).
- [PostgreSQL default privileges and global versus schema-specific grants](https://www.postgresql.org/docs/current/sql-alterdefaultprivileges.html).
- [PostgreSQL privilege inquiry functions](https://www.postgresql.org/docs/current/functions-info.html).
- [Supabase HTTP extension](https://supabase.com/docs/guides/database/extensions/http).
- [Supabase pg_net signatures and transaction behavior](https://supabase.com/docs/guides/database/extensions/pg_net).
- [Supabase Vault and its decrypted view](https://supabase.com/docs/guides/database/vault).
- [Supabase Storage bucket access models](https://supabase.com/docs/guides/storage/buckets/fundamentals).
- [Supabase Storage policies and upsert requirements](https://supabase.com/docs/guides/storage/security/access-control).
- [Supabase Storage path helpers](https://supabase.com/docs/guides/storage/schema/helper-functions).
- [Supabase Storage downloads](https://supabase.com/docs/guides/storage/serving/downloads).
- [Supabase Storage uploads](https://supabase.com/docs/guides/storage/uploads/standard-uploads).
- [Supabase Realtime settings and public-channel default](https://supabase.com/docs/guides/realtime/settings).
- [Supabase Broadcast and Presence authorization](https://supabase.com/docs/guides/realtime/authorization).
- [Supabase Postgres Changes security and limitations](https://supabase.com/docs/guides/realtime/postgres-changes).
- [Supabase Auth signup and anonymous-access settings](https://supabase.com/docs/guides/auth/general-configuration).
- [Supabase CLI Auth configuration and defaults](https://supabase.com/docs/guides/local-development/cli/config).
- [Supabase password signup](https://supabase.com/docs/guides/auth/passwords).
- [Supabase anonymous sign-ins](https://supabase.com/docs/guides/auth/auth-anonymous).
- [Supabase TOTP availability and assurance-level transitions](https://supabase.com/docs/guides/auth/auth-mfa/totp).
- [Supabase JavaScript select requests](https://supabase.com/docs/reference/javascript/select).
- [Supabase JavaScript RPC requests](https://supabase.com/docs/reference/javascript/rpc).
- [Supabase Edge Functions overview](https://supabase.com/docs/guides/functions).
- [Supabase Edge Function deployment CLI and JWT-verification flag](https://supabase.com/docs/reference/cli/supabase-functions-deploy).
- [Supabase Edge Function authentication and webhook verification](https://supabase.com/docs/guides/functions/auth).
- [Supabase Edge Function authorization headers, per-function JWT verification, and API-key compatibility](https://supabase.com/docs/guides/functions/auth-headers).
- [Supabase Edge Function secrets and privileged environment credentials](https://supabase.com/docs/guides/functions/secrets).
- [Supabase database Network Restrictions](https://supabase.com/docs/guides/platform/network-restrictions).
- [Supabase Postgres SSL enforcement](https://supabase.com/docs/guides/platform/ssl-enforcement).
- [Supabase database roles and password handling](https://supabase.com/docs/guides/database/postgres/roles).
- [Firebase Authentication JavaScript reference (anonymous sign-in and existing-user reuse)](https://firebase.google.com/docs/reference/js/auth).
- [Firebase AdditionalUserInfo isNewUser indicator](https://firebase.google.com/docs/reference/js/auth.additionaluserinfo).
- [Firebase Admin session revocation](https://firebase.google.com/docs/auth/admin/manage-sessions).
- [Firebase Storage Admin shareable download URLs](https://firebase.google.com/docs/storage/admin/start).
- [Firebase StorageReference download-token revocation](https://firebase.google.com/docs/reference/kotlin/com/google/firebase/storage/StorageReference).
- [Firebase Storage SDK direct downloads and browser CORS](https://firebase.google.com/docs/storage/web/download-files).
- [curl curl-8_14_1 write-out fields and version requirements (checked October 2026)](https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/write-out.md#L75-L79).
- [curl curl-8_14_1 headers from stdin (checked October 2026)](https://raw.githubusercontent.com/curl/curl/curl-8_14_1/docs/cmdline-opts/header.md).
- [ShellCheck v0.11.0 changelog release entry (checked October 2026)](https://github.com/koalaman/shellcheck/blob/v0.11.0/CHANGELOG.md#L1).


<!-- version-basis:start -->
## About the AI assistant section below

This generated section holds the recorded versions, claim statuses and source mappings for AI assistants; use [the prompt at the top](#ai-assistant-prompt). This guide is guidance to verify against your own deployment, not a certification, an audit, or a guarantee of compliance with any standard.

**Version basis**

AI assistants must compare the versions listed below with current releases and treat this guide as guidance, re-verifying version-specific defaults when newer releases exist.

DEMONSTRATED refers to historical evidence in this guide; REASONED records source reasoning, and any earlier-form run it rests on, not a live demonstration of the shipped form. Unknown means no version recorded.

Components (recorded basis):

- firebase: Firebase documentation (unknown)
- supabase: Supabase documentation (unknown)
- postgres: PostgreSQL documentation (unknown)
- postgres-view: PostgreSQL invoker-view minimum (15)
- curl: curl (curl-8_14_1)
- shellcheck: ShellCheck (v0.11.0)

Claims (full source mapping in the JSON block below):

- public-config (REASONED; firebase, supabase): Firebase API keys/config and Supabase publishable/anon keys are public identifiers, not authorization; hosted endpoints handle TLS.
- firebase-ownership (REASONED; firebase): Require authentication and ownership separately in Firestore, RTDB and Storage; authentication-only rules do not isolate users.
- firebase-starting (REASONED; firebase): Firestore production and RTDB locked modes deny clients; test templates expose data for about a month. Inspect expiry and replace open rules.
- firestore-rules (REASONED; firebase): Rules version 2 recursive wildcards include the user document and descendants; version 1 excludes the parent. Unmatched paths deny and overlapping grants can reopen access.
- rtdb-rules (REASONED; firebase): Owner rules under users.$uid need ancestor grants removed; child rules cannot revoke parent grants or filter parent reads.
- firebase-storage (REASONED; firebase): Storage has separate rules; conflicting default prose/example warrants explicit deny-all followed by deliberate owner-path access.
- firebase-download (REASONED; firebase): Storage download URLs are non-expiring bearer credentials unaffected by tighter Rules; revoke tokens and use authorized getBlob/getBytes direct downloads.
- firebase-rule-deploy (REASONED; firebase): Inspect and test deployed rules for every database/bucket/instance; keep local and deployed definitions synchronized.
- firebase-server (REASONED; firebase): Admin SDK/server credentials bypass client Rules; keep credentials server-side and apply IAM and caller authorization.
- firebase-callable (REASONED; firebase): Callable ID-token validation is optional authentication; reject missing request.auth, use its UID and validate resource access. First-generation handlers use context.auth.
- firebase-callable-appcheck (REASONED; firebase): onCall enforceAppCheck needs firebase-functions 4.0.0 or newer; App Check does not replace caller/resource authorization.
- firebase-http (REASONED; firebase): onRequest does not inherit callable auth; verify end-user tokens with verifyIdToken or restrict IAM invokers, then authorize the intended principal.
- firebase-appcheck (REASONED; firebase): Register compatible clients and inspect metrics, then enforce App Check per product and per callable; registration alone enforces nothing.
- firebase-key-restrictions (REASONED; firebase): Apply one app-restriction type per key plus API restrictions; separate platforms and unrelated billable APIs, using the full Firebase product table.
- firebase-anonymous (REASONED; firebase): Anonymous sign-in is opt-in; disable unused providers because anonymous accounts still satisfy authentication-only Rules.
- firebase-enumeration (REASONED; firebase): Email enumeration protection defaults on only for projects created from September 15, 2023; signup can still return EMAIL_EXISTS.
- firebase-emulators (REASONED; firebase): Emulators default to localhost but missing Firestore/RTDB/Storage Rules configuration means open data; keep listeners, UI, hub, proxies and tunnels private.
- supabase-network (REASONED; supabase): Restrict hosted database/pooler client IPs with Network Restrictions, enforce SSL and protect database-role passwords.
- supabase-grants (REASONED; supabase): Data API access needs grants plus RLS; automatic-grant defaults are transitioning. Table Editor enables RLS, while SQL creation needs explicit enablement.
- supabase-select (REASONED; supabase, postgres): The profiles baseline enables RLS, revokes broad grants and permits authenticated owners SELECT; audit inherited/column grants and existing policies.
- supabase-bypass (REASONED; postgres): With RLS enabled and no policy, ordinary subject roles get no rows; owners normally bypass, as do superusers/BYPASSRLS roles. TRUNCATE is outside RLS.
- supabase-writes (REASONED; supabase, postgres): Grant and policy INSERT/UPDATE/DELETE only when intended; UPDATE checks old/new ownership and needs applicable SELECT when reading columns.
- supabase-schemas (REASONED; supabase): public is exposed by default; restrict exposed schemas and deliberately grant schema/object access. Schema selection does not replace RLS.
- supabase-api-disable (REASONED; supabase): Disable an unused Data API to close generated REST endpoints; this does not disable all other services.
- supabase-keys (REASONED; supabase): Publishable keys select anon or authenticated by session; secret and legacy service_role keys bypass RLS and belong only on trusted servers.
- supabase-key-retire (REASONED; supabase): Replacement keys do not disable legacy keys; migrate consumers then explicitly deactivate legacy keys, or delete compromised secret keys.
- supabase-jwt-retire (REASONED; supabase): Rotation changes the signing key but retains previous trust until revocation; account for verifier caches and propagation.
- supabase-view-owner (REASONED; postgres, supabase): Views use owner privileges/policies by default; disclosure depends on reachable schemas, grants, query and owner privileges, not anon-key possession alone.
- supabase-view-invoker (REASONED; postgres-view, postgres): PostgreSQL 15+ security_invoker views apply caller policies and require underlying privileges.
- supabase-view-legacy (REASONED; postgres): PostgreSQL 14 and earlier require revoking all view privileges from PUBLIC/anon/authenticated or unexposing the schema; updatable views can bypass RLS for writes.
- supabase-functions (REASONED; supabase, postgres): Prefer INVOKER; restrict DEFINER execution, use empty search_path with qualified references and enforce caller authorization including required MFA.
- supabase-function-defaults (REASONED; postgres): New functions grant PUBLIC execution; create privileged functions and restrict grants transactionally. Global/default revocations are creator-specific and do not fix existing functions.
- supabase-http (REASONED; supabase): Audit http/pg_net wrappers and revoke unneeded execute grants; constrain callers/destinations/data. Extension enablement alone does not prove exploitable SSRF.
- supabase-vault (REASONED; supabase): Restrict vault.decrypted_secrets and privileged wrappers and keep Vault unexposed; at-rest encryption cannot prevent authorized plaintext queries.
- supabase-buckets (REASONED; supabase): Private downloads need authorized access or time-limited signed URLs; public buckets bypass retrieval checks but not upload/delete/move/copy controls.
- supabase-storage-policies (REASONED; supabase): Authorize storage.objects separately by bucket and owner path; upload needs INSERT, upsert also SELECT/UPDATE, and deletion needs deliberate permission.
- supabase-realtime-default (REASONED; supabase): Public Realtime channels are allowed by default; disable them project-wide and also set client config.private.
- supabase-realtime-policy (REASONED; supabase): Broadcast/Presence receive/send need separate SELECT/INSERT policies on realtime.messages, constrained by topic ownership and extension.
- supabase-changes (REASONED; supabase): Postgres Changes uses source-table authorization; private-channel policies are not universal and DELETE has separate limitations.
- supabase-signup (REASONED; supabase): Disable signup, anonymous sign-ins and unused providers when unwanted; inspect hosted settings instead of assuming universal defaults.
- supabase-cli-auth (REASONED; supabase): CLI enable_signup defaults true and enable_anonymous_sign_ins false; local config edits do not prove hosted settings changed.
- supabase-mfa (REASONED; supabase, postgres): TOTP is available on every plan at writing; enrollment alone does not constrain data. Require aal2 using a restrictive policy alongside permissive ownership policies.
- supabase-edge-jwt (REASONED; supabase): Per-function verify_jwt defaults true; --no-verify-jwt disables platform checking and requires handler authentication before protected work.
- supabase-edge-auth (REASONED; supabase): Platform JWT success is not resource authorization and API-key compatibility can pass it; separately authorize users or verify webhook signatures.
- supabase-edge-secrets (REASONED; supabase): Edge environments contain privileged credentials including SUPABASE_SERVICE_ROLE_KEY; protect managed/local secrets, responses, logs and client bundles.
- verify-firestore (REASONED; firebase): Compare unsigned/A/B reads and writes to user documents and descendants, with a successful owner control; test parent documents to distinguish recursive-rule versions.
- verify-rtdb (REASONED; firebase): Compare unsigned/A/B reads/writes to seeded RTDB owner paths; ancestor grants expose them while ownership rules deny unauthorized callers.
- verify-firebase-storage (REASONED; firebase): Compare unsigned/A/B object reads and uploads; ownership rules must deny unrelated callers while owner operations succeed.
- verify-download-token (REASONED; firebase): Same sessionless download URL works after Rules tightening but must lose bytes after token revocation; owner getBytes remains successful and network/CORS failures are inconclusive.
- verify-tables (REASONED; supabase, postgres, curl): Pair unsigned/A/B profiles GETs against seeded rows, using ordinary credentials and required MFA; test intended writes and persisted effects separately.
- verify-views (REASONED; postgres): Compare view reads with table boundaries; owner-privileged exposure must close under invoker/revoked access while intended reads or deliberate removal are confirmed.
- verify-rpc (REASONED; supabase): Test every API function overload with valid harmless arguments as unsigned/A/B; unauthorized data or operations must be denied while the intended caller succeeds.
- verify-http (REASONED; supabase): Probe HTTP wrappers with a controlled collector and marker; unauthorized fixed calls must emit no request. Commit pg_net fixture transactions before expecting delivery.
- verify-vault (REASONED; supabase, postgres): Use a disposable Vault canary to compare exposed/fixed wrappers; inspect function and table privileges as supporting evidence.
- verify-storage (REASONED; supabase): Compare public URL and A/B private downloads plus intended uploads/upserts; unauthorized callers must receive no bytes or cross-owner writes.
- verify-realtime (REASONED; supabase): Compare A/B join, Broadcast and Presence delivery; public-disabled clients lacking private=true must fail, and connection alone is insufficient.
- verify-changes (REASONED; supabase): Observe A/B INSERT/UPDATE subscription events against seeded rows; fixed table authorization withholds unrelated events. Evaluate DELETE separately.
- verify-edge (REASONED; supabase): Compare no/invalid Bearer without apikey, authorized owners and valid webhook signatures; distinguish platform 401 from handler authorization and inspect effects/secrets.
- verify-firebase-functions (REASONED; firebase): Compare callable requests with valid App Check but missing user auth and A/B operations; HTTP endpoints need separate invalid/valid user or IAM comparisons.
- verify-appcheck (REASONED; firebase): Repeat owner requests with/without App Check per product/callable; enforcement must deny missing attestation while compatible clients work.
- verify-api-restrictions (REASONED; firebase): Test intended versus excluded apps/referrers after key restrictions, retaining successful intended product traffic.
- verify-emulators (REASONED; firebase): Enumerate hub /emulators and sockets, compare missing versus loaded Rules and second-host connectivity, and retain local owner controls.
- verify-firebase-accounts (REASONED; firebase): Sign out before each Anonymous signup test and check isNewUser; disabled providers must reject creation. Enumeration tests compare sign-in errors, not EMAIL_EXISTS signup behavior.
- verify-supabase-accounts (REASONED; supabase): Fresh signup and anonymous creation must fail under invite-only/anonymous-disabled settings while an invited account still signs in.
- verify-mfa (REASONED; supabase): Owner profiles GET with aal1 must yield no protected rows under the restrictive policy, while fresh aal2 returns the seeded owner row.
- verify-key-retirement (REASONED; supabase): Compare old/new API keys after explicit deactivation and old/new JWTs after revocation, accounting for propagation and caches.
- verify-api-removal (REASONED; supabase): Previously successful profiles requests must stop returning fixtures after schema removal or Data API disabling; retained schemas need authorized controls.
- verify-bundle (REASONED; supabase): Filename-only service_role/eyJ/sb_secret_ scanning yields review candidates, not proof of leaks; public anon JWTs are legitimate. Use a marker control and inspect encoded/split secrets separately.
- local-guards (DEMONSTRATED; supabase, shellcheck): Historical local guard tests rejected placeholders and malformed set lines; this guide's assessment is shell behavior only, not live authorization. The recorded ShellCheck 0.11.0 has a release citation, not host-binary evidence; bash and other tool/parser versions are unrecorded. Runs covered earlier forms, whose guard refusals and bundle scan result arms exited 0; current forms were not re-run.
- local-syntax (DEMONSTRATED; firebase, supabase, shellcheck): Recorded ShellCheck 0.11.0/bash and JSON/TOML/JavaScript parsing passed; this guide's assessment is that these checks do not compile Firebase Rules, execute SQL or demonstrate services. Only the ShellCheck release is cited; other versions are unrecorded. Bash runs covered earlier forms, whose guard refusals and bundle scan result arms exited 0; current forms get only gate bash -n and ShellCheck.

````json
{
  "schema": 1,
  "checked": "2026-10-19",
  "documentation_checked": "2026-09",
  "body_sha256": "123ba439da8cac4dcfc5cbd4168affb2597f99eb8b09e31193a4e9523bab3428",
  "components": {
    "firebase": {
      "name": "Firebase documentation",
      "basis": "unknown",
      "sources": {
        "s100c2cdbdd59": "https://firebase.google.com/docs/rules",
        "s53bfe8b21868": "https://firebase.google.com/docs/rules/basics",
        "s622d3bb0665b": "https://firebase.google.com/docs/firestore/quickstart",
        "sb2c933c841ef": "https://firebase.google.com/docs/database/web/start",
        "s75f018e0fac7": "https://firebase.google.com/support/releases",
        "s7bd11c22c7ce": "https://firebase.google.com/docs/firestore/security/rules-structure",
        "sa6b1c4933e6a": "https://firebase.google.com/docs/database/security/core-syntax",
        "s0a7f54463abd": "https://firebase.google.com/docs/storage/security/core-syntax",
        "sd6071548f6fe": "https://firebase.google.com/docs/firestore/security/get-started",
        "s14872143a9e8": "https://firebase.google.com/docs/storage/security/get-started",
        "sc8f214d059d2": "https://firebase.google.com/docs/functions/callable",
        "s79da8f65f90a": "https://firebase.google.com/docs/functions/callable-reference",
        "s9a86df9623a6": "https://firebase.google.com/docs/functions/1st-gen/callable-1st",
        "s49f78d054708": "https://firebase.google.com/docs/auth/admin/verify-id-tokens",
        "s1bb711c9afeb": "https://firebase.google.com/docs/functions/http-events",
        "sc9f86ea271f6": "https://firebase.google.com/docs/reference/functions/2nd-gen/node/firebase-functions.https.httpsoptions",
        "sb0ff8f1726f7": "https://firebase.google.com/docs/app-check/cloud-functions",
        "sa71e958c99df": "https://firebase.google.com/docs/app-check/web/recaptcha-enterprise-provider",
        "sba7129c83405": "https://firebase.google.com/docs/app-check/enable-enforcement",
        "safeed4cd2b67": "https://firebase.google.com/docs/projects/api-keys",
        "sc78d5eb59b65": "https://docs.cloud.google.com/api-keys/docs/add-restrictions-api-keys",
        "sb0d26775f3b4": "https://firebase.google.com/docs/web/learn-more",
        "s77e2cbd8a29a": "https://firebase.google.com/docs/auth/web/anonymous-auth",
        "s06808e4b6965": "https://docs.cloud.google.com/identity-platform/docs/admin/email-enumeration-protection",
        "sd8a1bda29f5c": "https://firebase.google.com/docs/emulator-suite/install_and_configure",
        "s69d9721c7f29": "https://firebase.google.com/docs/emulator-suite/use_hosting",
        "s8c90f9f6c7fa": "https://firebase.google.com/docs/reference/js/auth",
        "s8c8336ec252e": "https://firebase.google.com/docs/reference/js/auth.additionaluserinfo",
        "s142e56472093": "https://firebase.google.com/docs/auth/admin/manage-sessions",
        "s9b7e57b472c7": "https://firebase.google.com/docs/storage/admin/start",
        "sa0584b797732": "https://firebase.google.com/docs/reference/kotlin/com/google/firebase/storage/StorageReference",
        "sfd1e7412abf6": "https://firebase.google.com/docs/storage/web/download-files"
      }
    },
    "supabase": {
      "name": "Supabase documentation",
      "basis": "unknown",
      "sources": {
        "s65d5b8043bad": "https://supabase.com/docs/guides/getting-started/api-keys",
        "s46cff2590323": "https://supabase.com/docs/guides/database/postgres/row-level-security",
        "s741468ff35a9": "https://supabase.com/docs/guides/auth/auth-mfa",
        "s6d5cf2d4dbf3": "https://supabase.com/docs/guides/api/securing-your-api",
        "s20ef046ac646": "https://supabase.com/docs/guides/api/using-custom-schemas",
        "sa946354db383": "https://supabase.com/docs/guides/getting-started/migrating-to-new-api-keys",
        "sfc2f9ae0232b": "https://supabase.com/docs/guides/auth/signing-keys",
        "s8405a9fb4b74": "https://supabase.com/docs/guides/database/functions",
        "s13da01bbbba5": "https://supabase.com/docs/guides/database/extensions/http",
        "s76740bffcb32": "https://supabase.com/docs/guides/database/extensions/pg_net",
        "s47bb8fa3e14e": "https://supabase.com/docs/guides/database/vault",
        "s1567fb838f20": "https://supabase.com/docs/guides/storage/buckets/fundamentals",
        "sdba7d7b6dcf8": "https://supabase.com/docs/guides/storage/security/access-control",
        "s9e1484f46eff": "https://supabase.com/docs/guides/storage/schema/helper-functions",
        "sc29febbb230e": "https://supabase.com/docs/guides/storage/serving/downloads",
        "see2d3be99ebd": "https://supabase.com/docs/guides/storage/uploads/standard-uploads",
        "s5674b1057e14": "https://supabase.com/docs/guides/realtime/settings",
        "s84efad0ba39d": "https://supabase.com/docs/guides/realtime/authorization",
        "s694eab64f2ec": "https://supabase.com/docs/guides/realtime/postgres-changes",
        "sc797f0b63472": "https://supabase.com/docs/guides/auth/general-configuration",
        "s3a5e39fe7b4d": "https://supabase.com/docs/guides/local-development/cli/config",
        "sa2dd4637969e": "https://supabase.com/docs/guides/auth/passwords",
        "sad79d4d1b6ee": "https://supabase.com/docs/guides/auth/auth-anonymous",
        "s182755725d74": "https://supabase.com/docs/guides/auth/auth-mfa/totp",
        "s92b405dc3c7e": "https://supabase.com/docs/reference/javascript/select",
        "s087c8cf42ab0": "https://supabase.com/docs/reference/javascript/rpc",
        "s7dfbb47b5d20": "https://supabase.com/docs/reference/cli/supabase-functions-deploy",
        "sf7d438b8c080": "https://supabase.com/docs/guides/functions/auth",
        "se52bbd097033": "https://supabase.com/docs/guides/functions/auth-headers",
        "sb3c4c0993e14": "https://supabase.com/docs/guides/functions/secrets",
        "sb787b5d63633": "https://supabase.com/docs/guides/platform/network-restrictions",
        "s83e15676e1ff": "https://supabase.com/docs/guides/platform/ssl-enforcement",
        "sf69cafb4bc6c": "https://supabase.com/docs/guides/database/postgres/roles"
      }
    },
    "postgres": {
      "name": "PostgreSQL documentation",
      "basis": "unknown",
      "sources": {
        "s13c54ab9cc6b": "https://www.postgresql.org/docs/current/sql-createview.html",
        "saa99ef28f60f": "https://www.postgresql.org/docs/current/sql-alterview.html",
        "sb6224f4ac866": "https://www.postgresql.org/docs/current/sql-revoke.html",
        "se9846041ce1f": "https://www.postgresql.org/docs/current/ddl-rowsecurity.html",
        "s8e65a2f3f2bb": "https://www.postgresql.org/docs/current/sql-createpolicy.html",
        "sec39c317b06f": "https://www.postgresql.org/docs/current/sql-createfunction.html",
        "s0fe66d71aa10": "https://www.postgresql.org/docs/current/sql-alterfunction.html",
        "s04e81888353f": "https://www.postgresql.org/docs/current/sql-alterdefaultprivileges.html",
        "sc39eceeac711": "https://www.postgresql.org/docs/current/functions-info.html"
      }
    },
    "postgres-view": {
      "name": "PostgreSQL invoker-view minimum",
      "basis": "15",
      "sources": {
        "s14443e063ef1": "https://www.postgresql.org/docs/release/15.0/"
      }
    },
    "curl": {
      "name": "curl",
      "basis": "curl-8_14_1",
      "sources": {
        "s5e1383feef7d": "https://github.com/curl/curl/blob/curl-8_14_1/docs/cmdline-opts/write-out.md#L75-L79",
        "s3db522258e44": "https://raw.githubusercontent.com/curl/curl/curl-8_14_1/docs/cmdline-opts/header.md"
      }
    },
    "shellcheck": {
      "name": "ShellCheck",
      "basis": "v0.11.0",
      "sources": {
        "sf994764bf270": "https://github.com/koalaman/shellcheck/blob/v0.11.0/CHANGELOG.md#L1"
      }
    }
  },
  "claims": {
    "public-config": {"text": "Firebase API keys/config and Supabase publishable/anon keys are public identifiers, not authorization; hosted endpoints handle TLS.", "components": ["firebase", "supabase"], "sources": ["firebase:safeed4cd2b67", "firebase:sb0d26775f3b4", "supabase:s65d5b8043bad"], "status": "REASONED"},
    "firebase-ownership": {"text": "Require authentication and ownership separately in Firestore, RTDB and Storage; authentication-only rules do not isolate users.", "components": ["firebase"], "sources": ["firebase:s100c2cdbdd59", "firebase:s53bfe8b21868"], "status": "REASONED"},
    "firebase-starting": {"text": "Firestore production and RTDB locked modes deny clients; test templates expose data for about a month. Inspect expiry and replace open rules.", "components": ["firebase"], "sources": ["firebase:s622d3bb0665b", "firebase:sb2c933c841ef", "firebase:s75f018e0fac7"], "status": "REASONED"},
    "firestore-rules": {"text": "Rules version 2 recursive wildcards include the user document and descendants; version 1 excludes the parent. Unmatched paths deny and overlapping grants can reopen access.", "components": ["firebase"], "sources": ["firebase:s7bd11c22c7ce"], "status": "REASONED"},
    "rtdb-rules": {"text": "Owner rules under users.$uid need ancestor grants removed; child rules cannot revoke parent grants or filter parent reads.", "components": ["firebase"], "sources": ["firebase:sa6b1c4933e6a"], "status": "REASONED"},
    "firebase-storage": {"text": "Storage has separate rules; conflicting default prose/example warrants explicit deny-all followed by deliberate owner-path access.", "components": ["firebase"], "sources": ["firebase:s53bfe8b21868", "firebase:s0a7f54463abd"], "status": "REASONED"},
    "firebase-download": {"text": "Storage download URLs are non-expiring bearer credentials unaffected by tighter Rules; revoke tokens and use authorized getBlob/getBytes direct downloads.", "components": ["firebase"], "sources": ["firebase:s9b7e57b472c7", "firebase:sa0584b797732", "firebase:sfd1e7412abf6"], "status": "REASONED"},
    "firebase-rule-deploy": {"text": "Inspect and test deployed rules for every database/bucket/instance; keep local and deployed definitions synchronized.", "components": ["firebase"], "sources": ["firebase:sd6071548f6fe", "firebase:s14872143a9e8"], "status": "REASONED"},
    "firebase-server": {"text": "Admin SDK/server credentials bypass client Rules; keep credentials server-side and apply IAM and caller authorization.", "components": ["firebase"], "sources": ["firebase:s7bd11c22c7ce"], "status": "REASONED"},
    "firebase-callable": {"text": "Callable ID-token validation is optional authentication; reject missing request.auth, use its UID and validate resource access. First-generation handlers use context.auth.", "components": ["firebase"], "sources": ["firebase:s79da8f65f90a", "firebase:sc8f214d059d2", "firebase:s9a86df9623a6"], "status": "REASONED"},
    "firebase-callable-appcheck": {"text": "onCall enforceAppCheck needs firebase-functions 4.0.0 or newer; App Check does not replace caller/resource authorization.", "components": ["firebase"], "sources": ["firebase:sb0ff8f1726f7"], "status": "REASONED"},
    "firebase-http": {"text": "onRequest does not inherit callable auth; verify end-user tokens with verifyIdToken or restrict IAM invokers, then authorize the intended principal.", "components": ["firebase"], "sources": ["firebase:s49f78d054708", "firebase:s1bb711c9afeb", "firebase:sc9f86ea271f6"], "status": "REASONED"},
    "firebase-appcheck": {"text": "Register compatible clients and inspect metrics, then enforce App Check per product and per callable; registration alone enforces nothing.", "components": ["firebase"], "sources": ["firebase:sa71e958c99df", "firebase:sba7129c83405", "firebase:sb0ff8f1726f7"], "status": "REASONED"},
    "firebase-key-restrictions": {"text": "Apply one app-restriction type per key plus API restrictions; separate platforms and unrelated billable APIs, using the full Firebase product table.", "components": ["firebase"], "sources": ["firebase:sc78d5eb59b65", "firebase:safeed4cd2b67"], "status": "REASONED"},
    "firebase-anonymous": {"text": "Anonymous sign-in is opt-in; disable unused providers because anonymous accounts still satisfy authentication-only Rules.", "components": ["firebase"], "sources": ["firebase:s77e2cbd8a29a"], "status": "REASONED"},
    "firebase-enumeration": {"text": "Email enumeration protection defaults on only for projects created from September 15, 2023; signup can still return EMAIL_EXISTS.", "components": ["firebase"], "sources": ["firebase:s06808e4b6965"], "status": "REASONED"},
    "firebase-emulators": {"text": "Emulators default to localhost but missing Firestore/RTDB/Storage Rules configuration means open data; keep listeners, UI, hub, proxies and tunnels private.", "components": ["firebase"], "sources": ["firebase:sd8a1bda29f5c", "firebase:s69d9721c7f29"], "status": "REASONED"},
    "supabase-network": {"text": "Restrict hosted database/pooler client IPs with Network Restrictions, enforce SSL and protect database-role passwords.", "components": ["supabase"], "sources": ["supabase:sb787b5d63633", "supabase:s83e15676e1ff", "supabase:sf69cafb4bc6c"], "status": "REASONED"},
    "supabase-grants": {"text": "Data API access needs grants plus RLS; automatic-grant defaults are transitioning. Table Editor enables RLS, while SQL creation needs explicit enablement.", "components": ["supabase"], "sources": ["supabase:s6d5cf2d4dbf3"], "status": "REASONED"},
    "supabase-select": {"text": "The profiles baseline enables RLS, revokes broad grants and permits authenticated owners SELECT; audit inherited/column grants and existing policies.", "components": ["supabase", "postgres"], "sources": ["supabase:s46cff2590323", "postgres:s8e65a2f3f2bb"], "status": "REASONED"},
    "supabase-bypass": {"text": "With RLS enabled and no policy, ordinary subject roles get no rows; owners normally bypass, as do superusers/BYPASSRLS roles. TRUNCATE is outside RLS.", "components": ["postgres"], "sources": ["postgres:se9846041ce1f"], "status": "REASONED"},
    "supabase-writes": {"text": "Grant and policy INSERT/UPDATE/DELETE only when intended; UPDATE checks old/new ownership and needs applicable SELECT when reading columns.", "components": ["supabase", "postgres"], "sources": ["supabase:s46cff2590323", "postgres:s8e65a2f3f2bb"], "status": "REASONED"},
    "supabase-schemas": {"text": "public is exposed by default; restrict exposed schemas and deliberately grant schema/object access. Schema selection does not replace RLS.", "components": ["supabase"], "sources": ["supabase:s20ef046ac646"], "status": "REASONED"},
    "supabase-api-disable": {"text": "Disable an unused Data API to close generated REST endpoints; this does not disable all other services.", "components": ["supabase"], "sources": ["supabase:s6d5cf2d4dbf3"], "status": "REASONED"},
    "supabase-keys": {"text": "Publishable keys select anon or authenticated by session; secret and legacy service_role keys bypass RLS and belong only on trusted servers.", "components": ["supabase"], "sources": ["supabase:s65d5b8043bad"], "status": "REASONED"},
    "supabase-key-retire": {"text": "Replacement keys do not disable legacy keys; migrate consumers then explicitly deactivate legacy keys, or delete compromised secret keys.", "components": ["supabase"], "sources": ["supabase:sa946354db383"], "status": "REASONED"},
    "supabase-jwt-retire": {"text": "Rotation changes the signing key but retains previous trust until revocation; account for verifier caches and propagation.", "components": ["supabase"], "sources": ["supabase:sfc2f9ae0232b"], "status": "REASONED"},
    "supabase-view-owner": {"text": "Views use owner privileges/policies by default; disclosure depends on reachable schemas, grants, query and owner privileges, not anon-key possession alone.", "components": ["postgres", "supabase"], "sources": ["postgres:s13c54ab9cc6b", "supabase:s46cff2590323"], "status": "REASONED"},
    "supabase-view-invoker": {"text": "PostgreSQL 15+ security_invoker views apply caller policies and require underlying privileges.", "components": ["postgres-view", "postgres"], "sources": ["postgres-view:s14443e063ef1", "postgres:saa99ef28f60f", "postgres:s13c54ab9cc6b"], "status": "REASONED"},
    "supabase-view-legacy": {"text": "PostgreSQL 14 and earlier require revoking all view privileges from PUBLIC/anon/authenticated or unexposing the schema; updatable views can bypass RLS for writes.", "components": ["postgres"], "sources": ["postgres:s13c54ab9cc6b", "postgres:sb6224f4ac866", "postgres:sc39eceeac711"], "status": "REASONED"},
    "supabase-functions": {"text": "Prefer INVOKER; restrict DEFINER execution, use empty search_path with qualified references and enforce caller authorization including required MFA.", "components": ["supabase", "postgres"], "sources": ["supabase:s8405a9fb4b74", "postgres:sec39c317b06f", "postgres:s0fe66d71aa10"], "status": "REASONED"},
    "supabase-function-defaults": {"text": "New functions grant PUBLIC execution; create privileged functions and restrict grants transactionally. Global/default revocations are creator-specific and do not fix existing functions.", "components": ["postgres"], "sources": ["postgres:sec39c317b06f", "postgres:s04e81888353f"], "status": "REASONED"},
    "supabase-http": {"text": "Audit http/pg_net wrappers and revoke unneeded execute grants; constrain callers/destinations/data. Extension enablement alone does not prove exploitable SSRF.", "components": ["supabase"], "sources": ["supabase:s13da01bbbba5", "supabase:s76740bffcb32"], "status": "REASONED"},
    "supabase-vault": {"text": "Restrict vault.decrypted_secrets and privileged wrappers and keep Vault unexposed; at-rest encryption cannot prevent authorized plaintext queries.", "components": ["supabase"], "sources": ["supabase:s47bb8fa3e14e"], "status": "REASONED"},
    "supabase-buckets": {"text": "Private downloads need authorized access or time-limited signed URLs; public buckets bypass retrieval checks but not upload/delete/move/copy controls.", "components": ["supabase"], "sources": ["supabase:s1567fb838f20"], "status": "REASONED"},
    "supabase-storage-policies": {"text": "Authorize storage.objects separately by bucket and owner path; upload needs INSERT, upsert also SELECT/UPDATE, and deletion needs deliberate permission.", "components": ["supabase"], "sources": ["supabase:sdba7d7b6dcf8", "supabase:s9e1484f46eff", "supabase:see2d3be99ebd"], "status": "REASONED"},
    "supabase-realtime-default": {"text": "Public Realtime channels are allowed by default; disable them project-wide and also set client config.private.", "components": ["supabase"], "sources": ["supabase:s5674b1057e14"], "status": "REASONED"},
    "supabase-realtime-policy": {"text": "Broadcast/Presence receive/send need separate SELECT/INSERT policies on realtime.messages, constrained by topic ownership and extension.", "components": ["supabase"], "sources": ["supabase:s84efad0ba39d"], "status": "REASONED"},
    "supabase-changes": {"text": "Postgres Changes uses source-table authorization; private-channel policies are not universal and DELETE has separate limitations.", "components": ["supabase"], "sources": ["supabase:s694eab64f2ec"], "status": "REASONED"},
    "supabase-signup": {"text": "Disable signup, anonymous sign-ins and unused providers when unwanted; inspect hosted settings instead of assuming universal defaults.", "components": ["supabase"], "sources": ["supabase:sc797f0b63472"], "status": "REASONED"},
    "supabase-cli-auth": {"text": "CLI enable_signup defaults true and enable_anonymous_sign_ins false; local config edits do not prove hosted settings changed.", "components": ["supabase"], "sources": ["supabase:s3a5e39fe7b4d"], "status": "REASONED"},
    "supabase-mfa": {"text": "TOTP is available on every plan at writing; enrollment alone does not constrain data. Require aal2 using a restrictive policy alongside permissive ownership policies.", "components": ["supabase", "postgres"], "sources": ["supabase:s182755725d74", "supabase:s741468ff35a9", "postgres:s8e65a2f3f2bb"], "status": "REASONED"},
    "supabase-edge-jwt": {"text": "Per-function verify_jwt defaults true; --no-verify-jwt disables platform checking and requires handler authentication before protected work.", "components": ["supabase"], "sources": ["supabase:s7dfbb47b5d20", "supabase:sf7d438b8c080", "supabase:se52bbd097033"], "status": "REASONED"},
    "supabase-edge-auth": {"text": "Platform JWT success is not resource authorization and API-key compatibility can pass it; separately authorize users or verify webhook signatures.", "components": ["supabase"], "sources": ["supabase:sf7d438b8c080", "supabase:se52bbd097033"], "status": "REASONED"},
    "supabase-edge-secrets": {"text": "Edge environments contain privileged credentials including SUPABASE_SERVICE_ROLE_KEY; protect managed/local secrets, responses, logs and client bundles.", "components": ["supabase"], "sources": ["supabase:sb3c4c0993e14"], "status": "REASONED"},
    "verify-firestore": {"text": "Compare unsigned/A/B reads and writes to user documents and descendants, with a successful owner control; test parent documents to distinguish recursive-rule versions.", "components": ["firebase"], "sources": ["firebase:s7bd11c22c7ce"], "status": "REASONED"},
    "verify-rtdb": {"text": "Compare unsigned/A/B reads/writes to seeded RTDB owner paths; ancestor grants expose them while ownership rules deny unauthorized callers.", "components": ["firebase"], "sources": ["firebase:sa6b1c4933e6a"], "status": "REASONED"},
    "verify-firebase-storage": {"text": "Compare unsigned/A/B object reads and uploads; ownership rules must deny unrelated callers while owner operations succeed.", "components": ["firebase"], "sources": ["firebase:s0a7f54463abd"], "status": "REASONED"},
    "verify-download-token": {"text": "Same sessionless download URL works after Rules tightening but must lose bytes after token revocation; owner getBytes remains successful and network/CORS failures are inconclusive.", "components": ["firebase"], "sources": ["firebase:s9b7e57b472c7", "firebase:sa0584b797732", "firebase:sfd1e7412abf6"], "status": "REASONED"},
    "verify-tables": {"text": "Pair unsigned/A/B profiles GETs against seeded rows, using ordinary credentials and required MFA; test intended writes and persisted effects separately.", "components": ["supabase", "postgres", "curl"], "sources": ["supabase:s92b405dc3c7e", "postgres:se9846041ce1f", "supabase:s741468ff35a9", "curl:s5e1383feef7d", "curl:s3db522258e44"], "status": "REASONED", "verify": [1]},
    "verify-views": {"text": "Compare view reads with table boundaries; owner-privileged exposure must close under invoker/revoked access while intended reads or deliberate removal are confirmed.", "components": ["postgres"], "sources": ["postgres:s13c54ab9cc6b"], "status": "REASONED"},
    "verify-rpc": {"text": "Test every API function overload with valid harmless arguments as unsigned/A/B; unauthorized data or operations must be denied while the intended caller succeeds.", "components": ["supabase"], "sources": ["supabase:s087c8cf42ab0", "supabase:s8405a9fb4b74"], "status": "REASONED"},
    "verify-http": {"text": "Probe HTTP wrappers with a controlled collector and marker; unauthorized fixed calls must emit no request. Commit pg_net fixture transactions before expecting delivery.", "components": ["supabase"], "sources": ["supabase:s76740bffcb32"], "status": "REASONED"},
    "verify-vault": {"text": "Use a disposable Vault canary to compare exposed/fixed wrappers; inspect function and table privileges as supporting evidence.", "components": ["supabase", "postgres"], "sources": ["supabase:s47bb8fa3e14e", "postgres:sc39eceeac711"], "status": "REASONED"},
    "verify-storage": {"text": "Compare public URL and A/B private downloads plus intended uploads/upserts; unauthorized callers must receive no bytes or cross-owner writes.", "components": ["supabase"], "sources": ["supabase:sc29febbb230e", "supabase:see2d3be99ebd", "supabase:s1567fb838f20"], "status": "REASONED"},
    "verify-realtime": {"text": "Compare A/B join, Broadcast and Presence delivery; public-disabled clients lacking private=true must fail, and connection alone is insufficient.", "components": ["supabase"], "sources": ["supabase:s5674b1057e14", "supabase:s84efad0ba39d"], "status": "REASONED"},
    "verify-changes": {"text": "Observe A/B INSERT/UPDATE subscription events against seeded rows; fixed table authorization withholds unrelated events. Evaluate DELETE separately.", "components": ["supabase"], "sources": ["supabase:s694eab64f2ec"], "status": "REASONED"},
    "verify-edge": {"text": "Compare no/invalid Bearer without apikey, authorized owners and valid webhook signatures; distinguish platform 401 from handler authorization and inspect effects/secrets.", "components": ["supabase"], "sources": ["supabase:se52bbd097033", "supabase:sf7d438b8c080", "supabase:sb3c4c0993e14"], "status": "REASONED"},
    "verify-firebase-functions": {"text": "Compare callable requests with valid App Check but missing user auth and A/B operations; HTTP endpoints need separate invalid/valid user or IAM comparisons.", "components": ["firebase"], "sources": ["firebase:s79da8f65f90a", "firebase:s49f78d054708"], "status": "REASONED"},
    "verify-appcheck": {"text": "Repeat owner requests with/without App Check per product/callable; enforcement must deny missing attestation while compatible clients work.", "components": ["firebase"], "sources": ["firebase:sba7129c83405", "firebase:sb0ff8f1726f7"], "status": "REASONED"},
    "verify-api-restrictions": {"text": "Test intended versus excluded apps/referrers after key restrictions, retaining successful intended product traffic.", "components": ["firebase"], "sources": ["firebase:safeed4cd2b67", "firebase:sc78d5eb59b65"], "status": "REASONED"},
    "verify-emulators": {"text": "Enumerate hub /emulators and sockets, compare missing versus loaded Rules and second-host connectivity, and retain local owner controls.", "components": ["firebase"], "sources": ["firebase:sd8a1bda29f5c", "firebase:s69d9721c7f29"], "status": "REASONED"},
    "verify-firebase-accounts": {"text": "Sign out before each Anonymous signup test and check isNewUser; disabled providers must reject creation. Enumeration tests compare sign-in errors, not EMAIL_EXISTS signup behavior.", "components": ["firebase"], "sources": ["firebase:s8c90f9f6c7fa", "firebase:s8c8336ec252e", "firebase:s142e56472093", "firebase:s77e2cbd8a29a", "firebase:s06808e4b6965"], "status": "REASONED"},
    "verify-supabase-accounts": {"text": "Fresh signup and anonymous creation must fail under invite-only/anonymous-disabled settings while an invited account still signs in.", "components": ["supabase"], "sources": ["supabase:sc797f0b63472", "supabase:sa2dd4637969e", "supabase:sad79d4d1b6ee"], "status": "REASONED"},
    "verify-mfa": {"text": "Owner profiles GET with aal1 must yield no protected rows under the restrictive policy, while fresh aal2 returns the seeded owner row.", "components": ["supabase"], "sources": ["supabase:s741468ff35a9"], "status": "REASONED", "verify": [1]},
    "verify-key-retirement": {"text": "Compare old/new API keys after explicit deactivation and old/new JWTs after revocation, accounting for propagation and caches.", "components": ["supabase"], "sources": ["supabase:sa946354db383", "supabase:sfc2f9ae0232b"], "status": "REASONED"},
    "verify-api-removal": {"text": "Previously successful profiles requests must stop returning fixtures after schema removal or Data API disabling; retained schemas need authorized controls.", "components": ["supabase"], "sources": ["supabase:s6d5cf2d4dbf3", "supabase:s20ef046ac646"], "status": "REASONED"},
    "verify-bundle": {"text": "Filename-only service_role/eyJ/sb_secret_ scanning yields review candidates, not proof of leaks; public anon JWTs are legitimate. Use a marker control and inspect encoded/split secrets separately.", "components": ["supabase"], "sources": ["supabase:s65d5b8043bad"], "status": "REASONED", "verify": [2]},
    "local-guards": {"text": "Historical local guard tests rejected placeholders and malformed set lines; this guide's assessment is shell behavior only, not live authorization. The recorded ShellCheck 0.11.0 has a release citation, not host-binary evidence; bash and other tool/parser versions are unrecorded. Runs covered earlier forms, whose guard refusals and bundle scan result arms exited 0; current forms were not re-run.", "components": ["supabase", "shellcheck"], "sources": ["supabase:s92b405dc3c7e", "supabase:s65d5b8043bad", "shellcheck:sf994764bf270"], "status": "DEMONSTRATED", "evidence": "Local guard tests refused embedded `REPLACE_WITH_` placeholders, `example.com`, angle brackets, empty values, and omitted or shortened `set --` lines."},
    "local-syntax": {"text": "Recorded ShellCheck 0.11.0/bash and JSON/TOML/JavaScript parsing passed; this guide's assessment is that these checks do not compile Firebase Rules, execute SQL or demonstrate services. Only the ShellCheck release is cited; other versions are unrecorded. Bash runs covered earlier forms, whose guard refusals and bundle scan result arms exited 0; current forms get only gate bash -n and ShellCheck.", "components": ["firebase", "supabase", "shellcheck"], "sources": ["firebase:sa6b1c4933e6a", "firebase:sd8a1bda29f5c", "supabase:s3a5e39fe7b4d", "firebase:sc8f214d059d2", "shellcheck:sf994764bf270"], "status": "DEMONSTRATED", "evidence": "The RTDB JSON, `firebase.json` fragment, Auth TOML, and callable JavaScript passed local parsing checks."}
  }
}
````
<!-- version-basis:end -->
